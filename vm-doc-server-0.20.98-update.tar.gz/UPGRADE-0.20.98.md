# Upgrade VM-DOC Server 0.20.97 → 0.20.98

Hotfix exclusiv frontend pentru pagina **Agenți**.

1. Oprește `vm-doc-server`.
2. Aplică update-ul peste 0.20.97.
3. Recompilează/repornește serverul conform procedurii curente.
4. În browser execută `Ctrl+F5` pentru a încărca `app.js?v=0.20.98`.

Nu există migrare DB și nu este necesar update de agent.
