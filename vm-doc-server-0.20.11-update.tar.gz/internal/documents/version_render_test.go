package documents

import (
	"strings"
	"testing"

	"vm-doc-server/internal/domain"
)

const mysqlWarningVersion = "mysql: [Warning] Using a password on the command line interface can be insecure.\nmysql  Ver 14.14 Distrib 5.5.37, for Linux (x86_64)"

func TestDocumentVersionCleanupCoversStructuredViews(t *testing.T) {
	softwareRows := primarySoftwarePreviewRows(domain.SoftwareVMView{Items: []domain.SoftwareItem{{Name: "MySQL", Version: mysqlWarningVersion, Primary: true, Present: true}}})
	if len(softwareRows) != 1 || strings.Contains(strings.ToLower(softwareRows[0].Value), "warning") || !strings.Contains(softwareRows[0].Value, "5.5.37") {
		t.Fatalf("software preview leaked version warning: %#v", softwareRows)
	}

	databaseRows := databasePreviewRows(domain.DatabaseVMView{
		Host:      &domain.DatabaseHostSummary{InstanceCount: 1},
		Instances: []domain.DatabaseInstance{{Product: "MySQL", Engine: "mysql", InstanceName: "default", Version: mysqlWarningVersion}},
	})
	joinedDB := ""
	for _, row := range databaseRows {
		joinedDB += row.Label + " " + row.Value + "\n"
	}
	if strings.Contains(strings.ToLower(joinedDB), "warning") || !strings.Contains(joinedDB, "5.5.37") {
		t.Fatalf("database preview leaked version warning: %q", joinedDB)
	}

	dockerXML := dockerDocumentXML(domain.DockerVMView{Host: &domain.DockerHostSummary{Installed: true, Version: "docker: [Warning] ignored config\nDocker version 27.3.1, build abc"}})
	if strings.Contains(strings.ToLower(dockerXML), "warning") || !strings.Contains(dockerXML, "27.3.1") {
		t.Fatalf("docker DOCX leaked version warning: %q", dockerXML)
	}
}

func TestServiceDOCXAndMarkdownDoNotLeakPackageVersionWarnings(t *testing.T) {
	data := ServiceGenerationData{
		Service: domain.InternalService{Name: "MySQL test"},
		PrimaryComponents: []ServicePrimaryComponent{{
			VMName:         "db01",
			ServiceName:    "mysql.service",
			SoftwareName:   "MySQL",
			Version:        mysqlWarningVersion,
			PackageName:    "mysql-server",
			PackageVersion: "warning: rpm database notice\n5.5.37-1",
			ActiveState:    "active",
			Detected:       true,
		}},
	}

	xml := serviceDocumentBodyXML(data)
	if strings.Contains(strings.ToLower(xml), "warning") {
		t.Fatalf("service DOCX leaked warning: %q", xml)
	}
	if !strings.Contains(xml, "5.5.37") || !strings.Contains(xml, "5.5.37-1") {
		t.Fatalf("service DOCX lost cleaned MySQL versions: %q", xml)
	}

	markdown := string(RenderServiceMarkdown(data))
	if strings.Contains(strings.ToLower(markdown), "warning") {
		t.Fatalf("service Markdown leaked warning: %q", markdown)
	}
	if !strings.Contains(markdown, "5.5.37") || !strings.Contains(markdown, "5.5.37-1") {
		t.Fatalf("service Markdown lost cleaned MySQL versions: %q", markdown)
	}
}

func TestVMMarkdownAnnexDoesNotLeakVersionWarnings(t *testing.T) {
	var out strings.Builder
	data := GenerationData{
		Software: domain.SoftwareVMView{Items: []domain.SoftwareItem{{Name: "MySQL Tools", Version: mysqlWarningVersion, Publisher: "Oracle", Primary: true, Present: true}}},
		Docker:   domain.DockerVMView{Host: &domain.DockerHostSummary{Installed: true, Version: "docker: [Warning] ignored config\nDocker version 27.3.1, build abc"}},
	}
	renderVMMarkdownAnnex(&out, data, 2)
	markdown := out.String()
	if strings.Contains(strings.ToLower(markdown), "warning") {
		t.Fatalf("VM Markdown leaked version warning: %q", markdown)
	}
	if !strings.Contains(markdown, "5.5.37") || !strings.Contains(markdown, "27.3.1") {
		t.Fatalf("VM Markdown lost cleaned versions: %q", markdown)
	}
}

func TestGenericInventoryVersionCellDropsWarning(t *testing.T) {
	got := humanizeValueForLabel("Versiune", mysqlWarningVersion)
	if strings.Contains(strings.ToLower(got), "warning") {
		t.Fatalf("generic version cell leaked warning: %q", got)
	}
}
