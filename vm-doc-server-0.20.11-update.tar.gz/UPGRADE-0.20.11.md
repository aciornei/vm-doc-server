# Upgrade vm-doc-server 0.20.10 → 0.20.11

Release exclusiv server-side. Nu necesită update de agent și nu adaugă migrare SQL.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.10 vm-doc-server-0.20.11
tar -xzf /cale/vm-doc-server-0.20.11-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.11
cd /usr/local/src/vm-doc-server-0.20.11
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Nu rulați `go mod vendor` pe serverul izolat.
