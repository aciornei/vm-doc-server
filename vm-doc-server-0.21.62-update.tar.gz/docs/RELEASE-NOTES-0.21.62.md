# VM-DOC Server 0.21.62 — Filtrare Resource Pool vCenter

Bază: 0.21.61 | Data: 2026-10-21 | Agent: 1.7.18 neschimbat

## Funcționalitate
- VM-uri → Surse & sincronizări → Pool-uri: Descoperă/actualizează, bifează/debifează, salvează.
- Toate pool-urile noi sunt **incluse implicit**. Selecția este persistată per sursă pe ID MoRef, nu pe nume.
- Statistici VM și POWERED_ON per pool și avertizare pentru pool-uri excluse cu VM-uri pornite, inclusiv în lista surselor vCenter.
- Importul exclude VM-uri noi din pool-uri debifate; cele existente se păstrează în DB și se marchează excluse logic, fără ștergere/retire/missing. La selectarea ulterioară reapar.
- Fișele VM noi, exporturile VM și publicarea individuală Outline nu includ VM-urile excluse.
- Sincronizările manuale și programate aplică aceeași politică.
- Descoperirea și sincronizarea eșuează explicit dacă endpointurile vCenter de pool sunt inaccesibile; plasamentele neidentificate nu sunt acceptate în prezența excluderilor.

## Modificări tehnice
- Migrare 079 (tabel `vcenter_resource_pools`, `virtual_machines.vcenter_resource_pool_moid`, `excluded_by_vcenter_pool`).
- `internal/vcenter/pools_client.go`, `pools.go`, `service.go`, `vms.go` și API `internal/server/server.go`.
- Swagger/OpenAPI: GET/PUT `/api/v1/vcenter/sources/{id}/pools`; POST `.../pools/scan`.
- Pagină VM / Surse: selector cu counts și avertizare; cache busting de 0.21.62.

## Limite și validări necesare
- Testare obligatorie în staging cu vCenter 8.0.3 și MariaDB reală, inclusiv pool-uri ierarhice, mutarea VM-urilor, surse multiple și confirmarea numărătorilor POWERED_ON.
- Bazele existente ale serviciilor și documentele istorice nu sunt șterse; rapoartele transversale de servicii/beneficiari și documentele de servicii necesită o verificare ulterioară pentru referințe istorice la VM-uri excluse.
- Build integral Go necesită vendor/dependințele mediului offline; în acest mediu au trecut testele pachetelor independente, sintaxa JS, formatul Go și parsarea YAML.
