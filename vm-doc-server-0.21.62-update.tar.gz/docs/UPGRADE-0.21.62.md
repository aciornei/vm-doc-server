# Upgrade VM-DOC 0.21.61 → 0.21.62

1. Backup MariaDB + aplicație, păstrează binarul 0.21.61 și configurația.
2. Test în **staging**, aplică arhiva update în rădăcina proiectului cu `tar -xzf vm-doc-server-0.21.62-update.tar.gz` (sau patch incremental în rădăcina sursei `patch -p1 < ...patch`).
3. Refolosește `vendor/` existent de pe serverul offline, verifică `go test ./...` și `make build`.
4. Oprește instanța înainte de schimbarea binarului și salvează backup-ul. Migrarea `079_vcenter_resource_pools.up.sql` se aplică automat la pornire.
5. VM-uri → Surse & sincronizări → Pool-uri → **Descoperă / actualizează** → bifează/debifează → Salvează selecția → Sync.
6. Confirmă că VM-urile noi excluse nu apar în inventarul activ și că VM-urile deja cunoscute sunt doar ascunse, nu șterse/retrase. Verifică avertizarea pentru `POWERED_ON` excluse.
7. Rollback: pentru revenirea la binarul 0.21.61, păstrează coloanele/tabela aditive (nu executa DOWN în producție decât după backup, când niciun proces 0.21.62 nu rulează); setările noi nu sunt interpretate de versiunea veche.

**Note:** Noi resource pool-uri sunt bifate implicit. Dacă vCenter nu returnează lista completă de pool-uri sau dacă filtrarea API e inaccesibilă, sincronizarea se oprește cu eroare în loc să aplice o excludere nesigură.
