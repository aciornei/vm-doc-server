-- Per-vCenter resource pool inclusion policy; safe default is all pools included.
CREATE TABLE IF NOT EXISTS vcenter_resource_pools (
  vcenter_source_id BIGINT UNSIGNED NOT NULL,
  moid VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  include_in_docs TINYINT(1) NOT NULL DEFAULT 1,
  vm_count INT UNSIGNED NOT NULL DEFAULT 0,
  powered_on_count INT UNSIGNED NOT NULL DEFAULT 0,
  present_in_vcenter TINYINT(1) NOT NULL DEFAULT 1,
  last_seen_at DATETIME(6) NULL,
  PRIMARY KEY (vcenter_source_id,moid),
  CONSTRAINT fk_vc_pool_source FOREIGN KEY (vcenter_source_id) REFERENCES vcenter_sources(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE virtual_machines
  ADD COLUMN vcenter_resource_pool_moid VARCHAR(128) NOT NULL DEFAULT '',
  ADD COLUMN excluded_by_vcenter_pool TINYINT(1) NOT NULL DEFAULT 0,
  ADD KEY idx_vm_pool_excluded (vcenter_source_id, excluded_by_vcenter_pool, vcenter_resource_pool_moid);
