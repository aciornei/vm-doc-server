ALTER TABLE virtual_machines DROP KEY idx_vm_pool_excluded, DROP COLUMN excluded_by_vcenter_pool, DROP COLUMN vcenter_resource_pool_moid;
DROP TABLE IF EXISTS vcenter_resource_pools;
