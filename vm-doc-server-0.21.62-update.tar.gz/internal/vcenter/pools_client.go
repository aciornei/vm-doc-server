package vcenter

import (
	"context"
	"fmt"
	"net/url"
	"sort"
	"strings"
	"sync"
)

// RemotePool retains MoRef identity: pool names are not unique across clusters.
type RemotePool struct {
	MoID           string `json:"resource_pool_moid"`
	Name           string `json:"name"`
	VMCount        int    `json:"vm_count"`
	PoweredOnCount int    `json:"powered_on_count"`
}
type poolSummary struct {
	ID   string `json:"resource_pool"`
	Name string `json:"name"`
}

// PoolDiscovery uses a single authenticated vCenter session to obtain a
// complete placement map. An error aborts the sync: partial placements must
// never silently bypass an exclusion policy.
func (c *Client) PoolDiscovery(ctx context.Context) ([]RemotePool, map[string]string, error) {
	session, err := c.createSession(ctx)
	if err != nil {
		return nil, nil, err
	}
	defer c.deleteSession(context.Background(), session)
	return c.poolDiscoverySession(ctx, session)
}

func (c *Client) poolDiscoverySession(ctx context.Context, session string) ([]RemotePool, map[string]string, error) {
	var raw []poolSummary
	if err := c.get(ctx, session, "/api/vcenter/resource-pool", &raw); err != nil {
		return nil, nil, fmt.Errorf("list vCenter resource pools: %w", err)
	}
	pools := make([]RemotePool, 0, len(raw))
	for _, r := range raw {
		if strings.TrimSpace(r.ID) != "" {
			pools = append(pools, RemotePool{MoID: r.ID, Name: r.Name})
		}
	}
	// Query the VM list once per pool. VMware's REST VM summaries have no pool
	// field. A filtered list is the supported way to establish membership.
	type result struct {
		id  string
		vms []listVM
		err error
	}
	results := make([]result, len(pools))
	jobs := make(chan int)
	workers := c.workers
	if workers > len(pools) {
		workers = len(pools)
	}
	var wg sync.WaitGroup
	for k := 0; k < workers; k++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				var vms []listVM
				path := "/api/vcenter/vm?resource_pools=" + url.QueryEscape(pools[i].MoID)
				err := c.get(ctx, session, path, &vms)
				results[i] = result{id: pools[i].MoID, vms: vms, err: err}
			}
		}()
	}
	for i := range pools {
		if ctx.Err() != nil {
			break
		}
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	if err := ctx.Err(); err != nil {
		return nil, nil, err
	}
	// When a VM appears in multiple pool filters (parent + child), choose the
	// most specific matching result (fewest VMs). Stable sort resolves ties.
	sort.SliceStable(results, func(i, j int) bool {
		if len(results[i].vms) != len(results[j].vms) {
			return len(results[i].vms) < len(results[j].vms)
		}
		return results[i].id < results[j].id
	})
	assigned := map[string]string{}
	for _, r := range results {
		if r.err != nil {
			return nil, nil, fmt.Errorf("resource pool %s VM membership: %w", r.id, r.err)
		}
		for _, v := range r.vms {
			if _, ok := assigned[v.VM]; !ok {
				assigned[v.VM] = r.id
			}
		}
	}
	byID := map[string]int{}
	for i := range pools {
		byID[pools[i].MoID] = i
	}
	// Counts reflect resolved, nonduplicated memberships.
	for _, r := range results {
		for _, v := range r.vms {
			if assigned[v.VM] != r.id {
				continue
			}
			idx := byID[r.id]
			pools[idx].VMCount++
			if v.PowerState == "POWERED_ON" {
				pools[idx].PoweredOnCount++
			}
		}
	}
	sort.Slice(pools, func(i, j int) bool {
		if pools[i].Name != pools[j].Name {
			return pools[i].Name < pools[j].Name
		}
		return pools[i].MoID < pools[j].MoID
	})
	return pools, assigned, nil
}

// InventoryWithPools fetches full VM details only for included pools. Excluded
// VM summaries remain present so existing VM rows can be marked excluded,
// not incorrectly marked missing or retired. Unknown membership stays included.
func (c *Client) InventoryWithPools(ctx context.Context, include map[string]bool) ([]RemoteVM, []RemotePool, error) {
	session, err := c.createSession(ctx)
	if err != nil {
		return nil, nil, err
	}
	defer c.deleteSession(context.Background(), session)
	pools, placement, err := c.poolDiscoverySession(ctx, session)
	if err != nil {
		return nil, nil, err
	}
	var list []listVM
	if err = c.get(ctx, session, "/api/vcenter/vm", &list); err != nil {
		return nil, nil, err
	}
	for _, item := range list {
		if placement[item.VM] == "" {
			for _, allowed := range include {
				if !allowed {
					return nil, nil, fmt.Errorf("cannot resolve resource pool for VM %s while exclusions are enabled", item.VM)
				}
			}
		}
	}
	out := make([]RemoteVM, len(list))
	jobs := make(chan int)
	workers := c.workers
	if workers > len(list) {
		workers = len(list)
	}
	errCh := make(chan error, 1)
	var wg sync.WaitGroup
	for k := 0; k < workers; k++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				item := list[i]
				poolID := placement[item.VM]
				if allowed, exists := include[poolID]; exists && !allowed {
					out[i] = RemoteVM{MoID: item.VM, Name: item.Name, PowerState: item.PowerState, ResourcePoolID: poolID}
					continue
				}
				vm, e := c.loadVM(ctx, session, item)
				if e != nil {
					select {
					case errCh <- fmt.Errorf("read VM %s: %w", item.VM, e):
					default:
					}
					continue
				}
				vm.ResourcePoolID = poolID
				out[i] = vm
			}
		}()
	}
	for i := range list {
		if ctx.Err() != nil {
			break
		}
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	select {
	case e := <-errCh:
		return nil, nil, e
	default:
	}
	if e := ctx.Err(); e != nil {
		return nil, nil, e
	}
	return out, pools, nil
}
