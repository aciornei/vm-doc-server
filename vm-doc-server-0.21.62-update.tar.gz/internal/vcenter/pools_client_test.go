package vcenter

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
	"vm-doc-server/internal/domain"
)

func TestPoolInventoryExcludesAndPreservesPoweredOnWarning(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/session", func(w http.ResponseWriter, r *http.Request) { _ = json.NewEncoder(w).Encode("session") })
	mux.HandleFunc("DELETE /api/session", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusNoContent) })
	mux.HandleFunc("GET /api/vcenter/resource-pool", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]map[string]string{{"resource_pool": "resgroup-1", "name": "ACTIVE"}, {"resource_pool": "resgroup-2", "name": "QUARANTINE"}})
	})
	mux.HandleFunc("GET /api/vcenter/vm", func(w http.ResponseWriter, r *http.Request) {
		var list []map[string]any
		switch r.URL.Query().Get("resource_pools") {
		case "resgroup-1":
			list = []map[string]any{{"vm": "vm-1", "name": "GOOD", "power_state": "POWERED_ON"}}
		case "resgroup-2":
			list = []map[string]any{{"vm": "vm-2", "name": "OLD", "power_state": "POWERED_ON"}}
		default:
			list = []map[string]any{{"vm": "vm-1", "name": "GOOD", "power_state": "POWERED_ON"}, {"vm": "vm-2", "name": "OLD", "power_state": "POWERED_ON"}}
		}
		_ = json.NewEncoder(w).Encode(list)
	})
	mux.HandleFunc("GET /api/vcenter/vm/vm-1", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{"identity": map[string]any{"name": "GOOD"}, "power_state": "POWERED_ON"})
	})
	mux.HandleFunc("GET /api/vcenter/vm/vm-2", func(w http.ResponseWriter, r *http.Request) {
		t.Error("excluded VM details must not be requested")
		http.Error(w, "should not load", 500)
	})
	server := httptest.NewServer(mux)
	defer server.Close()
	client, err := NewClient(domain.VCenterSource{BaseURL: server.URL, VerifyTLS: false}, "", 5*time.Second, 2)
	if err != nil {
		t.Fatal(err)
	}
	vms, pools, err := client.InventoryWithPools(context.Background(), map[string]bool{"resgroup-1": true, "resgroup-2": false})
	if err != nil {
		t.Fatal(err)
	}
	if len(vms) != 2 || vms[0].ResourcePoolID != "resgroup-1" || vms[1].ResourcePoolID != "resgroup-2" {
		t.Fatalf("wrong placement: %#v", vms)
	}
	if vms[1].InstanceUUID != "" || vms[1].PowerState != "POWERED_ON" {
		t.Fatalf("excluded VM should have only a summary: %+v", vms[1])
	}
	if len(pools) != 2 || pools[1].PoweredOnCount != 1 {
		t.Fatalf("missing powered on warning: %+v", pools)
	}
}

func TestPoolInventoryRejectsAmbiguousMembershipWhenExcluded(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/session", func(w http.ResponseWriter, r *http.Request) { _ = json.NewEncoder(w).Encode("session") })
	mux.HandleFunc("DELETE /api/session", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(204) })
	mux.HandleFunc("GET /api/vcenter/resource-pool", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]map[string]string{{"resource_pool": "resgroup-2", "name": "ARCHIVE"}})
	})
	mux.HandleFunc("GET /api/vcenter/vm", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("resource_pools") != "" {
			_ = json.NewEncoder(w).Encode([]any{})
			return
		}
		_ = json.NewEncoder(w).Encode([]map[string]any{{"vm": "vm-3", "name": "UNMAPPED"}})
	})
	server := httptest.NewServer(mux)
	defer server.Close()
	client, _ := NewClient(domain.VCenterSource{BaseURL: server.URL}, "", 5*time.Second, 1)
	if _, _, err := client.InventoryWithPools(context.Background(), map[string]bool{"resgroup-2": false}); err == nil {
		t.Fatal("must fail closed on unknown pool placement")
	}
}
