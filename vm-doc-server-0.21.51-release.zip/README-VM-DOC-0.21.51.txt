VM-DOC Server 0.21.51 — patch peste 0.21.50.
Arhiva conține: surse complete (source.zip), update incremental (update.tar.gz), patch și documente, scripts PREVIEW/CLEANUP.
Agentul 1.7.18 rămâne neschimbat.
DOAR pentru versiunea server 0.21.50, nu aplicați incremental pe versiuni mai vechi.
SQL de ștergere rulează manual după backup, cu serverul oprit.
Verificați UPGRADE-0.21.51.md și RELEASE-NOTES-0.21.51.md.
