# Upgrade VM-DOC Server 0.21.50 → 0.21.51

Schimbare punctuală a detectorului de modificări. Agent 1.7.18 nemodificat. Fără migrare SQL automată, fără schimbare API.

1. Faceți backup la sursele și binarul serverului și la baza MariaDB (`mariadb-dump` / `mysqldump`, conform politicii locale).
2. Opriți serverul pentru deployment (`systemctl stop vm-doc-server`). Păstrați `vendor/` și configurațiile locale intacte.
3. Aplicați `vm-doc-server-0.21.51-update.tar.gz` **peste sursele 0.21.50**, ori aplicați patch-ul din rădăcina codului, ori folosiți sursa completă. Nu aplicați update direct peste versiuni mai vechi.
4. Pe sistemul offline cu dependințele Go existente: `GOPROXY=off go test ./internal/inventorychanges`, apoi `GOPROXY=off go test ./...` și `GOPROXY=off make build`. Instalați binarul doar dacă toate verificările cerute de procedura locală reușesc.
5. Reporniți `vm-doc-server` și confirmați versiunea `0.21.51` în UI/log.
6. Pentru curățarea datelor **după verificarea noilor colectări**, opriți din nou serverul; faceți backup MariaDB, apoi `mariadb -u ... -p NUME_BAZA < scripts/preview-inventory-changes-cleanup.sql`. Verificați baza curentă și numerele candidate.
7. Numai cu backup verificat și lista de candidați aprobată: `mariadb -u ... -p NUME_BAZA < scripts/cleanup-inventory-changes.sql`. Reporniți serverul și refaceți interogările de top.

SQL-ul cumulează regulile 0.21.50 + 0.21.51, deci **nu** rulați de două ori cleanup-ul vechi separat. Nu atinge snapshoturi brute sau evenimente deja revizuite, cu decizii sau observații. Ștergerea este ireversibilă fără backup. Nu s-a testat încă SQL-ul pe MariaDB reală aici.

Rollback cod: restaurați sursele/binarul 0.21.50, păstrând copia configurației. Rollback date: numai din dump pre-cleanup, dacă ați executat curățarea manuală.
