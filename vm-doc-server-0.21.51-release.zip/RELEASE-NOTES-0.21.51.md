# VM-DOC Server 0.21.51 — reducere zgomot suplimentar

Pornire: 0.21.50 (20 octombrie 2026). Agent: 1.7.18, nemodificat.

- Ignorăm exclusiv familii Microsoft cunoscute de servicii Windows per-user cu sufix hex, precum PrintWorkflowUserSvc_6d76121b și ConsentUxUserSvc_6d76121b. Nu aplicăm regula altor servicii.
- Acoperim lxd-installer@177-1372636-0.service și alte instanțe strict numerice/compuse; numele arbitrare sunt păstrate.
- Versiunile cu linii [Warning]/[Error] sunt normalizate DOAR la comparația pentru inventory_changes. Sunt păstrate prefixele de versiune reale și versiunile din package_version; inventarul brut nu se alterează.
- Preview/cleanup manual cumulativ 0.21.50 + 0.21.51, cu protejarea review-urilor și a observațiilor. Preview/DELETE pentru warnings e intenționat conservator (timestamp în format 6 cifre, fără linii suplimentare), pentru a nu șterge un upgrade real.
- Nu există migrare SQL automată, schimbare API, reconstruire agent sau modificare a politicii Outline/Vault.

Validare: Go teste `internal/inventorychanges` OK; compilarea completă este blocată local de lipsa modulelor/vendor offline, iar SQL pe MariaDB reală rămâne de verificat în staging.
