# VM-DOC Server 0.21.85 — Modificări și documentare (UI)

**Data:** 23.10.2026. **Bază:** 0.21.84. **Agent:** 1.7.18, neschimbat.

## Global Modificări

- Navigare mare identică cu `VM-uri → Inventar VM / Surse & sincronizări`: **Modificări / De documentat / Ghid**, cu subtitluri.
- Modificări: șase carduri cu total, noi, documentație nesetată, necesită documentație, **VM de documentat** și **servicii de documentat**.
- De documentat: trei carduri cu total de obligații restante și număr distinct de VM-uri/servicii afectate. Tabel cu rânduri compacte, aliniere pe coloane: resursă/VM, categorie/obiect, modificare, revizie/datǎ, documentație, acțiune.
- Filtre globale: căutare după VM/serviciu/obiect/sumar, resursă, stare obligație, categorie, revizie; selector 10/20/50/100 rânduri. Paginare reală server-side.
- **Export Excel** din De documentat respectă aceleași filtre; exportă toate paginile potrivite, maximum 20.000 de rânduri. Nu exportă JSON brut, parole sau linkuri Vault.
- Ghid reorganizat cu pașii Detectează → Revizuiește → Documentează, matricea de stări, explicația baseline-ului și detectorului semantic.

## VM → Modificări

- Timeline: checkboxul „Include evenimentele ignorate” are aspect de switch și aliniere compactă.
- Modificări: overflow orizontal restrâns la tabelul intern, fără lărgirea paginii.
- De documentat: reutilizează tabelul/filtrele/exportul din pagina globală, dar numai obligațiile VM-ului curent (nu închide în mod implicit obligațiile serviciilor).
- Ghid: aceleași explicații și aceeași matrice ca în pagina globală.

## Clopoțel

- Maximum **5 resurse** afișate, cele mai recente; contorul rămâne totalul resurselor distincte.
- Rânduri compacte, textul privind restanțele este scurt (`X restante`) și nu rupe linia.
- Link **„Vezi toate obligațiile (N)”** către lista globală paginată.

## Compatibilitate, validare și limite

- Adaugă `GET /api/v1/changes/documentation/export` și extinde filtrele `q`, `category`, `review_status` pentru `GET /api/v1/changes/documentation/tasks`.
- **Fără migrare SQL nouă**; stările, obligațiile, baseline-ul și regulile de documentare rămân neschimbate.
- Testele Go independente și JS trec; Chromium a verificat navigarea, filtrarea, paginarea, query-ul exportului și lipsa scrollului paginii în fixture la 640/880/1440 px.
- **Nevalidate aici:** build Go complet cu vendor sincronizat, interogările SQL pe MariaDB reală, fișierul XLSX descărcat din aplicație și aspectul integrat pe serverul de producție.
