# Upgrade VM-DOC 0.21.84 → 0.21.85

1. Opriți serverul înainte de instalarea noului binar și păstrați backup binar/surse și un backup MariaDB.
2. Aplicați fișierul `vm-doc-server-0.21.84-to-0.21.85-update.tar.gz` în directorul **surselor 0.21.84** sau folosiți ZIP-ul complet cu sursele 0.21.85.
3. Verificați structura: `bash scripts/cleanup-source-tree.sh --check`.
4. Compilați pe mașina offline unde `vendor/` corespunde exact `go.mod`: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
5. Actualizați binarul indicat de `systemctl cat vm-doc-server` la `ExecStart`, apoi porniți serviciul. `web/static` este inclus prin `go:embed`.
6. În browser verificați `app.js?v=0.21.85` și `app.css?v=0.21.85` (Ctrl+F5 la nevoie).
7. Verificați `Modificări → De documentat`: filtrele, paginarea, exportul XLSX și butonul `Documentat` după revizie.
8. Verificați `VM → Modificări → Timeline / Modificări / De documentat / Ghid`, inclusiv fără scrollbar global.
9. Verificați clopoțelul cu peste 5 obligații distincte: afișează 5 resurse, iar `Vezi toate obligațiile (N)` indică totalul.

**Nu există migrare SQL.** Rollback prin reinstalarea binarului 0.21.84; DB rămâne compatibilă. Nicio schimbare la agentul 1.7.18.

**Limită:** nu am executat `go test ./internal/server` sau `make build` cu vendor complet în acest mediu, nici exportul XLSX cu MariaDB reală. Validarea integrată în staging rămâne obligatorie.
