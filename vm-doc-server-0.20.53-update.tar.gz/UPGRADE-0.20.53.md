# Upgrade vm-doc-server 0.20.52 → 0.20.53

## Ce se schimbă

Versiunea 0.20.53 repară `504 Gateway Timeout` la **Documente → Publică în Outline → Servicii → Verifică serviciile**. Verificarea rulează acum asincron, iar browserul urmărește progresul prin endpoint-ul existent de joburi.

Nu există migrare DB și nu este necesar update de agent.

## Upgrade

```bash
cp -a /usr/local/src/vm-doc-server-0.20.52 /usr/local/src/vm-doc-server-0.20.53
tar -xzf vm-doc-server-0.20.53-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.53
cd /usr/local/src/vm-doc-server-0.20.53

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește serviciul `vm-doc-server`, apoi fă `Ctrl+F5` în browser.

## Verificare

1. Deschide **Documente → Publică în Outline**.
2. Apasă **Verifică serviciile**.
3. Request-ul inițial trebuie să se închidă imediat, fără 504.
4. În UI trebuie să vezi progresul `servicii X/Y`.
5. La final apare sumarul și butonul de publicare pentru serviciile eligibile.
