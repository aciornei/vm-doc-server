package server

import (
	"strings"
	"testing"
)

func TestSoftwareComponentBeneficiaryRow(t *testing.T) {
	input := beneficiaryResourceRow{ResourceType: "database", ResourceID: 42, Name: "app_production", BeneficiaryType: "department", BeneficiaryID: 17, BeneficiaryName: "Financiar", Source: "ad", Direct: true, AssignmentID: 80, VMID: 9}
	got, ok := softwareComponentBeneficiaryRow(input, beneficiaryDatabaseEngine{VMID: 9, Engine: "mysql", Product: "MariaDB", Version: "10.11.14-MariaDB-0ubuntu0.24.04.1"})
	if !ok {
		t.Fatal("MariaDB motor not identified")
	}
	if got.ResourceType != "software_component" || got.Name != "MariaDB 10.11.14" || got.ComponentKey != "mariadb" || got.ComponentVersion != "10.11.14" {
		t.Fatalf("incorrect component mapping: %+v", got)
	}
	if got.Direct || got.AssignmentID != 0 || got.ViaType != "database" || got.ViaID != 42 || got.ViaName != "app_production" {
		t.Fatalf("provenance lost: %+v", got)
	}
	if got.VMID != 9 || got.ResourceID != 9 || got.BeneficiaryID != 17 {
		t.Fatalf("VM/beneficiary mismatch: %+v", got)
	}
	if strings.Contains(strings.ToLower(got.Name), "mysql") {
		t.Fatalf("MariaDB mislabeled as MySQL: %q", got.Name)
	}
}
func TestSoftwareComponentBeneficiaryUnrelatedEngine(t *testing.T) {
	_, ok := softwareComponentBeneficiaryRow(beneficiaryResourceRow{ResourceID: 1}, beneficiaryDatabaseEngine{VMID: 3, Engine: "unrecognized-db", Product: "Unknown"})
	if ok {
		t.Fatal("unrecognized engine should not create component")
	}
}
func TestSoftwareComponentDistinctVersions(t *testing.T) {
	input := beneficiaryResourceRow{ResourceType: "database", ResourceID: 12, BeneficiaryID: 7}
	a, _ := softwareComponentBeneficiaryRow(input, beneficiaryDatabaseEngine{VMID: 55, Engine: "mariadb", Version: "10.6.20"})
	b, _ := softwareComponentBeneficiaryRow(input, beneficiaryDatabaseEngine{VMID: 55, Engine: "mariadb", Version: "10.11.14"})
	c, _ := softwareComponentBeneficiaryRow(input, beneficiaryDatabaseEngine{VMID: 55, Engine: "mariadb", Version: "10.6.20"})
	if beneficiaryResourceIdentity(a) == beneficiaryResourceIdentity(b) {
		t.Fatal("distinct MariaDB versions counted as one")
	}
	if beneficiaryResourceIdentity(a) != beneficiaryResourceIdentity(c) {
		t.Fatal("same component+VM+version counted twice")
	}
}
