# Upgrade VM-DOC Server 0.20.77 → 0.20.78

0.20.78 adaugă o diagramă de rețea SVG interactivă, tip Visio, în harta de rețea per VM și per serviciu. Diagrama folosește endpoint-urile și datele deja existente din 0.20.77; nu există migrare DB și nu este necesar un nou Sync FortiGate.

Agentul rămâne 1.7.12.

```bash
systemctl stop vm-doc-server
cp -a /usr/local/src/vm-doc-server-0.20.77 /usr/local/src/vm-doc-server-0.20.78
tar -xzf vm-doc-server-0.20.78-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.78
cd /usr/local/src/vm-doc-server-0.20.78
# build/deploy folosind procedura curentă din mediul vostru
systemctl start vm-doc-server
```

După upgrade:
- deschide un VM → Securitate → Hartă rețea;
- verifică nodul VM și fluxurile FortiGate inbound/outbound;
- deschide un serviciu → Rețea pentru schema agregată;
- butonul Export SVG descarcă schema vizibilă.
