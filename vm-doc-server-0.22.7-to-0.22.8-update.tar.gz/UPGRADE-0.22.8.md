# Upgrade VM-DOC 0.22.7 → 0.22.8

1. Salvați configurația, baza de date și binarul curent. Copiați sursa 0.22.7 în `/usr/local/src/vm-doc-server-0.22.8`; păstrați directorul local `vendor/`.
2. Extrageți arhiva incrementală `vm-doc-server-0.22.7-to-0.22.8-update.tar.gz` în directorul nou.
3. Rulați verificările și compilarea:

```bash
cd /usr/local/src/vm-doc-server-0.22.8
node --check web/static/js/app.js
GOPROXY=off GOSUMDB=off go test -mod=vendor ./...
CGO_ENABLED=0 GOPROXY=off GOSUMDB=off go build -mod=vendor -trimpath \
  -ldflags "-X vm-doc-server/internal/buildinfo.Version=0.22.8" \
  -o bin/vm-doc-server ./cmd/vm-doc-server
```

4. Confirmați calea executabilului cu `systemctl cat vm-doc-server`. Opriți serviciul, copiați binarul vechi în backup și instalați binarul nou în **calea reală** a serviciului. Porniți doar `vm-doc-server` și verificați `systemctl status vm-doc-server` și `journalctl -u vm-doc-server -n 50 --no-pager`.
5. Deschideți `Ajutor`, fișa unei VM retrase și cele două istorice, inclusiv în dark mode. Folosiți `Ctrl+F5` dacă browserul afișează resurse vechi.

Nu există migrare SQL și nu se actualizează `vm-doc-collector` ori agenții.

**Rollback:** restaurați binarul 0.22.7 și reporniți `vm-doc-server`. Nu sunt schimbări de schemă de inversat.
