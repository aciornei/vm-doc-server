# VM-DOC Server 0.22.8 — Etichetă Retrasă, istoric dark mode și Ajutor

Bază: sursa completă **0.22.7**. Actualizare exclusiv de UI și documentație.

## Modificări

- **Fișă VM retrasă:** etichetă `RETRASĂ` cu fundal roșu, lângă numele VM-ului, în toate taburile; în registrul de arhivă și în istoricul de VM-uri, starea Retrasă este de asemenea evidentă. Acest marcaj nu reprezintă o nouă stare în baza de date.
- **Istoric VM-uri asociate** și **Istoric servicii asociate:** fundaluri adaptate temei deschise/întunecate, antet clar, contor, detalii extensibile, rânduri consistente, padding și contrast corect. Datele și orele din aceste două panouri apar pe **același rând**, fără să modifice formatterul global.
- **Ajutor** în meniul lateral: ghid compact, în aplicație, despre Activă, Retrasă, Arhivată, locurile unde se regăsesc VM-urile/documentele și regulile de publicare/mutare Outline. Conține linkuri către Arhivă VM & servicii, Servicii, Configurare Outline și Publicare / export. Nu inventează linkuri Outline reale și nu afișează secrete.

## Compatibilitate și verificare

- Nu există migrare MariaDB, endpoint/API nou, schimbare de agent ori de collector. Un rebuild al **vm-doc-server** este suficient pentru resursele statice încorporate (`go:embed`).
- Testele JavaScript/OpenAPI și pachetele Go fără dependențe externe pot fi rulate offline; `go test -mod=vendor ./...` și build integral se execută pe serverul cu `vendor/`.
- Verificați în staging fișa unei VM retrase, cele două panouri cu date reale, tema light/dark și paginile de Ajutor/Arhivă.
