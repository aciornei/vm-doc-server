// Offline UI regression for Help, retired status and the focused dark-mode CSS.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/static/js/app.js','utf8'),styles=fs.readFileSync('web/static/css/ui-refresh.css','utf8');
const index=fs.readFileSync('web/static/index.html','utf8');
const start=src.indexOf('function helpPage()'),end=src.indexOf('async function route(){',start);
assert(start>0&&end>start,'Help page function missing');
const mock={content:{innerHTML:''},pageMeta:(title,subtitle)=>{mock.pageTitle=title;mock.subtitle=subtitle}};
vm.createContext(mock);vm.runInContext(src.slice(start,end),mock);mock.helpPage();
assert.strictEqual(mock.pageTitle,'Ajutor');
for(const t of ['Retragere și arhivare','Activă','Retrasă','Arhivată','Istoric VM-uri asociate','Istoric servicii asociate','Retenția','#archive','#services','#documents/outline-config','#documents/export']){
  assert(mock.content.innerHTML.toLowerCase().includes(t.toLowerCase()),'missing in help: '+t);
}
for(const t of ['data-page="help"','#help','vm-retired-ribbon']) assert((src+'\n'+index).includes(t),'missing '+t);
for(const t of ['var(--panel)','var(--panel2)','.retirement-history-table','.retirement-history-panel .ui-datetime','flex-direction:row!important','.vm-retired-ribbon','html[data-theme']){
  assert((styles+'\n'+fs.readFileSync('web/static/css/app.css','utf8')).includes(t),'missing CSS '+t);
}
assert(!styles.includes('var(--surface, #fff)'),'bad hardcoded white history background');
console.log('PASS: Help links/text, retired VM label, dark-theme tokens and history inline datetime');
