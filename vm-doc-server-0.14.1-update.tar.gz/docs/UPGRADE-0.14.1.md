# Upgrade vm-doc-server 0.14.0 → 0.14.1

0.14.1 repară cazul în care snapshot-ul JSON conține secțiunea `docker`, dar tabul Docker este gol deoarece collectorul a fost raportat `partial`.

## Pași

1. Faceți backup aplicației și bazei de date.
2. Aplicați `vm-doc-server-0.14.1-update.tar.gz` peste sursa 0.14.0 sau patch-ul 0.14.0 → 0.14.1.
3. Compilați: `go build -o vm-doc-server ./cmd/vm-doc-server`.
4. Înlocuiți binarul folosit de systemd și reporniți `vm-doc-server`.
5. Deschideți din nou tabul Docker al VM-ului. Serverul încearcă automat backfill din snapshot-ul curent; nu este obligatorie o colectare nouă.

Nu există migrare DB nouă. `vm-doc-agent 1.4.0` și `1.4.1` sunt compatibile.
