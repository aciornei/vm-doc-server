ALTER TABLE docker_container_service_assignments
  ADD COLUMN environment_id BIGINT UNSIGNED NULL AFTER internal_service_id,
  ADD COLUMN operational_status_id BIGINT UNSIGNED NULL AFTER environment_id,
  ADD KEY idx_docker_service_assignment_environment (environment_id),
  ADD KEY idx_docker_service_assignment_status (operational_status_id),
  ADD CONSTRAINT fk_docker_service_assignment_environment FOREIGN KEY (environment_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL,
  ADD CONSTRAINT fk_docker_service_assignment_status FOREIGN KEY (operational_status_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL;

ALTER TABLE database_instance_service_assignments
  ADD COLUMN environment_id BIGINT UNSIGNED NULL AFTER internal_service_id,
  ADD COLUMN operational_status_id BIGINT UNSIGNED NULL AFTER environment_id,
  ADD KEY idx_database_instance_service_environment (environment_id),
  ADD KEY idx_database_instance_service_status (operational_status_id),
  ADD CONSTRAINT fk_database_instance_service_environment FOREIGN KEY (environment_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL,
  ADD CONSTRAINT fk_database_instance_service_status FOREIGN KEY (operational_status_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL;

ALTER TABLE database_catalog_service_assignments
  ADD COLUMN environment_id BIGINT UNSIGNED NULL AFTER internal_service_id,
  ADD COLUMN operational_status_id BIGINT UNSIGNED NULL AFTER environment_id,
  ADD KEY idx_database_catalog_service_environment (environment_id),
  ADD KEY idx_database_catalog_service_status (operational_status_id),
  ADD CONSTRAINT fk_database_catalog_service_environment FOREIGN KEY (environment_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL,
  ADD CONSTRAINT fk_database_catalog_service_status FOREIGN KEY (operational_status_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL;

ALTER TABLE web_site_service_assignments
  ADD COLUMN environment_id BIGINT UNSIGNED NULL AFTER internal_service_id,
  ADD COLUMN operational_status_id BIGINT UNSIGNED NULL AFTER environment_id,
  ADD KEY idx_web_site_service_environment (environment_id),
  ADD KEY idx_web_site_service_status (operational_status_id),
  ADD CONSTRAINT fk_web_site_service_environment FOREIGN KEY (environment_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL,
  ADD CONSTRAINT fk_web_site_service_status FOREIGN KEY (operational_status_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL;
