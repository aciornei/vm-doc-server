# Implementation status 0.13.4

## Implementat

- retenție automată `inventory_snapshots` cu protecția snapshot-urilor curente/documentate;
- Audit paginat și filtrabil, cu detalii before/after pentru operațiile instrumentate;
- model complet Rețea externă → Sistem extern → Conexiune externă;
- culoare/risc/trust/CIDR pentru rețele externe și integrare în UI, rapoarte și DOCX;

- fișă VM compactă pe subsecțiuni navigabile, cu tab-uri sticky și păstrarea secțiunii în URL;
- scor de completare VM bazat pe 11 criterii esențiale, afișat în listă și export;
- paginare configurabilă și memorată per nomenclator;
- pagina Agenți separată în listare și release-uri, cu căutare fără pierderea focusului;
- schemă logică automată a Serviciilor interne, cu VM-uri unice și asocieri multiple în același nod;
- pictograme configurabile pentru nomenclatoare prin `icon_key`;

- surse vCenter cu secrete criptate, sincronizare asincronă și programare zilnică;
- upsert VM și marcaj `missing` când o mașină nu mai este văzută în vCenter;
- corelare automată sau manuală cu agentul;
- listă VM, fișă tehnică structurată, căutare, paginare și export Excel;
- date operaționale independente de inventarul automat;
- catalog de servicii interne independent de încadrarea arhitecturală;
- domeniu și categorie de serviciu salvate pe fiecare asociere VM–serviciu;
- agregarea automată a domeniilor și categoriilor în pagina serviciului;
- roluri tehnice legate global de unul sau mai multe layer-e;
- selecție `domeniu–categorie–serviciu–layer–rol–tip soluție` pe fișa VM;
- asocieri multiple, cu tip de utilizare, prioritate și observații;
- validare server-side a relației categorie–domeniu și layer–rol;
- nomenclatoare grupate în submeniuri;
- registru de persoane și responsabilități multiple pe VM;
- structură separată de backup, pregătită pentru Veeam API;
- inventar agent structurat și restrâns implicit, istoric și audit paginate;
- generare DOCX pe bază de șabloane, previzualizare și istoric pentru VM și Serviciu intern;
- editor rich-text pentru Scop și domeniu / Obiective, cu bullets, numerotare, indentare și stiluri reproduse în DOCX;
- evidențiere PROD / TEST-UAT / DEV în pagina și documentația Serviciului intern;
- legături către fișele VM și pachete ZIP de documentație cu anexe VM versionate;
- modul Rapoarte cu indicatori, donut/pie charts, bar charts, timeline și liste de completitudine;
- pagină Agenți cu căutare, filtrare și paginare;
- listă Servicii cu descriere scurtată și filtre operaționale;
- servicii comune / globale pentru AD, DNS, LDAP, NTP, PKI și alte infrastructuri partajate;
- relații Serviciu → Serviciu comun și excepții VM → Serviciu comun, cu analiză de impact;
- dependențe comune afișate în UI, schema logică și fișele DOCX VM/Serviciu;
- servicii software principale selectabile din inventarul agentului, cu versiuni și propagare în fișele VM/Serviciu;
- etichete contextuale în inventarul agentului pentru stocare, porturi, conturi, cron și servicii, plus uptime umanizat;
- șabloane separate pe tip de obiect (`vm` / `service`) și documente de serviciu numerotate `FSI-*`;
- agregarea automată a tipurilor de soluție în pagina Serviciului intern;
- inventar agent compact în DOCX, cu tabele specializate și randare stabilă Word/LibreOffice;
- migrații, audit, RBAC și OpenAPI actualizate.

## Hotfix 0.13.3

- clientul HTTP către agenți este inițializat atât în `vm-doc-server`, cât și în `vm-doc-collector`;
- refresh-ul statusului auto-update pornit de heartbeat nu mai poate declanșa `nil pointer dereference`;
- `agentclient` tratează defensiv cazul unui client nil și întoarce eroare explicită.


## Schimbări de model în 0.4.0

- serviciul intern nu mai are domeniu sau categorie de serviciu configurate manual;
- `vm_internal_service_assignments` păstrează domeniul și categoria alese pe VM;
- pagina serviciului agregă automat toate încadrările observate;
- același serviciu poate fi reutilizat în mai multe domenii și categorii;
- datele existente sunt migrate din vechea categorie a serviciului.

## Validare necesară în mediul offline final

Arhiva standard nu include `vendor/`. În sursa offline care păstrează dependențele executați:

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

## Limitări

- datele efective din Veeam API nu sunt încă sincronizate;
- serviciile nu au încă responsabilități proprii distincte de responsabilitățile VM-urilor;
- conversia PDF și semnarea digitală nu sunt încă implementate;
- custom attributes generale din vCenter nu sunt încă extrase;
- nu există încă worker automat pentru retenția inventarelor și auditului.

## 0.11.1

- publicare agent/updater prin multipart upload din UI;
- promovare testing → stable și ștergere release;
- SHA-256 și manifest atomic păstrate în backend;
- integrare cu vm-doc-agent 1.3.2 pentru versiuni de servicii.

## 0.11.0

- UI contextual pentru servicii, routes și firewall în pagina VM;
- Rapoarte pe subcategorii;
- Auto-update agent 1.3.0+ prin repository central stable/testing.


## Agent update status 0.13.2

- force update din UI prin `POST /api/v1/agents/{id}/update`;
- canal stable/testing cache-uit central;
- refresh la Test/Colect/Update și heartbeat;
- filtrare și export după canal.


## Hotfix 0.13.4

- statusul `installing` este reconciliat la primul register/heartbeat al binarului nou;
- lista Agenți urmărește pentru scurt timp finalizarea update-ului forțat;
- nu există migrare SQL nouă.
## Docker inventory · 0.14.0

- vm-doc-agent 1.4.0 colectează Docker Engine, containere, Compose projects, images, networks și volumes fără valori de environment/secrete/loguri;
- serverul normalizează inventarul în tabele dedicate;
- container → serviciu este many-to-many și independent de VM → serviciu, pentru hosturi Docker partajate;
- asocierile manuale supraviețuiesc redeploy-urilor atunci când identitatea logică a containerului rămâne stabilă;
- labels `vm-doc.service`, `vm-doc.services`, `vm-doc.component`, `vm-doc.role` pot crea asocieri automate;
- pagina VM are tab Docker; pagina serviciului agregă containerele asociate de pe orice VM gazdă;
- DOCX VM și DOCX serviciu includ datele Docker.


## Docker inventory hotfix · 0.14.1

- acceptă payload Docker atât pentru collector `success`, cât și `partial`;
- statusurile `disabled`, `error` și `timeout` păstrează ultimul inventar bun;
- tabul Docker poate reconstrui automat datele structurate din snapshot-ul curent deja salvat în istoric;
- fără migrare SQL nouă.

## Database inventory · 0.15.0

- vm-doc-agent 1.5.0 detectează engine-uri și instanțe PostgreSQL, MySQL, MariaDB, MongoDB, Oracle, SQL Server, Db2, Redis, Firebird și CockroachDB;
- bazele logice sunt enumerate best-effort pentru PostgreSQL, MySQL/MariaDB și MongoDB numai când accesul local existent permite interogarea fără parole configurate de vm-doc;
- serverul normalizează engine-uri, instanțe și baze logice în tabele dedicate;
- instanță → serviciu și bază logică → serviciu sunt many-to-many, independente de VM → serviciu;
- pagina VM, pagina serviciului și documentele DOCX expun inventarul DB;
- nu sunt colectate parole, connection strings, query-uri sau date din baze.


## Web inventory și documente dinamice · 0.16.0

- vm-doc-agent 1.6.0 detectează Nginx, Apache HTTP Server și HAProxy și colectează metadate secret-safe pentru site-uri, virtual hosts și frontends;
- serverul normalizează serverele și site-urile Web în tabele dedicate și păstrează asocierea site → serviciu independentă de VM → serviciu;
- pagina VM are tab Web, iar pagina serviciului agregă site-urile asociate;
- controalele de asociere Docker/DB/Web au layout responsive cu butoane explicite;
- fișa VM afișează Docker, Baze de date și Web numai dacă există date și folosește numerotare dinamică pentru Inventar agent și subsecțiunile sale;
- fișa serviciului tratează la fel capitolele DB/Docker/Web opționale;
- migrare `031_web_inventory.up.sql`.


## VM inventory / documentation UX hotfix · 0.16.1

- carduri compacte și contrast dark-mode pentru Docker/DB/Web;
- listarea VM agregă serviciile directe și serviciile asociate resurselor Docker/DB/Web și le poate filtra;
- procent de completare dinamic: resursele Docker/DB/Web sunt criterii doar când există;
- Power ON/OFF, OS compact și versiune agent în tabel.

## UI & document rendering refinements · 0.16.2

- VM list keeps agent version beside Online/Offline, aggregates services and keeps dynamic documentation completion;
- all single-value selects use a searchable combobox wrapper while preserving native select values/events;
- vCenter synchronization history is server-side paginated, default 10/page;
- Docker/DB/Web tabs have spacing after the VM navigation; external connection blocks and VM document preview received dedicated layout/padding;
- VM DOCX port inventory now reads nested `processes[]` to show process/PID/executable;
- firewall document rendering is backend-agnostic (nftables, iptables/ip6tables, firewalld, UFW, SuSEfirewall2) with legacy UFW fallback;
- local account rendering honors `system_account` and includes UID 1000 when it is a normal user;
- no SQL migration and no agent bump required; vm-doc-agent 1.6.1 remains compatible.

## UI / DOCX hotfix · 0.16.3

- dropdown-urile searchable folosesc un portal deasupra panourilor/tabelelor, cu repoziționare la scroll/resize, evitând clipping-ul de `overflow`/z-index;
- detaliile Docker au padding suplimentar;
- subsecțiunile Inventar agent sunt numerotate continuu și nu mai includ secțiunea tehnică goală `Schema inventar`;
- Heading2 are indent explicit în DOCX, astfel încât subsecțiunile precum 5.1 sunt vizual sub capitolul părinte;
- Porturi ascultate este deduplicat la un rând per port/protocol, păstrând cele mai complete date despre proces/executabil;
- fără migrare SQL; agentul 1.6.1 este suficient.

## UI hotfix · 0.16.4

- poziționare stabilă pentru toate listbox-urile searchable, inclusiv după filtrarea rezultatelor;
- elimină dublul open/reposition generat de succesiunea focus + click;
- padding pentru starea Docker „nu este instalat”.


## Inventory change tracking · 0.17.0

- diferențe semantice între snapshot-uri succesive, cu filtrare a câmpurilor volatile;
- evenimente globale și per VM pentru conturi, DB, Docker, Web, servicii, porturi, firewall, rețea, stocare, identitate și integrări;
- clasificare documentație implicit `unset`, cu triere manuală și stare de revizuire;
- backfill pentru ultimele două snapshot-uri după upgrade;
- migrare `032_inventory_changes.up.sql`; fără modificare de agent.


## Hotfix migrare 032 · 0.17.1

- `inventory_changes.vm_id`, `agent_id`, `previous_inventory_id`, `inventory_id` și `reviewed_by` folosesc `BIGINT UNSIGNED`, identic cu PK-urile referențiate;
- 0.17.0 putea eșua la pornire cu MariaDB/MySQL Error 1005 / foreign key incorrectly formed;
- migrarea 032 nereușită nu este înregistrată în `schema_migrations`, deci după instalarea 0.17.1 este reluată automat.


## Baseline modificări · 0.17.2

- migrarea `033_inventory_change_baselines.up.sql` creează baseline-ul per VM și îl inițializează la snapshot-ul curent la upgrade;
- modificările cu `inventory_id` anterior sau egal baseline-ului rămân în DB, dar sunt excluse din lista Modificări și din criteriul de completare a documentației;
- baseline-ul poate fi mutat la snapshot-ul curent global sau per VM;
- pentru VM-uri noi, primul snapshot disponibil devine automat baseline la prima comparație;
- nu se șterge istoric și nu se modifică automat clasificările existente.


## Veeam Backup & Replication · 0.18.0

- integrare directă, read-only, prin VBR REST API;
- surse multiple cu URL, utilizator, parolă criptată, `x-api-version`, verificare TLS și interval de sincronizare;
- Test conexiune verifică autentificarea, `serverInfo` și accesul la `backupObjects`;
- sincronizarea citește `backupObjects`, `backups`, `jobs/states` și cel mai recent restore point al fiecărui obiect corelat;
- corelare exactă după numele VM-ului; duplicatele/nepotrivirile nu sunt asociate automat și sunt contabilizate în rulare;
- `vm_backup_summary` este populat cu protecție, job, repository, rezultat, ultim backup, next run și restore points;
- meniu global Backup cu sumar, surse și istoric paginat;
- scheduler implicit la 6 ore per sursă;
- agentul nu participă la integrarea Veeam.


## Veeam · 0.18.1

- compatibilitate Test cu Backup Viewer și VBR 12.1;
- corelare normalizată backup → job și fallback pe numele jobului;
- filtre Backup după protecție, power state și rezultat, card total/procente;
- filă Backup dedicată pe VM cu detalii din `raw_json`;
- backupurile VM-urilor sunt incluse în fișa serviciului;
- implicit 1440 minute pentru surse Veeam noi.

## Backup/Veeam și timezone · 0.18.2

- definiții job Veeam + repository inventory citite read-only, best-effort;
- retenție standard și GFS Weekly / Monthly / Yearly în sumarul VM;
- storage primar și storage secundar / backup copy;
- programarea jobului și next run în tabul Backup și documente;
- backup cron/script local documentabil per VM, fără execuție din vm-doc;
- cardurile Backup sunt recalculate cu aceleași filtre ca lista;
- filtre Backup compacte, inclusiv power state;
- sesiunea MariaDB este forțată în UTC; UI folosește `app.timezone` (implicit `Europe/Bucharest`).


## Apartenență job Veeam · 0.18.3

- `virtualMachines.includes` este citit din definițiile joburilor și corelat exact după numele VM-ului;
- `veeam_in_job` și `veeam_job_enabled` sunt persistate separat de `protected`;
- stări distincte: protejată, așteaptă primul backup, job dezactivat, backup existent în afara jobului, neprotejată, neverificată;
- job/repository/schedule/retention/GFS/next run pot fi afișate și înainte de primul restore point;
- pagina Backup expune filtre și indicatori pentru noile stări;
- migrare `037_veeam_job_membership.up.sql`; agent 1.6.2 neschimbat.

## Monitoring foundation · 0.19.0

- surse multiple Prometheus de tip `metrics` și `blackbox`, cu autentificare none/basic/bearer, TLS, Test, Sync și scheduler;
- targeturile active sunt sincronizate din API-ul Prometheus și păstrate ca inventar/stare, fără copierea seriilor de metrici;
- Node Exporter este citit din inventarul agentului 1.6.2 (instalare, service activ, versiune, endpoint);
- corelare target → VM: label explicit configurabil → FQDN → hostname → IP → alias manual;
- suport pentru targeturi adresate prin IP sau nume rezolvate de Prometheus din DNS/`/etc/hosts`;
- sursele Blackbox îmbogățesc targeturile cu probe HTTP/HTTPS: success, status code, duration și expirare TLS;
- meniu global Monitorizare cu carduri dependente de filtre, VM-uri, targeturi, surse și istoric;
- filă Monitorizare pe VM cu Node Exporter, Prometheus metrics, Blackbox și administrarea aliasurilor;
- RBAC: `monitoring.read` și `monitoring.manage`;
- migrare `038_prometheus_monitoring_foundation.up.sql`; agentul rămâne 1.6.2;
- Grafana/dashboardurile/alertele nu sunt încă sincronizate în 0.19.0.


## Monitoring bugfix · 0.19.1
- sursele `metrics` și `blackbox` pot folosi același Prometheus fără dublarea targeturilor;
- Blackbox este detectat din metadatele targetului (`__metrics_path__=/probe`, `__param_target`, `scrapeUrl=/probe`), nu din numele jobului;
- Test și Sync folosesc aceeași filtrare pe tip de sursă;
- clientul Prometheus ocolește proxy-ul de mediu pentru conexiunile interne;
- nu există migrare DB nouă; un Sync pe fiecare sursă curăță logic targeturile vechi prin `present=0`.

## Monitoring hosts correlation · 0.19.2

- sursele Prometheus pot fi asociate explicit cu un agent vm-doc;
- agentul asociat este selectat manual în UI, fără ghicire automată;
- inventarul agentului 1.6.3 furnizează `/etc/hosts` parsat;
- targeturile necunoscute ca FQDN/hostname/IP pot fi rezolvate prin hosts-ul exact al serverului Prometheus;
- ordinea de corelare: label explicit → FQDN → hostname → IP → Prometheus hosts → alias manual;
- metoda `prometheus_hosts` păstrează și traseul `alias -> IP` pentru depanare;
- lipsa agentului/hosts-ului nu blochează Sync Prometheus; doar dezactivează acest fallback.


## vCenter multi-IP + Monitoring UI · 0.19.3

- vCenter citește toate IPv4-urile guest din `/guest/networking/interfaces`;
- IP-urile sunt persistate în `vcenter_vm_ips` și intră în matching-ul Prometheus;
- VM-urile fără agent pot fi corelate printr-un IP secundar raportat de vCenter;
- setul anterior de IP-uri este păstrat dacă endpointul guest networking eșuează temporar;
- Monitorizare este împărțită în `Stare monitorizare` și `Surse & sincronizări`;
- formularul Prometheus, filtrele și fila VM Monitorizare au layout/padding mărite;
- migrare `040_vcenter_vm_guest_ips.up.sql`; agent 1.6.3 neschimbat.

## UI VM · 0.19.5

- pagina VM-uri are submeniuri `Inventar VM` și `Surse & sincronizări`;
- filtre VM reorganizate și aerisite, cu rezumatul filtrelor active;
- fișa VM are navigare pe zone funcționale și subtabs numai unde sunt necesare;
- listbox-urile searchable folosesc portal cu direcție blocată pe durata deschiderii;
- săgeată CSS unică pentru listbox-uri și selecturi native, cu padding rezervat;
- padding/layout mărit în fișa VM și în `VM → Monitorizare`;
- fără migrare DB; agentul rămâne 1.6.3.

## Curățare definitivă VM vCenter · 0.19.4

- filtru prezente/lipsă din vCenter;
- afișare `missing_since`;
- delete definitiv individual și bulk;
- impact preview și protecție pentru VM-urile încă prezente;
- audit complet;
- fără mecanism nou de arhivare și fără migrare DB.


## Database visibility + component context · 0.19.15

- bazele de sistem rămân în inventarul brut/normalizat, dar sunt excluse din UI, fișele VM și fișele serviciilor;
- Rezumatul VM semnalează engine/instanță DB detectată atunci când catalog discovery nu este complet și afișează motivul structurat;
- asocierile DB, Docker și Web cu un serviciu pot păstra separat mediul și statusul operațional din nomenclatoare;
- UI cere Mediu + Status pentru asocierile manuale noi, iar asocierile vechi rămân valide;
- migrare `045_component_assignment_context.up.sql`; vm-doc-agent recomandat 1.6.11.
