# Upgrade vm-doc-server 0.19.14 → 0.19.15

0.19.15 reduce zgomotul bazelor de date de sistem, semnalează discovery DB incomplet în Rezumat și adaugă context operațional per asociere DB/Docker/Web.

## Noutăți

- bazele de sistem sunt păstrate intern, dar nu mai apar în VM → Baze de date, fișa VM sau fișa serviciului;
- `Baze aplicație` numără numai cataloagele non-system;
- Rezumatul VM afișează avertisment dacă există engine/instanță DB dar bazele nu au putut fi enumerate, inclusiv motivul raportat de agent;
- la asocierea manuală a unei baze/instanțe DB, a unui container/proiect Docker sau a unui site Web se aleg `Serviciu`, `Mediu` și `Status operațional`;
- documentația include mediul/statusul asocierii;
- PostgreSQL 8/9 multi-instance este recomandat cu vm-doc-agent 1.6.11.

## Migrare DB

La pornire se aplică automat:

```text
045_component_assignment_context.up.sql
```

Migrarea adaugă coloane nullable `environment_id` și `operational_status_id` pe asocierile DB/Docker/Web; asocierile existente rămân valide.

## Upgrade

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.14 vm-doc-server-0.19.15
tar -xzf /cale/vm-doc-server-0.19.15-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.15
cd /usr/local/src/vm-doc-server-0.19.15
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

După upgrade folosiți `Ctrl+F5`.

## Verificări

1. `/version` trebuie să raporteze `0.19.15`.
2. În VM → Baze de date nu trebuie să apară bazele tehnice/system.
3. Pe o VM unde engine-ul este detectat dar catalog discovery eșuează, Rezumatul trebuie să afișeze avertismentul și motivul.
4. La asociere DB/Docker/Web trebuie să existe selectoarele Mediu și Status operațional.
5. Fișa VM și fișa serviciului trebuie să includă contextul mediului/statusului pentru asocierile respective.
6. Pe hostul PostgreSQL 8 de pe port 5434, după agent 1.6.11 și colectare nouă, bazele aplicației trebuie să apară.
