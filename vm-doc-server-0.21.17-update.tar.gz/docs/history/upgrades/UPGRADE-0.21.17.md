# Upgrade VM-DOC Server 0.21.16 → 0.21.17

Release UI-only. **Nu există migrare SQL nouă; agentul rămâne 1.7.18.**

1. Păstrează backup-ul surselor și binarului 0.21.16.
2. Copiază sursele 0.21.16 într-un director nou `vm-doc-server-0.21.17`, păstrând `vendor/`.
3. Extrage `vm-doc-server-0.21.17-update.tar.gz` în directorul nou; nu extrage arhive de release întregi în proiect.
4. Rulează `bash scripts/cleanup-source-tree.sh --check`, `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și `GOPROXY=off GOFLAGS=-mod=vendor make build`.
5. După succes, instalează binarul conform procedurii existente; reîncarcă browserul cu `Ctrl+F5` (`?v=0.21.17`).
6. Verifică la VM-uri Căutare/Power, filtrele expandate 4x2, selecția Power, cardurile, antetele Publicare/Outline și scroll-ul sticky. Verifică afișarea dată/oră și în alte module.

Nu modifica `vendor/`, configurațiile sau DB. Rollback: sursele/binarul 0.21.16, fără rollback DB.

**Testare locală:** Chromium cu date simulate (1440/1024/390), `node --check`, Go `./web ./internal/buildinfo`, comparare patch/update/surse; nu s-a rulat build-ul complet cu vendor/ și nici backend MariaDB real.
