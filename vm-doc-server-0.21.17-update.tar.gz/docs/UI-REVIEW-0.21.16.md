# VM-DOC 0.21.16 — Revizie UI transversală

**Scop:** uniformizare vizuală, fără schimbări de business logic. Evaluarea este asupra surselor front-end și a componentelor comune; nu este o validare funcțională cap-coadă cu date reale din producție.

## Pagini / zone acoperite de stilul comun

| Pagină principală | Revizie transversală | Zonă pentru validare cu date reale |
|---|---|---|
| Dashboard | carduri, header, paneluri, tabele | carduri agregate și căutare |
| VM-uri | filtre, tabele, fișă, taburi | inventare late, Forti, diagramă, subtaburi |
| Echipamente | formulare, paneluri, tabele | asocieri multiple |
| Modificări | filtre, sumar, istoric | paginare mare |
| Backup | filtre, navigare, carduri | jobs/repositories late |
| Monitorizare | navigare, filtre, panouri | Prometheus și Blackbox pe pagini mari |
| Servicii | filtre, taburi, formulare | editare inline și dependențe |
| Conectivitate externă | filtre, paneluri, dialoguri | tabele și conexiuni |
| Rapoarte | carduri și tabele | grafice și exporturi |
| Securitate | filtre, taburi, tabele | FortiGate foarte lat și Hardening |
| Agenți | navigare și filtre | listare/paginare și release-uri |
| Nomenclatoare | formulare, paneluri, submeniu | liste foarte lungi, Hardening |
| Documente | dialoguri, taburi, butoane | publicare Outline și istoric |
| Releasuri | navigare, tipografie | release-uri extinse |
| Audit | tabele, filtrare, dialoguri | volum mare de acțiuni |
| Acces | formulare și tabele | roluri și permisiuni |
| Autentificare | formular și contrast | LDAP/OIDC real |

## Decizii de UI

- Menținere structură navigare/rute și RBAC; meniu lateral grupat în patru categorii, scroll vertical propriu și meniu compact activat pe mobil.
- Toate panourile folosesc un strat separat de stil (`web/static/css/ui-refresh.css`), care poate fi ajustat/retras fără a rescrie `app.css`.
- Spațiere, antete, butoane, dialoguri, indicii focus, forme și tabele armonizate.
- Nu modificăm global gestionarea scrollului orizontal pentru tabelele speciale: regulile specifice FortiGate/VM rămân în vigoare, pentru a evita revenirea la problema „scroll în scroll”.
- Contrastul light/dark păstrează variabilele temei.

## Limite de testare

- Verificat în Chromium folosind date UI **simulate** la 1440, 1024 și 390 px: meniu, toggle mobil, aria-current, lățime fără overflow pe exemplul de listă.
- Nu au fost parcurse efectiv toate fluxurile în aplicația conectată la API/MariaDB. Se recomandă smoke pe ecranele critice cu date reale după instalare.
- Problemele particulare (diagrame, tabele de sute de coloane, formulare foarte lungi) vor fi tratate punctual după această bază comună.

## Follow-up 0.21.17

Corecții punctuale pentru VM-uri: filtre secundare pliate, sumar compact, date și ore separate, antete Outline, sticky meniu sub topbar. Validare vizuală izolată cu date simulate; validarea live pentru fiecare modul rămâne deschisă.
