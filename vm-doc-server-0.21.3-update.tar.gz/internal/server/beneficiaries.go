package server

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/directory"
	"vm-doc-server/internal/xlsx"
)

var beneficiaryResourceTables = map[string]string{
	"vm": "virtual_machines", "docker": "docker_containers", "database": "database_catalogs", "web": "web_sites",
	"service": "internal_services", "support_component": "vm_support_components",
}
var beneficiaryTypes = map[string]bool{"department": true, "person": true}

type beneficiaryInput struct {
	Type         string `json:"type"`
	Name         string `json:"name"`
	Email        string `json:"email"`
	DepartmentID int64  `json:"department_id"`
}
type beneficiaryAssignmentInput struct {
	ResourceType    string `json:"resource_type"`
	ResourceID      int64  `json:"resource_id"`
	BeneficiaryType string `json:"beneficiary_type"`
	BeneficiaryID   int64  `json:"beneficiary_id"`
}

func beneficiaryTable(typ string) string {
	if typ == "person" {
		return "people"
	}
	return "beneficiary_departments"
}
func beneficiaryTypeAndID(r *http.Request) (string, int64, error) {
	typ := r.URL.Query().Get("type")
	id, err := strconv.ParseInt(r.URL.Query().Get("id"), 10, 64)
	if !beneficiaryTypes[typ] || err != nil || id < 0 || (id == 0 && typ != "department") {
		return "", 0, errors.New("type=department|person; id=0 allowed only for all departments")
	}
	return typ, id, nil
}
func (a *App) listBeneficiaries(w http.ResponseWriter, r *http.Request) {
	typ := r.URL.Query().Get("type")
	if !beneficiaryTypes[typ] {
		badRequest(w, errors.New("type must be department or person"))
		return
	}
	query := "SELECT id,name,source,active,COALESCE(ldap_dn,''),COALESCE(parent_id,0),'' FROM beneficiary_departments"
	if typ == "person" {
		query = "SELECT id,display_name,IF(source='ldap','ad',source),active,COALESCE(directory_dn,''),COALESCE(beneficiary_department_id,0),email FROM people"
	}
	if r.URL.Query().Get("include_inactive") != "true" {
		query += " WHERE active=1"
	}
	query += " ORDER BY 2 LIMIT 10000"
	rows, err := a.DB.QueryContext(r.Context(), query)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, parent int64
		var name, source, dn, email string
		var active bool
		if err = rows.Scan(&id, &name, &source, &active, &dn, &parent, &email); err != nil {
			respond(w, nil, err)
			return
		}
		item := map[string]any{"id": id, "name": name, "source": source, "active": active, "dn": dn, "email": email}
		if typ == "department" {
			item["parent_id"] = parent
		} else {
			item["department_id"] = parent
		}
		out = append(out, item)
	}
	respond(w, out, rows.Err())
}
func (a *App) createBeneficiary(w http.ResponseWriter, r *http.Request) {
	var in beneficiaryInput
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 65536)).Decode(&in); err != nil {
		badRequest(w, err)
		return
	}
	in.Name = strings.TrimSpace(in.Name)
	in.Email = strings.TrimSpace(in.Email)
	if !beneficiaryTypes[in.Type] || in.Name == "" || len(in.Name) > 255 || len(in.Email) > 255 {
		badRequest(w, errors.New("invalid beneficiary type/name/email"))
		return
	}
	var result sql.Result
	var err error
	if in.Type == "department" {
		result, err = a.DB.ExecContext(r.Context(), "INSERT INTO beneficiary_departments(name,source) VALUES(?,'manual')", in.Name)
	} else {
		if in.DepartmentID > 0 {
			result, err = a.DB.ExecContext(r.Context(), "INSERT INTO people(display_name,email,source,beneficiary_department_id) VALUES(?,?,'manual',?)", in.Name, in.Email, in.DepartmentID)
		} else {
			result, err = a.DB.ExecContext(r.Context(), "INSERT INTO people(display_name,email,source) VALUES(?,?,'manual')", in.Name, in.Email)
		}
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	id, _ := result.LastInsertId()
	jsonResponse(w, http.StatusCreated, map[string]any{"id": id, "type": in.Type, "source": "manual"})
}
func (a *App) updateBeneficiary(w http.ResponseWriter, r *http.Request) {
	typ := r.URL.Query().Get("type")
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if !beneficiaryTypes[typ] || err != nil || id <= 0 {
		badRequest(w, errors.New("invalid type or id"))
		return
	}
	var in struct {
		Name         string `json:"name"`
		Email        string `json:"email"`
		Active       *bool  `json:"active"`
		DepartmentID *int64 `json:"department_id"`
	}
	if err = decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	var source string
	if err = a.DB.QueryRowContext(r.Context(), "SELECT source FROM "+beneficiaryTable(typ)+" WHERE id=?", id).Scan(&source); err != nil {
		respond(w, nil, err)
		return
	}
	if source != "manual" {
		badRequest(w, errors.New("AD beneficiaries are read-only; synchronize from AD"))
		return
	}
	if strings.TrimSpace(in.Name) == "" || len(in.Name) > 255 || len(in.Email) > 255 {
		badRequest(w, errors.New("name is required, maximum 255 characters"))
		return
	}
	active := true
	if in.Active != nil {
		active = *in.Active
	}
	if typ == "department" {
		_, err = a.DB.ExecContext(r.Context(), "UPDATE beneficiary_departments SET name=?,active=? WHERE id=?", strings.TrimSpace(in.Name), active, id)
	} else {
		var dept any = nil
		if in.DepartmentID != nil && *in.DepartmentID > 0 {
			dept = *in.DepartmentID
		}
		_, err = a.DB.ExecContext(r.Context(), "UPDATE people SET display_name=?,email=?,active=?,beneficiary_department_id=? WHERE id=?", strings.TrimSpace(in.Name), strings.TrimSpace(in.Email), active, dept, id)
	}
	respond(w, map[string]any{"status": "ok"}, err)
}
func (a *App) beneficiaryADOrganizationalUnits(w http.ResponseWriter, r *http.Request) {
	if !a.Directory.Enabled() {
		badRequest(w, errors.New("AD directory is disabled"))
		return
	}
	units, err := a.Directory.OrganizationalUnits()
	if err != nil {
		respond(w, nil, err)
		return
	}
	roots, err := a.DB.QueryContext(r.Context(), "SELECT ldap_dn FROM beneficiary_sync_roots ORDER BY ldap_dn")
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer roots.Close()
	selected := []string{}
	for roots.Next() {
		var dn string
		if err = roots.Scan(&dn); err != nil {
			respond(w, nil, err)
			return
		}
		selected = append(selected, dn)
	}
	if err = roots.Err(); err != nil {
		respond(w, nil, err)
		return
	}
	respond(w, map[string]any{"base_dn": a.Directory.Config.Directory.BaseDN, "ous": units, "selected_dns": selected}, nil)
}

// saveBeneficiaryRoots preserves the explicit OU selection across page reloads.
func saveBeneficiaryRoots(ctx context.Context, tx *sql.Tx, dns []string) error {
	if _, err := tx.ExecContext(ctx, "DELETE FROM beneficiary_sync_roots"); err != nil {
		return err
	}
	for _, dn := range dns {
		if _, err := tx.ExecContext(ctx, "INSERT INTO beneficiary_sync_roots(dn_hash,ldap_dn) VALUES(?,?)", dnHash(dn), dn); err != nil {
			return err
		}
	}
	return nil
}
func (a *App) updateBeneficiaryADRoots(w http.ResponseWriter, r *http.Request) {
	var in struct {
		RootDNs []string `json:"root_dns"`
	}
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if len(in.RootDNs) > 100 {
		badRequest(w, errors.New("at most 100 OU roots"))
		return
	}
	// Validate against the actual directory tree, not merely the Base DN string.
	units, err := a.Directory.OrganizationalUnits()
	if err != nil {
		respond(w, nil, err)
		return
	}
	valid := map[string]string{}
	for _, u := range units {
		valid[strings.ToLower(strings.TrimSpace(u.DN))] = u.DN
	}
	seen := map[string]bool{}
	roots := []string{}
	for _, raw := range in.RootDNs {
		dn, ok := valid[strings.ToLower(strings.TrimSpace(raw))]
		if !ok {
			badRequest(w, errors.New("OU not found under the configured Base DN"))
			return
		}
		if !seen[strings.ToLower(dn)] {
			roots = append(roots, dn)
			seen[strings.ToLower(dn)] = true
		}
	}
	tx, err := a.DB.BeginTx(r.Context(), nil)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer tx.Rollback()
	if err = saveBeneficiaryRoots(r.Context(), tx, roots); err != nil {
		respond(w, nil, err)
		return
	}
	if err = tx.Commit(); err != nil {
		respond(w, nil, err)
		return
	}
	respond(w, map[string]any{"root_dns": roots, "count": len(roots)}, nil)
}
func dnUnder(dn, root string) bool {
	dn = strings.ToLower(strings.TrimSpace(dn))
	root = strings.ToLower(strings.TrimSpace(root))
	return dn == root || strings.HasSuffix(dn, ","+root)
}
func parentOUDN(dn string) string {
	escaped := false
	for i, c := range dn {
		if c == '\\' && !escaped {
			escaped = true
			continue
		}
		if c == ',' && !escaped {
			return strings.TrimSpace(dn[i+1:])
		}
		escaped = false
	}
	return ""
}
func dnHash(dn string) string {
	sum := sha256.Sum256([]byte(strings.ToLower(strings.TrimSpace(dn))))
	return hex.EncodeToString(sum[:])
}

type beneficiarySyncRequest struct {
	RootDNs       []string `json:"root_dns"`
	IncludePeople bool     `json:"include_people"`
}

func (a *App) syncBeneficiariesAD(w http.ResponseWriter, r *http.Request) {
	if !a.Directory.Enabled() {
		badRequest(w, errors.New("AD is disabled"))
		return
	}
	var req beneficiarySyncRequest
	if err := decodeJSON(r, &req, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if len(req.RootDNs) == 0 {
		badRequest(w, errors.New("select at least one organizational unit (root_dns)"))
		return
	}
	if len(req.RootDNs) > 100 {
		badRequest(w, errors.New("at most 100 OU roots"))
		return
	}
	roots := []string{}
	seenRoots := map[string]bool{}
	for _, root := range req.RootDNs {
		root = strings.TrimSpace(root)
		if !a.Directory.DNWithinBase(root) {
			badRequest(w, errors.New("OU outside configured Base DN"))
			return
		}
		if !seenRoots[strings.ToLower(root)] {
			roots = append(roots, root)
			seenRoots[strings.ToLower(root)] = true
		}
	}
	// Fetch both inventories completely before opening the DB transaction: an LDAP
	// error must never cause a partial sync or mark existing entries inactive.
	ous, err := a.Directory.OrganizationalUnits()
	if err != nil {
		respond(w, nil, err)
		return
	}
	validRoot := map[string]bool{}
	for _, unit := range ous {
		validRoot[strings.ToLower(unit.DN)] = true
	}
	for _, root := range roots {
		if !validRoot[strings.ToLower(root)] {
			badRequest(w, errors.New("selected OU no longer exists in AD"))
			return
		}
	}
	people := []directory.DirectoryPerson{}
	if req.IncludePeople {
		people, err = a.Directory.BeneficiaryPeople()
		if err != nil {
			respond(w, nil, err)
			return
		}
	}
	matches := func(dn string) bool {
		for _, root := range roots {
			if dnUnder(dn, root) {
				return true
			}
		}
		return false
	}
	tx, err := a.DB.BeginTx(r.Context(), nil)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer tx.Rollback()
	// Capture previous AD records in the selected subtree. Only these may become
	// inactive; manual records and unrelated AD branches must remain untouched.
	priorDepartments := map[int64]bool{}
	priorPeople := map[int64]bool{}
	rows, err := tx.QueryContext(r.Context(), "SELECT id,ldap_dn FROM beneficiary_departments WHERE source='ad'")
	if err != nil {
		respond(w, nil, err)
		return
	}
	for rows.Next() {
		var id int64
		var dn sql.NullString
		if err = rows.Scan(&id, &dn); err != nil {
			break
		}
		if matches(dn.String) {
			priorDepartments[id] = true
		}
	}
	if readErr := rows.Err(); err == nil {
		err = readErr
	}
	rows.Close()
	if err != nil {
		respond(w, nil, err)
		return
	}
	if req.IncludePeople {
		rows, err = tx.QueryContext(r.Context(), "SELECT id,directory_dn FROM people WHERE source='ldap' AND beneficiary_ad_guid IS NOT NULL")
		if err != nil {
			respond(w, nil, err)
			return
		}
		for rows.Next() {
			var id int64
			var dn sql.NullString
			if err = rows.Scan(&id, &dn); err != nil {
				break
			}
			if matches(dn.String) {
				priorPeople[id] = true
			}
		}
		if readErr := rows.Err(); err == nil {
			err = readErr
		}
		rows.Close()
		if err != nil {
			respond(w, nil, err)
			return
		}
	}
	// AD OU GUID is authoritative across renames. A record is inserted only when
	// its GUID is not yet known. DN hashes are refreshed on rename.
	idByDN := map[string]int64{}
	ouCount := 0
	personCount := 0
	for _, unit := range ous {
		if !matches(unit.DN) || unit.GUID == "" {
			continue
		}
		var id int64
		err = tx.QueryRowContext(r.Context(), "SELECT id FROM beneficiary_departments WHERE source='ad' AND ad_object_guid=?", unit.GUID).Scan(&id)
		if errors.Is(err, sql.ErrNoRows) {
			res, e := tx.ExecContext(r.Context(), "INSERT INTO beneficiary_departments(name,source,ldap_dn,ldap_dn_hash,ad_object_guid,active) VALUES(?,'ad',?,?,?,1)", unit.Name, unit.DN, dnHash(unit.DN), unit.GUID)
			if e != nil {
				respond(w, nil, e)
				return
			}
			id, _ = res.LastInsertId()
		} else if err != nil {
			respond(w, nil, err)
			return
		} else {
			_, err = tx.ExecContext(r.Context(), "UPDATE beneficiary_departments SET name=?,ldap_dn=?,ldap_dn_hash=?,active=1 WHERE id=?", unit.Name, unit.DN, dnHash(unit.DN), id)
			if err != nil {
				respond(w, nil, err)
				return
			}
		}
		idByDN[strings.ToLower(unit.DN)] = id
		delete(priorDepartments, id)
		ouCount++
	}
	// Resolve OU parent identities after all OUs are written.
	for dn, id := range idByDN {
		var parent any = nil
		if p, ok := idByDN[strings.ToLower(parentOUDN(dn))]; ok {
			parent = p
		}
		if _, err = tx.ExecContext(r.Context(), "UPDATE beneficiary_departments SET parent_id=? WHERE id=?", parent, id); err != nil {
			respond(w, nil, err)
			return
		}
	}
	if req.IncludePeople {
		for _, person := range people {
			if !matches(person.DN) {
				continue
			}
			var dept any = nil
			ancestor := parentOUDN(person.DN)
			for ancestor != "" {
				if v, ok := idByDN[strings.ToLower(ancestor)]; ok {
					dept = v
					break
				}
				ancestor = parentOUDN(ancestor)
			}
			// One canonical people row for both VM responsibilities and beneficiaries.
			// Match GUID first; DN and nonempty email reconcile prior AD imports.
			var id int64
			err = tx.QueryRowContext(r.Context(), "SELECT id FROM people WHERE beneficiary_ad_guid=? LIMIT 1", person.GUID).Scan(&id)
			if errors.Is(err, sql.ErrNoRows) {
				err = tx.QueryRowContext(r.Context(), "SELECT id FROM people WHERE source='ldap' AND LOWER(directory_dn)=LOWER(?) LIMIT 1", person.DN).Scan(&id)
			}
			if errors.Is(err, sql.ErrNoRows) && person.Email != "" {
				err = tx.QueryRowContext(r.Context(), "SELECT id FROM people WHERE LOWER(email)=LOWER(?) ORDER BY CASE WHEN source='ldap' THEN 0 ELSE 1 END,id LIMIT 1", person.Email).Scan(&id)
			}
			if errors.Is(err, sql.ErrNoRows) {
				res, e := tx.ExecContext(r.Context(), "INSERT INTO people(display_name,email,source,beneficiary_ad_guid,directory_dn,beneficiary_department_id,active) VALUES(?,?,'ldap',?,?,?,1)", person.Name, person.Email, person.GUID, person.DN, dept)
				if e != nil {
					respond(w, nil, e)
					return
				}
				id, err = res.LastInsertId()
			} else if err == nil {
				// Preserve phone, role references and other locally maintained fields.
				_, err = tx.ExecContext(r.Context(), "UPDATE people SET display_name=?,email=?,source='ldap',beneficiary_ad_guid=?,directory_dn=?,beneficiary_department_id=?,active=1 WHERE id=?", person.Name, person.Email, person.GUID, person.DN, dept, id)
			}
			if err != nil {
				respond(w, nil, err)
				return
			}
			delete(priorPeople, id)
			personCount++
		}
	}
	for id := range priorDepartments {
		if _, err = tx.ExecContext(r.Context(), "UPDATE beneficiary_departments SET active=0 WHERE id=?", id); err != nil {
			respond(w, nil, err)
			return
		}
	}
	for id := range priorPeople {
		if _, err = tx.ExecContext(r.Context(), "UPDATE people SET active=0 WHERE id=?", id); err != nil {
			respond(w, nil, err)
			return
		}
	}
	if err = saveBeneficiaryRoots(r.Context(), tx, roots); err != nil {
		respond(w, nil, err)
		return
	}
	if err = tx.Commit(); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "beneficiaries.ad.sync", "beneficiary", "ad", "success", map[string]any{"departments": ouCount, "people": personCount, "roots": len(roots)})
	respond(w, map[string]any{"departments": ouCount, "people": personCount, "inactive_departments": len(priorDepartments), "inactive_people": len(priorPeople), "root_dns": roots}, nil)
}

func validateBeneficiaryResource(ctx context.Context, db *sql.DB, typ string, id int64) error {
	table, ok := beneficiaryResourceTables[typ]
	if !ok || id <= 0 {
		return errors.New("invalid resource type or id")
	}
	var found int
	if err := db.QueryRowContext(ctx, "SELECT 1 FROM "+table+" WHERE id=?", id).Scan(&found); err != nil {
		return errors.New("resource does not exist")
	}
	return nil
}
func (a *App) listBeneficiaryAssignments(w http.ResponseWriter, r *http.Request) {
	typ := r.URL.Query().Get("resource_type")
	id, err := strconv.ParseInt(r.URL.Query().Get("resource_id"), 10, 64)
	if _, ok := beneficiaryResourceTables[typ]; !ok || err != nil || id <= 0 {
		badRequest(w, errors.New("valid resource_type and resource_id required"))
		return
	}
	includeEffective := r.URL.Query().Get("effective") == "true"
	var out []beneficiaryResourceRow
	if includeEffective {
		out, err = a.effectiveBeneficiariesOnResource(r.Context(), typ, id)
	} else {
		out, err = a.directBeneficiariesOnResource(r.Context(), typ, id)
	}
	respond(w, out, err)
}
func (a *App) addBeneficiaryAssignment(w http.ResponseWriter, r *http.Request) {
	var in beneficiaryAssignmentInput
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 65536)).Decode(&in); err != nil {
		badRequest(w, err)
		return
	}
	if !beneficiaryTypes[in.BeneficiaryType] || in.BeneficiaryID <= 0 {
		badRequest(w, errors.New("invalid beneficiary type or id"))
		return
	}
	if err := validateBeneficiaryResource(r.Context(), a.DB, in.ResourceType, in.ResourceID); err != nil {
		badRequest(w, err)
		return
	}
	var found int
	if err := a.DB.QueryRowContext(r.Context(), "SELECT 1 FROM "+beneficiaryTable(in.BeneficiaryType)+" WHERE id=? AND active=1", in.BeneficiaryID).Scan(&found); err != nil {
		badRequest(w, errors.New("beneficiary not found or inactive"))
		return
	}
	_, err := a.DB.ExecContext(r.Context(), "INSERT INTO beneficiary_assignments(resource_type,resource_id,beneficiary_type,beneficiary_id) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE id=id", in.ResourceType, in.ResourceID, in.BeneficiaryType, in.BeneficiaryID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "beneficiaries.assignment.add", in.ResourceType, strconv.FormatInt(in.ResourceID, 10), "success", map[string]any{"beneficiary_type": in.BeneficiaryType, "beneficiary_id": in.BeneficiaryID})
	jsonResponse(w, http.StatusCreated, map[string]any{"status": "ok"})
}
func (a *App) deleteBeneficiaryAssignment(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		badRequest(w, errors.New("invalid assignment id"))
		return
	}
	result, err := a.DB.ExecContext(r.Context(), "DELETE FROM beneficiary_assignments WHERE id=?", id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	n, _ := result.RowsAffected()
	if n == 0 {
		http.Error(w, "assignment not found", http.StatusNotFound)
		return
	}
	a.auditRequest(r, "beneficiaries.assignment.delete", "beneficiary_assignment", strconv.FormatInt(id, 10), "success", nil)
	respond(w, map[string]any{"status": "ok"}, nil)
}

// A derived edge means a resource is used by its target, never that siblings
// on the same VM have the same beneficiaries. Derived edges have one hop only.
// This prevents accidental fan-out from Docker A to Docker B via their host VM.
const beneficiaryEdgesSQL = `
 SELECT 'vm' source_type, a.vm_id source_id,'service' target_type,a.internal_service_id target_id,'VM → serviciu' relation FROM vm_internal_service_assignments a
 UNION ALL SELECT 'vm',c.vm_id,'support_component',c.id,'VM → componentă suport' FROM vm_support_components c
 UNION ALL SELECT 'docker',d.id,'vm',d.vm_id,'Docker → VM gazdă' FROM docker_containers d
 UNION ALL SELECT 'database',d.id,'vm',d.vm_id,'Bază → VM gazdă' FROM database_catalogs d
 UNION ALL SELECT 'web',w.id,'vm',w.vm_id,'Web → VM gazdă' FROM web_sites w
 UNION ALL SELECT 'support_component',c.id,'vm',c.vm_id,'Componentă → VM gazdă' FROM vm_support_components c
 UNION ALL SELECT 'docker',a.docker_container_id,'service',a.internal_service_id,'Docker → serviciu' FROM docker_container_service_assignments a
 UNION ALL SELECT 'database',a.database_catalog_id,'service',a.internal_service_id,'Bază → serviciu' FROM database_catalog_service_assignments a
 UNION ALL SELECT 'database',c.id,'service',a.internal_service_id,'Instanță DB → serviciu' FROM database_instance_service_assignments a JOIN database_catalogs c ON c.database_instance_id=a.database_instance_id
 UNION ALL SELECT 'web',a.web_site_id,'service',a.internal_service_id,'Web → serviciu' FROM web_site_service_assignments a
 UNION ALL SELECT 'docker',a.docker_container_id,'support_component',c.id,'Docker → componentă declarată' FROM docker_container_service_assignments a JOIN docker_containers d ON d.id=a.docker_container_id JOIN vm_support_components c ON c.vm_id=d.vm_id AND LOWER(TRIM(c.component_name))=LOWER(TRIM(a.component_name)) WHERE TRIM(a.component_name)<>''
 UNION ALL SELECT 'database',a.database_catalog_id,'support_component',c.id,'Bază → componentă declarată' FROM database_catalog_service_assignments a JOIN database_catalogs d ON d.id=a.database_catalog_id JOIN vm_support_components c ON c.vm_id=d.vm_id AND LOWER(TRIM(c.component_name))=LOWER(TRIM(a.component_name)) WHERE TRIM(a.component_name)<>''
 UNION ALL SELECT 'web',a.web_site_id,'support_component',c.id,'Web → componentă declarată' FROM web_site_service_assignments a JOIN web_sites d ON d.id=a.web_site_id JOIN vm_support_components c ON c.vm_id=d.vm_id AND LOWER(TRIM(c.component_name))=LOWER(TRIM(a.component_name)) WHERE TRIM(a.component_name)<>''
`

// A row preserves the direct assignment ID only for directly editable entries.
type beneficiaryResourceRow struct {
	ResourceType     string `json:"resource_type"`
	ResourceID       int64  `json:"resource_id"`
	Name             string `json:"name"`
	VMID             int64  `json:"vm_id,omitempty"`
	BeneficiaryType  string `json:"beneficiary_type"`
	BeneficiaryID    int64  `json:"beneficiary_id"`
	BeneficiaryName  string `json:"beneficiary_name"`
	Source           string `json:"source"`
	Direct           bool   `json:"direct"`
	AssignmentID     int64  `json:"assignment_id,omitempty"`
	ViaType          string `json:"via_type,omitempty"`
	ViaID            int64  `json:"via_id,omitempty"`
	ViaName          string `json:"via_name,omitempty"`
	Relation         string `json:"relation,omitempty"`
	ComponentKey     string `json:"component_key,omitempty"`
	ComponentVersion string `json:"component_version,omitempty"`
}

const resourceNamesSQL = `
 SELECT 'vm' typ,id,name,id vm_id FROM virtual_machines
 UNION ALL SELECT 'docker',id,name,vm_id FROM docker_containers
 UNION ALL SELECT 'database',id,name,vm_id FROM database_catalogs
 UNION ALL SELECT 'web',id,name,vm_id FROM web_sites
 UNION ALL SELECT 'service',id,name,0 FROM internal_services
 UNION ALL SELECT 'support_component',id,component_name,vm_id FROM vm_support_components`
const beneficiaryEffectiveSQL = `
 WITH resource_names AS (` + resourceNamesSQL + `), edges AS (` + beneficiaryEdgesSQL + `),
 items AS (
  SELECT a.id assignment_id,a.resource_type,a.resource_id,a.beneficiary_type,a.beneficiary_id, 1 direct,'' via_type,0 via_id,'' relation FROM beneficiary_assignments a
  UNION ALL SELECT 0,e.target_type,e.target_id,a.beneficiary_type,a.beneficiary_id,0,e.source_type,e.source_id,e.relation
     FROM beneficiary_assignments a JOIN edges e ON e.source_type=a.resource_type AND e.source_id=a.resource_id
 )
 SELECT i.resource_type,i.resource_id,COALESCE(n.name,''),n.vm_id,i.beneficiary_type,i.beneficiary_id,
 COALESCE(d.name,p.display_name,''),COALESCE(d.source,IF(p.source='ldap','ad',p.source),''),i.direct,i.assignment_id,i.via_type,i.via_id,COALESCE(v.name,''),i.relation
 FROM items i
 JOIN resource_names n ON n.typ=i.resource_type AND n.id=i.resource_id
 LEFT JOIN resource_names v ON v.typ=i.via_type AND v.id=i.via_id
 LEFT JOIN beneficiary_departments d ON i.beneficiary_type='department' AND d.id=i.beneficiary_id
 LEFT JOIN people p ON i.beneficiary_type='person' AND p.id=i.beneficiary_id
 WHERE COALESCE(d.id,p.id) IS NOT NULL`

func scanBeneficiaryRows(rows *sql.Rows) ([]beneficiaryResourceRow, error) {
	out := []beneficiaryResourceRow{}
	for rows.Next() {
		var v beneficiaryResourceRow
		if err := rows.Scan(&v.ResourceType, &v.ResourceID, &v.Name, &v.VMID, &v.BeneficiaryType, &v.BeneficiaryID, &v.BeneficiaryName, &v.Source, &v.Direct, &v.AssignmentID, &v.ViaType, &v.ViaID, &v.ViaName, &v.Relation); err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}
func (a *App) directBeneficiariesOnResource(ctx context.Context, typ string, id int64) ([]beneficiaryResourceRow, error) {
	rows, err := a.DB.QueryContext(ctx, `SELECT a.resource_type,a.resource_id,'',0,a.beneficiary_type,a.beneficiary_id,COALESCE(d.name,p.display_name,''),COALESCE(d.source,IF(p.source='ldap','ad',p.source),''),1,a.id,'',0,'','' FROM beneficiary_assignments a LEFT JOIN beneficiary_departments d ON a.beneficiary_type='department' AND a.beneficiary_id=d.id LEFT JOIN people p ON a.beneficiary_type='person' AND a.beneficiary_id=p.id WHERE a.resource_type=? AND a.resource_id=? ORDER BY 6`, typ, id)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanBeneficiaryRows(rows)
}
func (a *App) effectiveBeneficiariesOnResource(ctx context.Context, typ string, id int64) ([]beneficiaryResourceRow, error) {
	rows, err := a.DB.QueryContext(ctx, beneficiaryEffectiveSQL+" AND i.resource_type=? AND i.resource_id=? ORDER BY i.beneficiary_type,6,i.direct DESC", typ, id)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanBeneficiaryRows(rows)
}

// A software component is not a logical database. The beneficiary of a named
// database is also a beneficiary of the corresponding database engine on that
// same VM, but NOT of the other engines or containers hosted there. Preserve
// the logical database as evidence for the derived association. These virtual
// report rows do not create persisted assignments or change VM inventory.
type beneficiaryDatabaseEngine struct {
	VMID    int64
	Engine  string
	Product string
	Version string
}

func softwareComponentBeneficiaryRow(row beneficiaryResourceRow, engine beneficiaryDatabaseEngine) (beneficiaryResourceRow, bool) {
	def, ok := identifyDatabaseComponent(engine.Engine, engine.Product)
	if !ok || engine.VMID <= 0 {
		return beneficiaryResourceRow{}, false
	}
	version := cleanSoftwareComponentVersion(def, engine.Version)
	derived := row
	derived.ResourceType = "software_component"
	derived.ResourceID = engine.VMID // Software component identity also includes ComponentKey and Version.
	derived.VMID = engine.VMID
	derived.ComponentKey = def.Key
	derived.ComponentVersion = version
	derived.Name = def.Name
	if version != "" {
		derived.Name += " " + version
	}
	derived.Direct = false
	derived.AssignmentID = 0
	derived.ViaType = "database"
	derived.ViaID = row.ResourceID
	derived.ViaName = row.Name
	derived.Relation = "Bază de date → motor DB"
	return derived, true
}

func (a *App) addSoftwareComponentBeneficiaries(ctx context.Context, items []beneficiaryResourceRow) ([]beneficiaryResourceRow, error) {
	ids, found := make([]int64, 0), map[int64]bool{}
	for _, r := range items {
		if r.ResourceType == "database" && !found[r.ResourceID] {
			ids = append(ids, r.ResourceID)
			found[r.ResourceID] = true
		}
	}
	if len(ids) == 0 {
		return items, nil
	}
	placeholders := strings.TrimSuffix(strings.Repeat("?,", len(ids)), ",")
	args := make([]any, 0, len(ids))
	for _, v := range ids {
		args = append(args, v)
	}
	rows, err := a.DB.QueryContext(ctx, `SELECT c.id,c.vm_id,i.engine,i.product,COALESCE(NULLIF(i.version,''),NULLIF(eng.version,''),'')
 FROM database_catalogs c JOIN database_instances i ON i.id=c.database_instance_id
 LEFT JOIN database_engines eng ON eng.vm_id=c.vm_id AND eng.engine=i.engine
 WHERE c.id IN (`+placeholders+`) AND c.present=1`, args...)
	if err != nil {
		return nil, err
	}
	byCatalog := make(map[int64]beneficiaryDatabaseEngine, len(ids))
	for rows.Next() {
		var catalogID int64
		var d beneficiaryDatabaseEngine
		if err = rows.Scan(&catalogID, &d.VMID, &d.Engine, &d.Product, &d.Version); err != nil {
			break
		}
		byCatalog[catalogID] = d
	}
	if scanErr := rows.Err(); err == nil {
		err = scanErr
	}
	rows.Close()
	if err != nil {
		return nil, err
	}
	// Multiple catalogs on one engine may point to the same beneficiary. Keep
	// distinct provenance rows while deduplicating the summary by component key.
	for _, v := range items {
		if v.ResourceType != "database" {
			continue
		}
		if engine, ok := byCatalog[v.ResourceID]; ok {
			if derived, ok := softwareComponentBeneficiaryRow(v, engine); ok {
				items = append(items, derived)
			}
		}
	}
	return items, nil
}

func beneficiaryResourceIdentity(row beneficiaryResourceRow) string {
	// ResourceID is a VM ID for virtual software-component rows, so the product
	// and version are necessary to count multiple engines/versions correctly.
	return fmt.Sprintf("%s:%d:%s:%s", row.ResourceType, row.ResourceID, row.ComponentKey, row.ComponentVersion)
}

func (a *App) beneficiaryReportRows(ctx context.Context, typ string, id int64, children bool) ([]beneficiaryResourceRow, error) {
	ids := []int64{id}
	if typ == "department" && children && id > 0 {
		// Recursive OU descendants are included only on request. MariaDB 10.6+.
		rows, err := a.DB.QueryContext(ctx, `WITH RECURSIVE tree AS (SELECT id FROM beneficiary_departments WHERE id=? UNION ALL SELECT c.id FROM beneficiary_departments c JOIN tree p ON c.parent_id=p.id) SELECT id FROM tree`, id)
		if err != nil {
			return nil, err
		}
		defer rows.Close()
		ids = []int64{}
		for rows.Next() {
			var x int64
			if err = rows.Scan(&x); err != nil {
				return nil, err
			}
			ids = append(ids, x)
		}
		if err = rows.Err(); err != nil {
			return nil, err
		}
	}
	args := []any{typ}
	where := " AND i.beneficiary_type=? AND i.resource_type <> 'support_component'"
	if id > 0 {
		if len(ids) == 0 {
			return []beneficiaryResourceRow{}, nil
		}
		placeholders := strings.TrimSuffix(strings.Repeat("?,", len(ids)), ",")
		where += " AND i.beneficiary_id IN (" + placeholders + ")"
		for _, x := range ids {
			args = append(args, x)
		}
	}
	rows, err := a.DB.QueryContext(ctx, beneficiaryEffectiveSQL+where+" ORDER BY FIELD(i.resource_type,'service','software_component','database','web','docker','vm'),i.resource_type,3,i.direct DESC", args...)
	if err != nil {
		return nil, err
	}
	items, err := scanBeneficiaryRows(rows)
	rows.Close() // Release the connection before reading database engine metadata.
	if err != nil {
		return nil, err
	}
	return a.addSoftwareComponentBeneficiaries(ctx, items)
}
func (a *App) reportBeneficiaries(w http.ResponseWriter, r *http.Request) {
	typ, id, err := beneficiaryTypeAndID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	child := r.URL.Query().Get("include_children") == "true"
	rows, err := a.beneficiaryReportRows(r.Context(), typ, id, child)
	if err != nil {
		respond(w, nil, err)
		return
	}
	counts := map[string]int{}
	unique := map[string]bool{}
	for _, row := range rows {
		k := beneficiaryResourceIdentity(row)
		if !unique[k] {
			counts[row.ResourceType]++
			unique[k] = true
		}
	}
	respond(w, map[string]any{"beneficiary_type": typ, "beneficiary_id": id, "include_children": child, "generated_at": time.Now().UTC(), "counts": counts, "resources": rows}, nil)
}
func (a *App) exportBeneficiaries(w http.ResponseWriter, r *http.Request) {
	typ, id, err := beneficiaryTypeAndID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	items, err := a.beneficiaryReportRows(r.Context(), typ, id, r.URL.Query().Get("include_children") == "true")
	if err != nil {
		respond(w, nil, err)
		return
	}
	header := []xlsx.Cell{xlsx.Text("Categorie"), xlsx.Text("Resursă"), xlsx.Text("ID resursă"), xlsx.Text("Beneficiar"), xlsx.Text("Tip beneficiar"), xlsx.Text("Sursă"), xlsx.Text("Asociere"), xlsx.Text("Proveniență"), xlsx.Text("ID origine"), xlsx.Text("Relație"), xlsx.Text("Componentă"), xlsx.Text("Versiune")}
	types := []struct{ Code, Label string }{{"service", "Servicii"}, {"software_component", "Componente software"}, {"database", "Baze de date"}, {"web", "Web"}, {"docker", "Docker"}, {"vm", "VM-uri"}}
	sheets := []xlsx.Sheet{{Name: "Sumar", Rows: [][]xlsx.Cell{{xlsx.Text("Categorie"), xlsx.Text("Total resurse distincte")}}}}
	counts := map[string]map[string]bool{}
	for _, x := range types {
		sheets = append(sheets, xlsx.Sheet{Name: x.Label, Rows: [][]xlsx.Cell{header}})
		counts[x.Code] = map[string]bool{}
	}
	for _, item := range items {
		assoc := "Calculată"
		if item.Direct {
			assoc = "Directă"
		}
		row := []xlsx.Cell{xlsx.Text(item.ResourceType), xlsx.Text(item.Name), xlsx.Number(float64(item.ResourceID)), xlsx.Text(item.BeneficiaryName), xlsx.Text(item.BeneficiaryType), xlsx.Text(item.Source), xlsx.Text(assoc), xlsx.Text(item.ViaName), xlsx.Number(float64(item.ViaID)), xlsx.Text(item.Relation), xlsx.Text(item.ComponentKey), xlsx.Text(item.ComponentVersion)}
		for i, x := range types {
			if item.ResourceType == x.Code {
				sheets[i+1].Rows = append(sheets[i+1].Rows, row)
				counts[x.Code][beneficiaryResourceIdentity(item)] = true
				break
			}
		}
	}
	for _, x := range types {
		sheets[0].Rows = append(sheets[0].Rows, []xlsx.Cell{xlsx.Text(x.Label), xlsx.Number(float64(len(counts[x.Code])))})
	}
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="vm-doc-beneficiari-%s-%d.xlsx"`, typ, id))
	if err = xlsx.WriteSheets(w, sheets); err != nil {
		a.Logger.Error("beneficiary Excel export", "error", err)
	}
}
