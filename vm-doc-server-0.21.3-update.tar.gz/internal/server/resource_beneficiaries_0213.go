package server

import (
	"errors"
	"net/http"
	"strings"
)

// One request for all rows in a VM tab. Avoid a per-container/catalog/site
// request and deliver the same effective beneficiary information as the editor.
func (a *App) listVMResourceBeneficiaries(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	typ := strings.TrimSpace(r.URL.Query().Get("type"))
	if typ != "docker" && typ != "database" && typ != "web" {
		badRequest(w, errors.New("type must be docker, database or web"))
		return
	}
	rows, err := a.DB.QueryContext(r.Context(), beneficiaryEffectiveSQL+" AND n.vm_id=? AND i.resource_type=? ORDER BY i.resource_id,i.direct DESC", vmID, typ)
	if err != nil {
		respond(w, nil, err)
		return
	}
	items, err := scanBeneficiaryRows(rows)
	rows.Close()
	respond(w, items, err)
}
