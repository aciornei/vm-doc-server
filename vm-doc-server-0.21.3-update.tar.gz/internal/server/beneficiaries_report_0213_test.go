package server

import (
	"net/http/httptest"
	"testing"
)

func TestBeneficiaryAllDepartmentsSelection(t *testing.T) {
	req := httptest.NewRequest("GET", "/api/v1/reports/beneficiaries?type=department&id=0", nil)
	typ, id, err := beneficiaryTypeAndID(req)
	if err != nil || typ != "department" || id != 0 {
		t.Fatalf("all departments: %q %d %v", typ, id, err)
	}
	for _, url := range []string{
		"/api/v1/reports/beneficiaries?type=person&id=0",
		"/api/v1/reports/beneficiaries?type=department&id=-1",
		"/api/v1/reports/beneficiaries?type=person&id=garbage",
	} {
		if _, _, err := beneficiaryTypeAndID(httptest.NewRequest("GET", url, nil)); err == nil {
			t.Errorf("invalid selection accepted: %s", url)
		}
	}
}
func TestResourceDocumentationExportLabel(t *testing.T) {
	for _, test := range []struct {
		exempt   bool
		count    int
		expected string
	}{
		{true, 2, "Nu necesită documentare"},
		{false, 0, "Nedocumentat"},
		{false, 1, "Documentat"},
	} {
		if got := resourceDocumentationExportLabel(test.exempt, test.count); got != test.expected {
			t.Errorf("got %q, expected %q", got, test.expected)
		}
	}
}
