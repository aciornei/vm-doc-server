# Upgrade vm-doc-server 0.19.5 → 0.19.6

0.19.6 extinde inventarul VM cu selecții persistente pentru porturile/procesele importante și actualizează fișa VM. Agentul și collectorul nu se modifică; `vm-doc-agent 1.6.3` rămâne compatibil.

## Noutăți

- în `VM → Inventar → Porturi ascultate` apare bifa **Principal**;
- selecția persistă după colectări și restarturi pe cheia `protocol + port + process_name`; PID-ul nu face parte din cheie;
- pentru o selecție detectată, serverul preia din inventarul curent PID-ul, executabilul și toate adresele de listen disponibile;
- selecțiile care nu mai sunt detectate rămân vizibile pentru revizuire;
- fișa VM adaugă subsecțiunea **Porturi și procese principale**;
- secțiunea separată **Politici** nu mai este generată în fișa VM. Capitolul Firewall păstrează informațiile sale, inclusiv politica implicită a firewall-ului.

## Migrare DB

La pornirea serverului se aplică automat:

```text
041_vm_primary_agent_ports.up.sql
```

Migrarea creează tabela `vm_primary_agent_ports`. Nu modifică snapshoturile de inventar existente.

## Instalare

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.5 vm-doc-server-0.19.6
tar -xzf /home/andrei.ciornei/vm-doc-server-0.19.6-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.6
cd /usr/local/src/vm-doc-server-0.19.6
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

Collectorul nu necesită rebuild/install pentru această versiune. După upgrade, folosiți `Ctrl+F5` pentru a încărca JavaScript-ul 0.19.6.

## Verificări rapide

1. `/version` trebuie să raporteze `0.19.6`.
2. Deschideți o VM cu inventar agent și secțiunea **Porturi ascultate**.
3. Marcați, de exemplu, `8100/TCP · soffice.bin` ca **Principal**, reîncărcați pagina și verificați că selecția persistă.
4. Preview/generare fișă VM trebuie să conțină **Porturi și procese principale** cu detaliile procesului.
5. Fișa VM nu trebuie să mai conțină secțiunea separată **Politici** din inventarul agentului.
