-- 0.19.6 · porturi/procese principale selectate din inventarul agentului

CREATE TABLE IF NOT EXISTS vm_primary_agent_ports (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  protocol VARCHAR(16) NOT NULL,
  port INT UNSIGNED NOT NULL,
  process_name VARCHAR(255) NOT NULL DEFAULT '',
  selected_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_vm_primary_agent_port (vm_id,protocol,port,process_name),
  KEY idx_vm_primary_agent_ports_vm (vm_id),
  CONSTRAINT fk_vm_primary_agent_ports_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_primary_agent_ports_user FOREIGN KEY (selected_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
