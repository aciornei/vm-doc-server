package inventory

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"sort"
	"strconv"
	"strings"

	"vm-doc-server/internal/domain"
)

const (
	maxPrimaryPortProtocolLength = 16
	maxPrimaryProcessNameLength  = 255
)

// SetPrimaryAgentPort marchează sau demarchează un port/proces raportat de
// agent ca fiind important pentru documentația VM-ului. PID-ul și adresele de
// listen nu fac parte din identitatea selecției, astfel încât aceasta
// supraviețuiește restarturilor și schimbărilor IPv4/IPv6.
func (s Service) SetPrimaryAgentPort(ctx context.Context, vmID, userID int64, protocol string, port int, processName string, primary bool) error {
	protocol = strings.ToLower(strings.TrimSpace(protocol))
	processName = strings.TrimSpace(processName)
	if protocol == "" {
		return errors.New("protocol is required")
	}
	if len(protocol) > maxPrimaryPortProtocolLength {
		return fmt.Errorf("protocol is too long (max %d characters)", maxPrimaryPortProtocolLength)
	}
	if port < 1 || port > 65535 {
		return errors.New("port must be between 1 and 65535")
	}
	if len(processName) > maxPrimaryProcessNameLength {
		return fmt.Errorf("process_name is too long (max %d characters)", maxPrimaryProcessNameLength)
	}
	if primary {
		_, err := s.DB.ExecContext(ctx, `INSERT INTO vm_primary_agent_ports(vm_id,protocol,port,process_name,selected_by) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE selected_by=VALUES(selected_by),updated_at=CURRENT_TIMESTAMP(6)`, vmID, protocol, port, processName, userID)
		return err
	}
	_, err := s.DB.ExecContext(ctx, `DELETE FROM vm_primary_agent_ports WHERE vm_id=? AND protocol=? AND port=? AND process_name=?`, vmID, protocol, port, processName)
	return err
}

func (s Service) PrimaryAgentPortSelections(ctx context.Context, vmID int64) ([]domain.PrimaryAgentPort, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT protocol,port,process_name FROM vm_primary_agent_ports WHERE vm_id=? ORDER BY port,protocol,LOWER(process_name),process_name`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.PrimaryAgentPort, 0)
	for rows.Next() {
		var item domain.PrimaryAgentPort
		if err := rows.Scan(&item.Protocol, &item.Port, &item.ProcessName); err != nil {
			return nil, err
		}
		out = append(out, item)
	}
	return out, rows.Err()
}

// ListPrimaryAgentPorts întoarce selecțiile persistente îmbogățite cu datele
// din inventarul curent. Dacă endpointul/procesul nu mai este raportat,
// selecția rămâne vizibilă cu Detected=false.
func (s Service) ListPrimaryAgentPorts(ctx context.Context, vmID int64, raw []byte) ([]domain.PrimaryAgentPort, error) {
	selected, err := s.PrimaryAgentPortSelections(ctx, vmID)
	if err != nil {
		return nil, err
	}
	observed, err := parseAgentPorts(raw)
	if err != nil && len(raw) > 0 {
		return nil, err
	}
	out := make([]domain.PrimaryAgentPort, 0, len(selected))
	for _, item := range selected {
		key := primaryPortKey(item.Protocol, item.Port, item.ProcessName)
		if current, ok := observed[key]; ok {
			current.Detected = true
			out = append(out, current)
			continue
		}
		item.Protocol = strings.ToLower(strings.TrimSpace(item.Protocol))
		item.ProcessName = strings.TrimSpace(item.ProcessName)
		item.Detected = false
		out = append(out, item)
	}
	sortPrimaryPorts(out)
	return out, nil
}

func parseAgentPorts(raw []byte) (map[string]domain.PrimaryAgentPort, error) {
	out := make(map[string]domain.PrimaryAgentPort)
	if len(bytes.TrimSpace(raw)) == 0 {
		return out, nil
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var root map[string]any
	if err := decoder.Decode(&root); err != nil {
		return nil, fmt.Errorf("decode inventory for primary ports: %w", err)
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return nil, errors.New("inventory JSON contains trailing data")
	}
	ports, _ := root["listening_ports"].([]any)
	for _, rawItem := range ports {
		item, ok := rawItem.(map[string]any)
		if !ok {
			continue
		}
		protocol := strings.ToLower(mapString(item, "protocol"))
		port := mapInt(item, "port")
		if protocol == "" || port < 1 || port > 65535 {
			continue
		}
		address := firstAgentMapString(item, "address", "local_address", "listen")
		processes, _ := item["processes"].([]any)
		added := false
		for _, rawProcess := range processes {
			process, ok := rawProcess.(map[string]any)
			if !ok {
				continue
			}
			processName := firstAgentMapString(process, "name", "process", "process_name", "service", "program")
			executable := firstAgentMapString(process, "executable", "exec", "exec_path", "binary", "path", "command")
			pid := mapInt(process, "pid")
			mergeObservedPrimaryPort(out, domain.PrimaryAgentPort{Protocol: protocol, Port: port, ProcessName: processName, Executable: executable, PIDs: positiveInts(pid), Addresses: nonEmptyStrings(address), Detected: true})
			added = true
		}
		if !added {
			processName := firstAgentMapString(item, "name", "process", "process_name", "service", "program")
			executable := firstAgentMapString(item, "executable", "exec", "exec_path", "binary", "path", "command")
			pid := mapInt(item, "pid")
			mergeObservedPrimaryPort(out, domain.PrimaryAgentPort{Protocol: protocol, Port: port, ProcessName: processName, Executable: executable, PIDs: positiveInts(pid), Addresses: nonEmptyStrings(address), Detected: true})
		}
	}
	for key, value := range out {
		value.PIDs = uniqueSortedInts(value.PIDs)
		value.Addresses = uniqueSortedStrings(value.Addresses)
		out[key] = value
	}
	return out, nil
}

func mergeObservedPrimaryPort(out map[string]domain.PrimaryAgentPort, item domain.PrimaryAgentPort) {
	item.Protocol = strings.ToLower(strings.TrimSpace(item.Protocol))
	item.ProcessName = strings.TrimSpace(item.ProcessName)
	item.Executable = strings.TrimSpace(item.Executable)
	key := primaryPortKey(item.Protocol, item.Port, item.ProcessName)
	current, ok := out[key]
	if !ok {
		out[key] = item
		return
	}
	if current.Executable == "" && item.Executable != "" {
		current.Executable = item.Executable
	}
	current.PIDs = append(current.PIDs, item.PIDs...)
	current.Addresses = append(current.Addresses, item.Addresses...)
	current.Detected = current.Detected || item.Detected
	out[key] = current
}

func primaryPortKey(protocol string, port int, processName string) string {
	return strings.ToLower(strings.TrimSpace(protocol)) + "/" + strconv.Itoa(port) + "/" + strings.ToLower(strings.TrimSpace(processName))
}

func sortPrimaryPorts(values []domain.PrimaryAgentPort) {
	sort.SliceStable(values, func(i, j int) bool {
		if values[i].Port != values[j].Port {
			return values[i].Port < values[j].Port
		}
		if values[i].Protocol != values[j].Protocol {
			return values[i].Protocol < values[j].Protocol
		}
		return strings.ToLower(values[i].ProcessName) < strings.ToLower(values[j].ProcessName)
	})
}

func mapInt(value map[string]any, key string) int {
	if value == nil {
		return 0
	}
	switch raw := value[key].(type) {
	case json.Number:
		n, _ := strconv.Atoi(raw.String())
		return n
	case float64:
		return int(raw)
	case float32:
		return int(raw)
	case int:
		return raw
	case int64:
		return int(raw)
	case string:
		n, _ := strconv.Atoi(strings.TrimSpace(raw))
		return n
	default:
		return 0
	}
}

func firstAgentMapString(value map[string]any, keys ...string) string {
	for _, key := range keys {
		if text := mapString(value, key); text != "" {
			return text
		}
	}
	return ""
}

func positiveInts(values ...int) []int {
	out := make([]int, 0, len(values))
	for _, value := range values {
		if value > 0 {
			out = append(out, value)
		}
	}
	return out
}

func nonEmptyStrings(values ...string) []string {
	out := make([]string, 0, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value != "" {
			out = append(out, value)
		}
	}
	return out
}

func uniqueSortedInts(values []int) []int {
	seen := make(map[int]bool)
	out := make([]int, 0, len(values))
	for _, value := range values {
		if value <= 0 || seen[value] {
			continue
		}
		seen[value] = true
		out = append(out, value)
	}
	sort.Ints(out)
	return out
}

func uniqueSortedStrings(values []string) []string {
	seen := make(map[string]bool)
	out := make([]string, 0, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		key := strings.ToLower(value)
		if seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, value)
	}
	sort.SliceStable(out, func(i, j int) bool { return strings.ToLower(out[i]) < strings.ToLower(out[j]) })
	return out
}
