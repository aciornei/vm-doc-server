package inventory

import "testing"

func TestParseAgentPortsMergesAddressesAndKeepsProcessIdentity(t *testing.T) {
	raw := []byte(`{"listening_ports":[{"address":"0.0.0.0","port":8100,"protocol":"tcp","processes":[{"pid":4242,"name":"soffice.bin","executable":"/usr/lib/libreoffice/program/soffice.bin"}]},{"address":"::","port":8100,"protocol":"tcp","processes":[{"pid":4242,"name":"soffice.bin","executable":"/usr/lib/libreoffice/program/soffice.bin"}]},{"address":"127.0.0.1","port":8983,"protocol":"tcp","processes":[{"pid":5001,"name":"java","executable":"/usr/bin/java"}]}]}`)
	values, err := parseAgentPorts(raw)
	if err != nil {
		t.Fatal(err)
	}
	soffice, ok := values["tcp/8100/soffice.bin"]
	if !ok {
		t.Fatalf("soffice selection missing: %+v", values)
	}
	if soffice.Executable != "/usr/lib/libreoffice/program/soffice.bin" || len(soffice.PIDs) != 1 || soffice.PIDs[0] != 4242 || len(soffice.Addresses) != 2 || !soffice.Detected {
		t.Fatalf("unexpected soffice value: %+v", soffice)
	}
	java, ok := values["tcp/8983/java"]
	if !ok || java.Port != 8983 || java.ProcessName != "java" {
		t.Fatalf("unexpected java value: %+v", java)
	}
}

func TestParseAgentPortsSupportsPortWithoutProcess(t *testing.T) {
	raw := []byte(`{"listening_ports":[{"address":"10.0.0.10","port":"443","protocol":"tcp","processes":[]}]}`)
	values, err := parseAgentPorts(raw)
	if err != nil {
		t.Fatal(err)
	}
	value, ok := values["tcp/443/"]
	if !ok || value.Port != 443 || value.ProcessName != "" || len(value.Addresses) != 1 {
		t.Fatalf("unexpected port: %+v", value)
	}
}
