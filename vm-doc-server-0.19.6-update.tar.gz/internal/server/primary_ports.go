package server

import (
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
)

type primaryPortRequest struct {
	Protocol    string `json:"protocol"`
	Port        int    `json:"port"`
	ProcessName string `json:"process_name"`
	Primary     bool   `json:"primary"`
}

func (a *App) setVMPrimaryPort(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input primaryPortRequest
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Inventory.SetPrimaryAgentPort(r.Context(), vmID, user.ID, input.Protocol, input.Port, input.ProcessName, input.Primary); err != nil {
		if a.Logger != nil {
			a.Logger.Error("VM primary agent port could not be updated", "vm_id", vmID, "protocol", input.Protocol, "port", input.Port, "process_name", input.ProcessName, "primary", input.Primary, "error", err)
		}
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "vm.primary_agent_port.update", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{"protocol": input.Protocol, "port": input.Port, "process_name": input.ProcessName, "primary": input.Primary})
	jsonResponse(w, http.StatusOK, map[string]any{"vm_id": vmID, "protocol": input.Protocol, "port": input.Port, "process_name": input.ProcessName, "primary": input.Primary})
}
