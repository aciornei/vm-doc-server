package buildinfo

var (
	Version = "0.19.6-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
