package server

import (
	"net/http"
	"strconv"
	"strings"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/fortigate"
	"vm-doc-server/internal/xlsx"
)

func (a *App) listFortiGateSources(w http.ResponseWriter, r *http.Request) {
	v, err := a.FortiGate.ListSources(r.Context())
	respond(w, v, err)
}
func (a *App) getFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.FortiGate.GetSource(r.Context(), id)
	respond(w, v, err)
}
func (a *App) createFortiGateSource(w http.ResponseWriter, r *http.Request) {
	var in fortigate.SourceInput
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.FortiGate.CreateSource(r.Context(), in, u.ID)
	if err == nil {
		a.auditRequest(r, "fortigate.source.create", "fortigate_source", strconv.FormatInt(v.ID, 10), "success", map[string]any{"name": v.Name, "base_url": v.BaseURL, "vdom": v.VDOM})
	}
	respondStatus(w, v, err, http.StatusCreated)
}
func (a *App) updateFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in fortigate.SourceInput
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.FortiGate.UpdateSource(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "fortigate.source.update", "fortigate_source", strconv.FormatInt(id, 10), "success", map[string]any{"name": v.Name, "base_url": v.BaseURL, "vdom": v.VDOM})
	}
	respond(w, v, err)
}
func (a *App) deleteFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	err = a.FortiGate.DeleteSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "fortigate.source.delete", "fortigate_source", strconv.FormatInt(id, 10), "success", nil)
	}
	respond(w, map[string]any{"deleted": err == nil}, err)
}
func (a *App) testFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.FortiGate.TestSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "fortigate.source.test", "fortigate_source", strconv.FormatInt(id, 10), "success", v)
	}
	respond(w, v, err)
}
func (a *App) syncFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	run, err := a.FortiGate.StartSync(r.Context(), id, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "fortigate.sync.queue", "fortigate_source", strconv.FormatInt(id, 10), "success", map[string]any{"run_id": run.ID})
	}
	respondStatus(w, run, err, http.StatusAccepted)
}
func (a *App) syncAllFortiGate(w http.ResponseWriter, r *http.Request) {
	u, _ := auth.UserFromContext(r.Context())
	runs, err := a.FortiGate.StartAll(r.Context(), &u.ID)
	if err == nil {
		a.auditRequest(r, "fortigate.sync.queue_all", "fortigate", "all", "success", map[string]any{"runs": len(runs)})
	}
	respondStatus(w, runs, err, http.StatusAccepted)
}
func (a *App) listFortiGateRuns(w http.ResponseWriter, r *http.Request) {
	page, size, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.FortiGate.ListRunsPage(r.Context(), page, size)
	respond(w, v, err)
}

func (a *App) exportFortiGateRules(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	items := make([]fortigate.RuleRow, 0)
	for page := 1; ; page++ {
		v, err := a.FortiGate.ListRules(r.Context(), q.Get("q"), q.Get("direction"), q.Get("risk"), q.Get("action"), q.Get("status"), q.Get("service"), q.Get("interface"), q.Get("vdom"), q.Get("review"), fortigate.ParseIntQuery(q.Get("source_id")), fortigate.ParseIntQuery(q.Get("vm_id")), page, 500)
		if err != nil {
			respond(w, nil, err)
			return
		}
		items = append(items, v.Items...)
		if v.Pages == 0 || page >= v.Pages {
			break
		}
	}
	rows := [][]xlsx.Cell{{
		xlsx.Text("VM"), xlsx.Text("IP VM"), xlsx.Text("Rol VM"), xlsx.Text("FortiGate"), xlsx.Text("VDOM"), xlsx.Text("Policy ID"), xlsx.Text("Policy"),
		xlsx.Text("Interfață sursă"), xlsx.Text("Interfață destinație"), xlsx.Text("Adrese sursă"), xlsx.Text("Adrese destinație"), xlsx.Text("Service"),
		xlsx.Text("Acțiune"), xlsx.Text("NAT"), xlsx.Text("Schedule"), xlsx.Text("Corelat prin"), xlsx.Text("Motiv corelare"), xlsx.Text("VIP"), xlsx.Text("External IP"),
		xlsx.Text("Indicatori"), xlsx.Text("Review"), xlsx.Text("Ultimul review"), xlsx.Text("Următorul review"), xlsx.Text("Reviewer"), xlsx.Text("Observații review"),
	}}
	for _, item := range items {
		reviewStatus := "Nerevizuit"
		if item.Review.ReviewedAt != nil {
			reviewStatus = "La zi"
			if item.Review.Due {
				reviewStatus = "Expirat"
			}
		}
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(item.VMName), xlsx.Text(item.VMIP), xlsx.Text(item.Direction), xlsx.Text(item.SourceName), xlsx.Text(item.VDOM), xlsx.Number(float64(item.PolicyID)), xlsx.Text(item.PolicyName),
			xlsx.Text(strings.Join(item.SrcIntf, ", ")), xlsx.Text(strings.Join(item.DstIntf, ", ")), xlsx.Text(strings.Join(item.SrcAddr, ", ")), xlsx.Text(strings.Join(item.DstAddr, ", ")), xlsx.Text(strings.Join(item.Services, ", ")),
			xlsx.Text(item.Action), xlsx.Text(yesNo(item.NAT)), xlsx.Text(item.Schedule), xlsx.Text(item.MatchObject), xlsx.Text(item.MatchReason), xlsx.Text(item.VIPName), xlsx.Text(item.ExtIP),
			xlsx.Text(strings.Join(item.Risks, "; ")), xlsx.Text(reviewStatus), xlsx.Text(exportTime(item.Review.ReviewedAt)), xlsx.Text(exportTime(item.Review.NextReviewAt)), xlsx.Text(item.Review.ReviewedBy), xlsx.Text(item.Review.Notes),
		})
	}
	if err := writeXLSXResponse(w, "Firewall FortiGate", "firewall-fortigate", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write FortiGate rules XLSX", "error", err)
	}
}

func (a *App) listFortiGateRules(w http.ResponseWriter, r *http.Request) {
	page, size, err := paginationFromRequest(r, 50, 500)
	if err != nil {
		badRequest(w, err)
		return
	}
	q := r.URL.Query()
	v, err := a.FortiGate.ListRules(r.Context(), q.Get("q"), q.Get("direction"), q.Get("risk"), q.Get("action"), q.Get("status"), q.Get("service"), q.Get("interface"), q.Get("vdom"), q.Get("review"), fortigate.ParseIntQuery(q.Get("source_id")), fortigate.ParseIntQuery(q.Get("vm_id")), page, size)
	respond(w, v, err)
}
