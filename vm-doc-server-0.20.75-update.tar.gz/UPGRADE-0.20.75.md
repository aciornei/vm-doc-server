# Upgrade VM-DOC Server 0.20.74 → 0.20.75

0.20.75 este o versiune de **UI/ergonomie Firewall** și export Excel. Nu schimbă matching-ul FortiGate și nu introduce migrare DB.

Agentul rămâne **1.7.12**.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.74 /usr/local/src/vm-doc-server-0.20.75
tar -xzf vm-doc-server-0.20.75-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.75
cd /usr/local/src/vm-doc-server-0.20.75
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi restart server și **Ctrl+F5** în browser.

## Verificare recomandată

1. Pe o VM, verifică faptul că **Hartă rețea** este sub meniul **Securitate**.
2. **VM → Securitate → Firewall**:
   - click pe cardurile Sursă / Destinație / VIP / Indicatori și verifică filtrarea tabelului;
   - verifică separarea coloanelor **Adresă sursă** și **Adresă destinație**;
   - verifică **Export Excel**;
   - verifică panoul **Firewall local al VM-ului**.
3. **Securitate → Firewall** trebuie să aibă submeniurile:
   - **1. Caută**;
   - **2. Surse & Sync**;
   - **3. Analiză Forti**.
4. În **Caută** și **Analiză Forti**, verifică filtrele compacte și scrollbar-ul orizontal al tabelului, vizibil în zona tabelului fără scroll până la finalul paginii.
5. În **Surse & Sync**, Adaugă/Edit trebuie să deschidă formularul inline, fără prompt-uri succesive.
6. Exportul global Excel trebuie să respecte filtrele active din Caută.

Nu este necesar un Sync FortiGate doar pentru upgrade-ul 0.20.75.
