-- VM-DOC 0.21.10: local hardening catalog, CIS traceability, no automatic remediation.
-- Benchmark recommendation IDs intentionally remain NULL until individually verified.
CREATE TABLE IF NOT EXISTS hardening_profiles (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(80) NOT NULL UNIQUE, name VARCHAR(255) NOT NULL,
 os_match VARCHAR(64) NOT NULL, version_prefix VARCHAR(30) NOT NULL DEFAULT '',
 level VARCHAR(12) NOT NULL DEFAULT 'L1', benchmark VARCHAR(255) NOT NULL DEFAULT '',
 benchmark_version VARCHAR(30) NOT NULL DEFAULT '', benchmark_url VARCHAR(1024) NOT NULL DEFAULT '',
 enabled TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS hardening_rules (
 code VARCHAR(64) NOT NULL PRIMARY KEY, name VARCHAR(255) NOT NULL,
 category VARCHAR(80) NOT NULL, check_key VARCHAR(100) NOT NULL,
 expected VARCHAR(80) NOT NULL, severity VARCHAR(20) NOT NULL DEFAULT 'medium',
 enabled TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS hardening_profile_rules (
 profile_id BIGINT NOT NULL, rule_code VARCHAR(64) NOT NULL,
 enabled TINYINT(1) NOT NULL DEFAULT 1,
 PRIMARY KEY(profile_id,rule_code),
 CONSTRAINT fk_hpr_profile FOREIGN KEY(profile_id) REFERENCES hardening_profiles(id) ON DELETE CASCADE,
 CONSTRAINT fk_hpr_rule FOREIGN KEY(rule_code) REFERENCES hardening_rules(code) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS hardening_cis_mappings (
 profile_id BIGINT NOT NULL,rule_code VARCHAR(64) NOT NULL,
 recommendation_id VARCHAR(50) NULL,control_id VARCHAR(50) NULL,
 status VARCHAR(20) NOT NULL DEFAULT 'pending', note VARCHAR(1024) NOT NULL DEFAULT '',
 updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
 PRIMARY KEY(profile_id,rule_code),
 CONSTRAINT fk_hcm_pr FOREIGN KEY(profile_id,rule_code) REFERENCES hardening_profile_rules(profile_id,rule_code) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS vm_hardening_profiles (
 vm_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,profile_id BIGINT NOT NULL,
 CONSTRAINT fk_vhp_vm FOREIGN KEY(vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
 CONSTRAINT fk_vhp_profile FOREIGN KEY(profile_id) REFERENCES hardening_profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO hardening_profiles (code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url) VALUES ('ubuntu-24-l1','Ubuntu 24.04 · Server L1','ubuntu','24.04','L1','CIS Ubuntu Linux 24.04 LTS','2.0.0','https://www.cisecurity.org/benchmark/ubuntu_linux');
INSERT IGNORE INTO hardening_profiles (code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url) VALUES ('ubuntu-22-l1','Ubuntu 22.04 · Server L1','ubuntu','22.04','L1','CIS Ubuntu Linux 22.04 LTS','3.0.0','https://www.cisecurity.org/benchmark/ubuntu_linux');
INSERT IGNORE INTO hardening_profiles (code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url) VALUES ('ubuntu-20-l1','Ubuntu 20.04 · Server L1','ubuntu','20.04','L1','CIS Ubuntu Linux 20.04 LTS','3.0.0','https://www.cisecurity.org/benchmark/ubuntu_linux');
INSERT IGNORE INTO hardening_profiles (code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url) VALUES ('debian-12-l1','Debian 12 · Server L1','debian','12','L1','CIS Debian Linux 12','2.0.0','https://www.cisecurity.org/benchmark/debian_linux');
INSERT IGNORE INTO hardening_profiles (code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url) VALUES ('windows-2019-l1','Windows Server 2019 · L1','windows','2019','L1','CIS Microsoft Windows Server 2019','5.0.0','https://www.cisecurity.org/benchmark/microsoft_windows_server');
INSERT IGNORE INTO hardening_profiles (code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url) VALUES ('windows-2022-l1','Windows Server 2022 · L1','windows','2022','L1','CIS Microsoft Windows Server 2022','5.1.0','https://www.cisecurity.org/benchmark/microsoft_windows_server');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-SSH-001','SSH: login root interzis','SSH','linux.ssh_permit_root','no','high');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-SSH-002','SSH: autentificare cu parolă dezactivată','SSH','linux.ssh_password_auth','no','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-SSH-003','SSH: parole goale interzise','SSH','linux.ssh_empty_passwords','no','high');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-SSH-004','SSH: X11 Forwarding dezactivat','SSH','linux.ssh_x11','no','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-SSH-005','SSH: maximum 4 încercări de autentificare','SSH','linux.ssh_max_auth_tries','max4','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-NET-001','IPv4 forwarding dezactivat (server non-router)','Rețea','linux.ip_forward','0','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-NET-002','ICMP redirects neacceptate','Rețea','linux.accept_redirects','0','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-NET-003','ICMP redirects netrimise','Rețea','linux.send_redirects','0','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-NET-004','Reverse path filtering activ','Rețea','linux.rp_filter','1or2','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-FS-001','Permisiuni restrictive /etc/shadow','Fișiere','linux.shadow_mode','shadow','high');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-OPS-001','Firewall local activ','Firewall','firewall.active','true','high');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-OPS-002','Sincronizare timp activă','NTP','ntp.synchronized','true','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-OPS-003','Politică parole aplicată','Conturi','accounts.password_policy','enforced','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-AUD-001','Serviciu de audit activ','Audit','services.auditd','active','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-FS-002','Directorul /tmp montat securizat','Fișiere','manual.tmp_mount','manual','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-OPS-004','Actualizări de securitate verificate','Actualizări','manual.security_updates','manual','high');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('WIN-SEC-001','UAC activ','Windows','windows.uac','1','high');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('WIN-SEC-002','SMBv1 dezactivat','Windows','windows.smb1','0','high');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('WIN-SEC-003','RDP necesită Network Level Authentication','Windows','windows.rdp_nla','1','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('WIN-OPS-001','Politica Windows Firewall verificată','Firewall','manual.windows_firewall','manual','high');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('WIN-AUD-001','Advanced Audit Policy verificată','Audit','manual.windows_audit','manual','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('WIN-OPS-002','Windows Update verificat','Actualizări','manual.windows_updates','manual','high');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('WIN-ACC-001','Politici Windows de parole verificate','Conturi','manual.windows_password_policy','manual','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('WIN-SEC-004','Microsoft Defender / antivirus verificat','Windows','manual.windows_av','manual','medium');
INSERT IGNORE INTO hardening_rules (code,name,category,check_key,expected,severity) VALUES ('LIN-ACC-001','Conturile privilegiate revizuite','Conturi','manual.privileged_accounts','manual','high');
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-001' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-002' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-003' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-004' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-005' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-001' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-002' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-003' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-004' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-FS-001' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-001' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-002' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-003' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-AUD-001' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-FS-002' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-004' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-ACC-001' FROM hardening_profiles WHERE code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_cis_mappings (profile_id,rule_code,status,note) SELECT profile_id,rule_code,'pending','ID CIS de verificat în benchmark-ul și versiunea selectate' FROM hardening_profile_rules JOIN hardening_profiles ON hardening_profiles.id=hardening_profile_rules.profile_id WHERE hardening_profiles.code='ubuntu-24-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-001' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-002' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-003' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-004' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-005' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-001' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-002' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-003' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-004' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-FS-001' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-001' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-002' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-003' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-AUD-001' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-FS-002' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-004' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-ACC-001' FROM hardening_profiles WHERE code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_cis_mappings (profile_id,rule_code,status,note) SELECT profile_id,rule_code,'pending','ID CIS de verificat în benchmark-ul și versiunea selectate' FROM hardening_profile_rules JOIN hardening_profiles ON hardening_profiles.id=hardening_profile_rules.profile_id WHERE hardening_profiles.code='ubuntu-22-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-001' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-002' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-003' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-004' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-005' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-001' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-002' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-003' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-004' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-FS-001' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-001' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-002' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-003' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-AUD-001' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-FS-002' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-004' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-ACC-001' FROM hardening_profiles WHERE code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_cis_mappings (profile_id,rule_code,status,note) SELECT profile_id,rule_code,'pending','ID CIS de verificat în benchmark-ul și versiunea selectate' FROM hardening_profile_rules JOIN hardening_profiles ON hardening_profiles.id=hardening_profile_rules.profile_id WHERE hardening_profiles.code='ubuntu-20-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-001' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-002' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-003' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-004' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-SSH-005' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-001' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-002' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-003' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-NET-004' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-FS-001' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-001' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-002' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-003' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-AUD-001' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-FS-002' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-OPS-004' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'LIN-ACC-001' FROM hardening_profiles WHERE code='debian-12-l1';
INSERT IGNORE INTO hardening_cis_mappings (profile_id,rule_code,status,note) SELECT profile_id,rule_code,'pending','ID CIS de verificat în benchmark-ul și versiunea selectate' FROM hardening_profile_rules JOIN hardening_profiles ON hardening_profiles.id=hardening_profile_rules.profile_id WHERE hardening_profiles.code='debian-12-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-SEC-001' FROM hardening_profiles WHERE code='windows-2019-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-SEC-002' FROM hardening_profiles WHERE code='windows-2019-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-SEC-003' FROM hardening_profiles WHERE code='windows-2019-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-OPS-001' FROM hardening_profiles WHERE code='windows-2019-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-AUD-001' FROM hardening_profiles WHERE code='windows-2019-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-OPS-002' FROM hardening_profiles WHERE code='windows-2019-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-ACC-001' FROM hardening_profiles WHERE code='windows-2019-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-SEC-004' FROM hardening_profiles WHERE code='windows-2019-l1';
INSERT IGNORE INTO hardening_cis_mappings (profile_id,rule_code,status,note) SELECT profile_id,rule_code,'pending','ID CIS de verificat în benchmark-ul și versiunea selectate' FROM hardening_profile_rules JOIN hardening_profiles ON hardening_profiles.id=hardening_profile_rules.profile_id WHERE hardening_profiles.code='windows-2019-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-SEC-001' FROM hardening_profiles WHERE code='windows-2022-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-SEC-002' FROM hardening_profiles WHERE code='windows-2022-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-SEC-003' FROM hardening_profiles WHERE code='windows-2022-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-OPS-001' FROM hardening_profiles WHERE code='windows-2022-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-AUD-001' FROM hardening_profiles WHERE code='windows-2022-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-OPS-002' FROM hardening_profiles WHERE code='windows-2022-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-ACC-001' FROM hardening_profiles WHERE code='windows-2022-l1';
INSERT IGNORE INTO hardening_profile_rules (profile_id,rule_code) SELECT id,'WIN-SEC-004' FROM hardening_profiles WHERE code='windows-2022-l1';
INSERT IGNORE INTO hardening_cis_mappings (profile_id,rule_code,status,note) SELECT profile_id,rule_code,'pending','ID CIS de verificat în benchmark-ul și versiunea selectate' FROM hardening_profile_rules JOIN hardening_profiles ON hardening_profiles.id=hardening_profile_rules.profile_id WHERE hardening_profiles.code='windows-2022-l1';
