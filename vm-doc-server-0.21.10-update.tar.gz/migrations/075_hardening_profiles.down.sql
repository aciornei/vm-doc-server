DROP TABLE IF EXISTS vm_hardening_profiles;
DROP TABLE IF EXISTS hardening_cis_mappings;
DROP TABLE IF EXISTS hardening_profile_rules;
DROP TABLE IF EXISTS hardening_rules;
DROP TABLE IF EXISTS hardening_profiles;
