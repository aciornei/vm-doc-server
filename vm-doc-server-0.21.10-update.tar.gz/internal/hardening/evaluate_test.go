package hardening

import "testing"

func TestUnknownIsNotPass(t *testing.T) {
	r := Evaluate([]byte(`{"os":{"id":"ubuntu","version_id":"24.04"}}`), []Rule{{Code: "LIN-SSH-001", CheckKey: "linux.ssh_permit_root", Expected: "no", Enabled: true}})
	if len(r) != 1 || r[0].Status != "unknown" {
		t.Fatalf("%+v", r)
	}
}
func TestEvidenceAndHardening(t *testing.T) {
	raw := []byte(`{"hardening":{"evidence":[{"key":"linux.ssh_permit_root","value":"no","status":"observed","source":"sshd -T"},{"key":"linux.shadow_mode","value":"640","status":"observed"}]}}`)
	r := Evaluate(raw, []Rule{{CheckKey: "linux.ssh_permit_root", Expected: "no", Enabled: true}, {CheckKey: "linux.shadow_mode", Expected: "shadow", Enabled: true}})
	for _, v := range r {
		if v.Status != "pass" {
			t.Fatalf("%+v", v)
		}
	}
}
func TestOSMatchesStrict(t *testing.T) {
	p := Profile{OSMatch: "ubuntu", VersionPrefix: "24.04", Enabled: true}
	if !Matches(p, OSIdentity{ID: "ubuntu", Version: "24.04"}) || Matches(p, OSIdentity{ID: "debian", Version: "12"}) {
		t.Fatal("bad profile matching")
	}
}
