// Package hardening evaluates internal, read-only checks against inventory evidence.
// This is NOT an official CIS benchmark assessment.
package hardening

import (
	"encoding/json"
	"strconv"
	"strings"
)

type Profile struct {
	ID               int64  `json:"id"`
	Code             string `json:"code"`
	Name             string `json:"name"`
	OSMatch          string `json:"os_match"`
	VersionPrefix    string `json:"version_prefix"`
	Level            string `json:"level"`
	Benchmark        string `json:"benchmark"`
	BenchmarkVersion string `json:"benchmark_version"`
	BenchmarkURL     string `json:"benchmark_url"`
	Enabled          bool   `json:"enabled"`
}
type Rule struct {
	Code             string `json:"code"`
	Name             string `json:"name"`
	Category         string `json:"category"`
	CheckKey         string `json:"check_key"`
	Expected         string `json:"expected"`
	Severity         string `json:"severity"`
	Enabled          bool   `json:"enabled"`
	ProfileID        int64  `json:"profile_id"`
	RecommendationID string `json:"recommendation_id"`
	ControlID        string `json:"control_id"`
	MappingStatus    string `json:"mapping_status"`
	MappingNote      string `json:"mapping_note"`
}
type Result struct {
	Rule   `json:",inline"`
	Status string `json:"status"`
	Actual string `json:"actual,omitempty"`
	Source string `json:"source,omitempty"`
	Note   string `json:"note,omitempty"`
}

// OSIdentity is intentionally narrow, so agents with older schemas remain usable.
type OSIdentity struct{ Family, Name, ID, Version string }
type inventory struct {
	OS struct {
		Family    string `json:"family"`
		Name      string `json:"name"`
		ID        string `json:"id"`
		Version   string `json:"version"`
		VersionID string `json:"version_id"`
	} `json:"os"`
	Hardening struct {
		Evidence []struct {
			Key    string `json:"key"`
			Value  string `json:"value"`
			Source string `json:"source"`
			Status string `json:"status"`
		} `json:"evidence"`
	} `json:"hardening"`
	Firewall struct {
		Detected bool `json:"detected"`
		Active   bool `json:"active"`
	} `json:"firewall"`
	NTP struct {
		Synchronized *bool `json:"synchronized"`
	} `json:"ntp"`
	Accounts struct {
		PasswordPolicy struct {
			EnforcementStatus string `json:"enforcement_status"`
		} `json:"password_policy"`
	} `json:"accounts"`
	Services []struct {
		Name   string `json:"name"`
		Active string `json:"active"`
		Status string `json:"status"`
	} `json:"services"`
	Collection struct {
		Collectors map[string]struct {
			Status string `json:"status"`
		} `json:"collectors"`
	} `json:"collection"`
}

func Inspect(raw []byte) OSIdentity {
	var inv inventory
	_ = json.Unmarshal(raw, &inv)
	version := inv.OS.VersionID
	if version == "" {
		version = inv.OS.Version
	}
	return OSIdentity{Family: inv.OS.Family, Name: inv.OS.Name, ID: inv.OS.ID, Version: version}
}
func Matches(p Profile, os OSIdentity) bool {
	if !p.Enabled {
		return false
	}
	hay := strings.ToLower(os.ID + " " + os.Family + " " + os.Name)
	switch p.OSMatch {
	case "ubuntu":
		if !strings.Contains(hay, "ubuntu") {
			return false
		}
	case "debian":
		if !strings.Contains(hay, "debian") || strings.Contains(hay, "ubuntu") {
			return false
		}
	case "windows":
		if !strings.Contains(hay, "windows") {
			return false
		}
	default:
		return false
	}
	ver := strings.ToLower(os.Version + " " + os.Name)
	return strings.Contains(ver, strings.ToLower(p.VersionPrefix))
}
func Pick(profiles []Profile, os OSIdentity) *Profile {
	for _, p := range profiles {
		if Matches(p, os) {
			cp := p
			return &cp
		}
	}
	return nil
}
func Evaluate(raw []byte, rules []Rule) []Result {
	var inv inventory
	_ = json.Unmarshal(raw, &inv)
	evidence := make(map[string]struct{ value, source string })
	for _, e := range inv.Hardening.Evidence {
		if e.Status == "observed" && e.Value != "" {
			evidence[e.Key] = struct{ value, source string }{strings.ToLower(strings.TrimSpace(e.Value)), e.Source}
		}
	}
	out := make([]Result, 0, len(rules))
	for _, r := range rules {
		if !r.Enabled {
			continue
		}
		res := Result{Rule: r, Status: "unknown", Note: "Date insuficiente; nu este considerat conform"}
		if strings.HasPrefix(r.CheckKey, "manual.") {
			res.Note = "Verificare manuală; colectarea automată nu este disponibilă"
			out = append(out, res)
			continue
		}
		e, ok := evidence[r.CheckKey]
		if ok {
			res.Actual = e.value
			res.Source = e.source
		}
		if !ok {
			switch r.CheckKey {
			case "firewall.active":
				if c, exists := inv.Collection.Collectors["firewall"]; exists && (c.Status == "success" || c.Status == "partial") {
					ok = true
					res.Actual = strconv.FormatBool(inv.Firewall.Active)
					res.Source = "firewall"
				}
			case "ntp.synchronized":
				if inv.NTP.Synchronized != nil {
					ok = true
					res.Actual = strconv.FormatBool(*inv.NTP.Synchronized)
					res.Source = "ntp"
				}
			case "accounts.password_policy":
				if s := strings.TrimSpace(inv.Accounts.PasswordPolicy.EnforcementStatus); s != "" {
					ok = true
					res.Actual = strings.ToLower(s)
					res.Source = "accounts.password_policy"
				}
			case "services.auditd":
				for _, svc := range inv.Services {
					if strings.Contains(strings.ToLower(svc.Name), "auditd") {
						ok = true
						res.Actual = strings.ToLower(svc.Active)
						if res.Actual == "" {
							res.Actual = strings.ToLower(svc.Status)
						}
						res.Source = "services"
						break
					}
				}
			}
		}
		if ok {
			expected := strings.ToLower(r.Expected)
			pass := false
			value := strings.ToLower(strings.TrimSpace(res.Actual))
			switch expected {
			case "max4":
				n, err := strconv.Atoi(value)
				pass = err == nil && n > 0 && n <= 4
			case "1or2":
				pass = value == "1" || value == "2"
			case "shadow":
				if mode, err := strconv.ParseUint(value, 8, 32); err == nil {
					pass = (mode&0007) == 0 && (mode&0020) == 0
				}
			case "enforced":
				pass = value == "enforced"
			case "active":
				pass = value == "active" || value == "running" || value == "true"
			default:
				pass = value == expected || (expected == "1" && value == "0x1") || (expected == "0" && (value == "0x0" || value == "0x00000000"))
			}
			if pass {
				res.Status = "pass"
				res.Note = "Evaluare internă pe valoarea observată"
			} else {
				res.Status = "fail"
				res.Note = "Valoare diferită de pragul profilului intern"
			}
		}
		out = append(out, res)
	}
	return out
}
