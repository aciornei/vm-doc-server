package server

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/hardening"
	"vm-doc-server/internal/xlsx"
)

type hardeningCatalog struct {
	Profiles []hardening.Profile `json:"profiles"`
	Rules    []hardening.Rule    `json:"rules"`
	Warning  string              `json:"warning"`
}
type vmHardeningAssessment struct {
	VMID        int64              `json:"vm_id"`
	VMName      string             `json:"vm_name"`
	OSName      string             `json:"os_name"`
	OSVersion   string             `json:"os_version"`
	Profile     *hardening.Profile `json:"profile,omitempty"`
	Assigned    bool               `json:"assigned"`
	Status      string             `json:"status"`
	Passed      int                `json:"passed"`
	Failed      int                `json:"failed"`
	Unknown     int                `json:"unknown"`
	Applicable  int                `json:"applicable"`
	Score       int                `json:"score"`
	EvaluatedAt time.Time          `json:"evaluated_at"`
	Results     []hardening.Result `json:"results"`
}
type hardeningReport struct {
	Items    []vmHardeningAssessment `json:"items"`
	Total    int                     `json:"total"`
	Page     int                     `json:"page"`
	PageSize int                     `json:"page_size"`
	Scope    string                  `json:"scope"`
	Note     string                  `json:"note"`
}

func (a *App) getHardeningCatalog(ctx context.Context) (hardeningCatalog, error) {
	result := hardeningCatalog{Profiles: []hardening.Profile{}, Rules: []hardening.Rule{}, Warning: "Mapările CIS nevalidate sunt marcate pending, fără ID-uri presupuse."}
	rows, err := a.DB.QueryContext(ctx, `SELECT id,code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url,enabled FROM hardening_profiles ORDER BY name`)
	if err != nil {
		return result, err
	}
	for rows.Next() {
		var p hardening.Profile
		if err = rows.Scan(&p.ID, &p.Code, &p.Name, &p.OSMatch, &p.VersionPrefix, &p.Level, &p.Benchmark, &p.BenchmarkVersion, &p.BenchmarkURL, &p.Enabled); err != nil {
			return result, err
		}
		result.Profiles = append(result.Profiles, p)
	}
	if err = rows.Err(); err != nil {
		rows.Close()
		return result, err
	}
	rows.Close()
	rs, err := a.DB.QueryContext(ctx, `SELECT r.code,r.name,r.category,r.check_key,r.expected,r.severity,r.enabled,pr.profile_id,
 COALESCE(cm.recommendation_id,''),COALESCE(cm.control_id,''),COALESCE(cm.status,'pending'),COALESCE(cm.note,'')
 FROM hardening_profile_rules pr JOIN hardening_rules r ON r.code=pr.rule_code
 LEFT JOIN hardening_cis_mappings cm ON cm.profile_id=pr.profile_id AND cm.rule_code=pr.rule_code
 WHERE pr.enabled=1 ORDER BY pr.profile_id,r.category,r.code`)
	if err != nil {
		return result, err
	}
	defer rs.Close()
	for rs.Next() {
		var r hardening.Rule
		if err = rs.Scan(&r.Code, &r.Name, &r.Category, &r.CheckKey, &r.Expected, &r.Severity, &r.Enabled, &r.ProfileID, &r.RecommendationID, &r.ControlID, &r.MappingStatus, &r.MappingNote); err != nil {
			return result, err
		}
		result.Rules = append(result.Rules, r)
	}
	return result, rs.Err()
}
func (a *App) hardeningCatalog(w http.ResponseWriter, r *http.Request) {
	v, err := a.getHardeningCatalog(r.Context())
	respond(w, v, err)
}

var hardeningReferenceID = regexp.MustCompile(`^\d+(\.\d+)*$`)

func (a *App) updateHardeningMapping(w http.ResponseWriter, r *http.Request) {
	var b struct {
		ProfileID        int64  `json:"profile_id"`
		RuleCode         string `json:"rule_code"`
		RecommendationID string `json:"recommendation_id"`
		ControlID        string `json:"control_id"`
		Note             string `json:"note"`
		Status           string `json:"status"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 12<<10)).Decode(&b); err != nil {
		badRequest(w, err)
		return
	}
	b.RuleCode = strings.TrimSpace(b.RuleCode)
	b.RecommendationID = strings.TrimSpace(b.RecommendationID)
	b.ControlID = strings.TrimSpace(b.ControlID)
	b.Note = strings.TrimSpace(b.Note)
	if b.ProfileID <= 0 || b.RuleCode == "" || len(b.Note) > 1024 || len(b.RuleCode) > 64 || len(b.RecommendationID) > 50 || len(b.ControlID) > 50 {
		badRequest(w, errors.New("invalid mapping"))
		return
	}
	if b.RecommendationID != "" && !hardeningReferenceID.MatchString(b.RecommendationID) {
		badRequest(w, errors.New("CIS recommendation ID must be numeric dotted notation"))
		return
	}
	if b.ControlID != "" && !hardeningReferenceID.MatchString(b.ControlID) {
		badRequest(w, errors.New("CIS Controls reference must be numeric dotted notation"))
		return
	}
	// 'reviewed' indicates internal review by an administrator; it is NOT a CIS certification.
	if b.Status != "pending" && b.Status != "reviewed" {
		badRequest(w, errors.New("status must be pending or reviewed"))
		return
	}
	if b.Status == "reviewed" && (b.RecommendationID == "" || b.Note == "") {
		badRequest(w, errors.New("reviewed mappings require recommendation_id and a verification note"))
		return
	}
	res, err := a.DB.ExecContext(r.Context(), `UPDATE hardening_cis_mappings SET recommendation_id=NULLIF(?,''),control_id=NULLIF(?,''),note=?,status=? WHERE profile_id=? AND rule_code=?`, b.RecommendationID, b.ControlID, b.Note, b.Status, b.ProfileID, b.RuleCode)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "hardening.mapping.update", "hardening_mapping", fmt.Sprintf("%d:%s", b.ProfileID, b.RuleCode), "success", map[string]any{"status": b.Status, "recommendation_id": b.RecommendationID, "control_id": b.ControlID})
	jsonResponse(w, 200, map[string]any{"ok": true})
}
func (a *App) updateHardeningRule(w http.ResponseWriter, r *http.Request) {
	code := r.PathValue("code")
	if len(code) > 64 || code == "" {
		badRequest(w, errors.New("invalid rule code"))
		return
	}
	var b struct {
		Enabled  bool   `json:"enabled"`
		Severity string `json:"severity"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&b); err != nil {
		badRequest(w, err)
		return
	}
	if b.Severity != "low" && b.Severity != "medium" && b.Severity != "high" {
		badRequest(w, errors.New("invalid severity"))
		return
	}
	result, err := a.DB.ExecContext(r.Context(), `UPDATE hardening_rules SET enabled=?,severity=? WHERE code=?`, b.Enabled, b.Severity, code)
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, 200, map[string]any{"ok": true})
}
func (a *App) updateHardeningProfile(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		badRequest(w, errors.New("invalid profile"))
		return
	}
	var b struct {
		Enabled bool `json:"enabled"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&b); err != nil {
		badRequest(w, err)
		return
	}
	res, err := a.DB.ExecContext(r.Context(), `UPDATE hardening_profiles SET enabled=? WHERE id=?`, b.Enabled, id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, 200, map[string]any{"ok": true})
}
func (a *App) assignHardeningProfile(w http.ResponseWriter, r *http.Request) {
	vmID, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || vmID <= 0 {
		badRequest(w, errors.New("invalid VM id"))
		return
	}
	var b struct {
		ProfileID int64 `json:"profile_id"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&b); err != nil {
		badRequest(w, err)
		return
	}
	if b.ProfileID == 0 {
		_, err = a.DB.ExecContext(r.Context(), `DELETE FROM vm_hardening_profiles WHERE vm_id=?`, vmID)
		respond(w, map[string]any{"ok": true}, err)
		return
	}
	var raw []byte
	err = a.DB.QueryRowContext(r.Context(), `SELECT COALESCE(i.raw_json,'') FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.id=?`, vmID).Scan(&raw)
	if err != nil {
		respond(w, nil, err)
		return
	}
	cat, err := a.getHardeningCatalog(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	var profile *hardening.Profile
	for _, p := range cat.Profiles {
		if p.ID == b.ProfileID && hardening.Matches(p, hardening.Inspect(raw)) {
			p0 := p
			profile = &p0
			break
		}
	}
	if profile == nil {
		badRequest(w, errors.New("selected profile is not compatible with the VM OS/version or is disabled"))
		return
	}
	_, err = a.DB.ExecContext(r.Context(), `INSERT INTO vm_hardening_profiles (vm_id,profile_id) VALUES (?,?) ON DUPLICATE KEY UPDATE profile_id=VALUES(profile_id)`, vmID, profile.ID)
	respond(w, map[string]any{"ok": true}, err)
}
func vmHardeningEval(vmID int64, name string, raw []byte, cat hardeningCatalog, assignedID sql.NullInt64) vmHardeningAssessment {
	os := hardening.Inspect(raw)
	v := vmHardeningAssessment{VMID: vmID, VMName: name, OSName: os.Name, OSVersion: os.Version, Status: "no_profile", Results: []hardening.Result{}, EvaluatedAt: time.Now().UTC()}
	var matched *hardening.Profile
	if assignedID.Valid {
		for _, p := range cat.Profiles {
			if p.ID == assignedID.Int64 && hardening.Matches(p, os) {
				cp := p
				matched = &cp
				v.Assigned = true
				break
			}
		}
	}
	if matched == nil {
		matched = hardening.Pick(cat.Profiles, os)
	}
	if matched == nil {
		return v
	}
	v.Profile = matched
	v.Status = "evaluated"
	rules := []hardening.Rule{}
	for _, r := range cat.Rules {
		if r.ProfileID == matched.ID && r.Enabled {
			rules = append(rules, r)
		}
	}
	v.Results = hardening.Evaluate(raw, rules)
	for _, x := range v.Results {
		switch x.Status {
		case "pass":
			v.Passed++
		case "fail":
			v.Failed++
		default:
			v.Unknown++
		}
	}
	v.Applicable = v.Passed + v.Failed + v.Unknown
	if v.Applicable > 0 {
		v.Score = int(float64(v.Passed)*100/float64(v.Applicable) + 0.5)
	}
	return v
}
func (a *App) hardeningVM(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		badRequest(w, errors.New("invalid VM id"))
		return
	}
	cat, err := a.getHardeningCatalog(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	var name string
	var raw []byte
	var assigned sql.NullInt64
	err = a.DB.QueryRowContext(r.Context(), `SELECT vm.name,COALESCE(i.raw_json,''),hp.profile_id FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id LEFT JOIN vm_hardening_profiles hp ON hp.vm_id=vm.id WHERE vm.id=?`, id).Scan(&name, &raw, &assigned)
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, 200, vmHardeningEval(id, name, raw, cat, assigned))
}
func (a *App) hardeningRows(ctx context.Context, vmID int64, cat hardeningCatalog, limit, offset int) ([]vmHardeningAssessment, error) {
	query := `SELECT vm.id,vm.name,COALESCE(i.raw_json,''),hp.profile_id FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id LEFT JOIN vm_hardening_profiles hp ON hp.vm_id=vm.id WHERE vm.retired=0`
	args := []any{}
	if vmID > 0 {
		query += ` AND vm.id=?`
		args = append(args, vmID)
	}
	query += ` ORDER BY vm.name,vm.id`
	if limit > 0 {
		query += ` LIMIT ? OFFSET ?`
		args = append(args, limit, offset)
	}
	rows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	all := []vmHardeningAssessment{}
	for rows.Next() {
		var id int64
		var name string
		var raw []byte
		var assigned sql.NullInt64
		if err = rows.Scan(&id, &name, &raw, &assigned); err != nil {
			return nil, err
		}
		all = append(all, vmHardeningEval(id, name, raw, cat, assigned))
	}
	return all, rows.Err()
}
func (a *App) hardeningReport(w http.ResponseWriter, r *http.Request) {
	cat, err := a.getHardeningCatalog(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	vmID, _ := strconv.ParseInt(r.URL.Query().Get("vm_id"), 10, 64)
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	size, _ := strconv.Atoi(r.URL.Query().Get("page_size"))
	if size < 1 || size > 100 {
		size = 25
	}
	countQuery := `SELECT COUNT(*) FROM virtual_machines WHERE retired=0`
	args := []any{}
	if vmID > 0 {
		countQuery += ` AND id=?`
		args = append(args, vmID)
	}
	var total int
	if err = a.DB.QueryRowContext(r.Context(), countQuery, args...).Scan(&total); err != nil {
		respond(w, nil, err)
		return
	}
	offset := (page - 1) * size
	if offset > total {
		offset = total
	}
	items, err := a.hardeningRows(r.Context(), vmID, cat, size, offset)
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, 200, hardeningReport{Items: items, Total: total, Page: page, PageSize: size, Scope: "pagina", Note: "Scor intern, nu certificare CIS. Neverificat reduce scorul; evaluare pe ultima colectare."})
}
func (a *App) hardeningExport(w http.ResponseWriter, r *http.Request) {
	cat, err := a.getHardeningCatalog(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	vmID, _ := strconv.ParseInt(r.URL.Query().Get("vm_id"), 10, 64)
	all, err := a.hardeningRows(r.Context(), vmID, cat, 0, 0)
	if err != nil {
		respond(w, nil, err)
		return
	}
	cells := func(parts ...string) []xlsx.Cell {
		out := make([]xlsx.Cell, len(parts))
		for i, p := range parts {
			out[i] = xlsx.Text(p)
		}
		return out
	}
	rows := [][]xlsx.Cell{cells("VM", "Profil", "Benchmark", "Versiune CIS", "Regulă VM-DOC", "Categorie", "Rezultat", "Observat", "Așteptat", "Sursă", "Recomandare CIS", "CIS Controls", "Mapare")}
	for _, vm := range all {
		if vm.Profile == nil {
			rows = append(rows, cells(vm.VMName, "Fără profil"))
			continue
		}
		for _, v := range vm.Results {
			rows = append(rows, cells(vm.VMName, vm.Profile.Name, vm.Profile.Benchmark, vm.Profile.BenchmarkVersion, v.Code, v.Category, v.Status, v.Actual, v.Expected, v.Source, v.RecommendationID, v.ControlID, v.MappingStatus))
		}
	}
	if err := writeXLSXResponse(w, "Hardening", "vm-doc-hardening", rows); err != nil && a.Logger != nil {
		a.Logger.Error("hardening Excel export", "error", err)
	}
}
func hardeningSummaryText(v vmHardeningAssessment) string {
	return fmt.Sprintf("%d/%d conforme", v.Passed, v.Applicable)
}
