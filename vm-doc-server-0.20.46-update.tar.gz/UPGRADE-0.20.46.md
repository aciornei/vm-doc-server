# Upgrade VM-DOC Server 0.20.45 -> 0.20.46

Hotfix fără migrare DB și fără modificare de agent.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.45 \
      /usr/local/src/vm-doc-server-0.20.46

tar -xzf vm-doc-server-0.20.46-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.46

cd /usr/local/src/vm-doc-server-0.20.46
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După înlocuirea binarului, restartează serviciul. Nu există migrare nouă.
