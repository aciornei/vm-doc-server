package buildinfo

var (
	Version = "0.19.5-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
