# Upgrade vm-doc-server 0.19.4 → 0.19.5

0.19.5 este un release de UI/UX pentru zona VM. Nu modifică schema bazei de date și nu necesită upgrade de agent sau collector.

## Noutăți

- **VM-uri** are două pagini sus: `Inventar VM` și `Surse & sincronizări`.
- Sursele vCenter și ultimele sincronizări nu mai încarcă pagina principală cu VM-uri.
- Filtrele VM sunt așezate pe un layout aerisit și afișează filtrele active.
- Fișa unei VM este grupată în zone principale: Rezumat, Configurare, Aplicație, Inventar, Backup, Monitorizare, Documentație și Modificări.
- Zonele Configurare, Aplicație și Inventar au subtabs pentru secțiunile existente.
- Hash-urile existente (`#vms/<id>/services`, `docker`, `web`, `history` etc.) rămân valide.
- Listbox-urile searchable au dropdown portal, direcție sus/jos blocată cât timp lista este deschisă, săgeată CSS stabilă și padding rezervat.
- Selecturile native rămase folosesc același chevron vizual.
- Paddingurile din fișa VM și `VM → Monitorizare` sunt mărite.

## Instalare

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.4 vm-doc-server-0.19.5
tar -xzf /home/andrei.ciornei/vm-doc-server-0.19.5-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.5
cd /usr/local/src/vm-doc-server-0.19.5
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

După upgrade, folosiți `Ctrl+F5` pentru a încărca CSS/JS 0.19.5.
