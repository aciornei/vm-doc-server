# Upgrade VM-DOC Server 0.20.76 → 0.20.77

0.20.77 este un patch exclusiv de UI. Tabelele FortiGate late nu mai au scrollbar orizontal propriu; lățimea lor extinde pagina, iar scroll-ul stânga-dreapta este cel al browserului/paginii, jos.

Nu există migrare DB și nu este necesar un nou Sync FortiGate. Agentul rămâne 1.7.12.

```bash
systemctl stop vm-doc-server
cp -a /usr/local/src/vm-doc-server-0.20.76 /usr/local/src/vm-doc-server-0.20.77
tar -xzf vm-doc-server-0.20.77-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.77
cd /usr/local/src/vm-doc-server-0.20.77
# build/deploy folosind procedura curentă din mediul vostru
systemctl start vm-doc-server
```
