VM-DOC Server 0.21.58 — CORECTION Docker bridge / SQL cleanup

Surse de bază: 0.21.57. Folosiți EITHER update TAR OR patch; NU ambele.
Pentru problema din captura curentă folosiți PREVIEW-docker-bridge-0.21.58.sql,
apoi, după backup și staging, CLEANUP-docker-bridge-0.21.58.sql (manual).
Nu rulați scripturile cumulative dacă vreți să eliminați doar bridge + guard.
See UPGRADE-0.21.58.md. Agent 1.7.18 unchanged.
