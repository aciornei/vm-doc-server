package agents

import (
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/config"
	"vm-doc-server/internal/domain"
)

func testService() Service {
	return Service{Config: config.CollectorConfig{
		LeaseDuration:             config.Duration(2 * time.Minute),
		DefaultCollectionInterval: config.Duration(15 * time.Minute),
		DefaultRequestTimeout:     config.Duration(45 * time.Second),
		DefaultOfflineAfter:       config.Duration(45 * time.Minute),
		RefreshBeforeCollect:      true,
	}}
}

func TestNormalizeRejectsAgentURLWithPath(t *testing.T) {
	s := testService()
	in := Input{Name: "vm1", BaseURL: "https://vm1:9078/unexpected", Token: "secret"}
	if err := s.normalizeAndValidate(&in, true); err == nil {
		t.Fatal("agent URL with a path unexpectedly accepted")
	}
}

func TestNormalizeRejectsTimeoutOutsideLease(t *testing.T) {
	s := testService()
	in := Input{Name: "vm1", BaseURL: "https://vm1:9078", Token: "secret", RequestTimeoutSeconds: 60}
	err := s.normalizeAndValidate(&in, true)
	if err == nil || !strings.Contains(err.Error(), "lease_duration") {
		t.Fatalf("got error %v, want lease duration validation", err)
	}
}

func TestEffectiveManagementURLReplacesStaleLiteralEndpoint(t *testing.T) {
	got := effectiveManagementURL("http://10.20.30.20:9078", "10.20.30.40")
	if got != "http://10.20.30.40:9078" {
		t.Fatalf("effective URL = %q", got)
	}
	got = effectiveManagementURL("https://agent01.example.test:9078", "10.20.30.40")
	if got != "https://agent01.example.test:9078" {
		t.Fatalf("DNS endpoint should not be rewritten, got %q", got)
	}
}

func TestClassifyAgentType(t *testing.T) {
	cases := []struct {
		name  string
		agent domain.Agent
		want  string
	}{
		{"linux amd64", domain.Agent{OSFamily: "linux", OSName: "Ubuntu", Architecture: "x86_64", AgentVersion: "1.7.15"}, "linux-amd64"},
		{"linux 386", domain.Agent{OSFamily: "linux", OSName: "Debian GNU/Linux", Architecture: "i686", AgentVersion: "1.7.15"}, "linux-386"},
		{"windows amd64", domain.Agent{OSFamily: "windows", OSName: "Microsoft Windows Server 2022", Architecture: "amd64", AgentVersion: "1.7.15"}, "windows-amd64"},
		{"windows 386", domain.Agent{OSFamily: "windows", OSName: "Microsoft Windows", Architecture: "386", AgentVersion: "1.7.15"}, "windows-386"},
		{"windows xp", domain.Agent{OSFamily: "windows", OSName: "Microsoft Windows XP", Architecture: "386", AgentRuntimeName: "vm-doc-agent-xp", AgentVersion: "1.0.1"}, "windows-xp"},
		{"windows legacy", domain.Agent{OSFamily: "windows", OSName: "Microsoft Windows Server 2008", Architecture: "amd64", AgentRuntimeName: "vm-doc-agent-legacy", AgentVersion: "1.0.2"}, "windows-legacy"},
		{"sles9 legacy", domain.Agent{OSFamily: "linux", OSName: "SUSE Linux Enterprise Server", OSVersion: "9 SP4", Architecture: "x86_64", AgentRuntimeName: "vm-doc-agent-legacy", AgentVersion: "1.0.0"}, "sles9-legacy"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			tc.agent.Architecture = normalizeAgentArchitecture(tc.agent.Architecture)
			if got := classifyAgentType(tc.agent); got != tc.want {
				t.Fatalf("classifyAgentType() = %q, want %q", got, tc.want)
			}
		})
	}
}
