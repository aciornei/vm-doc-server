# Upgrade VM-DOC Server 0.20.92 → 0.20.93

1. Oprește `vm-doc-server`.
2. Aplică update-ul peste 0.20.92.
3. Recompilează/repornește serviciul conform procedurii curente.
4. În browser fă `Ctrl+F5`.

Nu există migrare DB.

După upgrade, **Agenți → Listare agenți** are coloana și filtrul **Tip agent**. Tipul se derivă din inventarul curent; dacă un agent apare `Necunoscut`, rulează o colectare nouă (recomandat agent 1.7.15).
