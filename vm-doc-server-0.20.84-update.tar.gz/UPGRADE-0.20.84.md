# Upgrade VM-DOC Server 0.20.83 → 0.20.84

0.20.84 corectează detectarea mediului pentru regula **Outline numai pentru PROD**. Nu există migrare DB și nu este necesar update de agent.

## Ce se corectează

- mediul este citit prioritar din **Date operaționale → Mediu**, prin `vm_operational_nomenclatures` + `nomenclature_items`;
- valoarea text legacy `vm_operational_metadata.environment` este folosită doar ca fallback;
- `PROD`, `Producție`, `Productie` și `Production` sunt tratate ca producție, identic cu restul UI-ului;
- VM → Documentație, bulk publish, Rezumat și raportul Outline folosesc aceeași politică.

## Upgrade offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.83 vm-doc-server-0.20.84
tar -xzf /cale/vm-doc-server-0.20.84-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.84
cd /usr/local/src/vm-doc-server-0.20.84

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi înlocuiește binarul, repornește `vm-doc-server` și fă **Ctrl+F5**.

## Verificare

1. Deschide un VM care în **Date operaționale → Mediu** este `Producție`/`PROD`.
2. În Rezumat trebuie să apară Outline `Da` (dacă integrarea este activă și VM-ul nu este exclus explicit).
3. În **Documentație** trebuie să apară butonul **Trimite în Outline**.
4. TEST/DEV/fără mediu trebuie să rămână fără buton.
5. În **Documente → Publică în Outline → VM-uri**, VM-ul de producție trebuie să fie candidat la publicare, nu în lista săritelor.
