# VM-DOC Server 0.21.63 — Resource pool tree și Audit

Bază: **0.21.62** · 2026-10-21 · Agent 1.7.18 neschimbat

## Interfață
- Dialogul **VM-uri → Surse & sincronizări → Pool-uri** are spațiere, antet, sumar și acțiuni separate, scroll vertical interior numai pentru arbore.
- Arborele respectă legăturile reale părinte/copil returnate de vCenter prin `GET /api/vcenter/resource-pool/{moid}` (`resource_pools`: copii). Identitatea este MoRef, nu numele pool-ului.
- Părintele este pliabil; bifarea/debifarea unui părinte aplică aceeași selecție tuturor descendenților. Ulterior, un copil se poate configura separat.
- Coloanele VM-uri și ON arată numerele de **VM-uri direct alocate pool-ului**, nu suma descendenților; astfel nu apar dublări.
- Mesajul din popup indică numărul VM-urilor excluse și pornite, cu confirmare la salvarea unei excluderi cu POWERED_ON.

## Audit
- `vcenter.pool.excluded` și `vcenter.pool.included` sunt generate numai la schimbarea selecției pentru un pool. Au actorul real și detalii `vm_count`, `powered_on_count`, numele/MoRef-ul pool-ului.
- `vcenter.pool.excluded_count_change` apare când inventarierea vCenter constată o schimbare a numărului de VM-uri într-un pool deja exclus.
- `vcenter.pool.vm_powered_on` este auditat la sincronizarea cu vCenter pentru **fiecare VM POWERED_ON dintr-un pool debifat**, inclusiv VM-uri care nu au fost importate niciodată. Pentru VM-urile existente auditul este asociat fișei VM; pentru cele noi se păstrează MoRef și nume.
- Fără evenimente repetate la fiecare sync: tabelul `vcenter_pool_vm_audit_state` memorează ultima stare și permite o nouă alertă doar la tranziția către POWERED_ON/exclus sau schimbarea pool-ului exclus.
- Evenimentele sunt în tabela și pagina **Audit** deja existente; filtrul de arie „Operațiuni” include noile acțiuni `vcenter.pool.*`.

## Tehnic
- Migrare automată **080**: `vcenter_resource_pools.parent_moid` + `vcenter_pool_vm_audit_state`. Nu modifică/șterge fișe, documente sau selecții.
- `internal/vcenter/{pools_client.go,pools.go,pool_audit.go,service.go}`, `internal/audit/audit.go`, `internal/server/server.go`, UI JS/CSS, OpenAPI și documentație.
- Nu modifică agentul și nu schimbă politica Outline / Vault.
- Necesită test de integrare pe VCSA 8.0.3, MariaDB reală și build Go integral cu `vendor/` în mediul offline.
