# Upgrade VM-DOC Server 0.21.62 → 0.21.63

1. Backup MariaDB, cod/configurație, binar și arhiva sursei 0.21.62.
2. Test în staging. Aplică `tar -xzf vm-doc-server-0.21.63-update.tar.gz` la rădăcina surselor **0.21.62**; alternativ, `patch -p1 < vm-doc-server-0.21.62-to-0.21.63.patch`.
3. Folosește `vendor/` din mediul offline; execută `go test ./...` și `make build`.
4. Oprește serviciul, înlocuiește binarul, pornește-l. Migrarea aditivă `080_vcenter_pool_tree_audit.up.sql` se aplică automat.
5. VM-uri → Surse & sincronizări → Pool-uri → Descoperă / actualizează; confirmă arborele, numărătorii per pool direct, salvarea pe ramuri și popupul responsive.
6. Debifează un pool cu VM-uri POWERED_OFF și unul cu POWERED_ON. Confirmă în **Audit** evenimentul `Pool exclus de la import` cu contor și, după Sync, `VM pornită în pool exclus` pentru VM-urile active.
7. Repetă Sync fără schimbări: nu trebuie să apară avertizări duplicate. Oprește/repornește o VM în pool exclus și testează re-alertarea; mută o VM între pool-uri și verifică istoricul.
8. Rollback: restaurează binarul/sursele 0.21.62; păstrează migrarea 080 (coloanele sunt aditive). DOWN numai în staging sau prin procedură controlată după backup.

**Limitări:** verificarea locală nu înlocuiește testul real al permisiunii `System.Read` pe `/api/vcenter/resource-pool/{moid}`, al răspunsurilor ierarhice, al tranzacțiilor și auditului pe MariaDB. VMs excluse noi nu sunt importate; evenimentul le identifică prin MoRef.
