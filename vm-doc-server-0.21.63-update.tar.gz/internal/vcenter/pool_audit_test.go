package vcenter

import "testing"

func TestExcludedPoolPowerOnAuditTransitions(t *testing.T) {
	for _, tc := range []struct {
		name                string
		old                 poolVMState
		found, excluded, on bool
		pool                string
		want                bool
	}{
		{"new powered-on excluded", poolVMState{}, false, true, true, "resgroup-1", true},
		{"repeat must not create noise", poolVMState{PoolMoID: "resgroup-1", Excluded: true, PoweredOn: true}, true, true, true, "resgroup-1", false},
		{"power transition off to on", poolVMState{PoolMoID: "resgroup-1", Excluded: true, PoweredOn: false}, true, true, true, "resgroup-1", true},
		{"pool moved", poolVMState{PoolMoID: "resgroup-1", Excluded: true, PoweredOn: true}, true, true, true, "resgroup-2", true},
		{"pool reexcluded", poolVMState{PoolMoID: "resgroup-1", Excluded: false, PoweredOn: true}, true, true, true, "resgroup-1", true},
		{"not powered", poolVMState{}, false, true, false, "resgroup-1", false},
		{"included", poolVMState{}, false, false, true, "resgroup-1", false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			if got := shouldAuditExcludedPowerOn(tc.old, tc.found, tc.excluded, tc.on, tc.pool); got != tc.want {
				t.Fatalf("got %v, want %v", got, tc.want)
			}
		})
	}
}
