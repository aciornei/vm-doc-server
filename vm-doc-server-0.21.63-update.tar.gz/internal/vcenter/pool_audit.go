package vcenter

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strconv"
	"time"
)

type poolAuditCount struct {
	Name                    string
	Include                 bool
	VMCount, PoweredOnCount int
}

func readPoolAuditCounts(ctx context.Context, tx *sql.Tx, sourceID int64) (map[string]poolAuditCount, error) {
	rows, err := tx.QueryContext(ctx, `SELECT moid,name,include_in_docs,vm_count,powered_on_count FROM vcenter_resource_pools WHERE vcenter_source_id=?`, sourceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := map[string]poolAuditCount{}
	for rows.Next() {
		var key string
		var c poolAuditCount
		if err := rows.Scan(&key, &c.Name, &c.Include, &c.VMCount, &c.PoweredOnCount); err != nil {
			return nil, err
		}
		result[key] = c
	}
	return result, rows.Err()
}

// writeVCenterAudit is transactional: a failed vCenter sync must not leave audit events.
func writeVCenterAudit(ctx context.Context, tx *sql.Tx, action, resourceType, resourceID string, details any) error {
	return writeVCenterAuditActor(ctx, tx, action, resourceType, resourceID, 0, "vcenter-sync", details)
}

func writeVCenterAuditActor(ctx context.Context, tx *sql.Tx, action, resourceType, resourceID string, userID int64, actor string, details any) error {
	b, err := json.Marshal(details)
	if err != nil {
		return err
	}
	var actorID any
	if userID > 0 {
		actorID = userID
	}
	_, err = tx.ExecContext(ctx, `INSERT INTO audit_events(occurred_at,source,actor_user_id,actor_username,action,resource_type,resource_id,outcome,request_id,ip_address,user_agent,details_json) VALUES(UTC_TIMESTAMP(6),'vcenter',?,?,?,?,?,'success','','','',?)`, actorID, actor, action, resourceType, resourceID, string(b))
	return err
}

type poolVMState struct {
	PoolMoID  string
	Excluded  bool
	PoweredOn bool
}

// auditVCenterPoolVMStates emits one warning upon entering an excluded/powered-on
// condition, a power-off -> power-on transition, or a move into another excluded pool.
// Repeated scheduler syncs do not flood audit_events. Unimported VMs are also covered
// using their vCenter MoRef, while existing VM IDs link into the VM-specific audit.
func auditVCenterPoolVMStates(ctx context.Context, tx *sql.Tx, sourceID int64, remote []RemoteVM, pools []RemotePool, include map[string]bool, knownVMIDs map[string]int64, at time.Time) error {
	poolNames := map[string]string{}
	for _, pool := range pools {
		poolNames[pool.MoID] = pool.Name
	}

	rows, err := tx.QueryContext(ctx, `SELECT vcenter_moid,pool_moid,excluded,powered_on FROM vcenter_pool_vm_audit_state WHERE vcenter_source_id=?`, sourceID)
	if err != nil {
		return err
	}
	before := make(map[string]poolVMState)
	for rows.Next() {
		var key string
		var s poolVMState
		if err = rows.Scan(&key, &s.PoolMoID, &s.Excluded, &s.PoweredOn); err != nil {
			rows.Close()
			return err
		}
		before[key] = s
	}
	if err = rows.Err(); err != nil {
		rows.Close()
		return err
	}
	rows.Close()
	for _, vm := range remote {
		excluded, known := include[vm.ResourcePoolID]
		excluded = known && !excluded
		powered := vm.PowerState == "POWERED_ON"
		old, had := before[vm.MoID]
		// Log only newly observed risky states, including reactivation within the same excluded pool.
		if shouldAuditExcludedPowerOn(old, had, excluded, powered, vm.ResourcePoolID) {
			resourceType, resourceID := "vcenter_pool_vm", vm.MoID
			details := map[string]any{"vcenter_source_id": sourceID, "vcenter_moid": vm.MoID, "vm_name": vm.Name, "pool_moid": vm.ResourcePoolID, "pool_name": poolNames[vm.ResourcePoolID], "power_state": vm.PowerState, "excluded_from_import": true}
			if id := knownVMIDs[vm.MoID]; id > 0 {
				resourceType = "virtual_machine"
				resourceID = strconv.FormatInt(id, 10)
				details["vm_id"] = id
			}
			if err := writeVCenterAudit(ctx, tx, "vcenter.pool.vm_powered_on", resourceType, resourceID, details); err != nil {
				return fmt.Errorf("audit excluded powered-on VM %s: %w", vm.MoID, err)
			}
		}
		_, err = tx.ExecContext(ctx, `INSERT INTO vcenter_pool_vm_audit_state(vcenter_source_id,vcenter_moid,pool_moid,vm_name,excluded,powered_on,observed_at) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE pool_moid=VALUES(pool_moid),vm_name=VALUES(vm_name),excluded=VALUES(excluded),powered_on=VALUES(powered_on),observed_at=VALUES(observed_at)`, sourceID, vm.MoID, vm.ResourcePoolID, vm.Name, excluded, powered, at)
		if err != nil {
			return err
		}
	}
	return nil
}

// shouldAuditExcludedPowerOn is intentionally independent of the sync DB layer,
// so repeat-warning behavior can be regression tested offline.
func shouldAuditExcludedPowerOn(previous poolVMState, found, excluded, powered bool, poolMoID string) bool {
	return excluded && powered && (!found || !previous.Excluded || !previous.PoweredOn || previous.PoolMoID != poolMoID)
}
