package vcenter

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"
)

type ResourcePool struct {
	MoID           string `json:"resource_pool_moid"`
	Name           string `json:"name"`
	ParentMoID     string `json:"parent_resource_pool_moid,omitempty"`
	Include        bool   `json:"include_in_docs"`
	VMCount        int    `json:"vm_count"`
	PoweredOnCount int    `json:"powered_on_count"`
	Present        bool   `json:"present_in_vcenter"`
}
type PoolChoice struct {
	MoID    string `json:"resource_pool_moid"`
	Include bool   `json:"include_in_docs"`
}
type PoolSelectionInput struct {
	Pools []PoolChoice `json:"pools"`
}

func (s *Service) ListPools(ctx context.Context, sourceID int64) ([]ResourcePool, error) {
	if _, err := s.GetSource(ctx, sourceID); err != nil {
		return nil, err
	}
	rows, err := s.DB.QueryContext(ctx, `SELECT moid,name,parent_moid,include_in_docs,vm_count,powered_on_count,present_in_vcenter FROM vcenter_resource_pools WHERE vcenter_source_id=? ORDER BY name,moid`, sourceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]ResourcePool, 0)
	for rows.Next() {
		var x ResourcePool
		if err := rows.Scan(&x.MoID, &x.Name, &x.ParentMoID, &x.Include, &x.VMCount, &x.PoweredOnCount, &x.Present); err != nil {
			return nil, err
		}
		out = append(out, x)
	}
	return out, rows.Err()
}
func (s *Service) poolSelections(ctx context.Context, sourceID int64) (map[string]bool, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT moid,include_in_docs FROM vcenter_resource_pools WHERE vcenter_source_id=?`, sourceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	res := map[string]bool{}
	for rows.Next() {
		var moid string
		var allow bool
		if err := rows.Scan(&moid, &allow); err != nil {
			return nil, err
		}
		res[moid] = allow
	}
	return res, rows.Err()
}
func writePoolObservations(ctx context.Context, tx *sql.Tx, sourceID int64, pools []RemotePool, at time.Time) error {
	previous, err := readPoolAuditCounts(ctx, tx, sourceID)
	if err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE vcenter_resource_pools SET present_in_vcenter=0 WHERE vcenter_source_id=?`, sourceID); err != nil {
		return err
	}
	for _, pool := range pools {
		if _, err := tx.ExecContext(ctx, `INSERT INTO vcenter_resource_pools (vcenter_source_id,moid,name,parent_moid,vm_count,powered_on_count,last_seen_at,present_in_vcenter) VALUES(?,?,?,?,?,?,?,1) ON DUPLICATE KEY UPDATE name=VALUES(name),parent_moid=VALUES(parent_moid),vm_count=VALUES(vm_count),powered_on_count=VALUES(powered_on_count),last_seen_at=VALUES(last_seen_at),present_in_vcenter=1`, sourceID, pool.MoID, pool.Name, pool.ParentMoID, pool.VMCount, pool.PoweredOnCount, at); err != nil {
			return err
		}
		if old, ok := previous[pool.MoID]; ok && !old.Include && (old.VMCount != pool.VMCount || old.PoweredOnCount != pool.PoweredOnCount) {
			if err := writeVCenterAudit(ctx, tx, "vcenter.pool.excluded_count_change", "vcenter_resource_pool", pool.MoID, map[string]any{
				"vcenter_source_id": sourceID, "pool_name": pool.Name, "vm_count_before": old.VMCount,
				"vm_count": pool.VMCount, "powered_on_before": old.PoweredOnCount, "powered_on_count": pool.PoweredOnCount,
			}); err != nil {
				return err
			}
		}
	}
	return nil
}
func (s *Service) VMExcluded(ctx context.Context, vmID int64) (bool, error) {
	var excluded bool
	err := s.DB.QueryRowContext(ctx, `SELECT excluded_by_vcenter_pool FROM virtual_machines WHERE id=?`, vmID).Scan(&excluded)
	return excluded, err
}

// ScanPools is a read-only vCenter discovery followed by persisting pool counts;
// no VM is created, removed or retired by this operation.
func (s *Service) ScanPools(ctx context.Context, sourceID int64) ([]ResourcePool, error) {
	record, err := s.GetSourceRecord(ctx, sourceID)
	if err != nil {
		return nil, err
	}
	secret, err := s.decryptPassword(record)
	if err != nil {
		return nil, err
	}
	client, err := NewClient(record.VCenterSource, secret, s.Config.RequestTimeout.Value(), s.Config.DetailWorkers)
	if err != nil {
		return nil, err
	}
	pools, placement, err := client.PoolDiscovery(ctx)
	if err != nil {
		return nil, err
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	if err := writePoolObservations(ctx, tx, sourceID, pools, time.Now().UTC()); err != nil {
		return nil, err
	}
	for vmID, poolID := range placement {
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET vcenter_resource_pool_moid=? WHERE vcenter_source_id=? AND vcenter_moid=?`, poolID, sourceID, vmID); err != nil {
			return nil, err
		}
	}
	if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines vm JOIN vcenter_resource_pools p ON p.vcenter_source_id=vm.vcenter_source_id AND p.moid=vm.vcenter_resource_pool_moid SET vm.excluded_by_vcenter_pool=IF(p.include_in_docs=1,0,1) WHERE vm.vcenter_source_id=? AND p.present_in_vcenter=1`, sourceID); err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return s.ListPools(ctx, sourceID)
}
func (s *Service) SetPoolSelection(ctx context.Context, sourceID int64, in PoolSelectionInput, userID int64, actor string) ([]ResourcePool, error) {
	if _, err := s.GetSource(ctx, sourceID); err != nil {
		return nil, err
	}
	if in.Pools == nil {
		return nil, errors.New("pools field is required")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	// Explicitly validate every ID; missing/stale IDs cannot be used to bypass a policy.
	seen := map[string]bool{}
	before, err := readPoolAuditCounts(ctx, tx, sourceID)
	if err != nil {
		return nil, err
	}
	for _, choice := range in.Pools {
		id := strings.TrimSpace(choice.MoID)
		if id == "" {
			return nil, errors.New("resource pool ID cannot be empty")
		}
		if seen[id] {
			return nil, fmt.Errorf("duplicate pool %s", id)
		}
		seen[id] = true
		if old, exists := before[id]; exists && old.Include != choice.Include {
			action := "vcenter.pool.excluded"
			if choice.Include {
				action = "vcenter.pool.included"
			}
			if err := writeVCenterAuditActor(ctx, tx, action, "vcenter_resource_pool", id, userID, actor, map[string]any{
				"vcenter_source_id": sourceID, "pool_name": old.Name,
				"vm_count": old.VMCount, "powered_on_count": old.PoweredOnCount,
			}); err != nil {
				return nil, err
			}
		}
		res, err := tx.ExecContext(ctx, `UPDATE vcenter_resource_pools SET include_in_docs=? WHERE vcenter_source_id=? AND moid=? AND present_in_vcenter=1`, choice.Include, sourceID, id)
		if err != nil {
			return nil, err
		}
		affected, _ := res.RowsAffected()
		if affected == 0 {
			var exists int
			err = tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM vcenter_resource_pools WHERE vcenter_source_id=? AND moid=? AND present_in_vcenter=1`, sourceID, id).Scan(&exists)
			if err != nil {
				return nil, err
			}
			if exists == 0 {
				return nil, fmt.Errorf("unknown resource pool %s", id)
			}
		}
	}
	// Reject incomplete selection payloads; prevents an accidental partial reset.
	var total int
	if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM vcenter_resource_pools WHERE vcenter_source_id=? AND present_in_vcenter=1`, sourceID).Scan(&total); err != nil {
		return nil, err
	}
	if total != len(seen) {
		return nil, errors.New("selection must contain every visible resource pool")
	}
	// Existing entries are hidden or restored immediately. No deletions/retirements.
	_, err = tx.ExecContext(ctx, `UPDATE virtual_machines vm JOIN vcenter_resource_pools p ON p.vcenter_source_id=vm.vcenter_source_id AND p.moid=vm.vcenter_resource_pool_moid SET vm.excluded_by_vcenter_pool=IF(p.include_in_docs=1,0,1) WHERE vm.vcenter_source_id=? AND p.present_in_vcenter=1`, sourceID)
	if err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return s.ListPools(ctx, sourceID)
}
