DROP TABLE IF EXISTS vcenter_pool_vm_audit_state;
ALTER TABLE vcenter_resource_pools DROP COLUMN parent_moid;
