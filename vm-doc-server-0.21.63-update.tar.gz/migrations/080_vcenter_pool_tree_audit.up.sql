-- vCenter hierarchy and state-based audit; existing pool selections are preserved.
ALTER TABLE vcenter_resource_pools ADD COLUMN parent_moid VARCHAR(128) NOT NULL DEFAULT '' AFTER name;
CREATE TABLE IF NOT EXISTS vcenter_pool_vm_audit_state (
 vcenter_source_id BIGINT UNSIGNED NOT NULL,
 vcenter_moid VARCHAR(128) NOT NULL,
 pool_moid VARCHAR(128) NOT NULL DEFAULT '',
 vm_name VARCHAR(255) NOT NULL DEFAULT '',
 excluded TINYINT(1) NOT NULL DEFAULT 0,
 powered_on TINYINT(1) NOT NULL DEFAULT 0,
 observed_at DATETIME(6) NOT NULL,
 PRIMARY KEY (vcenter_source_id, vcenter_moid),
 CONSTRAINT fk_vcenter_pool_vm_audit_source FOREIGN KEY(vcenter_source_id) REFERENCES vcenter_sources(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
