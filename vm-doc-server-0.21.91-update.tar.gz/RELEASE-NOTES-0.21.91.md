# VM-DOC Server 0.21.91 — 2026-10-23

## Interfață
- Tabelele **Modificări** și **De documentat**, atât globale cât și din VM: numai antetele au fontul 12px; textul și controalele din rânduri rămân 14px.
- **VM → Modificări → Modificări**: tabel și panouri de detalii fără scroll orizontal; conținutul lung se încadrează și se rupe pe mai multe rânduri, fără să ascundă coloane.
- **VM → Modificări → Modificări**: «Salvează selectate» aliniat pe baza listboxurilor «Documentație» și «Stare».
- **Modificări (meniu stânga)**: în afară de header 12px, nu sunt făcute alte modificări în acest tabel.

## Compatibilitate
Update incremental peste **0.21.90**. Fără schimbări de API, date sau migrare SQL. Agentul rămâne **1.7.18**. Versiunea UI are cache-buster `0.21.91`.

## Verificări
Sunt efectuate verificări de sintaxă și teste Chromium pe fixture-uri locale. Nu se include build binar, dependențe `vendor/` sau test E2E cu datele de producție.
