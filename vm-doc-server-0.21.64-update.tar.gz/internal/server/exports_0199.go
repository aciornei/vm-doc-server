package server

import (
	"bytes"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/monitoring"
	"vm-doc-server/internal/veeam"
	"vm-doc-server/internal/xlsx"
)

func writeXLSXResponse(w http.ResponseWriter, sheet, prefix string, rows [][]xlsx.Cell) error {
	var output bytes.Buffer
	if err := xlsx.Write(&output, sheet, rows); err != nil {
		return err
	}
	filename := prefix + "-" + time.Now().Format("20060102-150405") + ".xlsx"
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
	w.Header().Set("Content-Length", strconv.Itoa(output.Len()))
	w.WriteHeader(http.StatusOK)
	_, err := w.Write(output.Bytes())
	return err
}

func (a *App) exportVeeamVMBackups(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query().Get("q")
	status := r.URL.Query().Get("status")
	power := r.URL.Query().Get("power")
	resultFilter := r.URL.Query().Get("result")
	items := make([]veeam.VMBackupItem, 0)
	for page := 1; ; page++ {
		result, err := a.Veeam.ListVMBackups(r.Context(), q, status, power, resultFilter, r.URL.Query().Get("environment"), page, 200)
		if err != nil {
			respond(w, nil, err)
			return
		}
		items = append(items, result.Items...)
		if result.Pages == 0 || page >= result.Pages {
			break
		}
	}
	rows := [][]xlsx.Cell{{
		xlsx.Text("VM"), xlsx.Text("Power state"), xlsx.Text("Stare backup"), xlsx.Text("În job Veeam"), xlsx.Text("Job activ"),
		xlsx.Text("Rezultat"), xlsx.Text("Job"), xlsx.Text("Repository primar"), xlsx.Text("Repository secundare"), xlsx.Text("Programare"),
		xlsx.Text("Retenție"), xlsx.Text("Restore points"), xlsx.Text("Ultimul backup"), xlsx.Text("Next run"), xlsx.Text("Sursă Veeam"), xlsx.Text("Sync vm-doc"), xlsx.Text("Eroare"),
	}}
	for _, v := range items {
		retention := strings.TrimSpace(v.RetentionType)
		if v.RetentionQuantity != nil {
			if retention != "" {
				retention += " · "
			}
			retention += strconv.Itoa(*v.RetentionQuantity)
		}
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(v.VMName), xlsx.Text(v.PowerState), xlsx.Text(v.VeeamState), xlsx.Text(yesNo(v.VeeamInJob)), xlsx.Text(yesNo(v.VeeamJobEnabled)),
			xlsx.Text(v.LastResult), xlsx.Text(v.JobName), xlsx.Text(firstNonEmptyString(v.PrimaryRepositoryName, v.RepositoryName)), xlsx.Text(v.SecondaryRepositoryNames), xlsx.Text(firstNonEmptyString(v.ScheduleText, v.CronBackupSchedule)),
			xlsx.Text(retention), optionalIntCell(v.RestorePoints), xlsx.Text(exportTime(v.LastBackupAt)), xlsx.Text(exportTime(v.NextRunAt)), xlsx.Text(v.SourceName), xlsx.Text(exportTime(v.SyncedAt)), xlsx.Text(v.ErrorMessage),
		})
	}
	if err := writeXLSXResponse(w, "Backup VM", "backup-vm", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write backup XLSX", "error", err)
	}
}

func (a *App) exportMonitoringVMs(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query().Get("q")
	state := r.URL.Query().Get("state")
	power := r.URL.Query().Get("power")
	items := make([]monitoring.VMListItem, 0)
	for page := 1; ; page++ {
		result, err := a.Monitoring.ListVMs(r.Context(), q, state, power, r.URL.Query().Get("environment"), page, 200)
		if err != nil {
			respond(w, nil, err)
			return
		}
		items = append(items, result.Items...)
		if result.Pages == 0 || page >= result.Pages {
			break
		}
	}
	rows := [][]xlsx.Cell{{
		xlsx.Text("VM"), xlsx.Text("Power state"), xlsx.Text("Node Exporter instalat"), xlsx.Text("Node Exporter rulează"), xlsx.Text("Versiune exporter"), xlsx.Text("Endpoint exporter"),
		xlsx.Text("Stare monitorizare"), xlsx.Text("Prometheus metrics"), xlsx.Text("Metrics UP"), xlsx.Text("Target metrics"), xlsx.Text("Job metrics"), xlsx.Text("Sursă metrics"), xlsx.Text("Metodă corelare"),
		xlsx.Text("Blackbox"), xlsx.Text("Blackbox UP"), xlsx.Text("Targeturi blackbox"),
	}}
	for _, v := range items {
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(v.VMName), xlsx.Text(v.PowerState), xlsx.Text(yesNo(v.ExporterInstalled)), xlsx.Text(yesNo(v.ExporterRunning)), xlsx.Text(v.ExporterVersion), xlsx.Text(v.ExporterEndpoint),
			xlsx.Text(v.MonitoringState), xlsx.Text(yesNo(v.MetricsMonitored)), xlsx.Text(yesNo(v.MetricsUp)), xlsx.Text(v.MetricsTarget), xlsx.Text(v.MetricsJob), xlsx.Text(v.MetricsSource), xlsx.Text(v.MetricsMatch),
			xlsx.Text(yesNo(v.BlackboxMonitored)), xlsx.Text(yesNo(v.BlackboxUp)), xlsx.Number(float64(v.BlackboxTargets)),
		})
	}
	if err := writeXLSXResponse(w, "Monitorizare VM", "monitorizare-vm", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write monitoring VM XLSX", "error", err)
	}
}

func (a *App) exportMonitoringTargets(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query().Get("q")
	sourceType := r.URL.Query().Get("source_type")
	health := r.URL.Query().Get("health")
	matched := r.URL.Query().Get("matched")
	items := make([]domain.MonitoringTarget, 0)
	for page := 1; ; page++ {
		result, err := a.Monitoring.ListTargets(r.Context(), q, sourceType, health, matched, page, 200)
		if err != nil {
			respond(w, nil, err)
			return
		}
		items = append(items, result.Items...)
		if result.Pages == 0 || page >= result.Pages {
			break
		}
	}
	rows := [][]xlsx.Cell{{
		xlsx.Text("Sursă"), xlsx.Text("Tip"), xlsx.Text("Job"), xlsx.Text("Instance"), xlsx.Text("URL scrape"), xlsx.Text("URL target"), xlsx.Text("Health"),
		xlsx.Text("VM corelat"), xlsx.Text("Metodă corelare"), xlsx.Text("Valoare corelare"), xlsx.Text("Încredere"), xlsx.Text("Ultimul scrape"), xlsx.Text("HTTP status"), xlsx.Text("TLS expiră"), xlsx.Text("Ultima eroare"), xlsx.Text("Sincronizat"),
	}}
	for _, t := range items {
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(t.PrometheusSourceName), xlsx.Text(t.SourceType), xlsx.Text(t.JobName), xlsx.Text(t.Instance), xlsx.Text(t.ScrapeURL), xlsx.Text(t.TargetURL), xlsx.Text(t.Health),
			xlsx.Text(t.MatchedVMName), xlsx.Text(t.MatchMethod), xlsx.Text(t.MatchValue), xlsx.Text(t.MatchConfidence), xlsx.Text(exportTime(t.LastScrapeAt)), optionalIntCell(t.HTTPStatusCode), xlsx.Text(exportTime(t.TLSExpiryAt)), xlsx.Text(t.LastError), xlsx.Text(t.SyncedAt.UTC().Format(time.RFC3339)),
		})
	}
	if err := writeXLSXResponse(w, "Targeturi", "monitorizare-targeturi", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write monitoring target XLSX", "error", err)
	}
}

func (a *App) exportInternalServices(w http.ResponseWriter, r *http.Request) {
	values, err := a.Catalog.List(r.Context(), true)
	if err != nil {
		respond(w, nil, err)
		return
	}
	q := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("q")))
	domainFilter := strings.TrimSpace(r.URL.Query().Get("domain"))
	categoryFilter := strings.TrimSpace(r.URL.Query().Get("category"))
	criticality := strings.TrimSpace(r.URL.Query().Get("criticality"))
	docStatus := strings.TrimSpace(r.URL.Query().Get("doc_status"))
	common := strings.TrimSpace(r.URL.Query().Get("common"))
	rows := [][]xlsx.Cell{{
		xlsx.Text("Serviciu"), xlsx.Text("Cod"), xlsx.Text("Descriere"), xlsx.Text("Domenii / categorii"), xlsx.Text("Criticitate"), xlsx.Text("Status documentație"), xlsx.Text("Tip serviciu"), xlsx.Text("VM-uri"), xlsx.Text("Dependențe"), xlsx.Text("Activ"), xlsx.Text("Link documentație"), xlsx.Text("Actualizat"),
	}}
	for _, s := range values {
		if !serviceExportMatches(s, q, domainFilter, categoryFilter, criticality, docStatus, common) {
			continue
		}
		classes := make([]string, 0, len(s.Classifications))
		for _, c := range s.Classifications {
			classes = append(classes, strings.TrimSpace(c.ArchitecturalDomain+" / "+c.ITILCategory))
		}
		kind := "aplicație"
		if s.ImplicitGlobal {
			kind = "global"
		} else if s.IsCommon {
			kind = "comun"
		}
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(s.Name), xlsx.Text(s.ServiceCode), xlsx.Text(s.Description), xlsx.Text(strings.Join(classes, "; ")), xlsx.Text(s.Criticality), xlsx.Text(s.DocumentationStatus), xlsx.Text(kind),
			xlsx.Number(float64(s.VMCount)), xlsx.Number(float64(s.DependencyCount)), xlsx.Text(yesNo(s.Active)), xlsx.Text(s.DocumentationURL), xlsx.Text(s.UpdatedAt.UTC().Format(time.RFC3339)),
		})
	}
	if err := writeXLSXResponse(w, "Servicii", "servicii", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write services XLSX", "error", err)
	}
}

func serviceExportMatches(s domain.InternalService, q, domainFilter, categoryFilter, criticality, docStatus, common string) bool {
	if q != "" && !strings.Contains(strings.ToLower(strings.Join([]string{s.Name, s.ServiceCode, s.Description}, " ")), q) {
		return false
	}
	if criticality != "" && s.Criticality != criticality {
		return false
	}
	if docStatus != "" && s.DocumentationStatus != docStatus {
		return false
	}
	if common == "common" && (!s.IsCommon || s.ImplicitGlobal) {
		return false
	}
	if common == "global" && !s.ImplicitGlobal {
		return false
	}
	if common == "normal" && s.IsCommon {
		return false
	}
	if domainFilter != "" || categoryFilter != "" {
		matched := false
		for _, c := range s.Classifications {
			if (domainFilter == "" || c.ArchitecturalDomain == domainFilter) && (categoryFilter == "" || c.ITILCategory == categoryFilter) {
				matched = true
				break
			}
		}
		if !matched {
			return false
		}
	}
	return true
}

func optionalIntCell[T ~int](value *T) xlsx.Cell {
	if value == nil {
		return xlsx.Text("")
	}
	return xlsx.Number(float64(*value))
}

func firstNonEmptyString(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return value
		}
	}
	return ""
}

func (a *App) exportReportPeople(w http.ResponseWriter, r *http.Request) {
	items, err := reportPeopleAssignments(r.Context(), a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}
	q := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("q")))
	responsibility := strings.TrimSpace(r.URL.Query().Get("responsibility"))
	department := strings.TrimSpace(r.URL.Query().Get("department"))
	environment := strings.TrimSpace(r.URL.Query().Get("environment"))
	rows := [][]xlsx.Cell{{
		xlsx.Text("Persoană"), xlsx.Text("Departament"), xlsx.Text("Email"), xlsx.Text("Responsabilitate"), xlsx.Text("VM"), xlsx.Text("Mediu"), xlsx.Text("Servicii"),
	}}
	for _, item := range items {
		if q != "" && !strings.Contains(strings.ToLower(strings.Join([]string{item.PersonName, item.Email, item.Department, item.VMName, item.Services}, " ")), q) {
			continue
		}
		if responsibility != "" && item.ResponsibilityType != responsibility {
			continue
		}
		if department != "" && item.Department != department {
			continue
		}
		if environment != "" && item.Environment != environment {
			continue
		}
		rows = append(rows, []xlsx.Cell{xlsx.Text(item.PersonName), xlsx.Text(item.Department), xlsx.Text(item.Email), xlsx.Text(reportResponsibilityLabel(item.ResponsibilityType)), xlsx.Text(item.VMName), xlsx.Text(item.Environment), xlsx.Text(item.Services)})
	}
	if err := writeXLSXResponse(w, "Persoane și VM-uri", "persoane-vm", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write people report XLSX", "error", err)
	}
}

func (a *App) exportReportOperationalGaps(w http.ResponseWriter, r *http.Request) {
	items, err := reportOperationalGaps(r.Context(), a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}
	q := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("q")))
	issue := strings.TrimSpace(r.URL.Query().Get("issue"))
	rows := [][]xlsx.Cell{{
		xlsx.Text("VM"), xlsx.Text("Hostname"), xlsx.Text("Mediu"), xlsx.Text("Power state"), xlsx.Text("Fără responsabil"), xlsx.Text("Fără serviciu"), xlsx.Text("Fără mediu"), xlsx.Text("Fără agent"), xlsx.Text("Agent offline"), xlsx.Text("Inventar lipsă/stale"), xlsx.Text("Backup"), xlsx.Text("Monitorizare"), xlsx.Text("Baseline"), xlsx.Text("Fișă VM"), xlsx.Text("Probleme"),
	}}
	for _, item := range items {
		if q != "" && !strings.Contains(strings.ToLower(strings.Join([]string{item.Name, item.Hostname, item.Environment, item.Issue}, " ")), q) {
			continue
		}
		if issue != "" && !reportGapMatches(item, issue) {
			continue
		}
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(item.Name), xlsx.Text(item.Hostname), xlsx.Text(item.Environment), xlsx.Text(item.PowerState), xlsx.Text(yesNo(item.NoResponsibility)), xlsx.Text(yesNo(item.NoService)), xlsx.Text(yesNo(item.NoEnvironment)), xlsx.Text(yesNo(item.NoAgent)), xlsx.Text(yesNo(item.AgentOffline)), xlsx.Text(yesNo(item.InventoryStale)), xlsx.Text(yesNo(item.BackupGap)), xlsx.Text(yesNo(item.MonitoringGap)), xlsx.Text(yesNo(item.NoBaseline)), xlsx.Text(yesNo(item.NoDocument)), xlsx.Text(item.Issue),
		})
	}
	if err := writeXLSXResponse(w, "Lipsuri operaționale", "lipsuri-operationale", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write operational gaps XLSX", "error", err)
	}
}

func reportResponsibilityLabel(value string) string {
	labels := map[string]string{"technical_admin": "Administrator tehnic", "service_owner": "Responsabil serviciu", "business_owner": "Responsabil business", "application_owner": "Responsabil aplicație", "infrastructure_owner": "Responsabil infrastructură", "security_contact": "Contact securitate", "backup_contact": "Contact backup", "other": "Altă responsabilitate"}
	if label := labels[value]; label != "" {
		return label
	}
	return value
}

func reportGapMatches(item reportOperationalGapRow, issue string) bool {
	switch issue {
	case "responsibility":
		return item.NoResponsibility
	case "service":
		return item.NoService
	case "environment":
		return item.NoEnvironment
	case "agent":
		return item.NoAgent
	case "agent_offline":
		return item.AgentOffline
	case "inventory":
		return item.InventoryStale
	case "backup":
		return item.BackupGap
	case "monitoring":
		return item.MonitoringGap
	case "baseline":
		return item.NoBaseline
	case "document":
		return item.NoDocument
	case "documentation":
		return item.NoResponsibility || item.NoService || item.NoEnvironment || item.NoBaseline || item.NoDocument
	}
	return true
}
