package vmenv

import "testing"

func TestEnvironmentNormalization(t *testing.T) {
	cases := []struct{ label, want string }{{"PROD", "PROD"}, {"Producție", "PROD"}, {"TEST", "TEST"}, {"UAT", "TEST"}, {"DEV", "DEV"}, {"dezvoltare", "DEV"}, {"", ""}}
	for _, tc := range cases {
		if got := Kind(tc.label); got != tc.want {
			t.Errorf("Kind(%q)=%q want %q", tc.label, got, tc.want)
		}
	}
	for _, v := range []string{"PROD", "TEST", "DEV", "", "all"} {
		if _, ok := Normalize(v); !ok {
			t.Errorf("valid environment: %q", v)
		}
	}
	if _, ok := Normalize("PROD' OR 1=1"); ok {
		t.Fatal("invalid environment accepted")
	}
}
