// Package vmenv keeps the VM environment filter consistent across inventory,
// agent, backup and monitoring views. It does not modify any environment label.
package vmenv

import "strings"

// Normalize validates API inputs; an empty value means all environments.
func Normalize(value string) (string, bool) {
	switch strings.ToUpper(strings.TrimSpace(value)) {
	case "", "ALL":
		return "", true
	case "PROD", "TEST", "DEV":
		return strings.ToUpper(strings.TrimSpace(value)), true
	default:
		return "", false
	}
}

// Kind uses the same documented classification as the VM web client.
func Kind(label string) string {
	s := strings.ToLower(strings.TrimSpace(label))
	switch {
	case strings.Contains(s, "prod") || strings.Contains(s, "produc"):
		return "PROD"
	case strings.Contains(s, "test") || strings.Contains(s, "uat") || s == "qa":
		return "TEST"
	case strings.Contains(s, "dev") || strings.Contains(s, "dezvolt"):
		return "DEV"
	default:
		return ""
	}
}

// SQLCase accepts ONLY trusted, developer-authored SQL expressions, never request input.
func SQLCase(expr string) string {
	s := "LOWER(COALESCE(" + expr + ",''))"
	return "CASE WHEN " + s + " LIKE '%prod%' OR " + s + " LIKE '%produc%' THEN 'PROD' " +
		"WHEN " + s + " LIKE '%test%' OR " + s + " LIKE '%uat%' OR " + s + "='qa' THEN 'TEST' " +
		"WHEN " + s + " LIKE '%dev%' OR " + s + " LIKE '%dezvolt%' THEN 'DEV' ELSE '' END"
}

// PreferredLabel returns a VM's effective environment, prioritizing nomenclature.
// The subquery is tied to an existing vm alias in its enclosing SQL SELECT.
const PreferredLabel = `COALESCE(NULLIF((SELECT n.name FROM vm_operational_nomenclatures mon JOIN nomenclature_items n ON n.id=mon.item_id AND n.category_code='environment' WHERE mon.vm_id=vm.id AND mon.category_code='environment' LIMIT 1),''),NULLIF(om_env.environment,''),'')`
