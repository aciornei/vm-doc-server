package vcenter

import (
	"strings"
	"testing"
)

func TestPowerEnvironmentVMFilter(t *testing.T) {
	f := NormalizeVMFilter(VMFilter{Power: "POWERED_ON", Environment: "prod"})
	sql, args, err := buildVMWhere(f)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(sql, "vm.power_state=?") || !strings.Contains(sql, "CASE WHEN") {
		t.Fatalf("missing filter expressions: %s", sql)
	}
	if len(args) != 2 || args[0] != "POWERED_ON" || args[1] != "PROD" {
		t.Fatalf("unexpected query params: %#v", args)
	}
	if _, _, err = buildVMWhere(VMFilter{Environment: "evil OR 1=1"}); err == nil {
		t.Fatal("invalid env accepted")
	}
}
