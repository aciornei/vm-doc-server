# VM-DOC Server 0.21.64 (2026-10-21)

Hotfix UI + API: în toate cele șase filtre cu Power apare lângă el Mediu (PROD, TEST, DEV, Toate), ambele preselectate Power ON + PROD la prima încărcare și după resetare. Filtrele și exporturile sunt aplicate înainte de paginare; Agenți folosește fast path SQL pentru combinația implicită, nu procesare masivă în memorie.

Pentru eroarea raportată `vmContext is not defined` la VM → Docker, sursele actuale nu conțin acel simbol. Am versionat HTML/JS la 0.21.64 și am dezactivat cache-ul HTTP pentru HTML/JS, pentru a preveni combinațiile de versiuni în browser. Acest lucru este o remediere preventivă; un stack trace este necesar dacă eroarea revine. Nu am modificat logica de colecție Docker.

Agent 1.7.18; fără modificări de DB, fără migrare SQL și fără noi permisiuni. Testele sintactice și unitare independente au trecut; integrările MariaDB și browser/vCenter real rămân de verificat în staging.
