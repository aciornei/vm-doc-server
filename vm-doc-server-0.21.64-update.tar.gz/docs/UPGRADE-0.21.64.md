# Upgrade VM-DOC Server 0.21.63 → 0.21.64

1. Backup la surse, configurație și baza MariaDB. Staging recomandat înainte de PROD.
2. Folosiți pachetul surse complet sau extrageți `vm-doc-server-0.21.64-update.tar.gz` peste sursele **0.21.63** (nu peste alte versiuni).
3. Pe mașina offline, păstrați `vendor/` existent și recompilați serverul conform fluxului de deployment folosit; validați `go test ./...` și `go build` local. Release-ul nu conține executabil compilat.
4. Repornire server și accesare UI prin Ctrl+F5 / refresh hard pentru invalidarea JavaScript vechi; verificați că `app.js?v=0.21.64` este servit. HTML/JS folosesc `Cache-Control: no-store`.
5. Verificați navigarea `VM → Docker`, apoi listele Agenți, VM, Backup și Monitorizare, respectiv rapoartele OS/Outline: **POWERED_ON + PROD** implicit; comutați pe TEST/DEV/Toate și confirmați exportul Excel.
6. În cazul `vmContext is not defined` persistent, copiați din DevTools → Console fișierul JS, numărul liniei și call stack-ul; identificatorul nu este prezent în JS din sursele 0.21.63/0.21.64 și nu se poate certifica cauza doar din textul erorii.

Nu există migrare SQL în 0.21.64 și nu se modifică agentul 1.7.18. Rollback: restaurați sursele/binarele 0.21.63 și reporniți; setările de mediu rămân în DB neschimbate.
