# VM-DOC 0.21.44 → 0.21.45

**Numai UI/metadate**. Nu există migrare SQL, modificare a endpointurilor API sau actualizare de agent.

1. Fă backup la binarul și sursele 0.21.44 și păstrează configurațiile și `vendor/`.
2. Din directorul surselor 0.21.44 aplică **una singură** dintre metode:

   ```bash
   tar -xzf /cale/vm-doc-server-0.21.45-update.tar.gz
   # SAU
   git apply /cale/vm-doc-server-0.21.44-to-0.21.45.patch
   ```

3. Confirmă `cat VERSION` = `0.21.45`; rulează `bash scripts/cleanup-source-tree.sh --check`.
4. În mediul offline cu `vendor/` disponibil rulează `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build`.
5. Repornește serviciul numai după validarea buildului și verifică Hardening cu un utilizator cu și fără `vms.manage`.
6. Fă hard refresh în Chrome pentru noile asseturi JS/CSS.

Rollback: restaurează sursele și binarul 0.21.44, apoi repornește serviciul. Nu este necesar rollback SQL.
