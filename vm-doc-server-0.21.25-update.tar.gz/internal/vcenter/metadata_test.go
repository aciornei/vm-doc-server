package vcenter

import "testing"

func TestNormalizeOperationalMetadata(t *testing.T) {
	input := OperationalMetadataInput{
		Purpose:          "  VM shared  ",
		DocumentationURL: "https://docs.example.test/vm/1",
		TicketReference:  "  INC-123  ",
		Classification:   "  Uz intern  ",
	}
	if err := normalizeOperationalMetadata(&input); err != nil {
		t.Fatal(err)
	}
	if input.Purpose != "VM shared" || input.TicketReference != "INC-123" || input.Classification != "Uz intern" {
		t.Fatalf("values were not normalized: %#v", input)
	}
}

func TestNormalizeOperationalMetadataRejectsInvalidValues(t *testing.T) {
	cases := []OperationalMetadataInput{
		{OwnerEmail: "not-an-email"},
		{DocumentationURL: "file:///tmp/doc"},
	}
	for index := range cases {
		if err := normalizeOperationalMetadata(&cases[index]); err == nil {
			t.Fatalf("case %d should fail", index)
		}
	}
}

func TestAllowedServiceUsageTypes(t *testing.T) {
	for _, value := range []string{"dedicated", "shared", "dependency"} {
		if !allowedServiceUsageTypes[value] {
			t.Fatalf("usage type %q should be allowed", value)
		}
	}
	if allowedServiceUsageTypes["invalid"] {
		t.Fatal("invalid usage type should not be allowed")
	}
}

func TestOperationalRecoveryDefaultsPreserveExplicitValues(t *testing.T) {
	rpo := 720
	rto := 0
	cases := []struct {
		name    string
		input   OperationalMetadataInput
		wantRPO int
		wantRTO int
	}{
		{name: "both missing", wantRPO: 1440, wantRTO: 240},
		{name: "custom RPO", input: OperationalMetadataInput{RPOMinutes: &rpo}, wantRPO: 720, wantRTO: 240},
		{name: "explicit zero RTO", input: OperationalMetadataInput{RTOMinutes: &rto}, wantRPO: 1440, wantRTO: 0},
		{name: "both custom", input: OperationalMetadataInput{RPOMinutes: &rpo, RTOMinutes: &rto}, wantRPO: 720, wantRTO: 0},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			applyOperationalRecoveryDefaults(&tc.input)
			if tc.input.RPOMinutes == nil || *tc.input.RPOMinutes != tc.wantRPO {
				t.Fatalf("RPO got %v, want %d", tc.input.RPOMinutes, tc.wantRPO)
			}
			if tc.input.RTOMinutes == nil || *tc.input.RTOMinutes != tc.wantRTO {
				t.Fatalf("RTO got %v, want %d", tc.input.RTOMinutes, tc.wantRTO)
			}
		})
	}
}
