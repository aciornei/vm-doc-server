-- Un rollback nu poate distinge valori implicite de cele alese explicit după migrare.
-- Restaurăm numai DEFAULT-urile schemei, fără să ștergem datele deja completate.
ALTER TABLE vm_operational_metadata
  MODIFY COLUMN rpo_minutes INT UNSIGNED NULL DEFAULT NULL,
  MODIFY COLUMN rto_minutes INT UNSIGNED NULL DEFAULT NULL;
