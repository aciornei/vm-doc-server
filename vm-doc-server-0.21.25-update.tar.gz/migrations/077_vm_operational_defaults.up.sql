-- VM-DOC 0.21.25: RPO/RTO defaults, fără modificarea valorilor existente (inclusiv 0).
ALTER TABLE vm_operational_metadata
  MODIFY COLUMN rpo_minutes INT UNSIGNED NULL DEFAULT 1440,
  MODIFY COLUMN rto_minutes INT UNSIGNED NULL DEFAULT 240;

UPDATE vm_operational_metadata
SET rpo_minutes = COALESCE(rpo_minutes, 1440),
    rto_minutes = COALESCE(rto_minutes, 240)
WHERE rpo_minutes IS NULL OR rto_minutes IS NULL;

-- Completează doar VM-urile fără rând operațional; păstrează datele operaționale existente.
INSERT INTO vm_operational_metadata (vm_id, purpose, notes, rpo_minutes, rto_minutes)
SELECT vm.id, '', '', 1440, 240
FROM virtual_machines vm
LEFT JOIN vm_operational_metadata om ON om.vm_id = vm.id
WHERE om.vm_id IS NULL;
