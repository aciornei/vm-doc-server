# Upgrade VM-DOC 0.21.24 → 0.21.25

1. Salvează un backup MariaDB și păstrează binarul 0.21.24 pentru rollback.
2. Instalează update-ul TAR.GZ într-o copie a surselor 0.21.24, păstrând `vendor/` de pe server.
3. Execută `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și `GOPROXY=off GOFLAGS=-mod=vendor make build`.
4. Testează întâi în staging. **Migrarea 077 este nouă:** la pornire, serverul va completa RPO/RTO lipsă cu 1440/240, fără să schimbe valori nenule. Nu folosi `down.sql` ca procedură automată de anulare: datele adăugate nu sunt șterse la rollback.
5. Pornește binarul nou și verifică VM → Infrastructură, respectiv VM → Operațional, inclusiv o VM cu RPO/RTO setate diferit și una fără valori.
6. Ctrl+F5 pentru a încărca CSS/JS noile versiuni.

SQL de control după migrare (numai pentru inspecție):
```sql
SELECT COUNT(*) AS valori_lipsa
FROM vm_operational_metadata
WHERE rpo_minutes IS NULL OR rto_minutes IS NULL;

SELECT vm_id, rpo_minutes, rto_minutes
FROM vm_operational_metadata
ORDER BY vm_id LIMIT 25;
```

Fără update Agent. Linkurile Vault nu sunt exportate.
