package inventorychanges

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestNoiseServices(t *testing.T) {
	raw := []byte(`{"services":[{"name":"wlidsvc","active_state":"active","sub_state":"running","enabled_state":"enabled","version":"1.0"},{"name":"user@1000.service","enabled_state":"enabled"},{"name":"lxd-installer@68.service"}]}`)
	objs, err := extractTracked(raw)
	if err != nil {
		t.Fatal(err)
	}
	v, ok := objs["services|service|wlidsvc"]
	if !ok {
		t.Fatal("service lost")
	}
	val := v.Value.(map[string]any)
	if _, ok := val["active_state"]; ok {
		t.Fatal("volatile active_state preserved")
	}
	if _, ok := val["sub_state"]; ok {
		t.Fatal("volatile sub_state preserved")
	}
	if val["enabled_state"] != "enabled" || val["version"] != "1.0" {
		t.Fatal("meaningful service fields lost")
	}
	for key := range objs {
		if strings.Contains(key, "user@1000") || strings.Contains(key, "lxd-installer@") {
			t.Fatal("ephemeral service tracked", key)
		}
	}
}

func TestPortSelectionAndDynamicRange(t *testing.T) {
	makePort := func(port int) trackedObject {
		return trackedObject{Category: "ports", Type: "listening_port", Value: map[string]any{"protocol": "tcp", "port": json.Number(strings.TrimSpace(func() string {
			switch port {
			case 443:
				return "443"
			case 55000:
				return "55000"
			}
			return ""
		}()))}}
	}
	high := makePort(55000)
	low := makePort(443)
	if !suppressDynamicPortChange(high, trackedObject{}, true, false, nil) {
		t.Fatal("dynamic high port not ignored")
	}
	if suppressDynamicPortChange(low, trackedObject{}, true, false, nil) {
		t.Fatal("well known port ignored")
	}
	marked := map[portSelection]bool{{protocol: "tcp", port: 55000}: true}
	if suppressDynamicPortChange(trackedObject{}, high, false, true, marked) {
		t.Fatal("Principal port ignored")
	}
}

func TestGeneratedRulesConservative(t *testing.T) {
	tests := []struct {
		chain    string
		expected bool
	}{{"DOCKER", true}, {"DOCKER-FORWARD", true}, {"ufw-before-input", true}, {"cni-forward", true}, {"ufw-user-input", false}, {"DOCKER-USER", false}, {"INPUT", false}, {"OUTPUT", false}, {"custom", false}}
	for _, tc := range tests {
		actual := isGeneratedFirewallRule(map[string]any{"backend": "nftables", "chain": tc.chain})
		if actual != tc.expected {
			t.Fatalf("chain %s: want %v got %v", tc.chain, tc.expected, actual)
		}
	}
	if isGeneratedFirewallRule(map[string]any{"backend": "windows_firewall", "chain": "DOCKER"}) {
		t.Fatal("windows rule incorrectly excluded")
	}
}

func TestRuntimeChangesNoLongerTracked(t *testing.T) {
	a := []byte(`{"services":[{"name":"foo.service","active_state":"active","sub_state":"running","enabled_state":"enabled","version":"1"}],"ntp":{"synchronized":true,"current_source":"a","service_active":"active","service_enabled":"enabled"},"integrations":{"auditbeat":{"installed":true,"service_active":"running","output_test_ok":true,"output_test_output":"ok","package_version":"1"}}}`)
	b := []byte(`{"services":[{"name":"foo.service","active_state":"inactive","sub_state":"dead","enabled_state":"enabled","version":"1"}],"ntp":{"synchronized":false,"current_source":"b","service_active":"inactive","service_enabled":"enabled"},"integrations":{"auditbeat":{"installed":true,"service_active":"stopped","output_test_ok":false,"output_test_output":"error","package_version":"1"}}}`)
	aa, err := extractTracked(a)
	if err != nil {
		t.Fatal(err)
	}
	bb, err := extractTracked(b)
	if err != nil {
		t.Fatal(err)
	}
	for key, val := range aa {
		if !canonicalEqual(val.Value, bb[key].Value) {
			t.Fatal("runtime noise still tracked", key)
		}
	}
	bb["services|service|foo.service"] = trackedObject{Value: map[string]any{"version": "2"}}
	if canonicalEqual(aa["services|service|foo.service"].Value, bb["services|service|foo.service"].Value) {
		t.Fatal("version change not detected")
	}
}

func TestMoreTransientServiceFamilies(t *testing.T) {
	for _, service := range []string{
		"lxd-installer@177-1372636-0.service",
		"lxd-installer@336-1266435-0.service",
		"PrintWorkflowUserSvc_6d76121b",
		"PimIndexMaintenanceSvc_6d76121b",
		"DevicesFlowUserSvc_6d76121b",
		"DevicePickerUserSvc_6d76121b",
		"ConsentUxUserSvc_6d76121b",
		"CaptureService_6d76121b",
		"BcastDVRUserService_6d76121b",
		"P9RdrService_b6809",
		"P9RdrService_31c5b23",
		"NPSMSvc_b6809",
		"NPSMSvc_31c5b23",
		"DeviceAssociationBrokerSvc_b6809",
		"DeviceAssociationBrokerSvc_31c5b23",
	} {
		if !isEphemeralService(service) {
			t.Fatalf("not suppressed: %s", service)
		}
	}
	for _, service := range []string{
		"lxd-installer@production.service",
		"lxd-installer@123-custom.service",
		"CaptureService",
		"ApplicationWorker_6d76121b",
		"TrustedInstaller",
		"P9RdrService",               // service base itself, not an ephemeral instance
		"NPSMSvc",                    // non-suffixed service stays visible
		"DeviceAssociationBrokerSvc", // non-suffixed service stays visible
		"ApplicationWorker_b6809",    // unknown third-party service not filtered
		"P9RdrService_invalidsuffix",
		"mysql",
	} {
		if isEphemeralService(service) {
			t.Fatalf("important or non-ephemeral service suppressed: %s", service)
		}
	}
}

func TestMySQLWarningDoesNotGenerateVersionChange(t *testing.T) {
	a := []byte(`{"services":[{"name":"mysql","manager":"sysv","package_name":"mysql-server","package_version":"5.5.60-0ubuntu0.14.04.1","version":"261019 9:46:33 [Warning] Using unique option prefix key_buffer"}]}`)
	b := []byte(`{"services":[{"name":"mysql","manager":"sysv","package_name":"mysql-server","package_version":"5.5.60-0ubuntu0.14.04.1","version":"261020 10:01:48 [Warning] Using unique option prefix key_buffer"}]}`)
	assertTrackedEqual(t, a, b, "services|service|mysql")
	obj, err := extractTracked(a)
	if err != nil {
		t.Fatal(err)
	}
	if _, exists := obj["services|service|mysql"].Value.(map[string]any)["version"]; exists {
		t.Fatal("warning-only version was tracked")
	}
	for _, test := range []struct {
		raw  string
		want string
	}{
		{raw: "261019 9:46:33 [Warning] Using unique option prefix key_buffer\nmysqld  Ver 8.0.36 for Linux", want: "mysqld  Ver 8.0.36 for Linux"},
		{raw: "8.0.36", want: "8.0.36"},
		{raw: "8.0.36 [Warning] message", want: "8.0.36"},
	} {
		got := trackedServiceFields(map[string]any{"version": test.raw})["version"]
		if got != test.want {
			t.Fatalf("got %#v want %q", got, test.want)
		}
	}
}

func TestRealVersionAndEnablementChangesStillDetected(t *testing.T) {
	before := []byte(`{"services":[{"name":"mysql","version":"8.0.35","package_version":"8.0.35","enabled_state":"enabled"}]}`)
	after := []byte(`{"services":[{"name":"mysql","version":"8.0.36","package_version":"8.0.36","enabled_state":"disabled"}]}`)
	a, err := extractTracked(before)
	if err != nil {
		t.Fatal(err)
	}
	b, err := extractTracked(after)
	if err != nil {
		t.Fatal(err)
	}
	if canonicalEqual(a["services|service|mysql"].Value, b["services|service|mysql"].Value) {
		t.Fatal("real changes must remain tracked")
	}
}

func TestWindowsPerUserServicesAbsentFromTrackedHistory(t *testing.T) {
	raw := []byte(`{"services":[{"name":"PrintWorkflowUserSvc_6d76121b"},{"name":"PimIndexMaintenanceSvc_6d76121b"},{"name":"DevicesFlowUserSvc_6d76121b"},{"name":"DevicePickerUserSvc_6d76121b"},{"name":"ConsentUxUserSvc_6d76121b"},{"name":"CaptureService_6d76121b"},{"name":"P9RdrService_b6809"},{"name":"P9RdrService_31c5b23"},{"name":"NPSMSvc_b6809"},{"name":"DeviceAssociationBrokerSvc_31c5b23"},{"name":"ApplicationWorker_6d76121b"}]}`)
	objs, err := extractTracked(raw)
	if err != nil {
		t.Fatal(err)
	}
	if len(objs) != 1 {
		t.Fatalf("expected only application service tracked, got %#v", objs)
	}
	if _, ok := objs["services|service|ApplicationWorker_6d76121b"]; !ok {
		t.Fatal("third party application service unexpectedly ignored")
	}
}

// Windows SCM DisplayName may be localized or fall back to the service key.
// The stable service name is still tracked, but the description alone is not.
func TestWindowsSCMDisplayNameDoesNotCreateHistoryNoise(t *testing.T) {
	before := []byte(`{"services":[{"name":"wuauserv","manager":"windows_scm","software_name":"Windows Update","enabled_state":"manual","version":"10.0"},{"name":"workfolderssvc","manager":"windows_scm","software_name":"Work Folders","enabled_state":"disabled"}]}`)
	after := []byte(`{"services":[{"name":"wuauserv","manager":"windows_scm","software_name":"wuauserv","enabled_state":"manual","version":"10.0"},{"name":"workfolderssvc","manager":"windows_scm","software_name":"workfolderssvc","enabled_state":"disabled"}]}`)
	for _, name := range []string{"wuauserv", "workfolderssvc"} {
		assertTrackedEqual(t, before, after, "services|service|"+name)
	}
	objects, err := extractTracked(before)
	if err != nil {
		t.Fatal(err)
	}
	if _, exists := objects["services|service|wuauserv"].Value.(map[string]any)["software_name"]; exists {
		t.Fatal("windows_scm software_name was retained in tracked fields")
	}
}

func TestWindowsSCMRealChangesRemainTracked(t *testing.T) {
	before := []byte(`{"services":[{"name":"wuauserv","manager":"windows_scm","software_name":"Windows Update","enabled_state":"manual","version":"10.0","package_version":"10.0"}]}`)
	for _, after := range [][]byte{
		[]byte(`{"services":[{"name":"wuauserv","manager":"windows_scm","software_name":"wuauserv","enabled_state":"disabled","version":"10.0","package_version":"10.0"}]}`),
		[]byte(`{"services":[{"name":"wuauserv","manager":"windows_scm","software_name":"wuauserv","enabled_state":"manual","version":"10.1","package_version":"10.0"}]}`),
		[]byte(`{"services":[{"name":"wuauserv","manager":"windows_scm","software_name":"wuauserv","enabled_state":"manual","version":"10.0","package_version":"10.1"}]}`),
		[]byte(`{"services":[{"name":"wuauserv","manager":"systemd","software_name":"wuauserv","enabled_state":"manual","version":"10.0","package_version":"10.0"}]}`),
	} {
		b, err := extractTracked(before)
		if err != nil {
			t.Fatal(err)
		}
		a, err := extractTracked(after)
		if err != nil {
			t.Fatal(err)
		}
		if canonicalEqual(b["services|service|wuauserv"].Value, a["services|service|wuauserv"].Value) {
			t.Fatalf("real change was hidden: %s", after)
		}
	}
	noService, err := extractTracked([]byte(`{"services":[]}`))
	if err != nil {
		t.Fatal(err)
	}
	old, _ := extractTracked(before)
	if _, exists := noService["services|service|wuauserv"]; exists {
		t.Fatal("removed service still present")
	}
	if _, exists := old["services|service|wuauserv"]; !exists {
		t.Fatal("base service disappeared")
	}
}

func TestOtherPlatformsStillTrackSoftwareName(t *testing.T) {
	for _, manager := range []string{"systemd", "sysv", "", "windows_service"} {
		a := []byte(`{"services":[{"name":"app","manager":"` + manager + `","software_name":"Application A","enabled_state":"enabled"}]}`)
		b := []byte(`{"services":[{"name":"app","manager":"` + manager + `","software_name":"Application B","enabled_state":"enabled"}]}`)
		old, err := extractTracked(a)
		if err != nil {
			t.Fatal(err)
		}
		next, err := extractTracked(b)
		if err != nil {
			t.Fatal(err)
		}
		if canonicalEqual(old["services|service|app"].Value, next["services|service|app"].Value) {
			t.Fatalf("software_name on manager %q unexpectedly ignored", manager)
		}
	}
	mixedCase := trackedServiceFields(map[string]any{"name": "win-service", "manager": "  Windows_SCM  ", "software_name": "text"})
	if _, ok := mixedCase["software_name"]; ok {
		t.Fatal("case-insensitive windows_scm not recognized")
	}
}
