# VM-DOC Server 0.21.55 — Windows service name-only change noise

Starting version: 0.21.54. Agent 1.7.18 unchanged. No API behavior change, no automatic SQL migration.

- For services with manager `windows_scm` only, ignore `software_name` (`Win32_Service.DisplayName`) during semantic history comparison.
- Preserve service identity, additions/removals, enabled state and version/package changes; preserve all existing behavior for non-Windows SCM services.
- Optional cumulative PREVIEW/CLEANUP 0.21.50–0.21.55 extends historical removal solely for `software_name`-only Windows SCM `modified` events, protecting operator reviews and notes.
- Raw snapshots and displayed inventory are unaffected. Full offline build and MariaDB staging verification remain necessary.
