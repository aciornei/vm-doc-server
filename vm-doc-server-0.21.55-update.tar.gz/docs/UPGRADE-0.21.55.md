# Upgrade VM-DOC Server 0.21.54 → 0.21.55

1. Verifică `VERSION=0.21.54` în sursele actuale. Fă backup verificat pentru baza MariaDB, configurații, binar și sursele instalate.
2. Oprește serverul. Aplică update-ul `.tar.gz` peste **sursele 0.21.54** (sau patch-ul incremental, nu ambele); `vendor/` și configurația locală se păstrează. Pentru instalare completă există `source.zip`.
3. Pe serverul de build offline cu dependențe vendorizate rulează `GOPROXY=off GOSUMDB=off go test ./internal/inventorychanges`, apoi `GOPROXY=off GOSUMDB=off go test ./...` și `make build`. Reinstalează binarul doar după ce acestea trec și testele staging sunt bune.
4. Verifică în staging: `wuauserv` Windows SCM `software_name=Windows Update`→`wuauserv` nu creează event; `enabled_state` și `version` modificate creează event; `systemd/sysv` nu se schimbă. Fișele și inventarele brute nu sunt afectate.
5. Curățare istorică **opțională**: după backup și cu serverul oprit, execută mai întâi `scripts/preview-inventory-changes-cleanup.sql`; analizează **toate** categoriile, fiind un script **cumulativ 0.21.50–0.21.55**. Noua categorie `software_name_windows_scm` trebuie să conțină exclusiv modificări Windows SCM în care doar acest câmp diferă și fără review, decizie sau notițe. Validează SQL pe o copie/staging MariaDB.
6. Numai după verificări rulează `scripts/cleanup-inventory-changes.sql`, apoi verifică volumele rămase și repornește serverul. Nu rula SQL cumulativ din versiuni anterioare după acesta.

**Agent:** 1.7.18 neschimbat. **SQL:** fără migrare automată, doar cleanup manual. **API/Swagger:** numai versiunea OpenAPI, fără endpoint-uri schimbate. **Rollback:** binarul/sursele 0.21.54; pentru ștergerile SQL, restore din backupul MariaDB (irreversibile fără acesta).

**Limitări validare:** build-ul integral cu `vendor/` și interogările pe MariaDB reală trebuie executate pe staging/mediul offline.
