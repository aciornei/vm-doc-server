# Upgrade vm-doc-server 0.20.40 -> 0.20.41

Versiunea 0.20.41 modifică doar raportul **Suport sisteme de operare** și frontend-ul aferent. Nu adaugă migrare DB și nu necesită update de vm-doc-agent.

## Schimbări

- filtrele sunt afișate primele;
- cardurile se recalculează după căutare și filtrele generale;
- graficele sunt colapsate implicit;
- tabelul este paginat, cu 10 / 25 / 50 / 100 / 200 rânduri pe pagină;
- alegerea dimensiunii paginii este păstrată în browser;
- Export Excel exportă toate rândurile care corespund filtrelor, nu doar pagina vizibilă.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.40 \
      /usr/local/src/vm-doc-server-0.20.41

tar -xzf vm-doc-server-0.20.41-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.41

cd /usr/local/src/vm-doc-server-0.20.41
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După restart folosește `Ctrl+F5` pentru a încărca `app.js?v=0.20.41`.
