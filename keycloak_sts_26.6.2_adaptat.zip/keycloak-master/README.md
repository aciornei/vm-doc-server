Keycloak (26.4.5)
======================

> This project contains custom **themes** and **plugins** for Keycloak.

## Project Structure

- `docker/` — Production deployment configuration for Keycloak:
    - `Dockerfile` — Builds a production Keycloak image with the custom theme JAR.
    - `compose.yml` — Docker Compose for production (Keycloak + PostgreSQL).
- `keycloak-dev/` — Local development environment (Docker Compose, H2 data, etc).
- `keycloak-themes/` — Contains custom Keycloak themes and theme JAR build (Maven project).
    - `theme/sts.v1/` — Main custom theme (login pages, resources, translations).
    - `target/keycloak-sts-themes-x.y.z.jar` — Built theme JAR for production deployment.

## Local Development (with H2 & Hot-Reload Themes)

From the project root:

```sh
cd keycloak-dev
# Start Keycloak with the custom theme mounted (development mode)
docker compose up
```

- The `keycloak-dev/compose.yml` mounts the `keycloak-themes/src/main/resources/theme` directory into the Keycloak container.
- The theme will be available as `sts.v1` in the Keycloak admin UI.

## Production Deployment (with PostgreSQL & Built Theme JAR)

1. **Build the theme JAR:**
   ```sh
   cd keycloak-themes
   mvn clean package
   ```
   This creates `target/keycloak-sts-themes-x.y.z.jar`.

2. **Build the production Keycloak image:**
   ```sh
   docker build --no-cache -t stsdockerhub/keycloak:x.y.z -f docker/Dockerfile .
   #docker build --no-cache -t stsdockerhub/keycloak:26.3.5 -f docker/Dockerfile .
   ```

3. **Start the production stack:**
   ```sh
   docker compose -f docker/compose.yml up
   ```
   - This runs Keycloak (with your custom theme JAR) and PostgreSQL 18+ with persistent storage in `docker/keycloak-db-data/`.

## Enabling the Custom Theme

1. Log in to the Keycloak admin console.
2. Go to **Realm Settings > Themes**.
3. Set the Login Theme to `sts.v1`.
4. Save changes.

## Theme Customization

- **Templates:** `keycloak-themes/*/*/theme/sts.v1/login/*.ftl`
- **CSS/JS:** `keycloak-themes/*/*/theme/sts.v1/login/resources/css/`, `.../js/`
- **Images:** `keycloak-themes/*/*/theme/sts.v1/login/resources/img/`
- **Translations:** `keycloak-themes/*/*/theme/sts.v1/login/messages/`

Edit these files to customize the look and feel of your Keycloak login pages.

## Development Tips

- After editing theme files, you may need to clear your browser cache or reload the Keycloak server to see changes.
- For advanced customization, refer to the [Keycloak Theme Documentation](https://www.keycloak.org/docs/latest/server_development/#_themes).

## Contributing

1. Fork this repository.
2. Create a new branch for your feature or fix.
3. Make your changes and test locally.
4. Submit a pull request.
