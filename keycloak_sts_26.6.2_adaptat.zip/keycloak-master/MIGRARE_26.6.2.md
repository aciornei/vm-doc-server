# Migrare tema STS v1: Keycloak 26.4.5 -> 26.6.2

## Concluzie

Această arhivă conține un proiect de temă Keycloak (`sts.v1`), nu un Authentication SPI Java. Pachetul `keycloak-sts-themes-1.0.0.jar` este alcătuit din resurse (FTL, CSS, JS, imagini, traduceri). Nu sunt necesare dependențe Java Keycloak sau compilare Java pentru temă.

**Atenție: validat static; NU a fost executat un container Keycloak 26.6.2 în mediul de analiză.** Confirmarea definitivă se face într-o instanță de test.

## Modificări față de arhiva primită

1. `docker/Dockerfile`: ambele imagini Keycloak au fost trecute la 26.6.2.
2. `docker/compose.yml`: imaginea și numele containerului Keycloak au fost trecute la 26.6.2.
3. `keycloak-dev/compose.yml`: imaginea Keycloak din mediul de dezvoltare a fost trecută la 26.6.2.
4. `template.ftl`: escape JavaScript sigur pentru parametrii injectați în scripturile de sesiune, după modelul din tema de bază Keycloak 26.6.2; protecție pentru meniul opțional lipsă.
5. `resources/js/theme.js`: protecție când butonul opțional `themeSwitch` nu există în pagina curentă.
6. `keycloak-themes/target/keycloak-sts-themes-1.0.0.jar`: arhivă JAR de resurse generată pentru test, echivalentă structural cu proiectul Maven.

Pachetul nu modifică identitatea vizuală, traducerile, mecanismele Kerberos, flow-urile ori configurările din baza de date.

## Build și rulare în test

Din directorul rădăcină al proiectului:

```bash
# Opțional: reconstrucție JAR cu Maven (înlocuiește pachetul generat inclus)
cd keycloak-themes && mvn clean package && cd ..

# Construire imagine (din directorul rădăcină)
docker build --no-cache -t stsdockerhub/keycloak:26.6.2 -f docker/Dockerfile .

# Fără conectare la baza de producție; vezi mai jos avertismentul pentru compose
docker compose -f docker/compose.yml config
```

## ATENȚIE la configurația originală

`docker/compose.yml` din sursa inițială conține valori demonstrative/slabe pentru `POSTGRES_PASSWORD` și `KEYCLOAK_ADMIN_PASSWORD`, iar porturile 8080 și 9000 sunt publicate. Aceste valori au fost conservate doar pentru a nu schimba comportamentul instalării existente. **Înlocuiește parolele și restricționează accesul înainte de folosirea acestui fișier într-un mediu real.** Nu conecta o instanță 26.6.2 de test la baza de date de producție, fiindcă migrarea schemei poate face imposibil un rollback fără restaurarea bazei.

## Checklist de testare

- [ ] Pornește Keycloak 26.6.2 pe o bază de date separată (snapshot/copie restaurată sau test realm separat).
- [ ] Verifică în `Realm Settings > Themes` că `sts.v1` apare și poate fi selectată ca temă de login.
- [ ] Login username/parolă, inclusiv mesaje de eroare și versiunea în limba română.
- [ ] SPNEGO/Kerberos și flow alternativ fără Kerberos (sunt configurări Keycloak, nu funcții din temă).
- [ ] OTP / Required Actions: UPDATE_PASSWORD, UPDATE_PROFILE, CONFIGURE_TOTP (și altele folosite în producție).
- [ ] Reset password, email actions, logout și expirarea sesiunii.
- [ ] Test în Edge, Chrome și Firefox, inclusiv fereastră privată.
- [ ] Test vizual desktop/mobil, tema luminoasă/întunecată și logo/slideshow.
- [ ] Inspectează erorile JavaScript și Network 404 în DevTools, plus logurile Keycloak.
- [ ] Verifică separat clienții care folosesc OAuth 2.0 token introspection: 26.6.2 validează `aud`, ceea ce poate necesita mapper Audience.
- [ ] Revizuiește flow-urile custom după schimbările din 26.6.0/26.6.1 (Organization sub-flow).

## Referințe oficiale

- https://www.keycloak.org/docs/26.6.4/upgrading/ (conține modificările de migrare 26.6.0–26.6.2)
- https://www.keycloak.org/ui-customization/themes
- https://www.keycloak.org/2026/05/keycloak-2662-released

