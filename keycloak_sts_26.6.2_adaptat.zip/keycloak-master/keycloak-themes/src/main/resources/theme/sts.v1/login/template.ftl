<#import "field.ftl" as field>
<#import "footer.ftl" as loginFooter>
<#import "logo.ftl" as logo>
<#macro username>
    <#assign label>
    <#if !realm.loginWithEmailAllowed>${msg("username")}<#elseif !realm.registrationEmailAsUsername>${msg("usernameOrEmail")}<#else>${msg("email")}</#if>
</#assign>
    <@field.group name="username" label=label>
        <div class="${properties.kcInputGroup!}">
            <div class="${properties.kcInputGroupItemClass!} ${properties.kcFill!}">
                <span class="${properties.kcInputClass!} ${properties.kcFormReadOnlyClass!}">
                    <input id="kc-attempted-username" value="${auth.attemptedUsername}" class="mb-6 form-control" readonly>
                </span>
            </div>
            <div class="${properties.kcInputGroupItemClass!}">
                <button id="reset-login" class="btn btn-primary d-grid w-100 ${properties.kcFormPasswordVisibilityButtonClass!} kc-login-tooltip" type="button"
                aria-label="${msg('restartLoginTooltip')}" onclick="location.href='${url.loginRestartFlowUrl}'">
                    <i class="fa-sync-alt fas" aria-hidden="true"></i>
                    <span class="kc-tooltip-text">${msg("restartLoginTooltip")}</span>
                </button>
            </div>
        </div>
    </@field.group>
</#macro>

<#macro registrationLayout bodyClass="" displayInfo=false displayMessage=true displayRequiredFields=false>
    <!DOCTYPE html>
    <html class="${properties.kcHtmlClass!}" lang="${lang}"<#if realm.internationalizationEnabled> dir="${(locale.rtl)?then('rtl','ltr')}"</#if>>

        <head>
            <meta charset="utf-8">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <meta name="color-scheme" content="light${darkMode?then(' dark', '')}">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta name="description" content="Securely sign in to your STS identity account at id.sts.ro using Keycloak single sign-on.">

            <#if properties.meta?has_content>
                <#list properties.meta?split(' ') as meta>
                    <meta name="${meta?split('==')[0]}" content="${meta?split('==')[1]}"/>
                </#list>
            </#if>
            <title>${msg("loginTitle",(realm.displayName!''))}</title>

            <link rel="icon" href="${url.resourcesPath}/favicon/favicon.ico" />
            <link rel="icon" type="image/png" href="${url.resourcesPath}/favicon/favicon-96x96.png" sizes="96x96" />
            <link rel="icon" type="image/svg+xml" href="${url.resourcesPath}/favicon/favicon.svg" />
            <link rel="shortcut icon" href="${url.resourcesPath}/favicon/favicon.ico" />
            <link rel="apple-touch-icon" sizes="180x180" href="${url.resourcesPath}/favicon/apple-touch-icon.png" />
            <meta name="apple-mobile-web-app-title" content="Id" />
            <link rel="manifest" href="${url.resourcesPath}/favicon/site.webmanifest" />

            <#if properties.stylesCommon?has_content>
                <#list properties.stylesCommon?split(' ') as style>
                    <link href="${url.resourcesCommonPath}/${style}" rel="stylesheet" />
                </#list>
            </#if>
            <#if properties.styles?has_content>
                <#list properties.styles?split(' ') as style>
                    <link href="${url.resourcesPath}/${style}" rel="stylesheet" />
                </#list>
            </#if>
            <script type="importmap">
                {
                    "imports": {
                        "rfc4648": "${url.resourcesCommonPath}/vendor/rfc4648/rfc4648.js"
                    }
                }
            </script>
            <#if darkMode>
                <script type="module" async blocking="render">
                    const DARK_MODE_CLASS = "${properties.kcDarkModeClass}";
                    const LIGHT_MODE_CLASS = "${properties.kcLightModeClass}";
                    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");

                    updateDarkMode(mediaQuery.matches);
                    mediaQuery.addEventListener("change", (event) => updateDarkMode(event.matches));

                    function updateDarkMode(isEnabled) {
                        const { classList } = document.documentElement;

                        if (isEnabled) {
                            document.documentElement.setAttribute('data-bs-theme', DARK_MODE_CLASS);
                            document.querySelector('meta[name="theme-color"]').setAttribute('content', '#09090b')
                        } else {
                            document.documentElement.setAttribute('data-bs-theme', LIGHT_MODE_CLASS);
                            document.querySelector('meta[name="theme-color"]').setAttribute('content', '#ffffff')
                        }
                    }
                </script>
            </#if>
            <#if properties.scripts?has_content>
                <#list properties.scripts?split(' ') as script>
                    <script src="${url.resourcesPath}/${script}" type="text/javascript"></script>
                </#list>
            </#if>
            <#if scripts??>
                <#list scripts as script>
                    <script src="${script}" type="text/javascript"></script>
                </#list>
            </#if>
            <script type="module" src="${url.resourcesPath}/js/passwordVisibility.js"></script>
            <script type="module" src="${url.resourcesPath}/js/theme.js"></script>
            <script type="module">
                <#outputformat "JavaScript">
                import { startSessionPolling } from ${(url.resourcesPath + "/js/authChecker.js")?c};
                startSessionPolling(${url.ssoLoginInOtherTabsUrl?c});
                </#outputformat>
            </script>
            <script type="module">
                document.addEventListener("click", (event) => {
                    const link = event.target.closest("a[data-once-link]");

                    if (!link) {
                        return;
                    }

                    if (link.getAttribute("aria-disabled") === "true") {
                        event.preventDefault();
                        return;
                    }

                    const { disabledClass } = link.dataset;

                    if (disabledClass) {
                        link.classList.add(...disabledClass.trim().split(/\s+/));
                    }

                    link.setAttribute("role", "link");
                    link.setAttribute("aria-disabled", "true");
                });
            </script>
            <#if authenticationSession??>
                <script type="module">
                    <#outputformat "JavaScript">
                    import { checkAuthSession } from ${(url.resourcesPath + "/js/authChecker.js")?c};
                    checkAuthSession(${authenticationSession.authSessionIdHash?c});
                    </#outputformat>
                </script>
            </#if>
            <script>
                // Workaround for https://bugzilla.mozilla.org/show_bug.cgi?id=1404468
                const isFirefox = true;
            </script>
            <script type="module">
                document.addEventListener("DOMContentLoaded", function () {
                    const btn   = document.getElementById("dropdownBtn");
                    const menu  = document.getElementById("dropdownMenu");
                    if (!btn || !menu) return;

                    function openMenu() {
                        btn.classList.add("show");
                        menu.classList.add("show");
                        btn.setAttribute("aria-expanded","true");

                        // position menu above the button, right-aligned
                        const topOffset  = btn.offsetTop - menu.offsetHeight;
                        menu.style.position = "absolute";
                        menu.style.top  = topOffset + "px";
                        menu.style.right= "0";
                        menu.style.left = "auto";
                    }

                    function closeMenu() {
                        btn.classList.remove("show");
                        menu.classList.remove("show");
                        btn.setAttribute("aria-expanded","false");
                        menu.removeAttribute("style");
                    }

                    btn.addEventListener("click", function (e) {
                        e.stopPropagation();
                        menu.classList.contains("show") ? closeMenu() : openMenu();
                    });

                    document.addEventListener("click", closeMenu);
                });
            </script>
            <script type="module">
                document.addEventListener("DOMContentLoaded", function () {
                    const slides = document.querySelectorAll(".slide-item");
                    const dots = document.querySelectorAll(".slider-dot");
                    let currentIndex = 0;
                    const intervalTime = 5000;

                    // Load the image of a given slide
                    function loadSlideImage(slide) {
                        const img = slide.querySelector("img[data-src]");
                        if (img && !img.src) {
                            img.src = img.dataset.src;

                            if (img.dataset.srcset) {
                                img.srcset = img.dataset.srcset;
                            }
                        }
                    }

                    function showSlide(index) {
                        slides.forEach((slide, i) => {
                            slide.classList.toggle("is-active", i === index);
                            if (i === index) {
                                loadSlideImage(slide);
                            }
                        });
                        dots.forEach((dot, i) => {
                            dot.classList.toggle("is-active", i === index);
                        });
                        currentIndex = index;
                    }

                    function nextSlide() {
                        const nextIndex = (currentIndex + 1) % slides.length;
                        showSlide(nextIndex);
                    }

                    // click on dots to jump to slide
                    dots.forEach((dot, i) => {
                        dot.addEventListener("click", () => showSlide(i));
                    });

                    // Load the first slide immediately
                    loadSlideImage(slides[0]);

                    // Auto-cycle slides
                    setInterval(nextSlide, intervalTime);
                });
            </script>
        </head>

        <body id="keycloak-bg" class="${properties.kcBodyClass!}" data-page-id="login-${pageId}">
            <!-- Content -->
            <div class="${properties.kcLogin!}">
                <div class="${properties.kcLoginContainer!}">
                    <!-- Logo -->
                    <a href="#" class="app-brand auth-cover-brand">
                        <span class="app-brand-logo">
                            <span class="text-primary" style="filter: brightness(0.9) grayscale(0.1);">
                                <@logo.content/>
                            </span>
                        </span>
                        <span class="app-brand-text fw-medium" style="color: #f0f0f0; text-shadow: 2px 2px 4px #333;">${msg("loginTitleHtmlRealm")}</span>
                    </a>
                    <!-- /Logo -->

                    <main class="${properties.kcLoginMain!}">

                        <!-- Left Text -->
                        <div class="d-none d-xl-flex col-xl-8 p-0">

                            <div class="slider slider-cover-bg relative">
                                <!-- Slides -->
                                <div class="slide-item is-active">
                                    <img data-src="${url.resourcesPath}/img/slides/slide-01-large.webp"
                                    data-srcset="
                                            ${url.resourcesPath}/img/slides/slide-01-small.webp 480w,
                                            ${url.resourcesPath}/img/slides/slide-01-medium.webp 1024w,
                                            ${url.resourcesPath}/img/slides/slide-01-large.webp 1920w"
                                    sizes="100vw"
                                    alt="Slide 1"/>
                                    <div class="slide-caption d-none d-md-block">
                                        <h5 class="slide-text">
                                            ${msg("loginSlide1Text")}
                                        </h5>
                                    </div>
                                </div>

                                <div class="slide-item">
                                    <img data-src="${url.resourcesPath}/img/slides/slide-02-large.webp"
                                    data-srcset="
                                            ${url.resourcesPath}/img/slides/slide-02-small.webp 480w,
                                            ${url.resourcesPath}/img/slides/slide-02-medium.webp 1024w,
                                            ${url.resourcesPath}/img/slides/slide-02-large.webp 1920w"
                                    sizes="100vw"
                                    alt="Slide 2"/>
                                    <div class="slide-caption d-none d-md-block">
                                        <h5 class="slide-text">
                                            ${msg("loginSlide2Text")}
                                        </h5>
                                    </div>
                                </div>

                                <div class="slide-item">
                                    <img data-src="${url.resourcesPath}/img/slides/slide-03-large.webp"
                                    data-srcset="
                                            ${url.resourcesPath}/img/slides/slide-03-small.webp 480w,
                                            ${url.resourcesPath}/img/slides/slide-03-medium.webp 1024w,
                                            ${url.resourcesPath}/img/slides/slide-03-large.webp 1920w"
                                    sizes="100vw"
                                    alt="Slide 3"/>
                                    <div class="slide-caption d-none d-md-block">
                                        <h5 class="slide-text">
                                            ${msg("loginSlide3Text")}
                                        </h5>
                                    </div>
                                </div>

                                <div class="slide-item">
                                    <img data-src="${url.resourcesPath}/img/slides/slide-04-large.webp"
                                    data-srcset="
                                            ${url.resourcesPath}/img/slides/slide-04-small.webp 480w,
                                            ${url.resourcesPath}/img/slides/slide-04-medium.webp 1024w,
                                            ${url.resourcesPath}/img/slides/slide-04-large.webp 1920w"
                                    sizes="100vw"
                                    alt="Slide 4"/>
                                    <div class="slide-caption d-none d-md-block">
                                        <h5 class="slide-text">
                                            ${msg("loginSlide4Text")}
                                        </h5>
                                    </div>
                                </div>

                                <div class="slide-item">
                                    <img data-src="${url.resourcesPath}/img/slides/slide-05-large.webp"
                                    data-srcset="
                                            ${url.resourcesPath}/img/slides/slide-05-small.webp 480w,
                                            ${url.resourcesPath}/img/slides/slide-05-medium.webp 1024w,
                                            ${url.resourcesPath}/img/slides/slide-05-large.webp 1920w"
                                    sizes="100vw"
                                    alt="Slide 5"/>
                                    <div class="slide-caption d-none d-md-block">
                                        <h5 class="slide-text">
                                            ${msg("loginSlide5Text")}
                                        </h5>
                                    </div>
                                </div>

                                <!-- Navigation dots -->
                                <div class="slider-dots">
                                    <span class="slider-dot is-active"></span>
                                    <span class="slider-dot"></span>
                                    <span class="slider-dot"></span>
                                    <span class="slider-dot"></span>
                                    <span class="slider-dot"></span>
                                </div>
                            </div>
                        </div>
                        <!-- /Left Text -->

                        <!-- Login -->
                        <div class="d-flex col-12 col-xl-4 align-items-center authentication-bg p-sm-12 p-6">
                            <div class="w-px-400 mx-auto mt-12 pt-5">
                                <h1 class="${properties.kcLoginMainTitle!} fw-bold text-2x1 mb-1" id="kc-page-title"><#nested "header"></h1>

                                <div class="${properties.kcLoginMainBody!}">
                                    <#if !(auth?has_content && auth.showUsername() && !auth.showResetCredentials())>
                                        <#if displayRequiredFields>
                                            <div class="${properties.kcContentWrapperClass!}">
                                                <div class="mb-6 ${properties.kcLabelWrapperClass!} subtitle">
                                                    <span class="${properties.kcInputHelperTextItemTextClass!}">
                                                        <span class="${properties.kcInputRequiredClass!}">*</span> ${msg("requiredFields")}
                                                    </span>
                                                </div>
                                            </div>
                                        </#if>
                                    <#else>
                                        <#if displayRequiredFields>
                                            <div class="${properties.kcContentWrapperClass!}">
                                                <div class="mb-6 ${properties.kcLabelWrapperClass!} subtitle">
                                                    <span class="${properties.kcInputHelperTextItemTextClass!}">
                                                        <span class="${properties.kcInputRequiredClass!}">*</span> ${msg("requiredFields")}
                                                    </span>
                                                </div>
                                                <div class="${properties.kcFormClass!} ${properties.kcContentWrapperClass!}">
                                                    <#nested "show-username">
                                                    <@username />
                                                </div>
                                            </div>
                                        <#else>
                                            <div class="${properties.kcFormClass!} ${properties.kcContentWrapperClass!}">
                                                <#nested "show-username">
                                                <@username />
                                            </div>
                                        </#if>
                                    </#if>

                                    <#-- App-initiated actions should not see warning messages about the need to complete the action -->
                                    <#-- during login.                                                                               -->
                                    <#if displayMessage && message?has_content && (message.type != 'warning' || !isAppInitiatedAction??)>

                                        <#if message.type = 'error'>
                                            <#assign alertTypeClass = 'alert-outline-danger'>
                                        <#elseif message.type = 'success'>
                                            <#assign alertTypeClass = 'alert-outline-success'>
                                        <#elseif message.type = 'warning'>
                                            <#assign alertTypeClass = 'alert-outline-success'>
                                        <#elseif message.type = 'info'>
                                            <#assign alertTypeClass = 'alert-outline-success'>
                                        <#else>
                                            <#assign alertTypeClass = 'alert-outline-secondary'>
                                        </#if>

                                        <div class="${properties.kcAlertClass!} ${alertTypeClass}">
                                            <div class="${properties.kcAlertIconClass!}">
                                                <#if message.type = 'success'><span class="${properties.kcFeedbackSuccessIcon!}"></span></#if>
                                                <#if message.type = 'warning'><span class="${properties.kcFeedbackWarningIcon!}"></span></#if>
                                                <#if message.type = 'error'><span class="${properties.kcFeedbackErrorIcon!}"></span></#if>
                                                <#if message.type = 'info'><span class="${properties.kcFeedbackInfoIcon!}"></span></#if>
                                            </div>
                                            <span class="${properties.kcAlertTitleClass!} kc-feedback-text">${kcSanitize(message.summary)?no_esc}</span>
                                        </div>
                                    </#if>

                                    <#nested "form">

                                    <#if auth?has_content && auth.showTryAnotherWayLink()>
                                        <form id="kc-select-try-another-way-form" action="${url.loginAction}" method="post" novalidate="novalidate">
                                            <input type="hidden" name="tryAnotherWay" value="on"/>
                                            <a id="try-another-way" href="javascript:document.forms['kc-select-try-another-way-form'].requestSubmit()"
                                            class="${properties.kcButtonSecondaryClass} ${properties.kcButtonBlockClass} ${properties.kcMarginTopClass}">
                                                ${kcSanitize(msg("doTryAnotherWay"))?no_esc}
                                            </a>
                                        </form>
                                    </#if>

                                    <div class="${properties.kcLoginMainFooter!}">
                                        <#nested "socialProviders">

                                        <#if displayInfo>
                                            <div id="kc-info" class="${properties.kcLoginMainFooterBand!} ${properties.kcFormClass!}">
                                                <div id="kc-info-wrapper" class="${properties.kcLoginMainFooterBandItem!}">
                                                    <#nested "info">
                                                </div>
                                            </div>
                                        </#if>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /Login -->

                        <div class="${properties.kcLoginMainFooter!}">
                            <@loginFooter.content/>
                        </div>
                    </main>
                </div>
            </div>

            <!-- /Content -->

        </body>
    </html>
</#macro>
