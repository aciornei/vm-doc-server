<#import "template.ftl" as layout>
<#import "field.ftl" as field>
<#import "buttons.ftl" as buttons>
<@layout.registrationLayout displayInfo=true displayMessage=!messagesPerField.existsError('username'); section>
    <#if section = "header">
        <h1 class="fw-bold text-2x1 mb-1">${msg("emailForgotTitle")}</h1>

        <#if realm.duplicateEmailsAllowed>
            <p class="mb-6">${msg("emailInstructionUsername")}</p>
        <#else>
            <p class="mb-6">${msg("emailInstruction")}</p>
        </#if>
    <#elseif section = "form">
        <form id="kc-reset-password-form" class="${properties.kcFormClass!}" action="${url.loginAction}" method="post">
            <#assign label>
                <#if !realm.loginWithEmailAllowed>${msg("username")}<#elseif !realm.registrationEmailAsUsername>${msg("usernameOrEmail")}<#else>${msg("email")}</#if>
            </#assign>

            <#if !realm.loginWithEmailAllowed>
                <#assign usernamePlaceholder = msg('usernamePlaceholder')>
            <#elseif !realm.registrationEmailAsUsername>
                <#assign usernamePlaceholder = msg('usernameOrEmailPlaceholder')>
            <#else>
                <#assign usernamePlaceholder = msg('emailPlaceholder')>
            </#if>
            <@field.input name="username" label=label value=auth.attemptedUsername!'' autofocus=true placeholder="${kcSanitize(usernamePlaceholder)?no_esc}"/>

            <@buttons.actionGroup>
              <@buttons.button id="kc-form-buttons" label="doSubmit" class=["kcButtonPrimaryClass", "kcButtonBlockClass"]/>
              <div class="mt-6 text-center">
                <@buttons.buttonLink href=url.loginUrl label="backToLogin" class=["kcButtonSecondaryClass", "kcButtonBlockClass", "kcButtonLinkClass"]/>
              </div>
            </@buttons.actionGroup>

        </form>
    <#elseif section = "info" >

    </#if>
</@layout.registrationLayout>