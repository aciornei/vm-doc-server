const themeSwitch = document.getElementById('themeSwitch')

// Your existing function
const setTheme = theme => {
  if (theme === 'system') {
    document.documentElement.setAttribute(
      'data-bs-theme',
      window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
    )
  } else {
    document.documentElement.setAttribute('data-bs-theme', theme)
  }
  localStorage.setItem('theme', theme) // remember choice
}

// Toggle listener
if (themeSwitch) themeSwitch.addEventListener('change', e => {
  if (e.target.checked) {
    setTheme('dark')
  } else {
    setTheme('light')
  }
})

// Keep in sync with OS theme when user wants “system”
const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
mediaQuery.addEventListener('change', () => {
  if (localStorage.getItem('theme') === 'system') {
    setTheme('system')
  }
});

// On page load: apply stored or system theme and set switch position
(function initTheme () {
  const saved = localStorage.getItem('theme') || 'system'
  setTheme(saved)

  // If saved is system, reflect the *current* OS setting in the switch
  if (saved === 'system') {
    if (themeSwitch) themeSwitch.checked = mediaQuery.matches
  } else {
    if (themeSwitch) themeSwitch.checked = saved === 'dark'
  }
})()
