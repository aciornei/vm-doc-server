<#macro content>
    <#-- The footer at the bottom of the "login-box". You can override this file in your custom theme to declare a custom login footer element -->
    <div class="link-wrapper">
        <a href="https://wiki.sts.ro/s/74fb70c2-4474-47e7-ae2d-7569a071f469" target="_blank" rel="noopener noreferrer">
            ${msg("footerLinkIntegrationGuide")}
        </a>

        <#if realm.internationalizationEnabled  && locale.supported?size gt 1>
            <i class="breadcrumb-icon icon-base ti tabler-minus-vertical align-middle icon-xs"></i>

            <div class="dropdown">
                <button
                id="dropdownBtn"
                type="button"
                class="btn btn-text-secondary rounded-pill text-body-secondary border-0 p-2 me-n1"
                data-bs-toggle="dropdown"
                aria-label="Select language"
                aria-haspopup="true"
                aria-expanded="false">
                    <i class="icon-base ti tabler-language text-body-secondary"></i>
                </button>
                <ul id="dropdownMenu" class="dropdown-menu dropdown-menu-end">
                    <#list locale.supported?sort_by("label") as l>
                        <li><a class="dropdown-item <#if l.languageTag == locale.currentLanguageTag>active</#if>" href="${l.url}">${l.label}</a></li>
                    </#list>
                </ul>
            </div>
        </#if>

        <i class="breadcrumb-icon icon-base ti tabler-minus-vertical align-middle icon-xs"></i>

        <label class="switch">
            <input type="checkbox" class="switch-input" id="themeSwitch" aria-label="Toggle theme"/>
            <span class="switch-toggle-slider">
                <span class="switch-on">
                    <i class="icon-base ti tabler-sun"></i>
                </span>
                <span class="switch-off">
                    <i class="icon-base ti tabler-moon"></i>
                </span>
            </span>
        </label>
    </div>
</#macro>
