# 0.20.56

- schimbă semantica **Ascunde porturile ascultate**: se ascunde numai lista completă detectată, nu și porturile/procesele marcate explicit **Principal**;
- când lista completă este ascunsă, VM-ul afișează separat numai porturile principale selectate;
- fișa VM și Markdown-ul/Outline omit complet secțiunea **Porturi ascultate**, dar păstrează **Porturi și procese principale** dacă există selecții;
- publicarea individuală **Trimite în Outline** rulează acum asincron ca job de fundal, pentru a evita `504 Gateway Timeout` pe request-ul browser → VM-DOC;
- păstrează organizarea Documente → Publică în Outline pe două rânduri și preview-ul serviciilor cu carduri clicabile, paginare și Export Excel;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.55

- hotfix pentru testul introdus în 0.20.54 la ascunderea porturilor ascultate;
- corectează `vm_listening_ports_test.go` pentru structura curentă `inventory.DocumentSection`, folosind câmpul `Title` în loc de câmpul inexistent `Label`;
- nu schimbă funcționalitatea aplicației, schema DB sau agentul.

# 0.20.54

- adaugă pe fiecare VM opțiunea **Ascunde porturile ascultate**, utilă pentru servere AD/DNS cu multe porturi RPC dinamice;
- când opțiunea este activă, secțiunea `Porturi ascultate` și porturile/procesele principale nu mai apar în interfața VM, nici în JSON-ul brut afișat din interfață și nici în fișa/documentația VM;
- criteriul de completare pentru port/proces principal este considerat satisfăcut pentru VM-urile la care porturile sunt ascunse intenționat;
- reorganizează **Documente → Publică în Outline** pe două rânduri complete: VM-uri pe primul rând, Servicii pe al doilea;
- rezultatul verificării serviciilor Outline are acum carduri clicabile pentru filtrare, paginare 10/25/50/100/200 și memorarea dimensiunii paginii;
- adaugă **Export Excel** pentru verificarea serviciilor Outline; exportul respectă cardul/filtrul selectat și exportă toate rândurile filtrate, nu doar pagina vizibilă;
- include migrarea `065_vm_hide_listening_ports.up.sql`; vm-doc-agent neschimbat.

# 0.20.53

- repară `504 Gateway Timeout` la **Verifică serviciile** înainte de publicarea în Outline;
- dry-run-ul serviciilor rulează acum **asincron**, ca job de fundal, la fel ca publicarea în masă;
- request-ul HTTP pornește jobul și răspunde imediat cu `202 Accepted`, astfel încât timeout-ul Nginx/HAProxy nu mai întrerupe verificarea;
- UI afișează progresul `servicii X/Y` și serviciul verificat curent, apoi încarcă automat sumarul și tabelul complet;
- validările existente rămân neschimbate: link Outline, acces document, stare serviciu, bifa Outline, generare Markdown și protecția Vault;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.52

- adaugă **dry-run obligatoriu** înainte de publicarea în masă a serviciilor în Outline;
- `Documente → Publică în Outline → Servicii` afișează mai întâi **Verifică serviciile** și numai după verificare butonul **Publică serviciile eligibile**;
- verificarea controlează: serviciu activ/neretras, bifa Outline, Link documentație, document Outline existent și accesibil, plus generarea conținutului Markdown;
- sumarul dry-run arată: total, eligibile, fără link, excluse Outline, inactive/retrase, erori link și erori conținut; tabelul explică motivul pentru fiecare serviciu;
- publicarea primește exact ID-urile eligibile din dry-run și reverifică starea curentă înainte de fiecare update;
- după finalizarea jobului este necesară o nouă verificare înainte de republicare;
- adaugă protecție runtime care blochează publicarea dacă URL-ul Vault ar apărea accidental în Markdown-ul Outline;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.51

- mută **Publicare Outline** și **Vault** exclusiv pe prima pagină a VM-ului, în **Rezumat**;
- în Rezumat, cele două panouri sunt afișate compact pe același rând: Publicare Outline în stânga și Vault în dreapta;
- elimină complet Publicare Outline și Vault din `Configurare → Infrastructură`;
- elimină afișarea redundantă `Se publică în Outline` din panoul Identificare și încadrare, starea rămânând în panoul dedicat Publicare Outline;
- Servicii → Detalii → Vault rămâne neschimbat; linkurile Vault rămân strict interne aplicației și nu intră în fișe, Outline sau exporturi de documentație;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.50

- compactează zona VM → Configurare/Infrastructură: **Publicare Outline** și **Vault** sunt afișate pe același rând, în două coloane;
- adaugă `vault_url` strict intern aplicației pentru VM-uri și servicii;
- pe VM, linkul Vault se editează din panoul din dreapta și este clicabil imediat sub textbox când există;
- în Servicii → Detalii adaugă subtab-ul **Vault**, cu textbox și link clicabil;
- linkurile Vault sunt excluse explicit din fișele DOCX/Markdown/PDF, exporturile de documentație și toate publicările Outline;
- include teste de regresie care verifică faptul că URL-ul Vault nu ajunge în Markdown/Outline sau în DOCX;
- include migrarea `064_vault_links_internal_only.up.sql`; vm-doc-agent neschimbat.

# 0.20.49

- elimină coloana `Hostname` din tabelul **Inventar VM** publicat în Outline;
- lista VM din aplicație și exporturile Excel rămân neschimbate;
- tabelul publicat rămâne: `VM | Power | CPU / RAM | Mediu | OS | Suport OS | IP | Servicii | Outline | Ultima publicare Outline`;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.48

- adaugă pagina **Releasuri** în navigația principală, cu istoricul versiunilor serverului;
- fiecare release afișează în forma colapsată `Versiune`, `Data` și `Modificarea principală`;
- click pe release deschide detaliile complete ale modificărilor; toate intrările sunt colapsate implicit;
- versiunea serverului aflată în execuție este evidențiată în listă;
- istoricul 0.20.4 → versiunea curentă este inclus ca resursă statică în binarul aplicației;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.47

- Rafinează tabelul publicat din Inventar VM în Outline: elimină `vCenter`, `Agent`, `Completare` și `Ultimul JSON` și adaugă `Hostname`.
- Power este afișat compact `ON` / `OFF`; starea `SUSPENDED` rămâne explicită dacă apare.
- Mediu este normalizat la `PROD` / `TEST` / `DEV` pentru valorile uzuale.
- Numele VM este link către pagina sa Outline atunci când există mapping în `outline_vm_documents_global`.
- Serviciile din tabel sunt linkuri către `internal_services.documentation_url` atunci când au Link documentație; altfel rămân text simplu.
- Butonul **Publică tabelul în Outline** apare în lista VM numai dacă Outline este activ global, destinația `vm_inventory` este activă și are document/link configurat.
- Endpoint-ul de publicare validează server-side aceleași condiții înainte să modifice pagina Outline.
- Fără migrare DB; agent neschimbat.

## 0.20.46

- Hotfix test export VM: `TestVMExportRowsUsesInventoryValues` a fost actualizat pentru schema curentă de 26 coloane.
- Au fost corectați indicii coloanelor după introducerea `Mediu` și `OS suportat`.
- Fără modificări funcționale, fără migrare DB, agent neschimbat.

## 0.20.45

- Lista principală VM adaugă filtrele `Outline: Toate/DA/NU` și `OS suportat: Toate/DA/NU`; aceleași filtre se aplică listei paginate, exportului Excel și publicării tabelului în Outline.
- `OS suportat = DA` include numai VM-urile determinate ca suportate conform nomenclatorului `unsupported_os`; `NU` include numai VM-urile potrivite explicit pe o regulă activă; cazurile nedeterminate rămân la `Toate`.
- Adaugă butonul **Publică tabelul în Outline** în lista VM; sunt publicate toate VM-urile rezultate din filtrele curente, nu doar pagina vizibilă.
- Adaugă destinații generice de publicare Outline, configurabile din **Documente → Configurare Outline → Destinații publicare**; prima destinație este `vm_inventory` / **Inventar VM**.
- Destinația indică o pagină Outline existentă; VM-DOC îi păstrează titlul și actualizează conținutul tabelului. Configurația reține URL-ul/document ID-ul rezolvat și data ultimei publicări.
- Tabelul publicat include VM, stare vCenter, Power, CPU/RAM, mediu, OS, suport OS, IP, agent/stare/versiune, servicii, Outline DA/NU, ultima publicare a fișei VM, completare și ultimul JSON.
- Publicarea este blocată dacă filtrele curente nu întorc niciun VM, pentru a nu suprascrie accidental pagina cu un tabel gol.
- Exportul Excel VM include acum și `Mediu` și `OS suportat`.
- Include migrarea `063_outline_publication_targets.up.sql`; vm-doc-agent nu necesită update.

## 0.20.44

- Documente → Publică în Outline verifică explicit bifa `Nu se publică în Outline` înainte de publicarea fiecărui VM.
- VM-urile excluse sunt sărite, nu sunt trimise către Outline și nu sunt raportate ca erori.
- Jobul bulk afișează separat numărul de VM-uri publicate și sărite.
- Verificarea este dublă: înainte de apelul de publicare și din nou în fluxul individual `publishVMToOutline`.
- Fără migrare DB; agent neschimbat.

## 0.20.43

- Raportul Suport sisteme de operare afișează serviciile interne asociate fiecărui VM.
- Filtrul VM pornit/oprit pornește implicit pe Pornit; Reset filtre revine la Pornit.
- Cardurile reflectă căutarea și filtrele generale, inclusiv filtrul implicit Pornit.
- Spațiere îmbunătățită între filtre, carduri, grafice și tabel.
- Rândul cu contor, Export Excel și nomenclator are padding pe toată lățimea.
- Exportul Excel Suport OS include coloana Servicii.
- Fără migrare DB și fără update de agent.

## 0.20.42

- Lista principală VM are coloana `Outline` cu `DA/NU`, calculată strict din `outline_documentation_disabled`.
- Lista VM afișează `Ultima publicare Outline` din `outline_vm_documents_global.last_synced_at` pentru targetul `virtualization`.
- VM-urile nepulicate încă afișează `—` la data ultimei publicări.
- Exportul Excel VM include aceleași două coloane.
- Fără migrare DB; agent neschimbat.

## 0.20.41

- Raportul **Suport sisteme de operare** afișează filtrele înaintea cardurilor și a restului conținutului.
- Cardurile **VM-uri / Suportate / Nesuportate / Nedeterminat** se recalculează după căutare, power state, mediu și Outline; filtrul de stare rămâne dimensiunea selectabilă prin carduri.
- Graficele sunt mutate într-un bloc colapsat implicit și se recalculează după căutare și filtrele generale.
- Tabelul este paginat local după filtrare, cu opțiuni 10 / 25 / 50 / 100 / 200 rânduri pe pagină; preferința este păstrată în browser.
- Exportul Excel continuă să folosească toate filtrele active, independent de pagina curentă.
- Fără migrare DB; agent neschimbat.

## 0.20.40

- repară binding-ul filtrelor pentru `Suport sisteme de operare`, `Outline · VM-uri` și `Outline · Servicii`;
- cardurile de sumar aplică acum imediat filtrul corespunzător și actualizează contorul + URL-ul de export Excel;
- select-urile aplică filtrul la `change`, iar câmpul de căutare filtrează la tastare și la Enter;
- adaugă butoanele `Caută / Aplică` și `Resetează` în cele trei rapoarte;
- mută listener-ele după randarea DOM-ului, eliminând regresia introdusă în 0.20.39;
- fără migrare DB și fără update de vm-doc-agent.

## 0.20.39

- separă raportul `Publicare Outline` în două rapoarte independente: `Outline · VM-uri` și `Outline · Servicii`;
- VM-uri: filtre după publicare, Pornit/Oprit, mediu, motiv și căutare; cardurile Total/Se publică/Nu se publică/Pornite/Oprite sunt clicabile;
- servicii: filtre după publicare, stare Activ/Inactiv/Retras, criticitate, status documentație, motiv și căutare; cardurile sunt clicabile;
- exporturile Excel pentru cele două rapoarte Outline respectă exact filtrele curente;
- raportul `Suport sisteme de operare` primește filtre după stare suport, Pornit/Oprit, mediu, Outline și căutare, cu carduri clicabile și export Excel filtrat;
- migrarea `062_reports_filters_unsupported_os_seed.up.sql` schimbă unicitatea nomenclatorului în `(category_code,name,item_code)` și prepopulează idempotent familiile/versiunile EOL standard pentru Ubuntu, Debian, CentOS Linux și Windows legacy;
- fără update de vm-doc-agent.

## 0.20.38

- corectează eroarea `bad_request` la salvarea bifei VM **Nu se publică în Outline** și acceptă temporar și aliasul vechi/greșit `outlin_documentation_disabled`;
- adaugă migrarea reparatorie `061_outline_schema_repair.up.sql`, care recreează idempotent coloanele/indexurile Outline dacă migrarea 058 a fost înregistrată incomplet;
- rapoartele **Publicare Outline** și **Suport sisteme de operare** verifică schema înainte de a folosi coloanele Outline și nu mai cad cu HTTP 500 dacă acestea lipsesc;
- revalidează categoria `unsupported_os` în migrarea 061;
- update exclusiv server/UI/DB, fără update de vm-doc-agent.

## 0.20.37

- adaugă nomenclatorul `Sisteme de operare nesuportate`, cu familie OS și versiune/familie de versiune;
- adaugă raportul `Suport sisteme de operare` cu trei pie chart-uri și liste separate pentru VM-uri suportate, nesuportate și cu suport nedeterminat;
- raportul OS include VM, hostname, mediu, IP, OS/versiune, regula potrivită și starea de publicare Outline;
- adaugă raportul `Publicare Outline` pentru VM-uri și servicii, cu pie chart-uri, motivul excluderii și export Excel;
- în Rezumat VM și Rezumat Serviciu este afișată starea efectivă `Se publică în Outline: Da/Nu`, inclusiv motivul;
- include migrarea `060_unsupported_os_nomenclature.up.sql`; vm-doc-agent nu necesită update.

## 0.20.36

- corectează bifa **Componentă suport** astfel încât salvarea să fie inline, fără reîncărcarea fișei VM și fără schimbarea tabului/subsecțiunii curente;
- după bifare, rândul serviciului se deschide automat și afișează imediat editorul pentru **Componentă propusă**, **Versiune manuală** și **Port(uri) manual**;
- endpoint-ul de salvare întoarce componenta îmbogățită cu versiunea și porturile detectate, astfel încât valorile automate sunt vizibile imediat;
- salvarea override-urilor rămâne în același loc și actualizează editorul fără refresh;
- fără migrare DB nouă și fără update de vm-doc-agent.

## 0.20.35

- adaugă pe serviciile observate de agent din pagina VM bifa **Componentă suport**, independentă de marcajul **Principal**;
- normalizează automat denumiri uzuale precum PostgreSQL, Redis, Meilisearch, MinIO, Docmosis, Sentry și Keycloak, dar permite editarea numelui canonic pentru orice tehnologie;
- versiunea este preluată automat din `version` / `package_version`; versiunea și porturile pot avea override manual per VM/serviciu;
- corelează automat porturile atunci când procesul/executabilul poate fi asociat în mod sigur cu tehnologia selectată;
- adaugă raportul **Rapoarte → Componente suport**, grupat **Componentă → Versiune → Mediu**, cu VM/amplasare, hostname, IP, porturi, servicii/proiecte asociate și serviciul agent;
- raportul are filtre și export Excel în aceeași structură logică;
- include migrarea `059_vm_support_components.up.sql`; vm-doc-agent rămâne neschimbat.

## 0.20.34

- afișează controlul VM **Nu se publică în Outline** direct în **Rezumat**, astfel încât opțiunea să fie vizibilă imediat la deschiderea VM-ului;
- păstrează același control și în **Configurare → Infrastructură**; ambele folosesc câmpul persistent `outline_documentation_disabled`;
- după salvare rămâne deschisă secțiunea curentă a VM-ului;
- fără migrare DB nouă și fără update de vm-doc-agent.

## 0.20.33

- ascunde temporar din interfața **Documente → Export / Publică** butoanele de export PDF; endpoint-urile PDF rămân disponibile în backend pentru reluarea ulterioară a funcției;
- adaugă lifecycle explicit pentru servicii: **Retras / scos din uz**, motiv de retragere din nomenclator și data retragerii; marcarea ca retras dezactivează automat serviciul;
- adaugă nomenclatorul editabil `service_retirement_reason`, cu valori inițiale pentru scos din uz, înlocuit/migrat, proiect închis, contract încheiat și alt motiv;
- adaugă bifa independentă **Nu se documentează în Outline**, utilizabilă inclusiv pentru servicii active; serviciile retrase sau excluse explicit nu sunt publicate și nu sunt folosite drept linkuri Outline din fișele VM;
- butoanele Outline din fișa VM și din fișa serviciului sunt afișate numai când integrarea Outline este activată global în **Documente**;
- fișa tehnică și operațională a serviciului include starea lifecycle și, pentru serviciile retrase, motivul și data retragerii;
- adaugă pe VM bifa independentă **Nu se publică în Outline**; publicarea individuală, publicarea în masă și linkurile VM din fișele serviciilor respectă această excludere;
- dacă mapping-ul unei VM indică o pagină Outline care a fost ștearsă, publicarea verifică existența documentului și îl recreează automat sub **Virtualizare**, actualizând mapping-ul local;
- include migrarea `058_service_lifecycle_outline_controls.up.sql`; vm-doc-agent rămâne neschimbat.

## 0.20.32

- separă pagina **Documente** în două zone: **Export / Publică** și **Șabloane**, folosind aceeași navigare pe taburi ca paginile de inventar;
- publicarea Outline a VM-urilor folosește ca titlu exact numele VM-ului din vCenter, fără prefixul `VM —` și fără preferință pentru guest hostname;
- fișa VM publicată în Outline transformă serviciile asociate în linkuri Outline atunci când serviciul are configurat **Link documentație** către aceeași instanță Outline;
- fișa serviciului publicată în Outline transformă VM-urile asociate în linkuri către paginile lor Outline din categoria **Virtualizare**; linkurile interne VM-DOC nu mai sunt inserate în conținutul Outline;
- adaugă publicarea serviciilor din fișa serviciului și publicarea în masă din **Documente → Export / Publică**; serviciul este actualizat numai în pagina indicată de **Link documentație**, fără creare, redenumire sau mutare automată;
- la publicarea în masă a serviciilor, serviciile fără Link documentație sunt sărite și raportate separat, iar erorile unui serviciu nu opresc restul jobului;
- câmpul **Virtualizare · Document / URL** acceptă UUID, slug sau URL Outline și este rezolvat automat la UUID-ul real la salvare;
- testul Outline afișează explicit când integrarea este dezactivată și propagă mesajele HTTP reale de la API-ul Outline în locul unui `500` generic;
- nu adaugă migrare DB și nu necesită update de vm-doc-agent.

## 0.20.31

- schimbă modelul Outline: proiectele/serviciile nu mai sunt publicate automat și VM-urile nu mai sunt grupate sub proiecte;
- introduce ținta Outline **Virtualizare**, configurată prin propriul `Document ID`; toate fișele VM sunt create direct ca pagini copil sub acest document;
- publicarea individuală din fișa VM nu mai cere alegerea unui proiect; mapping-ul Outline este global per VM și categorie, astfel încât aceeași VM să nu fie duplicată din cauza asocierilor la mai multe proiecte;
- publicarea în masă din **Documente → Outline** lucrează direct cu VM-urile și păstrează filtrul **Doar VM-uri pornite** bifat implicit;
- configurația Outline este pregătită pentru categorii cu părinți diferiți prin tabelul `outline_targets`; prima țintă este `virtualization`;
- dacă ID-ul documentului părinte Virtualizare se schimbă, paginile VM deja mapate sunt mutate automat la noul părinte prin API-ul Outline;
- butonul de publicare Outline este eliminat din fișa proiectului; pentru servicii se folosește în continuare câmpul existent **Link documentație**;
- include migrarea `057_outline_virtualization_target.up.sql`; vm-doc-agent rămâne neschimbat.

## 0.20.30

- adaugă integrarea directă cu Outline prin API key Bearer, configurabilă din pagina **Documente**; cheia este criptată în DB cu cheia master VM-DOC;
- fiecare proiect/serviciu intern este publicat ca document Outline, iar fișele VM sunt publicate ca documente copil sub proiectul ales;
- adaugă buton **Trimite în Outline** în fișa proiectului și în fișa VM; VM-urile asociate mai multor proiecte permit alegerea proiectului destinație;
- adaugă în **Documente → Outline** publicare în masă asincronă, cu progres, opțiunea **Include fișele VM** și filtrul **Doar VM-uri pornite**;
- publicarea este idempotentă la nivel de mapping: paginile create sunt actualizate la următoarele publicări și sunt recreate dacă mapping-ul indică un document șters;
- conținutul este Markdown derivat din aceeași structură documentară ca fișele VM/Serviciu și nu include câmpul vizibil **Generat de**;
- folosește numărul electronic și data ultimei fișe generate atunci când acestea există;
- adaugă Audit pentru configurare, test de conexiune, publicare individuală și publicare bulk Outline;
- include migrarea `056_outline_integration.up.sql`; vm-doc-agent rămâne neschimbat.

## 0.20.29

- exportul bulk **VM DOCX** primește opțiunea **Doar VM-uri pornite**, bifată implicit; când este activă sunt incluse numai VM-urile active/neretrase cu `power_state=POWERED_ON`, iar debifarea revine la toate VM-urile active/neretrase;
- regenerarea fișelor VM se aplică numai setului selectat de filtrul de power state și continuă să genereze documente fără rândul vizibil **Generat de**;
- exportul bulk **Proiecte DOCX** primește opțiunea **Regenerează toate fișele proiectelor înainte de export**, implicit debifată; aceasta creează o versiune nouă pentru fiecare proiect activ folosind șablonul implicit și fără **Generat de**;
- dacă sunt bifate simultan **Regenerează** și **Generează dacă nu există**, regenerarea tuturor proiectelor are prioritate;
- celelalte opțiuni ale proiectelor rămân implicit debifate, iar exporturile PDF nu sunt modificate;
- nu există migrare DB nouă și agentul rămâne neschimbat.

## 0.20.28

- extinde exportul bulk DOCX al VM-urilor cu opțiunea **Regenerează toate fișele VM înainte de export**; opțiunea este implicit debifată și folosește șablonul VM implicit;
- fișele VM regenerate de exportul bulk și fișele de proiect generate automat de export nu includ rândul vizibil **Generat de**; utilizatorul rămâne păstrat în istoricul documentului și în Audit;
- exportul bulk DOCX al proiectelor primește două opțiuni independente și implicit debifate: **Generează fișa proiectului dacă nu există** și **Include și fișele VM asociate proiectelor**;
- fișele VM asociate proiectelor sunt incluse separat în directorul `VM-uri/<proiect>/` din arhivă, fără regenerare automată; VM-urile fără fișă apar explicit în `_manifest.csv`;
- exporturile PDF rămân neschimbate în această versiune; opțiunile noi sunt aplicate numai DOCX;
- nu există migrare DB nouă și agentul rămâne neschimbat.

## 0.20.27

- adaugă patru exporturi în masă din pagina **Documente**: arhivă ZIP cu fișele tuturor VM-urilor în DOCX, toate VM-urile în PDF, toate proiectele/serviciile în DOCX și toate proiectele/serviciile în PDF;
- fiecare export folosește **ultima fișă deja generată** pentru fiecare VM activ/neretras sau proiect activ și nu creează versiuni noi în istoricul documentelor;
- arhivele includ `_manifest.csv`, `_sumar.txt` și `_README.txt`, astfel încât obiectele fără fișă sau conversiile eșuate să fie vizibile explicit;
- exportul PDF convertește DOCX-urile în loturi prin LibreOffice/soffice, cu profil temporar izolat, cleanup automat și suport pentru executabil configurat prin `VM_DOC_SOFFICE_BIN`;
- descărcarea ZIP este transmisă incremental, cu buffering Nginx dezactivat pentru request, pentru a suporta volume mari de fișe fără a încărca întreaga arhivă în memorie;
- nu există migrare DB nouă și agentul rămâne neschimbat.

## 0.20.26

- adaugă inventar manual **Echipamente** pentru dispozitive medicale, echipamente de laborator, appliance-uri, servere fizice, storage, IoT și alte resurse care nu sunt VM-uri;
- fiecare echipament poate avea tip din nomenclator, producător, model, serie, hostname, IP-uri, MAC, locație, responsabil, descriere, observații și link de documentație;
- echipamentele se leagă many-to-many la proiecte/servicii interne; aceeași pereche echipament–serviciu poate avea mai multe fluxuri distincte cu rol, protocol, port, sens, scop și observații;
- pagina Serviciului primește secțiunea **Echipamente**, cu adăugare/editare/ștergere a asocierilor, iar pagina echipamentului arată toate serviciile asociate;
- schema serviciului, căutarea globală, Auditul contextual și fișele Serviciu DOCX/Markdown includ echipamentele; ștergerea/comasarea proiectelor contabilizează și mută asocierile de echipamente;
- adaugă nomenclatorul editabil `device_type`, permisiunile `equipment.read` / `equipment.manage` și migrarea `055_equipment_inventory.up.sql`; agentul rămâne neschimbat.

## 0.20.25

- permite mai multe dependențe explicite între aceleași două servicii cu același tip de relație și aceleași medii; fiecare `Adaugă dependență` creează un flux separat în loc să suprascrie primul rând;
- protocolul, portul și câmpul `Scop / detalii` diferențiază fluxurile (de exemplu syslog și API către același serviciu);
- schema vizuală a serviciului, `Depinde de` / `Este utilizat de`, dependențele vizibile pe VM și fișele DOCX/Markdown păstrează toate fluxurile distincte;
- auditul `service.dependency.create` include ID-ul concret al dependenței și detaliile fluxului;
- fără migrare DB și fără update de agent.

## 0.20.24

- transformă prima pagină într-un dashboard operațional: căutare globală, KPI-uri de atenție, listă de lucru, modificări recente, stare colectări/sincronizări, acoperire, HA și servicii cu lipsuri;
- căutarea globală găsește VM-uri după nume/hostname/IP, servicii, persoane, containere Docker, instanțe/cataloguri DB și configurații Web/LB și navighează direct la contextul relevant;
- KPI-urile sunt clickabile și deschid liste prefiltrate pentru agenți offline, inventar vechi, backup, monitorizare și documentație incompletă;
- „Necesită atenție” permite filtrare rapidă pe Agent, Backup, Monitorizare, Documentație și HA și afișează serviciile, responsabilii și ultima colectare;
- „Grad de acoperire” arată procentul pentru servicii asociate, responsabili, backup, monitorizare, baseline, fișe VM și fișe servicii;
- dashboardul evidențiază grupurile HA cu noduri problematice sau diferențe de volum ale resurselor Docker/DB/Web și serviciile care necesită completări;
- Rapoarte → Lipsuri operaționale acceptă filtrul agregat „Documentație incompletă”, iar linkurile din dashboard pot deschide direct filtrul dorit;
- nu adaugă migrare DB și nu necesită update de agent.

## 0.20.23

- face auditul lizibil: resursele cunoscute sunt afișate cu nume și context (VM/servicii) în loc de identificatori tehnici izolați precum `docker_container #677`; ID-ul rămâne vizibil pentru diagnostic;
- adaugă fila **Audit** direct în fișa VM și în fișa Serviciului intern, cu filtre după căutare, zonă, actor, sursă, acțiune, tip resursă, rezultat și interval de timp;
- auditul VM include evenimentele resurselor Docker, DB, Web, software, modificărilor de inventar, documentelor și agentului care pot fi corelate cu VM-ul;
- auditul Serviciului include evenimentele directe și resursele Docker/DB/Web/documente/anexe asociate; pentru noile modificări de asociere se păstrează uniunea serviciilor înainte/după astfel încât și eliminările să rămână regăsibile;
- adaugă în **Rapoarte → Persoane & responsabilități** relația Persoană → VM → rol → mediu → servicii, cu filtre și export Excel;
- adaugă **Rapoarte → Lipsuri operaționale** pentru VM fără responsabil, serviciu, mediu, agent/inventar actual, backup, monitorizare, baseline sau fișă VM, cu filtre și export Excel;
- nu adaugă migrare DB și nu necesită update de agent.

## 0.20.22

- curăță istoricul de modificări VM de câmpurile volatile din NTP/chrony (`tracking_summary` și starea runtime per peer);
- `node_exporter` nu mai generează modificări pentru `metrics_checked_at`, `metric_sample_count`, reachability/status HTTP sau erori de probe;
- regulile nftables sunt comparate semantic: contoarele `packets/bytes` și `# handle` sunt ignorate, dar schimbările reale de regulă rămân detectate;
- în Detalii, modificările afișează întâi câmpurile care diferă (`Anterior` / `Nou`), iar JSON-ul complet rămâne disponibil separat;
- fără migrare DB și fără update de agent.

## 0.20.21

- buton „Sincronizează acum Docker / DB / Web” pe VM-urile care moștenesc resurse dintr-un nod sursă HA/cluster;
- sincronizarea manuală folosește inventarul tehnic deja normalizat și raportează resurse potrivite/nepotrivite; resursele nou descoperite continuă să se sincronizeze automat la Colect;
- mesajul de moștenire din partea de sus a VM → Configurare primește margini/padding vizual stânga-dreapta și spacing mai bun pe mobil;
- fără migrare DB și fără update de agent.

## 0.20.20

- extinde moștenirea HA / cluster la documentarea și asocierile resurselor Docker, baze de date și Web, fără copierea inventarului tehnic;
- propagă proiect/serviciu, mediu, status, tip soluție, componentă, rol, observații și marcajele de documentare numai către resurse potrivite univoc;
- sincronizează automat la activarea relației, după modificări pe sursă și după inventare noi ale sursei sau membrului;
- blochează editarea locală Docker/DB/Web pe membru cât timp moștenirea resurselor este activă;
- adaugă padding suplimentar în zona VM → Configurare;
- migrare DB `054_vm_resource_inheritance.up.sql`; fără update de agent.

## 0.20.19

- adaugă ștergere definitivă pentru proiecte/servicii interne, cu impact afișat înainte de confirmare; serviciile globale implicite sunt protejate până la dezactivarea explicită a marcajului global;
- adaugă **Comasează proiectul**: asocierile VM, rolurile, Docker, baze de date, Web/LB, dependențele, conexiunile externe, documentele și anexele sunt mutate în proiectul destinație, iar sursa este eliminată;
- adaugă documentație comună pentru perechi HA și clustere: un VM membru poate moșteni serviciile/configurarea arhitecturală și datele operaționale comune de la un VM sursă;
- propagă automat modificările ulterioare făcute pe VM-ul sursă către membrii care au moștenirea activă; datele tehnice individuale (hostname, IP, UUID, agent, CPU/RAM, discuri, backup și monitorizare) rămân locale;
- fișele VM DOCX/Markdown indică grupul HA/cluster și sursa documentației comune;
- la dezactivarea moștenirii, valorile deja copiate rămân pe membru și pot fi editate local;
- migrare DB `053_vm_documentation_inheritance.up.sql`; fără update de agent.

## 0.20.18

- generalizează `internal_service_dependencies`: orice serviciu activ poate depinde de orice alt serviciu activ, nu doar de infrastructura comună;
- permite mai multe relații între aceeași pereche de servicii în funcție de `mediu sursă → mediu destinație`;
- adaugă pe relație criticitate (`Informativă`, `Normală`, `Critică`), protocol, port, observații și stare activă;
- pagina Serviciului are în fila Dependențe două sensuri explicite: `Depinde de` și `Este utilizat de`; relația se declară o singură dată;
- relațiile pot fi activate/dezactivate fără ștergere, iar ștergerea definitivă rămâne disponibilă;
- fișele Serviciu DOCX/Markdown includ dependențele active cu medii, criticitate și endpoint; analiza `Este utilizat de` funcționează și pentru servicii care nu sunt comune;
- serviciile comune/globale și dependențele directe VM rămân compatibile cu modelul existent;
- migrare DB `052_general_service_dependencies.up.sql`; fără update de agent.

## 0.20.17

- UI: toate tabelele cu antet pot fi sortate la click pe coloană.
- Sortare ascendentă/descendentă cu indicator vizual și suport tastatură.
- Comparatorul recunoaște text, numere, procente, dimensiuni, date și valori naturale precum versiuni/IP-uri.
- Coloanele de acțiuni/checkbox sunt excluse automat; rândurile de detaliu Audit rămân atașate evenimentului.

## 0.20.16

- leagă procentul de completare al VM-ului de proiectele/serviciile selectate în Docker, Baze de date și Web;
- pentru fiecare serviciu intern distinct folosit de aceste resurse se adaugă un criteriu separat `Configurare serviciu: <nume>`;
- criteriul este satisfăcut numai dacă aceeași VM are serviciul configurat și în `Configurare servicii` cu domeniu, categorie, layer, rol tehnic și tip soluție;
- același serviciu folosit de mai multe containere, baze sau site-uri este numărat o singură dată;
- în fila Servicii apare un avertisment cu proiectele detectate în Docker/DB/Web care lipsesc din asocierile VM–serviciu;
- fără migrare DB și fără update de agent.

## 0.20.15

- adaugă în Inventar → Servicii marcajul persistent `Servicii verificate`, pentru a confirma că operatorul a trecut prin categoria serviciilor agentului;
- pe Linux/non-Windows, criteriul `Serviciu software principal` este satisfăcut dacă există cel puțin un serviciu marcat `Principal` **sau** dacă este bifat `Servicii verificate`;
- fără serviciu `Principal` și fără confirmarea de verificare, criteriul continuă să penalizeze procentul de completare;
- marcajul este salvat independent de snapshotul de inventar și este auditat prin `vm.agent_services_review.update`;
- adaugă migrarea `051_vm_documentation_reviews.up.sql`; nu necesită update de agent;
- aliniază testul exportului VM la cele 22 de coloane introduse în 0.20.14 prin coloana `Baseline`.

## 0.20.14

- separă regulile de completare după sistemul de operare: pe Windows este obligatoriu cel puțin un software marcat Principal, fără a cere selectarea serviciilor agentului; pe Linux rămân obligatorii serviciul intern documentat și cel puțin un serviciu software/daemon marcat Principal;
- păstrează criteriul Port / proces principal pentru VM-urile cu inventar atât pe Windows, cât și pe Linux;
- adaugă starea Baseline (Da/Nu) în obiectul VM, cardul din fișa VM, filtrul inventarului VM și exportul Excel;
- filtrul Baseline este aplicat identic la listare și export.

## 0.20.13

- Layout compact 2×2 pentru asocierea resurselor Docker / DB / Web și mutarea `Nu necesită documentare` deasupra asocierii.
- Recalculare live, debounced, a procentului de completare după documentare și selecțiile `Principal`.
- Recalcularea nu reîncarcă întreaga fișă VM și ignoră răspunsurile stale după navigare.

# Changelog

## 0.20.12

- recalculă procentul de completare pe fiecare resursă Docker, DB și Web, nu doar pe categorie;
- `Nu necesită documentare` satisface explicit criteriul resursei și actualizează imediat procentul;
- include în completare selectarea serviciilor software și porturilor/proceselor principale din inventar;
- adaugă cardul `IP principal` în antetul fișei VM și butoanele `Test` / `Colect` direct în Inventar;
- normalizează rezultatul `partial` la `success` când singurele colectoare ne-success sunt nesuportate/omise/neaplicabile și nu există fail/error/timeout;
- repară suprapunerea controalelor Serviciu / Mediu / Status / Tip soluție / Asociază;
- protejează fișa VM și routerul împotriva răspunsurilor stale la clickuri foarte rapide;
- fără migrare DB și fără update de agent.


## 0.20.11

- finalizează curățarea server-side a valorilor de versiune în fișele DOCX și exporturile Markdown;
- elimină `Warning:` / `[Warning]` și din `package_version`, software instalat principal, sumarul DB, Docker și fallback-urile generice ale inventarului;
- normalizează în continuare MySQL/MariaDB `mysql Ver 14.14 Distrib 5.5.37` la `5.5.37`;
- adaugă teste de regresie care verifică explicit că warning-urile nu ajung în corpul DOCX sau Markdown;
- fără migrare DB și fără update de agent.

## 0.20.10

- elimină din afișare liniile `Warning:` / `[Warning]` ajunse în câmpurile de versiune raportate de agent;
- normalizează MySQL/MariaDB astfel încât `mysql Ver 14.14 Distrib 5.5.37` să fie afișat ca `5.5.37`, nu `14.14`;
- aplică aceeași curățare în inventarul structurat, lista de servicii principale și documentele DOCX/Markdown;
- schimbarea este exclusiv în vm-doc-server; nu necesită update de agent și nu modifică schema DB.


## 0.20.9

- redenumește documentul generat pentru serviciu în **Fișă tehnică și operațională a serviciului**;
- redenumește documentele DOCX atașate în **Proceduri operaționale și fluxuri de lucru**;
- păstrează procedurile la final ca anexe B1/B2…, după anexele VM A1/A2…;
- aliniază DOCX, Markdown, UI, audit și OpenAPI la noua terminologie;
- normalizează la randare titlul vechi din șabloanele service existente;
- migrarea `050_service_document_terminology.up.sql` redenumește metadatele șablonului implicit `service.standard`; fără schimbare de schemă și fără update de agent.

## 0.20.8

- hotfix pentru deschiderea fișei unui Serviciu atunci când serviciul are Site-uri Web asociate;
- `webinventory.ListForService` selectează acum și `ws.documentation_exempt`, în acord cu lista de destinații `Scan`;
- elimină eroarea SQL `expected 20 destination arguments in Scan, not 21` care era returnată ca HTTP 500 de `GET /api/v1/services/{id}`;
- fără migrare DB și fără update de agent.

## 0.20.7

- fișele DOCX permit rândurilor lungi din tabele să se împartă natural între pagini; se elimină `w:cantSplit` din rândurile de date și din cardurile VM, păstrând header-ele repetabile;
- corectează în special tabelele cu multe Site-uri Web, DB, Docker, servicii, porturi și alte inventare: conținutul continuă pe pagina următoare de la poziția rămasă;
- documentația DOCX suplimentară încărcată pe serviciu este mutată din capitolul 2 la finalul fișei, ca anexă B1/B2/etc., după anexele A* ale fișelor VM;
- exportul Markdown păstrează aceeași ordine logică, cu documentația suplimentară la final;
- fără migrare DB și fără update de agent.

## 0.20.6

- corectare corelare Prometheus pentru targeturi FQDN care au alias scurt în `/etc/hosts` al serverului Prometheus;
- `/etc/hosts` este consultat înaintea fallback-ului pe hostname scurt, evitând blocarea pe un hostname ambiguu;
- matching-ul prin `/etc/hosts` preferă IP-urile guest curente din vCenter și folosește IP-urile inventarului agentului doar ca fallback;
- teste de regresie pentru `ns2.stsnet.ro:9100` → `ns2` → `172.20.9.100` și VM cu mai multe IP-uri;
- fără migrare DB și fără update de agent.

## 0.20.5

- adaugă `Nu necesită documentare` la nivelul fiecărui container Docker, catalog/bază logică și site/configurație Web; marcajele sunt persistente și nu sunt suprascrise la resync;
- păstrează și controalele coarse existente pentru Docker host, instanță DB și server Web, dar aliniază toate checkbox-urile de documentare într-o coloană dedicată;
- resursele marcate sunt excluse din fișele VM/serviciu și din calculul completitudinii documentației, fără a fi șterse din inventar;
- fișa VM unește `Principal` cu `Utilizare` pe două rânduri, elimină coloana `Pachet` din componentele software, concatenează detaliile port/proces și persoană/departament și elimină `Indicatori` din tabelul containerelor;
- exportul Markdown al anexelor VM folosește aceleași structuri de tabel ca DOCX pentru Sistem/OS/Stocare/Rețea/Servicii/Porturi/Firewall/Conturi/SSSD/Integrări/Politici/Cron/NTP și aplică aceleași filtre;
- corectează testul `buildVMWhere` pentru cele 17 argumente de căutare după introducerea IP-ului principal preferat;
- migrare DB `049_resource_documentation_exempt.up.sql`; nu necesită update de agent.

## 0.20.4

- redenumește `Data generării` în `Data referință` și permite ascunderea câmpului `Generat de` la generarea fișelor VM și serviciu;
- adaugă IP principal documentație și RPO/RTO în Date operaționale; IP-ul preferat este folosit în liste și fișe;
- adaugă `Nu necesită documentare` pentru Docker, instanțe DB și engine-uri Web; resursele exceptate rămân în inventar, dar sunt excluse din completitudine și documentație;
- normalizează cazul Node Exporter activ dar nedetectat ca instalat și scurtează versiunile tehnice la versiunea utilă;
- lărgește tabelele DOCX, elimină fraza automată de la final și permite blocurilor descriptive ale serviciului să curgă natural între pagini;
- completează exportul Markdown cu inventarul agentului și îmbunătățește conversia DOCX suplimentar → Markdown (paragrafe, headings, liste, bold/italic, tabele);
- migrare DB `048_documentation_controls.up.sql`; fără update de agent.

## 0.20.3

- corectează exportul Markdown pentru Outline când este bifată opțiunea `Lipește anexele A1, A2… în același document`;
- anexele VM sunt acum incluse efectiv în fișierul `.md`, nu doar listate ca linkuri/referințe;
- fiecare anexă este randată ca secțiune `A1`, `A2` etc. și include toate secțiunile disponibile ale fișei VM (identificare, încadrare, servicii, dependențe, software, Docker/DB/Web, backup, monitorizare și inventar agent);
- exportul Markdown nu generează și nu salvează o fișă VM nouă în baza de date; folosește datele curente ale VM-ului;
- fără migrare DB și fără modificări de agent.

# Changelog

## 0.20.12

- recalculă procentul de completare pe fiecare resursă Docker, DB și Web, nu doar pe categorie;
- `Nu necesită documentare` satisface explicit criteriul resursei și actualizează imediat procentul;
- include în completare selectarea serviciilor software și porturilor/proceselor principale din inventar;
- adaugă cardul `IP principal` în antetul fișei VM și butoanele `Test` / `Colect` direct în Inventar;
- normalizează rezultatul `partial` la `success` când singurele colectoare ne-success sunt nesuportate/omise/neaplicabile și nu există fail/error/timeout;
- repară suprapunerea controalelor Serviciu / Mediu / Status / Tip soluție / Asociază;
- protejează fișa VM și routerul împotriva răspunsurilor stale la clickuri foarte rapide;
- fără migrare DB și fără update de agent.


## 0.20.2

- adaugă exportul fișei serviciului intern în Markdown, pregătit pentru import/paste manual în Outline sau alt wiki;
- nou buton **Markdown pentru Outline** în panoul de generare al serviciului;
- păstrează structura logică a fișei DOCX: identificare, descriere/scop/obiective, medii, dependențe, clasificări, componente, DB/Docker/Web, backup, monitorizare, VM-uri și anexe;
- convertește rich-text-ul serviciului în Markdown (bold, italic, liste; underline este păstrat prin tag HTML `<u>`);
- documentația suplimentară Word este inclusă în export prin textul extras, iar anexele VM sunt listate A1/A2… cu link către fișa existentă atunci când `base_url` este configurat;
- exportul Markdown este download direct `.md`, nu creează o versiune nouă în istoricul documentelor și nu necesită migrare DB sau update de agent.

## 0.20.1

- adaugă la generarea fișei serviciului opțiunea **Lipește anexele A1, A2… în același document**; fișele VM pot fi integrate în DOCX, fiecare pe pagină nouă, independent de pachetul ZIP;
- documentația suplimentară DOCX încărcată pe serviciu este inserată în capitolul 2 prin `altChunk`, pentru păstrarea formatării originale Word, inclusiv tabele, liste și imagini;
- din capitolul `VM-uri asociate` elimină coloana `Fișă VM`;
- din `Monitorizare` elimină coloanele `Versiune`, `Targets` și `Probe`;
- din `Backup și restaurare` elimină coloanele `Job` și `Storage`;
- normalizează afișarea mediului la codurile uppercase `PROD`, `TEST`, `DEV` în UI și documente;
- nu introduce migrare DB și nu necesită update de agent.

## 0.20.0

- adaugă `Tip soluție` din nomenclator pe asocierile manuale Docker, baze de date și Web;
- extinde Detalii serviciu cu `Descriere scurtă`, `Autentificare`, `Link serviciu` și `Tehnologii folosite`;
- adaugă `Documentație suplimentară a serviciului`: upload/download/delete DOCX, cu importul textului în capitolul 2 al fișei;
- redenumește în interfață și fișe `Număr document` în `Număr electronic document`;
- fișa serviciului pune numele serviciului în titlu și îl elimină din tabelul de identificare; tabelul include noile câmpuri de identificare;
- descrierea detaliată continuă să fie rich-text și este redată formatat în fișă;
- capitolul 3 listează VM-urile pe rând, nu grupate cu virgulă;
- elimină coloana `VM-uri furnizor` din dependențe și servicii comune;
- fișele tehnice VM sunt prezentate la final ca Anexe și pot fi incluse în pachetul ZIP;
- documentele generate folosesc Arial 12 pentru text normal, inclusiv peste șabloane DOCX personalizate;
- migrare DB `047_service_documentation_enrichment.up.sql`; nu necesită update de agent.

## 0.19.16

- normalizează inventarul `software.items` raportat de vm-doc-agent 1.7.2;
- adaugă fila VM `Software instalat`, cu căutare/filtre, export Excel și selecție persistentă `Principal`;
- fila apare numai când există inventar software raportat, deci în prezent în mod normal doar pentru VM-uri Windows;
- fișa VM include numai aplicațiile marcate Principal; selecțiile rămân vizibile și când software-ul nu mai este detectat;
- marcajul Principal supraviețuiește upgrade-urilor de versiune ale aceleiași aplicații;
- migrare DB `046_software_inventory.up.sql`.

## 0.19.15

- ascunde din UI și documentația VM/serviciu bazele marcate ca sistem (`postgres`, `template0`, `template1`, `mysql`, `information_schema`, `performance_schema`, `sys`, respectiv MongoDB `admin/config/local`), păstrându-le în inventarul brut și în stocarea normalizată;
- cardul `Baze aplicație` și `catalog_count` din vederea VM numără numai bazele non-system;
- Rezumatul VM avertizează când este detectat un engine/instanță DB dar enumerarea bazelor nu a reușit și afișează motivul secret-safe raportat de agent;
- asocierile manuale pentru Baze de date, Docker și Web includ acum `Mediu` și `Status operațional` din nomenclatoare, per componentă;
- asocierile existente rămân compatibile prin câmpuri nullable, iar UI cere contextul operațional la asocierile manuale noi;
- fișele VM și serviciu includ mediul/statusul pe asocierile DB/Docker/Web;
- migrare DB `045_component_assignment_context.up.sql`; recomandat cu vm-doc-agent 1.6.11 pentru PostgreSQL 8/9 multi-instance.

## 0.19.14

- persistă metadata joburilor PostgreSQL programate raportate de vm-doc-agent 1.6.10 (`pgAgent` / `pg_cron`) fără SQL/comenzi/scripturi;
- VM → Baze de date afișează numărul și starea discovery-ului joburilor per instanță și un tabel separat `Joburi programate PostgreSQL`;
- afișează mai clar instanțele PostgreSQL multi-instance, inclusiv data directory, endpoint și socket;
- fișa VM include metadata joburilor PostgreSQL și starea discovery-ului lor;
- fișa serviciului include numărul de joburi pe resursa DB și un tabel deduplicat cu joburile relevante;
- adaugă motivele `maintenance_database_missing` și `user_switch_unavailable` în UI/documentație;
- migrare DB `044_database_scheduled_jobs.up.sql`; recomandat cu vm-doc-agent 1.6.10 (schema 2.7).

## 0.19.13

- adaugă `386 (i386/i686)` în selectorul de arhitectură din Agenți → Release-uri agent și în filtrul repository;
- repository-ul existent este deja multi-arhitectură: cheia release-ului include canal + OS + arch + versiune, iar endpointul latest selectează exact arhitectura cerută de agent;
- documentează publicarea în paralel a binarelor `linux/amd64` și `linux/386` pentru vm-doc-agent 1.6.8;
- fără migrare DB; backend-ul de update nu necesită schimbare de schemă.

## 0.19.12

- folosește clasificarea serviciilor raportată de vm-doc-agent 1.6.7 (`system` / `application` / `unknown`);
- VM → Inventar → Servicii afișează implicit numai servicii active de aplicație + necunoscute și oferă filtru pentru serviciile OS;
- serviciile marcate `Principal` rămân vizibile indiferent de filtrul de clasificare/stare;
- fișa VM omite din `Servicii active` numai serviciile clasificate explicit `system`; serviciile `application`, `unknown` și snapshoturile vechi rămân documentate;
- păstrează clasificarea și motivul în metadatele serviciilor principale;
- fără migrare DB; necesită vm-doc-agent 1.6.7 pentru clasificare, dar rămâne compatibil cu agenți mai vechi.

## 0.19.11

- include Monitorizarea în fișa VM: stare generală, Node Exporter, targeturi Prometheus metrics și probe Blackbox, inclusiv stare, corelare, HTTP/durată/TLS unde sunt disponibile;
- include Monitorizarea agregată în fișa serviciului, pe VM-urile asociate;
- curăță afișarea Firewall în UI și DOCX: când există un manager high-level (UFW/firewalld/SuSEfirewall2), regulile tehnice nftables/iptables/ip6tables generate dedesubt nu mai sunt afișate;
- păstrează politicile implicite ca rezumat și zonele firewalld, iar pe hosturile care folosesc direct nftables/iptables regulile rămân documentate;
- nu modifică schema bazei de date și nu necesită upgrade de agent sau collector; versiunea recomandată de agent rămâne 1.6.6.

## 0.19.10

- persistă `catalog_discovery_reason` raportat de vm-doc-agent 1.6.5 pentru instanțele de baze de date;
- afișează în VM → Baze de date motivul pentru `metadata only` (autentificare, permisiuni, socket/server indisponibil, client lipsă, timeout etc.);
- include motivul și în fișa DOCX a VM-ului;
- urmărește schimbarea motivului în Modificări inventar;
- migrare DB nouă `043_database_catalog_discovery_reason.up.sql`.

## 0.19.9

- standardizează filtrele și paginarea: selecturile din zonele de filtrare rămân native, stabile și nu mai folosesc dropdown-ul searchable cu portal;
- lista VM afișează și procentele pentru prezența în vCenter, lipsă și asocierea cu agent;
- Backup este separat în taburile `Backup` și `Surse & sincronizări`, iar lista VM Veeam primește export Excel filtrat;
- Monitorizare păstrează filtrele într-un layout stabil și adaugă export Excel filtrat pentru VM-uri și targeturi;
- catalogul Servicii primește paginare, export Excel și elimină coloana cu butoanele `Deschide` / `Editează`; numele serviciului rămâne linkul de navigare;
- `Descriere` serviciu devine rich-text, inclusiv la creare, este păstrată separat în DB și este redată cu formatare în fișa DOCX;
- Conectivitate externă și Rețele externe folosesc secțiuni `Adaugă` colapsate, iar formularele/conexiunile primesc padding consistent;
- filtrele Agenți sunt reașezate în aceeași grilă responsive folosită în restul aplicației;
- migrare DB: `042_service_description_rich_text.up.sql`; agentul și collectorul nu se modifică.

## 0.19.8

- mută editarea serviciului intern în pagina lui de detaliu, în același model ca fișa VM;
- `Detalii` are subtabs `General`, `Descriere`, `Scop și domeniu` și `Obiective`, fiecare editabil direct și cu salvare proprie;
- formularul modal vechi rămâne numai pentru crearea unui serviciu nou; butonul `Editează` din catalog deschide fișa serviciului, nu modalul;
- reconstruiește filtrele din lista Servicii pe layout-ul aerisit folosit la VM, cu listbox-uri încadrate în grid, zonă separată de acțiuni și filtre active;
- elimină suprapunerile dintre listbox-uri și butoanele filtrării la lățimi intermediare;
- nu modifică schema DB și nu necesită upgrade de agent sau collector.

## 0.19.7

- reorganizează pagina detaliu a serviciului intern pe taburi, în același model vizual ca fișa VM;
- adaugă zonele Rezumat, Detalii, Arhitectură, Componente, Dependențe și Documentație, cu subtabs pentru zonele complexe;
- mută vizual toate informațiile administrate din formularul „Editează serviciul” în tabul Detalii;
- păstrează butonul Editează în contextul tabului Detalii și revine pe aceeași secțiune după salvare;
- adaugă navigare directă prin hash-uri `#services/<id>/<secțiune>`;
- nu modifică schema DB și nu necesită upgrade de agent.

## 0.19.6

- în `VM → Inventar → Porturi ascultate`, porturile/procesele pot fi marcate persistent ca **Principale**;
- identitatea selecției este `protocol + port + process_name`, fără PID, astfel încât persistă după restarturi;
- fișa VM adaugă **Porturi și procese principale** cu port, protocol, proces, PID curent, executabil, adresă de listen și stare;
- selecțiile dispărute din inventarul curent rămân vizibile ca `Nedetectat`, până la demarcare;
- secțiunea separată **Politici** este eliminată din fișa VM; politicile implicite ale firewall-ului rămân în capitolul Firewall;
- migrare DB: `041_vm_primary_agent_ports.up.sql`; agentul și collectorul nu se modifică, `vm-doc-agent` rămâne 1.6.3.

## 0.19.5

- reorganizare UI VM: `Inventar VM` separat de `Surse & sincronizări`;
- fișa VM are meniu principal pe zone funcționale și subtabs locale;
- filtre VM aerisite și rezumat al filtrelor active;
- listbox-uri searchable stabilizate: portal, direcție blocată, săgeată CSS și padding constant;
- chevron uniform pentru selecturile native;
- padding și spațiere îmbunătățite inclusiv în VM → Monitorizare;
- fără migrare DB; agentul rămâne 1.6.3.

## 0.19.4

- curățare definitivă pentru VM-uri dispărute din vCenter, fără introducerea unui flux nou de arhivare;
- filtru `vCenter` pentru prezente/lipsă și afișarea `missing_since`;
- ștergere individuală și bulk, maximum 200 VM-uri per operație;
- ștergerea este permisă numai pentru `present_in_vcenter=0` și este tranzacțională;
- preview de impact înainte de delete: servicii, documente, monitorizare, backup, conexiuni externe, responsabilități și schimbări;
- targeturile de monitorizare sunt decorelate, nu șterse; agentul asociat nu este șters;
- audit `vm.delete.permanent`;
- fără migrare DB nouă; agentul rămâne `vm-doc-agent 1.6.3`.

## 0.19.3

- vCenter sincronizează toate adresele IPv4 guest raportate de `/guest/networking/interfaces`, nu doar `guest/identity.ip_address`;
- adresele sunt păstrate în `vcenter_vm_ips`; setul complet este înlocuit numai când endpointul guest networking răspunde cu succes;
- corelarea Prometheus/Blackbox folosește și IP-urile secundare vCenter, inclusiv pentru VM-uri fără agent;
- pagina VM → Monitorizare afișează IP-urile vCenter folosite la corelare;
- Monitorizare este împărțită în două pagini: **Stare monitorizare** și **Surse & sincronizări**;
- formularul Prometheus este mărit și împărțit pe secțiuni, iar filtrele/paddingurile din Monitorizare și din fila VM au fost aerisite;
- migrare DB: `040_vcenter_vm_guest_ips.up.sql`; agentul rămâne `vm-doc-agent 1.6.3`.

## 0.19.2

- sursa Prometheus poate fi asociată explicit cu un agent vm-doc;
- UI oferă selectorul „Agent asociat” la creare/editare;
- serverul citește `hosts.entries` din inventarul curent al agentului asociat;
- corelarea devine label → FQDN → hostname → IP → Prometheus `/etc/hosts` → alias manual;
- metoda de corelare este salvată ca `prometheus_hosts` cu valoarea `alias -> IP`;
- Test Prometheus raportează și disponibilitatea / numărul de intrări hosts;
- migrare DB: `039_prometheus_source_agent_hosts.up.sql`;
- necesită vm-doc-agent 1.6.3 pe serverele Prometheus pentru corelarea prin hosts.

## 0.19.1
- separă targeturile `metrics` de `blackbox` chiar când ambele surse folosesc același Prometheus;
- identifică Blackbox după `/probe`, `__metrics_path__` și `__param_target`, fără dependență de numele jobului;
- Test raportează numărul de targeturi filtrat după tipul sursei;
- clientul Prometheus ocolește proxy-ul de mediu (`Proxy: nil`);
- următorul Sync marchează automat `present=0` rândurile importate greșit de 0.19.0, fără migrare DB.

# Changelog

## 0.20.12

- recalculă procentul de completare pe fiecare resursă Docker, DB și Web, nu doar pe categorie;
- `Nu necesită documentare` satisface explicit criteriul resursei și actualizează imediat procentul;
- include în completare selectarea serviciilor software și porturilor/proceselor principale din inventar;
- adaugă cardul `IP principal` în antetul fișei VM și butoanele `Test` / `Colect` direct în Inventar;
- normalizează rezultatul `partial` la `success` când singurele colectoare ne-success sunt nesuportate/omise/neaplicabile și nu există fail/error/timeout;
- repară suprapunerea controalelor Serviciu / Mediu / Status / Tip soluție / Asociază;
- protejează fișa VM și routerul împotriva răspunsurilor stale la clickuri foarte rapide;
- fără migrare DB și fără update de agent.


## 0.19.9

- standardizează layout-ul filtrelor și dezactivează listbox-urile searchable custom în zonele de filtrare/paginare, pentru a elimina suprapunerile și poziționările instabile;
- VM: cardurile de inventar afișează și procentele pentru prezență vCenter, lipsă și acoperire agent;
- Backup: separă pagina în taburile `Backup` și `Surse & sincronizări`, adaugă Export Excel pentru lista filtrată;
- Monitorizare: aliniază filtrele cu restul aplicației și adaugă Export Excel separat pentru VM-uri și targeturi;
- Servicii: adaugă paginare configurabilă, Export Excel, elimină coloana/butoanele Deschide/Editează și face Descrierea rich-text persistentă;
- Conectivitate externă: formularele de adăugare sistem/rețea sunt colapsate implicit, iar editarea conexiunilor primește padding și spacing consistent;
- Agenți: filtrele sunt rearanjate pe layout-ul comun.
- migrare DB nouă `042_service_description_rich_text.up.sql`.

## 0.19.0

- adaugă fundația de monitorizare read-only pentru surse **Prometheus metrics** și **Prometheus Blackbox**;
- meniu nou **Monitorizare** cu surse configurabile, Test, Sync manual/global, scheduler și istoric paginat;
- sincronizează targeturile active prin API-ul Prometheus fără a duplica seriile de metrici în MariaDB;
- corelează targeturile cu VM-urile în ordinea: label explicit configurabil (implicit `vm_fqdn`) → FQDN → hostname → IP → alias manual;
- suportă joburi Prometheus care folosesc IP, FQDN sau hostname rezolvat local pe serverul Prometheus, inclusiv prin `/etc/hosts`;
- folosește inventarul agentului 1.6.2 pentru starea Node Exporter: instalat, service activ, versiune și endpoint;
- pentru sursele Blackbox citește `probe_success`, codul HTTP, durata probei și expirarea certificatului TLS;
- adaugă fila **Monitorizare** în pagina VM cu Node Exporter, targeturi Prometheus/Blackbox și aliasuri manuale;
- pagina globală afișează VM monitorizate/nemonitorizate, exporter fără target, targeturi DOWN, corelate/necorelate și filtre după power state;
- migrare nouă `038_prometheus_monitoring_foundation.up.sql`; agentul rămâne `vm-doc-agent 1.6.2`; integrarea Grafana este lăsată intenționat pentru etapa următoare după validarea Prometheus/Blackbox.

## 0.18.3

- citește VM-urile configurate direct în joburile Veeam din `virtualMachines.includes`, nu doar obiectele care au deja backup/restore point;
- separă starea `În job Veeam` de existența unui backup utilizabil: VM-urile nou adăugate apar imediat ca `Așteaptă primul backup`;
- detectează cazul invers: restore point existent, dar VM-ul nu mai este inclus direct într-un job (`Backup existent · în afara jobului`);
- pentru VM-urile configurate înainte de primul backup afișează deja jobul, repository-ul, programarea, retenția/GFS și `Next run` când sunt raportate de Veeam;
- pagina Backup adaugă filtre și carduri pentru `În job`, `Așteaptă primul backup` și `Backup în afara jobului`; cardurile rămân sensibile la filtre;
- întărește compatibilitatea 0.18.2: repară DSN-ul UTC, default-ul `cron_backup_notes` și INSERT-urile de sync/cron pentru instalări curate și upgrade-uri existente;
- migrare nouă `037_veeam_job_membership.up.sql`; agentul rămâne 1.6.2.

## 0.18.2

- citește din Veeam definițiile joburilor, programarea, retenția și politicile GFS Weekly / Monthly / Yearly;
- diferențiază storage-ul primar de storage-ul secundar (backup copy) și afișează ambele în UI și documente;
- cardurile din pagina Backup se recalculează după căutare și filtre, iar filtrarea include power state;
- adaugă backup cron/script local documentabil per VM; cron-urile raportate de agent pot fi selectate direct, iar backupul apare în tabul Backup și în fișele VM/serviciu;
- compactează listboxurile din filtrarea Backup;
- normalizează conexiunile MariaDB la UTC și expune timezone-ul aplicației către UI; timezone implicit: Europe/Bucharest.

## 0.18.1

- corectează corelarea ID-urilor Veeam pentru backup/job (case-insensitive și compatibilă cu UUID-uri între acolade), astfel încât să fie populate `Job`, `Repository`, `Last result` și `Next run`;
- păstrează Test-ul Veeam compatibil cu rolul **Backup Viewer**, fără apel la `serverInfo`;
- acceptă răspunsurile VBR 12.1 în care `platformName` nu este întotdeauna string;
- îmbunătățește pagina **Backup** cu filtre separate pentru protecție, power state și rezultat, plus căutare și paginare;
- adaugă card **Toate VM-urile** și procente pentru protejate, neprotejate și neverificate;
- adaugă fila **Backup** în pagina VM, cu sumar și detaliile Veeam ale lanțurilor de backup/restore point;
- include backupurile VM-urilor și în fișa DOCX a serviciului intern; fișa VM continua să includă secțiunea Backup;
- intervalul implicit pentru sursele Veeam noi devine 1440 minute (o dată pe zi); sursele existente își păstrează intervalul configurat;
- nu adaugă migrare DB și nu necesită update de agent (`vm-doc-agent 1.6.2`).

## 0.18.0

- adaugă integrare read-only cu **Veeam Backup & Replication** prin REST API;
- meniu nou **Backup** cu surse Veeam, Test conexiune, sincronizare manuală/globală și istoric paginat al sincronizărilor;
- parolele surselor Veeam sunt criptate cu cheia master a serverului și nu sunt returnate prin API;
- corelează obiectele Veeam cu VM-urile din vm-doc după **numele exact** al VM-ului;
- populează automat `vm_backup_summary` cu job, repository, ultimul rezultat, ultimul backup/restore point, următoarea rulare și numărul de restore points;
- scheduler per sursă, implicit la 360 minute (6 ore), cu stare și ultima eroare;
- migrare nouă `034_veeam_backup_integration.up.sql`; nu necesită update de agent, `vm-doc-agent 1.6.2` rămâne compatibil.

## 0.17.2

- introduce baseline pentru meniul Modificări, global și per VM;
- la upgrade, inventarul curent devine automat baseline pentru VM-urile existente, evitând zgomotul inițial;
- modificările de dinaintea baseline-ului rămân păstrate pentru audit, dar nu mai apar în trierea curentă și nu afectează procentul de completare;
- VM-urile noi își stabilesc automat primul snapshot drept baseline înainte de urmărirea diferențelor;
- butoane noi „Stabilește inventarul curent ca baseline” global și „Stabilește baseline VM” în fila Modificări.

## 0.17.1

- corectează migrarea `032_inventory_changes.up.sql`: coloanele care referențiază chei `BIGINT UNSIGNED` sunt acum tot `BIGINT UNSIGNED`;
- repară pornirea pe MariaDB/MySQL unde 0.17.0 eșua cu `Error 1005 ... Foreign key constraint is incorrectly formed`;
- nu adaugă o migrare nouă și nu schimbă schema funcțională planificată pentru 0.17.0; migrarea 032 eșuată este reluată automat la pornire.

## 0.17.0

- adaugă meniul global **Modificări** și fila **Modificări** în fiecare VM;
- compară semantic snapshot-ul JSON nou cu snapshot-ul anterior și ignoră zgomotul volatil (timpi de colectare, uptime, durate, PID-uri/inode-uri);
- urmărește schimbări relevante pentru documentație: conturi locale, baze/instanțe DB, containere Docker, site-uri/frontends Web, servicii OS, porturi, firewall, rețea, stocare, SSSD, integrări, NTP, OS și hardware;
- fiecare diferență este clasificată `added`, `removed` sau `modified` și păstrează valorile anterioare/noi pentru verificare;
- adaugă triere manuală `Documentație`: `Nesetat` (implicit), `Necesită documentație`, `Nu necesită`, plus starea `Nou / Revizuit / Ignorat` și observații;
- pagina globală are filtre, paginare și indicatori; din VM se văd numai schimbările VM-ului respectiv;
- include acțiunea **Compară ultimele snapshot-uri** pentru popularea inițială după upgrade;
- migrare nouă `032_inventory_changes.up.sql`; agentul 1.6.1 rămâne compatibil și nu necesită update.


## 0.16.4

- stabilizează dropdown-urile searchable: elimină repoziționarea dublă la focus/click și recalculează poziția după fiecare filtrare, folosind înălțimea reală a listei;
- dropdown-ul rămâne ancorat de listbox când rezultatele filtrate schimbă înălțimea listei, inclusiv când lista este deschisă deasupra controlului;
- adaugă padding explicit mesajului Docker „nu este instalat” și informației despre ultima colectare.

## 0.16.3

- repară listbox-urile searchable care puteau fi tăiate de panel/table overflow: dropdown-ul este randat ca portal cu z-index ridicat și repoziționat la scroll/resize;
- adaugă padding suplimentar în detaliile Docker;
- elimină subsecțiunea goală „Schema inventar” și numerotează continuu subsecțiunile Inventar agent, fără goluri pentru secțiuni eliminate;
- indentează explicit Heading2 în DOCX, astfel încât 5.1 și toate subsecțiunile să fie vizual sub capitolul părinte;
- deduplică Porturi ascultate la o singură intrare per port/protocol, păstrând exemplul cu cele mai bune informații de proces/executabil;
- fără migrare SQL; vm-doc-agent 1.6.1 rămâne suficient.


## 0.16.2

- mută versiunea agentului lângă badge-ul de stare din lista VM și elimină coloana separată;
- adaugă căutare prin tastare pentru select-urile single-value din interfață;
- adaugă paginare server-side pentru ultimele sincronizări vCenter;
- îmbunătățește spațierea filelor Docker/DB/Web, previzualizarea fișei VM și panoul de conexiuni externe;
- repară tabelul de porturi din fișa VM folosind `processes[]` din inventarul agentului;
- generalizează secțiunea Firewall pentru nftables, iptables/ip6tables, firewalld, UFW și SuSEfirewall2;
- include corect utilizatorii locali non-system, inclusiv UID 1000.
- fără migrare SQL; agentul 1.6.1 este suficient.

## 0.16.1

- compactează cardurile din Rezumat VM, Docker, Baze de date și Web astfel încât pe desktop să ocupe un singur rând; repară fundalul deschis al cardurilor Docker Compose în tema dark;
- aerisește controalele de asociere serviciu în taburile Docker, Baze de date și Web;
- listarea VM afișează versiunea agentului și toate serviciile asociate, inclusiv cele provenite din containere Docker, baze/instanțe DB și site-uri Web; adaugă filtru după serviciu;
- simplifică sistemul de operare și power state în listare (`ON` / `OFF`) și elimină coloana vCenter din tabel;
- procentul de completare devine dinamic: VM-urile cu Docker/DB/Web primesc criterii suplimentare pentru asocierea resurselor la servicii, iar VM-urile fără aceste resurse nu sunt penalizate;
- criteriul „Serviciu documentat” este satisfăcut și de asocieri Docker/DB/Web, util pentru hosturile partajate care nu aparțin integral unui singur serviciu;
- fără migrare SQL nouă.

## 0.16.0

- adaugă inventar structurat pentru Nginx, Apache HTTP Server și HAProxy: servere, site-uri/virtual hosts/frontends, nume publice, bind-uri, document root, backend-uri și ținte proxy;
- adaugă relația many-to-many site Web → serviciu intern, independentă de VM → serviciu, pentru hosturi web partajate;
- pagina VM primește tabul `Web`, iar pagina serviciului agregă site-urile asociate de pe orice VM gazdă;
- îmbunătățește controalele de asociere în taburile Docker și Baze de date și folosește aceleași controale aerisite în Web;
- fișa VM omite automat capitolele Docker, Baze de date și Web când nu există date și renumerotează dinamic capitolele următoare;
- repară prefixul subsecțiunilor Inventar agent, eliminând situații de tipul capitol 9 urmat de 8.x;
- fișa serviciului include Web numai când există site-uri asociate și renumerotează dinamic capitolele opționale;
- migrare DB nouă `031_web_inventory.up.sql`; necesită `vm-doc-agent 1.6.0` pentru colectarea Web.

## 0.15.0

- adaugă inventar structurat pentru PostgreSQL, MySQL, MariaDB, MongoDB, Oracle Database, Microsoft SQL Server, IBM Db2, Redis, Firebird și CockroachDB;
- inventariază engine-uri, instanțe, endpoint-uri, versiuni, servicii/procese, directoare/config și, când accesul local fără credențiale permite, bazele logice;
- adaugă relații many-to-many instanță → serviciu și bază logică → serviciu, independente de relația VM → serviciu;
- pagina VM primește tabul `Baze de date`, iar pagina serviciului agregă bazele/instanțele asociate de pe orice VM gazdă;
- fișele DOCX de VM și serviciu includ secțiuni DB;
- importul acceptă statusurile collectorului `success` și `partial` și poate face backfill din snapshot-ul curent;
- migrare DB nouă `030_database_inventory.up.sql`; necesită `vm-doc-agent 1.5.0` pentru colectare.

## 0.14.1

- repară normalizarea inventarului Docker când collectorul agentului are status `partial`; `vm-doc-agent` marchează un collector `partial` pentru orice warning, chiar dacă payload-ul Docker este valid și conține engine/containere;
- păstrează protecția pentru statusurile `disabled`, `error` și `timeout`, care nu suprascriu ultimul inventar Docker bun;
- adaugă backfill/self-healing din `inventory_snapshots.raw_json`: la deschiderea tabului Docker, dacă snapshot-ul curent conține Docker dar tabelele structurate nu au fost populate de 0.14.0, serverul reconstruiește automat inventarul fără o colectare nouă;
- nu există migrare DB nouă; agentul 1.4.0/1.4.1 este compatibil.

## 0.14.0

- inventar Docker structurat în baza de date pentru fiecare VM: engine, containere, Docker Compose, imagini, rețele și volume;
- containerele au identitate logică stabilă pentru a păstra asocierile manuale după redeploy;
- asociere many-to-many container → serviciu intern, independent de asocierea VM-ului; un host Docker partajat poate găzdui containere pentru servicii diferite;
- asociere manuală per container și asociere în masă per proiect Docker Compose;
- labels opționale `vm-doc.service`, `vm-doc.services`, `vm-doc.component` și `vm-doc.role` creează automat asocieri fără a suprascrie asocierile manuale;
- tab nou Docker în fișa VM, cu engine, Compose projects, containere, porturi, indicatori și serviciile asociate;
- pagina serviciului afișează containerele asociate chiar dacă VM-ul gazdă este partajat și nu aparține exclusiv serviciului;
- fișa DOCX a VM-ului și fișa DOCX a serviciului includ secțiuni Docker;
- migrare nouă `029_docker_inventory.up.sql`; necesită `vm-doc-agent 1.4.0` pentru colectarea Docker.


## 0.13.8

- Agent actions (Test / Colect / Update) now prefer the registered management IP when the stored agent URL still points to a VIP.
- Auto-registration normalizes a literal-IP base_url to the advertised management IP, preserving scheme and port.
- The agent list no longer shows the redundant "IP-uri raportate VM" column; those addresses remain available in inventory data.
- Agent Excel export removes the redundant reported-VM-IP column and exports the effective management URL.

## 0.13.7

- Fix auto-registration for a brand-new agent: the `agents` INSERT now has a value for every listed column, including `last_registration_ip`.
- Keep internal registration/heartbeat/inventory errors hidden from HTTP clients but log the real server-side error for troubleshooting.
- No database migration is required.

## 0.13.6

- separă în pagina Agenți adresa `IP agent / management` de adresele IP raportate de interfețele VM;
- afișează separat IP-ul sursă observat la register/heartbeat când diferă de IP-ul de management;
- inventarul curent păstrează compact lista adreselor raportate pentru listare/căutare/export fără a încărca payload-ul JSON complet;
- `primary_ip` al inventarului preferă `src/prefsrc` al rutei implicite înaintea primei adrese de interfață, reducând riscul ca un VIP să devină IP principal;
- exportul Excel pentru agenți include IP management, IP sursă register și IP-urile raportate;
- migrare nouă `028_agent_network_identity.up.sql`.

## 0.13.5

- layout fluid pe toată lățimea monitorului; eliminată limita fixă de 1600 px care lăsa spațiu gol pe ecrane mari;
- spațiere adaptivă cu `clamp()` pentru monitoare Full HD, 2K, 4K și ferestre redimensionate;
- cardurile, panourile, tabelele și workspace-urile pot folosi întreaga lățime disponibilă fără overflow inutil;
- toolbar-urile și antetele de panou se împachetează controlat când spațiul scade;
- dialogurile sunt limitate la viewport și pot fi derulate pe ecrane joase;
- navigarea secundară devine scrollabilă pe ecrane mobile, iar controalele se reașază fără să iasă din viewport;
- CSS-ul este versionat în URL pentru cache-busting la upgrade;
- fără migrare DB și fără modificări de backend/API.

## 0.13.4

- fix status auto-update rămas `stable / installing / <versiune>` după instalarea reușită;
- la register/heartbeat, serverul reconciliază cache-ul de update când `agent.version` este egal cu `update_available_version`;
- după reconciliere, `update_state` devine `current`, versiunea disponibilă se golește și se actualizează timestamp-ul de succes;
- UI-ul listei de agenți face refresh-uri scurte după butonul Update pentru a afișa finalizarea fără refresh manual;
- fără migrare DB; compatibil cu vm-doc-agent 1.3.6.

## 0.13.3

- hotfix pentru panic-ul `nil pointer dereference` din `agentclient.Client` introdus pe calea de refresh/update a agenților în 0.13.2;
- `vm-doc-server` inițializează acum propriul `agentclient.Client` cu aceleași `collector.allowed_networks` și limite folosite de collector;
- heartbeat-ul și butonul **Update** pot interoga `/v1/update` / `/v1/update/check` fără a opri procesul serverului;
- protecție defensivă în client: un client neinițializat returnează eroare explicită în loc de SIGSEGV;
- fără migrare MariaDB nouă și fără modificări obligatorii la `vm-doc-agent`.

## 0.13.2

- buton **Update** în lista Agenți pentru verificare/instalare imediată, fără a aștepta `updates.check_interval`;
- serverul apelează endpoint-ul existent `POST /v1/update/check` al agentului 1.3.3+ și respectă canalul configurat local pe agent;
- lista Agenți afișează canalul de update `stable` / `testing`, starea update-ului și versiunea disponibilă când există;
- filtru și căutare după canal/stare update;
- statusul de update este memorat central și reîmprospătat la Test/Colect, la update forțat și periodic pentru agenții auto-înregistrați;
- exportul Excel Agenți include canalul și starea auto-update;
- migrarea `027_agent_update_status.up.sql`;
- `vm-doc-agent 1.3.3` rămâne compatibil, fără upgrade obligatoriu al agentului.

## 0.13.1

- navigare orizontală în pagina Agenți;
- OS + versiune OS raportate de agent în listă și căutare;
- butoane compacte Test / Colect / Edit / Del;
- export Excel pentru agenți;
- publicarea unui release este colapsată implicit;
- release-uri cu filtre, paginare și export Excel;
- toate paginările pornesc implicit de la 10;
- fără migrare MariaDB.

## 0.13.0

- retenție configurabilă a snapshot-urilor de inventar și raportare a volumului de stocare;
- Audit paginat, filtrabil și cu before/after pentru operațiile principale instrumentate;
- obiect nou `external_networks`, cu culoare, tip zonă, risc, trust, CIDR-uri și metadate operaționale;
- sisteme externe asociate unei rețele externe și conexiuni către VM/Servicii interne;
- conectivitatea externă apare în UI, rapoarte și documentația DOCX;
- migrarea `026_inventory_retention_audit_external_systems.up.sql`.

## 0.12.0

- fișa VM împărțită în șapte subsecțiuni cu navigare sticky și URL dedicat;
- procent de completare pentru VM, vizibil în listă, rezumat și export Excel;
- paginare Nomenclatoare configurabilă 10/20/50/100/200, memorată pe categorie;
- pagina Agenți separată în listare și administrarea release-urilor;
- repară pierderea focusului în câmpul de căutare Agenți;
- fără migrare MariaDB nouă.

## 0.11.1

- administrare completă a repository-ului de agent din UI: publicare, promovare și ștergere;
- upload multipart protejat de RBAC `agents.manage` și CSRF;
- suport pentru rollout testing → stable;
- release recomandat împreună cu vm-doc-agent 1.3.2 pentru detecția robustă a versiunilor software.



## 0.11.0

- Servicii agent pe VM: căutare, filtru Active/Inactive/Toate și stare lângă nume;
- Network Routes afișate tabelar;
- Firewall Rules: reguli explicite separate de regulile tehnice backend și reguli brute ascunse implicit;
- Rapoarte împărțite în subcategorii;
- readuce repository-ul central de auto-update pentru vm-doc-agent 1.3.0+;
- pagina Agenți afișează versiunea agentului și release-urile publicate;
- fără migrare MariaDB nouă.

## 0.10.0

- servicii software principale selectabile din inventarul agentului;
- selecții persistente pe VM, independente de snapshotul curent;
- metadate de versiune software/pachet preluate din agentul 1.3.1+;
- componentele principale apar în fișa VM și sunt agregate în fișa Serviciului intern;
- renderer contextual pentru uptime, mount point, port, username, comandă cron și nume serviciu;
- migrarea `025_vm_primary_agent_services.up.sql`;
- OpenAPI și documentație actualizate.


## 0.9.1

- repară eroarea HTTP 500 la adăugarea unei dependențe directe `VM → Serviciu comun`;
- citirea dependențelor VM nu mai folosește un `UNION ALL` fragil în MariaDB, ci interogări separate agregate în aplicație;
- erorile de creare a unei dependențe directe pe VM sunt acum scrise explicit în log;
- fără migrare de bază de date.


## 0.9.0

- căutare, filtrare și paginare în pagina Agenți;
- filtre extinse și descriere scurtată în lista Serviciilor interne;
- carduri compacte în pagina serviciului și afișare condiționată a mediilor PROD/TEST/DEV;
- model nou pentru servicii comune și dependențe globale/explicite;
- nomenclator `dependency_type`;
- relații `internal_service_dependencies` și excepții `vm_common_service_dependencies`;
- servicii comune marcabile ca `is_common` și `implicit_global`;
- dependențe afișate în pagina VM, pagina serviciului și schema logică;
- VM-urile furnizor ale AD/DNS/LDAP și ale altor servicii comune sunt expuse în UI și documentație;
- fișele DOCX VM/Serviciu includ infrastructura comună și analiza de impact;
- rapoarte noi pentru servicii comune, tipuri de dependență și impact;
- migrarea `024_common_service_dependencies.up.sql`;
- OpenAPI și documentație actualizate.

## 0.8.0

- evidențiere explicită a mediilor **PROD / TEST / UAT / DEV** în pagina și fișa DOCX a Serviciului intern;
- lista VM-urilor serviciului afișează ultima fișă VM generată și link direct către document;
- generarea documentației serviciului poate fixa fișele VM ca anexe și poate regenera automat fișele lipsă sau toate fișele;
- pachet ZIP reproductibil cu fișa serviciului și versiunile exacte ale fișelor VM anexate;
- tabel `service_document_annexes` pentru relația dintre o fișă de serviciu și documentele VM folosite la generare;
- meniu nou **Rapoarte**, cu indicatori, pie/donut charts, bar charts și evoluția documentelor generate;
- rapoarte pentru medii, power state, CPU/RAM, OS, vCenter, agenți, backup, inventar, documentare, criticitate, domenii, categorii, layer-e, roluri, tip soluție și completitudinea asocierilor;
- liste de servicii și VM-uri cu informații lipsă pentru completarea documentației;
- permisiune nouă `reports.read`;
- migrarea `023_reports_service_annexes.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.3

- hotfix pentru editorul rich-text: clickul în **Scop și domeniu** / **Obiective** păstrează focusul în zona editabilă în loc să activeze butonul Bold;
- structură HTML corectată și îmbunătățiri de accesibilitate;
- fără migrare de bază de date.


## 0.7.2

- editor rich-text pentru **Scop și domeniu** și **Obiective**;
- suport pentru paragrafe, newline, bold, italic, underline, bullets, numerotare și indentare;
- model rich-text JSON restricționat și validat server-side, fără stocare de HTML executabil;
- compatibilitate menținută prin câmpurile plain-text `purpose` / `objectives`;
- randare rich-text în pagina serviciului și în DOCX;
- conversie automată din textul existent la prima afișare/editare;
- migrarea `022_service_rich_text.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.1

- câmp narativ **Scop și domeniu** pentru serviciul intern, reutilizând `purpose` pentru compatibilitate;
- câmp nou **Obiective** pe serviciul intern;
- afișare aerisită a Descrierii, Scopului și domeniului și Obiectivelor;
- schema logică a serviciului inclusă automat în DOCX;
- un singur nod per VM în schema DOCX, cu toate asocierile și rolurile acelui VM;
- placeholdere `{{service.scope_domain}}` și `{{service.objectives}}`;
- migrarea `021_service_scope_objectives_docx_diagram.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.0

- schemă automată a serviciului, agregată din asocierile VM;
- un singur nod per VM, cu multiple asocieri afișate în același nod;
- grupare pe layer și zonă Multi-layer;
- pictograme configurabile prin `icon_key` în nomenclatoare;
- iconițe implicite pentru clasificare, layere, roluri și tipuri de soluție;
- export Excel nomenclatoare extins cu pictograma;
- migrarea `020_service_diagram_icons.up.sql`;
- OpenAPI și documentația actualizate.



## 0.6.0

- nomenclator `solution_type` și valori inițiale Open source / Dezvoltată intern / Comercială;
- `solution_type_id` pe asocierea VM–serviciu–layer–rol;
- interfață aerisită, pe carduri, pentru asocierile serviciilor din fișa VM;
- agregare tip soluție în lista și pagina Serviciilor interne;
- șabloane DOCX tipizate `vm` / `service` și șablon implicit pentru serviciu intern;
- previzualizare, generare, istoric și descărcare DOCX pentru Serviciu intern;
- numere de document `FSI-*` pentru fișele de serviciu;
- OpenAPI, documentație și migrarea `019_service_documents_solution_type.up.sql` actualizate.


## 0.5.1

- inventarul agentului este randat în tabele compacte, specifice fiecărei secțiuni, în locul flatten-ului generic;
- eliminate din document secțiunile Agent și Proxy și câmpul `uptime_seconds`;
- stocare în format partiție/filesystem/capacitate cu unități lizibile;
- rețea pe câte un rând pentru adresă și interfață;
- numai servicii active, porturi esențiale, reguli UFW numbered și conturi relevante;
- rezumat SSSD și matrice compactă pentru Auditbeat, Filebeat, GLPI Agent, Node Exporter și Syslog;
- cron și NTP simplificate; politici lăsate pregătite pentru completare ulterioară;
- tabele DOCX cu grilă explicită și lățimi fixe, compatibile cu randarea LibreOffice;
- fără migrare de bază de date.

## 0.5.0

- generator DOCX pentru fișa tehnică a VM-ului, disponibil direct în pagina VM;
- previzualizare a datelor și avertismente pentru inventar, servicii sau responsabilități lipsă;
- șabloane DOCX încărcabile și administrabile, cu șablon implicit creat automat;
- placeholder obligatoriu `{{VM_DOCUMENT_BODY}}` și placeholdere scalare pentru antetul șablonului;
- documentul include identificare, resurse, date operaționale, servicii, roluri, responsabilități, backup și inventarul structurat al agentului;
- istoric al documentelor generate, număr unic, fișier, dimensiune, SHA-256, autor și snapshot sursă;
- permisiuni noi `documents.read` și `documents.manage`;
- migrarea `018_document_generation.up.sql` creează `document_templates` și `generated_documents`.

## 0.4.4

- toate valorile nomenclatoarelor sunt sortate consecvent după ordinea părintelui, apoi după ordinea proprie și denumire;
- categoriile de serviciu sunt grupate după ordinea domeniului arhitectural;
- rolurile tehnice sunt grupate după primul layer în ordinea layer-elor, apoi după ordinea proprie; valorile nemapate sunt afișate la final;
- registrul Persoane este ordonat după departament, apoi după nume;
- filtre pe fiecare pagină de nomenclator: căutare text și stare, plus domeniu pentru categorii și layer pentru roluri;
- filtre suplimentare pentru Persoane: departament, sursă și stare;
- paginarea se aplică rezultatului filtrat, iar exportul Excel păstrează lista completă în ordinea nouă;
- fără migrare de bază de date.

## 0.4.3

- paginare pentru toate nomenclatoarele și pentru registrul Persoane, cu dimensiune selectabilă a paginii;
- export Excel pentru nomenclatorul curent, disponibil tuturor utilizatorilor cu permisiunea `nomenclatures.read`;
- exportul include toate rândurile active și inactive, nu numai pagina vizibilă;
- coloane relaționale în Excel pentru `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- export complet pentru persoane, inclusiv departament, sursă și cont AD;
- fără migrare de bază de date.

## 0.4.2

- corectată interogarea de citire a inventarului după ID: parametrul `id` este transmis către `QueryRowContext`;
- eliminată eroarea MariaDB `Error 1064 ... near '?' at line 1` la deschiderea fișei VM;
- inventarul curent și vederea structurată a JSON-ului agentului se încarcă din nou fără recollectare;
- fără migrare de bază de date.

## 0.4.1

- termenul vizibil **Categorie ITIL** este înlocuit cu **Categorie de serviciu**; cheia tehnică `itil_category` rămâne neschimbată pentru compatibilitate;
- integrare de tip director cu Active Directory, reutilizând gazdele LDAP, TLS-ul și contul bind deja configurate pentru autentificare;
- OU rădăcină configurabil, citire recursivă a utilizatorilor și afișare arborescentă după sub-OU-uri;
- filtrare obligatorie după atributul `department`, cu primul departament în ordine alfabetică selectat implicit sau cu un departament implicit configurabil;
- import multiplu și actualizare idempotentă a persoanelor din AD în registrul local de responsabilități, folosind `objectGUID` ca identitate stabilă;
- persoanele importate păstrează sursa LDAP și contul AD, iar reimportul actualizează numele, e-mailul, telefonul și departamentul;
- migrarea `017_service_category_ad_directory.up.sql` actualizează eticheta nomenclatorului și extinde tabelul `people` cu identitatea de director;
- migrarea `016_vm_service_classification.up.sql` este corectată astfel încât indexul nou să fie creat înainte de eliminarea indexului folosit de cheia externă.

## 0.4.0

- domeniul arhitectural și categoria de serviciu sunt mutate de la serviciul intern la asocierea VM–serviciu;
- formularul serviciului intern păstrează numai identitatea, descrierea, criticitatea și informațiile de documentare;
- fișa VM adaugă selectorul Categorie de serviciu între Domeniu și Serviciu intern;
- domeniul filtrează categoriile de serviciu, iar layer-ul filtrează rolurile tehnice;
- pagina și lista Servicii agregă automat încadrările domeniu–categorie din VM-uri;
- VM-urile din pagina serviciului afișează încadrarea folosită de fiecare asociere;
- validare backend pentru relația `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- migrarea `016_vm_service_classification.up.sql` păstrează încadrările existente și extinde cheia unică a asocierii.

## 0.3.9

- pagina Nomenclatoare nu mai afișează toate listele simultan;
- submeniu lateral grupat în Catalog servicii, Arhitectură tehnică, Operare VM și Responsabilități;
- se afișează o singură listă la un moment dat, cu numărul valorilor în submeniu;
- ruta păstrează categoria selectată, de exemplu `#nomenclatures/technical_role`;
- pe ecrane înguste, submeniul devine o grilă adaptivă de opțiuni;
- actualizarea este exclusiv de interfață și nu necesită migrare MariaDB.

## 0.3.8

- selecție în cascadă pe fișa VM: domeniu → serviciu intern → layer → rol tehnic;
- serviciile interne nu mai păstrează configurații layer–rol proprii; combinațiile observate sunt agregate automat din asocierile VM;
- validarea backend verifică serviciul și relația globală layer–rol, fără o restricție suplimentară la nivelul serviciului;
- selector multiplu cu căutare, stil Select2 și complet offline, pentru layer-ele permise ale unui rol tehnic;
- rolurile tehnice sunt ordonate după ordinea layer-ului, apoi după ordinea rolului;
- endpointul de modificare a combinațiilor layer–rol pe serviciu a fost eliminat din API și OpenAPI;
- actualizarea nu necesită migrare de schemă.

## 0.3.7

- fiecare rol tehnic este legat explicit de unul sau mai multe layer-e arhitecturale;
- rolurile sunt filtrate după layer în configurarea serviciului intern;
- validare server-side globală layer–rol, suplimentară față de validarea serviciului;
- relațiile deja folosite sunt migrate automat prin `015_layer_technical_role_mappings.up.sql`;
- relațiile utilizate nu pot fi eliminate accidental;
- Nomenclatoare afișează layer-ele permise pentru fiecare rol tehnic.

## 0.3.6

- relație multiplă VM–serviciu intern–layer–rol tehnic;
- mai multe servicii interne și mai multe roluri pentru același serviciu pe un singur VM;
- tip de utilizare `dedicated`, `shared` sau `dependency`, marcaj principal și observații pe asociere;
- profilul/data provisionării eliminate din modelul funcțional și din nomenclatoare;
- vechiul lifecycle `Retired` migrat la `Status operațional: Retras` și eliminat din interfața/API curent;
- cardul redundant „Rezumat ultimul inventar” eliminat;
- migrarea `014_multi_service_assignments.up.sql`, API, OpenAPI și documentație actualizate.

## 0.3.5

- fișa VM continuă să se încarce dacă datele operaționale sau sumarul de backup au o eroare;
- toate etapele de încărcare a fișei VM sunt jurnalizate cu `stage` și `vm_id`;
- versiunea din interfață este citită din `/version`, nu mai este hard-codată.

## 0.3.4

- pagina VM se încarcă degradat dacă datele agentului, snapshotul curent sau vederea structurată nu pot fi citite;
- erorile opționale din fișa VM sunt jurnalizate cu etapa exactă și `vm_id`;
- interfața afișează un avertisment fără a bloca datele vCenter și operaționale.

## 0.3.3

- secțiunile cu datele colectate de agent sunt restrânse implicit, inclusiv listele de obiecte din interior;
- istoricul inventarelor VM este paginat server-side, cu 10, 20, 50 sau 100 de înregistrări pe pagină;
- pagina Audit este paginată server-side, cu 25, 50, 100 sau 200 de evenimente pe pagină;
- endpointurile de inventar și audit acceptă `page` și `page_size` și întorc metadate de paginare;
- OpenAPI, testele și documentația de upgrade au fost actualizate;
- include corecția de compilare pentru funcția `nullableInt64Ptr` din 0.3.2.

## 0.3.2

- meniu principal **Servicii** pentru catalogul serviciilor interne;
- `Serviciu` ITIL este redenumit **Categorie de serviciu**, iar vechea `Componentă` devine **Serviciu intern**;
- ierarhie validată `Domeniu arhitectural → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- categoriile de serviciu sunt legate de domeniul arhitectural părinte;
- fiecare serviciu definește explicit combinațiile layer–rol permise;
- fișa VM folosește list-box-uri în cascadă și backendul respinge combinațiile incompatibile;
- pagina serviciului afișează descrierea, criticitatea, starea documentației, combinațiile permise și VM-urile asociate;
- migrare automată a datelor 0.3.1 și permisiuni RBAC `services.read` / `services.manage`;
- API și OpenAPI pentru catalogul serviciilor prin migrarea `013_internal_service_catalog.up.sql`.

## 0.3.1

- meniu nou **Nomenclatoare** pentru serviciu, componentă, domeniu arhitectural, layer, mediu, status operațional, profil de provisionare și clasificare;
- câmpurile controlate din fișa VM sunt list-box-uri și nu mai acceptă text liber;
- registru de persoane și mai multe responsabilități pe aceeași VM;
- secțiune separată **Backup și restaurare · Veeam**, cu model de date pregătit pentru sincronizarea prin API;
- migrarea automată a valorilor și responsabililor existenți din 0.3.0;
- endpointuri API, audit și OpenAPI pentru nomenclatoare și persoane;
- migrarea `012_nomenclatures_responsibilities_backup.up.sql`.

## 0.3.0

- pagină VM refăcută ca fișă tehnică structurată pe carduri și secțiuni pliabile;
- vedere sigură a inventarului agentului, cu mascarea câmpurilor sensibile;
- date operaționale separate de snapshoturile agentului și sincronizarea vCenter;
- tabel nou `vm_operational_metadata` prin migrarea 011;
- endpoint `PUT /api/v1/vms/{id}/operational` și audit `vm.operational.update`;
- formular pentru serviciu, componentă, domeniu, layer, mediu, status, scop, responsabili, provisionare, RPO/RTO, backup, clasificare și referințe;
- OpenAPI, documentație și teste actualizate.

## 0.2.2

- autoînregistrare pentru vm-doc-agent 1.1.0;
- heartbeat și stare online/offline fără creare manuală;
- push direct al inventarului;
- asociere automată cu VM după UUID;
- migrarea 010 și documentația de upgrade.


## 0.2.1

- căutare și filtre VM după nume/hostname, power, OS, IP, agent, `Retired` și sursă vCenter;
- paginare server-side și selector 25/50/100/200 înregistrări;
- statistici pentru rezultatele filtrate;
- export Excel `.xlsx` fără dependențe Go suplimentare;
- antet fix corect în tabelul VM, fără suprapunerea primului rând;
- API-ul `GET /api/v1/vms` întoarce un obiect paginat;
- endpoint nou `GET /api/v1/vms/export`;
- listele vCenter goale sunt serializate ca `[]`, nu `null`;
- rutele Swagger sunt înregistrate explicit ca `GET`, evitând panic în Go 1.23.

## 0.2.0

- vCenter devine sursa principală pentru lista de VM-uri;
- CRUD pentru surse vCenter, cu parolă criptată și verificare TLS;
- sincronizare manuală per sursă sau pentru toate sursele;
- scheduler zilnic configurabil per sursă, în fusul orar al aplicației;
- tabele `vcenter_sources`, `virtual_machines` și `vcenter_sync_runs`;
- VM-urile absente sunt marcate `missing_from_vcenter`, fără ștergere automată;
- lifecycle local `Retired`, cu dată, utilizator și notă;
- asociere automată după BIOS/DMI UUID, inclusiv ordinea SMBIOS legacy VMware;
- asociere manuală și dezlegare agent din fișa VM;
- stare agent și colectare manuală direct din fișa VM;
- parser pentru `agent.id`, `agent.version`, `collection.collectors`, FQDN și UUID-uri de corelare;
- listă VM, filtre, pagină de detaliu și istoric sincronizări în frontend;
- permisiuni RBAC noi: `vcenter.read`, `vcenter.manage`, `vms.manage`;
- OpenAPI 3.1 și documentație actualizate.

## 0.1.0

- două binare: `vm-doc-server` și `vm-doc-collector`;
- configurație YAML și secrete criptate AES-256-GCM;
- migrații MariaDB incluse în binar;
- autentificare LDAP și Keycloak/OIDC cu PKCE;
- sesiuni server-side, CSRF și RBAC;
- administrarea agenților și tokenuri criptate individual;
- joburi manuale și periodice cu lease;
- testare agent, colectare, UUID binding și validare schemă 2.x;
- snapshoturi brute, istoric, hash și stare online/offline;
- audit server/collector;
- frontend static fără Node.js;
- OpenAPI 3.1 și Swagger UI embedded;
- unități systemd și reverse proxy Nginx.
