# Upgrade 0.20.55 → 0.20.56

1. Copiază directorul 0.20.55 în 0.20.56 sau aplică arhiva update peste copia nouă.
2. Nu există migrare DB nouă.
3. Rulează testele și build-ul offline:

```bash
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

4. Repornește serviciul `vm-doc-server` și fă `Ctrl+F5`.

## Schimbări

- `Ascunde porturile ascultate` ascunde doar lista completă; porturile marcate Principal rămân în secțiunea dedicată.
- Porturi ascultate este omisă complet din DOCX/Markdown/Outline când este ascunsă.
- Publicarea individuală VM → Outline este asincronă și nu mai depinde de timeout-ul request-ului browser/reverse proxy.
- Fără update de agent.
