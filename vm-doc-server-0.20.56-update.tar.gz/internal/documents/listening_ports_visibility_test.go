package documents

import (
	"strings"
	"testing"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/inventory"
)

func TestVMMarkdownKeepsPrimaryPortsWhenListeningPortsSectionIsAbsent(t *testing.T) {
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{
		{Key: "system", Title: "Sistem", Data: map[string]any{"hostname": "dc01"}},
	}}
	data := GenerationData{
		VM:                domain.VirtualMachine{Name: "dc01"},
		InventoryDocument: &view,
		PrimaryPorts: []domain.PrimaryAgentPort{
			{Protocol: "tcp", Port: 53, ProcessName: "dns", Addresses: []string{"0.0.0.0"}, Detected: true},
		},
	}
	text := string(RenderVMMarkdown(data))
	if !strings.Contains(text, "Porturi și procese principale") || !strings.Contains(text, "53/TCP") {
		t.Fatalf("primary port must remain in VM markdown: %s", text)
	}
	if strings.Contains(text, "Porturi ascultate") {
		t.Fatalf("listening ports section must be omitted when collector section is absent: %s", text)
	}
}

func TestCompactInventoryMarkdownIncludesListeningPortsWhenSectionExists(t *testing.T) {
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{
		{Key: "listening_ports", Title: "Porturi ascultate", Data: []any{map[string]any{"protocol": "tcp", "port": 443}}},
	}}
	var out strings.Builder
	compactInventoryMarkdown(&out, &view, 3)
	if !strings.Contains(out.String(), "Porturi ascultate") {
		t.Fatalf("listening ports section must remain when present: %s", out.String())
	}
}
