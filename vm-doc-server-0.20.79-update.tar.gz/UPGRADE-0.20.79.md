# Upgrade VM-DOC Server 0.20.78 → 0.20.79

0.20.79 este un update de Network Map/UI. Nu există migrare DB și nu este necesar Sync FortiGate după upgrade.

## Pași

```bash
systemctl stop vm-doc-server
cp -a /usr/local/src/vm-doc-server-0.20.78 /usr/local/src/vm-doc-server-0.20.79
tar -xzf vm-doc-server-0.20.79-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.79
cd /usr/local/src/vm-doc-server-0.20.79
# build/deploy conform procedurii locale
systemctl start vm-doc-server
```

## Verificări recomandate

1. Deschide Securitate → Firewall → Caută pe un tabel lat și verifică bara orizontală a paginii jos.
2. Deschide VM → Securitate → Hartă rețea și extinde un obiect Forti cu mai mult de 4 adrese/obiecte.
3. Verifică nodul VM: porturile trebuie să fie afișate vertical; pentru HTTPS/HTTP/SSH/DB sau servicii cu port numeric, săgeata inbound trebuie să ajungă la portul corespunzător dacă acesta este observat.
4. Verifică o hartă cu peste 24 fluxuri: toate fluxurile primite de Network Map trebuie desenate.

Agentul rămâne 1.7.12.
