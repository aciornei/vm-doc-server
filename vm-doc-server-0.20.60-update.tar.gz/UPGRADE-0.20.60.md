# Upgrade 0.20.59 → 0.20.60

## Ce se schimbă

Versiunea 0.20.60 curăță câmpul **Versiune** din **Rapoarte → Componente software**.

Valorile brute provenite din colectoare pot conține uneori bannerul complet al executabilului sau mesaje stderr. De exemplu:

```text
/usr/sbin/mysqld Ver 10.6.11-MariaDB-0ubuntu0.22.04.1 ...
```

este afișat acum simplu:

```text
10.6.11
```

Liniile de tip `[Warning]`, `[Error]`, `deprecated`, `adjusted to`, `invalid option` etc. nu mai sunt acceptate drept versiuni.

Corecția este aplicată în momentul construirii inventarului agregat, deci repară și datele deja existente fără o nouă colectare de agent.

## Bază de date

Nu există migrare DB nouă.

## Agent

Nu este necesar update de `vm-doc-agent`.

## Instalare offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.59 \
      /usr/local/src/vm-doc-server-0.20.60

tar -xzf vm-doc-server-0.20.60-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.60

cd /usr/local/src/vm-doc-server-0.20.60

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Înlocuiește binarul, repornește `vm-doc-server`, apoi fă `Ctrl+F5` în browser.

## Verificare recomandată

1. Deschide **Rapoarte → Componente software**.
2. Selectează **MariaDB**.
3. Valorile de versiune trebuie să fie compacte, de exemplu `10.6.11` sau `10.11.14`.
4. Nu trebuie să mai existe rânduri de versiune care conțin `[Warning]`, `deprecated`, date/ore sau texte de log.
5. Verifică și Export Excel / publicarea Outline: trebuie să folosească aceleași versiuni curate.
