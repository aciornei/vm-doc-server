# Upgrade vm-doc-server 0.20.23 → 0.20.24

## Ce se schimbă

0.20.24 înlocuiește dashboardul minimal cu o primă pagină operațională:

- căutare globală după VM / IP / hostname / serviciu / persoană / container / DB / Web;
- KPI-uri clickabile pentru VM-uri, agenți offline, inventar vechi, backup, monitorizare și documentație incompletă;
- tabel **Necesită atenție** cu filtre rapide;
- modificări recente relevante din audit;
- stare colectări și ultimele sincronizări vCenter / Veeam / Prometheus;
- grad de acoperire pentru servicii, responsabili, backup, monitorizare, baseline și documentație;
- grupuri HA cu probleme și servicii care necesită completări;
- filtrul `Documentație incompletă` în raportul Lipsuri operaționale.

Nu există migrare DB nouă și nu este necesar update de agent.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.23 /usr/local/src/vm-doc-server-0.20.24
tar -xzf vm-doc-server-0.20.24-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.24
cd /usr/local/src/vm-doc-server-0.20.24
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

## Verificare funcțională

1. Deschide Dashboard și verifică încărcarea tuturor celor 6 KPI-uri.
2. Caută un hostname, un IP, un serviciu, un container și o bază de date în căutarea globală.
3. Apasă pe `Fără backup`, `Fără monitorizare` și `Documentație incompletă`; raportul trebuie să se deschidă direct cu filtrul selectat.
4. Verifică filtrele rapide din `Necesită atenție`.
5. Verifică `Modificări recente`, ultimele sincronizări și procentele din `Grad de acoperire`.
6. Pentru un grup HA configurat, verifică sumarul nodurilor și eventualele diferențe de resurse.
