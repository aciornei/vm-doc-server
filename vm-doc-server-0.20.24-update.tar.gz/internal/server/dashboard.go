package server

import (
	"context"
	"database/sql"
	"fmt"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"

	"vm-doc-server/internal/audit"
	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/rbac"
)

type dashboardAttentionRow struct {
	ID                  int64      `json:"id"`
	Name                string     `json:"name"`
	Hostname            string     `json:"hostname"`
	Environment         string     `json:"environment"`
	PowerState          string     `json:"power_state"`
	Responsibilities    string     `json:"responsibilities"`
	Services            string     `json:"services"`
	InventoryReceivedAt *time.Time `json:"inventory_received_at,omitempty"`
	NoResponsibility    bool       `json:"no_responsibility"`
	NoService           bool       `json:"no_service"`
	NoEnvironment       bool       `json:"no_environment"`
	NoAgent             bool       `json:"no_agent"`
	AgentOffline        bool       `json:"agent_offline"`
	InventoryStale      bool       `json:"inventory_stale"`
	BackupGap           bool       `json:"backup_gap"`
	MonitoringGap       bool       `json:"monitoring_gap"`
	NoBaseline          bool       `json:"no_baseline"`
	NoDocument          bool       `json:"no_document"`
	HAGap               bool       `json:"ha_gap"`
	DocumentationGap    bool       `json:"documentation_gap"`
	Issue               string     `json:"issue"`
	severity            int
}

type dashboardCoverageRow struct {
	Key     string `json:"key"`
	Label   string `json:"label"`
	Done    int64  `json:"done"`
	Total   int64  `json:"total"`
	Percent int64  `json:"percent"`
	URL     string `json:"url"`
}

type dashboardOperations struct {
	AgentsEnabled      int64      `json:"agents_enabled"`
	AgentsOnline       int64      `json:"agents_online"`
	InventoryFresh24h  int64      `json:"inventory_fresh_24h"`
	VMsActive          int64      `json:"vms_active"`
	CollectionErrors24 int64      `json:"collection_errors_24h"`
	JobsPending        int64      `json:"jobs_pending"`
	LastVCenterSync    *time.Time `json:"last_vcenter_sync,omitempty"`
	LastVeeamSync      *time.Time `json:"last_veeam_sync,omitempty"`
	LastMonitoringSync *time.Time `json:"last_monitoring_sync,omitempty"`
}

type dashboardHAGroup struct {
	Name               string `json:"name"`
	Type               string `json:"type"`
	SourceVMID         int64  `json:"source_vm_id"`
	SourceVMName       string `json:"source_vm_name"`
	Nodes              int64  `json:"nodes"`
	HealthIssues       int64  `json:"health_issues"`
	ResourceMismatches int64  `json:"resource_mismatches"`
	Issue              string `json:"issue"`
}

type dashboardSearchResult struct {
	Type      string `json:"type"`
	TypeLabel string `json:"type_label"`
	ID        int64  `json:"id"`
	Label     string `json:"label"`
	Subtitle  string `json:"subtitle"`
	URL       string `json:"url"`
}

func (a *App) dashboard(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	attention, err := dashboardAttention(ctx, a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}

	var vmsTotal, agentsOffline, inventoryStale, backupGaps, monitoringGaps, documentationIncomplete int64
	if err := a.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM virtual_machines WHERE retired=0`).Scan(&vmsTotal); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM agents WHERE enabled=1 AND (last_contact_at IS NULL OR TIMESTAMPDIFF(SECOND,last_contact_at,UTC_TIMESTAMP())>offline_after_seconds)`).Scan(&agentsOffline); err != nil {
		respond(w, nil, err)
		return
	}
	for _, item := range attention {
		if item.InventoryStale {
			inventoryStale++
		}
		if item.BackupGap {
			backupGaps++
		}
		if item.MonitoringGap {
			monitoringGaps++
		}
		if item.DocumentationGap {
			documentationIncomplete++
		}
	}

	coverage, err := dashboardCoverage(ctx, a.DB, vmsTotal)
	if err != nil {
		respond(w, nil, err)
		return
	}
	operations, err := dashboardOperationState(ctx, a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}
	haGroups, healthyHA, err := dashboardHAGroups(ctx, a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}
	serviceIssues, err := reportServiceIssues(ctx, a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if len(serviceIssues) > 8 {
		serviceIssues = serviceIssues[:8]
	}
	recent := []audit.Record{}
	if user, ok := auth.UserFromContext(ctx); ok && rbac.Allowed(user.Roles, "audit.read") {
		recent, err = dashboardRecentAudit(ctx, a.Audit)
		if err != nil {
			respond(w, nil, err)
			return
		}
	}

	if len(attention) > 50 {
		attention = attention[:50]
	}
	jsonResponse(w, http.StatusOK, map[string]any{
		"generated_at": time.Now().UTC(),
		"summary": map[string]int64{
			"vms_total":                vmsTotal,
			"agents_offline":           agentsOffline,
			"inventory_stale":          inventoryStale,
			"backup_gaps":              backupGaps,
			"monitoring_gaps":          monitoringGaps,
			"documentation_incomplete": documentationIncomplete,
		},
		"attention":         attention,
		"recent_changes":    recent,
		"operations":        operations,
		"coverage":          coverage,
		"ha_groups":         haGroups,
		"ha_groups_healthy": healthyHA,
		"service_issues":    serviceIssues,
	})
}

func dashboardAttention(ctx context.Context, db *sql.DB) ([]dashboardAttentionRow, error) {
	rows, err := db.QueryContext(ctx, `SELECT vm.id,vm.name,COALESCE(NULLIF(i.hostname,''),vm.guest_hostname,''),COALESCE(m.environment,''),vm.power_state,
		COALESCE((SELECT GROUP_CONCAT(DISTINCT p.display_name ORDER BY p.display_name SEPARATOR ', ') FROM vm_responsibilities vr JOIN people p ON p.id=vr.person_id WHERE vr.vm_id=vm.id AND p.active=1),''),
		COALESCE((SELECT GROUP_CONCAT(DISTINCT s.name ORDER BY s.name SEPARATOR ', ') FROM vm_internal_service_assignments va JOIN internal_services s ON s.id=va.internal_service_id WHERE va.vm_id=vm.id AND s.active=1),''),
		i.received_at,
		NOT EXISTS(SELECT 1 FROM vm_responsibilities vr WHERE vr.vm_id=vm.id) no_responsibility,
		NOT EXISTS(SELECT 1 FROM vm_internal_service_assignments va WHERE va.vm_id=vm.id) no_service,
		COALESCE(m.environment,'')='' no_environment,
		vm.agent_id IS NULL no_agent,
		CASE WHEN vm.agent_id IS NULL THEN 0 WHEN ag.enabled=0 OR ag.last_contact_at IS NULL OR TIMESTAMPDIFF(SECOND,ag.last_contact_at,UTC_TIMESTAMP())>ag.offline_after_seconds THEN 1 ELSE 0 END agent_offline,
		CASE WHEN vm.current_inventory_id IS NULL THEN 1 WHEN i.received_at<UTC_TIMESTAMP()-INTERVAL 7 DAY THEN 1 ELSE 0 END inventory_stale,
		CASE WHEN b.vm_id IS NULL THEN 1 WHEN COALESCE(b.protected,0)=0 AND COALESCE(b.cron_backup_enabled,0)=0 AND COALESCE(b.veeam_in_job,0)=0 THEN 1 ELSE 0 END backup_gap,
		NOT EXISTS(SELECT 1 FROM monitoring_targets mt WHERE mt.matched_vm_id=vm.id AND mt.present=1) monitoring_gap,
		NOT EXISTS(SELECT 1 FROM inventory_change_baselines bl WHERE bl.vm_id=vm.id) no_baseline,
		NOT EXISTS(SELECT 1 FROM generated_documents d WHERE d.object_type='vm' AND d.vm_id=vm.id) no_document,
		CASE WHEN inh.vm_id IS NULL OR COALESCE(inh.inherit_resource_assignments,0)=0 THEN 0 ELSE
			((SELECT COUNT(*) FROM docker_containers c WHERE c.vm_id=vm.id AND c.present=1)<>(SELECT COUNT(*) FROM docker_containers c WHERE c.vm_id=inh.source_vm_id AND c.present=1)) OR
			((SELECT COUNT(*) FROM database_instances di WHERE di.vm_id=vm.id AND di.present=1)<>(SELECT COUNT(*) FROM database_instances di WHERE di.vm_id=inh.source_vm_id AND di.present=1)) OR
			((SELECT COUNT(*) FROM database_catalogs dc WHERE dc.vm_id=vm.id AND dc.present=1 AND dc.is_system=0)<>(SELECT COUNT(*) FROM database_catalogs dc WHERE dc.vm_id=inh.source_vm_id AND dc.present=1 AND dc.is_system=0)) OR
			((SELECT COUNT(*) FROM web_sites ws WHERE ws.vm_id=vm.id AND ws.present=1)<>(SELECT COUNT(*) FROM web_sites ws WHERE ws.vm_id=inh.source_vm_id AND ws.present=1))
		END ha_gap
		FROM virtual_machines vm
		LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id
		LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id
		LEFT JOIN agents ag ON ag.id=vm.agent_id
		LEFT JOIN vm_backup_summary b ON b.vm_id=vm.id
		LEFT JOIN vm_documentation_inheritance inh ON inh.vm_id=vm.id
		WHERE vm.retired=0 ORDER BY vm.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]dashboardAttentionRow, 0)
	for rows.Next() {
		var item dashboardAttentionRow
		var inventoryAt sql.NullTime
		var noResp, noService, noEnv, noAgent, agentOffline, stale, backup, monitoring, baseline, document, haGap int
		if err := rows.Scan(&item.ID, &item.Name, &item.Hostname, &item.Environment, &item.PowerState, &item.Responsibilities, &item.Services, &inventoryAt, &noResp, &noService, &noEnv, &noAgent, &agentOffline, &stale, &backup, &monitoring, &baseline, &document, &haGap); err != nil {
			return nil, err
		}
		if inventoryAt.Valid {
			value := inventoryAt.Time
			item.InventoryReceivedAt = &value
		}
		item.NoResponsibility = noResp != 0
		item.NoService = noService != 0
		item.NoEnvironment = noEnv != 0
		item.NoAgent = noAgent != 0
		item.AgentOffline = agentOffline != 0
		item.InventoryStale = stale != 0
		item.BackupGap = backup != 0
		item.MonitoringGap = monitoring != 0
		item.NoBaseline = baseline != 0
		item.NoDocument = document != 0
		item.HAGap = haGap != 0
		item.DocumentationGap = item.NoResponsibility || item.NoService || item.NoEnvironment || item.NoBaseline || item.NoDocument
		issues := make([]string, 0, 11)
		if item.NoAgent {
			issues = append(issues, "fără agent")
			item.severity += 110
		} else if item.AgentOffline {
			issues = append(issues, "agent offline")
			item.severity += 105
		}
		if item.BackupGap {
			issues = append(issues, "backup neacoperit")
			item.severity += 95
		}
		if item.InventoryStale {
			issues = append(issues, "inventar lipsă / > 7 zile")
			item.severity += 90
		}
		if item.MonitoringGap {
			issues = append(issues, "fără monitorizare")
			item.severity += 80
		}
		if item.HAGap {
			issues = append(issues, "diferență resurse HA")
			item.severity += 75
		}
		if item.NoResponsibility {
			issues = append(issues, "fără responsabil")
			item.severity += 55
		}
		if item.NoService {
			issues = append(issues, "fără serviciu")
			item.severity += 45
		}
		if item.NoEnvironment {
			issues = append(issues, "fără mediu")
			item.severity += 35
		}
		if item.NoBaseline {
			issues = append(issues, "fără baseline")
			item.severity += 25
		}
		if item.NoDocument {
			issues = append(issues, "fără fișă VM")
			item.severity += 15
		}
		item.Issue = strings.Join(issues, "; ")
		if item.Issue != "" {
			out = append(out, item)
		}
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].severity == out[j].severity {
			return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name)
		}
		return out[i].severity > out[j].severity
	})
	return out, nil
}

func dashboardCoverage(ctx context.Context, db *sql.DB, vmTotal int64) ([]dashboardCoverageRow, error) {
	type metric struct {
		key, label, query, url string
		total                  int64
	}
	metrics := []metric{
		{"services", "Servicii asociate", `SELECT COUNT(*) FROM virtual_machines vm WHERE vm.retired=0 AND EXISTS(SELECT 1 FROM vm_internal_service_assignments a WHERE a.vm_id=vm.id)`, "#reports/operations/service", vmTotal},
		{"responsibilities", "Responsabili", `SELECT COUNT(*) FROM virtual_machines vm WHERE vm.retired=0 AND EXISTS(SELECT 1 FROM vm_responsibilities r WHERE r.vm_id=vm.id)`, "#reports/operations/responsibility", vmTotal},
		{"backup", "Backup", `SELECT COUNT(*) FROM virtual_machines vm JOIN vm_backup_summary b ON b.vm_id=vm.id WHERE vm.retired=0 AND (COALESCE(b.protected,0)=1 OR COALESCE(b.cron_backup_enabled,0)=1 OR COALESCE(b.veeam_in_job,0)=1)`, "#reports/operations/backup", vmTotal},
		{"monitoring", "Monitorizare", `SELECT COUNT(*) FROM virtual_machines vm WHERE vm.retired=0 AND EXISTS(SELECT 1 FROM monitoring_targets mt WHERE mt.matched_vm_id=vm.id AND mt.present=1)`, "#reports/operations/monitoring", vmTotal},
		{"baseline", "Baseline", `SELECT COUNT(*) FROM virtual_machines vm WHERE vm.retired=0 AND EXISTS(SELECT 1 FROM inventory_change_baselines bl WHERE bl.vm_id=vm.id)`, "#reports/operations/baseline", vmTotal},
		{"vm_documents", "Documentație VM", `SELECT COUNT(*) FROM virtual_machines vm WHERE vm.retired=0 AND EXISTS(SELECT 1 FROM generated_documents d WHERE d.object_type='vm' AND d.vm_id=vm.id)`, "#reports/operations/document", vmTotal},
	}
	var serviceTotal int64
	if err := db.QueryRowContext(ctx, `SELECT COUNT(*) FROM internal_services WHERE active=1`).Scan(&serviceTotal); err != nil {
		return nil, err
	}
	metrics = append(metrics, metric{"service_documents", "Documentație servicii", `SELECT COUNT(*) FROM internal_services s WHERE s.active=1 AND EXISTS(SELECT 1 FROM generated_documents d WHERE d.object_type='service' AND d.internal_service_id=s.id)`, "#reports/documents", serviceTotal})
	out := make([]dashboardCoverageRow, 0, len(metrics))
	for _, item := range metrics {
		var done int64
		if err := db.QueryRowContext(ctx, item.query).Scan(&done); err != nil {
			return nil, err
		}
		percent := int64(100)
		if item.total > 0 {
			percent = done * 100 / item.total
		}
		out = append(out, dashboardCoverageRow{Key: item.key, Label: item.label, Done: done, Total: item.total, Percent: percent, URL: item.url})
	}
	return out, nil
}

func dashboardOperationState(ctx context.Context, db *sql.DB) (dashboardOperations, error) {
	var out dashboardOperations
	queries := []struct {
		target *int64
		query  string
	}{
		{&out.AgentsEnabled, `SELECT COUNT(*) FROM agents WHERE enabled=1`},
		{&out.AgentsOnline, `SELECT COUNT(*) FROM agents WHERE enabled=1 AND last_contact_at IS NOT NULL AND TIMESTAMPDIFF(SECOND,last_contact_at,UTC_TIMESTAMP())<=offline_after_seconds`},
		{&out.VMsActive, `SELECT COUNT(*) FROM virtual_machines WHERE retired=0`},
		{&out.InventoryFresh24h, `SELECT COUNT(*) FROM virtual_machines vm JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0 AND i.received_at>=UTC_TIMESTAMP()-INTERVAL 1 DAY`},
		{&out.CollectionErrors24, `SELECT COUNT(*) FROM collection_jobs WHERE status='failed' AND created_at>=UTC_TIMESTAMP()-INTERVAL 1 DAY`},
		{&out.JobsPending, `SELECT COUNT(*) FROM collection_jobs WHERE status IN ('queued','running')`},
	}
	for _, item := range queries {
		if err := db.QueryRowContext(ctx, item.query).Scan(item.target); err != nil {
			return dashboardOperations{}, err
		}
	}
	var err error
	if out.LastVCenterSync, err = dashboardMaxTime(ctx, db, `SELECT MAX(last_success_at) FROM vcenter_sources WHERE enabled=1`); err != nil {
		return dashboardOperations{}, err
	}
	if out.LastVeeamSync, err = dashboardMaxTime(ctx, db, `SELECT MAX(last_success_at) FROM veeam_sources WHERE enabled=1`); err != nil {
		return dashboardOperations{}, err
	}
	if out.LastMonitoringSync, err = dashboardMaxTime(ctx, db, `SELECT MAX(last_success_at) FROM prometheus_sources WHERE enabled=1`); err != nil {
		return dashboardOperations{}, err
	}
	return out, nil
}

func dashboardMaxTime(ctx context.Context, db *sql.DB, query string) (*time.Time, error) {
	var value sql.NullTime
	if err := db.QueryRowContext(ctx, query).Scan(&value); err != nil {
		return nil, err
	}
	if !value.Valid {
		return nil, nil
	}
	result := value.Time
	return &result, nil
}

func dashboardHAGroups(ctx context.Context, db *sql.DB) ([]dashboardHAGroup, int64, error) {
	rows, err := db.QueryContext(ctx, `SELECT COALESCE(NULLIF(inh.group_name,''),CONCAT(src.name,' · cluster')),inh.group_type,inh.source_vm_id,src.name,COUNT(DISTINCT inh.vm_id)+1 nodes,
		SUM(CASE WHEN member.agent_id IS NULL OR ag.enabled=0 OR ag.last_contact_at IS NULL OR TIMESTAMPDIFF(SECOND,ag.last_contact_at,UTC_TIMESTAMP())>ag.offline_after_seconds OR member.current_inventory_id IS NULL OR inv.received_at<UTC_TIMESTAMP()-INTERVAL 7 DAY OR b.vm_id IS NULL OR (COALESCE(b.protected,0)=0 AND COALESCE(b.cron_backup_enabled,0)=0 AND COALESCE(b.veeam_in_job,0)=0) OR NOT EXISTS(SELECT 1 FROM monitoring_targets mt WHERE mt.matched_vm_id=member.id AND mt.present=1) THEN 1 ELSE 0 END) health_issues,
		SUM(CASE WHEN COALESCE(inh.inherit_resource_assignments,0)=0 THEN 0 WHEN
			((SELECT COUNT(*) FROM docker_containers c WHERE c.vm_id=member.id AND c.present=1)<>(SELECT COUNT(*) FROM docker_containers c WHERE c.vm_id=inh.source_vm_id AND c.present=1)) OR
			((SELECT COUNT(*) FROM database_instances di WHERE di.vm_id=member.id AND di.present=1)<>(SELECT COUNT(*) FROM database_instances di WHERE di.vm_id=inh.source_vm_id AND di.present=1)) OR
			((SELECT COUNT(*) FROM database_catalogs dc WHERE dc.vm_id=member.id AND dc.present=1 AND dc.is_system=0)<>(SELECT COUNT(*) FROM database_catalogs dc WHERE dc.vm_id=inh.source_vm_id AND dc.present=1 AND dc.is_system=0)) OR
			((SELECT COUNT(*) FROM web_sites ws WHERE ws.vm_id=member.id AND ws.present=1)<>(SELECT COUNT(*) FROM web_sites ws WHERE ws.vm_id=inh.source_vm_id AND ws.present=1)) THEN 1 ELSE 0 END) resource_mismatches
		FROM vm_documentation_inheritance inh
		JOIN virtual_machines member ON member.id=inh.vm_id AND member.retired=0
		JOIN virtual_machines src ON src.id=inh.source_vm_id AND src.retired=0
		LEFT JOIN agents ag ON ag.id=member.agent_id
		LEFT JOIN inventory_snapshots inv ON inv.id=member.current_inventory_id
		LEFT JOIN vm_backup_summary b ON b.vm_id=member.id
		GROUP BY COALESCE(NULLIF(inh.group_name,''),CONCAT(src.name,' · cluster')),inh.group_type,inh.source_vm_id,src.name
		ORDER BY health_issues DESC,resource_mismatches DESC,1`)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()
	all := make([]dashboardHAGroup, 0)
	var healthy int64
	for rows.Next() {
		var item dashboardHAGroup
		if err := rows.Scan(&item.Name, &item.Type, &item.SourceVMID, &item.SourceVMName, &item.Nodes, &item.HealthIssues, &item.ResourceMismatches); err != nil {
			return nil, 0, err
		}
		parts := make([]string, 0, 2)
		if item.HealthIssues > 0 {
			parts = append(parts, fmt.Sprintf("%d nod(uri) cu probleme operaționale", item.HealthIssues))
		}
		if item.ResourceMismatches > 0 {
			parts = append(parts, fmt.Sprintf("%d diferență(e) de resurse", item.ResourceMismatches))
		}
		item.Issue = strings.Join(parts, "; ")
		if item.Issue == "" {
			healthy++
		} else {
			all = append(all, item)
		}
	}
	if err := rows.Err(); err != nil {
		return nil, 0, err
	}
	if len(all) > 8 {
		all = all[:8]
	}
	return all, healthy, nil
}

func dashboardRecentAudit(ctx context.Context, svc audit.Service) ([]audit.Record, error) {
	page, err := svc.ListFiltered(ctx, audit.Filter{Page: 1, PageSize: 60})
	if err != nil {
		return nil, err
	}
	out := make([]audit.Record, 0, 10)
	for _, item := range page.Items {
		if item.Operation == "operation" {
			action := strings.ToLower(item.Action)
			if strings.HasPrefix(action, "collection.") || strings.Contains(action, ".sync") || strings.Contains(action, ".test") || strings.Contains(action, "heartbeat") {
				continue
			}
		}
		out = append(out, item)
		if len(out) >= 10 {
			break
		}
	}
	return out, nil
}

func (a *App) dashboardSearch(w http.ResponseWriter, r *http.Request) {
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	if len([]rune(q)) < 2 {
		jsonResponse(w, http.StatusOK, []dashboardSearchResult{})
		return
	}
	items, err := dashboardSearchAll(r.Context(), a.DB, q)
	respond(w, items, err)
}

func dashboardSearchAll(ctx context.Context, db *sql.DB, q string) ([]dashboardSearchResult, error) {
	like := "%" + q + "%"
	out := make([]dashboardSearchResult, 0, 36)
	appendRows := func(query string, args []any, scan func(*sql.Rows) (dashboardSearchResult, error)) error {
		rows, err := db.QueryContext(ctx, query, args...)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			item, err := scan(rows)
			if err != nil {
				return err
			}
			out = append(out, item)
		}
		return rows.Err()
	}
	if err := appendRows(`SELECT vm.id,vm.name,COALESCE(NULLIF(i.hostname,''),vm.guest_hostname,''),COALESCE(NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,''),'') FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0 AND (vm.name LIKE ? OR vm.guest_hostname LIKE ? OR vm.primary_ip LIKE ? OR i.hostname LIKE ? OR i.primary_ip LIKE ? OR EXISTS(SELECT 1 FROM vcenter_vm_ips vip WHERE vip.vm_id=vm.id AND vip.ip_address LIKE ?)) ORDER BY vm.name LIMIT 8`, []any{like, like, like, like, like, like}, func(rows *sql.Rows) (dashboardSearchResult, error) {
		var id int64
		var name, host, ip string
		if err := rows.Scan(&id, &name, &host, &ip); err != nil {
			return dashboardSearchResult{}, err
		}
		parts := make([]string, 0, 2)
		if host != "" {
			parts = append(parts, host)
		}
		if ip != "" {
			parts = append(parts, ip)
		}
		return dashboardSearchResult{Type: "vm", TypeLabel: "VM", ID: id, Label: name, Subtitle: strings.Join(parts, " · "), URL: fmt.Sprintf("#vms/%d/overview", id)}, nil
	}); err != nil {
		return nil, err
	}
	if err := appendRows(`SELECT id,name,COALESCE(service_code,''),COALESCE(description,'') FROM internal_services WHERE active=1 AND (name LIKE ? OR COALESCE(service_code,'') LIKE ? OR description LIKE ?) ORDER BY name LIMIT 6`, []any{like, like, like}, func(rows *sql.Rows) (dashboardSearchResult, error) {
		var id int64
		var name, code, description string
		if err := rows.Scan(&id, &name, &code, &description); err != nil {
			return dashboardSearchResult{}, err
		}
		sub := code
		if sub == "" {
			sub = description
		}
		if len([]rune(sub)) > 90 {
			sub = string([]rune(sub)[:90]) + "…"
		}
		return dashboardSearchResult{Type: "service", TypeLabel: "Serviciu", ID: id, Label: name, Subtitle: sub, URL: fmt.Sprintf("#services/%d/overview", id)}, nil
	}); err != nil {
		return nil, err
	}
	if err := appendRows(`SELECT id,display_name,email,department FROM people WHERE active=1 AND (display_name LIKE ? OR email LIKE ? OR department LIKE ?) ORDER BY display_name LIMIT 6`, []any{like, like, like}, func(rows *sql.Rows) (dashboardSearchResult, error) {
		var id int64
		var name, email, department string
		if err := rows.Scan(&id, &name, &email, &department); err != nil {
			return dashboardSearchResult{}, err
		}
		sub := strings.Trim(strings.Join([]string{department, email}, " · "), " ·")
		return dashboardSearchResult{Type: "person", TypeLabel: "Persoană", ID: id, Label: name, Subtitle: sub, URL: "#reports/people/" + url.PathEscape(name)}, nil
	}); err != nil {
		return nil, err
	}
	if err := appendRows(`SELECT c.id,c.name,c.image_ref,c.compose_project,c.compose_service,vm.id,vm.name FROM docker_containers c JOIN virtual_machines vm ON vm.id=c.vm_id WHERE c.present=1 AND vm.retired=0 AND (c.name LIKE ? OR c.image_ref LIKE ? OR c.compose_project LIKE ? OR c.compose_service LIKE ?) ORDER BY c.name LIMIT 6`, []any{like, like, like, like}, func(rows *sql.Rows) (dashboardSearchResult, error) {
		var id, vmID int64
		var name, image, project, service, vmName string
		if err := rows.Scan(&id, &name, &image, &project, &service, &vmID, &vmName); err != nil {
			return dashboardSearchResult{}, err
		}
		compose := strings.Trim(strings.Join([]string{project, service}, "/"), "/")
		sub := vmName
		if compose != "" {
			sub += " · " + compose
		} else if image != "" {
			sub += " · " + image
		}
		return dashboardSearchResult{Type: "docker", TypeLabel: "Container", ID: id, Label: name, Subtitle: sub, URL: fmt.Sprintf("#vms/%d/docker", vmID)}, nil
	}); err != nil {
		return nil, err
	}
	if err := appendRows(`SELECT di.id,TRIM(CONCAT(COALESCE(NULLIF(di.product,''),di.engine),' ',COALESCE(di.instance_name,''))),di.version,vm.id,vm.name FROM database_instances di JOIN virtual_machines vm ON vm.id=di.vm_id WHERE di.present=1 AND vm.retired=0 AND (di.engine LIKE ? OR di.product LIKE ? OR di.instance_name LIKE ? OR di.version LIKE ?) ORDER BY vm.name,di.engine LIMIT 5`, []any{like, like, like, like}, func(rows *sql.Rows) (dashboardSearchResult, error) {
		var id, vmID int64
		var name, version, vmName string
		if err := rows.Scan(&id, &name, &version, &vmID, &vmName); err != nil {
			return dashboardSearchResult{}, err
		}
		return dashboardSearchResult{Type: "database", TypeLabel: "Instanță DB", ID: id, Label: name, Subtitle: strings.Trim(strings.Join([]string{vmName, version}, " · "), " ·"), URL: fmt.Sprintf("#vms/%d/databases", vmID)}, nil
	}); err != nil {
		return nil, err
	}
	if err := appendRows(`SELECT dc.id,dc.name,di.engine,vm.id,vm.name FROM database_catalogs dc JOIN database_instances di ON di.id=dc.database_instance_id JOIN virtual_machines vm ON vm.id=dc.vm_id WHERE dc.present=1 AND dc.is_system=0 AND vm.retired=0 AND (dc.name LIKE ? OR di.engine LIKE ?) ORDER BY dc.name LIMIT 6`, []any{like, like}, func(rows *sql.Rows) (dashboardSearchResult, error) {
		var id, vmID int64
		var name, engine, vmName string
		if err := rows.Scan(&id, &name, &engine, &vmID, &vmName); err != nil {
			return dashboardSearchResult{}, err
		}
		return dashboardSearchResult{Type: "database", TypeLabel: "Bază de date", ID: id, Label: name, Subtitle: vmName + " · " + engine, URL: fmt.Sprintf("#vms/%d/databases", vmID)}, nil
	}); err != nil {
		return nil, err
	}
	if err := appendRows(`SELECT ws.id,COALESCE(NULLIF(ws.name,''),ws.identity_key),ws.engine,vm.id,vm.name FROM web_sites ws JOIN virtual_machines vm ON vm.id=ws.vm_id WHERE ws.present=1 AND vm.retired=0 AND (ws.name LIKE ? OR ws.engine LIKE ? OR ws.identity_key LIKE ? OR ws.server_names_json LIKE ? OR ws.bindings_json LIKE ?) ORDER BY vm.name,ws.name LIMIT 6`, []any{like, like, like, like, like}, func(rows *sql.Rows) (dashboardSearchResult, error) {
		var id, vmID int64
		var name, engine, vmName string
		if err := rows.Scan(&id, &name, &engine, &vmID, &vmName); err != nil {
			return dashboardSearchResult{}, err
		}
		return dashboardSearchResult{Type: "web", TypeLabel: "Web / LB", ID: id, Label: name, Subtitle: vmName + " · " + engine, URL: fmt.Sprintf("#vms/%d/web", vmID)}, nil
	}); err != nil {
		return nil, err
	}
	return out, nil
}
