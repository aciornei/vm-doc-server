# Upgrade VM-DOC 0.21.87 → 0.21.88

1. Fă backup binar, surse, configurație și MariaDB.
2. Oprește VM-DOC Server și aplică `vm-doc-server-0.21.87-to-0.21.88-update.tar.gz` în rădăcina surselor complete 0.21.87, sau înlocuiește sursele cu `vm-doc-server-0.21.88-source.zip`.
3. Verifică `bash scripts/cleanup-source-tree.sh --check`.
4. Compilează cu dependențele offline: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
5. Instalează binarul în locația reală din `systemctl cat vm-doc-server`; pornește serviciul, verifică jurnalul.
6. Verifică în browser `app.js?v=0.21.88`, `app.css?v=0.21.88`; rulează Ctrl+F5 dacă este necesar.
7. Global/VM → Modificări: filtre aplicate, Detalii în Tip, tabel aliniat fără scrollbar orizontal.
8. Global/VM → De documentat: lupa, colapsarea filtrelor, tabel 14px, paginare, bulk, export.
9. VM → Timeline: data și ora în stânga, fără cod HTML în pagină.

**Rollback:** reinstalează binarul/sursele 0.21.87. Nu există migrare SQL de reversat. Agentul rămâne 1.7.18.
