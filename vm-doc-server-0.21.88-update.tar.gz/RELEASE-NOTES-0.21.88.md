# VM-DOC Server 0.21.88 — Modificări UI uniformizate

**Bază:** 0.21.87 · **Data:** 2026-10-23 · **Agent:** 1.7.18, neschimbat.

## Schimbări
- Global → Modificări: tabelul folosește întreaga lățime a panoului, ca în fișa VM. «Detalii» este mutat în celula «Tip», sub eticheta Adăugat/Eliminat/Modificat. Diferențele se deschid pe întreaga lățime a tabelului.
- Global/VM → Modificări: un mic panou «Filtre aplicate» afișează termenul de căutare, categoria, tipul, cerința documentației și starea. Se actualizează imediat la schimbarea filtrelor, cu text escapăt.
- Global/VM → De documentat: search pe rând cu lupă centrată vertical, Export Excel, buton-săgeată pentru filtrele avansate (colapsate implicit), rezumatul filtrelor, același tabel cu 14px și layout adaptiv fără scroll orizontal global. Paginarea server-side 10/20/50/100 și bulk rămân neschimbate.
- VM → Timeline: remediere «cod HTML afișat în loc de dată»; dt() returnează markup escapat intern și trebuie introdus ca HTML, nu dublu-escapat. Data și ora sunt stilizate pe rânduri separate.

## Compatibilitate
Nu există migrare SQL, schimbare de API, detector semantic, baseline, obligații de documentare sau agent. Nu se șterg snapshoturi și modificări. Modificările de frontend sunt încorporate prin go:embed în binarul Go, deci necesită rebuild + actualizare binar.

## Limite testare
Sunt verificate sintaxa JS, testele Go independente și previzualizările Chromium cu date simulate. Build-ul complet Go cu vendor, SQL MariaDB și exportul XLSX real nu au fost disponibile în acest mediu. Validarea în staging rămâne necesară.
