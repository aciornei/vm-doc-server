## 0.21.88 — 2026-10-23 — Uniformizare Modificări / De documentat și Timeline
- Modificări globale și în fișa VM: «Detalii» apare în coloana Tip, sub Adăugat/Eliminat/Modificat; rândul de diferențe rămâne pe întreaga lățime.
- Căutare și filtre: sumar «Filtre aplicate» sincronizat cu termenul de căutare și filtrele selectate, fără refacerea DOM-ului câmpului la fiecare tastare.
- De documentat global și VM: aceeași bară de căutare cu lupă centrată, Export Excel și filtru avansat colapsabil, plus rezumatul filtrelor active.
- Tabele fără lățimi minime arbitrare: afișare adaptivă pe ecrane înguste, păstrând toate câmpurile și acțiunile; textul rămâne lizibil la 14px în De documentat.
- Timeline: formatul HTML returnat de dt() este afișat, nu escapăt a doua oară; data și ora apar lizibil în stânga axei.
- Fără migrare SQL / schimbare de API, detector sau agent.

## 0.21.87 — 2026-10-23 — Interfață Modificări globală/VM
- Global Modificări: panou/tabel pe lățimea disponibilă, fără modificări ale detectorului.
- De documentat (global + VM): afișează nume resursă urmat de tipul în paranteză; păstrează paginarea server-side, filtrele, Excel și bulk.
- VM Timeline: data și ora numai în stânga axei pentru fiecare eveniment, fără data în dreapta ori eticheta «Istoricul reviziilor»; Include ignorate în dreapta titlului panoului; explicații în partea de jos cu margini.
- VM Modificări: tabel adaptiv fără scrollbar orizontal la 600–1440 px; toate controalele păstrate; la lățimi reduse rândul se reorganizează.
- Ghid global și VM: conținut comun cu margini proprii, fără cardul introductiv redundant.
- Nicio migrare, schimbare de API sau de agent.

## 0.21.86 — 2026-10-23
- Global Modificări: bara de navigare se întinde pe pagina disponibilă, dar taburile sunt compacte, exact ca la VM; carduri KPI de înălțime uniformă, lățimi responsive fără scroll la nivelul paginii.
- De documentat (global și VM): căutare lată și lupă aliniată în stilul fișei VM, tabel cu font 14px; selecție pe pagina curentă și acțiune bulk «Marchează selectatele Documentat». Sunt eligibile numai obligațiile deja revizuite. Salvările sunt executate prin endpointurile existente, fiecare răspuns e contabilizat separat.
- VM → Modificări: checkbox pe fiecare rând, «Selectează toate» pentru pagina vizibilă, alegere comună a valorilor Documentație/Stare și «Salvează selectate»; confirmare înainte de avansarea baseline-ului, raportare succes/eșec individual; nu operează asupra paginilor nevizibile.
- Timeline VM: data afișată în stânga axei, switchul «Include evenimente ignorate» în dreapta antetului și explicația semnificației datelor sub timeline.
- Ghid global și Ghid VM: aceeași componentă, explicațiile Documentație «Nesetat / Necesită / Nu necesită», Revizuit vs Documentat, detector semantic și baseline; matricea veche 3×3 a fost eliminată.
- Nicio schimbare de API, schemă, colector, baseline semantic sau agent. Build complet și MariaDB reală: necesită validare pe serverul offline cu vendor/.

## 0.21.85 — 2026-10-23
- Modificări globale: navigare în stil Inventar VM / Surse & sincronizări, cu subtitluri; două carduri noi pentru VM și servicii ce necesită documentare.
- De documentat: trei carduri KPI, tabel compact, căutare, filtre după resursă/status/categorie/revizie, paginare configurabilă și export Excel filtrat pe toate paginile (max. 20.000).
- VM → Modificări: timeline cu switch „Include ignorate”; tabel de modificări cu overflow local; De documentat reutilizează tabelul global filtrat după VM; Ghid cu pași clari și aceeași matrice.
- Clopoțel: ultimele 5 resurse în panou compact, număr total în `Vezi toate obligațiile (N)`.
- Extensie API: parametri `q`, `category`, `review_status` pentru obligații; endpoint XLSX nou. Fără migrare SQL, fără modificare de agent sau baseline.
- Teste JS și Chromium pe fixture; Go independent OK. Build-ul complet și MariaDB reală nevalidate.

## 0.21.84 — 2026-10-22
- Pagina globală Modificări are subpagini în stilul fișei VM: Modificări (implicit), De documentat și Ghid. Ghidul include matricea de stare/documentare, explicațiile detectorului și baseline-ului.
- VM → Modificări are Timeline (implicit), Modificări, De documentat și Ghid. Obligațiile VM sunt în De documentat, separate de timeline.
- Clopoțel mic (33px), panou 540px, ultimele 10 resurse ordonate după cea mai recentă obligație; contorul continuă să numere toate resursele restante. Link direct spre VM/De documentat sau serviciu, plus acces la lista globală paginată.
- Clarificare în Ghid: Documentat închide o obligație, nu este o stare de revizie.
- Fără migrare SQL, schimbări ale detectorului/baseline-ului sau ale agentului.
- Teste Chromium pentru navigare/notifications (640, 1024, 1440px); Go offline pentru pachetele independente; build integral și DB reală nevalidate.

## 0.21.83 — 2026-10-22
- VM → Modificări devine Timeline (implicit), Modificări și Ghid.
- Migrarea 084: sarcini de documentare separate VM/serviciu, confirmare Documentat cu autor și dată, indexuri pentru filtrarea restanțelor.
- Clopoțel lângă username, contor pe resurse, listă de linkuri și pagina globală De documentat.
- Procentul completitudinii VM urmărește documentarea efectivă, nu simpla revizie tehnică.
- Teste mock Chromium; compilarea completă/MariaDB reală nevalidate.

## 0.21.82 — 2026-10-22
- Ignorat manual separat de revenire automată (`reverted`), timeline implicit fără ignorate, filtre/contori activi neafectați, indexuri MariaDB 083, ghid actualizat și overflow orizontal corectat.

## 0.21.80 (2026-10-22)
- Help matrice decizii Documentație × Stare, cu efect real asupra VM și stare Documentat marcată neimplementată.
- Reducere spațiu căutare/tabel și înlocuire lupă Unicode cu SVG centrat. Fără schimbări backend/migrare.

## 0.21.79 (2026-10-22) — Modificări: căutare lată, info vizibil, detalii edge-to-edge

- Selectorul de domeniu al căutării ocupă maximum 150px; textul primește lățimea disponibilă și are buton dedicat.
- Toggle pentru filtrele avansate în extrema dreaptă, ca la Inventar VM; filtrele sunt pliate inițial.
- Explicații funcționale „i” la Documentație și Stare (clic și tastatură).
- Detectorul semantic și baseline-ul, pliate, au fost mutate sub tabel cu margin-top.
- Detalii sunt afișate fără padding lateral față de rândul părinte și cu rotunjire doar jos.
- Niciun impact asupra API, bazei de date, sistemului de autentificare, detectorului sau agentului.

## 0.21.78 (2026-10-22) — Căutare funcțională, layout și export Excel
- Cauză exactă rezolvată: callback-ul căutării returna referința loadGlobalChanges în loc să execute loadGlobalChanges(); Chrome confirmă acum apelul API la tastare.
- Căutarea globală pornește pe domeniul VM (nume sau hostname), dar permite Peste tot, Serviciu, Obiect. Confirmare la Enter/buton și debounce.
- Detector semantic și Baseline sunt colapsate implicit; Categorie, Tip, Documentație și Stare sunt grupate în Filtre avansate.
- Detalii păstrează rândul complet și folosește grilă ca la Securitate Firewall, cu rezumatul câmpurilor și diferențele anterior/nou.
- Export Excel pentru toate rândurile filtrate (maximum 20.000), nu doar pagina curentă; fără JSON brut sau referințe interne confidențiale.
- Nicio migrare SQL, nicio schimbare de agent și nicio modificare a comparației 1:1.

## 0.21.77 (2026-10-22) — UI Modificări și căutare servicii
- Detalii într-un rând pe toată lățimea; Documentație/Stare/Salvează rămân vizibile.
- Îndepărtare coloana Observații din UI; păstrare note vechi în PATCH.
- Căutare cu selector de domeniu VM/Serviciu/Obiect, buton Caută → și feedback; serviciile se caută și prin asocieri indirecte.
- Fără migrare SQL sau schimbări de agent; testat offline fără MariaDB reală.

## 0.21.76 (2026-10-22) — Căutare Modificări + comparator 1:1

- Fix căutare în lista Modificări global/VM: input, Enter, clear, anularea efectului cererilor întârziate și revenirea la pagina 1.
- Căutare SQL extinsă la `object_key`, `object_type`, `category` fără scanare JSON complet.
- Comparație semantică directă între snapshotul vechi și cel nou, fără o a treia observație. Fără pierderea protecției per-colector pentru `partial`/`timeout`/`disabled`/`truncated`.
- Datele istorice și baseline-urile nu sunt șterse; fără migrare SQL și fără schimbare agent.

## 0.21.74 — 2026-10-22 — Director LDAP independent de login

- `auth.ldap.enabled=false` nu mai blochează `auth.ldap.directory.enabled=true`; hosts sunt obligatorii când oricare funcție este pornită.
- Importurile AD (persoane, responsabili, beneficiari/OU) funcționează fără login LDAP; OIDC rămâne singurul provider activ într-o configurație OIDC-only.
- Login afișează doar metodele disponibile (LDAP, Keycloak, dev); textul și separatorul sunt dinamice, nu mai apare mesajul LDAP în OIDC-only.
- Endpointul de login cu parolă refuză cereri dacă atât login LDAP, cât și dev sunt dezactivate.
- Fără migrare SQL, fără schimbare agent.

## 0.21.73 — 2026-10-21 — Detector semantic pe domenii (Faza 1)

- Înlăturată restricția globală 0.21.72 pentru porturi TCP stabile, servicii OS nemarcate și reguli firewall explicite; păstrată normalizarea PID/workeri și regula confirmării.
- UDP, TCP/53/5353/5355, TCP 49152–65535 numai dacă portul este marcat Principal. Docker firewall rules generate rămân excluse.
- Guard `collection.collectors`: evenimente numai pentru colectări complete `success` (și fără truncation) în toate cele 3 snapshoturi; DB catalog/HBA/privilegii au protecții suplimentare pentru probe parțiale.
- Noi domenii în inventar de modificări: web ACL, DB utilizatori/privilegii/HBA, cron și software Win32/Windows features.
- **Etapa 2** FortiGate/Veeam/Prometheus central și **Etapa 3** „Documentat”/timeline încă neimplementate. Agent 1.7.18 neschimbat, fără migrare.
- Upgrade cumulativ **direct 0.21.71 → 0.21.73**; vechiul CLEANUP 0.21.72 dezactivat ca nesigur în noua politică. Instrucțiuni în `docs/UPGRADE-0.21.73.md`.

## 0.21.72 — 2026-10-21 — Politică STRICT globală pentru Modificări

- Porturi: numai Principal, cheie stabilă `protocol/port`; fluctuațiile de procese Postfix master/smtpd nu mai produc removed/added.
- Servicii: numai Componente suport; versiune / package_version / enabled_state.
- Firewall: în istoricul Modificări rămâne doar default_policies, nu fiecare regulă (toate regulile rămân în inventar).
- DB, Docker, Web, rețea, integrare: comparație strict semantică, nu runtime/detectare instabilă.
- **Confirmare de două colectări pentru toate categoriile**; nu doar pentru porturi. SQL manual PREVIEW/CLEANUP pentru zgomot istoric nerevizuit (firewall rules/servicii nemarcate/porturi nemarcate).
- Fără migrare, API sau agent nou; compilare offline și test MariaDB staging obligatorii. `docs/RELEASE-NOTES-0.21.72.md` explică compromisurile și regulile de siguranță.

## 0.21.71 (2026-10-21) — Filtrare servicii OS systemd-fsck

- Nu mai scrie evenimente `services|service` pentru `systemd-fsck@*.service`, `systemd-fsckd.service`, `systemd-fsck.service`, `systemd-fsck-root.service`, `systemd-fsck-usr.service`; acestea produc intrări duplicate la update-ul sistemului, câte una pe disc.
- Păstrează evenimentele pentru restul serviciilor și informațiile complete din inventarele brute.
- SQL țintit PREVIEW/CLEANUP numai manual pentru evenimentele istorice neexaminate; fără migrare SQL, schimbări API sau agent.
- Agent 1.7.18 neschimbat.

## 0.21.70 — 2026-10-21 — Corectare schimbări false versiune MySQL/MariaDB [Note]

- Captură reală din `inventory_changes`: versiune `261021 14:04:10 [Note] /usr/libexec/mysqld (mysqld 5.5.56-MariaDB) starting as process 59985 ...`, în care ora/PID-ul diferă între colectări.
- `internal/inventorychanges/noise.go`: recunoaște logul datat de startup `[Note]` pentru instanțele `engine=mysql/mariadb`, extrage **versiunea reală** din bannerul `mysqld/mariadbd`; modificările reale ale versiunii continuă să genereze evenimente.
- Păstrează filtrul `[Warning]/[Error]` și snapshoturile brute, fără schimbări la agent sau DB/API. Nu șterge/modifică retroactiv evenimentele deja scrise.
- SQL PREVIEW/CLEANUP **manual** pentru perechi `[Note]` cu aceeași versiune și toate celelalte câmpuri egale; exclude evenimentele revizuite, cu note sau decizii. Teste unitare și de regresie; test MariaDB reală încă necesar.

## 0.21.69 — 2026-10-21 — Docker iptables NAT POSTROUTING MASQUERADE

- Captură reală: `-A POSTROUTING -s 172.19.0.0/16 ! -o br-f7410327c933 -j MASQUERADE`, cu evenimente added/removed după regenerarea bridge-ului Docker. Familia de reguli e **iptables**, nu nftables, de aceea filtrul 0.21.60 nu o acoperea.
- Filtru strict în `internal/inventorychanges/noise.go`: numai backend iptables, family ipv4, table nat, chain POSTROUTING, acțiune MASQUERADE, sursă CIDR integral în RFC1918 (validat prin netip), bridge `br-<12hex>` și sintaxa exactă, fără condiții suplimentare. Alte reguli NAT sunt păstrate.
- `scripts/preview-iptables-nat-docker-02169.sql` și `scripts/cleanup-iptables-nat-docker-02169.sql` pentru istoricul deja stocat. **Manual**, după PREVIEW/backup/staging; nu afectează snapshoturi sau audit, protejează evenimentele revizuite/cu decizii/note.
- Teste unitare plus regresie pentru rotația bridge și păstrarea regulilor manuale. Nu se schimbă agentul 1.7.18, API, MariaDB schema, documentele sau datele brute; compilare completă cu vendor și MariaDB reală de verificat în staging.

## 0.21.69 — 2026-10-21 — Docker iptables NAT MASQUERADE fără zgomot

- Confirmat din captura utilizatorului: `iptables` `nat/POSTROUTING` cu `-A POSTROUTING -s 172.18/19.0.0/16 ! -o br-<12hex> -j MASQUERADE` generează perechi `removed/added` când Docker recreează bridge-ul. Filtrul nftables 0.21.60 nu putea identifica această sintaxă.
- `inventorychanges/noise.go`: exclude DOAR acest tip strict de regulă automată, cu rețea IPv4 complet RFC1918, CIDR aliniat și bridge `br-<12 hex>`. Nu exclude NAT administrat manual, `docker0`, bridge-uri cu nume stabil ori alte lanțuri/acțiuni; snapshoturile brute sunt păstrate.
- Două scripturi SQL **manuale** `scripts/preview-iptables-nat-docker-02169.sql` și `scripts/cleanup-iptables-nat-docker-02169.sql` pentru `inventory_changes` istoric, strict `added/removed` și cheie `firewall|rule|iptables|ipv4|nat|POSTROUTING|...`, cu evenimente revizuite/decise/adnotate protejate. Niciun DELETE automat sau migrare nouă.
- Teste pentru variantele capturate, schimbare de bridge fără evenimente, IPv4 public/nealiniat și reguli NAT explicit diferite. Agent 1.7.18 neschimbat; verificarea MariaDB staging și build Go complet cu vendor/ rămân necesare.

## 0.21.68 — 2026-10-21 — UI Arhivă VM & servicii · BETA

- Arhivă refăcută cu antet propriu, panglică BETA roșie identică cu Hardening și avertizare de funcționalitate în validare.
- KPI clicabile și filtrare din sumar, etape compacte, filtre responsive cu reset și rânduri/pagină, număr rezultate și paginare.
- Registru responsive: scroll orizontal, coloane compacte, observații la cerere, acțiuni ordonate și texte escape HTML.
- Test izolat Node `scripts/test-lifecycle-ui.cjs` pentru interacțiuni; nicio migrare SQL, nicio schimbare de backend, API sau agent (1.7.18).
- Build integral cu vendor și verificare reală în browser/MariaDB rămân obligatorii în staging.

## 0.21.67 — 2026-10-21 — Arhivă VM + Servicii și audit la dispariție vCenter

- UI Arhivă VM & servicii, ciclu de viață și tranziții explicite auditabile.
- Migrare 081 aditivă: motive, aprobator, retenție și snapshotul asocierilor directe VM–serviciu.
- Audit fără duplicare la prima dispariție neașteptată din vCenter.
- Fără ștergere automată din MariaDB; protecție pentru VM-uri și servicii retrase/arhivate.
- Inventar operațional separat de Arhivă; rollback necesită atenție la liste.

# CHANGELOG

## 0.21.66 — 2026-10-21 — Hotfix resource editor VM (Docker/Databases/Web)

- Cauză demonstrată de stack trace-ul real de la utilizator: `ReferenceError: vmResourceContexts is not defined` în `registerResourceEditor`, `app.js` (0.21.65), apelat din `vmDetail` pe cele trei pagini.
- Inițializat registrul partajat `const vmResourceContexts=new Map();` înainte de utilizare. `registerResourceEditor` și `resolveResourceContext` folosesc aceeași hartă, cu cheie `(vmID,section)`.
- Test Node fără dependențe `scripts/test-vm-resource-context.cjs`: trei secțiuni, înregistrare/rezolvare, izolare per VM.
- Refreshed asset version + diagnostic markers 0.21.66; fără API/migrare/agent nou. Compilarea integrală cu vendor, test browser real se validează în staging.


## 0.21.65 — 2026-10-21 — Mediu din nomenclator și diagnostic `vmContext`
- Cele șase filtre de mediu de lângă Power (Agenți, Inventar VM, Backup, Monitorizare, raport OS suportat, raport publicare Outline VM) folosesc toate valorile nomenclatorului `environment`, inclusiv cele inactive marcate ca atare; la navigare, catalogul este încărcat din API și se invalidează după editarea nomenclatoarelor.
- Valoarea implicită rămâne Power ON + PROD (gruparea existentă), iar opțiunile custom filtrează exact numele din nomenclator prin `name:<label>` în API, inclusiv SQL parametrizat pentru liste și exporturi.
- `vmenv.Matches`, `vmenv.Predicate` și `vmenv.Normalize` suportă nume custom; raportul OS și Outline folosesc aceeași semantică în tabel și Excel. Teste de regresie pentru medii custom.
- `vmContext is not defined`: mesajul este raportat în UI cu sursa/linia/stack trace și markerul aplicației 0.21.65 pe VM → Docker/DB/Web. Simbolul nu există în sursele JS 0.21.64 și cauza exactă NU poate fi declarată rezolvată înainte de analiza stack trace-ului real.
- Fără migrare SQL, fără schimbări de agent; necesar build pe server cu `vendor/` și test MariaDB/browser.

## 0.21.64 (2026-10-21) — Power și Mediu implicit Pornite + PROD; încărcare JS sigură

- Filtrele **Power** și **Mediu** sunt simultan vizibile în cele șase secțiuni: Agenți, Inventar VM, Backup Veeam, Monitorizare VM, Raport suport OS și Raport publicare Outline VM. Valorile implicite sunt **POWERED_ON / PROD**; Toate/TEST/DEV/Oprite pot fi selectate independent. „Resetează” revine la ON + PROD.
- Backendul aplică filtrarea mediului înainte de `COUNT`, paginare și export XLSX; folosește nomenclatorul VM cu fallback la metadata și normalizează etichetele Producție/PROD, TEST/UAT, DEV/Dezvoltare. Interogarea implicită Agenți este paginată în SQL, fără încărcarea completă a agentilor.
- Rapoartele OS și Outline aplică aceeași clasificare la afișare și export; cardurile și linkurile de export rămân coerente cu filtrele curente.
- Asseturile statice HTML/JS sunt versionate 0.21.64 și servite cu `Cache-Control: no-store` pentru a evita rularea combinată a JavaScript vechi și interfeței noi. În sursele 0.21.63 nu există referință literală `vmContext`; această măsură vizează problema probabilă de cache, nu reprezintă diagnostic cert al erorii Docker. Dacă revine, este necesară linia din Console/stack trace.
- Fără migrare SQL nouă și fără schimbare agent (1.7.18). Nu modifică procesele de inventar și publicare. Build Go complet cu vendor și test browser cu backend real de verificat în staging.

## 0.21.63 (2026-10-21) — Resource pool tree și Audit

- Dialogul Pool-uri are spacing, arbore real din vCenter, expandare și selecție pe subarbore; indicatori per pool și avertizări pentru VM pornite.
- Audit de tip `vcenter.pool.excluded/included` cu numărul VM-urilor, `excluded_count_change` la modificarea populației, `vm_powered_on` la VM pornită în pool exclus; stare persistentă anti-spam.
- Migrare 080; update Go/JS/CSS/OpenAPI, fără agent nou, fără ștergeri VM sau modificări documente.
- Teste Go izolate și validări statice; integrare VCSA/MariaDB și build cu vendor încă nevalidate.


## 0.21.62 (2026-10-21) — Filtru resource pool vCenter

- Sursa vCenter descoperă pool-uri prin `/api/vcenter/resource-pool`, asociază VM-urile prin `/api/vcenter/vm?resource_pools=...`; default toate selectate.
- Configurație per sursă (`vcenter_source_id`, MoRef), dashboard avertizare pentru `POWERED_ON` excluse.
- Noua migrare `079_vcenter_resource_pools.up.sql` adaugă tabela `vcenter_resource_pools` și două coloane în `virtual_machines`.
- VM-urile existente în pool-uri excluse nu sunt șterse, retrase sau marcate lipsă; sunt ascunse din lista normală, exportul VM și generarea/publicarea fișei VM. VM-urile noi excluse nu sunt create.
- Full Go build cu `vendor/` și integration testing VCSA/MariaDB rămân necesare. Agentul 1.7.18 neschimbat.

## 0.21.61 (2026-10-20) — Versiuni Elastic Beats fără zgomot

- `inventorychanges`: normalizează bannerul Beat `auditbeat version 9.4.1 (amd64), libbeat 9.4.1 ... built timestamp` la `9.4.1` exclusiv pentru comparațiile semantic relevante. Suport Auditbeat/Filebeat/Metricbeat/Packetbeat/Heartbeat/Winlogbeat.
- Identitatea produsului și libbeat trebuie să fie congruente; modificările `package_version`, versiuni reale și restul inventarului rămân intacte.
- Integrare Auditbeat/Filebeat normalizată și ea; teste Go de regresie și SQL separat PREVIEW/CLEANUP pentru istoricul vechi; fără migrare DB automată sau update de agent.
- Build complet vendor/MariaDB staging neconfirmat în acest mediu.

## 0.21.60 (2026-10-20) — Filtrare semantică minimă inventory_changes

Docker numai name+image/tag (fără IP/MAC/porturi/digest/Compose), UDP numai Principal, warninguri MySQL la `version` eliminate inclusiv la instanțe DB, filtrare specifică nftables nat/POSTROUTING bridge Docker MASQUERADE. SQL de curățare țintit manual pentru zgomot vechi, cu PREVIEW și protecția deciziilor/review-urilor. Inventare brute neatinse, agent 1.7.18 compatibil, fără migrare sau API nou. Build complet/MariaDB staging încă de verificat.

## 0.21.59 (2026-10-20) — iptables Docker raw/PREROUTING (nu nftables)

- Reprodus exemplul real `-A PREROUTING -d 172.18.0.7/32 ! -i br-f392b3fbdb12 -j DROP`, raportat cu backend `iptables`, table `raw`, family `ipv4`, chain `PREROUTING`.
- Suprimare precisă a acestui guard Docker generat din istoricul de modificări; aceeași regulă cu numele bridge-ului schimbat nu mai generează `removed/added`.
- Nu sunt excluse alte reguli `DROP`, alte chain/table sau reguli manuale, DOCKER-USER, destinații publice, interfețe stabile. `inventory_snapshots` rămâne complet.
- PREVIEW/CLEANUP SQL *țintit*, manual, pentru vechile rânduri `iptables` din `inventory_changes` (nu doar `nftables`). Review-uri, decizii și note manuale protejate.
- Fără migrare automată, API/agent nou. Teste unitare Go; build complet cu vendor și SQL live MariaDB de validat în staging.

## 0.21.58 (2026-10-20) — SQL cleanup fix pentru Docker bridge / nftables

- Corectat object_key compus în PREVIEW/CLEANUP: `firewall|rule|nftables|...`, `network|interface|veth...`.
- Adăugată excluderea semantică numai pentru interfețe Docker generate `br-<12 hex>`.
- Adăugate PREVIEW și CLEANUP țintite pentru bridge și nftables fără modificarea inventarului brut; protecție review/decizii/observații.
- Reparat diagnostic SQL nftables; versiunea anterioară putea raporta 0 din cauza cheii greșite.
- Fără migrare API/SQL automată sau update agent. Full build și MariaDB staging încă necesare.

## 0.21.57 (2026-10-20) — Docker MAC-only și diagnostic nftables

- MAC-ul endpointurilor Docker este exclus numai din istoricul semantic al modificărilor; inventarul brut și documentația Docker îl păstrează.
- IP/gateway/network ID/imagine/configurație reală rămân detectate. Teste de regresie pentru comparație fără mutația datelor sursă.
- Regula nftables Docker guard recunoaște și `meta iifname` / bridge neîncadrat în ghilimele; alte reguli și DOCKER-USER rămân.
- SQL diagnostic nftables read-only și PREVIEW/CLEANUP cumulativ 0.21.50–0.21.57 (nou: Docker MAC-only), cu protecțiile pentru revizii și note.
- Fără migrare automată, API sau actualizare agent. Validare MariaDB reală / build cu vendor/ încă necesare.

## 0.21.56 (2026-10-20) — Porturi stabile și nftables Docker bridge guards

- Cheia evenimentului `listening_port` folosește lista **deduplicată** a proceselor, nu fiecare worker Apache; previne `added/removed` fals pentru TCP/443 și TCP/80 cu JSON identic. Confirmarea porturilor prin trei snapshoturi din 0.21.52 rămâne.
- Filtru restrâns pentru reguli `nftables` generate la schimbarea bridge-urilor Docker, `ip daddr <IPv4 privat> iifname != "br-<12 hex>" counter drop`, inclusiv variante cu contoare și `# handle`; exclude `DOCKER-USER` și nu atinge politicile administrate explicit ori alte reguli.
- `PREVIEW/CLEANUP` SQL cumulativ 0.21.50–0.21.56 elimină perechi opuse cu chei vechi diferite, dar VM/inventory_id/label/JSON identice, și guard-uri Docker recunoscute; protejează reviziile, deciziile și notele. Backup + staging înainte de ștergere; snapshoturile brute rămân.
- Fără migrare SQL automată, schimbare API, update de agent (1.7.18), dependențe Go noi sau schimbări de documentație/Outline/Vault. Teste noi pentru porturi Apache/nftables; validarea MariaDB live și build-ul full cu `vendor/` rămân de confirmat.

## 0.21.55 (2026-10-20) — Windows SCM DisplayName în istoricul schimbărilor

- Detectorul de modificări ignoră **doar** `software_name` pentru serviciile raportate cu `manager=windows_scm` (mapat de agentul Windows 1.7.18 din `Win32_Service.DisplayName`). Oscilații precum `Windows Update` ↔ `wuauserv` și `Work Folders` ↔ `workfolderssvc` nu mai produc `modified`.
- Numele stabil `name`, adăugarea/eliminarea serviciilor, `enabled_state`, `version`, `package_version` și `manager` continuă să producă modificări. Alte platforme/manageri rămân neschimbați. Datele din `inventory_snapshots` și inventarul tehnic afișat nu sunt modificate.
- Scripturile **cumulative** PREVIEW/CLEANUP 0.21.50–0.21.55 adaugă filtrul `software_name_windows_scm`, exclusiv pentru rândurile istorice `modified` cu `old_json/new_json` valide, manager Windows SCM pe ambele părți, **doar `software_name` diferit**, fără review/decizie/notițe. Cleanup manual după backup și test MariaDB staging, fără migrare automată.
- Teste noi de regresie: descrieri Windows oscilante, enabled/versiuni/manager rămân urmărite, Linux/sysv neschimbate, servicii scoase din inventar rămân detectate. Agent 1.7.18 și API neschimbate. Full Go build cu `vendor/` și MariaDB reală sunt de verificat offline.

## 0.21.54 (2026-10-20) — Windows per-user services: familii suplimentare

- Extinsă **lista restrictivă** a serviciilor Windows per-user din detectorul de modificări cu `P9RdrService`, `NPSMSvc`, `DeviceAssociationBrokerSvc`. Numai instanțele cu nume `<familie>_<sufix hexadecimal de 5–12 caractere>` sunt excluse din `inventory_changes`; numele de bază și serviciile necunoscute rămân urmărite.
- SQL PREVIEW/CLEANUP cumulativ 0.21.50–0.21.54 include aceste trei familii și păstrează filtrele de protecție a review-urilor, deciziilor și observațiilor. Ștergerea este manuală după backup și staging; inventarele brute nu sunt modificate.
- Teste pentru nume cu sufixe de lungimi diferite și pentru excluderea conservatoare a familiilor necunoscute. Agent 1.7.18 și API/schema SQL neschimbate. Build complet cu `vendor/` și integrarea MariaDB rămân de confirmat pe sistemul offline.

## 0.21.53 (2026-10-20) — Excludere veth efemer din istoricul modificărilor

- Detectorul de inventar ignoră strict interfețele Linux **veth + sufix hexadecimal** (și varianta raportată cu `@ifN`) în istoricul `inventory_changes`. Nu se modifică inventarul agentului sau vizualizarea rețelei și nu sunt excluse `eth*`, `ens*`, `bond*`, `vlan*`, `docker0`, `br-*` ori interfețele `veth-*` denumite manual.
- SQL PREVIEW/CLEANUP cumulativ 0.21.50–0.21.53 include categoria `interfete_veth_efemere`, cu filtrare strictă și protecția review/decizii/notițe. SQL este manual, după backup, nu migrare automată.
- Teste Go pentru recunoașterea veth și păstrarea modificărilor rețelei reale. Agent 1.7.18 compatibil fără actualizare, API/schema neschimbate. Integrarea MariaDB și build-ul server cu `vendor/` necesită verificare offline.

## 0.21.52 (2026-10-20) — Confirmare porturi și curățare perechi false

- Evenimentele pentru porturi ascultate apar doar după **două colectări consecutive care confirmă noua stare**. Un port TCP/80 cu `apache2` care dispare temporar și reapare la colectarea următoare nu mai produce perechi de modificări false. Păstrăm modificările persistente, inclusiv schimbarea executabilului/procesului; restul categoriilor nu primesc întârziere.
- Evenimentul confirmat indică inventarul anterior real și inventarul curent; fără migrare SQL.
- Scripturile de curățare a regulilor firewall generate citesc acum corect `object_key` (`backend|family|table|chain|rule`), reparând o condiție istorică ce nu se potrivea cu formatul real.
- SQL Preview/CLEANUP manual cumulativ 0.21.50–0.21.52: elimină perechile opuse `added/removed` cu aceeași VM, cheie și valoare JSON în interval <= 10 minute (inclusiv porturi precum TCP/80); nu elimină review-uri, decizii/documentare sau note.
- Agent 1.7.18 nemodificat. Raw `inventory_snapshots` neatins. Verificarea completă cu `vendor/` și MariaDB staging rămâne obligatorie.

## 0.21.51 (2026-10-20) — Zgomot servicii per-user, lxd-installer și versiuni MySQL

- **Windows:** filtrează numai lista controlată de servicii per-user cu sufix hexadecimal (`PrintWorkflowUserSvc`, `PimIndexMaintenanceSvc`, `DevicesFlowUserSvc`, `DevicePickerUserSvc`, `ConsentUxUserSvc`, `CaptureService` etc.), fără a exclude servicii terțe după sufix.
- **Linux:** acceptă și instanțe efemere `lxd-installer@177-1372636-0.service`, nu doar formatul `@68.service`; instanțele denumite arbitrar nu sunt excluse.
- **Versiuni servicii:** dacă `version` sau `package_version` include mesaje `[Warning]`/`[Error]`, liniile diagnostice sunt ignorate la compararea snapshoturilor. Liniile de versiune valide și schimbările reale de pachet/`enabled_state` rămân urmărite; snapshotul brut nu este schimbat.
- **Curățare:** SQL preview și cleanup manual (incluzând și regulile 0.21.50) acoperă noile tipuri; protejează review/decizii/note. Fără rulare automată; nu șterge inventare brute.
- **Compatibilitate:** upgrade server **0.21.50 → 0.21.51**, fără migrare DB automată sau API nou; Agent **1.7.18** nemodificat. Go unit tests și packaging local, build Go cu vendor și SQL MariaDB pe staging rămân de confirmat.

## 0.21.50 (2026-10-20) — Reducerea zgomotului din inventory_changes

- **Porturi ascultate:** nu se mai generează evenimente `added/removed` pentru porturi ne-selectate ca **Principal** în intervalul **49152–65535**. Porturile Principale sunt protejate chiar dacă sunt în acest interval; inventarul brut și fișa VM nu sunt filtrate.
- **Firewall:** excludere țintită a regulilor din lanțuri generate automat (`ufw-before/after/track/logging/...`, `DOCKER*` mai puțin `DOCKER-USER`, CNI, Kubernetes, libvirt), în detectorul de schimbări, pentru nftables/iptables/ip6tables. Regulile administrate explicit rămân. Nu se șterge configurația firewall de pe VM-uri.
- **Servicii:** instanțe efemere `user@UID.service`, `user-runtime-dir@UID.service`, `lxd-installer@N.service`; `active_state`/`sub_state` nu mai produc eveniment pentru modificări de stare. `enabled_state`, versiunea/pachetul rămân urmărite.
- **NTP și integrări:** stare de sincronizare/sursă curentă, `service_active` și rezultate volatile ale testelor Beat excluse numai din istoria de modificări; configurațiile persistente rămân detectate.
- **Curățare istorică explicită:** `scripts/preview-inventory-changes-cleanup.sql` și `scripts/cleanup-inventory-changes.sql`; fără rulare automată. Se șterg numai rânduri cu `review_status='new'`, `documentation_requirement='unset'`, fără revizie și fără observații. Backup obligatoriu înainte; scriptul are tranzacție. Raw snapshots nu sunt atinse.
- **Compatibilitate:** server 0.21.49 → 0.21.50, Agent 1.7.18 nemodificat, **fără migrare automată sau modificare de API**. Teste unitare locale pentru filtrare; test MariaDB real și build Go complet cu `vendor/` de confirmat în staging.

## 0.21.49 (2026-10-19) — Hartă rețea: VM(IP), obiecte și SVG complet pentru export

- **Sursă/Destinație:** numele VM-urilor corelate și IP-urile lor apar împreună, ca `app-server-01(172.20.10.25)`; sub ele se afișează subtitlul **Obiecte FortiGate:** și fiecare obiect separat. Numele/IP-urile corelate nu sunt duplicate în lista de obiecte. La începutul coloanelor apar antetele **SURSĂ** și **DESTINAȚIE**.
- **Porturi VM:** distanța verticală dintre porturile observate crește de la 15 la 21 unități SVG, păstrând ancorele săgeților, click port↔linie și etichetele scurte `9078/tcp`.
- **Interpretare:** adăugat `padding-inline: 16px` pentru nota explicativă de sub hartă.
- **Export SVG:** nu mai este serializată copia diagramei interactive, ci este construită o vedere completă nouă care conține **toate obiectele FortiGate** și toate VM-urile din context, fără limitări/paginare/`Extinde`/`Restrânge`. Textele lungi sunt păstrate prin împărțire pe mai multe linii, iar casetele și fundalul SVG sunt albe, pentru documentație/print. Diagrama interactivă rămâne compactă și paginată.
- **Compatibilitate:** exclusiv JS/CSS și metadate, fără API nou, migrare SQL sau agent nou; Agent 1.7.18 neschimbat. Verificare Chromium pe date simulate, inclusiv export cu 125 de obiecte, `node --check`; testarea pe FortiGate real și build-ul Go cu `vendor/` rămân pentru staging.

## 0.21.48 (2026-10-19) — Hartă rețea: detalii FortiGate restaurate și afișare aerisită

- **Policy:** numai numărul (`#205`) în partea de sus, cu serviciile/porturile permise enumerate vertical în aceeași casetă, conform comportamentului 0.21.46. Numele policy, VDOM și NAT rămân în tooltip și în lista de fluxuri detaliate.
- **Sursă / Destinație:** sunt afișate din nou obiectele de adresă, IP-urile și VM-urile corelate, pe linii separate, fără etichete/titluri redundante. Listele foarte lungi sunt paginate în SVG: primele 4, apoi ferestre de câte 16; `Restrânge` și navigarea către obiectele anterioare/următoare rămân disponibile.
- **Porturi VM:** suprimă numai descrieri generice de tip „port ascultat”, lăsând `9078/tcp`; numele utile, de exemplu PostgreSQL, rămân. Filtrarea UDP și DNS 53 rămâne.
- **Aspect:** zona VM rămâne de 274 px, nodurile laterale și policy au mai mult spațiu, SVG folosește lățimea disponibilă și săgețile au vârf și mai mic; scroll exclusiv în diagramă.
- **Interacțiune:** păstrează evidențierea bidirecțională port ↔ policy/linie/nod și exportul SVG. Fără SQL/API/agent nou; Agent 1.7.18 neschimbat.
- **Validare:** `node --check`, Chromium mock 1595/1366/1024/390/350, listă de 125 obiecte, două policy-uri spre același port, diagramă de serviciu cu două VM-uri și comparație patch/update/source. Build complet cu `vendor/` și test pe FortiGate real rămân de confirmat în staging.

## 0.21.47 (2026-10-19) — Hartă rețea: KPI compacți și legături interactive

- **Carduri:** opt KPI într-un singur rând desktop, cu dimensiuni și spațiere reduse; margini superioare și laterale uniforme, responsive 4/2 coloane la lățimi mici.
- **SVG:** VM central lărgit la 274 px, zonă VM lărgită și spațiul orizontal redistribuit; nodurile FortiGate afișează doar `#Policy`, iar Sursă / Destinație doar tipul nodului, fără listele repetate. Obiectele, serviciile, VDOM și NAT rămân disponibile în panoul Fluxuri FortiGate corelate și în tooltip.
- **Conexiuni:** săgeți mai mici; click pe port TCP evidențiază fluxurile corelate cu acel port, iar click pe linie / policy / nodul sursă-destinație evidențiază fluxul și portul asociat; selecția poate fi anulată. Legarea portului se face exclusiv când există potrivire observată, fără atribuiri presupuse.
- **Compatibilitate:** fără modificări SQL, API sau agent. Verificările pe inventare reale FortiGate și compilarea completă Go cu `vendor/` rămân de efectuat în staging.

## 0.21.46 (2026-10-19) — Hartă rețea: compactare, scroll izolat și fluxuri expandabile

- **VM → Securitate → Hartă rețea:** panoul și zona diagramei nu mai lărgesc documentul sub meniul stâng; SVG-ul folosește spațiul disponibil și doar pe ecrane înguste are scroll în zona diagramei.
- **Diagramă:** VM central de 180 px în loc de 220 px, grup de o VM redus la 230 px, poziționare verticală mai jos, distanțe între nodurile FortiGate/declarații/VM reduse; nu sunt schimbate legăturile/ancorele porturilor sau regulile de filtrare.
- **Fluxuri corelate FortiGate:** liste pe verticală pentru VM-uri, adrese/obiecte și servicii; primele 4 valori + expandare la listele lungi. Deduplicare vizuală fără modificarea datelor brute.
- **Detalii tehnice:** două panouri independente, DECLARAT / OBSERVAT / PERMIS și Fluxuri FortiGate corelate, fiecare cu sumar și expandare; colapsate inițial pentru evitarea golurilor verticale.
- **Compatibilitate:** numai UI/metadate/documentație; fără migrare SQL, endpoint nou, modificări backend/agent. Agent 1.7.18 neschimbat. Build Go complet offline cu `vendor/` și browser pe date reale de verificat în staging.

## 0.21.45 (2026-10-19) — Hardening: 3 carduri, Export lângă controale și marcaj BETA tip semn de carte

- **VM → Securitate → Hardening:** cele două carduri (Profil de evaluare / Evaluare curentă) sunt completate de al treilea card **Profil aplicat**, cu selector și **Salvează profilul** pentru utilizatorii cu `vms.manage`. Fără drept de modificare, cardul este informativ; nu se expune o acțiune fără permisiune.
- **Controale evaluate:** butonul **Export Excel** este mutat în `panel-header`, în dreapta titlului, cu același URL/API și aceleași rezultate ca înainte.
- **BETA:** în fișa VM, Securitate → Hardening și Nomenclatoare → Hardening este afișat un semn de carte roșu în colțul din dreapta sus. Explicațiile detaliate despre validare, scor intern și necertificarea CIS sunt mutate la finalul conținutului (pagina de administrare păstrează și explicația sa existentă).
- **UI responsive:** cele trei carduri sunt pe un rând desktop, se adaptează la tabletă/mobil; butonul de salvare și exportul rămân accesibile. Compatibil cu modurile light/dark.
- **Fără schimbări de calcul**, colectare, SQL, migrare, endpointuri API, drepturi, Vault/Outline sau Agent 1.7.18. Modificări JS/CSS, versiune/cache-busting, OpenAPI `info.version`, istoricul release-urilor și documentele proiectului.
- **Validare locală:** `node --check`, teste Go independente și Chromium mock 1595/1024/390/350 px pentru carduri, export, BETA și overflow. Build complet cu `vendor/` și MariaDB reală rămân de testat în staging.

## 0.21.44 (2026-10-19) — Hardening BETA și corecție săgeată sortare Firewall

- **Securitate → Hardening** adoptă structura UI comună: antet de pagină cu statusul **BETA · în validare**, patru carduri KPI compacte și un panou unic **Evaluări VM** cu acțiuni **Profiluri și reguli** și **Export Excel** (doar cu permisiunile corespunzătoare).
- Filtre noi, fără API nou: căutare după VM/OS/profil și stare (cu neconformități, neverificate, fără profil sau fără neconformități). **Filtrele se aplică explicit numai paginii curente** (serverul păstrează paginarea 10/25/50/100), fără promisiune de căutare globală.
- Detaliile verificărilor sunt expandabile pe fiecare VM; tabelele late derulează numai în interiorul panoului, cu afișare responsive pe mobil. Indicatorii pentru neconforme/neverificate sunt explicit ai paginii curente.
- **VM → Securitate → Hardening** și **Nomenclatoare → Hardening** indică și ele starea **BETA**. Evaluarea rămâne un baseline intern, **nu** certificare CIS și nu execută remedieri automate.
- **Securitate → Firewall:** dezactivată sortarea generică a browserului pe tabelele FortiGate/Local cu detalii/revizii, eliminând indicatorul izolat `↕` din antet. Nu modifică paginarea, expandarea regulilor, exporturile sau reviziile.
- **Compatibilitate:** exclusiv JS/CSS, cache-busting, versiune/release și documentație; fără schimbări de logică Hardening, API, Swagger (în afară de `info.version`), migrare SQL, colectori sau Agent 1.7.18.
- **Verificări locale:** `node --check` și testele Go independente OpenAPI/Web/Buildinfo/Domain/XLSX/Migrations; Chromium cu date simulate la 1595/1024/390/350 px, inclusiv filtre, reset, detalii și lipsă overflow. Build Go integral cu `vendor/` și test MariaDB reală **neconfirmate**.

## 0.21.43 (2026-10-19) — Firewall: un rând de carduri, progres aliniat și policy compact

- **Navigare + KPI în același rând:** cardurile **FortiGate** și **Local** stau în stânga, indicatorii FortiGate stau în dreapta, cu spațiu flexibil între grupuri. Implementat în Firewall central și în VM → Securitate → Firewall, fără dublarea indicatorilor ori schimbarea filtrelor KPI. La 1595/1366 px se aliniază orizontal; la lățimi insuficiente se mută pe rândul următor, fără scroll orizontal global.
- **Revizuite X din Y:** indicatorul este într-un rând separat, la dreapta, cu padding de 18 px (14 px pe mobil). Disponibil pentru reguli FortiGate globale și per VM și regulile Firewall local (și după încărcare asincronă). Pentru pagina globală FortiGate contorul rămâne raportat la **pagina curentă**, nu la totalul neîncărcat.
- **Policy #:** eliminat paddingul suplimentar vertical al butonului care extinde detaliile; aliniere `vertical-align:top`, line-height uniform cu celelalte celule. Expandarea policy-ului și cele trei coloane de revizie sunt neschimbate.
- **Compatibilitate:** modificări doar `web/static/js/app.js`, `web/static/css/app.css`, metadata VERSION, cache busting, releases.json și documentație. **Fără migrare SQL, fără schimbări backend/API sau agent.** Agent 1.7.18 neschimbat. Build Go complet cu `vendor/` și verificare cu date reale în staging rămân de efectuat.
- **Verificări locale:** `node --check`, teste Chromium simulate la 1595/1366/1024/390/350 px pentru cele două grupuri, progres, policy și lipsa overflow-ului global; verificări pachete patch/update surse.

## 0.21.42 (2026-10-19) — Firewall: carduri de mod, revizii uniforme și detalii policy inline

- **FortiGate / Local** devin două carduri selectabile, nu doar butoane simple. Panoul separat **Filtre** dispare; Export Excel și Revizuiește secțiunea sunt în `panel-header`. Filtrele din pagina globală FortiGate se păstrează în „Căutare avansată”, în cadrul panoului de rezultate, pentru a nu pierde funcționalitatea.
- **Policy #** devine expandabil: click pe număr deschide sub rând detaliile FortiGate, VDOM, nume policy, Corelat prin, motiv, indicatori, schedule și status. Coloana Detalii dispare complet. Nu sunt eliminate date din inventar ori XLSX.
- **Revizie individuală:** fiecare regulă FortiGate și locală folosește componenta comună de **trei coloane Revizuit / De / Next review**, cu butonul Revizuiește pe regula respectivă. Starea nerevizuită are o acțiune întinsă pe trei coloane. Revizia colectivă existentă rămâne în antetul panoului și este limitată la VM.
- **Progres Revizuite X din Y:** în Firewall central este indicat pe pagina curentă (număr total corelări afișat separat, fără a pretinde că toate au fost încărcate); în Firewall local, pe regulile VM-ului; în Database Access pe Units Users/Grants/HBA, iar în Web ACL pe site-uri/vhost-uri. Revizia unui grup de granturi este per principal, nu per obiect/grant fizic.
- **UI:** păstrează scroll-ul orizontal doar în tabel și KPI-urile compacte. Teste JS, Chromium cu date simulate la 1595/1024/390/350 px și Go independent. **Fără migrare SQL, fără endpoint API nou, fără agent nou**: Agent 1.7.18 rămâne recomandat. Verificarea completă cu vendor/MariaDB în staging rămâne necesară.

## 0.21.41 (2026-10-19) — Firewall compact, filtre, export și revizie pe secțiune

- **Firewall central și fișa VM**: selector **FortiGate / Local**. Panoul unificat **Filtre** păstrează **Export Excel** și **Revizuiește secțiunea** vizibile, cu filtrele detaliate colapsabile și săgeată în dreapta.
- **FortiGate**: rol VM compact, **Policy #** fără nume lung, interfețe sursă/destinație și servicii afișate vertical; sursă/destinație clare. **Corelat prin**, motivul, indicatorii, numele policy, VDOM și schedule sunt accesibile la click în **Detalii**. Coloanele nu se pierd din exportul XLSX FortiGate existent.
- **Layout și scroll**: lățime limitată pentru cardurile KPI, indiferent de dimensiunea tabelului; panoul rămâne în lățimea zonei de conținut. Tabelul FortiGate gestionează separat scroll-ul orizontal, fără suprapuneri între meniu, antete și navigare. Meniul lateral se compactează doar în context Firewall pe desktop.
- **Firewall local**: la alegerea unui VM, se citesc numai regulile sale din ultimul inventar, fără colectare suplimentară. Lista „Reguli configurate” folosește numai **Acțiune / Regulă**, cu review integrat în celula regulii, fără alte coloane tehnice. Revizia individuală și colectivă au chei stabile `fwl:` și verificare server-side; operația colectivă este atomică, auditabilă și limitată la VM selectat.
- **API + export**: `GET /api/v1/security/firewall/local?vm_id=`, `GET /api/v1/security/firewall/local/export?vm_id=`; `PUT /api/v1/security/review` acceptă `firewall_local`, iar `PUT /api/v1/security/review/bulk` acceptă `firewall` și `firewall_local`. Exportul local păstrează și coloane diagnostice și starea reviziei, chiar dacă UI arată doar Acțiune și Regulă. Swagger actualizat.
- **Compatibilitate**: fără migrare SQL (tabela generică `security_reviews` folosește `VARCHAR(64)` pentru tip), fără actualizare agent, Agent 1.7.18 neschimbat. Linkurile Vault și regulile Outline neatinse.
- **Verificări**: `node --check`, `gofmt`, teste Chromium cu date simulate la 1595, 1024, 390 și 350 px — fără overflow al paginii, tabel scrollabil; teste Go independente. Build complet cu `vendor/`, MariaDB, exportul XLSX și salvarea review-urilor reale **nevalidate încă**.

## 0.21.40 (2026-10-19) — Web ACL: Filtre unificate și acțiuni permanente

- **Securitate → Web Access Control și VM → Securitate → Web ACL:** un singur panou **Filtre** înlocuiește barele separate „Export complet Web ACL” și „Revizuiește secțiunea”. Ambele acțiuni **Export Excel** și **Revizuiește secțiunea** sunt vizibile în antet, inclusiv cu filtrele restrânse.
- Săgeata din colțul dreapta-sus extinde/restrânge conținutul panoului. **Căutare generală** (VM, site, adresă/sursă, directivă, fișier), checkbox **Doar cele cu ACL**, și celelalte filtre din pagina globală rămân în interior, colapsate implicit; se păstrează căutarea, Motor, Tip ACL fără reguli/ALLOW ALL, Acțiune, ALLOW ALL, Review și Reset.
- **Revizie colectivă globală:** butonul este mereu vizibil; selectarea VM-ului se face din filtrele extinse. Dacă utilizatorul apasă Revizuiește fără VM selectat, se deschid filtrele și se focalizează selectorul; nu se trimite operație fără VM. Cu VM selectat, revizia acoperă în continuare toate site-urile eligibile de pe acel VM, **nu doar cele afișate după filtre**, respectând confirmarea explicită și auditul existente.
- **Fișa VM:** filtrarea după text și ACL operează numai asupra cardurilor vizibile, fără API suplimentar sau recrearea DOM-ului. Căutarea/checkbox-ul și deschiderea panoului persistă în timpul rerandării aceleiași VM; la schimbarea VM-ului filtrele locale sunt resetate.
- **Compatibilitate:** modificare numai în JS/CSS, metadata de versiune, cache-busting și documentație. Endpoint-ul XLSX este neschimbat, inclusiv exportul tuturor datelor indiferent de filtrele UI. Fără SQL, Agent 1.7.18 nemodificat, nicio schimbare de backend/API.
- **Verificări:** `node --check`; teste Chromium simulate la 1595/1024/390/350 px: antet/butoane, toggle, selecție VM + blocare revizie nespecificată, căutare globală, doar ACL și resetare locală; fără overflow orizontal. Teste Go independente disponibile. Testul complet Go cu `vendor/` și staging MariaDB încă necesare.

## 0.21.39 (2026-10-19) — Web ACL compact, review în antet și export Excel

- În **Securitate → Web Access Control** și **VM → Securitate → Web ACL**, site-urile cu reguli explicite ALLOW/DENY apar primele, deschise implicit; cele fără reguli apar ultimele și colapsate, inclusiv când au review restant. Site-urile cu ALLOW ALL au prioritate în cadrul celor cu reguli.
- Pentru un site fără reguli, eticheta **Fără ACL explicit** apare o singură dată în antet; nu se mai afișează al doilea mesaj redundant în conținut.
- Starea review-ului și butonul **Revizuiește** sunt în `summary`, aliniate în dreapta (responsive). Click pe buton nu extinde/restrânge accidental site-ul. Revizia colectivă pe VM și revizia individuală rămân funcționale.
- **Export Excel** din Web ACL global și din fișa VM: endpoint nou `GET /api/v1/security/web/export`, protejat `inventories.read`; workbook cu worksheet `Site-uri` (include site-uri fără ACL și metadatele reviziei) și worksheet `Reguli ACL` când există reguli (allow/deny, sursă, scope, directivă, fișier sursă). Exportul citește inventarul complet pe server, fără plafonul paginației UI; parametrul `vm_id` restrânge la o VM.
- **Fără migrare SQL și fără modificări ale colectării agentului.** Agentul rămâne 1.7.18. API aditiv; build Go complet cu `vendor/`, teste MariaDB/Excel end-to-end și staging cu date reale rămân de confirmat.
- Verificat: `node --check`, teste Go independente (xlsx, OpenAPI, web, buildinfo, domain, migrations), Chromium cu date simulate la 1595/1024/390 px pentru ordonare, extindere implicită, badge unic, buton review fără toggle și export link. Testul Go al noului workbook nu a putut rula din cauza modulelor externe absente.

## 0.21.38 (2026-10-16) — Dialog revizie colectivă și Grants compacte

- Dialogul „Revizuiește secțiunea” nu mai ascunde confirmarea și butoanele sub scroll: header și footer separate, câmpurile derulabile doar când este necesar, checkbox de dimensiune fixă și text lizibil inclusiv pe mobil.
- Mesaj de confirmare mai scurt, păstrând explicit faptul că sunt suprascrise review-urile existente numai pentru categoria/VM/instanța selectată; formularul cere în continuare observații și confirmare.
- Database Access → Grants: gruparea rămâne per principal; fiecare utilizator apare o singură dată, cu butonul „Revizuiește” în antet, lângă starea reviziei. Eliminat blocul de privilegii duplicat; deschiderea utilizatorului afișează direct grupurile tehnice, apoi la cerere obiectele în loturi de 200.
- Fără schimbări Go/API/SQL/Swagger funcționale, fără migrare, agent 1.7.18 nemodificat. Verificarea în Chrome și staging cu date reale rămâne necesară.

## 0.21.37 (2026-10-16) — Optimizare memorie browser / Security

- Probleme găsite în sursa 0.21.36: `securityDBRenderCache` reținea fără limită inventare DB vizitate; `GET /api/v1/security` returna toate categoriile (inclusiv toate granturile PostgreSQL) chiar și pe Dashboard sau Conturi; zona Grants era construită în DOM înainte să fie deschisă. Cache-ul VM păstra până la 64 de răspunsuri chiar și expirate.
- `GET /api/v1/security?section=overview|accounts|databases|web` permite răspunsuri mai mici: overview doar sumar + până la 15 conturi / 10 DB / 10 Web restante cu detalii DB minimizate; fiecare tab primește categoria lui. Fără parametrul `section`, contractul anterior rămâne complet. `vm_id` nu este schimbat.
- JS eliberează datele Securitate la navigare, golește referințele DB vechi și restrânge cache-ul VM la maximum 16 intrări, cu eliminarea intrărilor expirate la fiecare acces.
- Lista de utilizatori/grupuri Grants apare numai când este selectată categoria Grants, iar subgrupurile/rândurile construite sunt eliberate la `Restrânge`; max. 200 obiecte per extindere rămâne.
- Căutarea în instanțe DB nu mai construiește un șir temporar cu toate atributele celor 20.000+ de granturi.
- Test Chrome mock 20.000 grants / 40 utilizatori la 1595/1024/390: inițial 0 grupuri DOM, 40 la intrarea în Grants, 0 subgrupuri după restrângere. `node --check`, Go OpenAPI/Web/Domain/XLSX/Buildinfo/Migrations trecute; Go integral/vendor și profilare pe date reale neconfirmate.
- Fără migrare SQL, schimbare de agent (rămâne 1.7.18), modificare a reviziilor, exporturilor Excel sau a inventarului brut. Nu pretindem că 4,7 GB observați în Chrome sunt exclusiv cauzați de VM-DOC fără măsurare pe client.

## 0.21.36 (2026-10-16) — DB: revizii pe categorii, grants per user, export Excel

- **Securitate → Database Access:** Revizuiește secțiunea mutat separat în Users, Grants și HBA; butonul global de la Toate instanțele înlocuit cu **Export Excel**. Revizii individuale păstrate pentru fiecare user, grup Grants per principal/host și regulă HBA concretă. Cele trei tipuri de review sunt independente și sunt raportate distinct în Calendar revizii.
- **PostgreSQL grants:** 20.000+ granturi grupate într-o singură intrare per principal/host; subgrupuri la deschidere după bază/schema/scope/privilegiu/stare; randare progresivă de maximum 200 obiecte la un pas. Toate granturile originale sunt păstrate și pot fi exportate.
- **HBA:** prezent numai la PostgreSQL (nu la MySQL/MariaDB), text explicativ pentru `all/all` și `md5`, fără a repeta warning-uri redundante; păstrate Type, Address, fișier sursă și linie. Fără interpretarea `all/all` ca acces universal din orice IP.
- **Excel:** nou `GET /api/v1/security/databases/export` cu filtru opțional `vm_id`. Workbook cu 1–3 sheet-uri (Users obligatoriu, Grants și HBA când există), din toate instanțele/înregistrările server-side, independent de pagina vizibilă. Granturile exportă inclusiv revizia principalului.
- **Backend:** noi chei `database_grants` și `database_hba` validate contra inventarului actual. Revizia bulk acceptă `database_grants`/`database_hba` numai la instanță explicită, cu tranzacție/audit și RBAC existente. Fără migrare SQL, fără agent nou (**1.7.18**).
- **Verificări:** sintaxă JavaScript, 20.000 granturi/40 utilizatori, Chromium la 1595/1024/390 și module Go independente reușite. **Build server integral (`vendor/` absent), teste MariaDB/CSRF/audit și export Excel cu inventar real rămân de executat în staging.**

## 0.21.35 (2026-10-16) — Database Access în 3 zone și revizii colective controlate

- **UI Database Access:** titlu vizibil pentru fiecare instanță (`VM / produs / nume instanță`), versiune și număr granturi; trei zone în aceeași fișă: **1. Users / Roles**, **2. Grants**, **3. Conectare / HBA**. Se afișează câte o zonă, păstrând filtrele/paginarea paginii și reviziile individuale.
- **Roluri / privilegii server:** până la patru valori pe linii separate și `+N · Extinde` pentru restul; nu se elimină rolurile custom NOLOGIN. Rolurile PostgreSQL **predefinite `pg_*` cu NOLOGIN** sunt ascunse din Securitate și calendarul reviziilor, însă rămân în inventarul brut `access_json` și nu sunt șterse din colectare.
- **Granturi:** eliminat pragul vizual de 500; grupare exclusiv de prezentare după principal, host, scope, bază, schemă, privilegiu, stare și GRANT OPTION. Grupurile se pot extinde și afișează **toate** granturile originale, obiectele și sursele, inclusiv 2.000+ granturi; DENY/GRANT OPTION sunt păstrate distinct.
- **Revizie colectivă:** buton `Revizuiește secțiunea` pentru Conturi relevante, Database Access (toate instanțele VM sau o singură instanță), Web ACL, plus selector de VM în paginile centrale de securitate. `PUT /api/v1/security/review/bulk` enumeră țintele pe server, limitat la o VM (și opțional o instanță DB), drept `vms.manage`, CSRF, confirmare și observații obligatorii, maximum 10.000 obiecte. Tranzacție atomică și eveniment de audit; reviziile existente ale obiectelor vizate sunt suprascrise numai după confirmare; acțiunile individuale rămân disponibile.
- **Compatibilitate:** un endpoint Go/API nou documentat în Swagger; fără migrare SQL, fără schimbări de agent (rămâne 1.7.18), fără modificări ale fișelor DOCX/Markdown/PDF/Outline sau ale regulilor Vault.
- **Verificări:** sintaxă JavaScript `node --check`; Chromium/Playwright simulat la 1595/1024/390 px (titlu, trei zone, 2.000 de granturi grupate, NOLOGIN pg_* ascunse, extinderea rolurilor); formular colectiv simulat cu request verificat; Go `openapi`, `web`, `domain`, `xlsx`, `buildinfo`, `migrations` OK. **Build-ul complet `internal/server` și testele unitare ale endpointului nou nu au putut rula fără dependențele `vendor/`; validarea MariaDB reală și staging rămâne obligatorie.**

## 0.21.34 (2026-10-15) — Review compact în 3 coloane, context VM/cont

- **Securitate / Access Review:** în tabele, înlocuiește coloana unică Review cu 3 coloane reale **Revizuit**, **De**, **Next review**; nu repetă „Revizuit” în fiecare celulă. Data ultimei revizii este verde, cu data și ora pe aceeași linie. Next review afișează data+ora pe aceeași linie; butonul de revizuire existent rămâne utilizabil în ultima coloană.
- **Nerevizuite:** numai butonul `Revizuiește` într-o singură celulă care ocupă cele 3 coloane (`colspan=3`); rândurile fără review aplicabil păstrează `—` cu același colspan. Pentru roluri fără `vms.manage`, nu se afișează acțiuni neautorizate.
- **Popup revizie:** afișează numele VM-ului și al contului/resursei selectate (inclusiv DB principal și identificatorul lizibil al regulii FortiGate). Revizorul și momentul reviziei sunt stabilite în continuare de backend; câmpurile existente pentru interval 6/12 luni, justificare și observații rămân intacte.
- **Randare:** coloanele sunt împărțite doar la reconstruirea paginilor de securitate/fișei VM, fără MutationObserver global nou. Panourile fără tabel folosesc grid compact. Login/system fără review nu adaugă acțiuni.
- **Compatibilitate:** modificări numai JS/CSS și fișierele VERSION, OpenAPI version, UI cache-bust, releases.json și documentație. **Fără migrare SQL, endpoint API nou sau schimbare de agent** (rămâne 1.7.18); nu modifică semantica securității ori a datelor de audit.
- **Verificări:** `node --check` OK; Chromium 1595/1024/390 cu date simulate pentru coloanele Review, `colspan=3` și dialog VM/cont; teste Go OpenAPI/Web/Buildinfo/Domain/XLSX/Migrations. **Build Go complet cu `vendor/`, testul MariaDB real și verificarea în staging rămân necesare.**

## 0.21.33 (2026-10-15) — Revizii securitate: popup și coloană coerentă

- **Toate ecranele cu review** (Conturi VM, Database Access per principal, Web ACL, Firewall, Rezumat securitate, Calendar revizii): componenta comună `securityReviewCell` afișează în ordine **Revizuit**, **De către**, **Next review**, **Revizuiește**. Informațiile lipsă sunt marcate `—`, fără a inventa revizii.
- **Dialog de revizie:** în loc de `prompt()`/`confirm()` folosim popup cu interval 6/12 luni, câmp obligatoriu Justificat Da/Nu și Observații (max. 2000 caractere). Datele existente sunt precompletate; anularea nu salvează, iar erorile de API rămân vizibile în dialog. Reviewer/datele sunt stabilite în continuare server-side din identitatea utilizatorului autentificat.
- **Conturi system în fișa VM:** deschiderea panoului afișează imediat conturile, fără bifa suplimentară „Afișează conturile system”. Tabelul nu are Review, iar conturile relevante rămân întotdeauna vizibile și revizuibile.
- **Compatibilitate:** exclusiv JS/CSS și metadate VERSION/Swagger/release/documente; **fără migrare SQL sau schimbări de API**, Agent 1.7.18 nemodificat. Verificare Chromium 1595/1024/390 cu API simulat, inclusiv submit/cancel/validare, fără dialoguri native; `node --check`, teste Go OpenAPI/Web/Buildinfo/Domain/XLSX/Migrations; build complet cu `vendor/` și test MariaDB reală rămân necesare.

## 0.21.32 (2026-10-15) — Securitate VM: Politica parolelor, conturi system și review DB pe principal

- **Securitate → Rezumat VM:** explicația „Conturile system fără login real...” are padding lateral, fără redesignul rezumatului.
- **Securitate VM → Conturi:** Politica parolelor este colapsată implicit; când este extinsă, în stânga sunt trei indicatori compacți vertical (Enforcement, Verificări, Necesită atenție), în dreapta tabelul complet de verificări; valorile efective se pot extinde separat. Layout responsive, pe mobil vertical.
- **Conturi relevante:** rămân mereu vizibile și păstrează review-ul individual. **Conturi system:** panou colapsabil, checkbox cu spațiere corectă, tabel fără coloana Review. Conturile system cu login/privilegii/parolă relevantă continuă să fie tratate drept conturi relevante.
- **Database Access:** revizia se poate face **per utilizator/rol (principal)**, nu doar la nivel de instanță. Cheie persistentă bazată pe instanța DB + nume/host/database, hash SHA-256 pentru unică identificare; răspunsul Security API include `principals[].review`, iar `PUT /api/v1/security/review` acceptă `resource_type=database_principal`. Serverul verifică apartenența instanței la VM și identitatea în snapshotul curent.
- **Raport Revizii securitate:** câte un reper pentru fiecare principal DB; filtrul Baze de date include și `database_principal`. Review-urile vechi pe instanță rămân în baza de date și, unde există, sunt indicate ca istorice; nu sunt moștenite automat de toate conturile.
- Fără migrare SQL nouă: schema `security_reviews` permite deja tipuri distincte. Fără schimbări de agent, rămâne **1.7.18**. Modificări Go/API/Swagger/JS/CSS, compatibile cu citirea inventarelor precedente. Testare end-to-end/MariaDB și build complet cu vendor rămân necesare.

## 0.21.31 (2026-10-15) — Securitate: UI comun și filtre colapsabile

- Meniul global **Securitate** (Dashboard, Conturi VM, Database Access, Web Access Control, Firewall/Caută/Surse/Analiză și Hardening) utilizează layout comun `.security-workspace`: aliniere lățimi și margini, un singur gap de **16 px desktop** și **14 px mobil**, padding lateral **20/16 px**, fără margini cumulative.
- **Conturi VM, Database Access, Web ACL, Firewall/Caută și Analiză Forti:** câmpul Caută rămâne vizibil; filtrele secundare sunt colapsabile cu chevron central, rezumat permanent al selecțiilor și buton Resetează. Maximum **4 filtre pe rând desktop**, 2 tabletă, 1 mobil; deschiderea panoului persistă la reafișarea listei.
- Sunt reutilizate ID-urile inputurilor și handler-ele existente: nu se schimbă filtrarea, review-urile, paginarea, exporturile, drepturile, corelarea FortiGate sau funcționalitățile Hardening. Modificările sunt **strict frontend** (CSS/JS) și metadate versiune.
- Teste: `node --check`; Go OpenAPI/Web/Buildinfo/Domain/XLSX/Migrations; browser Chromium 1595/1024/390 px pe codul de filtre cu date simulate, inclusiv toggle, reset vizibil, câmp de căutare, număr coloane, distanțe și overflow. **Build Go complet cu `vendor/`, MariaDB și testare pe UI cu date reale neconfirmate.**
- **Fără migrare SQL/API nou și fără update agent** (rămâne **1.7.18**).

## 0.21.30 (2026-10-15) — UI Docker / Baze de date / Web: aliniere și spațiere comună

- Cele trei secțiuni din fișa VM folosesc aceeași structură `.vm-resource-layout`, cu un singur `gap` între blocurile principale (16px desktop/tabletă și 14px mobil). Marginile `margin-top` ale `.panel`, `margin-bottom` ale KPI și marginile barelor de filtre nu se mai cumulează.
- Toate cardurile KPI, panourile de filtre, proiectele Compose, panourile de inventar și detaliile colapsabile sunt aliniate pe aceeași lățime. Antetele filtrelor, conținutul filtrelor și panourile de detaliu au padding lateral comun (20px desktop, 16px mobil).
- Păstrate toate funcțiile existente: filtre/revenire/resetare, beneficiari, asociere servicii, listele DB și Web, joburile PostgreSQL condiționale, căile YAML Compose și legăturile pentru documentare. Codul API/SQL nu este schimbat.
- Modificări: `web/static/js/app.js`, `web/static/css/app.css`, `web/static/index.html`, `VERSION`, `web/static/releases.json`, `openapi/openapi.yaml` (versiune), `CONTEXT.md`, `CHANGELOG.md`, `docs/TODO.md` (menținere backlog). Nu există migrare SQL; Agent 1.7.18 nemodificat.
- Verificări: Chromium/Playwright cu markup reprezentativ pentru trei secțiuni la 1595, 1024 și 390 px; aliniere x/lățime, gap fix, padding comun; `node --check`; Go `web/openapi/internal/buildinfo/internal/domain/internal/xlsx/migrations`. Verificarea vizuală reală și build-ul complet cu `vendor/` pe server rămân necesare.

## 0.21.29 (2026-10-15) — Beneficiari instanțe DB, date/ore și interfață Web

- **VM → Baze de date → Instanțe:** rezolvat „Beneficiari: se încarcă…” persistent. În tabelul de instanțe se afișează beneficiarii agregați din bazele logice aparținând instanței, eliminați duplicat după tip + ID beneficiar. Asocierile directe și configurarea lor rămân **la nivel de bază logică**; nu introducem asocieri artificiale la nivel de instanță. Dacă instanța nu are baze logice sau beneficiari, afișăm „Beneficiari: —”. Citirea asincronă este protejată împotriva navigării către alt VM.
- **Data și ora:** formatterul existent rămâne neschimbat, dar CSS le afișează **pe două rânduri numai în tabele** și **pe un singur rând în carduri, panouri de detalii și alte zone**. Așa se corectează inclusiv „Ultima colectare/observație” din Docker, DB și Web.
- **VM → Web:** aceleași principii ca Docker și Baze de date: panou de filtre colapsabil, rezumatul selecțiilor vizibil permanent și buton de resetare. Cele 6 filtre existente sunt păstrate și adăugăm **Motor Web** și **Stare site**, în total 8 filtre (4/linie desktop, 2 tabletă, 1 mobil). Filtrarea combinată afectează tabelul de site-uri/frontends, nu ascunde servere din inventarul brut. Selecțiile persistă la revenirea în aceeași VM.
- **Servere web detectate** devine panou extensibil, păstrând configurațiile și controalele de documentare. Lista site-urilor rămâne afișată. Nu modificăm colectorii agentului, inventarul sau asocierile la servicii/beneficiari.
- **Impact tehnic:** numai `web/static/js/app.js`, `web/static/css/app.css`, `web/static/css/ui-refresh.css`, cache-busting UI, VERSION, metadatele OpenAPI, istoricul release-urilor și documentele. **Fără migrare SQL sau endpointuri API noi. Agent 1.7.18 neschimbat.**
- **Verificări:** teste Playwright/Chromium cu date simulate la 1595/1024/390 px pentru cele 8 filtre, resetare, persistență, afișare beneficiari agregată fără duplicate și dată/oră în/fără tabel; sintaxă JS; teste Go `openapi`, `web`, `internal/buildinfo`, `internal/domain`, `internal/xlsx`. Compilarea completă cu `vendor/` și integrarea în MariaDB/PROD rămân de verificat în staging; `GOPROXY=off go test ./...` local este blocat de modulele absente.

## 0.21.28 (2026-10-15) — Baze de date: UI precum Docker, filtre și joburi PostgreSQL condiționale

- **VM → Baze de date:** panou de filtre colapsabil pe modelul Docker; selecțiile active sunt afișate permanent în bara de sus, cu buton Resetează și chevron. Cele 6 filtre existente sunt păstrate și se adaugă **Motor DB** și **Stare instanță**: 8 filtre în două rânduri a câte 4 pe desktop (2/linie tabletă, 1/linie mobil). Selecțiile și starea panoului se păstrează la reafișarea tabului pe aceeași VM.
- Filtrarea afectează **instanțele și bazele logice** în același timp și raportează separat numărul de rânduri vizibile. Baza logică preia motorul și starea instanței părinte pentru filtre; nu sunt schimbate asocierile și datele de inventar.
- **Engine-uri detectate** este un panou extensibil la finalul paginii, ca „Engine și obiecte Docker”; tabelul de instanțe și bazele logice rămân vizibile normal.
- **Joburi programate PostgreSQL** și cardul său KPI dispar dacă inventarul nu conține niciun job. Când există joburi, panoul, cardul și coloana „Joburi DB” din instanțe sunt afișate. Dacă nu există joburi, ascundem și coloana inactivă.
- Schimbări **strict frontend**: `web/static/js/app.js`, `web/static/css/app.css`, `web/static/index.html`, alături de versiune, note și istoricul release-urilor. **Fără migrare SQL, schimbare API/Swagger sau Agent nou** (rămâne 1.7.18).
- Verificări: `node --check`, Go OpenAPI/Web/Buildinfo/Domain/XLSX, browser Chromium cu date simulate 1595/1024/390 px, filtre, resetare, păstrare stare și cazuri cu/fără joburi. **Build Go complet cu vendor și test UI pe date reale rămân necesare**.

## 0.21.27 (2026-10-14) — Docker Compose: YAML, beneficiari proiect, filtre și liste

- **Proiecte Compose:** afișăm directorul de lucru `compose_working_dir` și fiecare cale din `compose_config_files`, fiecare cu buton de copiere; dacă etichetele lipsesc, afișăm „Nedetectat”. Nu citim conținutul fișierelor YAML și nu exportăm date sensibile.
- **Beneficiari Compose:** buton „Configurează beneficiari…” deschide un dialog pentru selecția multiplă de departamente și persoane. **Migrarea 078** introduce `docker_compose_beneficiaries`, cu identificare stabilă după VM + numele proiectului, independent de recrearea containerelor. Nu suprascrie beneficiarii atribuiți individual containerelor.
- **Propagare:** beneficiarii proiectului apar ca asocieri *calculate* la containerele prezente și la VM/servicii/componente corelate prin relațiile deja existente. Informațiile sunt vizibile în listele și rapoartele de beneficiari. Editarea e tranzacțională, auditată și disponibilă prin API/Swagger.
- **Filtre containere:** panou colapsabil, selecții rezumate permanent în bară, Resetare, stare Docker (running/exited etc.) și 7 controale organizate pe 2 rânduri de maximum 4 pe desktop; responsive pe mobil.
- **Engine și obiecte Docker:** Images, Networks, Volumes afișate pe rânduri distincte, cu liniuță, nu cu virgule.
- **Teste:** JavaScript sintactic, validare strictă OpenAPI (211 rute), Go pentru pachetele fără dependențe externe și verificare Chromium cu date/API simulate la 1595/1024/390, inclusiv salvare dialog. **Compilare integrală cu `vendor/` și migrarea 078 pe MariaDB reală rămân de confirmat în staging**. Agent 1.7.18 neschimbat.

## 0.21.26 (2026-10-14) — Infrastructură mai rapidă și nume beneficiari evidențiate

- **Infrastructură:** timpul până la afișarea datelor principale nu mai este blocat de `/api/v1/agents`, sistemele/conexiunile externe și inventarul software. Lista agenților se încarcă ulterior în selectul existent; până atunci este dezactivat, iar agentul asociat rămâne vizibil. Conexiunile externe se completează fără reîncărcarea întregii fișe. Nu se execută cererea software în Infrastructură; aceasta se citește în tabul său.
- **Performanță UI:** panourile neactive Docker, Baze, Web, Securitate, Inventar, Backup etc. nu mai sunt construite inutil la fiecare deschidere. Completarea rămâne calculată asincron, cu valoare necunoscută până la obținerea dovezilor necesare.
- **Beneficiari Operațional:** numele departamentului/persoanei este în bold și subliniat în badge-ul de beneficiar; sursa AD/manual este afișată discret. Restul listelor de beneficiari sunt neschimbate.
- **Compatibilitate:** fără modificări SQL/API și fără actualizare Agent; rămâne 1.7.18. Teste Chromium la 1595/1024/390 px cu întârzieri simulate de 650 ms pentru cereri secundare; endpointul VM real și MariaDB trebuie verificate pe server. Build Go complet offline rămâne de verificat cu `vendor/`.

## 0.21.25 (2026-10-14) — Hotfix Infrastructură, RPO/RTO implicit și Operațional

- **Infrastructură:** remediere `Cannot read properties of undefined (reading 'length')` introdusă în 0.21.24. Panoul „Completarea fișei” este construit numai în Rezumat, nu când Infrastructură așteaptă încă dovezile pentru completare; actualizarea asincronă a cardului rămâne activă.
- **RPO/RTO:** valori implicite 1440 / 240 minute numai pentru câmpuri lipsă (`NULL`) sau VM-uri fără înregistrare operațională. Migrarea SQL `077` modifică `DEFAULT`-urile, actualizează numai câmpurile `NULL` și creează numai înregistrările operaționale inexistente; **păstrează orice valoare stabilită, inclusiv 0**. API-ul, formularul și salvarea respectă valorile implicite. Nu schimbă valorile din sumarul Veeam.
- **Operațional:** beneficiarii sunt evidențiați cu accent vizual și titlu subliniat; eticheta duplicată „Observații” este ascunsă vizual, păstrând o etichetă accesibilă pentru textarea.
- **Teste:** Chromium 1595/1024/390 pe codul JS real, cu API simulat; `node --check`; Go OpenAPI/Web/Buildinfo/Domain/Migrations. Verificările complete Go cu `vendor` și migrarea pe MariaDB reală rămân de confirmat pe server.
- Agent 1.7.18 neschimbat. Vault rămâne numai intern aplicației.

## 0.21.24 (2026-10-14) — Operațional simplificat, sortare VM globală și Infrastructură mai receptivă

- Configurare → Operațional: doar câmpul Observații în secțiunea finală; URL documentație / Referință tichet ascunse. La salvare se păstrează valorile istorice în baza de date, fără ștergeri implicite. În Rezumat, linkul Documentație utilizează exclusiv Outline dacă este asociat.
- Inventar VM: toate coloanele informative (VM, vCenter, Power, CPU/RAM, OS, IP, Agent, Servicii, Publicare, Outline, Completare, Ultimul JSON) suportă sortare **pe toate rezultatele filtrate**, efectuată în SQL înainte de paginare. Direcția se inversează la click; pagina revine la 1. Exportul XLSX păstrează aceeași ordine; whitelist fără interpolare SQL din utilizator. `completion_asc` este compatibil cu versiunile precedente.
- Infrastructură VM: afișarea navigării și a mesajului de încărcare are loc imediat; cererile pentru Docker/DB/Web și beneficiari nu mai blochează primul render, ci actualizează ulterior procentul real al completării. Nu se afișează procente parțiale ca definitive.
- Verificări: JS sintactic, OpenAPI/Web/Buildinfo Go, teste izolate pentru whitelist sortare, browser 1595/1024/390 cu date simulate. Testarea SQL MariaDB și compilarea completă cu `vendor/` sunt de efectuat pe server.
- Fără migrare SQL, fără update de Agent (1.7.18), fără modificări Vault/Outline export.

## 0.21.23 (2026-10-14) — Aliniere panouri și formulare Configurare VM

- Eliminat paddingul exterior al `.vm-detail-workspace-configuration` care restrângea panourile față de `.vm-detail-navigation`. Lățimea este acum aceeași pentru toate taburile VM; paddingul rămâne în interiorul panourilor.
- **Cluster / grup HA:** formular cu spațiu la stânga/dreapta și sub acțiuni; câmpurile nu mai ating marginile, opțiunile au grupare vizuală, iar „Salvează grupul HA” are separator și spațiu față de bordura de jos.
- **Configurare → Servicii / Încadrare:** butoanele „Adaugă asociere” și „Salvează asocierile” sunt distanțate de ultimul câmp „Observații”, cu padding consistent. Aceeași regulă pentru acțiunile formularului Operațional.
- CSS responsive la 1595 / 1024 / 390 px, fără schimbări în marcajele UI și în handler-ele JS. Fără migrare SQL, API sau schimbări de agent; build complet offline cu `vendor/` rămâne de verificat pe serverul utilizatorului.

## 0.21.22 (2026-10-14) — Carduri KPI, responsabilități și navigare după repere

- Cele 7 carduri KPI de pe Inventar VM și din fișa VM se întind uniform pe lățimea disponibilă la viewport desktop de minim 1551px, cu aceeași înălțime și aspect. Breakpointurile pentru ecrane mici rămân.
- Rezumatul afișează toate numele persoanelor distincte asociate VM-ului, despărțite prin virgulă, indiferent de rol; nu mai exclude persoanele cu rol `technical_admin`. Eticheta rolului nu este afișată.
- Reperele „De completat” sunt linkuri către paginile/taburile corecte. Pentru câmpurile identificabile, formularul/elementul este adus în vedere și evidențiat după încărcarea asincronă; pentru datele colectate automat, se deschide secțiunea corespunzătoare. Reîmprospătarea progresului păstrează clickurile funcționale.
- Schimbare UI exclusivă; fără migrare SQL, API sau agent. Testele browser sunt simulate; compilarea completă pe mașina de producție trebuie verificată.

## 0.21.21 (2026-10-14) — Rezumat VM și reconciliere MariaDB / MySQL

- Contract KPI comun ajustat de la 152 la **174 px**, pentru 7 carduri pe un rând la lățimea disponibilă dintr-un viewport de 1595 px; la rezoluții mai înguste folosește breakpoints responsive.
- **VM → Rezumat / Identificare și încadrare**: 8 câmpuri în 4 coloane × 2 rânduri, cu **Beneficiari** agregați unic și despărțiți prin virgulă. **Responsabilități** devine un rând separat, cu nume despărțite prin virgulă și fără rolul `technical_admin` (rolul rămâne în date/editor). Eliminat câmpul afișat Referință tichet; linkul Documentație scos din grilă.
- **Publicare Outline / Vault**: panouri aliniate; rând comun pentru linkurile Documentație și Vault. Pentru Documentație se preferă URL-ul Outline deja publicat obținut prin endpointul existent `/api/v1/vms/{id}/outline`, în rest URL-ul operațional; nu se trimite niciun URL Vault în exporturi/Outline.
- **Inventar baze de date**: suprimare condiționată a motorului MySQL-fantomă creat de aliasul compatibil `mysqld` al MariaDB, numai cu semnal de versiune MariaDB și fără instanță MySQL reală. Aplicată la sincronizările viitoare și la vizualizarea snapshoturilor deja stocate; fără ștergeri manuale de instanțe/catalog și fără ascunderea MySQL real. Teste de regresie Go.
- Fără migrare SQL și fără update de agent (rămâne **1.7.18**). Verificările pe infrastructura reală rămân necesare.

## 0.21.19 (2026-10-14) — Hotfix Swagger/OpenAPI

- Rezolvată eroarea `duplicated mapping key` în `openapi/openapi.yaml`: rutele `/api/v1/people` și `/api/v1/people/{id}` erau documentate de două ori. Păstrăm variantele complete, inclusiv schemele și descrierile pentru beneficiari.
- Adăugat test automat `go test ./openapi` pentru unicitarea rutelor paths (fără chei duplicate la nivelul rutelor), cu verificare `info.version` față de VERSION.
- Fără migrare SQL, fără schimbări în logica API runtime sau în Agent 1.7.18. YAML este embedded, deci serverul trebuie recompilat pentru Swagger.
- Validare: parser YAML strict + teste OpenAPI locale; **build complet cu vendor, MariaDB și Swagger pe serverul real sunt încă neconfirmate**.

## 0.21.20 — 2026-10-14 — UI KPI coerent și filtre

- Corectată regresia din 0.21.18 care întindea cele 7 carduri ale listei VM în 4 coloane late, anulând compactarea 0.21.17.
- `ui-kpi-seven` reutilizabil pentru seturi de șapte KPI, aplicat atât listei VM, cât și rezumatului fișei VM: aceeași lățime, înălțime, padding și tipografie, cu adaptare responsive.
- Butonul de extindere/restrângere a filtrelor este centrat în bara de filtre, independent de lungimea rezumatului și de butonul Resetează.
- Nicio schimbare în logică, API, schema SQL ori agent (1.7.18).


## 0.21.18 (2026-10-14) — UI VM-uri: servicii, filtre și rezumat agregat

- Coloana **Servicii** din inventarul VM afișează implicit maximum 4 servicii; `+N · Extinde` / `Restrânge` permite consultarea listei complete în aceeași celulă, fără pierderea numelor.
- Bara de filtre secundare afișează acum **„Filtre: Niciun filtru activ”** sau selecțiile actuale și **Resetează**; în partea dreaptă rămâne numai săgeata care expandează cele 8 filtre secundare. Căutare VM și Power rămân pe primul rând, iar filtrele secundare apar în 4 coloane pe desktop.
- Trei carduri noi în inventar: **Pornite** (imediat după Rezultate), **Publicare Outline** (VM-uri cu o sincronizare/publicare deja înregistrată) și **Completare generală** (media aritmetică a procentelor individuale de completare). Sunt incluse și cardurile precedente; toate sunt clickabile.
- Clic pe Pornite / Publicare Outline / Prezente / Lipsă / Cu agent aplică sau elimină filtrul relevant. Clic pe Completare generală activează/dezactivează sortarea VM-urilor crescător după completare. Clic pe Rezultate revine la toate VM-urile.
- API `GET /api/v1/vms`: trei agregate noi, `powered_on_count`, `outline_published_count`, `completion_average_percent`, calculate în SQL peste **întregul set filtrat**, înainte de paginare. Noi parametri validați `published=yes|no` și `sort=completion_asc`; actualizare Swagger. Media folosește exact aceeași formulă ca procentul afișat în fiecare rând, nu doar datele paginii curente.
- Fără migrare SQL nouă, fără modificare a agentului 1.7.18 și fără schimbări asupra regulilor Outline/permisiunilor. Test UI cu API simulat în Chromium la 1440/1024/390 px, sintaxă JS și OpenAPI; constructorul de filtre Go testat izolat. **Compilarea completă a serverului cu `vendor/` și testul MariaDB cu date reale rămân de efectuat pe server.**

## 0.21.17 (2026-10-14) — Ajustări UI listă VM și date/ora

- Pagina VM-uri: **Căutare VM** și **Power** vizibile pe primul rând; celelalte 8 filtre (Agent, vCenter, Baseline, Serviciu, Sursă vCenter, Outline, OS suportat, Pe pagină) într-o secțiune pliabilă, 4 coloane la rezoluții desktop. Deschiderea panoului persistă pe durata filtrării/paginării.
- Cardurile de sumar VM au format compact, precum rezumatul VM: lățime limitată, padding și fonturi mai mici, responsive.
- Data și ora sunt afișate pe două rânduri în interfață, în fusul orar configurat, prin formatterul `dt()`; valori absente sau invalide rămân `—`.
- Tabelul VM: coloana cu eligibilitatea publicării se numește **Publicare**, iar **Ultima publicare Outline** devine **Outline**, pentru a evita două coloane cu același nume.
- Eliminat spațiul dintre meniurile sticky și topbar la scroll: înălțimea reală a topbar-ului este sincronizată prin `ResizeObserver` și CSS custom property.
- Doar HTML/JS/CSS, VERSION, releases și documentație. **Fără modificări de Go, API, migrare SQL, `go.mod`/`go.sum` sau agent.** Teste browser cu API simulat la 1440/1024/390 px; test complet backend în staging necesar.

## 0.21.16 (2026-10-14) — Revizie UI și backlog prioritizat

- Uniformizare transversală în toate paginile fără schimbări de business logic: stil separat `ui-refresh.css`, antete, panouri, carduri, filtre, formulare, tabele, navigare, paginare, modaluri, focus și ecrane mici.
- Navigare laterală grupată; meniul are scroll pe desktop și toggle pe mobil. Păstrate rutele și verificările RBAC.
- `docs/UI-REVIEW-0.21.16.md` conține inventarul paginilor și testele necesare cu date reale.
- `docs/TODO.md`: integrare Wazuh API/SCA și consolă SSH prin Vault **amânate** până la maturizarea aplicației; Hardening-ul intern rămâne baseline.
- Fără migrare SQL, schimbări API/Swagger, agent, `go.mod` sau `go.sum`. Teste Chromium cu UI mock; build Go complet cu `vendor/` și e2e pe MariaDB rămân pentru staging.

## 0.21.15 (2026-10-14) — Catalog Hardening extensibil

- Migrare SQL 076: profiluri OS/Componentă, stări Draft/Publicat/Arhivat, revizie, operatori de evaluare, benchmarkuri metadata și snapshoturi la publicare.
- API/Swagger + UI pentru creare profil, clonare, editare Draft, publicare, arhivare, reguli noi și asociere la profil, import/export JSON. Protecție față de modificarea criteriilor aplicate unui profil publicat.
- 7 șabloane tehnice nepublicate: Apache, Nginx, MariaDB, MySQL, PostgreSQL, MongoDB, Docker; nu sunt evaluate automat până la colectarea dovezilor.
- Profilurile OS și asocierile existente nu se șterg. CIS recommendation IDs nu sunt inventate, nu se distribuie benchmarkuri CIS.
- Teste unitare și verificări UI/JS/OpenAPI; **serverul complet nu este compilat aici cu vendor**, nici migrat pe MariaDB reală. Se recomandă staging.

## 0.21.13 (2026-10-13) — Curățare structură surse și documentație

- Mutate 108 UPGRADE, 108 RELEASE-NOTES și 3 VERIFICATION din rădăcină în `docs/history/`, fără ștergerea conținutului istoric; index navigabil.
- `scripts/cleanup-source-tree.sh`: dry-run implicit, `--apply` pentru organizarea copiilor vechi și arhivarea proiectelor imbricate în afara directorului Go, `--check` pentru verificarea structurii.
- `Makefile` adaugă verificarea structurii înainte de test/build, ca să nu mai compileze surse vechi 0.20.17/0.20.98 extrase accidental în directorul activ.
- Actualizate `README.md`, versiunea și istoricul din interfață. **Fără schimbări de business logic, SQL, Swagger sau agent.**
- Teste: integritate/echivalență patch/update/surse, script cleanup într-un director temporar, sintaxă JS/JSON, teste Go disponibile; **build complet cu vendor/ și testele MariaDB rămân de verificat pe server**.

## 0.21.12 (2026-10-13) — Hotfix compilare Hardening

- Corectat `internal/server/hardening.go` la `updateHardeningProfile`: `_, err :=` → `_, err =`; `err` era deja declarat, iar 0.21.11 eșua cu `no new variables on left side of :=`.
- Fără migrare SQL, schimbări de logică, API/Swagger sau agent. Actualizate `VERSION`, `releases.json`, cache-busting UI și documentația.
- Verificări structurale și comparație patch/update/surse; **compilarea Go completă cu vendor și integrarea reală rămân de executat pe server**.

## 0.21.11 (2026-10-13) — Hotfix compilare Hardening

- Remediere erori de compilare în `internal/server/hardening.go` pentru variabilele `res` și `result` neutilizate la liniile 130, 156 și 176 din 0.21.10.
- Rezultatele SQL neutilizate sunt atribuite lui `_`, iar erorile `err` continuă să fie verificate.
- Fără migrare SQL, schimbări API, modificări de agent sau schimbare a regulilor de Hardening.
- Test complet al serverului încă necesar offline cu directorul `vendor/` de pe serverul utilizatorului.

## 0.21.9 (2026-10-13)

- Agent 1.7.16: consumă `origin`, `container_id`, `container_name`, `container_image`, `compose_project`, `replica_set`, `replica_role`, `replica_primary` pentru fiecare instanță DB.
- Instanțe DB Docker identificate separat după motor + container ID; portul intern identic nu mai produce coliziuni.
- Migrarea `074_database_instance_origins.up.sql` adaugă metadatele fără să șteargă cataloagele sau asocierile existente.
- Adoptarea identității vechi este permisă doar când o singură instanță din colectare are aceeași cheie istorică.
- Fișa VM > Baze de date afișează originea și rolul Replica Set; exportul Excel include aceste câmpuri; Swagger documentează inventarul.
- Compatibilitate cu agent 1.7.15 și ramurile legacy: câmpurile noi rămân goale, fără dispariția informațiilor vechi.
- Nu include modificări de agent, de `go.mod` sau de `go.sum`; `vendor/` existent se reutilizează.

## 0.21.8 (2026-10-13)

- **Motoare DB ignorate** configurabile din Nomenclatoare → Inventar tehnic; IBM Db2 exclus implicit.
- Filtrare reversibilă pentru inventarul vizibil al VM, serviciilor, raportelor, securității și fișelor DOCX/MD/PDF/Outline; raw agent JSON și tabelele normalizate rămân neatinse.
- Raport Componente software și completitudine VM folosesc aceeași vizibilitate; motorul ignorat nu penalizează documentarea.
- Migrarea `073_database_engine_visibility.up.sql` creează tabela regulilor și interogări filtrate pentru fiecare ecran.
- API/Swagger GET/PUT pentru reguli, cu permisiuni `nomenclatures.read`/`nomenclatures.manage` și audit.
- Fără modificare de agent, `go.mod`, `go.sum` sau `vendor/`.

## 0.21.7 (2026-10-12)

- **Nomenclatoare:** contorul Beneficiari afișează numărul de departamente (AD OU + manual), inclusiv inactive, ca celelalte elemente ale meniului.
- **Docker Compose:** spațiu deasupra controalelor; elimină al doilea rând cu Servicii și Beneficiari (aceștia rămân accesibili din tabelul containerelor).
- Cele patru listbox-uri afișează serviciul, mediul, statusul și tipul soluției deja salvate, dacă sunt aceleași pe toate containerele proiectului; pentru configurații mixte arată „Valori diferite”, fără a suprascrie datele până la confirmarea explicită prin „Asociază”.
- Fără migrare SQL, schimbări API, vendor sau agent.

## 0.21.6 (2026-10-12)

- **Nomenclatoare:** Beneficiari este afișat sub Persoane în grupul Responsabilități, nu în partea de sus.
- **Docker Compose:** corecție CSS pentru selectoare: înălțime fixă 42 px; layout compact și aliniat pe un rând, servicii și beneficiari vizibili sub rând.
- **Nu necesită documentare:** checkbox și mesaj compact, cu padding și aliniere corecte.
- **Istoric versiuni:** intrări individuale 0.21.1, 0.21.2, 0.21.3, 0.21.4, completând intervalul 0.21.0–0.21.6.
- Cache-busting pentru CSS, JS și releases.json la versiunea 0.21.6; fără migrare SQL, schimbări API sau agent.

## 0.21.5 (2026-10-12)

- Secțiunea Proiecte Docker Compose este colapsabilă și afișează numărul de proiecte în antet.
- Fiecare proiect folosește un singur rând cu patru selectoare mai late și buton de asociere; la lățimi reduse scroll-ul rămâne numai în secțiune.
- Serviciile rămân linkuri clicabile în coloana Documentare / Servicii, inclusiv în tabelele Docker, baze și Web.
- Beneficiarii proiectelor Compose sunt afișați dedesubt, agregați fără duplicate din containerele proiectului, folosind cererea bulk deja existentă.
- Navigarea în nomenclatoare și zona de raportare au spațieri/denumiri mai compacte; nu există migrare SQL, schimbare de agent sau de vendor.

## 0.21.4 (2026-10-12)

- Proiectele Docker Compose au câte un rând, cu selectoare responsive fără suprapunere.
- Export Excel mutat în antetul tabelelor Docker/Baze/Web.
- Criteriul Beneficiar VM participă o singură dată la completarea documentării, în fișa VM și în lista VM-urilor.
- Actualizare versiune asset-uri CSS/JS; fără migrare SQL, agent sau vendor nou.

## 0.21.3 (2026-10-12)

- Beneficiarii VM apar sub Persoane în Responsabilități, fără card de sumar separat.
- Raport Beneficiari: Toate departamentele; fără Componente suport.
- Docker/Baze/Web: documentare, servicii și beneficiari rezumați pe rând, cu dialog comun pentru configurare.
- Export XLSX pe fiecare inventar; citire beneficiari în lot și optimizări de încărcare.
- Corectare cache busting asset-uri 0.21.3, actualizare OpenAPI. Fără migrare SQL ori update agent.

## 0.21.2 (2026-10-12)

- VM beneficiaries moved into Operational / Responsibilities, below people.
- Beneficiary report layout refreshed, with clearer filters and spacing.
- MariaDB and other database engines linked to beneficiary databases appear under Software components with detected version and provenance.
- Excel report adds Software components worksheet. No database migration or agent update.

## 0.21.0 (2026-10-12)

- Beneficiari AD/manual pentru departamente OU și persoane; asocieri, calcul servicii/componente, raport Excel și API Swagger.
- Migrare 071. Nu necesită schimbări de agent sau dependențe Go.

# Changelog

## 0.20.99

- aliniază **Agenți** cu designul workspace-ului **Monitorizare** (taburi mari, titlu + subtitlu, spacing și responsive comune);
- pagina afișează imediat navigarea și filtrele, apoi încarcă asincron tabelul activ;
- optimizează deschiderea implicită a listei: `ListPage()` folosește `COUNT + LIMIT/OFFSET` și citește doar pagina cerută în loc să materializeze toți agenții înainte de paginare;
- păstrează filtrarea complexă server-side pentru Status agent / Status operațional VM / Power / Tip agent / Canal;
- debounce căutare 350 ms;
- fără migrare DB și fără update de agent.

## 0.20.98

- restaurează declarația locală `tools` în `agentsPage()` înainte de apelul `panel()`;
- repară crash-ul UI `tools is not defined` în lista Agenți;
- schimbare exclusiv frontend, fără migrare DB și fără update de agent.

## 0.20.97

- adaugă pe Agent `vm_operational_status` și `vm_operational_status_code`, citite din `vm_operational_nomenclatures`/`nomenclature_items` cu fallback pe metadata legacy;
- filtrul **Stare VM** folosește valorile reale din nomenclator, inclusiv `Retras`;
- `item_code=retired` este tratat ca VM retrasă pentru statusul agentului și pentru excluderea incidentelor offline;
- rearanjează filtrele Agenți pe două rânduri și compactează tabelul;
- înlocuiește butoanele text din Acțiuni cu iconițe fixe și adaugă legenda acțiunilor;
- exportul Excel include Status operațional VM și codul lui;
- fără migrare DB și fără update de agent.

## 0.20.96

- adaugă VM/power/lifecycle în modelul de listare a agenților;
- filtre noi `power` și `vm_state` pentru `/api/v1/agents` și export;
- introduce `operational_status`: `powered_off` și `retired` sunt stări benigne, distincte de `offline`;
- Dashboard și raportul de lipsuri operaționale nu mai semnalizează agent offline pentru VM-uri `POWERED_OFF`;
- fără migrare DB.

## 0.20.95

- extinde `securityLinuxLike()` pentru familiile reale Linux (`debian`, `redhat`, `suse`, `sles`, Ubuntu/RHEL/CentOS/Rocky/Alma/Oracle/openSUSE);
- repară cazul SLES9 legacy în care `password_policy.login_defs` era prezent, dar UI afișa `Unknown` fără details deoarece derivarea legacy nu era executată;
- adaugă test de regresie pentru familiile Linux și păstrează Windows/Darwin în afara clasificării;
- fără migrare DB.

## 0.20.94

- adaugă evaluare server-side pentru `accounts.password_policy` provenit din agenți Linux legacy care nu trimit încă `checks[]` / `enforcement_status`;
- derivează complexitate PAM (`pam_pwcheck`, `pam_cracklib`, `pam_pwquality`), minimum length, history și PASS_MIN/MAX/WARN_DAYS;
- verifică aging-ul efectiv per cont folosind valorile deja colectate din `/etc/shadow`;
- nu modifică fluxul agenților moderni 1.7.15; recomandat pentru SLES9 legacy 1.0.1;
- fără migrare DB.

## 0.20.93

- expune `agent_type`, `architecture`, `os_family` și `agent_runtime_name` în API-ul Agenți;
- derivează tipul agentului din snapshot-ul curent fără migrare DB;
- adaugă filtrul server-side `agent_type` și îl propagă în exportul Excel;
- UI adaugă coloana și filtrul **Tip agent**;
- normalizează arhitecturile `x86_64/x64 → amd64` și `i386/i686/x86 → 386`;
- recunoaște explicit ramurile Windows XP, Windows legacy și SLES 9 legacy;
- fără migrare DB; vm-doc-agent 1.7.15 rămâne recomandat.

## 0.20.92

- restaurează `securityDBPrivileges()` în `web/static/js/app.js`, funcție eliminată accidental în 0.20.91;
- repară crash-ul UI `securityDBPrivileges is not defined` în Security / Database Access;
- schimbare exclusiv frontend, fără migrare DB și fără update de agent.

## 0.20.91

- integrează în Security / Access Review `accounts.password_policy` din `vm-doc-agent 1.7.15`;
- expune per VM `enforcement_status`, valorile efective, sursele și `checks[]` pentru politica de parole;
- adaugă sumar central Enforced / Partial / Not enforced / Unknown și card detaliat în fișa VM;
- normalizează conturile system Linux și pentru inventare unde flag-ul `system_account` nu a fost suficient: UID < 1000 este system, fără a aplica regula UID pe Windows;
- corectează interpretarea shell-urilor tehnice `/bin/sync`, `nologin`, `false`, `shutdown`, `halt` ca non-login;
- UI ascunde implicit conturile system cu valoare operațională redusă și oferă checkbox pentru inventarul complet;
- fără migrare DB; recomandat `vm-doc-agent 1.7.15` (schema 2.12).

## 0.20.90

- corectează deduplicarea snapshot-urilor push + pull introdusă în 0.20.89: `inventory_snapshots.collected_at` este `DATETIME(6)` și poate pierde nanosecundele din timestamp-ul agentului;
- pentru comparația aceleiași colectări, serverul folosește acum în primul rând `collected_at` din JSON-ul brut al snapshot-ului precedent, unde precizia originală este păstrată;
- fallback-ul pe coloana DB compară la precizie de microsecundă, conform `DATETIME(6)`;
- aceeași colectare manuală nu mai trebuie să apară de două ori în Istoric; colectările ulterioare reale rămân distincte;
- fără migrare DB și fără agent nou; vm-doc-agent 1.7.14 rămâne recomandat.

## 0.20.89

- elimină snapshot-urile duplicate din Istoric inventare atunci când aceeași colectare ajunge simultan prin push-ul agentului și pull-ul jobului serverului;
- salvarea inventarului este serializată per agent și reutilizează snapshot-ul anterior numai când payload-ul SHA-256 și `collected_at` sunt identice;
- colectările reale ulterioare, chiar dacă nu schimbă configurația, rămân snapshot-uri distincte deoarece au alt `collected_at`;
- fără migrare DB și fără agent nou; vm-doc-agent 1.7.14 rămâne compatibil și recomandat.

## 0.20.88

- corectează eroarea JavaScript `managed.includes is not a function` din panoul Firewall;
- `managed` este un `Set`, deci UI folosește acum `managed.has()`;
- fără migrare DB și fără update de agent.


- extinde politica **Outline numai pentru PROD** și la serviciile interne, atât la publicarea individuală cât și la bulk;
- un serviciu este eligibil pentru Outline numai dacă are cel puțin o asociere VM în mediul PROD, determinată din mediul canonic al VM-ului;
- pagina Outline a serviciului este generată dintr-o copie filtrată: Încadrare pe medii, VM-uri, componente software principale, backup, monitorizare, DB, Docker, Web și conexiunile legate de VM includ numai PROD;
- agregările de domeniu/categorie, tip soluție și layer/rol sunt recalculate numai din asocierile PROD;
- dependențele cu mediu explicit non-PROD și VM-urile dependente non-PROD sunt eliminate din conținutul Outline;
- în Serviciu → Documentație, butonul de publicare nu este afișat dacă serviciul nu are PROD; endpoint-ul individual aplică aceeași regulă server-side;
- preview-ul bulk afișează numai serviciile cu PROD și raportează separat câte servicii non-PROD au fost omise;
- fișele DOCX/Markdown normale, cardurile/lista serviciilor și exporturile existente rămân neschimbate;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.86

- **Componente software → Publică în Outline** publică exclusiv rândurile asociate VM-urilor din mediul PROD;
- mediul pentru această decizie este citit din `vm_operational_nomenclatures` / `nomenclature_items`, cu fallback pe `vm_operational_metadata.environment`, fără a schimba raportul afișat sau exportul;
- pagina Outline a fiecărei componente este redenumită/creată cu prefixul `comp-`;
- conținutul paginii include numai VM-uri PROD și linkurile către serviciile asociate acelor VM-uri;
- componentele fără nicio instalare PROD nu sunt publicate;
- clasificarea PROD este strictă (`PROD`, `Production`, `Productie`, `Producție`), astfel încât `PREPROD` nu este eligibil;
- cardurile, filtrele și exportul Excel rămân neschimbate;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.85

- repară regresia de filtrare a regulilor firewall din fișa VM și Markdown/Outline: managerul UFW/firewalld/SuSEfirewall2 este dedus și din fișierele de configurare și lanțurile ruleset-ului, nu doar din lista `backends`;
- dacă agentul raportează doar `nftables`/`iptables`, dar ruleset-ul conține lanțuri UFW, regulile tehnice `ufw-before-*`, `ufw-after-*`, logging/jump nu mai sunt enumerate în documentație;
- pentru UFW inferat se păstrează numai regulile explicite din lanțurile `ufw-user-*`; nftables/iptables configurat direct, fără manager high-level, rămâne documentat;
- aceeași filtrare este aplicată în UI-ul inventarului Firewall și în DOCX/Markdown/Outline;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.84

- corectează detectarea mediului pentru politica **Outline numai pentru PROD**: mediul este citit prioritar din nomenclatorul VM (`vm_operational_nomenclatures` / `nomenclature_items`), exact ca în Date operaționale;
- normalizează valorile de producție la fel ca restul aplicației: `PROD`, `Producție`, `Productie` și `Production` sunt tratate ca PROD;
- elimină cazul din 0.20.83 în care VM-uri afișate în UI ca PROD erau marcate greșit `Nu · numai PROD`;
- bulk publish, VM → Documentație, Rezumat și raportul Outline folosesc acum aceeași regulă;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.83

- extinde regula **Outline numai pentru PROD** și la publicarea individuală din fișa VM;
- în **VM → Documentație**, butonul **Trimite în Outline** este afișat numai dacă VM-ul are `Mediu = PROD`, integrarea Outline este activă și VM-ul nu este marcat `Nu se publică în Outline`;
- pentru TEST, DEV sau mediu nespecificat, zona Documentație afișează motivul și nu mai oferă acțiunea de publicare;
- endpoint-ul individual `POST /api/v1/vms/{id}/outline` validează aceeași regulă server-side, astfel încât un VM non-PROD nu poate fi publicat prin apel direct;
- Rezumatul VM și raportul de publicabilitate Outline țin cont de mediu și marchează non-PROD ca nepublicabil;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.82

- schimbă titlul paginilor VM publicate în Outline astfel încât să înceapă întotdeauna cu `vm-`; un prefix existent `vm-`/`VM-` este normalizat și nu este dublat;
- **Documente → Publică în Outline → VM-uri** publică în masă numai VM-urile cu `Mediu = PROD`;
- VM-urile TEST, DEV sau cu mediu nespecificat sunt numărate ca **sărite**, nu ca erori, și sunt afișate într-un tabel separat cu mediul și motivul;
- VM-urile PROD marcate `Nu se publică în Outline` rămân sărite și apar în același tabel cu motiv explicit;
- filtrul existent `Doar VM-uri pornite` rămâne neschimbat; publicarea individuală din fișa VM rămâne disponibilă, dar folosește noul titlu `vm-...`;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.81

- adaugă în fluxurile Network Map referințe VM corelate cu IP-urile exacte din `fortigate_vm_matches.vm_ip`;
- în nodurile Sursă/Destinație, VM-ul este afișat o singură dată, iar IP-ul/IP-urile care au produs match-ul apar imediat dedesubt;
- separă numele regulii de contextul `VDOM · NAT/FĂRĂ NAT`, cu padding vertical și linie dedicată;
- păstrează filtrarea vizuală introdusă în 0.20.80 pentru UDP și DNS/53;
- fără migrare DB și fără agent nou.

# 0.20.80

- evită repetarea numelui VM-DOC în obiectele sursă/destinație din diagramă; numele VM este titlul nodului, iar dedesubt rămân obiectele/adresele FortiGate;
- policy-urile FortiGate au acum noduri dinamice și listează toate serviciile/porturile permise pe linii separate;
- serviciile UDP-only sunt omise din diagramă și nu mai pot ancora accidental o săgeată într-un port TCP cu același număr;
- porturile UDP observate nu mai sunt afișate în nodurile VM; pe VM-urile DNS este ascuns și TCP/53;
- fără migrare DB, fără schimbări în matching/sync FortiGate și fără agent nou.

# 0.20.79

- repară scroll-ul orizontal global: pe desktop `html/body` nu mai taie overflow-ul X, astfel încât tabelele FortiGate și Network Map pot fi parcurse cu bara paginii/browserului;
- obiectele FortiGate sursă/destinație din diagramă afișează până la 4 valori pe verticală și pot fi extinse/restrânse fără suprapuneri;
- nodurile VM listează porturile observate pe linii separate; săgețile inbound/interne țintesc direct portul când service-ul Forti poate fi corelat sigur la un port observat;
- elimină limita vizuală de 24 fluxuri din diagramă, limita backend de 200 fluxuri și limita de 120 fluxuri din detaliile tehnice;
- fără migrare DB și fără agent nou.

# 0.20.78

- adaugă o diagramă de rețea SVG interactivă, tip Visio, pentru VM și serviciu, folosind datele existente DECLARAT / OBSERVAT / PERMIS;
- VM-urile sunt noduri clickable cu IP, servicii, Web/DB/Docker/porturi și firewall host sumarizate;
- fluxurile FortiGate sunt desenate sursă → policy/service → VM/destinație, inclusiv fluxurile interne dintre VM-uri;
- dependențele declarate inbound/outbound sunt reprezentate cu muchii întrerupte;
- harta detaliată veche rămâne accesibilă într-o secțiune expandabilă sub diagramă;
- adaugă Export SVG client-side pentru diagramă;
- fără migrare DB, fără modificări FortiGate matching/sync și fără agent nou.

# 0.20.77

- FortiGate wide tables now use the browser/page horizontal scroll instead of an inner table scrollbar.
- VM Firewall, Firewall Search and Forti Analysis expand the panel to the table width; vertical flow remains page-level.

# 0.20.76

- FortiGate tables no longer use an internal vertical scroll area; they expand with the page and keep one horizontal scrollbar at the bottom.
- Applies to VM Firewall, Firewall search and Forti analysis.
- UI-only patch; no DB, matching, sync or agent changes.

# 0.20.75

- mută **VM → Hartă rețea** sub grupul **Securitate**, reducând numărul de taburi principale;
- **VM → Securitate → Firewall** are carduri clickable pentru Source / Destination / VIP / Indicatori, tabel cu coloane separate Sursă/Destinație, Export Excel și panou pentru firewall-ul local al VM-ului;
- tabelele FortiGate au zonă verticală limitată și scrollbar orizontal accesibil în zona vizibilă a tabelului;
- reorganizează **Securitate → Firewall** în submeniurile **1. Caută / 2. Surse & Sync / 3. Analiză Forti**;
- filtrele Firewall și Analiză sunt compacte/orizontale, iar KPI-urile sunt micșorate pentru un singur rând pe desktop;
- Add/Edit sursă FortiGate este formular inline, fără prompt-uri succesive;
- adaugă `GET /api/v1/fortigate/rules/export`, cu export XLSX global filtrat și per VM;
- nu schimbă matching-ul FortiGate și nu necesită Sync doar pentru upgrade; fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.74

- adaugă **VM → Rețea → Hartă rețea** și **Serviciu → Rețea**, pe modelul **DECLARAT / OBSERVAT / PERMIS**;
- DECLARAT include servicii, dependențe interne inbound/outbound și conexiuni externe; OBSERVAT include porturi ascultate, Docker, baze și Web; PERMIS include firewall host și FortiGate;
- adaugă o vedere de fluxuri FortiGate `sursă → policy/service → destinație`, cu VM-urile corelate și obiectele FortiGate originale;
- adaugă **Securitate → Analiză FortiGate / Firewall Hygiene**, cu policies Corelate / Necorelate cu inventarul / Prea largi / Necesită verificare și indicatori ALL / fără comentariu;
- policies necorelate nu sunt declarate automat inutile; fără hit-count/last-used ele sunt doar candidați de verificare;
- analiza afișează VM-uri distincte și corelări source/destination/VIP per policy;
- Test/Sync FortiGate refuză acum răspunsurile `limited_permission=true`, evitând importul configurației mascate/default;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.73

- adaugă review pentru regulile FortiGate corelate cu VM-urile, direct în **Securitate → Firewall central** și în **VM → Securitate → Firewall**;
- review-ul Firewall folosește același flux ca pentru conturi, baze și Web ACL: interval 6/12 luni, justificat Da/Nu, observații, reviewer, last review și next review;
- cheia review-ului este stabilă la resincronizare: `VM + sursă FortiGate + VDOM + Policy ID + rol` (`source` / `destination` / `vip`), nu ID-ul temporar al match-ului;
- adaugă filtrul **Review** în Firewall central: Toate / Necesită review / Nerevizuite / La zi;
- **Rapoarte → Revizii securitate** include categoria nouă **Firewall**, cu policy, rol, indicatori de risc, corelarea FortiGate și calendarul review-ului; exportul Excel include automat și aceste rânduri;
- intervalul implicit pentru Firewall este 6 luni; nu există migrare DB nouă deoarece este reutilizată tabela generică `security_reviews`;
- fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.72

- revine la GET CMDB complet, fără `start/count`, pentru `firewall/address`, `firewall/addrgrp`, `firewall/policy` și `firewall/vip`; 0.20.71 putea tăia inventarul exact la 500 de policy-uri;
- dacă FortiGate raportează `limit_reached=true`, sync-ul eșuează explicit în loc să accepte inventar parțial;
- matcher-ul păstrează `ipmask` și `iprange` și adaugă corelare sigură pentru `interface-subnet` și `wildcard`; `dynamic`, `geography`, FQDN, MAC, route-tag și `/0` rămân ignorate;
- Test FortiGate afișează totalul real active + disabled și distribuția obiectelor de adresă corelabile;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.71

- corectează sincronizarea FortiGate CMDB: endpoint-urile `firewall/address`, `firewall/addrgrp`, `firewall/policy` și `firewall/vip` sunt paginate complet cu `start`/`count` în loc să fie citită doar prima pagină;
- folosește `limit_reached` și `next_idx` din răspunsul FortiGate și protecții anti-loop;
- păstrează matcher-ul strict din 0.20.70 (`ipmask`, `iprange`, VIP, grupuri recursive către obiecte IP valide), deci nu reintroduce match-urile false eliminate anterior;
- Test FortiGate arată acum și numărul de pagini citite pentru adrese, grupuri, policies și VIP-uri;
- logul de sync raportează numărul total de obiecte și paginile CMDB citite, util pentru verificarea inventarului complet;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.70

- corectează matcher-ul FortiGate: numai obiectele IPv4 statice `ipmask` și `iprange` pot dovedi apartenența unui VM la o policy; tipurile `geography`, `dynamic`, `interface-subnet`, `wildcard`, `mac`, `route-tag`, FQDN etc. sunt ignorate pentru corelarea VM;
- obiectele custom `0.0.0.0/0` sunt tratate ca `all` și nu mai generează match-uri către toate VM-urile;
- grupurile de adrese sunt păstrate recursive, dar produc match doar dacă traseul ajunge la un obiect IPv4 static valid;
- păstrează maximum un match `source` și unul `destination` per VM/policy, indiferent de numărul de IP-uri sau obiecte suprapuse; VIP-urile rămân distincte;
- migrarea `070_fortigate_strict_vm_matching.up.sql` șterge corelările vechi calculate cu algoritmul permisiv și adaugă indexuri pentru paginarea Firewall central; după upgrade este necesar un Sync FortiGate;
- optimizează `GET /api/v1/fortigate/rules`: statisticile sunt calculate într-o singură agregare, iar pagina este ordonată după cheile indexabile ale match-ului în loc de un filesort global după numele VM;
- Test FortiGate raportează separat obiectele IP corelabile și obiectele ignorate;
- nu necesită agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.69

- hotfix pentru migrarea `069_fortigate_ignore_disabled_policies.up.sql`: `disabled_policy_count` și indexul FortiGate sunt create cu `IF NOT EXISTS`, astfel încât migrarea poate fi reluată după un startup 0.20.68 întrerupt;
- rezolvă eroarea de pornire `Duplicate column name disabled_policy_count`;
- nu schimbă schema funcțională față de 0.20.68 și nu necesită agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.68

- FortiGate: policy-urile cu `status=disable` / `disabled` / `off` nu mai sunt salvate și nu mai intră în corelarea VM ↔ firewall;
- matcher-ul verifică defensiv starea policy-ului înainte de orice corelare, inclusiv pentru VIP/DNAT;
- **Securitate → Firewall central** afișează numai policy-uri active și nu mai oferă filtrul pentru Disabled;
- Test conexiune raportează separat `policies active` și `disabled ignorate`, iar istoricul de Sync păstrează numărul policy-urilor disabled sărite;
- migrarea `069_fortigate_ignore_disabled_policies.up.sql` elimină din inventarul existent policy-urile disabled și corelările lor și adaugă index pe status;
- `match_count` din noile sincronizări reprezintă exclusiv corelări provenite din policy-uri active;
- nu necesită agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.67

- adaugă integrarea **FortiGate REST API** în **Securitate → Firewall central**, cu surse multiple, VDOM, token API criptat, Test, Sync manual și scheduler;
- sincronizează address objects, address groups, firewall policies și VIP/DNAT din FortiGate;
- corelează IP-urile VM cu obiecte exacte, subneturi, intervale și grupuri nested/recursive; un obiect `all` singur nu este folosit ca dovadă de apartenență a unei VM, pentru a evita corelări false;
- corelează VIP/DNAT prin `mappedip` și afișează VM-ul ca sursă, destinație sau țintă VIP;
- adaugă filtre/paginare după FortiGate, VDOM, rol VM, action, policy status, service, interfață și indicator;
- evidențiază pentru review indicatori precum source ALL, destination ALL, service ALL, WAN → VM, VIP/DNAT și lipsa comentariului, fără a clasifica automat regula ca nesigură;
- adaugă **VM → Securitate → Firewall**, cu motivul exact al corelării și link către Firewall central;
- migrarea DB `068_fortigate_firewall_inventory.up.sql`; nu necesită agent nou, `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.66

- adaugă raportul **Rapoarte → Revizii securitate**, ca plan calendaristic pentru Access Review;
- tabel paginat cu VM, versiune agent, categorie, resursă, indicatori, ultimul review, următorul review și numărul de zile până la scadență;
- filtre după VM, versiune agent, categorie (Conturi / Baze de date / Web), status, perioadă calendaristică, reviewer, justificare și risc, plus intervale Last review / Next review și min/max zile până la scadență;
- preseturi rapide pentru Nerevizuite, Expirate, Săptămâna aceasta, Săptămâna viitoare, Luna aceasta, Luna viitoare, Următoarele 30 zile și Risc ridicat;
- export Excel respectând filtrele active și acțiune **Revizuiește** direct din raport;
- raportul prioritizează automat nerevizuitele, expiratele și următoarele scadențe și include indicatori de risc derivați din conturi privilegiate, HBA warnings, GRANT OPTION, ALLOW ALL și lipsa ACL explicit;
- link direct **Calendar revizii** din Securitate;
- fără migrare DB și fără agent nou; vm-doc-agent 1.7.12 rămâne recomandat.

# 0.20.65

- adaugă în VM → Aplicație → Docker / Baze de date / Web filtre după Serviciu, Mediu, Status operațional și Tip soluție;
- filtrele listează numai valorile deja folosite pe VM-ul curent, nu toate valorile globale;
- adaugă filtre separate pentru Necesită/Nu necesită documentare și pentru resurse Complete/Nesetate;
- „Nesetate” include resurse fără asociere sau cu cel puțin o asociere incompletă;
- filtrele combinate se potrivesc pe aceeași asociere serviciu-context;
- fără migrare DB și fără agent nou.

# 0.20.64

- Web Access Control afișează toate site-urile/vhost-urile inventariate, inclusiv cele fără reguli ACL explicite;
- adaugă filtrul ACL: toate / cu reguli / fără ACL explicit / ALLOW ALL;
- pagina VM → Securitate → Web ACL afișează toate vhost-urile VM-ului;
- remediază cazul reverse-proxy în care UI-ul ascundea vhost-urile fără allow/deny, deși existau în inventarul Web.

# 0.20.63

- afișează pentru conturile VM data ultimei schimbări a parolei și data expirării;
- adaugă în Database Access privilegiile/grants colectate de vm-doc-agent 1.7.12;
- PostgreSQL/MariaDB/MySQL/SQL Server pot afișa scope, database, schema, obiect, privilegiu, GRANT OPTION și DENY unde există;
- căutarea Database Access include privilegiile și obiectele, iar filtrul Indicator include GRANT OPTION și DENY explicit;
- pagina VM → Securitate → Baze de date afișează aceleași informații;
- fără migrare DB nouă: access_json păstrează aditiv câmpurile noi.

# 0.20.62

- adaugă filtre și paginare în **Securitate → Conturi VM / Database Access / Web Access Control**;
- conturile system fără login, fără privilegii și fără o stare de parolă relevantă sunt ascunse implicit; `root` rămâne întotdeauna vizibil, iar conturile system relevante (de ex. cu shell/login, privilegii sau parolă activă/goală) rămân în listă;
- filtrul Tip cont permite afișarea inventarului complet, numai a conturilor system sau numai a utilizatorilor + root;
- adaugă în fișa fiecărui VM zona **Securitate** cu Rezumat, Conturi, Baze de date și Web ACL;
- `GET /api/v1/security` acceptă `vm_id` pentru încărcarea eficientă a securității unei singure VM;
- nu necesită migrare DB și nu necesită o versiune nouă de agent; vm-doc-agent 1.7.11 rămâne recomandat.

# 0.20.61

- modul nou **Securitate / Access Review** cu Dashboard, Conturi VM, Database Access și Web Access Control;
- review configurabil la 6/12 luni, cu reviewed_at/by, justificare și observații;
- conturile VM afișează explicit shell-ul și starea parolei;
- persistă inventarul DB users/roles/HBA și Web allow/deny primit de la agent 1.7.11;
- Web ACL este asociat site-ului/vhost-ului și păstrează source_file pentru reguli provenite din include.
# 0.20.60

- curăță și normalizează versiunile din **Rapoarte → Componente software**;
- elimină din câmpul Versiune liniile capturate accidental ca `[Warning]`, `[Error]`, `deprecated`, `adjusted to`, `invalid option` și alte diagnostice;
- reduce bannerele lungi la versiunea produsului, de exemplu MariaDB `10.6.11-MariaDB-0ubuntu...` → `10.6.11`;
- normalizează și forme uzuale precum SQL Server `2022`, Java `8u401` și taguri de container `16-alpine`;
- aceeași normalizare se aplică în interfață, filtre, Export Excel și publicarea Outline;
- inventarul brut rămâne neschimbat, fără migrare DB și fără update de vm-doc-agent.

# 0.20.59

- adaugă în **Documente → Configurare Outline** destinația/părintele **Componente suport** pentru publicarea inventarului automat de componente software;
- **Rapoarte → Componente software** poate publica asincron toate componentele detectate sau numai componenta selectată;
- creează câte o pagină copil Outline per componentă și păstrează maparea locală pentru update fără duplicate;
- VM-urile din raport și din paginile publicate folosesc linkul fișei VM Outline când există; serviciile/proiectele folosesc Link documentație Outline;
- separă coloanele **Power** și **Mediu** și normalizează Power la **ON/OFF**;
- filtrele vizuale de versiune/categorie/mediu/căutare nu limitează conținutul publicat, astfel încât pagina unei componente rămâne completă;
- migrare DB `066_outline_software_component_documents.up.sql`; vm-doc-agent neschimbat.

# 0.20.58

- adaugă **Rapoarte → Componente software**, un inventar automat cross-VM pentru întrebări de tip „unde am PostgreSQL / MongoDB / Java 8?”;
- detectează și normalizează componentele din colectoarele specializate **Baze de date / Web / Docker**, din imaginile containerelor Docker, din serviciile observate de agent și din inventarul software instalat;
- sursele specializate au prioritate pentru versiune și stare, iar aceeași componentă este deduplicată per VM; pot rămâne mai multe versiuni pe aceeași VM atunci când sunt observate explicit;
- include un catalog curatat pentru baze de date, cache, web/proxy, application server, runtime, messaging, identity, mail, containere, observability, search/storage și platformă;
- raportul oferă carduri clicabile per componentă, filtre după componentă/categorie/versiune/mediu, căutare liberă, paginare 10/25/50/100/200 și export Excel;
- **Componente suport** și marcajele **Principal** rămân neschimbate și independente de inventarul automat;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.57

- hotfix pentru numerotarea din fișa VM când secțiunea **Porturi ascultate** este ascunsă sau absentă;
- secțiunea **Porturi ascultate** rămâne omisă complet, dar numărul ei este rezervat astfel încât **Firewall** rămâne `9.7` și capitolele următoare nu se renumerotează;
- păstrează comportamentul 0.20.56: porturile marcate **Principal** rămân în secțiunea dedicată, iar lista completă nu apare;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.56

- schimbă semantica **Ascunde porturile ascultate**: se ascunde numai lista completă detectată, nu și porturile/procesele marcate explicit **Principal**;
- când lista completă este ascunsă, VM-ul afișează separat numai porturile principale selectate;
- fișa VM și Markdown-ul/Outline omit complet secțiunea **Porturi ascultate**, dar păstrează **Porturi și procese principale** dacă există selecții;
- publicarea individuală **Trimite în Outline** rulează acum asincron ca job de fundal, pentru a evita `504 Gateway Timeout` pe request-ul browser → VM-DOC;
- păstrează organizarea Documente → Publică în Outline pe două rânduri și preview-ul serviciilor cu carduri clicabile, paginare și Export Excel;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.55

- hotfix pentru testul introdus în 0.20.54 la ascunderea porturilor ascultate;
- corectează `vm_listening_ports_test.go` pentru structura curentă `inventory.DocumentSection`, folosind câmpul `Title` în loc de câmpul inexistent `Label`;
- nu schimbă funcționalitatea aplicației, schema DB sau agentul.

# 0.20.54

- adaugă pe fiecare VM opțiunea **Ascunde porturile ascultate**, utilă pentru servere AD/DNS cu multe porturi RPC dinamice;
- când opțiunea este activă, secțiunea `Porturi ascultate` și porturile/procesele principale nu mai apar în interfața VM, nici în JSON-ul brut afișat din interfață și nici în fișa/documentația VM;
- criteriul de completare pentru port/proces principal este considerat satisfăcut pentru VM-urile la care porturile sunt ascunse intenționat;
- reorganizează **Documente → Publică în Outline** pe două rânduri complete: VM-uri pe primul rând, Servicii pe al doilea;
- rezultatul verificării serviciilor Outline are acum carduri clicabile pentru filtrare, paginare 10/25/50/100/200 și memorarea dimensiunii paginii;
- adaugă **Export Excel** pentru verificarea serviciilor Outline; exportul respectă cardul/filtrul selectat și exportă toate rândurile filtrate, nu doar pagina vizibilă;
- include migrarea `065_vm_hide_listening_ports.up.sql`; vm-doc-agent neschimbat.

# 0.20.53

- repară `504 Gateway Timeout` la **Verifică serviciile** înainte de publicarea în Outline;
- dry-run-ul serviciilor rulează acum **asincron**, ca job de fundal, la fel ca publicarea în masă;
- request-ul HTTP pornește jobul și răspunde imediat cu `202 Accepted`, astfel încât timeout-ul Nginx/HAProxy nu mai întrerupe verificarea;
- UI afișează progresul `servicii X/Y` și serviciul verificat curent, apoi încarcă automat sumarul și tabelul complet;
- validările existente rămân neschimbate: link Outline, acces document, stare serviciu, bifa Outline, generare Markdown și protecția Vault;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.52

- adaugă **dry-run obligatoriu** înainte de publicarea în masă a serviciilor în Outline;
- `Documente → Publică în Outline → Servicii` afișează mai întâi **Verifică serviciile** și numai după verificare butonul **Publică serviciile eligibile**;
- verificarea controlează: serviciu activ/neretras, bifa Outline, Link documentație, document Outline existent și accesibil, plus generarea conținutului Markdown;
- sumarul dry-run arată: total, eligibile, fără link, excluse Outline, inactive/retrase, erori link și erori conținut; tabelul explică motivul pentru fiecare serviciu;
- publicarea primește exact ID-urile eligibile din dry-run și reverifică starea curentă înainte de fiecare update;
- după finalizarea jobului este necesară o nouă verificare înainte de republicare;
- adaugă protecție runtime care blochează publicarea dacă URL-ul Vault ar apărea accidental în Markdown-ul Outline;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.51

- mută **Publicare Outline** și **Vault** exclusiv pe prima pagină a VM-ului, în **Rezumat**;
- în Rezumat, cele două panouri sunt afișate compact pe același rând: Publicare Outline în stânga și Vault în dreapta;
- elimină complet Publicare Outline și Vault din `Configurare → Infrastructură`;
- elimină afișarea redundantă `Se publică în Outline` din panoul Identificare și încadrare, starea rămânând în panoul dedicat Publicare Outline;
- Servicii → Detalii → Vault rămâne neschimbat; linkurile Vault rămân strict interne aplicației și nu intră în fișe, Outline sau exporturi de documentație;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.50

- compactează zona VM → Configurare/Infrastructură: **Publicare Outline** și **Vault** sunt afișate pe același rând, în două coloane;
- adaugă `vault_url` strict intern aplicației pentru VM-uri și servicii;
- pe VM, linkul Vault se editează din panoul din dreapta și este clicabil imediat sub textbox când există;
- în Servicii → Detalii adaugă subtab-ul **Vault**, cu textbox și link clicabil;
- linkurile Vault sunt excluse explicit din fișele DOCX/Markdown/PDF, exporturile de documentație și toate publicările Outline;
- include teste de regresie care verifică faptul că URL-ul Vault nu ajunge în Markdown/Outline sau în DOCX;
- include migrarea `064_vault_links_internal_only.up.sql`; vm-doc-agent neschimbat.

# 0.20.49

- elimină coloana `Hostname` din tabelul **Inventar VM** publicat în Outline;
- lista VM din aplicație și exporturile Excel rămân neschimbate;
- tabelul publicat rămâne: `VM | Power | CPU / RAM | Mediu | OS | Suport OS | IP | Servicii | Outline | Ultima publicare Outline`;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.48

- adaugă pagina **Releasuri** în navigația principală, cu istoricul versiunilor serverului;
- fiecare release afișează în forma colapsată `Versiune`, `Data` și `Modificarea principală`;
- click pe release deschide detaliile complete ale modificărilor; toate intrările sunt colapsate implicit;
- versiunea serverului aflată în execuție este evidențiată în listă;
- istoricul 0.20.4 → versiunea curentă este inclus ca resursă statică în binarul aplicației;
- fără migrare DB; vm-doc-agent neschimbat.

# 0.20.47

- Rafinează tabelul publicat din Inventar VM în Outline: elimină `vCenter`, `Agent`, `Completare` și `Ultimul JSON` și adaugă `Hostname`.
- Power este afișat compact `ON` / `OFF`; starea `SUSPENDED` rămâne explicită dacă apare.
- Mediu este normalizat la `PROD` / `TEST` / `DEV` pentru valorile uzuale.
- Numele VM este link către pagina sa Outline atunci când există mapping în `outline_vm_documents_global`.
- Serviciile din tabel sunt linkuri către `internal_services.documentation_url` atunci când au Link documentație; altfel rămân text simplu.
- Butonul **Publică tabelul în Outline** apare în lista VM numai dacă Outline este activ global, destinația `vm_inventory` este activă și are document/link configurat.
- Endpoint-ul de publicare validează server-side aceleași condiții înainte să modifice pagina Outline.
- Fără migrare DB; agent neschimbat.

## 0.20.46

- Hotfix test export VM: `TestVMExportRowsUsesInventoryValues` a fost actualizat pentru schema curentă de 26 coloane.
- Au fost corectați indicii coloanelor după introducerea `Mediu` și `OS suportat`.
- Fără modificări funcționale, fără migrare DB, agent neschimbat.

## 0.20.45

- Lista principală VM adaugă filtrele `Outline: Toate/DA/NU` și `OS suportat: Toate/DA/NU`; aceleași filtre se aplică listei paginate, exportului Excel și publicării tabelului în Outline.
- `OS suportat = DA` include numai VM-urile determinate ca suportate conform nomenclatorului `unsupported_os`; `NU` include numai VM-urile potrivite explicit pe o regulă activă; cazurile nedeterminate rămân la `Toate`.
- Adaugă butonul **Publică tabelul în Outline** în lista VM; sunt publicate toate VM-urile rezultate din filtrele curente, nu doar pagina vizibilă.
- Adaugă destinații generice de publicare Outline, configurabile din **Documente → Configurare Outline → Destinații publicare**; prima destinație este `vm_inventory` / **Inventar VM**.
- Destinația indică o pagină Outline existentă; VM-DOC îi păstrează titlul și actualizează conținutul tabelului. Configurația reține URL-ul/document ID-ul rezolvat și data ultimei publicări.
- Tabelul publicat include VM, stare vCenter, Power, CPU/RAM, mediu, OS, suport OS, IP, agent/stare/versiune, servicii, Outline DA/NU, ultima publicare a fișei VM, completare și ultimul JSON.
- Publicarea este blocată dacă filtrele curente nu întorc niciun VM, pentru a nu suprascrie accidental pagina cu un tabel gol.
- Exportul Excel VM include acum și `Mediu` și `OS suportat`.
- Include migrarea `063_outline_publication_targets.up.sql`; vm-doc-agent nu necesită update.

## 0.20.44

- Documente → Publică în Outline verifică explicit bifa `Nu se publică în Outline` înainte de publicarea fiecărui VM.
- VM-urile excluse sunt sărite, nu sunt trimise către Outline și nu sunt raportate ca erori.
- Jobul bulk afișează separat numărul de VM-uri publicate și sărite.
- Verificarea este dublă: înainte de apelul de publicare și din nou în fluxul individual `publishVMToOutline`.
- Fără migrare DB; agent neschimbat.

## 0.20.43

- Raportul Suport sisteme de operare afișează serviciile interne asociate fiecărui VM.
- Filtrul VM pornit/oprit pornește implicit pe Pornit; Reset filtre revine la Pornit.
- Cardurile reflectă căutarea și filtrele generale, inclusiv filtrul implicit Pornit.
- Spațiere îmbunătățită între filtre, carduri, grafice și tabel.
- Rândul cu contor, Export Excel și nomenclator are padding pe toată lățimea.
- Exportul Excel Suport OS include coloana Servicii.
- Fără migrare DB și fără update de agent.

## 0.20.42

- Lista principală VM are coloana `Outline` cu `DA/NU`, calculată strict din `outline_documentation_disabled`.
- Lista VM afișează `Ultima publicare Outline` din `outline_vm_documents_global.last_synced_at` pentru targetul `virtualization`.
- VM-urile nepulicate încă afișează `—` la data ultimei publicări.
- Exportul Excel VM include aceleași două coloane.
- Fără migrare DB; agent neschimbat.

## 0.20.41

- Raportul **Suport sisteme de operare** afișează filtrele înaintea cardurilor și a restului conținutului.
- Cardurile **VM-uri / Suportate / Nesuportate / Nedeterminat** se recalculează după căutare, power state, mediu și Outline; filtrul de stare rămâne dimensiunea selectabilă prin carduri.
- Graficele sunt mutate într-un bloc colapsat implicit și se recalculează după căutare și filtrele generale.
- Tabelul este paginat local după filtrare, cu opțiuni 10 / 25 / 50 / 100 / 200 rânduri pe pagină; preferința este păstrată în browser.
- Exportul Excel continuă să folosească toate filtrele active, independent de pagina curentă.
- Fără migrare DB; agent neschimbat.

## 0.20.40

- repară binding-ul filtrelor pentru `Suport sisteme de operare`, `Outline · VM-uri` și `Outline · Servicii`;
- cardurile de sumar aplică acum imediat filtrul corespunzător și actualizează contorul + URL-ul de export Excel;
- select-urile aplică filtrul la `change`, iar câmpul de căutare filtrează la tastare și la Enter;
- adaugă butoanele `Caută / Aplică` și `Resetează` în cele trei rapoarte;
- mută listener-ele după randarea DOM-ului, eliminând regresia introdusă în 0.20.39;
- fără migrare DB și fără update de vm-doc-agent.

## 0.20.39

- separă raportul `Publicare Outline` în două rapoarte independente: `Outline · VM-uri` și `Outline · Servicii`;
- VM-uri: filtre după publicare, Pornit/Oprit, mediu, motiv și căutare; cardurile Total/Se publică/Nu se publică/Pornite/Oprite sunt clicabile;
- servicii: filtre după publicare, stare Activ/Inactiv/Retras, criticitate, status documentație, motiv și căutare; cardurile sunt clicabile;
- exporturile Excel pentru cele două rapoarte Outline respectă exact filtrele curente;
- raportul `Suport sisteme de operare` primește filtre după stare suport, Pornit/Oprit, mediu, Outline și căutare, cu carduri clicabile și export Excel filtrat;
- migrarea `062_reports_filters_unsupported_os_seed.up.sql` schimbă unicitatea nomenclatorului în `(category_code,name,item_code)` și prepopulează idempotent familiile/versiunile EOL standard pentru Ubuntu, Debian, CentOS Linux și Windows legacy;
- fără update de vm-doc-agent.

## 0.20.38

- corectează eroarea `bad_request` la salvarea bifei VM **Nu se publică în Outline** și acceptă temporar și aliasul vechi/greșit `outlin_documentation_disabled`;
- adaugă migrarea reparatorie `061_outline_schema_repair.up.sql`, care recreează idempotent coloanele/indexurile Outline dacă migrarea 058 a fost înregistrată incomplet;
- rapoartele **Publicare Outline** și **Suport sisteme de operare** verifică schema înainte de a folosi coloanele Outline și nu mai cad cu HTTP 500 dacă acestea lipsesc;
- revalidează categoria `unsupported_os` în migrarea 061;
- update exclusiv server/UI/DB, fără update de vm-doc-agent.

## 0.20.37

- adaugă nomenclatorul `Sisteme de operare nesuportate`, cu familie OS și versiune/familie de versiune;
- adaugă raportul `Suport sisteme de operare` cu trei pie chart-uri și liste separate pentru VM-uri suportate, nesuportate și cu suport nedeterminat;
- raportul OS include VM, hostname, mediu, IP, OS/versiune, regula potrivită și starea de publicare Outline;
- adaugă raportul `Publicare Outline` pentru VM-uri și servicii, cu pie chart-uri, motivul excluderii și export Excel;
- în Rezumat VM și Rezumat Serviciu este afișată starea efectivă `Se publică în Outline: Da/Nu`, inclusiv motivul;
- include migrarea `060_unsupported_os_nomenclature.up.sql`; vm-doc-agent nu necesită update.

## 0.20.36

- corectează bifa **Componentă suport** astfel încât salvarea să fie inline, fără reîncărcarea fișei VM și fără schimbarea tabului/subsecțiunii curente;
- după bifare, rândul serviciului se deschide automat și afișează imediat editorul pentru **Componentă propusă**, **Versiune manuală** și **Port(uri) manual**;
- endpoint-ul de salvare întoarce componenta îmbogățită cu versiunea și porturile detectate, astfel încât valorile automate sunt vizibile imediat;
- salvarea override-urilor rămâne în același loc și actualizează editorul fără refresh;
- fără migrare DB nouă și fără update de vm-doc-agent.

## 0.20.35

- adaugă pe serviciile observate de agent din pagina VM bifa **Componentă suport**, independentă de marcajul **Principal**;
- normalizează automat denumiri uzuale precum PostgreSQL, Redis, Meilisearch, MinIO, Docmosis, Sentry și Keycloak, dar permite editarea numelui canonic pentru orice tehnologie;
- versiunea este preluată automat din `version` / `package_version`; versiunea și porturile pot avea override manual per VM/serviciu;
- corelează automat porturile atunci când procesul/executabilul poate fi asociat în mod sigur cu tehnologia selectată;
- adaugă raportul **Rapoarte → Componente suport**, grupat **Componentă → Versiune → Mediu**, cu VM/amplasare, hostname, IP, porturi, servicii/proiecte asociate și serviciul agent;
- raportul are filtre și export Excel în aceeași structură logică;
- include migrarea `059_vm_support_components.up.sql`; vm-doc-agent rămâne neschimbat.

## 0.20.34

- afișează controlul VM **Nu se publică în Outline** direct în **Rezumat**, astfel încât opțiunea să fie vizibilă imediat la deschiderea VM-ului;
- păstrează același control și în **Configurare → Infrastructură**; ambele folosesc câmpul persistent `outline_documentation_disabled`;
- după salvare rămâne deschisă secțiunea curentă a VM-ului;
- fără migrare DB nouă și fără update de vm-doc-agent.

## 0.20.33

- ascunde temporar din interfața **Documente → Export / Publică** butoanele de export PDF; endpoint-urile PDF rămân disponibile în backend pentru reluarea ulterioară a funcției;
- adaugă lifecycle explicit pentru servicii: **Retras / scos din uz**, motiv de retragere din nomenclator și data retragerii; marcarea ca retras dezactivează automat serviciul;
- adaugă nomenclatorul editabil `service_retirement_reason`, cu valori inițiale pentru scos din uz, înlocuit/migrat, proiect închis, contract încheiat și alt motiv;
- adaugă bifa independentă **Nu se documentează în Outline**, utilizabilă inclusiv pentru servicii active; serviciile retrase sau excluse explicit nu sunt publicate și nu sunt folosite drept linkuri Outline din fișele VM;
- butoanele Outline din fișa VM și din fișa serviciului sunt afișate numai când integrarea Outline este activată global în **Documente**;
- fișa tehnică și operațională a serviciului include starea lifecycle și, pentru serviciile retrase, motivul și data retragerii;
- adaugă pe VM bifa independentă **Nu se publică în Outline**; publicarea individuală, publicarea în masă și linkurile VM din fișele serviciilor respectă această excludere;
- dacă mapping-ul unei VM indică o pagină Outline care a fost ștearsă, publicarea verifică existența documentului și îl recreează automat sub **Virtualizare**, actualizând mapping-ul local;
- include migrarea `058_service_lifecycle_outline_controls.up.sql`; vm-doc-agent rămâne neschimbat.

## 0.20.32

- separă pagina **Documente** în două zone: **Export / Publică** și **Șabloane**, folosind aceeași navigare pe taburi ca paginile de inventar;
- publicarea Outline a VM-urilor folosește ca titlu exact numele VM-ului din vCenter, fără prefixul `VM —` și fără preferință pentru guest hostname;
- fișa VM publicată în Outline transformă serviciile asociate în linkuri Outline atunci când serviciul are configurat **Link documentație** către aceeași instanță Outline;
- fișa serviciului publicată în Outline transformă VM-urile asociate în linkuri către paginile lor Outline din categoria **Virtualizare**; linkurile interne VM-DOC nu mai sunt inserate în conținutul Outline;
- adaugă publicarea serviciilor din fișa serviciului și publicarea în masă din **Documente → Export / Publică**; serviciul este actualizat numai în pagina indicată de **Link documentație**, fără creare, redenumire sau mutare automată;
- la publicarea în masă a serviciilor, serviciile fără Link documentație sunt sărite și raportate separat, iar erorile unui serviciu nu opresc restul jobului;
- câmpul **Virtualizare · Document / URL** acceptă UUID, slug sau URL Outline și este rezolvat automat la UUID-ul real la salvare;
- testul Outline afișează explicit când integrarea este dezactivată și propagă mesajele HTTP reale de la API-ul Outline în locul unui `500` generic;
- nu adaugă migrare DB și nu necesită update de vm-doc-agent.

## 0.20.31

- schimbă modelul Outline: proiectele/serviciile nu mai sunt publicate automat și VM-urile nu mai sunt grupate sub proiecte;
- introduce ținta Outline **Virtualizare**, configurată prin propriul `Document ID`; toate fișele VM sunt create direct ca pagini copil sub acest document;
- publicarea individuală din fișa VM nu mai cere alegerea unui proiect; mapping-ul Outline este global per VM și categorie, astfel încât aceeași VM să nu fie duplicată din cauza asocierilor la mai multe proiecte;
- publicarea în masă din **Documente → Outline** lucrează direct cu VM-urile și păstrează filtrul **Doar VM-uri pornite** bifat implicit;
- configurația Outline este pregătită pentru categorii cu părinți diferiți prin tabelul `outline_targets`; prima țintă este `virtualization`;
- dacă ID-ul documentului părinte Virtualizare se schimbă, paginile VM deja mapate sunt mutate automat la noul părinte prin API-ul Outline;
- butonul de publicare Outline este eliminat din fișa proiectului; pentru servicii se folosește în continuare câmpul existent **Link documentație**;
- include migrarea `057_outline_virtualization_target.up.sql`; vm-doc-agent rămâne neschimbat.

## 0.20.30

- adaugă integrarea directă cu Outline prin API key Bearer, configurabilă din pagina **Documente**; cheia este criptată în DB cu cheia master VM-DOC;
- fiecare proiect/serviciu intern este publicat ca document Outline, iar fișele VM sunt publicate ca documente copil sub proiectul ales;
- adaugă buton **Trimite în Outline** în fișa proiectului și în fișa VM; VM-urile asociate mai multor proiecte permit alegerea proiectului destinație;
- adaugă în **Documente → Outline** publicare în masă asincronă, cu progres, opțiunea **Include fișele VM** și filtrul **Doar VM-uri pornite**;
- publicarea este idempotentă la nivel de mapping: paginile create sunt actualizate la următoarele publicări și sunt recreate dacă mapping-ul indică un document șters;
- conținutul este Markdown derivat din aceeași structură documentară ca fișele VM/Serviciu și nu include câmpul vizibil **Generat de**;
- folosește numărul electronic și data ultimei fișe generate atunci când acestea există;
- adaugă Audit pentru configurare, test de conexiune, publicare individuală și publicare bulk Outline;
- include migrarea `056_outline_integration.up.sql`; vm-doc-agent rămâne neschimbat.

## 0.20.29

- exportul bulk **VM DOCX** primește opțiunea **Doar VM-uri pornite**, bifată implicit; când este activă sunt incluse numai VM-urile active/neretrase cu `power_state=POWERED_ON`, iar debifarea revine la toate VM-urile active/neretrase;
- regenerarea fișelor VM se aplică numai setului selectat de filtrul de power state și continuă să genereze documente fără rândul vizibil **Generat de**;
- exportul bulk **Proiecte DOCX** primește opțiunea **Regenerează toate fișele proiectelor înainte de export**, implicit debifată; aceasta creează o versiune nouă pentru fiecare proiect activ folosind șablonul implicit și fără **Generat de**;
- dacă sunt bifate simultan **Regenerează** și **Generează dacă nu există**, regenerarea tuturor proiectelor are prioritate;
- celelalte opțiuni ale proiectelor rămân implicit debifate, iar exporturile PDF nu sunt modificate;
- nu există migrare DB nouă și agentul rămâne neschimbat.

## 0.20.28

- extinde exportul bulk DOCX al VM-urilor cu opțiunea **Regenerează toate fișele VM înainte de export**; opțiunea este implicit debifată și folosește șablonul VM implicit;
- fișele VM regenerate de exportul bulk și fișele de proiect generate automat de export nu includ rândul vizibil **Generat de**; utilizatorul rămâne păstrat în istoricul documentului și în Audit;
- exportul bulk DOCX al proiectelor primește două opțiuni independente și implicit debifate: **Generează fișa proiectului dacă nu există** și **Include și fișele VM asociate proiectelor**;
- fișele VM asociate proiectelor sunt incluse separat în directorul `VM-uri/<proiect>/` din arhivă, fără regenerare automată; VM-urile fără fișă apar explicit în `_manifest.csv`;
- exporturile PDF rămân neschimbate în această versiune; opțiunile noi sunt aplicate numai DOCX;
- nu există migrare DB nouă și agentul rămâne neschimbat.

## 0.20.27

- adaugă patru exporturi în masă din pagina **Documente**: arhivă ZIP cu fișele tuturor VM-urilor în DOCX, toate VM-urile în PDF, toate proiectele/serviciile în DOCX și toate proiectele/serviciile în PDF;
- fiecare export folosește **ultima fișă deja generată** pentru fiecare VM activ/neretras sau proiect activ și nu creează versiuni noi în istoricul documentelor;
- arhivele includ `_manifest.csv`, `_sumar.txt` și `_README.txt`, astfel încât obiectele fără fișă sau conversiile eșuate să fie vizibile explicit;
- exportul PDF convertește DOCX-urile în loturi prin LibreOffice/soffice, cu profil temporar izolat, cleanup automat și suport pentru executabil configurat prin `VM_DOC_SOFFICE_BIN`;
- descărcarea ZIP este transmisă incremental, cu buffering Nginx dezactivat pentru request, pentru a suporta volume mari de fișe fără a încărca întreaga arhivă în memorie;
- nu există migrare DB nouă și agentul rămâne neschimbat.

## 0.20.26

- adaugă inventar manual **Echipamente** pentru dispozitive medicale, echipamente de laborator, appliance-uri, servere fizice, storage, IoT și alte resurse care nu sunt VM-uri;
- fiecare echipament poate avea tip din nomenclator, producător, model, serie, hostname, IP-uri, MAC, locație, responsabil, descriere, observații și link de documentație;
- echipamentele se leagă many-to-many la proiecte/servicii interne; aceeași pereche echipament–serviciu poate avea mai multe fluxuri distincte cu rol, protocol, port, sens, scop și observații;
- pagina Serviciului primește secțiunea **Echipamente**, cu adăugare/editare/ștergere a asocierilor, iar pagina echipamentului arată toate serviciile asociate;
- schema serviciului, căutarea globală, Auditul contextual și fișele Serviciu DOCX/Markdown includ echipamentele; ștergerea/comasarea proiectelor contabilizează și mută asocierile de echipamente;
- adaugă nomenclatorul editabil `device_type`, permisiunile `equipment.read` / `equipment.manage` și migrarea `055_equipment_inventory.up.sql`; agentul rămâne neschimbat.

## 0.20.25

- permite mai multe dependențe explicite între aceleași două servicii cu același tip de relație și aceleași medii; fiecare `Adaugă dependență` creează un flux separat în loc să suprascrie primul rând;
- protocolul, portul și câmpul `Scop / detalii` diferențiază fluxurile (de exemplu syslog și API către același serviciu);
- schema vizuală a serviciului, `Depinde de` / `Este utilizat de`, dependențele vizibile pe VM și fișele DOCX/Markdown păstrează toate fluxurile distincte;
- auditul `service.dependency.create` include ID-ul concret al dependenței și detaliile fluxului;
- fără migrare DB și fără update de agent.

## 0.20.24

- transformă prima pagină într-un dashboard operațional: căutare globală, KPI-uri de atenție, listă de lucru, modificări recente, stare colectări/sincronizări, acoperire, HA și servicii cu lipsuri;
- căutarea globală găsește VM-uri după nume/hostname/IP, servicii, persoane, containere Docker, instanțe/cataloguri DB și configurații Web/LB și navighează direct la contextul relevant;
- KPI-urile sunt clickabile și deschid liste prefiltrate pentru agenți offline, inventar vechi, backup, monitorizare și documentație incompletă;
- „Necesită atenție” permite filtrare rapidă pe Agent, Backup, Monitorizare, Documentație și HA și afișează serviciile, responsabilii și ultima colectare;
- „Grad de acoperire” arată procentul pentru servicii asociate, responsabili, backup, monitorizare, baseline, fișe VM și fișe servicii;
- dashboardul evidențiază grupurile HA cu noduri problematice sau diferențe de volum ale resurselor Docker/DB/Web și serviciile care necesită completări;
- Rapoarte → Lipsuri operaționale acceptă filtrul agregat „Documentație incompletă”, iar linkurile din dashboard pot deschide direct filtrul dorit;
- nu adaugă migrare DB și nu necesită update de agent.

## 0.20.23

- face auditul lizibil: resursele cunoscute sunt afișate cu nume și context (VM/servicii) în loc de identificatori tehnici izolați precum `docker_container #677`; ID-ul rămâne vizibil pentru diagnostic;
- adaugă fila **Audit** direct în fișa VM și în fișa Serviciului intern, cu filtre după căutare, zonă, actor, sursă, acțiune, tip resursă, rezultat și interval de timp;
- auditul VM include evenimentele resurselor Docker, DB, Web, software, modificărilor de inventar, documentelor și agentului care pot fi corelate cu VM-ul;
- auditul Serviciului include evenimentele directe și resursele Docker/DB/Web/documente/anexe asociate; pentru noile modificări de asociere se păstrează uniunea serviciilor înainte/după astfel încât și eliminările să rămână regăsibile;
- adaugă în **Rapoarte → Persoane & responsabilități** relația Persoană → VM → rol → mediu → servicii, cu filtre și export Excel;
- adaugă **Rapoarte → Lipsuri operaționale** pentru VM fără responsabil, serviciu, mediu, agent/inventar actual, backup, monitorizare, baseline sau fișă VM, cu filtre și export Excel;
- nu adaugă migrare DB și nu necesită update de agent.

## 0.20.22

- curăță istoricul de modificări VM de câmpurile volatile din NTP/chrony (`tracking_summary` și starea runtime per peer);
- `node_exporter` nu mai generează modificări pentru `metrics_checked_at`, `metric_sample_count`, reachability/status HTTP sau erori de probe;
- regulile nftables sunt comparate semantic: contoarele `packets/bytes` și `# handle` sunt ignorate, dar schimbările reale de regulă rămân detectate;
- în Detalii, modificările afișează întâi câmpurile care diferă (`Anterior` / `Nou`), iar JSON-ul complet rămâne disponibil separat;
- fără migrare DB și fără update de agent.

## 0.20.21

- buton „Sincronizează acum Docker / DB / Web” pe VM-urile care moștenesc resurse dintr-un nod sursă HA/cluster;
- sincronizarea manuală folosește inventarul tehnic deja normalizat și raportează resurse potrivite/nepotrivite; resursele nou descoperite continuă să se sincronizeze automat la Colect;
- mesajul de moștenire din partea de sus a VM → Configurare primește margini/padding vizual stânga-dreapta și spacing mai bun pe mobil;
- fără migrare DB și fără update de agent.

## 0.20.20

- extinde moștenirea HA / cluster la documentarea și asocierile resurselor Docker, baze de date și Web, fără copierea inventarului tehnic;
- propagă proiect/serviciu, mediu, status, tip soluție, componentă, rol, observații și marcajele de documentare numai către resurse potrivite univoc;
- sincronizează automat la activarea relației, după modificări pe sursă și după inventare noi ale sursei sau membrului;
- blochează editarea locală Docker/DB/Web pe membru cât timp moștenirea resurselor este activă;
- adaugă padding suplimentar în zona VM → Configurare;
- migrare DB `054_vm_resource_inheritance.up.sql`; fără update de agent.

## 0.20.19

- adaugă ștergere definitivă pentru proiecte/servicii interne, cu impact afișat înainte de confirmare; serviciile globale implicite sunt protejate până la dezactivarea explicită a marcajului global;
- adaugă **Comasează proiectul**: asocierile VM, rolurile, Docker, baze de date, Web/LB, dependențele, conexiunile externe, documentele și anexele sunt mutate în proiectul destinație, iar sursa este eliminată;
- adaugă documentație comună pentru perechi HA și clustere: un VM membru poate moșteni serviciile/configurarea arhitecturală și datele operaționale comune de la un VM sursă;
- propagă automat modificările ulterioare făcute pe VM-ul sursă către membrii care au moștenirea activă; datele tehnice individuale (hostname, IP, UUID, agent, CPU/RAM, discuri, backup și monitorizare) rămân locale;
- fișele VM DOCX/Markdown indică grupul HA/cluster și sursa documentației comune;
- la dezactivarea moștenirii, valorile deja copiate rămân pe membru și pot fi editate local;
- migrare DB `053_vm_documentation_inheritance.up.sql`; fără update de agent.

## 0.20.18

- generalizează `internal_service_dependencies`: orice serviciu activ poate depinde de orice alt serviciu activ, nu doar de infrastructura comună;
- permite mai multe relații între aceeași pereche de servicii în funcție de `mediu sursă → mediu destinație`;
- adaugă pe relație criticitate (`Informativă`, `Normală`, `Critică`), protocol, port, observații și stare activă;
- pagina Serviciului are în fila Dependențe două sensuri explicite: `Depinde de` și `Este utilizat de`; relația se declară o singură dată;
- relațiile pot fi activate/dezactivate fără ștergere, iar ștergerea definitivă rămâne disponibilă;
- fișele Serviciu DOCX/Markdown includ dependențele active cu medii, criticitate și endpoint; analiza `Este utilizat de` funcționează și pentru servicii care nu sunt comune;
- serviciile comune/globale și dependențele directe VM rămân compatibile cu modelul existent;
- migrare DB `052_general_service_dependencies.up.sql`; fără update de agent.

## 0.20.17

- UI: toate tabelele cu antet pot fi sortate la click pe coloană.
- Sortare ascendentă/descendentă cu indicator vizual și suport tastatură.
- Comparatorul recunoaște text, numere, procente, dimensiuni, date și valori naturale precum versiuni/IP-uri.
- Coloanele de acțiuni/checkbox sunt excluse automat; rândurile de detaliu Audit rămân atașate evenimentului.

## 0.20.16

- leagă procentul de completare al VM-ului de proiectele/serviciile selectate în Docker, Baze de date și Web;
- pentru fiecare serviciu intern distinct folosit de aceste resurse se adaugă un criteriu separat `Configurare serviciu: <nume>`;
- criteriul este satisfăcut numai dacă aceeași VM are serviciul configurat și în `Configurare servicii` cu domeniu, categorie, layer, rol tehnic și tip soluție;
- același serviciu folosit de mai multe containere, baze sau site-uri este numărat o singură dată;
- în fila Servicii apare un avertisment cu proiectele detectate în Docker/DB/Web care lipsesc din asocierile VM–serviciu;
- fără migrare DB și fără update de agent.

## 0.20.15

- adaugă în Inventar → Servicii marcajul persistent `Servicii verificate`, pentru a confirma că operatorul a trecut prin categoria serviciilor agentului;
- pe Linux/non-Windows, criteriul `Serviciu software principal` este satisfăcut dacă există cel puțin un serviciu marcat `Principal` **sau** dacă este bifat `Servicii verificate`;
- fără serviciu `Principal` și fără confirmarea de verificare, criteriul continuă să penalizeze procentul de completare;
- marcajul este salvat independent de snapshotul de inventar și este auditat prin `vm.agent_services_review.update`;
- adaugă migrarea `051_vm_documentation_reviews.up.sql`; nu necesită update de agent;
- aliniază testul exportului VM la cele 22 de coloane introduse în 0.20.14 prin coloana `Baseline`.

## 0.20.14

- separă regulile de completare după sistemul de operare: pe Windows este obligatoriu cel puțin un software marcat Principal, fără a cere selectarea serviciilor agentului; pe Linux rămân obligatorii serviciul intern documentat și cel puțin un serviciu software/daemon marcat Principal;
- păstrează criteriul Port / proces principal pentru VM-urile cu inventar atât pe Windows, cât și pe Linux;
- adaugă starea Baseline (Da/Nu) în obiectul VM, cardul din fișa VM, filtrul inventarului VM și exportul Excel;
- filtrul Baseline este aplicat identic la listare și export.

## 0.20.13

- Layout compact 2×2 pentru asocierea resurselor Docker / DB / Web și mutarea `Nu necesită documentare` deasupra asocierii.
- Recalculare live, debounced, a procentului de completare după documentare și selecțiile `Principal`.
- Recalcularea nu reîncarcă întreaga fișă VM și ignoră răspunsurile stale după navigare.

# Changelog

## 0.20.12

- recalculă procentul de completare pe fiecare resursă Docker, DB și Web, nu doar pe categorie;
- `Nu necesită documentare` satisface explicit criteriul resursei și actualizează imediat procentul;
- include în completare selectarea serviciilor software și porturilor/proceselor principale din inventar;
- adaugă cardul `IP principal` în antetul fișei VM și butoanele `Test` / `Colect` direct în Inventar;
- normalizează rezultatul `partial` la `success` când singurele colectoare ne-success sunt nesuportate/omise/neaplicabile și nu există fail/error/timeout;
- repară suprapunerea controalelor Serviciu / Mediu / Status / Tip soluție / Asociază;
- protejează fișa VM și routerul împotriva răspunsurilor stale la clickuri foarte rapide;
- fără migrare DB și fără update de agent.


## 0.20.11

- finalizează curățarea server-side a valorilor de versiune în fișele DOCX și exporturile Markdown;
- elimină `Warning:` / `[Warning]` și din `package_version`, software instalat principal, sumarul DB, Docker și fallback-urile generice ale inventarului;
- normalizează în continuare MySQL/MariaDB `mysql Ver 14.14 Distrib 5.5.37` la `5.5.37`;
- adaugă teste de regresie care verifică explicit că warning-urile nu ajung în corpul DOCX sau Markdown;
- fără migrare DB și fără update de agent.

## 0.20.10

- elimină din afișare liniile `Warning:` / `[Warning]` ajunse în câmpurile de versiune raportate de agent;
- normalizează MySQL/MariaDB astfel încât `mysql Ver 14.14 Distrib 5.5.37` să fie afișat ca `5.5.37`, nu `14.14`;
- aplică aceeași curățare în inventarul structurat, lista de servicii principale și documentele DOCX/Markdown;
- schimbarea este exclusiv în vm-doc-server; nu necesită update de agent și nu modifică schema DB.


## 0.20.9

- redenumește documentul generat pentru serviciu în **Fișă tehnică și operațională a serviciului**;
- redenumește documentele DOCX atașate în **Proceduri operaționale și fluxuri de lucru**;
- păstrează procedurile la final ca anexe B1/B2…, după anexele VM A1/A2…;
- aliniază DOCX, Markdown, UI, audit și OpenAPI la noua terminologie;
- normalizează la randare titlul vechi din șabloanele service existente;
- migrarea `050_service_document_terminology.up.sql` redenumește metadatele șablonului implicit `service.standard`; fără schimbare de schemă și fără update de agent.

## 0.20.8

- hotfix pentru deschiderea fișei unui Serviciu atunci când serviciul are Site-uri Web asociate;
- `webinventory.ListForService` selectează acum și `ws.documentation_exempt`, în acord cu lista de destinații `Scan`;
- elimină eroarea SQL `expected 20 destination arguments in Scan, not 21` care era returnată ca HTTP 500 de `GET /api/v1/services/{id}`;
- fără migrare DB și fără update de agent.

## 0.20.7

- fișele DOCX permit rândurilor lungi din tabele să se împartă natural între pagini; se elimină `w:cantSplit` din rândurile de date și din cardurile VM, păstrând header-ele repetabile;
- corectează în special tabelele cu multe Site-uri Web, DB, Docker, servicii, porturi și alte inventare: conținutul continuă pe pagina următoare de la poziția rămasă;
- documentația DOCX suplimentară încărcată pe serviciu este mutată din capitolul 2 la finalul fișei, ca anexă B1/B2/etc., după anexele A* ale fișelor VM;
- exportul Markdown păstrează aceeași ordine logică, cu documentația suplimentară la final;
- fără migrare DB și fără update de agent.

## 0.20.6

- corectare corelare Prometheus pentru targeturi FQDN care au alias scurt în `/etc/hosts` al serverului Prometheus;
- `/etc/hosts` este consultat înaintea fallback-ului pe hostname scurt, evitând blocarea pe un hostname ambiguu;
- matching-ul prin `/etc/hosts` preferă IP-urile guest curente din vCenter și folosește IP-urile inventarului agentului doar ca fallback;
- teste de regresie pentru `ns2.stsnet.ro:9100` → `ns2` → `172.20.9.100` și VM cu mai multe IP-uri;
- fără migrare DB și fără update de agent.

## 0.20.5

- adaugă `Nu necesită documentare` la nivelul fiecărui container Docker, catalog/bază logică și site/configurație Web; marcajele sunt persistente și nu sunt suprascrise la resync;
- păstrează și controalele coarse existente pentru Docker host, instanță DB și server Web, dar aliniază toate checkbox-urile de documentare într-o coloană dedicată;
- resursele marcate sunt excluse din fișele VM/serviciu și din calculul completitudinii documentației, fără a fi șterse din inventar;
- fișa VM unește `Principal` cu `Utilizare` pe două rânduri, elimină coloana `Pachet` din componentele software, concatenează detaliile port/proces și persoană/departament și elimină `Indicatori` din tabelul containerelor;
- exportul Markdown al anexelor VM folosește aceleași structuri de tabel ca DOCX pentru Sistem/OS/Stocare/Rețea/Servicii/Porturi/Firewall/Conturi/SSSD/Integrări/Politici/Cron/NTP și aplică aceleași filtre;
- corectează testul `buildVMWhere` pentru cele 17 argumente de căutare după introducerea IP-ului principal preferat;
- migrare DB `049_resource_documentation_exempt.up.sql`; nu necesită update de agent.

## 0.20.4

- redenumește `Data generării` în `Data referință` și permite ascunderea câmpului `Generat de` la generarea fișelor VM și serviciu;
- adaugă IP principal documentație și RPO/RTO în Date operaționale; IP-ul preferat este folosit în liste și fișe;
- adaugă `Nu necesită documentare` pentru Docker, instanțe DB și engine-uri Web; resursele exceptate rămân în inventar, dar sunt excluse din completitudine și documentație;
- normalizează cazul Node Exporter activ dar nedetectat ca instalat și scurtează versiunile tehnice la versiunea utilă;
- lărgește tabelele DOCX, elimină fraza automată de la final și permite blocurilor descriptive ale serviciului să curgă natural între pagini;
- completează exportul Markdown cu inventarul agentului și îmbunătățește conversia DOCX suplimentar → Markdown (paragrafe, headings, liste, bold/italic, tabele);
- migrare DB `048_documentation_controls.up.sql`; fără update de agent.

## 0.20.3

- corectează exportul Markdown pentru Outline când este bifată opțiunea `Lipește anexele A1, A2… în același document`;
- anexele VM sunt acum incluse efectiv în fișierul `.md`, nu doar listate ca linkuri/referințe;
- fiecare anexă este randată ca secțiune `A1`, `A2` etc. și include toate secțiunile disponibile ale fișei VM (identificare, încadrare, servicii, dependențe, software, Docker/DB/Web, backup, monitorizare și inventar agent);
- exportul Markdown nu generează și nu salvează o fișă VM nouă în baza de date; folosește datele curente ale VM-ului;
- fără migrare DB și fără modificări de agent.

# Changelog

## 0.20.12

- recalculă procentul de completare pe fiecare resursă Docker, DB și Web, nu doar pe categorie;
- `Nu necesită documentare` satisface explicit criteriul resursei și actualizează imediat procentul;
- include în completare selectarea serviciilor software și porturilor/proceselor principale din inventar;
- adaugă cardul `IP principal` în antetul fișei VM și butoanele `Test` / `Colect` direct în Inventar;
- normalizează rezultatul `partial` la `success` când singurele colectoare ne-success sunt nesuportate/omise/neaplicabile și nu există fail/error/timeout;
- repară suprapunerea controalelor Serviciu / Mediu / Status / Tip soluție / Asociază;
- protejează fișa VM și routerul împotriva răspunsurilor stale la clickuri foarte rapide;
- fără migrare DB și fără update de agent.


## 0.20.2

- adaugă exportul fișei serviciului intern în Markdown, pregătit pentru import/paste manual în Outline sau alt wiki;
- nou buton **Markdown pentru Outline** în panoul de generare al serviciului;
- păstrează structura logică a fișei DOCX: identificare, descriere/scop/obiective, medii, dependențe, clasificări, componente, DB/Docker/Web, backup, monitorizare, VM-uri și anexe;
- convertește rich-text-ul serviciului în Markdown (bold, italic, liste; underline este păstrat prin tag HTML `<u>`);
- documentația suplimentară Word este inclusă în export prin textul extras, iar anexele VM sunt listate A1/A2… cu link către fișa existentă atunci când `base_url` este configurat;
- exportul Markdown este download direct `.md`, nu creează o versiune nouă în istoricul documentelor și nu necesită migrare DB sau update de agent.

## 0.20.1

- adaugă la generarea fișei serviciului opțiunea **Lipește anexele A1, A2… în același document**; fișele VM pot fi integrate în DOCX, fiecare pe pagină nouă, independent de pachetul ZIP;
- documentația suplimentară DOCX încărcată pe serviciu este inserată în capitolul 2 prin `altChunk`, pentru păstrarea formatării originale Word, inclusiv tabele, liste și imagini;
- din capitolul `VM-uri asociate` elimină coloana `Fișă VM`;
- din `Monitorizare` elimină coloanele `Versiune`, `Targets` și `Probe`;
- din `Backup și restaurare` elimină coloanele `Job` și `Storage`;
- normalizează afișarea mediului la codurile uppercase `PROD`, `TEST`, `DEV` în UI și documente;
- nu introduce migrare DB și nu necesită update de agent.

## 0.20.0

- adaugă `Tip soluție` din nomenclator pe asocierile manuale Docker, baze de date și Web;
- extinde Detalii serviciu cu `Descriere scurtă`, `Autentificare`, `Link serviciu` și `Tehnologii folosite`;
- adaugă `Documentație suplimentară a serviciului`: upload/download/delete DOCX, cu importul textului în capitolul 2 al fișei;
- redenumește în interfață și fișe `Număr document` în `Număr electronic document`;
- fișa serviciului pune numele serviciului în titlu și îl elimină din tabelul de identificare; tabelul include noile câmpuri de identificare;
- descrierea detaliată continuă să fie rich-text și este redată formatat în fișă;
- capitolul 3 listează VM-urile pe rând, nu grupate cu virgulă;
- elimină coloana `VM-uri furnizor` din dependențe și servicii comune;
- fișele tehnice VM sunt prezentate la final ca Anexe și pot fi incluse în pachetul ZIP;
- documentele generate folosesc Arial 12 pentru text normal, inclusiv peste șabloane DOCX personalizate;
- migrare DB `047_service_documentation_enrichment.up.sql`; nu necesită update de agent.

## 0.19.16

- normalizează inventarul `software.items` raportat de vm-doc-agent 1.7.2;
- adaugă fila VM `Software instalat`, cu căutare/filtre, export Excel și selecție persistentă `Principal`;
- fila apare numai când există inventar software raportat, deci în prezent în mod normal doar pentru VM-uri Windows;
- fișa VM include numai aplicațiile marcate Principal; selecțiile rămân vizibile și când software-ul nu mai este detectat;
- marcajul Principal supraviețuiește upgrade-urilor de versiune ale aceleiași aplicații;
- migrare DB `046_software_inventory.up.sql`.

## 0.19.15

- ascunde din UI și documentația VM/serviciu bazele marcate ca sistem (`postgres`, `template0`, `template1`, `mysql`, `information_schema`, `performance_schema`, `sys`, respectiv MongoDB `admin/config/local`), păstrându-le în inventarul brut și în stocarea normalizată;
- cardul `Baze aplicație` și `catalog_count` din vederea VM numără numai bazele non-system;
- Rezumatul VM avertizează când este detectat un engine/instanță DB dar enumerarea bazelor nu a reușit și afișează motivul secret-safe raportat de agent;
- asocierile manuale pentru Baze de date, Docker și Web includ acum `Mediu` și `Status operațional` din nomenclatoare, per componentă;
- asocierile existente rămân compatibile prin câmpuri nullable, iar UI cere contextul operațional la asocierile manuale noi;
- fișele VM și serviciu includ mediul/statusul pe asocierile DB/Docker/Web;
- migrare DB `045_component_assignment_context.up.sql`; recomandat cu vm-doc-agent 1.6.11 pentru PostgreSQL 8/9 multi-instance.

## 0.19.14

- persistă metadata joburilor PostgreSQL programate raportate de vm-doc-agent 1.6.10 (`pgAgent` / `pg_cron`) fără SQL/comenzi/scripturi;
- VM → Baze de date afișează numărul și starea discovery-ului joburilor per instanță și un tabel separat `Joburi programate PostgreSQL`;
- afișează mai clar instanțele PostgreSQL multi-instance, inclusiv data directory, endpoint și socket;
- fișa VM include metadata joburilor PostgreSQL și starea discovery-ului lor;
- fișa serviciului include numărul de joburi pe resursa DB și un tabel deduplicat cu joburile relevante;
- adaugă motivele `maintenance_database_missing` și `user_switch_unavailable` în UI/documentație;
- migrare DB `044_database_scheduled_jobs.up.sql`; recomandat cu vm-doc-agent 1.6.10 (schema 2.7).

## 0.19.13

- adaugă `386 (i386/i686)` în selectorul de arhitectură din Agenți → Release-uri agent și în filtrul repository;
- repository-ul existent este deja multi-arhitectură: cheia release-ului include canal + OS + arch + versiune, iar endpointul latest selectează exact arhitectura cerută de agent;
- documentează publicarea în paralel a binarelor `linux/amd64` și `linux/386` pentru vm-doc-agent 1.6.8;
- fără migrare DB; backend-ul de update nu necesită schimbare de schemă.

## 0.19.12

- folosește clasificarea serviciilor raportată de vm-doc-agent 1.6.7 (`system` / `application` / `unknown`);
- VM → Inventar → Servicii afișează implicit numai servicii active de aplicație + necunoscute și oferă filtru pentru serviciile OS;
- serviciile marcate `Principal` rămân vizibile indiferent de filtrul de clasificare/stare;
- fișa VM omite din `Servicii active` numai serviciile clasificate explicit `system`; serviciile `application`, `unknown` și snapshoturile vechi rămân documentate;
- păstrează clasificarea și motivul în metadatele serviciilor principale;
- fără migrare DB; necesită vm-doc-agent 1.6.7 pentru clasificare, dar rămâne compatibil cu agenți mai vechi.

## 0.19.11

- include Monitorizarea în fișa VM: stare generală, Node Exporter, targeturi Prometheus metrics și probe Blackbox, inclusiv stare, corelare, HTTP/durată/TLS unde sunt disponibile;
- include Monitorizarea agregată în fișa serviciului, pe VM-urile asociate;
- curăță afișarea Firewall în UI și DOCX: când există un manager high-level (UFW/firewalld/SuSEfirewall2), regulile tehnice nftables/iptables/ip6tables generate dedesubt nu mai sunt afișate;
- păstrează politicile implicite ca rezumat și zonele firewalld, iar pe hosturile care folosesc direct nftables/iptables regulile rămân documentate;
- nu modifică schema bazei de date și nu necesită upgrade de agent sau collector; versiunea recomandată de agent rămâne 1.6.6.

## 0.19.10

- persistă `catalog_discovery_reason` raportat de vm-doc-agent 1.6.5 pentru instanțele de baze de date;
- afișează în VM → Baze de date motivul pentru `metadata only` (autentificare, permisiuni, socket/server indisponibil, client lipsă, timeout etc.);
- include motivul și în fișa DOCX a VM-ului;
- urmărește schimbarea motivului în Modificări inventar;
- migrare DB nouă `043_database_catalog_discovery_reason.up.sql`.

## 0.19.9

- standardizează filtrele și paginarea: selecturile din zonele de filtrare rămân native, stabile și nu mai folosesc dropdown-ul searchable cu portal;
- lista VM afișează și procentele pentru prezența în vCenter, lipsă și asocierea cu agent;
- Backup este separat în taburile `Backup` și `Surse & sincronizări`, iar lista VM Veeam primește export Excel filtrat;
- Monitorizare păstrează filtrele într-un layout stabil și adaugă export Excel filtrat pentru VM-uri și targeturi;
- catalogul Servicii primește paginare, export Excel și elimină coloana cu butoanele `Deschide` / `Editează`; numele serviciului rămâne linkul de navigare;
- `Descriere` serviciu devine rich-text, inclusiv la creare, este păstrată separat în DB și este redată cu formatare în fișa DOCX;
- Conectivitate externă și Rețele externe folosesc secțiuni `Adaugă` colapsate, iar formularele/conexiunile primesc padding consistent;
- filtrele Agenți sunt reașezate în aceeași grilă responsive folosită în restul aplicației;
- migrare DB: `042_service_description_rich_text.up.sql`; agentul și collectorul nu se modifică.

## 0.19.8

- mută editarea serviciului intern în pagina lui de detaliu, în același model ca fișa VM;
- `Detalii` are subtabs `General`, `Descriere`, `Scop și domeniu` și `Obiective`, fiecare editabil direct și cu salvare proprie;
- formularul modal vechi rămâne numai pentru crearea unui serviciu nou; butonul `Editează` din catalog deschide fișa serviciului, nu modalul;
- reconstruiește filtrele din lista Servicii pe layout-ul aerisit folosit la VM, cu listbox-uri încadrate în grid, zonă separată de acțiuni și filtre active;
- elimină suprapunerile dintre listbox-uri și butoanele filtrării la lățimi intermediare;
- nu modifică schema DB și nu necesită upgrade de agent sau collector.

## 0.19.7

- reorganizează pagina detaliu a serviciului intern pe taburi, în același model vizual ca fișa VM;
- adaugă zonele Rezumat, Detalii, Arhitectură, Componente, Dependențe și Documentație, cu subtabs pentru zonele complexe;
- mută vizual toate informațiile administrate din formularul „Editează serviciul” în tabul Detalii;
- păstrează butonul Editează în contextul tabului Detalii și revine pe aceeași secțiune după salvare;
- adaugă navigare directă prin hash-uri `#services/<id>/<secțiune>`;
- nu modifică schema DB și nu necesită upgrade de agent.

## 0.19.6

- în `VM → Inventar → Porturi ascultate`, porturile/procesele pot fi marcate persistent ca **Principale**;
- identitatea selecției este `protocol + port + process_name`, fără PID, astfel încât persistă după restarturi;
- fișa VM adaugă **Porturi și procese principale** cu port, protocol, proces, PID curent, executabil, adresă de listen și stare;
- selecțiile dispărute din inventarul curent rămân vizibile ca `Nedetectat`, până la demarcare;
- secțiunea separată **Politici** este eliminată din fișa VM; politicile implicite ale firewall-ului rămân în capitolul Firewall;
- migrare DB: `041_vm_primary_agent_ports.up.sql`; agentul și collectorul nu se modifică, `vm-doc-agent` rămâne 1.6.3.

## 0.19.5

- reorganizare UI VM: `Inventar VM` separat de `Surse & sincronizări`;
- fișa VM are meniu principal pe zone funcționale și subtabs locale;
- filtre VM aerisite și rezumat al filtrelor active;
- listbox-uri searchable stabilizate: portal, direcție blocată, săgeată CSS și padding constant;
- chevron uniform pentru selecturile native;
- padding și spațiere îmbunătățite inclusiv în VM → Monitorizare;
- fără migrare DB; agentul rămâne 1.6.3.

## 0.19.4

- curățare definitivă pentru VM-uri dispărute din vCenter, fără introducerea unui flux nou de arhivare;
- filtru `vCenter` pentru prezente/lipsă și afișarea `missing_since`;
- ștergere individuală și bulk, maximum 200 VM-uri per operație;
- ștergerea este permisă numai pentru `present_in_vcenter=0` și este tranzacțională;
- preview de impact înainte de delete: servicii, documente, monitorizare, backup, conexiuni externe, responsabilități și schimbări;
- targeturile de monitorizare sunt decorelate, nu șterse; agentul asociat nu este șters;
- audit `vm.delete.permanent`;
- fără migrare DB nouă; agentul rămâne `vm-doc-agent 1.6.3`.

## 0.19.3

- vCenter sincronizează toate adresele IPv4 guest raportate de `/guest/networking/interfaces`, nu doar `guest/identity.ip_address`;
- adresele sunt păstrate în `vcenter_vm_ips`; setul complet este înlocuit numai când endpointul guest networking răspunde cu succes;
- corelarea Prometheus/Blackbox folosește și IP-urile secundare vCenter, inclusiv pentru VM-uri fără agent;
- pagina VM → Monitorizare afișează IP-urile vCenter folosite la corelare;
- Monitorizare este împărțită în două pagini: **Stare monitorizare** și **Surse & sincronizări**;
- formularul Prometheus este mărit și împărțit pe secțiuni, iar filtrele/paddingurile din Monitorizare și din fila VM au fost aerisite;
- migrare DB: `040_vcenter_vm_guest_ips.up.sql`; agentul rămâne `vm-doc-agent 1.6.3`.

## 0.19.2

- sursa Prometheus poate fi asociată explicit cu un agent vm-doc;
- UI oferă selectorul „Agent asociat” la creare/editare;
- serverul citește `hosts.entries` din inventarul curent al agentului asociat;
- corelarea devine label → FQDN → hostname → IP → Prometheus `/etc/hosts` → alias manual;
- metoda de corelare este salvată ca `prometheus_hosts` cu valoarea `alias -> IP`;
- Test Prometheus raportează și disponibilitatea / numărul de intrări hosts;
- migrare DB: `039_prometheus_source_agent_hosts.up.sql`;
- necesită vm-doc-agent 1.6.3 pe serverele Prometheus pentru corelarea prin hosts.

## 0.19.1
- separă targeturile `metrics` de `blackbox` chiar când ambele surse folosesc același Prometheus;
- identifică Blackbox după `/probe`, `__metrics_path__` și `__param_target`, fără dependență de numele jobului;
- Test raportează numărul de targeturi filtrat după tipul sursei;
- clientul Prometheus ocolește proxy-ul de mediu (`Proxy: nil`);
- următorul Sync marchează automat `present=0` rândurile importate greșit de 0.19.0, fără migrare DB.

# Changelog

## 0.20.12

- recalculă procentul de completare pe fiecare resursă Docker, DB și Web, nu doar pe categorie;
- `Nu necesită documentare` satisface explicit criteriul resursei și actualizează imediat procentul;
- include în completare selectarea serviciilor software și porturilor/proceselor principale din inventar;
- adaugă cardul `IP principal` în antetul fișei VM și butoanele `Test` / `Colect` direct în Inventar;
- normalizează rezultatul `partial` la `success` când singurele colectoare ne-success sunt nesuportate/omise/neaplicabile și nu există fail/error/timeout;
- repară suprapunerea controalelor Serviciu / Mediu / Status / Tip soluție / Asociază;
- protejează fișa VM și routerul împotriva răspunsurilor stale la clickuri foarte rapide;
- fără migrare DB și fără update de agent.


## 0.19.9

- standardizează layout-ul filtrelor și dezactivează listbox-urile searchable custom în zonele de filtrare/paginare, pentru a elimina suprapunerile și poziționările instabile;
- VM: cardurile de inventar afișează și procentele pentru prezență vCenter, lipsă și acoperire agent;
- Backup: separă pagina în taburile `Backup` și `Surse & sincronizări`, adaugă Export Excel pentru lista filtrată;
- Monitorizare: aliniază filtrele cu restul aplicației și adaugă Export Excel separat pentru VM-uri și targeturi;
- Servicii: adaugă paginare configurabilă, Export Excel, elimină coloana/butoanele Deschide/Editează și face Descrierea rich-text persistentă;
- Conectivitate externă: formularele de adăugare sistem/rețea sunt colapsate implicit, iar editarea conexiunilor primește padding și spacing consistent;
- Agenți: filtrele sunt rearanjate pe layout-ul comun.
- migrare DB nouă `042_service_description_rich_text.up.sql`.

## 0.19.0

- adaugă fundația de monitorizare read-only pentru surse **Prometheus metrics** și **Prometheus Blackbox**;
- meniu nou **Monitorizare** cu surse configurabile, Test, Sync manual/global, scheduler și istoric paginat;
- sincronizează targeturile active prin API-ul Prometheus fără a duplica seriile de metrici în MariaDB;
- corelează targeturile cu VM-urile în ordinea: label explicit configurabil (implicit `vm_fqdn`) → FQDN → hostname → IP → alias manual;
- suportă joburi Prometheus care folosesc IP, FQDN sau hostname rezolvat local pe serverul Prometheus, inclusiv prin `/etc/hosts`;
- folosește inventarul agentului 1.6.2 pentru starea Node Exporter: instalat, service activ, versiune și endpoint;
- pentru sursele Blackbox citește `probe_success`, codul HTTP, durata probei și expirarea certificatului TLS;
- adaugă fila **Monitorizare** în pagina VM cu Node Exporter, targeturi Prometheus/Blackbox și aliasuri manuale;
- pagina globală afișează VM monitorizate/nemonitorizate, exporter fără target, targeturi DOWN, corelate/necorelate și filtre după power state;
- migrare nouă `038_prometheus_monitoring_foundation.up.sql`; agentul rămâne `vm-doc-agent 1.6.2`; integrarea Grafana este lăsată intenționat pentru etapa următoare după validarea Prometheus/Blackbox.

## 0.18.3

- citește VM-urile configurate direct în joburile Veeam din `virtualMachines.includes`, nu doar obiectele care au deja backup/restore point;
- separă starea `În job Veeam` de existența unui backup utilizabil: VM-urile nou adăugate apar imediat ca `Așteaptă primul backup`;
- detectează cazul invers: restore point existent, dar VM-ul nu mai este inclus direct într-un job (`Backup existent · în afara jobului`);
- pentru VM-urile configurate înainte de primul backup afișează deja jobul, repository-ul, programarea, retenția/GFS și `Next run` când sunt raportate de Veeam;
- pagina Backup adaugă filtre și carduri pentru `În job`, `Așteaptă primul backup` și `Backup în afara jobului`; cardurile rămân sensibile la filtre;
- întărește compatibilitatea 0.18.2: repară DSN-ul UTC, default-ul `cron_backup_notes` și INSERT-urile de sync/cron pentru instalări curate și upgrade-uri existente;
- migrare nouă `037_veeam_job_membership.up.sql`; agentul rămâne 1.6.2.

## 0.18.2

- citește din Veeam definițiile joburilor, programarea, retenția și politicile GFS Weekly / Monthly / Yearly;
- diferențiază storage-ul primar de storage-ul secundar (backup copy) și afișează ambele în UI și documente;
- cardurile din pagina Backup se recalculează după căutare și filtre, iar filtrarea include power state;
- adaugă backup cron/script local documentabil per VM; cron-urile raportate de agent pot fi selectate direct, iar backupul apare în tabul Backup și în fișele VM/serviciu;
- compactează listboxurile din filtrarea Backup;
- normalizează conexiunile MariaDB la UTC și expune timezone-ul aplicației către UI; timezone implicit: Europe/Bucharest.

## 0.18.1

- corectează corelarea ID-urilor Veeam pentru backup/job (case-insensitive și compatibilă cu UUID-uri între acolade), astfel încât să fie populate `Job`, `Repository`, `Last result` și `Next run`;
- păstrează Test-ul Veeam compatibil cu rolul **Backup Viewer**, fără apel la `serverInfo`;
- acceptă răspunsurile VBR 12.1 în care `platformName` nu este întotdeauna string;
- îmbunătățește pagina **Backup** cu filtre separate pentru protecție, power state și rezultat, plus căutare și paginare;
- adaugă card **Toate VM-urile** și procente pentru protejate, neprotejate și neverificate;
- adaugă fila **Backup** în pagina VM, cu sumar și detaliile Veeam ale lanțurilor de backup/restore point;
- include backupurile VM-urilor și în fișa DOCX a serviciului intern; fișa VM continua să includă secțiunea Backup;
- intervalul implicit pentru sursele Veeam noi devine 1440 minute (o dată pe zi); sursele existente își păstrează intervalul configurat;
- nu adaugă migrare DB și nu necesită update de agent (`vm-doc-agent 1.6.2`).

## 0.18.0

- adaugă integrare read-only cu **Veeam Backup & Replication** prin REST API;
- meniu nou **Backup** cu surse Veeam, Test conexiune, sincronizare manuală/globală și istoric paginat al sincronizărilor;
- parolele surselor Veeam sunt criptate cu cheia master a serverului și nu sunt returnate prin API;
- corelează obiectele Veeam cu VM-urile din vm-doc după **numele exact** al VM-ului;
- populează automat `vm_backup_summary` cu job, repository, ultimul rezultat, ultimul backup/restore point, următoarea rulare și numărul de restore points;
- scheduler per sursă, implicit la 360 minute (6 ore), cu stare și ultima eroare;
- migrare nouă `034_veeam_backup_integration.up.sql`; nu necesită update de agent, `vm-doc-agent 1.6.2` rămâne compatibil.

## 0.17.2

- introduce baseline pentru meniul Modificări, global și per VM;
- la upgrade, inventarul curent devine automat baseline pentru VM-urile existente, evitând zgomotul inițial;
- modificările de dinaintea baseline-ului rămân păstrate pentru audit, dar nu mai apar în trierea curentă și nu afectează procentul de completare;
- VM-urile noi își stabilesc automat primul snapshot drept baseline înainte de urmărirea diferențelor;
- butoane noi „Stabilește inventarul curent ca baseline” global și „Stabilește baseline VM” în fila Modificări.

## 0.17.1

- corectează migrarea `032_inventory_changes.up.sql`: coloanele care referențiază chei `BIGINT UNSIGNED` sunt acum tot `BIGINT UNSIGNED`;
- repară pornirea pe MariaDB/MySQL unde 0.17.0 eșua cu `Error 1005 ... Foreign key constraint is incorrectly formed`;
- nu adaugă o migrare nouă și nu schimbă schema funcțională planificată pentru 0.17.0; migrarea 032 eșuată este reluată automat la pornire.

## 0.17.0

- adaugă meniul global **Modificări** și fila **Modificări** în fiecare VM;
- compară semantic snapshot-ul JSON nou cu snapshot-ul anterior și ignoră zgomotul volatil (timpi de colectare, uptime, durate, PID-uri/inode-uri);
- urmărește schimbări relevante pentru documentație: conturi locale, baze/instanțe DB, containere Docker, site-uri/frontends Web, servicii OS, porturi, firewall, rețea, stocare, SSSD, integrări, NTP, OS și hardware;
- fiecare diferență este clasificată `added`, `removed` sau `modified` și păstrează valorile anterioare/noi pentru verificare;
- adaugă triere manuală `Documentație`: `Nesetat` (implicit), `Necesită documentație`, `Nu necesită`, plus starea `Nou / Revizuit / Ignorat` și observații;
- pagina globală are filtre, paginare și indicatori; din VM se văd numai schimbările VM-ului respectiv;
- include acțiunea **Compară ultimele snapshot-uri** pentru popularea inițială după upgrade;
- migrare nouă `032_inventory_changes.up.sql`; agentul 1.6.1 rămâne compatibil și nu necesită update.


## 0.16.4

- stabilizează dropdown-urile searchable: elimină repoziționarea dublă la focus/click și recalculează poziția după fiecare filtrare, folosind înălțimea reală a listei;
- dropdown-ul rămâne ancorat de listbox când rezultatele filtrate schimbă înălțimea listei, inclusiv când lista este deschisă deasupra controlului;
- adaugă padding explicit mesajului Docker „nu este instalat” și informației despre ultima colectare.

## 0.16.3

- repară listbox-urile searchable care puteau fi tăiate de panel/table overflow: dropdown-ul este randat ca portal cu z-index ridicat și repoziționat la scroll/resize;
- adaugă padding suplimentar în detaliile Docker;
- elimină subsecțiunea goală „Schema inventar” și numerotează continuu subsecțiunile Inventar agent, fără goluri pentru secțiuni eliminate;
- indentează explicit Heading2 în DOCX, astfel încât 5.1 și toate subsecțiunile să fie vizual sub capitolul părinte;
- deduplică Porturi ascultate la o singură intrare per port/protocol, păstrând exemplul cu cele mai bune informații de proces/executabil;
- fără migrare SQL; vm-doc-agent 1.6.1 rămâne suficient.


## 0.16.2

- mută versiunea agentului lângă badge-ul de stare din lista VM și elimină coloana separată;
- adaugă căutare prin tastare pentru select-urile single-value din interfață;
- adaugă paginare server-side pentru ultimele sincronizări vCenter;
- îmbunătățește spațierea filelor Docker/DB/Web, previzualizarea fișei VM și panoul de conexiuni externe;
- repară tabelul de porturi din fișa VM folosind `processes[]` din inventarul agentului;
- generalizează secțiunea Firewall pentru nftables, iptables/ip6tables, firewalld, UFW și SuSEfirewall2;
- include corect utilizatorii locali non-system, inclusiv UID 1000.
- fără migrare SQL; agentul 1.6.1 este suficient.

## 0.16.1

- compactează cardurile din Rezumat VM, Docker, Baze de date și Web astfel încât pe desktop să ocupe un singur rând; repară fundalul deschis al cardurilor Docker Compose în tema dark;
- aerisește controalele de asociere serviciu în taburile Docker, Baze de date și Web;
- listarea VM afișează versiunea agentului și toate serviciile asociate, inclusiv cele provenite din containere Docker, baze/instanțe DB și site-uri Web; adaugă filtru după serviciu;
- simplifică sistemul de operare și power state în listare (`ON` / `OFF`) și elimină coloana vCenter din tabel;
- procentul de completare devine dinamic: VM-urile cu Docker/DB/Web primesc criterii suplimentare pentru asocierea resurselor la servicii, iar VM-urile fără aceste resurse nu sunt penalizate;
- criteriul „Serviciu documentat” este satisfăcut și de asocieri Docker/DB/Web, util pentru hosturile partajate care nu aparțin integral unui singur serviciu;
- fără migrare SQL nouă.

## 0.16.0

- adaugă inventar structurat pentru Nginx, Apache HTTP Server și HAProxy: servere, site-uri/virtual hosts/frontends, nume publice, bind-uri, document root, backend-uri și ținte proxy;
- adaugă relația many-to-many site Web → serviciu intern, independentă de VM → serviciu, pentru hosturi web partajate;
- pagina VM primește tabul `Web`, iar pagina serviciului agregă site-urile asociate de pe orice VM gazdă;
- îmbunătățește controalele de asociere în taburile Docker și Baze de date și folosește aceleași controale aerisite în Web;
- fișa VM omite automat capitolele Docker, Baze de date și Web când nu există date și renumerotează dinamic capitolele următoare;
- repară prefixul subsecțiunilor Inventar agent, eliminând situații de tipul capitol 9 urmat de 8.x;
- fișa serviciului include Web numai când există site-uri asociate și renumerotează dinamic capitolele opționale;
- migrare DB nouă `031_web_inventory.up.sql`; necesită `vm-doc-agent 1.6.0` pentru colectarea Web.

## 0.15.0

- adaugă inventar structurat pentru PostgreSQL, MySQL, MariaDB, MongoDB, Oracle Database, Microsoft SQL Server, IBM Db2, Redis, Firebird și CockroachDB;
- inventariază engine-uri, instanțe, endpoint-uri, versiuni, servicii/procese, directoare/config și, când accesul local fără credențiale permite, bazele logice;
- adaugă relații many-to-many instanță → serviciu și bază logică → serviciu, independente de relația VM → serviciu;
- pagina VM primește tabul `Baze de date`, iar pagina serviciului agregă bazele/instanțele asociate de pe orice VM gazdă;
- fișele DOCX de VM și serviciu includ secțiuni DB;
- importul acceptă statusurile collectorului `success` și `partial` și poate face backfill din snapshot-ul curent;
- migrare DB nouă `030_database_inventory.up.sql`; necesită `vm-doc-agent 1.5.0` pentru colectare.

## 0.14.1

- repară normalizarea inventarului Docker când collectorul agentului are status `partial`; `vm-doc-agent` marchează un collector `partial` pentru orice warning, chiar dacă payload-ul Docker este valid și conține engine/containere;
- păstrează protecția pentru statusurile `disabled`, `error` și `timeout`, care nu suprascriu ultimul inventar Docker bun;
- adaugă backfill/self-healing din `inventory_snapshots.raw_json`: la deschiderea tabului Docker, dacă snapshot-ul curent conține Docker dar tabelele structurate nu au fost populate de 0.14.0, serverul reconstruiește automat inventarul fără o colectare nouă;
- nu există migrare DB nouă; agentul 1.4.0/1.4.1 este compatibil.

## 0.14.0

- inventar Docker structurat în baza de date pentru fiecare VM: engine, containere, Docker Compose, imagini, rețele și volume;
- containerele au identitate logică stabilă pentru a păstra asocierile manuale după redeploy;
- asociere many-to-many container → serviciu intern, independent de asocierea VM-ului; un host Docker partajat poate găzdui containere pentru servicii diferite;
- asociere manuală per container și asociere în masă per proiect Docker Compose;
- labels opționale `vm-doc.service`, `vm-doc.services`, `vm-doc.component` și `vm-doc.role` creează automat asocieri fără a suprascrie asocierile manuale;
- tab nou Docker în fișa VM, cu engine, Compose projects, containere, porturi, indicatori și serviciile asociate;
- pagina serviciului afișează containerele asociate chiar dacă VM-ul gazdă este partajat și nu aparține exclusiv serviciului;
- fișa DOCX a VM-ului și fișa DOCX a serviciului includ secțiuni Docker;
- migrare nouă `029_docker_inventory.up.sql`; necesită `vm-doc-agent 1.4.0` pentru colectarea Docker.


## 0.13.8

- Agent actions (Test / Colect / Update) now prefer the registered management IP when the stored agent URL still points to a VIP.
- Auto-registration normalizes a literal-IP base_url to the advertised management IP, preserving scheme and port.
- The agent list no longer shows the redundant "IP-uri raportate VM" column; those addresses remain available in inventory data.
- Agent Excel export removes the redundant reported-VM-IP column and exports the effective management URL.

## 0.13.7

- Fix auto-registration for a brand-new agent: the `agents` INSERT now has a value for every listed column, including `last_registration_ip`.
- Keep internal registration/heartbeat/inventory errors hidden from HTTP clients but log the real server-side error for troubleshooting.
- No database migration is required.

## 0.13.6

- separă în pagina Agenți adresa `IP agent / management` de adresele IP raportate de interfețele VM;
- afișează separat IP-ul sursă observat la register/heartbeat când diferă de IP-ul de management;
- inventarul curent păstrează compact lista adreselor raportate pentru listare/căutare/export fără a încărca payload-ul JSON complet;
- `primary_ip` al inventarului preferă `src/prefsrc` al rutei implicite înaintea primei adrese de interfață, reducând riscul ca un VIP să devină IP principal;
- exportul Excel pentru agenți include IP management, IP sursă register și IP-urile raportate;
- migrare nouă `028_agent_network_identity.up.sql`.

## 0.13.5

- layout fluid pe toată lățimea monitorului; eliminată limita fixă de 1600 px care lăsa spațiu gol pe ecrane mari;
- spațiere adaptivă cu `clamp()` pentru monitoare Full HD, 2K, 4K și ferestre redimensionate;
- cardurile, panourile, tabelele și workspace-urile pot folosi întreaga lățime disponibilă fără overflow inutil;
- toolbar-urile și antetele de panou se împachetează controlat când spațiul scade;
- dialogurile sunt limitate la viewport și pot fi derulate pe ecrane joase;
- navigarea secundară devine scrollabilă pe ecrane mobile, iar controalele se reașază fără să iasă din viewport;
- CSS-ul este versionat în URL pentru cache-busting la upgrade;
- fără migrare DB și fără modificări de backend/API.

## 0.13.4

- fix status auto-update rămas `stable / installing / <versiune>` după instalarea reușită;
- la register/heartbeat, serverul reconciliază cache-ul de update când `agent.version` este egal cu `update_available_version`;
- după reconciliere, `update_state` devine `current`, versiunea disponibilă se golește și se actualizează timestamp-ul de succes;
- UI-ul listei de agenți face refresh-uri scurte după butonul Update pentru a afișa finalizarea fără refresh manual;
- fără migrare DB; compatibil cu vm-doc-agent 1.3.6.

## 0.13.3

- hotfix pentru panic-ul `nil pointer dereference` din `agentclient.Client` introdus pe calea de refresh/update a agenților în 0.13.2;
- `vm-doc-server` inițializează acum propriul `agentclient.Client` cu aceleași `collector.allowed_networks` și limite folosite de collector;
- heartbeat-ul și butonul **Update** pot interoga `/v1/update` / `/v1/update/check` fără a opri procesul serverului;
- protecție defensivă în client: un client neinițializat returnează eroare explicită în loc de SIGSEGV;
- fără migrare MariaDB nouă și fără modificări obligatorii la `vm-doc-agent`.

## 0.13.2

- buton **Update** în lista Agenți pentru verificare/instalare imediată, fără a aștepta `updates.check_interval`;
- serverul apelează endpoint-ul existent `POST /v1/update/check` al agentului 1.3.3+ și respectă canalul configurat local pe agent;
- lista Agenți afișează canalul de update `stable` / `testing`, starea update-ului și versiunea disponibilă când există;
- filtru și căutare după canal/stare update;
- statusul de update este memorat central și reîmprospătat la Test/Colect, la update forțat și periodic pentru agenții auto-înregistrați;
- exportul Excel Agenți include canalul și starea auto-update;
- migrarea `027_agent_update_status.up.sql`;
- `vm-doc-agent 1.3.3` rămâne compatibil, fără upgrade obligatoriu al agentului.

## 0.13.1

- navigare orizontală în pagina Agenți;
- OS + versiune OS raportate de agent în listă și căutare;
- butoane compacte Test / Colect / Edit / Del;
- export Excel pentru agenți;
- publicarea unui release este colapsată implicit;
- release-uri cu filtre, paginare și export Excel;
- toate paginările pornesc implicit de la 10;
- fără migrare MariaDB.

## 0.13.0

- retenție configurabilă a snapshot-urilor de inventar și raportare a volumului de stocare;
- Audit paginat, filtrabil și cu before/after pentru operațiile principale instrumentate;
- obiect nou `external_networks`, cu culoare, tip zonă, risc, trust, CIDR-uri și metadate operaționale;
- sisteme externe asociate unei rețele externe și conexiuni către VM/Servicii interne;
- conectivitatea externă apare în UI, rapoarte și documentația DOCX;
- migrarea `026_inventory_retention_audit_external_systems.up.sql`.

## 0.12.0

- fișa VM împărțită în șapte subsecțiuni cu navigare sticky și URL dedicat;
- procent de completare pentru VM, vizibil în listă, rezumat și export Excel;
- paginare Nomenclatoare configurabilă 10/20/50/100/200, memorată pe categorie;
- pagina Agenți separată în listare și administrarea release-urilor;
- repară pierderea focusului în câmpul de căutare Agenți;
- fără migrare MariaDB nouă.

## 0.11.1

- administrare completă a repository-ului de agent din UI: publicare, promovare și ștergere;
- upload multipart protejat de RBAC `agents.manage` și CSRF;
- suport pentru rollout testing → stable;
- release recomandat împreună cu vm-doc-agent 1.3.2 pentru detecția robustă a versiunilor software.



## 0.11.0

- Servicii agent pe VM: căutare, filtru Active/Inactive/Toate și stare lângă nume;
- Network Routes afișate tabelar;
- Firewall Rules: reguli explicite separate de regulile tehnice backend și reguli brute ascunse implicit;
- Rapoarte împărțite în subcategorii;
- readuce repository-ul central de auto-update pentru vm-doc-agent 1.3.0+;
- pagina Agenți afișează versiunea agentului și release-urile publicate;
- fără migrare MariaDB nouă.

## 0.10.0

- servicii software principale selectabile din inventarul agentului;
- selecții persistente pe VM, independente de snapshotul curent;
- metadate de versiune software/pachet preluate din agentul 1.3.1+;
- componentele principale apar în fișa VM și sunt agregate în fișa Serviciului intern;
- renderer contextual pentru uptime, mount point, port, username, comandă cron și nume serviciu;
- migrarea `025_vm_primary_agent_services.up.sql`;
- OpenAPI și documentație actualizate.


## 0.9.1

- repară eroarea HTTP 500 la adăugarea unei dependențe directe `VM → Serviciu comun`;
- citirea dependențelor VM nu mai folosește un `UNION ALL` fragil în MariaDB, ci interogări separate agregate în aplicație;
- erorile de creare a unei dependențe directe pe VM sunt acum scrise explicit în log;
- fără migrare de bază de date.


## 0.9.0

- căutare, filtrare și paginare în pagina Agenți;
- filtre extinse și descriere scurtată în lista Serviciilor interne;
- carduri compacte în pagina serviciului și afișare condiționată a mediilor PROD/TEST/DEV;
- model nou pentru servicii comune și dependențe globale/explicite;
- nomenclator `dependency_type`;
- relații `internal_service_dependencies` și excepții `vm_common_service_dependencies`;
- servicii comune marcabile ca `is_common` și `implicit_global`;
- dependențe afișate în pagina VM, pagina serviciului și schema logică;
- VM-urile furnizor ale AD/DNS/LDAP și ale altor servicii comune sunt expuse în UI și documentație;
- fișele DOCX VM/Serviciu includ infrastructura comună și analiza de impact;
- rapoarte noi pentru servicii comune, tipuri de dependență și impact;
- migrarea `024_common_service_dependencies.up.sql`;
- OpenAPI și documentație actualizate.

## 0.8.0

- evidențiere explicită a mediilor **PROD / TEST / UAT / DEV** în pagina și fișa DOCX a Serviciului intern;
- lista VM-urilor serviciului afișează ultima fișă VM generată și link direct către document;
- generarea documentației serviciului poate fixa fișele VM ca anexe și poate regenera automat fișele lipsă sau toate fișele;
- pachet ZIP reproductibil cu fișa serviciului și versiunile exacte ale fișelor VM anexate;
- tabel `service_document_annexes` pentru relația dintre o fișă de serviciu și documentele VM folosite la generare;
- meniu nou **Rapoarte**, cu indicatori, pie/donut charts, bar charts și evoluția documentelor generate;
- rapoarte pentru medii, power state, CPU/RAM, OS, vCenter, agenți, backup, inventar, documentare, criticitate, domenii, categorii, layer-e, roluri, tip soluție și completitudinea asocierilor;
- liste de servicii și VM-uri cu informații lipsă pentru completarea documentației;
- permisiune nouă `reports.read`;
- migrarea `023_reports_service_annexes.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.3

- hotfix pentru editorul rich-text: clickul în **Scop și domeniu** / **Obiective** păstrează focusul în zona editabilă în loc să activeze butonul Bold;
- structură HTML corectată și îmbunătățiri de accesibilitate;
- fără migrare de bază de date.


## 0.7.2

- editor rich-text pentru **Scop și domeniu** și **Obiective**;
- suport pentru paragrafe, newline, bold, italic, underline, bullets, numerotare și indentare;
- model rich-text JSON restricționat și validat server-side, fără stocare de HTML executabil;
- compatibilitate menținută prin câmpurile plain-text `purpose` / `objectives`;
- randare rich-text în pagina serviciului și în DOCX;
- conversie automată din textul existent la prima afișare/editare;
- migrarea `022_service_rich_text.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.1

- câmp narativ **Scop și domeniu** pentru serviciul intern, reutilizând `purpose` pentru compatibilitate;
- câmp nou **Obiective** pe serviciul intern;
- afișare aerisită a Descrierii, Scopului și domeniului și Obiectivelor;
- schema logică a serviciului inclusă automat în DOCX;
- un singur nod per VM în schema DOCX, cu toate asocierile și rolurile acelui VM;
- placeholdere `{{service.scope_domain}}` și `{{service.objectives}}`;
- migrarea `021_service_scope_objectives_docx_diagram.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.0

- schemă automată a serviciului, agregată din asocierile VM;
- un singur nod per VM, cu multiple asocieri afișate în același nod;
- grupare pe layer și zonă Multi-layer;
- pictograme configurabile prin `icon_key` în nomenclatoare;
- iconițe implicite pentru clasificare, layere, roluri și tipuri de soluție;
- export Excel nomenclatoare extins cu pictograma;
- migrarea `020_service_diagram_icons.up.sql`;
- OpenAPI și documentația actualizate.



## 0.6.0

- nomenclator `solution_type` și valori inițiale Open source / Dezvoltată intern / Comercială;
- `solution_type_id` pe asocierea VM–serviciu–layer–rol;
- interfață aerisită, pe carduri, pentru asocierile serviciilor din fișa VM;
- agregare tip soluție în lista și pagina Serviciilor interne;
- șabloane DOCX tipizate `vm` / `service` și șablon implicit pentru serviciu intern;
- previzualizare, generare, istoric și descărcare DOCX pentru Serviciu intern;
- numere de document `FSI-*` pentru fișele de serviciu;
- OpenAPI, documentație și migrarea `019_service_documents_solution_type.up.sql` actualizate.


## 0.5.1

- inventarul agentului este randat în tabele compacte, specifice fiecărei secțiuni, în locul flatten-ului generic;
- eliminate din document secțiunile Agent și Proxy și câmpul `uptime_seconds`;
- stocare în format partiție/filesystem/capacitate cu unități lizibile;
- rețea pe câte un rând pentru adresă și interfață;
- numai servicii active, porturi esențiale, reguli UFW numbered și conturi relevante;
- rezumat SSSD și matrice compactă pentru Auditbeat, Filebeat, GLPI Agent, Node Exporter și Syslog;
- cron și NTP simplificate; politici lăsate pregătite pentru completare ulterioară;
- tabele DOCX cu grilă explicită și lățimi fixe, compatibile cu randarea LibreOffice;
- fără migrare de bază de date.

## 0.5.0

- generator DOCX pentru fișa tehnică a VM-ului, disponibil direct în pagina VM;
- previzualizare a datelor și avertismente pentru inventar, servicii sau responsabilități lipsă;
- șabloane DOCX încărcabile și administrabile, cu șablon implicit creat automat;
- placeholder obligatoriu `{{VM_DOCUMENT_BODY}}` și placeholdere scalare pentru antetul șablonului;
- documentul include identificare, resurse, date operaționale, servicii, roluri, responsabilități, backup și inventarul structurat al agentului;
- istoric al documentelor generate, număr unic, fișier, dimensiune, SHA-256, autor și snapshot sursă;
- permisiuni noi `documents.read` și `documents.manage`;
- migrarea `018_document_generation.up.sql` creează `document_templates` și `generated_documents`.

## 0.4.4

- toate valorile nomenclatoarelor sunt sortate consecvent după ordinea părintelui, apoi după ordinea proprie și denumire;
- categoriile de serviciu sunt grupate după ordinea domeniului arhitectural;
- rolurile tehnice sunt grupate după primul layer în ordinea layer-elor, apoi după ordinea proprie; valorile nemapate sunt afișate la final;
- registrul Persoane este ordonat după departament, apoi după nume;
- filtre pe fiecare pagină de nomenclator: căutare text și stare, plus domeniu pentru categorii și layer pentru roluri;
- filtre suplimentare pentru Persoane: departament, sursă și stare;
- paginarea se aplică rezultatului filtrat, iar exportul Excel păstrează lista completă în ordinea nouă;
- fără migrare de bază de date.

## 0.4.3

- paginare pentru toate nomenclatoarele și pentru registrul Persoane, cu dimensiune selectabilă a paginii;
- export Excel pentru nomenclatorul curent, disponibil tuturor utilizatorilor cu permisiunea `nomenclatures.read`;
- exportul include toate rândurile active și inactive, nu numai pagina vizibilă;
- coloane relaționale în Excel pentru `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- export complet pentru persoane, inclusiv departament, sursă și cont AD;
- fără migrare de bază de date.

## 0.4.2

- corectată interogarea de citire a inventarului după ID: parametrul `id` este transmis către `QueryRowContext`;
- eliminată eroarea MariaDB `Error 1064 ... near '?' at line 1` la deschiderea fișei VM;
- inventarul curent și vederea structurată a JSON-ului agentului se încarcă din nou fără recollectare;
- fără migrare de bază de date.

## 0.4.1

- termenul vizibil **Categorie ITIL** este înlocuit cu **Categorie de serviciu**; cheia tehnică `itil_category` rămâne neschimbată pentru compatibilitate;
- integrare de tip director cu Active Directory, reutilizând gazdele LDAP, TLS-ul și contul bind deja configurate pentru autentificare;
- OU rădăcină configurabil, citire recursivă a utilizatorilor și afișare arborescentă după sub-OU-uri;
- filtrare obligatorie după atributul `department`, cu primul departament în ordine alfabetică selectat implicit sau cu un departament implicit configurabil;
- import multiplu și actualizare idempotentă a persoanelor din AD în registrul local de responsabilități, folosind `objectGUID` ca identitate stabilă;
- persoanele importate păstrează sursa LDAP și contul AD, iar reimportul actualizează numele, e-mailul, telefonul și departamentul;
- migrarea `017_service_category_ad_directory.up.sql` actualizează eticheta nomenclatorului și extinde tabelul `people` cu identitatea de director;
- migrarea `016_vm_service_classification.up.sql` este corectată astfel încât indexul nou să fie creat înainte de eliminarea indexului folosit de cheia externă.

## 0.4.0

- domeniul arhitectural și categoria de serviciu sunt mutate de la serviciul intern la asocierea VM–serviciu;
- formularul serviciului intern păstrează numai identitatea, descrierea, criticitatea și informațiile de documentare;
- fișa VM adaugă selectorul Categorie de serviciu între Domeniu și Serviciu intern;
- domeniul filtrează categoriile de serviciu, iar layer-ul filtrează rolurile tehnice;
- pagina și lista Servicii agregă automat încadrările domeniu–categorie din VM-uri;
- VM-urile din pagina serviciului afișează încadrarea folosită de fiecare asociere;
- validare backend pentru relația `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- migrarea `016_vm_service_classification.up.sql` păstrează încadrările existente și extinde cheia unică a asocierii.

## 0.3.9

- pagina Nomenclatoare nu mai afișează toate listele simultan;
- submeniu lateral grupat în Catalog servicii, Arhitectură tehnică, Operare VM și Responsabilități;
- se afișează o singură listă la un moment dat, cu numărul valorilor în submeniu;
- ruta păstrează categoria selectată, de exemplu `#nomenclatures/technical_role`;
- pe ecrane înguste, submeniul devine o grilă adaptivă de opțiuni;
- actualizarea este exclusiv de interfață și nu necesită migrare MariaDB.

## 0.3.8

- selecție în cascadă pe fișa VM: domeniu → serviciu intern → layer → rol tehnic;
- serviciile interne nu mai păstrează configurații layer–rol proprii; combinațiile observate sunt agregate automat din asocierile VM;
- validarea backend verifică serviciul și relația globală layer–rol, fără o restricție suplimentară la nivelul serviciului;
- selector multiplu cu căutare, stil Select2 și complet offline, pentru layer-ele permise ale unui rol tehnic;
- rolurile tehnice sunt ordonate după ordinea layer-ului, apoi după ordinea rolului;
- endpointul de modificare a combinațiilor layer–rol pe serviciu a fost eliminat din API și OpenAPI;
- actualizarea nu necesită migrare de schemă.

## 0.3.7

- fiecare rol tehnic este legat explicit de unul sau mai multe layer-e arhitecturale;
- rolurile sunt filtrate după layer în configurarea serviciului intern;
- validare server-side globală layer–rol, suplimentară față de validarea serviciului;
- relațiile deja folosite sunt migrate automat prin `015_layer_technical_role_mappings.up.sql`;
- relațiile utilizate nu pot fi eliminate accidental;
- Nomenclatoare afișează layer-ele permise pentru fiecare rol tehnic.

## 0.3.6

- relație multiplă VM–serviciu intern–layer–rol tehnic;
- mai multe servicii interne și mai multe roluri pentru același serviciu pe un singur VM;
- tip de utilizare `dedicated`, `shared` sau `dependency`, marcaj principal și observații pe asociere;
- profilul/data provisionării eliminate din modelul funcțional și din nomenclatoare;
- vechiul lifecycle `Retired` migrat la `Status operațional: Retras` și eliminat din interfața/API curent;
- cardul redundant „Rezumat ultimul inventar” eliminat;
- migrarea `014_multi_service_assignments.up.sql`, API, OpenAPI și documentație actualizate.

## 0.3.5

- fișa VM continuă să se încarce dacă datele operaționale sau sumarul de backup au o eroare;
- toate etapele de încărcare a fișei VM sunt jurnalizate cu `stage` și `vm_id`;
- versiunea din interfață este citită din `/version`, nu mai este hard-codată.

## 0.3.4

- pagina VM se încarcă degradat dacă datele agentului, snapshotul curent sau vederea structurată nu pot fi citite;
- erorile opționale din fișa VM sunt jurnalizate cu etapa exactă și `vm_id`;
- interfața afișează un avertisment fără a bloca datele vCenter și operaționale.

## 0.3.3

- secțiunile cu datele colectate de agent sunt restrânse implicit, inclusiv listele de obiecte din interior;
- istoricul inventarelor VM este paginat server-side, cu 10, 20, 50 sau 100 de înregistrări pe pagină;
- pagina Audit este paginată server-side, cu 25, 50, 100 sau 200 de evenimente pe pagină;
- endpointurile de inventar și audit acceptă `page` și `page_size` și întorc metadate de paginare;
- OpenAPI, testele și documentația de upgrade au fost actualizate;
- include corecția de compilare pentru funcția `nullableInt64Ptr` din 0.3.2.

## 0.3.2

- meniu principal **Servicii** pentru catalogul serviciilor interne;
- `Serviciu` ITIL este redenumit **Categorie de serviciu**, iar vechea `Componentă` devine **Serviciu intern**;
- ierarhie validată `Domeniu arhitectural → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- categoriile de serviciu sunt legate de domeniul arhitectural părinte;
- fiecare serviciu definește explicit combinațiile layer–rol permise;
- fișa VM folosește list-box-uri în cascadă și backendul respinge combinațiile incompatibile;
- pagina serviciului afișează descrierea, criticitatea, starea documentației, combinațiile permise și VM-urile asociate;
- migrare automată a datelor 0.3.1 și permisiuni RBAC `services.read` / `services.manage`;
- API și OpenAPI pentru catalogul serviciilor prin migrarea `013_internal_service_catalog.up.sql`.

## 0.3.1

- meniu nou **Nomenclatoare** pentru serviciu, componentă, domeniu arhitectural, layer, mediu, status operațional, profil de provisionare și clasificare;
- câmpurile controlate din fișa VM sunt list-box-uri și nu mai acceptă text liber;
- registru de persoane și mai multe responsabilități pe aceeași VM;
- secțiune separată **Backup și restaurare · Veeam**, cu model de date pregătit pentru sincronizarea prin API;
- migrarea automată a valorilor și responsabililor existenți din 0.3.0;
- endpointuri API, audit și OpenAPI pentru nomenclatoare și persoane;
- migrarea `012_nomenclatures_responsibilities_backup.up.sql`.

## 0.3.0

- pagină VM refăcută ca fișă tehnică structurată pe carduri și secțiuni pliabile;
- vedere sigură a inventarului agentului, cu mascarea câmpurilor sensibile;
- date operaționale separate de snapshoturile agentului și sincronizarea vCenter;
- tabel nou `vm_operational_metadata` prin migrarea 011;
- endpoint `PUT /api/v1/vms/{id}/operational` și audit `vm.operational.update`;
- formular pentru serviciu, componentă, domeniu, layer, mediu, status, scop, responsabili, provisionare, RPO/RTO, backup, clasificare și referințe;
- OpenAPI, documentație și teste actualizate.

## 0.2.2

- autoînregistrare pentru vm-doc-agent 1.1.0;
- heartbeat și stare online/offline fără creare manuală;
- push direct al inventarului;
- asociere automată cu VM după UUID;
- migrarea 010 și documentația de upgrade.


## 0.2.1

- căutare și filtre VM după nume/hostname, power, OS, IP, agent, `Retired` și sursă vCenter;
- paginare server-side și selector 25/50/100/200 înregistrări;
- statistici pentru rezultatele filtrate;
- export Excel `.xlsx` fără dependențe Go suplimentare;
- antet fix corect în tabelul VM, fără suprapunerea primului rând;
- API-ul `GET /api/v1/vms` întoarce un obiect paginat;
- endpoint nou `GET /api/v1/vms/export`;
- listele vCenter goale sunt serializate ca `[]`, nu `null`;
- rutele Swagger sunt înregistrate explicit ca `GET`, evitând panic în Go 1.23.

## 0.2.0

- vCenter devine sursa principală pentru lista de VM-uri;
- CRUD pentru surse vCenter, cu parolă criptată și verificare TLS;
- sincronizare manuală per sursă sau pentru toate sursele;
- scheduler zilnic configurabil per sursă, în fusul orar al aplicației;
- tabele `vcenter_sources`, `virtual_machines` și `vcenter_sync_runs`;
- VM-urile absente sunt marcate `missing_from_vcenter`, fără ștergere automată;
- lifecycle local `Retired`, cu dată, utilizator și notă;
- asociere automată după BIOS/DMI UUID, inclusiv ordinea SMBIOS legacy VMware;
- asociere manuală și dezlegare agent din fișa VM;
- stare agent și colectare manuală direct din fișa VM;
- parser pentru `agent.id`, `agent.version`, `collection.collectors`, FQDN și UUID-uri de corelare;
- listă VM, filtre, pagină de detaliu și istoric sincronizări în frontend;
- permisiuni RBAC noi: `vcenter.read`, `vcenter.manage`, `vms.manage`;
- OpenAPI 3.1 și documentație actualizate.

## 0.1.0

- două binare: `vm-doc-server` și `vm-doc-collector`;
- configurație YAML și secrete criptate AES-256-GCM;
- migrații MariaDB incluse în binar;
- autentificare LDAP și Keycloak/OIDC cu PKCE;
- sesiuni server-side, CSRF și RBAC;
- administrarea agenților și tokenuri criptate individual;
- joburi manuale și periodice cu lease;
- testare agent, colectare, UUID binding și validare schemă 2.x;
- snapshoturi brute, istoric, hash și stare online/offline;
- audit server/collector;
- frontend static fără Node.js;
- OpenAPI 3.1 și Swagger UI embedded;
- unități systemd și reverse proxy Nginx.

## 0.21.10 (2026-10-13)
- Hardening intern read-only: 25 reguli, 6 profiluri, mapări CIS versionate cu stare pending până la validare, raport Excel, API Swagger, migrare 075.
- Nu este audit CIS oficial; agenții legacy furnizează numai datele deja colectate; unknown != pass.


## 2026-10-13 — Server 0.21.14
- Hotfix curățare surse: `cleanup-source-tree.sh --apply` gestionează documente istorice cu același nume și conținut diferit, păstrând ambele exemplare.
- Variantele diferite se salvează în `docs/history/variants/<categorie>/`, cu hash SHA-256 în denumire.
- Fără migrare SQL sau schimbări în codul funcțional; testare compilare completă necesară pe serverul utilizatorului.

## 0.21.75 (2026-10-22) — Uniformizare identitate OIDC/LDAP
- Afișarea Keycloak folosește `family_name given_name (department)`, configurabil prin `auth.oidc.department_claim`, cu fallback sigur pentru claimuri lipsă.
- LDAP `displayName` rămâne nemodificat; nu se schimbă autentificarea, RBAC sau importul AD.
- Migrare SQL: niciuna. Agent: neschimbat (1.7.18).

## 0.21.81 — 2026-10-22
- Schimbările sunt detectate față de baseline-ul acceptat per obiect, nu numai prin perechi de snapshoturi succesive; nu se generează duplicate zilnice pentru aceeași diferență nerevizuită.
- Revizuit / Ignorat actualizează baseline-ul **doar** pentru obiectul ales și mută evenimentul în timeline-ul VM.
- Modificări afișează implicit doar „Nou”; în fișa VM apare un timeline al reviziilor cu înainte/după, dată, autor.
- Migrarea 082 păstrează baseline-ul independent de retenția snapshoturilor și schimbă inventarul asociat evenimentului la ON DELETE SET NULL pentru a preveni pierderea istoricului.
- CSS: scroll lateral limitat la tabel și help, fără scrollbar orizontal pentru toată pagina.
