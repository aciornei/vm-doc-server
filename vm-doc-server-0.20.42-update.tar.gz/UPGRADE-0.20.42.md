# Upgrade vm-doc-server 0.20.41 -> 0.20.42

Versiunea 0.20.42 extinde lista principală și exportul Excel al VM-urilor cu starea de publicare Outline și ultima dată de publicare. Nu adaugă migrare DB și nu necesită update de vm-doc-agent.

## Schimbări

- `Outline`: `DA` dacă VM-ul nu are bifat `Nu se publică în Outline`; `NU` dacă bifa este activă.
- `Ultima publicare Outline`: `outline_vm_documents_global.last_synced_at` pentru targetul `virtualization`.
- Dacă VM-ul nu a fost publicat niciodată, data este goală / `—`.
- Exportul Excel `VM-uri` include aceleași două câmpuri.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.41 \
      /usr/local/src/vm-doc-server-0.20.42

tar -xzf vm-doc-server-0.20.42-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.42

cd /usr/local/src/vm-doc-server-0.20.42
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După restart folosește `Ctrl+F5` pentru a încărca `app.js?v=0.20.42`.
