# Upgrade VM-DOC 0.21.42 → 0.21.43

1. Fă backup la surse/binar și asigură-te că poți reveni la 0.21.42. Păstrează separat `vendor/`, configurația și datele runtime.
2. Pe o copie curată a surselor 0.21.42 extrage `vm-doc-server-0.21.43-update.tar.gz` din rădăcina proiectului **sau** aplică `git apply vm-doc-server-0.21.42-to-0.21.43.patch` (nu ambele).
3. Verifică `cat VERSION` → 0.21.43; `bash scripts/cleanup-source-tree.sh --check`.
4. În mediul offline cu dependențe instalate: `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build`.
5. Validează Securitate → Firewall FortiGate/Local, KPI pe același rând, Revizuite X din Y, expandarea Policy # și interfața pe ecrane mici. Pentru a vedea CSS/JS noi poate fi necesar hard refresh.

Rollback: restaurează binarul/sursele 0.21.42; nu există migrare SQL ori schimbare de agent.
