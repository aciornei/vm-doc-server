package server

import (
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/documents"
)

func TestRetirementOperationalNotesPreserveHistoryAndIdempotent(t *testing.T) {
	when := time.Date(2026, 11, 20, 12, 0, 0, 0, time.UTC)
	one, err := retirementOperationalNotes("Observații istorice", "Proiect închis", "Director IT", "Schimbare aprobată", when)
	if err != nil {
		t.Fatal(err)
	}
	for _, part := range []string{"Observații istorice", "2026-11-20", "Proiect închis", "Schimbare aprobată"} {
		if !strings.Contains(one, part) {
			t.Errorf("missing %q in %s", part, one)
		}
	}
	two, err := retirementOperationalNotes(one, "Proiect închis", "Director IT", "Schimbare aprobată", when)
	if err != nil {
		t.Fatal(err)
	}
	if one != two {
		t.Fatal("repeated retirement must not duplicate existing note")
	}
}

func TestRetirementOperationalNotesDoNotTruncate(t *testing.T) {
	_, err := retirementOperationalNotes(strings.Repeat("a", 60001), "Motiv", "", "", time.Now())
	if err == nil {
		t.Fatal("oversized notes should fail before Outline publication")
	}
}

func TestRetirementOutlineBannerSafeAndStatus(t *testing.T) {
	data := documents.GenerationData{}
	data.Operational.OperationalStatus = "Retras"
	data.OutlineMode = true
	text := string(retirementOutlineMarkdown(data, "<script> & oprit", "Director IT", "Aprobat \n [M]", time.Date(2026, 11, 20, 0, 0, 0, 0, time.UTC)))
	if !strings.Contains(text, "VM RETRASĂ DIN EXPLOATARE") || !strings.Contains(text, "20.11.2026") || !strings.Contains(text, "Status operațional") || !strings.Contains(text, "Retras") {
		t.Fatalf("retirement document misses core details: %s", text)
	}
	if strings.Contains(text, "<script>") {
		t.Fatal("HTML must be escaped in lifecycle metadata")
	}
	if !strings.Contains(text, "&lt;script&gt;") {
		t.Fatal("escaped HTML missing")
	}
	if !strings.Contains(text, "\\[M\\]") {
		t.Fatal("Markdown syntax should be escaped")
	}
}
