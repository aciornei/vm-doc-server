# VM-DOC Server 0.22.5 — Retrage VM (operațiune unică)

**Bază:** 0.22.4 (2026-11-18). **Agent:** 1.7.18, nemodificat. **MariaDB:** migrare nouă NU.

## Scop

În VM → Rezumat/Infrastructură sau Arhivă, butonul **Retrage VM** folosește acum un job asincron. Motivul este obligatoriu.

1. Verifică starea VM-ului și valorile canonice din nomenclator. Identifică mediul PROD și setarea „Nu se publică în Outline”.
2. Pentru **PROD eligibil**: construiește fișa din ultima documentație disponibilă (chiar dacă VM-ul a fost exclus prin resource pool), adaugă anunțul **VM RETRASĂ DIN EXPLOATARE**, data, motivul și observațiile și actualizează **aceeași pagină Outline**. Dacă publicarea eșuează, *nu se aplică retragerea în baza de date*.
3. Într-o tranzacție MariaDB actualizează statusul operațional (nomenclator + metadata și observații), apoi `virtual_machines.retired`, data/motivul/actorul. Inventarul, relațiile, documentele și înregistrările VM nu sunt șterse.
4. Pentru medii non-PROD sau VM-uri marcate explicit „Nu se publică în Outline”, publicarea este omisă conform politicii, iar retragerea se finalizează local. Pentru PROD eligibil dar Outline neconfigurat/inactiv, jobul **eșuează fără retragere**.

Registrul **Arhivă VM & servicii** include și VM-urile din resource pool-uri excluse, cu indicatorul „Pool exclus din import”, pentru ca butonul Retrage VM să rămână accesibil chiar după sincronizarea vCenter.

Publicările obișnuite rămân interzise pentru VM-uri excluse prin pool. Tabelul **Inventar VM** publicat în Outline exclude VM-urile retired la **următoarea republicare**; nu suprascriem automat o pagină agregată care poate avea propriile filtre. Nu mutăm automat paginile într-un folder arhivă, pentru a păstra linkurile.

## Implementare

- API nou `POST /api/v1/lifecycle/vm/{id}/retire` și `GET /api/v1/lifecycle/vm/{id}/retire/jobs/{job_id}`, protejate cu `vms.manage`; pentru Outline se cere suplimentar `documents.manage`.
- Endpointul vechi `PUT lifecycle/vm/{id}` nu mai acceptă **Activ → Retras** (se păstrează **Arhivat → Retras**, reactivarea și arhivarea). `PATCH vms/{id}` nu mai poate modifica direct câmpul `retired`.
- Audit de succes/eșec fără secrete. Joburile se păstrează în memorie 24h după finalizare, similar joburilor de publicare Outline. Pentru restart în timpul operației, operatorul verifică starea în VM-DOC și poate relua dacă nu s-a finalizat.
- O eroare DB după publicarea Outline poate lăsa pagina istorică deja actualizată în Outline, dar statusul local încă activ. Mesajul jobului semnalizează situația; reluarea este idempotentă la nivel de pagină Outline.

## Verificări

- `node --check` și teste UI offline; `gofmt` Go; verificare sintactică OpenAPI.
- Build Go complet cu dependențele `vendor/` și integrare reală MariaDB/Outline **nevalidate în mediul de generare**; test obligatoriu în staging înainte de PROD.
