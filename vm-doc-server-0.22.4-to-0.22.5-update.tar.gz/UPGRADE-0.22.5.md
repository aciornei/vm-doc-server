# Upgrade VM-DOC Server 0.22.4 → 0.22.5

Numai `vm-doc-server`; `vm-doc-collector` și `vm-doc-agent` nemodificate. Nu există migrare SQL nouă.

1. Backup MariaDB și `/opt/vm-doc-server` (binare și configurație). Testați mai întâi în staging cu o VM PROD eligibilă.
2. Extrageți arhiva **update** peste sursele 0.22.4 sau folosiți sursele complete din pachet, fără a suprascrie `config.yaml`/secretele ori `vendor/` existent.
3. Din directorul care conține `go.mod`: `GOPROXY=off GOSUMDB=off go test -mod=vendor ./...` apoi `CGO_ENABLED=0 GOPROXY=off GOSUMDB=off go build -mod=vendor -trimpath -o /tmp/vm-doc-server-0.22.5 ./cmd/vm-doc-server` (adaptați dacă sursa folosește un alt mod de compilare). Pentru număr corect de versiune utilizați Makefile/ldflags din pachet: `make build` când `vendor/` e disponibil.
4. Opriți `vm-doc-server`; faceți backup la executabilul curent, apoi instalați noul executabil în calea `ExecStart` a serviciului. Porniți serviciul și verificați `systemctl status vm-doc-server` și `journalctl -u vm-doc-server -n 100 --no-pager`.
5. În UI, deschideți o VM de test cu mediu PROD și mapping Outline. Retrageți cu motiv și confirmați jobul `success`, pagina Outline cu marcaj/data, status operațional Retras și retired tehnic. În caz de eșec Outline, verificați că VM este încă activă tehnic. Re-publicați tabelul Inventar VM dacă este folosit în Outline.
6. Pentru rollback, opriți serverul și restaurați executabilul/sursele 0.22.4. Nu există downgrade DB. O pagină Outline deja actualizată înainte de eșecul unei tranzacții DB necesită verificare manuală.

**Atenție:** nu porniți upgrade din `/opt/vm-doc-server` dacă nu există acolo `go.mod`. Folosiți directorul surselor 0.22.4/0.22.5. Nu includeți `vendor/` vechi în arhivă peste unul funcțional.
