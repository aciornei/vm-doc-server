package vcenter

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/url"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/vmenv"
)

const (
	defaultVMPageSize = 10
	maxVMPageSize     = 200
)

type VMFilter struct {
	Query       string
	Power       string
	Environment string
	Agent       string
	Retired     string
	Presence    string
	Baseline    string
	SourceID    int64
	ServiceID   int64
	Outline     string
	OSSupport   string
	Published   string
	Sort        string
	Page        int
	PageSize    int
}

type VMPage struct {
	Items                    []domain.VirtualMachine `json:"items"`
	Page                     int                     `json:"page"`
	PageSize                 int                     `json:"page_size"`
	Total                    int                     `json:"total"`
	Pages                    int                     `json:"pages"`
	PresentCount             int                     `json:"present_count"`
	WithAgentCount           int                     `json:"with_agent_count"`
	PoweredOnCount           int                     `json:"powered_on_count"`
	OutlinePublishedCount    int                     `json:"outline_published_count"`
	CompletionAveragePercent float64                 `json:"completion_average_percent"`
}

func NormalizeVMFilter(in VMFilter) VMFilter {
	in.Query = strings.TrimSpace(in.Query)
	in.Power = strings.TrimSpace(in.Power)
	in.Environment = strings.TrimSpace(in.Environment)
	in.Agent = strings.ToLower(strings.TrimSpace(in.Agent))
	in.Retired = strings.ToLower(strings.TrimSpace(in.Retired))
	in.Presence = strings.ToLower(strings.TrimSpace(in.Presence))
	in.Baseline = strings.ToLower(strings.TrimSpace(in.Baseline))
	in.Outline = strings.ToLower(strings.TrimSpace(in.Outline))
	in.OSSupport = strings.ToLower(strings.TrimSpace(in.OSSupport))
	in.Published = strings.ToLower(strings.TrimSpace(in.Published))
	in.Sort = strings.ToLower(strings.TrimSpace(in.Sort))
	if in.Page < 1 {
		in.Page = 1
	}
	if in.PageSize <= 0 {
		in.PageSize = defaultVMPageSize
	}
	if in.PageSize > maxVMPageSize {
		in.PageSize = maxVMPageSize
	}
	return in
}

// vmSortColumns este o listă explicită de expresii SQL, niciodată interpolată
// din inputul utilizatorului. Sortarea are loc în baza de date, înainte de LIMIT.
var vmSortColumns = map[string]string{
	"name":           "vm.name",
	"presence":       "vm.present_in_vcenter",
	"power":          "vm.power_state",
	"cpu":            "vm.cpu_count",
	"os":             "COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),'')",
	"ip":             "COALESCE(NULLIF(ompref.preferred_ip,''),NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,''),'')",
	"agent":          "COALESCE(a.name,'')",
	"services":       "COALESCE(svcmap.service_names,'')",
	"publication":    "vm.outline_documentation_disabled",
	"outline_date":   "ovmoutline.last_synced_at",
	"completion":     "completion_percent",
	"inventory_date": "i.received_at",
}

func vmOrderBy(filter VMFilter) (string, error) {
	switch filter.Sort {
	case "":
		if filter.Presence == "missing" {
			return ` ORDER BY (vm.missing_since IS NULL),vm.missing_since ASC,vm.name ASC,vm.id ASC`, nil
		}
		return ` ORDER BY vm.present_in_vcenter DESC,vm.name ASC,vm.id ASC`, nil
	case "completion_asc": // compatibilitate cu cardul KPI și versiunile anterioare
		return ` ORDER BY completion_percent ASC,vm.name ASC,vm.id ASC`, nil
	}
	parts := strings.Split(filter.Sort, ":")
	if len(parts) != 2 || (parts[1] != "asc" && parts[1] != "desc") {
		return "", fmt.Errorf("invalid VM sort %q", filter.Sort)
	}
	column, ok := vmSortColumns[parts[0]]
	if !ok {
		return "", fmt.Errorf("invalid VM sort %q", filter.Sort)
	}
	direction := strings.ToUpper(parts[1])
	if parts[0] == "cpu" {
		return ` ORDER BY vm.cpu_count ` + direction + `,vm.memory_mib ` + direction + `,vm.name ASC,vm.id ASC`, nil
	}
	// Pentru valori NULL, toate sortările țin VM-urile fără valoare la final.
	if parts[0] == "outline_date" || parts[0] == "inventory_date" {
		return ` ORDER BY (` + column + ` IS NULL) ASC,` + column + ` ` + direction + `,vm.name ASC,vm.id ASC`, nil
	}
	return ` ORDER BY ` + column + ` ` + direction + `,vm.name ASC,vm.id ASC`, nil
}

func (s *Service) ListVMs(ctx context.Context, filter VMFilter) (VMPage, error) {
	filter = NormalizeVMFilter(filter)
	where, args, err := buildVMWhere(filter)
	if err != nil {
		return VMPage{}, err
	}

	var result VMPage
	result.Page = filter.Page
	result.PageSize = filter.PageSize
	result.Items = make([]domain.VirtualMachine, 0)

	// Toate cardurile sunt agregate peste setul filtrat complet, înainte de paginare.
	summaryQuery := `SELECT COUNT(*),
 COALESCE(SUM(vm.present_in_vcenter=1),0),
 COALESCE(SUM(vm.agent_id IS NOT NULL),0),
 COALESCE(SUM(vm.power_state='POWERED_ON'),0),
 COALESCE(SUM(ovmoutline.last_synced_at IS NOT NULL),0),
 COALESCE(AVG(` + vmCompletionExpr + `),0)` + vmFrom + where
	if err := s.DB.QueryRowContext(ctx, summaryQuery, args...).Scan(
		&result.Total,
		&result.PresentCount,
		&result.WithAgentCount,
		&result.PoweredOnCount,
		&result.OutlinePublishedCount,
		&result.CompletionAveragePercent,
	); err != nil {
		return VMPage{}, err
	}

	if result.Total == 0 {
		return result, nil
	}
	result.Pages = (result.Total + result.PageSize - 1) / result.PageSize
	if result.Page > result.Pages {
		result.Page = result.Pages
	}
	offset := (result.Page - 1) * result.PageSize

	orderBy, err := vmOrderBy(filter)
	if err != nil {
		return VMPage{}, err
	}
	query := vmSelect + where + orderBy + ` LIMIT ? OFFSET ?`
	queryArgs := append(append([]any{}, args...), result.PageSize, offset)
	rows, err := s.DB.QueryContext(ctx, query, queryArgs...)
	if err != nil {
		return VMPage{}, err
	}
	defer rows.Close()
	for rows.Next() {
		vm, err := scanVM(rows)
		if err != nil {
			return VMPage{}, err
		}
		result.Items = append(result.Items, vm)
	}
	return result, rows.Err()
}

func (s *Service) ExportVMs(ctx context.Context, filter VMFilter) ([]domain.VirtualMachine, error) {
	filter = NormalizeVMFilter(filter)
	where, args, err := buildVMWhere(filter)
	if err != nil {
		return nil, err
	}
	orderBy, err := vmOrderBy(filter)
	if err != nil {
		return nil, err
	}
	rows, err := s.DB.QueryContext(ctx, vmSelect+where+orderBy, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.VirtualMachine, 0)
	for rows.Next() {
		vm, err := scanVM(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, vm)
	}
	return out, rows.Err()
}

func (s *Service) ListVMIPs(ctx context.Context, vmID int64) ([]string, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT ip_address FROM vcenter_vm_ips WHERE vm_id=? ORDER BY is_primary DESC,ip_address`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]string, 0)
	seen := map[string]bool{}
	for rows.Next() {
		var ip string
		if err := rows.Scan(&ip); err != nil {
			return nil, err
		}
		ip = strings.TrimSpace(ip)
		if ip != "" && !seen[ip] {
			seen[ip] = true
			out = append(out, ip)
		}
	}
	return out, rows.Err()
}

func buildVMWhere(filter VMFilter) (string, []any, error) {
	clauses := []string{`vm.excluded_by_vcenter_pool=0`}
	args := make([]any, 0, 8)

	if filter.Query != "" {
		pattern := "%" + filter.Query + "%"
		clauses = append(clauses, `(vm.name LIKE ? OR vm.guest_hostname LIKE ? OR i.hostname LIKE ? OR vm.power_state LIKE ? OR vm.guest_os LIKE ? OR i.os_name LIKE ? OR i.os_version LIKE ? OR vm.primary_ip LIKE ? OR i.primary_ip LIKE ? OR ompref.preferred_ip LIKE ? OR a.name LIKE ? OR a.agent_version LIKE ? OR src.name LIKE ? OR COALESCE(svcmap.service_names,'') LIKE ?)`)
		for range 14 {
			args = append(args, pattern)
		}
	}
	if filter.Power != "" {
		clauses = append(clauses, `vm.power_state=?`)
		args = append(args, filter.Power)
	}
	if environment, ok := vmenv.Normalize(filter.Environment); !ok {
		return "", nil, fmt.Errorf("invalid VM environment filter %q", filter.Environment)
	} else if environment != "" {
		predicate, value := vmenv.Predicate(vmenv.PreferredLabel, environment)
		clauses = append(clauses, predicate)
		args = append(args, value)
	}
	if filter.SourceID > 0 {
		clauses = append(clauses, `vm.vcenter_source_id=?`)
		args = append(args, filter.SourceID)
	}
	if filter.ServiceID > 0 {
		clauses = append(clauses, `FIND_IN_SET(?,COALESCE(svcmap.service_ids,''))>0`)
		args = append(args, filter.ServiceID)
	}
	switch filter.Retired {
	case "", "all":
	case "true", "1", "yes":
		clauses = append(clauses, `vm.retired=1`)
	case "false", "0", "no":
		clauses = append(clauses, `vm.retired=0`)
	default:
		return "", nil, fmt.Errorf("invalid retired filter %q", filter.Retired)
	}
	switch filter.Presence {
	case "", "all":
	case "present":
		clauses = append(clauses, `vm.present_in_vcenter=1`)
	case "missing":
		clauses = append(clauses, `vm.present_in_vcenter=0`)
	default:
		return "", nil, fmt.Errorf("invalid presence filter %q", filter.Presence)
	}
	switch filter.Baseline {
	case "", "all":
	case "yes", "true", "1":
		clauses = append(clauses, `vmbl.vm_id IS NOT NULL`)
	case "no", "false", "0":
		clauses = append(clauses, `vmbl.vm_id IS NULL`)
	default:
		return "", nil, fmt.Errorf("invalid baseline filter %q", filter.Baseline)
	}

	switch filter.Outline {
	case "", "all":
	case "yes", "true", "1":
		clauses = append(clauses, `vm.outline_documentation_disabled=0`)
	case "no", "false", "0":
		clauses = append(clauses, `vm.outline_documentation_disabled=1`)
	default:
		return "", nil, fmt.Errorf("invalid outline filter %q", filter.Outline)
	}

	switch filter.Published {
	case "", "all":
	case "yes":
		clauses = append(clauses, `ovmoutline.last_synced_at IS NOT NULL`)
	case "no":
		clauses = append(clauses, `ovmoutline.last_synced_at IS NULL`)
	default:
		return "", nil, fmt.Errorf("invalid published filter %q", filter.Published)
	}
	if _, err := vmOrderBy(filter); err != nil {
		return "", nil, err
	}

	switch filter.OSSupport {
	case "", "all":
	case "yes", "true", "1", "supported":
		clauses = append(clauses, `(`+vmOSSupportExpr+`='supported')`)
	case "no", "false", "0", "unsupported":
		clauses = append(clauses, `(`+vmOSSupportExpr+`='unsupported')`)
	default:
		return "", nil, fmt.Errorf("invalid os_support filter %q", filter.OSSupport)
	}

	switch filter.Agent {
	case "", "all":
	case "configured":
		clauses = append(clauses, `vm.agent_id IS NOT NULL`)
	case "unconfigured":
		clauses = append(clauses, `vm.agent_id IS NULL`)
	case "disabled":
		clauses = append(clauses, `vm.agent_id IS NOT NULL AND a.enabled=0`)
	case "unknown":
		clauses = append(clauses, `vm.agent_id IS NOT NULL AND a.enabled=1 AND a.last_contact_at IS NULL`)
	case "online":
		clauses = append(clauses, `vm.agent_id IS NOT NULL AND a.enabled=1 AND a.last_contact_at IS NOT NULL AND a.offline_after_seconds>0 AND TIMESTAMPDIFF(SECOND,a.last_contact_at,UTC_TIMESTAMP())<=a.offline_after_seconds`)
	case "offline":
		clauses = append(clauses, `vm.agent_id IS NOT NULL AND a.enabled=1 AND a.last_contact_at IS NOT NULL AND (a.offline_after_seconds<=0 OR TIMESTAMPDIFF(SECOND,a.last_contact_at,UTC_TIMESTAMP())>a.offline_after_seconds)`)
	default:
		return "", nil, fmt.Errorf("invalid agent filter %q", filter.Agent)
	}

	if len(clauses) == 0 {
		return "", args, nil
	}
	return ` WHERE ` + strings.Join(clauses, ` AND `), args, nil
}

func (s *Service) GetVM(ctx context.Context, id int64) (domain.VirtualMachine, error) {
	return scanVM(s.DB.QueryRowContext(ctx, vmSelect+` WHERE vm.id=?`, id))
}

func (s *Service) UpdateVM(ctx context.Context, id int64, in VMUpdate, userID int64) (domain.VirtualMachine, error) {
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.VirtualMachine{}, err
	}
	defer tx.Rollback()
	var exists int
	if err := tx.QueryRowContext(ctx, `SELECT 1 FROM virtual_machines WHERE id=? FOR UPDATE`, id).Scan(&exists); err != nil {
		return domain.VirtualMachine{}, err
	}
	if in.Retired != nil {
		if *in.Retired {
			_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET retired=1,retired_at=COALESCE(retired_at,?),retired_by=?,retired_note=? WHERE id=?`, time.Now().UTC(), userID, strings.TrimSpace(in.RetiredNote), id)
		} else {
			_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET retired=0,retired_at=NULL,retired_by=NULL,retired_note=? WHERE id=?`, strings.TrimSpace(in.RetiredNote), id)
		}
		if err != nil {
			return domain.VirtualMachine{}, err
		}
	} else if in.RetiredNote != "" {
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET retired_note=? WHERE id=?`, strings.TrimSpace(in.RetiredNote), id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if in.OutlineDocumentationDisabled != nil {
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET outline_documentation_disabled=? WHERE id=?`, *in.OutlineDocumentationDisabled, id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if in.VaultURL != nil {
		vaultURL := strings.TrimSpace(*in.VaultURL)
		if len([]rune(vaultURL)) > 2048 {
			return domain.VirtualMachine{}, errors.New("vault_url must not exceed 2048 characters")
		}
		if vaultURL != "" {
			parsed, err := url.ParseRequestURI(vaultURL)
			if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
				return domain.VirtualMachine{}, errors.New("vault_url must be an absolute HTTP or HTTPS URL")
			}
		}
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET vault_url=? WHERE id=?`, vaultURL, id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if in.HideListeningPorts != nil {
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET hide_listening_ports=? WHERE id=?`, *in.HideListeningPorts, id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if in.ClearAgent {
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=NULL,current_inventory_id=NULL WHERE id=?`, id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if in.AgentID != nil {
		if *in.AgentID <= 0 {
			return domain.VirtualMachine{}, errors.New("invalid agent_id")
		}
		var currentInventory sql.NullInt64
		if err := tx.QueryRowContext(ctx, `SELECT current_inventory_id FROM agents WHERE id=?`, *in.AgentID).Scan(&currentInventory); err != nil {
			return domain.VirtualMachine{}, err
		}
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=NULL,current_inventory_id=NULL WHERE agent_id=? AND id<>?`, *in.AgentID, id); err != nil {
			return domain.VirtualMachine{}, err
		}
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=?,current_inventory_id=? WHERE id=?`, *in.AgentID, nullableInt64(currentInventory), id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if err := tx.Commit(); err != nil {
		return domain.VirtualMachine{}, err
	}
	return s.GetVM(ctx, id)
}

const vmOSSupportExpr = `CASE
 WHEN TRIM(COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),''))='' THEN 'undetermined'
 WHEN EXISTS (
   SELECT 1 FROM nomenclature_items osr
    WHERE osr.category_code='unsupported_os' AND osr.active=1
      AND LOWER(COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),'')) LIKE CONCAT('%',LOWER(osr.name),'%')
      AND (TRIM(COALESCE(osr.item_code,''))=''
           OR LOWER(COALESCE(i.os_version,'')) LIKE CONCAT(LOWER(osr.item_code),'%')
           OR LOWER(COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),'')) LIKE CONCAT('%',LOWER(osr.item_code),'%'))
 ) THEN 'unsupported'
 ELSE 'supported'
END`

const vmFrom = `
 FROM virtual_machines vm
 JOIN vcenter_sources src ON src.id=vm.vcenter_source_id
 LEFT JOIN agents a ON a.id=vm.agent_id
 LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id
 LEFT JOIN vm_operational_metadata ompref ON ompref.vm_id=vm.id
 LEFT JOIN vm_operational_metadata om_env ON om_env.vm_id=vm.id
 LEFT JOIN (
   SELECT service_rows.vm_id,
          GROUP_CONCAT(DISTINCT service_rows.service_id ORDER BY service_rows.service_id SEPARATOR ',') AS service_ids,
          GROUP_CONCAT(DISTINCT service_rows.service_name ORDER BY service_rows.service_name SEPARATOR '\t') AS service_names
   FROM (
     SELECT sa.vm_id,sa.internal_service_id AS service_id,s.name AS service_name
       FROM vm_internal_service_assignments sa JOIN internal_services s ON s.id=sa.internal_service_id
     UNION ALL
     SELECT c.vm_id,a2.internal_service_id,s.name
       FROM docker_container_service_assignments a2 JOIN docker_containers c ON c.id=a2.docker_container_id AND c.present=1 JOIN internal_services s ON s.id=a2.internal_service_id
     UNION ALL
     SELECT di.vm_id,a3.internal_service_id,s.name
       FROM database_instance_service_assignments a3 JOIN (SELECT i0.* FROM database_instances i0 WHERE NOT EXISTS(SELECT 1 FROM database_engine_exclusions ex WHERE ex.ignored=1 AND ex.engine_key=(CASE WHEN REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') IN ('db2','ibmdb2','db2luw','ibmdb2luw') THEN 'db2' ELSE REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') END))) di ON di.id=a3.database_instance_id AND di.present=1 JOIN internal_services s ON s.id=a3.internal_service_id
     UNION ALL
     SELECT dc.vm_id,a4.internal_service_id,s.name
       FROM database_catalog_service_assignments a4 JOIN (SELECT c0.* FROM database_catalogs c0 JOIN database_instances i0 ON i0.id=c0.database_instance_id WHERE NOT EXISTS(SELECT 1 FROM database_engine_exclusions ex WHERE ex.ignored=1 AND ex.engine_key=(CASE WHEN REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') IN ('db2','ibmdb2','db2luw','ibmdb2luw') THEN 'db2' ELSE REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') END))) dc ON dc.id=a4.database_catalog_id AND dc.present=1 JOIN internal_services s ON s.id=a4.internal_service_id
     UNION ALL
     SELECT ws.vm_id,a5.internal_service_id,s.name
       FROM web_site_service_assignments a5 JOIN web_sites ws ON ws.id=a5.web_site_id AND ws.present=1 JOIN internal_services s ON s.id=a5.internal_service_id
   ) service_rows
   GROUP BY service_rows.vm_id
 ) svcmap ON svcmap.vm_id=vm.id
 LEFT JOIN (
   SELECT c.vm_id,COUNT(DISTINCT c.id) resource_count,
          COUNT(DISTINCT CASE WHEN dh.documentation_exempt=1 OR c.documentation_exempt=1 OR a1.id IS NOT NULL THEN c.id END) documented_count
     FROM docker_containers c LEFT JOIN docker_container_service_assignments a1 ON a1.docker_container_id=c.id JOIN docker_hosts dh ON dh.vm_id=c.vm_id
    WHERE c.present=1 GROUP BY c.vm_id
 ) dcomp ON dcomp.vm_id=vm.id
 LEFT JOIN (
   SELECT dc.vm_id,COUNT(DISTINCT dc.id) resource_count,
          COUNT(DISTINCT CASE WHEN dc.documentation_exempt=1 OR di0.documentation_exempt=1 OR a1.id IS NOT NULL THEN dc.id END) documented_count
     FROM (SELECT c0.* FROM database_catalogs c0 JOIN database_instances i0 ON i0.id=c0.database_instance_id WHERE NOT EXISTS(SELECT 1 FROM database_engine_exclusions ex WHERE ex.ignored=1 AND ex.engine_key=(CASE WHEN REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') IN ('db2','ibmdb2','db2luw','ibmdb2luw') THEN 'db2' ELSE REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') END))) dc JOIN (SELECT i0.* FROM database_instances i0 WHERE NOT EXISTS(SELECT 1 FROM database_engine_exclusions ex WHERE ex.ignored=1 AND ex.engine_key=(CASE WHEN REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') IN ('db2','ibmdb2','db2luw','ibmdb2luw') THEN 'db2' ELSE REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') END))) di0 ON di0.id=dc.database_instance_id LEFT JOIN database_catalog_service_assignments a1 ON a1.database_catalog_id=dc.id
    WHERE dc.present=1 AND dc.is_system=0 GROUP BY dc.vm_id
 ) dbcatcomp ON dbcatcomp.vm_id=vm.id
 LEFT JOIN (
   SELECT di.vm_id,COUNT(DISTINCT di.id) resource_count,
          COUNT(DISTINCT CASE WHEN di.documentation_exempt=1 OR a1.id IS NOT NULL THEN di.id END) documented_count
     FROM (SELECT i0.* FROM database_instances i0 WHERE NOT EXISTS(SELECT 1 FROM database_engine_exclusions ex WHERE ex.ignored=1 AND ex.engine_key=(CASE WHEN REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') IN ('db2','ibmdb2','db2luw','ibmdb2luw') THEN 'db2' ELSE REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') END))) di LEFT JOIN database_instance_service_assignments a1 ON a1.database_instance_id=di.id
    WHERE di.present=1 GROUP BY di.vm_id
 ) dbinstcomp ON dbinstcomp.vm_id=vm.id
 LEFT JOIN (
   SELECT ws.vm_id,COUNT(DISTINCT ws.id) resource_count,
          COUNT(DISTINCT CASE WHEN ws.documentation_exempt=1 OR COALESCE(wsv.documentation_exempt,0)=1 OR a1.id IS NOT NULL THEN ws.id END) documented_count
     FROM web_sites ws LEFT JOIN web_site_service_assignments a1 ON a1.web_site_id=ws.id LEFT JOIN web_servers wsv ON wsv.vm_id=ws.vm_id AND wsv.engine=ws.engine AND wsv.present=1
    WHERE ws.present=1 AND ws.enabled=1 GROUP BY ws.vm_id
 ) webcomp ON webcomp.vm_id=vm.id
 LEFT JOIN (
   SELECT resource_services.vm_id,
          COUNT(DISTINCT resource_services.internal_service_id) required_count,
          COUNT(DISTINCT CASE WHEN direct_assignment.id IS NOT NULL
                                  AND direct_assignment.architectural_domain_id IS NOT NULL
                                  AND direct_assignment.itil_category_id IS NOT NULL
                                  AND direct_assignment.layer_id IS NOT NULL
                                  AND direct_assignment.technical_role_id IS NOT NULL
                                  AND direct_assignment.solution_type_id IS NOT NULL
                              THEN resource_services.internal_service_id END) configured_count
     FROM (
       SELECT c.vm_id,a.internal_service_id
         FROM docker_container_service_assignments a
         JOIN docker_containers c ON c.id=a.docker_container_id AND c.present=1
       UNION ALL
       SELECT di.vm_id,a.internal_service_id
         FROM database_instance_service_assignments a
         JOIN (SELECT i0.* FROM database_instances i0 WHERE NOT EXISTS(SELECT 1 FROM database_engine_exclusions ex WHERE ex.ignored=1 AND ex.engine_key=(CASE WHEN REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') IN ('db2','ibmdb2','db2luw','ibmdb2luw') THEN 'db2' ELSE REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') END))) di ON di.id=a.database_instance_id AND di.present=1
       UNION ALL
       SELECT dc.vm_id,a.internal_service_id
         FROM database_catalog_service_assignments a
         JOIN (SELECT c0.* FROM database_catalogs c0 JOIN database_instances i0 ON i0.id=c0.database_instance_id WHERE NOT EXISTS(SELECT 1 FROM database_engine_exclusions ex WHERE ex.ignored=1 AND ex.engine_key=(CASE WHEN REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') IN ('db2','ibmdb2','db2luw','ibmdb2luw') THEN 'db2' ELSE REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') END))) dc ON dc.id=a.database_catalog_id AND dc.present=1 AND dc.is_system=0
       UNION ALL
       SELECT ws.vm_id,a.internal_service_id
         FROM web_site_service_assignments a
         JOIN web_sites ws ON ws.id=a.web_site_id AND ws.present=1 AND ws.enabled=1
     ) resource_services
     LEFT JOIN vm_internal_service_assignments direct_assignment
       ON direct_assignment.vm_id=resource_services.vm_id
      AND direct_assignment.internal_service_id=resource_services.internal_service_id
    GROUP BY resource_services.vm_id
 ) resourcecfg ON resourcecfg.vm_id=vm.id
 LEFT JOIN (SELECT vm_id,COUNT(*) selected_count FROM vm_primary_agent_services GROUP BY vm_id) psvc ON psvc.vm_id=vm.id
 LEFT JOIN (SELECT vm_id,COUNT(*) selected_count FROM vm_primary_agent_ports GROUP BY vm_id) pport ON pport.vm_id=vm.id
 LEFT JOIN (SELECT vm_id,COUNT(*) selected_count FROM software_items WHERE present=1 AND is_primary=1 GROUP BY vm_id) psoft ON psoft.vm_id=vm.id
 LEFT JOIN inventory_change_baselines vmbl ON vmbl.vm_id=vm.id
 LEFT JOIN outline_vm_documents_global ovmoutline ON ovmoutline.vm_id=vm.id AND ovmoutline.target_code='virtualization'
 LEFT JOIN (
   SELECT c.vm_id,COUNT(*) required_count,COALESCE(SUM(c.review_status='reviewed'),0) reviewed_count
     FROM inventory_changes c
     LEFT JOIN inventory_change_baselines b ON b.vm_id=c.vm_id
    WHERE c.documentation_requirement='required'
      AND (b.inventory_id IS NULL OR c.inventory_id>b.inventory_id)
    GROUP BY c.vm_id
 ) chgcomp ON chgcomp.vm_id=vm.id`

// Aceeași expresie SQL pentru procentul individual și pentru media setului filtrat.
const vmCompletionExpr = `CAST(ROUND(100.0*(
  IF(vm.agent_id IS NOT NULL,1,0)+
  IF(vm.current_inventory_id IS NOT NULL,1,0)+
  IF(COALESCE(NULLIF(i.hostname,''),NULLIF(vm.guest_hostname,'')) IS NOT NULL,1,0)+
  IF(COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,'')) IS NOT NULL,1,0)+
  IF(COALESCE(NULLIF(ompref.preferred_ip,''),NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,'')) IS NOT NULL,1,0)+
  IF(EXISTS(SELECT 1 FROM vm_operational_nomenclatures c1 WHERE c1.vm_id=vm.id AND c1.category_code='environment'),1,0)+
  IF(EXISTS(SELECT 1 FROM vm_operational_nomenclatures c2 WHERE c2.vm_id=vm.id AND c2.category_code='operational_status'),1,0)+
  IF(EXISTS(SELECT 1 FROM vm_operational_nomenclatures c3 WHERE c3.vm_id=vm.id AND c3.category_code='classification'),1,0)+
  IF(EXISTS(SELECT 1 FROM vm_operational_metadata om WHERE om.vm_id=vm.id AND TRIM(om.purpose)<>''),1,0)+
  IF(LOWER(COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),'')) LIKE '%windows%',IF(COALESCE(psoft.selected_count,0)>0,1,0),IF(COALESCE(svcmap.service_names,'')<>'',1,0))+
  IF(EXISTS(SELECT 1 FROM vm_responsibilities vr WHERE vr.vm_id=vm.id),1,0)+
  IF(EXISTS(SELECT 1 FROM beneficiary_assignments ba WHERE ba.resource_type='vm' AND ba.resource_id=vm.id),1,0)+
  COALESCE(dcomp.documented_count,0)+
  IF(COALESCE(dbcatcomp.resource_count,0)>0,COALESCE(dbcatcomp.documented_count,0),COALESCE(dbinstcomp.documented_count,0))+
  COALESCE(webcomp.documented_count,0)+
  COALESCE(resourcecfg.configured_count,0)+
  IF(vm.current_inventory_id IS NOT NULL AND LOWER(COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),'')) NOT LIKE '%windows%' AND (COALESCE(psvc.selected_count,0)>0 OR EXISTS(SELECT 1 FROM vm_documentation_reviews vdr WHERE vdr.vm_id=vm.id AND vdr.category_code='agent_services')),1,0)+
  IF(vm.current_inventory_id IS NOT NULL AND (vm.hide_listening_ports=1 OR COALESCE(pport.selected_count,0)>0),1,0)+
  IF(COALESCE(chgcomp.required_count,0)>0,IF(COALESCE(chgcomp.reviewed_count,0)=COALESCE(chgcomp.required_count,0),1,0),0)
 )/(12+
    COALESCE(dcomp.resource_count,0)+
    IF(COALESCE(dbcatcomp.resource_count,0)>0,COALESCE(dbcatcomp.resource_count,0),COALESCE(dbinstcomp.resource_count,0))+
    COALESCE(webcomp.resource_count,0)+
    COALESCE(resourcecfg.required_count,0)+
    IF(vm.current_inventory_id IS NOT NULL,IF(LOWER(COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),'')) LIKE '%windows%',1,2),0)+
    IF(COALESCE(chgcomp.required_count,0)>0,1,0)
 )) AS UNSIGNED)`

const vmSelect = `SELECT
 vm.id,vm.vcenter_source_id,src.name,vm.vcenter_moid,vm.instance_uuid,vm.bios_uuid,vm.name,vm.power_state,vm.cpu_count,vm.memory_mib,vm.hardware_version,vm.guest_os,vm.guest_hostname,COALESCE(NULLIF(ompref.preferred_ip,''),vm.primary_ip),vm.custom_attributes_json,
 vm.retired,vm.retired_at,vm.retired_by,vm.retired_note,vm.outline_documentation_disabled,vm.vault_url,vm.hide_listening_ports,ovmoutline.last_synced_at,vm.present_in_vcenter,vm.first_seen_at,vm.last_seen_at,vm.missing_since,vm.last_vcenter_sync_at,
 vm.agent_id,a.name,COALESCE(a.agent_version,''),a.enabled,a.offline_after_seconds,a.last_contact_at,a.last_success_at,a.last_error,vm.current_inventory_id,
 i.hostname,i.os_name,i.os_version,` + vmOSSupportExpr + `,COALESCE(ompref.environment,''),i.primary_ip,i.received_at,COALESCE(svcmap.service_names,''),COALESCE(chgcomp.required_count,0),GREATEST(COALESCE(chgcomp.required_count,0)-COALESCE(chgcomp.reviewed_count,0),0),IF(vmbl.vm_id IS NOT NULL,1,0),COALESCE(psoft.selected_count,0),vm.created_at,vm.updated_at,
 ` + vmCompletionExpr + ` AS completion_percent` + vmFrom

func scanVM(scanner interface{ Scan(...any) error }) (domain.VirtualMachine, error) {
	var vm domain.VirtualMachine
	var retiredAt, outlineLastSyncedAt, missingSince, lastVCenter, agentContact, agentSuccess, inventoryReceived sql.NullTime
	var retiredBy, agentID, currentInventory sql.NullInt64
	var agentName, agentVersion, agentError, invHostname, invOSName, invOSVersion, osSupportStatus, environment, invPrimaryIP, serviceNames sql.NullString
	var agentEnabled sql.NullBool
	var offlineAfter sql.NullInt64
	var custom []byte
	err := scanner.Scan(
		&vm.ID, &vm.VCenterSourceID, &vm.VCenterSourceName, &vm.VCenterMoID, &vm.InstanceUUID, &vm.BIOSUUID, &vm.Name, &vm.PowerState, &vm.CPUCount, &vm.MemoryMiB, &vm.HardwareVersion, &vm.GuestOS, &vm.GuestHostname, &vm.PrimaryIP, &custom,
		&vm.Retired, &retiredAt, &retiredBy, &vm.RetiredNote, &vm.OutlineDocumentationDisabled, &vm.VaultURL, &vm.HideListeningPorts, &outlineLastSyncedAt, &vm.PresentInVCenter, &vm.FirstSeenAt, &vm.LastSeenAt, &missingSince, &lastVCenter,
		&agentID, &agentName, &agentVersion, &agentEnabled, &offlineAfter, &agentContact, &agentSuccess, &agentError, &currentInventory,
		&invHostname, &invOSName, &invOSVersion, &osSupportStatus, &environment, &invPrimaryIP, &inventoryReceived, &serviceNames, &vm.RequiredChangeCount, &vm.OutstandingRequiredChanges, &vm.BaselineEstablished, &vm.PrimarySoftwareCount, &vm.CreatedAt, &vm.UpdatedAt, &vm.CompletionPercent,
	)
	if err != nil {
		return vm, err
	}
	vm.CustomAttributesJSON = custom
	if retiredAt.Valid {
		vm.RetiredAt = &retiredAt.Time
	}
	if retiredBy.Valid {
		v := retiredBy.Int64
		vm.RetiredBy = &v
	}
	if outlineLastSyncedAt.Valid {
		vm.OutlineLastSyncedAt = &outlineLastSyncedAt.Time
	}
	if missingSince.Valid {
		vm.MissingSince = &missingSince.Time
	}
	if lastVCenter.Valid {
		vm.LastVCenterSyncAt = &lastVCenter.Time
	}
	if agentID.Valid {
		v := agentID.Int64
		vm.AgentID = &v
		vm.AgentName = agentName.String
		vm.AgentVersion = agentVersion.String
		vm.AgentLastError = agentError.String
		if agentContact.Valid {
			vm.AgentLastContactAt = &agentContact.Time
		}
		if agentSuccess.Valid {
			vm.AgentLastSuccessAt = &agentSuccess.Time
		}
		vm.AgentStatus = agentStatus(agentEnabled.Bool, agentContact, offlineAfter.Int64)
	} else {
		vm.AgentStatus = "unconfigured"
	}
	if currentInventory.Valid {
		v := currentInventory.Int64
		vm.CurrentInventoryID = &v
	}
	vm.InventoryHostname = invHostname.String
	vm.InventoryOSName = invOSName.String
	vm.InventoryOSVersion = invOSVersion.String
	vm.OSSupportStatus = osSupportStatus.String
	vm.Environment = environment.String
	vm.InventoryPrimaryIP = invPrimaryIP.String
	if raw := strings.TrimSpace(serviceNames.String); raw != "" {
		for _, name := range strings.Split(raw, "\t") {
			if name = strings.TrimSpace(name); name != "" {
				vm.ServiceNames = append(vm.ServiceNames, name)
			}
		}
	}
	if inventoryReceived.Valid {
		vm.InventoryReceivedAt = &inventoryReceived.Time
	}
	return vm, nil
}

func agentStatus(enabled bool, lastContact sql.NullTime, offlineAfter int64) string {
	if !enabled {
		return "disabled"
	}
	if !lastContact.Valid {
		return "unknown"
	}
	if offlineAfter <= 0 || time.Since(lastContact.Time.UTC()) > time.Duration(offlineAfter)*time.Second {
		return "offline"
	}
	return "online"
}

func nullableInt64(value sql.NullInt64) any {
	if value.Valid {
		return value.Int64
	}
	return nil
}
