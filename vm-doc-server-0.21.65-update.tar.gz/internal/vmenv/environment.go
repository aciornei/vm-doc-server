// Package vmenv keeps the VM environment filter consistent across inventory,
// agent, backup and monitoring views. It does not modify any environment label.
package vmenv

import "strings"

// Normalize accepts broad legacy PROD/TEST/DEV, or one exact nomenclature label
// in the name:<label> form. No SQL is constructed from user text.
func Normalize(value string) (string, bool) {
	value = strings.TrimSpace(value)
	switch strings.ToUpper(value) {
	case "", "ALL":
		return "", true
	case "PROD", "TEST", "DEV":
		return strings.ToUpper(value), true
	}
	if !strings.HasPrefix(value, "name:") {
		return "", false
	}
	if strings.ContainsAny(value, "\x00\n\r") {
		return "", false
	}
	name := strings.TrimSpace(strings.TrimPrefix(value, "name:"))
	if len(name) == 0 || len(name) > 250 || strings.ContainsAny(name, "\x00\n\r") {
		return "", false
	}
	return "name:" + name, true
}

// Matches uses exact names for nomenclature choices; the legacy filters retain
// their historical grouping semantics ("Producție" is included in PROD).
func Matches(label, filter string) bool {
	if filter == "" {
		return true
	}
	if strings.HasPrefix(filter, "name:") {
		return strings.EqualFold(strings.TrimSpace(label), strings.TrimSpace(strings.TrimPrefix(filter, "name:")))
	}
	return strings.EqualFold(Kind(label), filter)
}

// Predicate builds a parameterized condition on an application-authored expression.
func Predicate(labelExpression, filter string) (string, any) {
	if strings.HasPrefix(filter, "name:") {
		return "LOWER(TRIM(" + labelExpression + "))=LOWER(?)", strings.TrimPrefix(filter, "name:")
	}
	return SQLCase(labelExpression) + "=?", filter
}

// Kind uses the same documented classification as the VM web client.
func Kind(label string) string {
	s := strings.ToLower(strings.TrimSpace(label))
	switch {
	case strings.Contains(s, "prod") || strings.Contains(s, "produc"):
		return "PROD"
	case strings.Contains(s, "test") || strings.Contains(s, "uat") || s == "qa":
		return "TEST"
	case strings.Contains(s, "dev") || strings.Contains(s, "dezvolt"):
		return "DEV"
	default:
		return ""
	}
}

// SQLCase accepts ONLY trusted, developer-authored SQL expressions, never request input.
func SQLCase(expr string) string {
	s := "LOWER(COALESCE(" + expr + ",''))"
	return "CASE WHEN " + s + " LIKE '%prod%' OR " + s + " LIKE '%produc%' THEN 'PROD' " +
		"WHEN " + s + " LIKE '%test%' OR " + s + " LIKE '%uat%' OR " + s + "='qa' THEN 'TEST' " +
		"WHEN " + s + " LIKE '%dev%' OR " + s + " LIKE '%dezvolt%' THEN 'DEV' ELSE '' END"
}

// PreferredLabel returns a VM's effective environment, prioritizing nomenclature.
// The subquery is tied to an existing vm alias in its enclosing SQL SELECT.
const PreferredLabel = `COALESCE(NULLIF((SELECT n.name FROM vm_operational_nomenclatures mon JOIN nomenclature_items n ON n.id=mon.item_id AND n.category_code='environment' WHERE mon.vm_id=vm.id AND mon.category_code='environment' LIMIT 1),''),NULLIF(om_env.environment,''),'')`
