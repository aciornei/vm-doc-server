package vmenv

import "testing"

func TestEnvironmentNormalization(t *testing.T) {
	cases := []struct{ label, want string }{{"PROD", "PROD"}, {"Producție", "PROD"}, {"TEST", "TEST"}, {"UAT", "TEST"}, {"DEV", "DEV"}, {"dezvoltare", "DEV"}, {"", ""}}
	for _, tc := range cases {
		if got := Kind(tc.label); got != tc.want {
			t.Errorf("Kind(%q)=%q want %q", tc.label, got, tc.want)
		}
	}
	for _, v := range []string{"PROD", "TEST", "DEV", "", "all"} {
		if _, ok := Normalize(v); !ok {
			t.Errorf("valid environment: %q", v)
		}
	}
	if _, ok := Normalize("PROD' OR 1=1"); ok {
		t.Fatal("invalid environment accepted")
	}
}

func TestCustomEnvironmentNomenclature(t *testing.T) {
	for _, label := range []string{"STAGING", "UAT", "Laborator intern", "Preproducție"} {
		f, ok := Normalize("name:" + label)
		if !ok || f != "name:"+label {
			t.Fatalf("environment %q rejected: %q", label, f)
		}
		if !Matches(label, f) || Matches("Unrelated", f) {
			t.Fatalf("wrong matching for %q", label)
		}
		clause, arg := Predicate(PreferredLabel, f)
		if clause == "" || arg != label {
			t.Fatalf("invalid sql filter %q: %#v", clause, arg)
		}
	}
	if !Matches("Producție", "PROD") || Matches("STAGING", "PROD") {
		t.Fatal("legacy PROD matching changed")
	}
	for _, bad := range []string{"name:", "name:\ninvalid", "LAB", "name:" + string(make([]byte, 260))} {
		if _, ok := Normalize(bad); ok {
			t.Fatalf("invalid filter accepted %q", bad)
		}
	}
}
