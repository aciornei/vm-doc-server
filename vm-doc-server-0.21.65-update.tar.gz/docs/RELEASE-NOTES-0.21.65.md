# VM-DOC Server 0.21.65 — Mediu din nomenclator / diagnostic JavaScript

Filtrul Mediu nu mai este restricționat la PROD/TEST/DEV: folosește valorile complete ale nomenclatorului (inclusiv personalizate și inactive, etichetate). Selecțiile custom filtrează exact numele de mediu în API, paginare și exporturi Excel. Implicit continuă Power ON + PROD. Endpoint-urile existente acceptă `environment=name:<nume>` pentru selecții exacte; `environment=PROD|TEST|DEV` rămâne compatibil cu gruparea de până acum.

Pentru eroarea `vmContext is not defined` întâlnită pe VM → Docker/DB/Web, versiunea adaugă afișarea stack-ului și sursei JS. Nu există niciun simbol `vmContext` în codul client livrat și fără fișier/linie din browser nu se poate promite că eroarea a fost remediată. Diagnosticul este intenționat neinvaziv, fără injectarea artificială a unui `vmContext` global.

Agent 1.7.18 neschimbat; fără migrare sau SQL cleanup. Build Go complet, DB și interfața conectată la vCenter rămân de verificat în mediu real.
