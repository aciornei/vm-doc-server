# Upgrade VM-DOC Server 0.21.64 → 0.21.65 (offline)

1. Oprește vm-doc-server; fă backup pentru binarul existent, `/etc/vm-doc` și baza MariaDB.
2. Aplică arhiva `vm-doc-server-0.21.65-update.tar.gz` în rădăcina surselor 0.21.64 sau patch-ul incremental (nu ambele). Pentru o instalare de la zero folosește arhiva completă a surselor.
3. Reconstruiește binarul serverului pe mașina offline folosind dependințele Go din `vendor/` deja aprobate în mediu (de exemplu `go build -mod=vendor ./cmd/vm-doc-server` potrivit procedurii locale). Nu este livrat binar precompilat.
4. Verifică `VERSION=0.21.65`; instalează binarul, repornește serviciul și încarcă UI cu Ctrl+F5.
5. Verifică Agenți, Inventar VM, Backup Veeam, Monitorizare VM, Raport OS suportat și Publicare Outline: dropdown-ul Mediu listează **toate valorile nomenclatorului Mediu** și Power ON + PROD sunt selectate implicit. Selectează un mediu personalizat și compară tabelul cu exportul Excel.
6. Pe VM → Docker/DB/Web: dacă persistă `vmContext is not defined`, copiază textul complet de diagnostic afișat și primele linii din F12 → Console, inclusiv numele fișierului JS și numărul liniei. Eroarea NU este confirmată ca remediată în acest release.

Nu există migrare SQL și nu este necesară actualizarea agentului 1.7.18. Rollback: reinstalează binarul și sursele 0.21.64; nu sunt modificări de schemă.
