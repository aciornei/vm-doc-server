# Upgrade VM-DOC Server 0.21.41 → 0.21.42

1. Efectuează backup la binar, surse și baza MariaDB înainte de instalare.
2. În copia de staging a surselor **0.21.41**, aplică numai una dintre: `tar -xzf vm-doc-server-0.21.42-update.tar.gz` sau `git apply vm-doc-server-0.21.41-to-0.21.42.patch`.
3. Confirmă `cat VERSION` = `0.21.42`. Păstrează directorul local `vendor/` și configurația runtime.
4. Rulează `bash scripts/cleanup-source-tree.sh --check`, apoi `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build`.
5. Verifică în Chromium pagina Firewall globală și fișa VM, cardurile Forti/Local, exporturile, review individual/colectiv, cele trei coloane și expandarea detaliilor din Policy #. Verifică și progresul review DB/Web.
6. Promovează în producție numai după validarea în staging.

Nu există migrare SQL sau modificare de agent; rollback-ul reface sursele/binarul 0.21.41. Nu combina TAR update cu patchul (ar aplica de două ori aceleași schimbări).
