package inventorychanges

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestExtractTrackedDetectsUserAndDatabase(t *testing.T) {
	raw := []byte(`{"host":{"hostname":"vm1"},"os":{"name":"Ubuntu","version":"24.04"},"accounts":{"local_users":[{"username":"app","uid":1000,"gid":1000,"system_account":false}]},"databases":{"instances":[{"engine":"postgresql","product":"PostgreSQL","instance_name":"main","data_dir":"/var/lib/postgresql/16/main","endpoints":[{"port":5432}],"catalogs":[{"name":"portal","kind":"database","system":false}]}]}}`)
	values, err := extractTracked(raw)
	if err != nil {
		t.Fatal(err)
	}
	foundUser, foundDB := false, false
	for _, v := range values {
		if v.Type == "local_user" && v.Key == "1000" {
			foundUser = true
		}
		if v.Type == "database" && v.Label == "Bază de date portal" {
			foundDB = true
		}
	}
	if !foundUser || !foundDB {
		b, _ := json.MarshalIndent(values, "", "  ")
		t.Fatalf("missing tracked objects: %s", b)
	}
}

func TestVolatileCollectionFieldsIgnored(t *testing.T) {
	a := []byte(`{"collected_at":"2026-01-01T00:00:00Z","collection":{"duration_ms":10},"host":{"hostname":"vm1"},"os":{"name":"Ubuntu","version":"24.04"}}`)
	b := []byte(`{"collected_at":"2026-01-01T00:05:00Z","collection":{"duration_ms":999},"host":{"hostname":"vm1"},"os":{"name":"Ubuntu","version":"24.04"}}`)
	aa, err := extractTracked(a)
	if err != nil {
		t.Fatal(err)
	}
	bb, err := extractTracked(b)
	if err != nil {
		t.Fatal(err)
	}
	if len(aa) != len(bb) {
		t.Fatalf("different normalized objects: %d %d", len(aa), len(bb))
	}
	for k, v := range aa {
		other, ok := bb[k]
		if !ok || !canonicalEqual(v.Value, other.Value) {
			t.Fatalf("volatile data changed %s", k)
		}
	}
}

func TestNTPTrackingSummaryAndPeerRuntimeStateIgnored(t *testing.T) {
	a := []byte(`{"ntp":{"installed":true,"implementation":"chrony","version":"4.5","service_name":"chronyd.service","service_active":"active","service_enabled":"enabled","synchronized":true,"current_source":"ntp1","servers":[{"address":"ntp1","type":"server","selected":true,"reachable":true,"source":"chronyc"}],"config_files":["/etc/chrony.conf"],"tracking_summary":{"System time":"0.0001 seconds slow","Ref time (UTC)":"A"}}}`)
	b := []byte(`{"ntp":{"installed":true,"implementation":"chrony","version":"4.5","service_name":"chronyd.service","service_active":"active","service_enabled":"enabled","synchronized":true,"current_source":"ntp1","servers":[{"address":"ntp1","type":"server","selected":false,"reachable":false,"source":"chronyc"}],"config_files":["/etc/chrony.conf"],"tracking_summary":{"System time":"0.998 seconds fast","Ref time (UTC)":"B"}}}`)
	assertTrackedEqual(t, a, b, "time|ntp|ntp")
}

func TestNodeExporterMetricsProbeFieldsIgnored(t *testing.T) {
	a := []byte(`{"integrations":{"node_exporter":{"installed":true,"name":"node_exporter","version":"1.8.2","binary_path":"/usr/local/bin/node_exporter","service_names":["node_exporter.service"],"service_active":"active","service_enabled":"enabled","config_files":["/etc/systemd/system/node_exporter.service"],"listen_addresses":["[::]:9100"],"metrics_endpoints":["http://127.0.0.1:9100/metrics"],"metrics_reachable":true,"metrics_http_status":200,"metric_sample_count":877,"metrics_checked_at":"2026-08-25T13:21:32Z","metrics_error":""}}}`)
	b := []byte(`{"integrations":{"node_exporter":{"installed":true,"name":"node_exporter","version":"1.8.2","binary_path":"/usr/local/bin/node_exporter","service_names":["node_exporter.service"],"service_active":"active","service_enabled":"enabled","config_files":["/etc/systemd/system/node_exporter.service"],"listen_addresses":["[::]:9100"],"metrics_endpoints":["http://127.0.0.1:9100/metrics"],"metrics_reachable":false,"metrics_http_status":503,"metric_sample_count":12,"metrics_checked_at":"2026-08-25T13:26:32Z","metrics_error":"connection reset"}}}`)
	assertTrackedEqual(t, a, b, "integrations|integration|node_exporter")
}

func TestNftablesCounterAndHandleIgnored(t *testing.T) {
	a := []byte(`{"firewall":{"rules":[{"backend":"nftables","family":"ip","table":"filter","chain":"OUTPUT","action":"jump","rule":"counter packets 75482 bytes 28829444 jump ufw-before-output # handle 31"}]}}`)
	b := []byte(`{"firewall":{"rules":[{"backend":"nftables","family":"ip","table":"filter","chain":"OUTPUT","action":"jump","rule":"counter packets 99999 bytes 77777777 jump ufw-before-output # handle 131"}]}}`)
	aa, err := extractTracked(a)
	if err != nil {
		t.Fatal(err)
	}
	bb, err := extractTracked(b)
	if err != nil {
		t.Fatal(err)
	}
	if len(aa) != len(bb) {
		t.Fatalf("different object counts: %d %d", len(aa), len(bb))
	}
	for key, av := range aa {
		bv, ok := bb[key]
		if !ok || !canonicalEqual(av.Value, bv.Value) {
			t.Fatalf("nft runtime counters changed tracked object %s: %#v %#v", key, av.Value, bv.Value)
		}
	}
}

func TestNftablesSemanticRuleChangeStillDetected(t *testing.T) {
	a := []byte(`{"firewall":{"rules":[{"backend":"nftables","family":"ip","table":"filter","chain":"INPUT","action":"accept","rule":"tcp dport 443 counter packets 10 bytes 1000 accept # handle 10"}]}}`)
	b := []byte(`{"firewall":{"rules":[{"backend":"nftables","family":"ip","table":"filter","chain":"INPUT","action":"accept","rule":"tcp dport 8443 counter packets 11 bytes 1100 accept # handle 20"}]}}`)
	aa, err := extractTracked(a)
	if err != nil {
		t.Fatal(err)
	}
	bb, err := extractTracked(b)
	if err != nil {
		t.Fatal(err)
	}
	oldRules, newRules := 0, 0
	for key := range aa {
		if strings.HasPrefix(key, "firewall|rule|") {
			oldRules++
			if _, ok := bb[key]; ok {
				t.Fatalf("semantic firewall rule change kept the same key: %s", key)
			}
		}
	}
	for key := range bb {
		if strings.HasPrefix(key, "firewall|rule|") {
			newRules++
		}
	}
	if oldRules != 1 || newRules != 1 {
		t.Fatalf("expected one tracked firewall rule per inventory, got %d and %d", oldRules, newRules)
	}
}

func assertTrackedEqual(t *testing.T, a, b []byte, key string) {
	t.Helper()
	aa, err := extractTracked(a)
	if err != nil {
		t.Fatal(err)
	}
	bb, err := extractTracked(b)
	if err != nil {
		t.Fatal(err)
	}
	av, ok := aa[key]
	if !ok {
		t.Fatalf("missing %s in first inventory", key)
	}
	bv, ok := bb[key]
	if !ok {
		t.Fatalf("missing %s in second inventory", key)
	}
	if !canonicalEqual(av.Value, bv.Value) {
		aj, _ := json.Marshal(av.Value)
		bj, _ := json.Marshal(bv.Value)
		t.Fatalf("volatile fields changed %s: %s != %s", key, aj, bj)
	}
}
