# Upgrade vm-doc-server 0.20.21 → 0.20.22

## Ce se schimbă

0.20.22 curăță pagina **Modificări** de diferențele produse doar de valori runtime:

- NTP/chrony: `tracking_summary` nu mai este urmărit, iar `selected` / `reachable` ale surselor NTP nu mai produc modificări;
- node_exporter: sunt ignorate probele runtime (`metrics_checked_at`, `metric_sample_count`, `metrics_reachable`, `metrics_http_status`, `metrics_error`);
- nftables: valorile `counter packets ... bytes ...` și `# handle ...` sunt eliminate înainte de comparație;
- schimbările reale de configurație (port, action, chain, source/destination, jump target etc.) rămân detectate;
- Detalii afișează tabelul câmpurilor efectiv schimbate, iar JSON-ul complet rămâne într-o secțiune separată.

Modificările deja stocate înainte de upgrade rămân pentru audit. Dacă vrei o listă curată după instalare, poți folosi **Stabilește baseline VM** după ce verifici inventarul curent.

## Bază de date

Nu există migrare nouă.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.21 /usr/local/src/vm-doc-server-0.20.22
tar -xzf vm-doc-server-0.20.22-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.22
cd /usr/local/src/vm-doc-server-0.20.22
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Nu este necesar update de agent.
