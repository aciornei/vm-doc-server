# Monitorizare · vm-doc-server 0.19.3

## Scop

vm-doc verifică dacă o VM este monitorizată cap-coadă, fără să încerce să înlocuiască Prometheus. Seriile de metrici rămân în Prometheus; vm-doc păstrează numai starea și metadatele necesare documentației.

## Surse

O sursă poate avea tipul:

- `metrics` — targeturi de infrastructură, de exemplu Node Exporter;
- `blackbox` — probe HTTP/HTTPS publicate de un Prometheus care scrappează Blackbox Exporter.

Câmpuri principale: URL, autentificare `none`/`basic`/`bearer`, verificare TLS, interval de sincronizare, label VM și label target. Secretul este criptat cu cheia master a aplicației.

## Corelare target → VM

Ordinea este fixă:

1. label explicit configurabil, implicit `vm_fqdn`;
2. FQDN exact;
3. hostname exact;
4. IP exact — IP din agent, IP principal vCenter și toate IPv4-urile guest vCenter;
5. `/etc/hosts` al agentului asociat sursei Prometheus;
6. alias manual salvat pe VM.

Portul din `instance` este ignorat pentru corelarea identității. Astfel `172.20.1.25:9100`, `web01:9100` și `web01.example.ro:9100` pot identifica aceeași VM prin metode diferite.

Dacă Prometheus folosește un hostname definit numai în propriul `/etc/hosts`, nu este necesar ca vm-doc să îl rezolve. Atât timp cât numele targetului coincide cu hostname/FQDN/aliasul VM-ului, corelarea se face textual.

Pentru un alias arbitrar este recomandat fie un alias manual în vm-doc, fie un label explicit în Prometheus:

```yaml
static_configs:
  - targets: ['prometheus-web-prod:9100']
    labels:
      vm_fqdn: 'web01.example.ro'
```

## Node Exporter

Starea locală vine din inventarul `vm-doc-agent 1.6.3`: instalat, service activ, versiune și endpoint de metrics. vm-doc diferențiază între:

- exporter activ și target Prometheus UP;
- exporter activ, dar fără target Prometheus;
- target Prometheus DOWN;
- exporter absent/oprit.

## Blackbox

Pentru targeturile surselor `blackbox`, sincronizarea execută query-uri read-only pentru:

- `probe_success`;
- `probe_http_status_code`;
- `probe_duration_seconds`;
- `probe_ssl_earliest_cert_expiry`.

Valorile sunt best-effort: lipsa unei metrici nu invalidează sincronizarea targetului.

## Separarea metrics / blackbox în 0.19.1

Două surse vm-doc pot indica același URL Prometheus fără să dubleze inventarul. Sursa `metrics` exclude targeturile Blackbox, iar sursa `blackbox` păstrează numai targeturile identificate prin `__metrics_path__=/probe`, `__param_target` sau calea `/probe` din `scrapeUrl`. Detectarea nu depinde de numele jobului.

Clientul Prometheus folosește conexiune directă (`Proxy: nil`) pentru infrastructura internă; variabilele de mediu `HTTP_PROXY`/`HTTPS_PROXY` nu sunt folosite pentru aceste surse.

## Grafana

Grafana nu este inclusă în 0.19.3. După validarea Prometheus/Blackbox, etapa următoare poate sincroniza read-only dashboardurile și regulile/stările alertelor pentru a închide circuitul de monitorizare.

## Agent asociat și /etc/hosts · 0.19.2

Fiecare sursă Prometheus poate fi asociată explicit cu agentul vm-doc instalat pe serverul Prometheus. Asocierea este per sursă, astfel încât două servere Prometheus cu fișiere `/etc/hosts` diferite nu își amestecă rezolvările.

Ordinea de corelare este: label explicit → FQDN → hostname → IP → `/etc/hosts` al agentului asociat → alias manual. Dacă targetul `prod-linux-037:9100` nu corespunde unui hostname VM, dar agentul Prometheus raportează `prod-linux-037 -> 172.20.1.25`, vm-doc corelează apoi IP-ul `172.20.1.25` cu VM-ul. Metoda salvată este `prometheus_hosts`, iar valoarea de depanare este de forma `prod-linux-037 -> 172.20.1.25`.

Dacă agentul asociat nu are inventar curent sau rulează o versiune mai veche fără colectorul `hosts`, sincronizarea Prometheus continuă cu metodele normale; corelarea prin hosts este doar indisponibilă.


## IPv4-uri multiple din vCenter · 0.19.3

Pe lângă `guest/identity.ip_address`, serverul citește best-effort `GET /api/vcenter/vm/{vm}/guest/networking/interfaces` și extrage toate adresele IPv4 utile de pe toate interfețele guest. Loopback, link-local și IPv6 sunt ignorate. Datele sunt persistate în `vcenter_vm_ips`.

Dacă endpointul guest networking nu este disponibil temporar (VM oprit, VMware Tools indisponibil sau permisiuni insuficiente), sincronizarea vCenter continuă și ultimul set complet de IP-uri nu este șters.

Aceste IP-uri sunt folosite la corelarea Prometheus chiar dacă VM-ul nu are agent. Pagina VM → Monitorizare afișează lista IP-urilor vCenter cunoscute.

## UI Monitorizare · 0.19.3

Meniul Monitorizare este împărțit în două subpagini:

- **Stare monitorizare** — carduri, VM-uri, targeturi Prometheus/Blackbox și filtre;
- **Surse & sincronizări** — configurarea surselor, Test/Sync și istoricul rulărilor.

Formularul Prometheus este mai lat și grupat în secțiuni, iar filtrele și panourile din Monitorizare/VM Monitorizare au padding și spațiere mărite.
