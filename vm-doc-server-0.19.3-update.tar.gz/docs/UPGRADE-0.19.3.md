# Upgrade vm-doc-server 0.19.2 → 0.19.3

0.19.3 adaugă toate IPv4-urile guest vCenter în corelarea Prometheus și reorganizează UI-ul Monitorizare. `vm-doc-agent` rămâne 1.6.3.

## Pași

1. Actualizați serverul la 0.19.3 și porniți serviciul; se aplică migrarea `040_vcenter_vm_guest_ips.up.sql`.
2. Rulați o sincronizare vCenter pentru a popula `vcenter_vm_ips`. Endpointul folosit este `/api/vcenter/vm/{vm}/guest/networking/interfaces` și este best effort.
3. Verificați o VM cu mai multe IP-uri în **VM → Monitorizare**; cardul `IP-uri vCenter` trebuie să afișeze IPv4-urile cunoscute.
4. Rulați **Monitorizare → Surse & sincronizări → Sincronizează toate** pentru a reface corelarea targeturilor cu noile IP-uri.
5. Pentru targeturile rezolvate prin `/etc/hosts` al Prometheus, `match_method` rămâne `prometheus_hosts`, iar `match_value` arată `alias -> IP`.

Nu este necesară golirea tabelelor de monitorizare. Nu este necesar update de agent peste 1.6.3.
