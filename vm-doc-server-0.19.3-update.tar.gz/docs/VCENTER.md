# Integrarea vCenter

## Principiu

Tabelul `virtual_machines` este alimentat din vCenter. O VM există în aplicație indiferent dacă are agent sau inventar JSON.

Sincronizarea:

1. creează o sesiune REST vCenter;
2. citește lista VM-urilor;
3. citește detaliile fiecărei VM cu un număr limitat de workeri;
4. face upsert după `(vcenter_source_id, vcenter_moid)`;
5. păstrează statusul operațional, asocierile cu servicii și asocierea agentului;
6. marchează VM-urile nevăzute ca `present_in_vcenter=false` și setează `missing_since`;
7. încearcă asocierea automată cu ultimul inventar al agentului.

## Corelarea agentului

Ordinea de corelare este:

1. BIOS UUID din vCenter cu `host.product_uuid` sau `host.correlation.dmi_product_uuid`;
2. varianta `host.correlation.smbios_legacy_byte_order` pentru VMware;
3. asocierea deja salvată;
4. hostname/FQDN numai dacă există un singur candidat;
5. asociere manuală din fișa VM.

O asociere manuală nu este suprascrisă de sincronizările ulterioare.

Starea agentului trebuie interpretată astfel:

- **online/offline/disabled**: există un agent configurat și asociat;
- **unknown**: agentul este asociat, dar nu există încă un contact confirmat;
- **unconfigured**: aplicația nu are încă o asociere cu un agent.

`unconfigured` nu dovedește că pachetul nu este instalat în sistemul de operare. Confirmarea instalării se face după asocierea agentului și executarea acțiunii **Testează agentul**, iar primirea inventarului confirmă complet identitatea prin UUID.

## Configurarea sursei

Din **VM-uri → Adaugă sursă** se configurează:

- nume;
- URL, de exemplu `https://vcenter.example.ro`;
- utilizator dedicat;
- parolă;
- verificare TLS și, opțional, numele certificatului;
- activarea sincronizării zilnice și ora locală.

Parola este criptată în baza de date cu cheia master a aplicației.

## Programarea zilnică

Schedulerul rulează în procesul `vm-doc-server`. Ora sursei este interpretată în `app.timezone`. Dacă serverul pornește după ora programată și sursa nu a avut o sincronizare reușită în ziua curentă, sincronizarea este pornită la următoarea verificare.

## Status operațional și missing

- ciclul de viață administrativ este reprezentat prin nomenclatorul **Status operațional**;
- valoarea **Retras** înlocuiește vechiul marcaj local `Retired`;
- `present_in_vcenter=false` înseamnă că VM-ul nu a apărut în ultima sincronizare;
- VM-urile lipsă nu sunt șterse automat;
- ștergerea unei surse vCenter șterge VM-urile sincronizate din acea sursă.

## API REST folosit

Clientul folosește autentificarea prin sesiune și endpointurile:

```text
POST   /api/session
GET    /api/vcenter/vm
GET    /api/vcenter/vm/{vm}
GET    /api/vcenter/vm/{vm}/guest/identity                # best effort
GET    /api/vcenter/vm/{vm}/guest/networking/interfaces   # best effort, toate IPv4-urile
DELETE /api/session
```

Citirea `guest/identity` și `guest/networking/interfaces` poate eșua legitim pentru VM-uri oprite, VMware Tools indisponibil sau permisiuni insuficiente; sincronizarea VM-ului continuă cu datele de bază. În 0.19.3, toate IPv4-urile guest disponibile sunt păstrate în `vcenter_vm_ips` și sunt folosite la corelarea targeturilor Prometheus.

## vSphere REST list limit

The vSphere `GET /api/vcenter/vm` operation returns at most 4,000 virtual machines. Version 0.2.0 synchronizes all machines visible to the configured service account when the source inventory is within that API limit. A source with more than 4,000 visible VMs must be split or synchronized with inventory filters in a later version.
