package vcenter

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/domain"
)

const maxResponseSize = 32 << 20

type Client struct {
	baseURL  *url.URL
	username string
	password string
	http     *http.Client
	workers  int
}

type RemoteVM struct {
	MoID                     string         `json:"moid"`
	Name                     string         `json:"name"`
	PowerState               string         `json:"power_state"`
	CPUCount                 int            `json:"cpu_count"`
	MemoryMiB                int64          `json:"memory_mib"`
	InstanceUUID             string         `json:"instance_uuid"`
	BIOSUUID                 string         `json:"bios_uuid"`
	HardwareVersion          string         `json:"hardware_version"`
	GuestOS                  string         `json:"guest_os"`
	GuestHostname            string         `json:"guest_hostname"`
	PrimaryIP                string         `json:"primary_ip"`
	IPAddresses              []string       `json:"ip_addresses,omitempty"`
	GuestNetworkingAvailable bool           `json:"guest_networking_available,omitempty"`
	CustomAttributes         map[string]any `json:"custom_attributes"`
}

type listVM struct {
	VM            string `json:"vm"`
	Name          string `json:"name"`
	PowerState    string `json:"power_state"`
	CPUCount      int    `json:"cpu_count"`
	MemorySizeMiB int64  `json:"memory_size_mib"`
}

type vmInfo struct {
	Identity struct {
		Name         string `json:"name"`
		BIOSUUID     string `json:"bios_uuid"`
		InstanceUUID string `json:"instance_uuid"`
	} `json:"identity"`
	CPU struct {
		Count int `json:"count"`
	} `json:"cpu"`
	Memory struct {
		SizeMiB int64 `json:"size_mib"`
	} `json:"memory"`
	PowerState string `json:"power_state"`
	Hardware   struct {
		Version string `json:"version"`
	} `json:"hardware"`
	GuestOS string `json:"guest_os"`
}

type guestIdentity struct {
	Name      string          `json:"name"`
	FullName  json.RawMessage `json:"full_name"`
	HostName  string          `json:"host_name"`
	IPAddress string          `json:"ip_address"`
}

type guestNetworkInterface struct {
	NIC        string `json:"nic"`
	MACAddress string `json:"mac_address"`
	IP         struct {
		IPAddresses []struct {
			IPAddress    string `json:"ip_address"`
			PrefixLength int    `json:"prefix_length"`
			Origin       string `json:"origin"`
			State        string `json:"state"`
		} `json:"ip_addresses"`
	} `json:"ip"`
}

func NewClient(source domain.VCenterSource, password string, timeout time.Duration, workers int) (*Client, error) {
	base, err := url.Parse(strings.TrimRight(source.BaseURL, "/"))
	if err != nil || base.Scheme == "" || base.Host == "" {
		return nil, errors.New("invalid vCenter base URL")
	}
	if workers < 1 {
		workers = 1
	}
	transport := &http.Transport{
		Proxy: nil,
		TLSClientConfig: &tls.Config{
			MinVersion:         tls.VersionTLS12,
			ServerName:         source.TLSServerName,
			InsecureSkipVerify: !source.VerifyTLS, // Configurable for private/offline vCenter PKI.
		},
		ForceAttemptHTTP2: true,
	}
	return &Client{
		baseURL:  base,
		username: source.Username,
		password: password,
		http:     &http.Client{Transport: transport, Timeout: timeout},
		workers:  workers,
	}, nil
}

func (c *Client) Test(ctx context.Context) (int, error) {
	session, err := c.createSession(ctx)
	if err != nil {
		return 0, err
	}
	defer c.deleteSession(context.Background(), session)
	var items []listVM
	if err := c.get(ctx, session, "/api/vcenter/vm", &items); err != nil {
		return 0, err
	}
	return len(items), nil
}

func (c *Client) Inventory(ctx context.Context) ([]RemoteVM, error) {
	session, err := c.createSession(ctx)
	if err != nil {
		return nil, err
	}
	defer c.deleteSession(context.Background(), session)

	var list []listVM
	if err := c.get(ctx, session, "/api/vcenter/vm", &list); err != nil {
		return nil, err
	}
	result := make([]RemoteVM, len(list))
	jobs := make(chan int)
	errCh := make(chan error, 1)
	workerCount := c.workers
	if workerCount > len(list) {
		workerCount = len(list)
	}
	if workerCount == 0 {
		return result, nil
	}
	var wg sync.WaitGroup
	for worker := 0; worker < workerCount; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for index := range jobs {
				item := list[index]
				vm, err := c.loadVM(ctx, session, item)
				if err != nil {
					select {
					case errCh <- fmt.Errorf("read VM %s (%s): %w", item.Name, item.VM, err):
					default:
					}
					return
				}
				result[index] = vm
			}
		}()
	}
	go func() {
		defer close(jobs)
		for i := range list {
			select {
			case <-ctx.Done():
				return
			case jobs <- i:
			}
		}
	}()
	wg.Wait()
	select {
	case err := <-errCh:
		return nil, err
	default:
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return result, nil
}

func (c *Client) loadVM(ctx context.Context, session string, item listVM) (RemoteVM, error) {
	vm := RemoteVM{
		MoID: item.VM, Name: item.Name, PowerState: item.PowerState,
		CPUCount: item.CPUCount, MemoryMiB: item.MemorySizeMiB,
		CustomAttributes: map[string]any{},
	}
	var info vmInfo
	if err := c.get(ctx, session, "/api/vcenter/vm/"+url.PathEscape(item.VM), &info); err != nil {
		return vm, err
	}
	if info.Identity.Name != "" {
		vm.Name = info.Identity.Name
	}
	vm.BIOSUUID = info.Identity.BIOSUUID
	vm.InstanceUUID = info.Identity.InstanceUUID
	vm.HardwareVersion = info.Hardware.Version
	vm.GuestOS = info.GuestOS
	if info.CPU.Count > 0 {
		vm.CPUCount = info.CPU.Count
	}
	if info.Memory.SizeMiB > 0 {
		vm.MemoryMiB = info.Memory.SizeMiB
	}
	if info.PowerState != "" {
		vm.PowerState = info.PowerState
	}
	// VMware Tools/guest identity is best effort: powered-off VMs or restricted
	// service accounts may legitimately return an error for this endpoint.
	var guest guestIdentity
	if err := c.get(ctx, session, "/api/vcenter/vm/"+url.PathEscape(item.VM)+"/guest/identity", &guest); err == nil {
		vm.GuestHostname = firstNonEmpty(guest.HostName, guest.Name)
		vm.PrimaryIP = guest.IPAddress
		if vm.GuestOS == "" {
			vm.GuestOS = localizedText(guest.FullName)
		}
	}
	// vCenter guest identity exposes only one primary IP. When VMware Tools is
	// available, guest networking exposes every address from every guest NIC.
	// This endpoint is best effort so older vCenter versions, powered-off VMs or
	// restricted accounts do not make the whole inventory synchronization fail.
	var interfaces []guestNetworkInterface
	if err := c.get(ctx, session, "/api/vcenter/vm/"+url.PathEscape(item.VM)+"/guest/networking/interfaces", &interfaces); err == nil {
		vm.GuestNetworkingAvailable = true
		vm.IPAddresses = guestIPv4Addresses(vm.PrimaryIP, interfaces)
	} else {
		vm.IPAddresses = guestIPv4Addresses(vm.PrimaryIP, nil)
	}
	return vm, nil
}

func guestIPv4Addresses(primary string, interfaces []guestNetworkInterface) []string {
	seen := map[string]struct{}{}
	out := make([]string, 0, 4)
	add := func(raw string) {
		ip := net.ParseIP(strings.TrimSpace(raw))
		if ip == nil || ip.To4() == nil || ip.IsLoopback() || ip.IsUnspecified() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() {
			return
		}
		value := ip.To4().String()
		if _, ok := seen[value]; ok {
			return
		}
		seen[value] = struct{}{}
		out = append(out, value)
	}
	add(primary)
	for _, iface := range interfaces {
		for _, address := range iface.IP.IPAddresses {
			add(address.IPAddress)
		}
	}
	return out
}

func (c *Client) createSession(ctx context.Context) (string, error) {
	req, err := c.request(ctx, http.MethodPost, "/api/session", nil)
	if err != nil {
		return "", err
	}
	req.SetBasicAuth(c.username, c.password)
	var raw json.RawMessage
	if err := c.do(req, &raw); err != nil {
		return "", fmt.Errorf("vCenter authentication failed: %w", err)
	}
	var session string
	if err := json.Unmarshal(raw, &session); err == nil && session != "" {
		return session, nil
	}
	var envelope struct {
		Value string `json:"value"`
	}
	if err := json.Unmarshal(raw, &envelope); err == nil && envelope.Value != "" {
		return envelope.Value, nil
	}
	return "", errors.New("vCenter authentication returned no session ID")
}

func (c *Client) deleteSession(ctx context.Context, session string) {
	if session == "" {
		return
	}
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	req, err := c.request(ctx, http.MethodDelete, "/api/session", nil)
	if err != nil {
		return
	}
	req.Header.Set("vmware-api-session-id", session)
	resp, err := c.http.Do(req)
	if err == nil {
		resp.Body.Close()
	}
}

func (c *Client) get(ctx context.Context, session, path string, target any) error {
	req, err := c.request(ctx, http.MethodGet, path, nil)
	if err != nil {
		return err
	}
	req.Header.Set("vmware-api-session-id", session)
	return c.do(req, target)
}

func (c *Client) request(ctx context.Context, method, path string, body []byte) (*http.Request, error) {
	rel, err := url.Parse(path)
	if err != nil {
		return nil, err
	}
	u := c.baseURL.ResolveReference(rel)
	var reader io.Reader
	if body != nil {
		reader = bytes.NewReader(body)
	}
	req, err := http.NewRequestWithContext(ctx, method, u.String(), reader)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Accept", "application/json")
	return req, nil
}

func (c *Client) do(req *http.Request, target any) error {
	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, maxResponseSize+1))
	if err != nil {
		return err
	}
	if len(body) > maxResponseSize {
		return errors.New("vCenter response exceeds size limit")
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		message := strings.TrimSpace(string(body))
		if len(message) > 500 {
			message = message[:500]
		}
		return fmt.Errorf("HTTP %d: %s", resp.StatusCode, message)
	}
	if target == nil || len(bytes.TrimSpace(body)) == 0 {
		return nil
	}
	if raw, ok := target.(*json.RawMessage); ok {
		*raw = append((*raw)[:0], body...)
		return nil
	}
	if err := json.Unmarshal(body, target); err == nil {
		return nil
	}
	var envelope struct {
		Value json.RawMessage `json:"value"`
	}
	if err := json.Unmarshal(body, &envelope); err != nil || len(envelope.Value) == 0 {
		return errors.New("invalid JSON returned by vCenter")
	}
	if err := json.Unmarshal(envelope.Value, target); err != nil {
		return fmt.Errorf("decode vCenter response: %w", err)
	}
	return nil
}

func localizedText(raw json.RawMessage) string {
	if len(bytes.TrimSpace(raw)) == 0 || bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
		return ""
	}
	var value string
	if err := json.Unmarshal(raw, &value); err == nil {
		return strings.TrimSpace(value)
	}
	var message struct {
		Localized      string `json:"localized"`
		DefaultMessage string `json:"default_message"`
		ID             string `json:"id"`
	}
	if err := json.Unmarshal(raw, &message); err != nil {
		return ""
	}
	return firstNonEmpty(message.Localized, message.DefaultMessage, message.ID)
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}
