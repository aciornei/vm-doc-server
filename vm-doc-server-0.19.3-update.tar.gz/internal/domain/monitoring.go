package domain

import (
	"encoding/json"
	"time"
)

type PrometheusSource struct {
	ID                  int64      `json:"id"`
	SecretRef           string     `json:"-"`
	Name                string     `json:"name"`
	BaseURL             string     `json:"base_url"`
	SourceType          string     `json:"source_type"`
	Username            string     `json:"username,omitempty"`
	AuthMode            string     `json:"auth_mode"`
	VMLabel             string     `json:"vm_label,omitempty"`
	TargetLabel         string     `json:"target_label,omitempty"`
	AgentID             *int64     `json:"agent_id,omitempty"`
	AgentName           string     `json:"agent_name,omitempty"`
	AgentVersion        string     `json:"agent_version,omitempty"`
	AgentInventoryID    *int64     `json:"agent_inventory_id,omitempty"`
	Enabled             bool       `json:"enabled"`
	VerifyTLS           bool       `json:"verify_tls"`
	TLSServerName       string     `json:"tls_server_name,omitempty"`
	SyncIntervalMinutes int        `json:"sync_interval_minutes"`
	SecretConfigured    bool       `json:"secret_configured"`
	LastSyncAt          *time.Time `json:"last_sync_at,omitempty"`
	LastSuccessAt       *time.Time `json:"last_success_at,omitempty"`
	LastError           string     `json:"last_error,omitempty"`
	CreatedAt           time.Time  `json:"created_at"`
	UpdatedAt           time.Time  `json:"updated_at"`
}

type PrometheusSyncRun struct {
	ID                   int64      `json:"id"`
	PrometheusSourceID   int64      `json:"prometheus_source_id"`
	PrometheusSourceName string     `json:"prometheus_source_name,omitempty"`
	Source               string     `json:"source"`
	Status               string     `json:"status"`
	RequestedByUserID    *int64     `json:"requested_by_user_id,omitempty"`
	StartedAt            *time.Time `json:"started_at,omitempty"`
	FinishedAt           *time.Time `json:"finished_at,omitempty"`
	TargetCount          int        `json:"target_count"`
	MatchedVMCount       int        `json:"matched_vm_count"`
	UpCount              int        `json:"up_count"`
	DownCount            int        `json:"down_count"`
	UnmatchedCount       int        `json:"unmatched_count"`
	AmbiguousCount       int        `json:"ambiguous_count"`
	ErrorMessage         string     `json:"error_message,omitempty"`
	CreatedAt            time.Time  `json:"created_at"`
}

type MonitoringTarget struct {
	ID                    int64           `json:"id"`
	PrometheusSourceID    int64           `json:"prometheus_source_id"`
	PrometheusSourceName  string          `json:"prometheus_source_name"`
	SourceType            string          `json:"source_type"`
	Fingerprint           string          `json:"fingerprint"`
	JobName               string          `json:"job_name,omitempty"`
	Instance              string          `json:"instance,omitempty"`
	ScrapeURL             string          `json:"scrape_url,omitempty"`
	TargetURL             string          `json:"target_url,omitempty"`
	Health                string          `json:"health,omitempty"`
	LastError             string          `json:"last_error,omitempty"`
	LastScrapeAt          *time.Time      `json:"last_scrape_at,omitempty"`
	ScrapeDurationSeconds *float64        `json:"scrape_duration_seconds,omitempty"`
	ProbeSuccess          *bool           `json:"probe_success,omitempty"`
	HTTPStatusCode        *int            `json:"http_status_code,omitempty"`
	ProbeDurationSeconds  *float64        `json:"probe_duration_seconds,omitempty"`
	TLSExpiryAt           *time.Time      `json:"tls_expiry_at,omitempty"`
	LabelsJSON            json.RawMessage `json:"labels,omitempty"`
	DiscoveredLabelsJSON  json.RawMessage `json:"discovered_labels,omitempty"`
	MatchedVMID           *int64          `json:"matched_vm_id,omitempty"`
	MatchedVMName         string          `json:"matched_vm_name,omitempty"`
	MatchMethod           string          `json:"match_method,omitempty"`
	MatchValue            string          `json:"match_value,omitempty"`
	MatchConfidence       string          `json:"match_confidence,omitempty"`
	SyncedAt              time.Time       `json:"synced_at"`
}

type MonitoringAlias struct {
	ID        int64     `json:"id"`
	VMID      int64     `json:"vm_id"`
	Alias     string    `json:"alias"`
	CreatedAt time.Time `json:"created_at"`
}

type VMMonitoringSummary struct {
	VMID              int64              `json:"vm_id"`
	VMName            string             `json:"vm_name,omitempty"`
	PowerState        string             `json:"power_state,omitempty"`
	VCenterIPs        []string           `json:"vcenter_ips,omitempty"`
	ExporterInstalled bool               `json:"exporter_installed"`
	ExporterRunning   bool               `json:"exporter_running"`
	ExporterVersion   string             `json:"exporter_version,omitempty"`
	ExporterEndpoint  string             `json:"exporter_endpoint,omitempty"`
	MetricsTargets    []MonitoringTarget `json:"metrics_targets"`
	BlackboxTargets   []MonitoringTarget `json:"blackbox_targets"`
	Aliases           []MonitoringAlias  `json:"aliases"`
	MetricsMonitored  bool               `json:"metrics_monitored"`
	MetricsUp         bool               `json:"metrics_up"`
	BlackboxMonitored bool               `json:"blackbox_monitored"`
	BlackboxUp        bool               `json:"blackbox_up"`
	MonitoringState   string             `json:"monitoring_state"`
}
