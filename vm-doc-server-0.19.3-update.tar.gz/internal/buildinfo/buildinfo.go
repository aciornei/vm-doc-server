package buildinfo

var (
	Version = "0.19.3-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
