-- 0.19.3: toate IPv4-urile guest raportate de vCenter pentru corelare sigură.

CREATE TABLE IF NOT EXISTS vcenter_vm_ips (
  vm_id BIGINT UNSIGNED NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  is_primary TINYINT(1) NOT NULL DEFAULT 0,
  source VARCHAR(32) NOT NULL DEFAULT 'guest_networking',
  synced_at DATETIME(6) NOT NULL,
  PRIMARY KEY (vm_id, ip_address),
  KEY idx_vcenter_vm_ips_address (ip_address),
  CONSTRAINT fk_vcenter_vm_ips_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
