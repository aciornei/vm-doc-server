# Upgrade VM-DOC Server 0.20.80 → 0.20.81

0.20.81 rafinează Network Map. Nu există migrare DB și nu este necesar un nou Sync FortiGate: IP-urile sunt citite din corelările existente `fortigate_vm_matches.vm_ip`.

## Pași

```bash
systemctl stop vm-doc-server
cp -a /usr/local/src/vm-doc-server-0.20.80 /usr/local/src/vm-doc-server-0.20.81
tar -xzf vm-doc-server-0.20.81-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.81
cd /usr/local/src/vm-doc-server-0.20.81
# build/deploy conform procedurii locale
systemctl start vm-doc-server
```

## Verificări

1. Deschide un VM → Securitate → Hartă rețea și verifică o regulă cu VM corelat în Sursă/Destinație.
2. Numele VM trebuie să apară o singură dată, iar dedesubt să apară `IP x.x.x.x`.
3. În policy, după numele regulii trebuie să existe spațiu și o linie separată `VDOM · NAT` sau `VDOM · FĂRĂ NAT`.
4. Serviciile rămân unul sub altul; UDP și DNS/53 rămân filtrate vizual ca în 0.20.80.

Agentul rămâne 1.7.12.
