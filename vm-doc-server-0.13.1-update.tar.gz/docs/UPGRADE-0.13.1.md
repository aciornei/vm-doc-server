# Upgrade la vm-doc-server 0.13.1

0.13.1 este un release de administrare pentru modulul **Agenți** și nu adaugă migrări MariaDB.

## Modificări

- navigare orizontală în pagina Agenți;
- OS și versiune OS raportate de inventarul curent;
- căutare după OS;
- export Excel pentru agenți;
- Release-uri agent cu filtre, paginare și export Excel;
- formularul Adaugă release este colapsat implicit;
- toate paginările au implicit 10 elemente.

## Upgrade din 0.13.0

Păstrează configurația, secretele și directorul repository-ului de agent update. Nu rula nicio migrare manuală nouă.

Într-un arbore de sursă care conține deja `vendor/`:

```bash
cp -a /usr/local/src/vm-doc-server-0.13.0 /usr/local/src/vm-doc-server-0.13.1
tar -xzf vm-doc-server-0.13.1-update.tar.gz -C /usr/local/src/vm-doc-server-0.13.1
cd /usr/local/src/vm-doc-server-0.13.1
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
make build
```

Instalează binarele conform procedurii existente și repornește serviciul. După autentificare fă `Ctrl+F5` pentru a încărca JavaScript/CSS 0.13.1.

## Verificare

- `/version` trebuie să raporteze `0.13.1`;
- pagina Agenți trebuie să aibă meniul orizontal;
- căutarea `Ubuntu`, `Debian`, `Windows` etc. trebuie să filtreze după OS-ul raportat;
- exporturile Excel trebuie să respecte filtrele curente;
- Release-uri agent trebuie să pornească cu 10 rânduri/pagină.
