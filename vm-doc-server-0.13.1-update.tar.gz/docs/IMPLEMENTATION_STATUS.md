# Implementation status 0.13.1

## Implementat

- retenție automată `inventory_snapshots` cu protecția snapshot-urilor curente/documentate;
- Audit paginat și filtrabil, cu detalii before/after pentru operațiile instrumentate;
- model complet Rețea externă → Sistem extern → Conexiune externă;
- culoare/risc/trust/CIDR pentru rețele externe și integrare în UI, rapoarte și DOCX;

- fișă VM compactă pe subsecțiuni navigabile, cu tab-uri sticky și păstrarea secțiunii în URL;
- scor de completare VM bazat pe 11 criterii esențiale, afișat în listă și export;
- paginare configurabilă și memorată per nomenclator;
- pagina Agenți separată în listare și release-uri, cu căutare fără pierderea focusului;
- schemă logică automată a Serviciilor interne, cu VM-uri unice și asocieri multiple în același nod;
- pictograme configurabile pentru nomenclatoare prin `icon_key`;

- surse vCenter cu secrete criptate, sincronizare asincronă și programare zilnică;
- upsert VM și marcaj `missing` când o mașină nu mai este văzută în vCenter;
- corelare automată sau manuală cu agentul;
- listă VM, fișă tehnică structurată, căutare, paginare și export Excel;
- date operaționale independente de inventarul automat;
- catalog de servicii interne independent de încadrarea arhitecturală;
- domeniu și categorie de serviciu salvate pe fiecare asociere VM–serviciu;
- agregarea automată a domeniilor și categoriilor în pagina serviciului;
- roluri tehnice legate global de unul sau mai multe layer-e;
- selecție `domeniu–categorie–serviciu–layer–rol–tip soluție` pe fișa VM;
- asocieri multiple, cu tip de utilizare, prioritate și observații;
- validare server-side a relației categorie–domeniu și layer–rol;
- nomenclatoare grupate în submeniuri;
- registru de persoane și responsabilități multiple pe VM;
- structură separată de backup, pregătită pentru Veeam API;
- inventar agent structurat și restrâns implicit, istoric și audit paginate;
- generare DOCX pe bază de șabloane, previzualizare și istoric pentru VM și Serviciu intern;
- editor rich-text pentru Scop și domeniu / Obiective, cu bullets, numerotare, indentare și stiluri reproduse în DOCX;
- evidențiere PROD / TEST-UAT / DEV în pagina și documentația Serviciului intern;
- legături către fișele VM și pachete ZIP de documentație cu anexe VM versionate;
- modul Rapoarte cu indicatori, donut/pie charts, bar charts, timeline și liste de completitudine;
- pagină Agenți cu căutare, filtrare și paginare;
- listă Servicii cu descriere scurtată și filtre operaționale;
- servicii comune / globale pentru AD, DNS, LDAP, NTP, PKI și alte infrastructuri partajate;
- relații Serviciu → Serviciu comun și excepții VM → Serviciu comun, cu analiză de impact;
- dependențe comune afișate în UI, schema logică și fișele DOCX VM/Serviciu;
- servicii software principale selectabile din inventarul agentului, cu versiuni și propagare în fișele VM/Serviciu;
- etichete contextuale în inventarul agentului pentru stocare, porturi, conturi, cron și servicii, plus uptime umanizat;
- șabloane separate pe tip de obiect (`vm` / `service`) și documente de serviciu numerotate `FSI-*`;
- agregarea automată a tipurilor de soluție în pagina Serviciului intern;
- inventar agent compact în DOCX, cu tabele specializate și randare stabilă Word/LibreOffice;
- migrații, audit, RBAC și OpenAPI actualizate.

## Schimbări de model în 0.4.0

- serviciul intern nu mai are domeniu sau categorie de serviciu configurate manual;
- `vm_internal_service_assignments` păstrează domeniul și categoria alese pe VM;
- pagina serviciului agregă automat toate încadrările observate;
- același serviciu poate fi reutilizat în mai multe domenii și categorii;
- datele existente sunt migrate din vechea categorie a serviciului.

## Validare necesară în mediul offline final

Arhiva standard nu include `vendor/`. În sursa offline care păstrează dependențele executați:

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

## Limitări

- datele efective din Veeam API nu sunt încă sincronizate;
- serviciile nu au încă responsabilități proprii distincte de responsabilitățile VM-urilor;
- conversia PDF și semnarea digitală nu sunt încă implementate;
- custom attributes generale din vCenter nu sunt încă extrase;
- nu există încă worker automat pentru retenția inventarelor și auditului.

## 0.11.1

- publicare agent/updater prin multipart upload din UI;
- promovare testing → stable și ștergere release;
- SHA-256 și manifest atomic păstrate în backend;
- integrare cu vm-doc-agent 1.3.2 pentru versiuni de servicii.

## 0.11.0

- UI contextual pentru servicii, routes și firewall în pagina VM;
- Rapoarte pe subcategorii;
- Auto-update agent 1.3.0+ prin repository central stable/testing.
