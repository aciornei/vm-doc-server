# Changelog

## 0.13.1

- navigare orizontală în pagina Agenți;
- OS + versiune OS raportate de agent în listă și căutare;
- butoane compacte Test / Colect / Edit / Del;
- export Excel pentru agenți;
- publicarea unui release este colapsată implicit;
- release-uri cu filtre, paginare și export Excel;
- toate paginările pornesc implicit de la 10;
- fără migrare MariaDB.

## 0.13.0

- retenție configurabilă a snapshot-urilor de inventar și raportare a volumului de stocare;
- Audit paginat, filtrabil și cu before/after pentru operațiile principale instrumentate;
- obiect nou `external_networks`, cu culoare, tip zonă, risc, trust, CIDR-uri și metadate operaționale;
- sisteme externe asociate unei rețele externe și conexiuni către VM/Servicii interne;
- conectivitatea externă apare în UI, rapoarte și documentația DOCX;
- migrarea `026_inventory_retention_audit_external_systems.up.sql`.

## 0.12.0

- fișa VM împărțită în șapte subsecțiuni cu navigare sticky și URL dedicat;
- procent de completare pentru VM, vizibil în listă, rezumat și export Excel;
- paginare Nomenclatoare configurabilă 10/20/50/100/200, memorată pe categorie;
- pagina Agenți separată în listare și administrarea release-urilor;
- repară pierderea focusului în câmpul de căutare Agenți;
- fără migrare MariaDB nouă.

## 0.11.1

- administrare completă a repository-ului de agent din UI: publicare, promovare și ștergere;
- upload multipart protejat de RBAC `agents.manage` și CSRF;
- suport pentru rollout testing → stable;
- release recomandat împreună cu vm-doc-agent 1.3.2 pentru detecția robustă a versiunilor software.



## 0.11.0

- Servicii agent pe VM: căutare, filtru Active/Inactive/Toate și stare lângă nume;
- Network Routes afișate tabelar;
- Firewall Rules: reguli explicite separate de regulile tehnice backend și reguli brute ascunse implicit;
- Rapoarte împărțite în subcategorii;
- readuce repository-ul central de auto-update pentru vm-doc-agent 1.3.0+;
- pagina Agenți afișează versiunea agentului și release-urile publicate;
- fără migrare MariaDB nouă.

## 0.10.0

- servicii software principale selectabile din inventarul agentului;
- selecții persistente pe VM, independente de snapshotul curent;
- metadate de versiune software/pachet preluate din agentul 1.3.1+;
- componentele principale apar în fișa VM și sunt agregate în fișa Serviciului intern;
- renderer contextual pentru uptime, mount point, port, username, comandă cron și nume serviciu;
- migrarea `025_vm_primary_agent_services.up.sql`;
- OpenAPI și documentație actualizate.


## 0.9.1

- repară eroarea HTTP 500 la adăugarea unei dependențe directe `VM → Serviciu comun`;
- citirea dependențelor VM nu mai folosește un `UNION ALL` fragil în MariaDB, ci interogări separate agregate în aplicație;
- erorile de creare a unei dependențe directe pe VM sunt acum scrise explicit în log;
- fără migrare de bază de date.


## 0.9.0

- căutare, filtrare și paginare în pagina Agenți;
- filtre extinse și descriere scurtată în lista Serviciilor interne;
- carduri compacte în pagina serviciului și afișare condiționată a mediilor PROD/TEST/DEV;
- model nou pentru servicii comune și dependențe globale/explicite;
- nomenclator `dependency_type`;
- relații `internal_service_dependencies` și excepții `vm_common_service_dependencies`;
- servicii comune marcabile ca `is_common` și `implicit_global`;
- dependențe afișate în pagina VM, pagina serviciului și schema logică;
- VM-urile furnizor ale AD/DNS/LDAP și ale altor servicii comune sunt expuse în UI și documentație;
- fișele DOCX VM/Serviciu includ infrastructura comună și analiza de impact;
- rapoarte noi pentru servicii comune, tipuri de dependență și impact;
- migrarea `024_common_service_dependencies.up.sql`;
- OpenAPI și documentație actualizate.

## 0.8.0

- evidențiere explicită a mediilor **PROD / TEST / UAT / DEV** în pagina și fișa DOCX a Serviciului intern;
- lista VM-urilor serviciului afișează ultima fișă VM generată și link direct către document;
- generarea documentației serviciului poate fixa fișele VM ca anexe și poate regenera automat fișele lipsă sau toate fișele;
- pachet ZIP reproductibil cu fișa serviciului și versiunile exacte ale fișelor VM anexate;
- tabel `service_document_annexes` pentru relația dintre o fișă de serviciu și documentele VM folosite la generare;
- meniu nou **Rapoarte**, cu indicatori, pie/donut charts, bar charts și evoluția documentelor generate;
- rapoarte pentru medii, power state, CPU/RAM, OS, vCenter, agenți, backup, inventar, documentare, criticitate, domenii, categorii, layer-e, roluri, tip soluție și completitudinea asocierilor;
- liste de servicii și VM-uri cu informații lipsă pentru completarea documentației;
- permisiune nouă `reports.read`;
- migrarea `023_reports_service_annexes.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.3

- hotfix pentru editorul rich-text: clickul în **Scop și domeniu** / **Obiective** păstrează focusul în zona editabilă în loc să activeze butonul Bold;
- structură HTML corectată și îmbunătățiri de accesibilitate;
- fără migrare de bază de date.


## 0.7.2

- editor rich-text pentru **Scop și domeniu** și **Obiective**;
- suport pentru paragrafe, newline, bold, italic, underline, bullets, numerotare și indentare;
- model rich-text JSON restricționat și validat server-side, fără stocare de HTML executabil;
- compatibilitate menținută prin câmpurile plain-text `purpose` / `objectives`;
- randare rich-text în pagina serviciului și în DOCX;
- conversie automată din textul existent la prima afișare/editare;
- migrarea `022_service_rich_text.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.1

- câmp narativ **Scop și domeniu** pentru serviciul intern, reutilizând `purpose` pentru compatibilitate;
- câmp nou **Obiective** pe serviciul intern;
- afișare aerisită a Descrierii, Scopului și domeniului și Obiectivelor;
- schema logică a serviciului inclusă automat în DOCX;
- un singur nod per VM în schema DOCX, cu toate asocierile și rolurile acelui VM;
- placeholdere `{{service.scope_domain}}` și `{{service.objectives}}`;
- migrarea `021_service_scope_objectives_docx_diagram.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.0

- schemă automată a serviciului, agregată din asocierile VM;
- un singur nod per VM, cu multiple asocieri afișate în același nod;
- grupare pe layer și zonă Multi-layer;
- pictograme configurabile prin `icon_key` în nomenclatoare;
- iconițe implicite pentru clasificare, layere, roluri și tipuri de soluție;
- export Excel nomenclatoare extins cu pictograma;
- migrarea `020_service_diagram_icons.up.sql`;
- OpenAPI și documentația actualizate.



## 0.6.0

- nomenclator `solution_type` și valori inițiale Open source / Dezvoltată intern / Comercială;
- `solution_type_id` pe asocierea VM–serviciu–layer–rol;
- interfață aerisită, pe carduri, pentru asocierile serviciilor din fișa VM;
- agregare tip soluție în lista și pagina Serviciilor interne;
- șabloane DOCX tipizate `vm` / `service` și șablon implicit pentru serviciu intern;
- previzualizare, generare, istoric și descărcare DOCX pentru Serviciu intern;
- numere de document `FSI-*` pentru fișele de serviciu;
- OpenAPI, documentație și migrarea `019_service_documents_solution_type.up.sql` actualizate.


## 0.5.1

- inventarul agentului este randat în tabele compacte, specifice fiecărei secțiuni, în locul flatten-ului generic;
- eliminate din document secțiunile Agent și Proxy și câmpul `uptime_seconds`;
- stocare în format partiție/filesystem/capacitate cu unități lizibile;
- rețea pe câte un rând pentru adresă și interfață;
- numai servicii active, porturi esențiale, reguli UFW numbered și conturi relevante;
- rezumat SSSD și matrice compactă pentru Auditbeat, Filebeat, GLPI Agent, Node Exporter și Syslog;
- cron și NTP simplificate; politici lăsate pregătite pentru completare ulterioară;
- tabele DOCX cu grilă explicită și lățimi fixe, compatibile cu randarea LibreOffice;
- fără migrare de bază de date.

## 0.5.0

- generator DOCX pentru fișa tehnică a VM-ului, disponibil direct în pagina VM;
- previzualizare a datelor și avertismente pentru inventar, servicii sau responsabilități lipsă;
- șabloane DOCX încărcabile și administrabile, cu șablon implicit creat automat;
- placeholder obligatoriu `{{VM_DOCUMENT_BODY}}` și placeholdere scalare pentru antetul șablonului;
- documentul include identificare, resurse, date operaționale, servicii, roluri, responsabilități, backup și inventarul structurat al agentului;
- istoric al documentelor generate, număr unic, fișier, dimensiune, SHA-256, autor și snapshot sursă;
- permisiuni noi `documents.read` și `documents.manage`;
- migrarea `018_document_generation.up.sql` creează `document_templates` și `generated_documents`.

## 0.4.4

- toate valorile nomenclatoarelor sunt sortate consecvent după ordinea părintelui, apoi după ordinea proprie și denumire;
- categoriile de serviciu sunt grupate după ordinea domeniului arhitectural;
- rolurile tehnice sunt grupate după primul layer în ordinea layer-elor, apoi după ordinea proprie; valorile nemapate sunt afișate la final;
- registrul Persoane este ordonat după departament, apoi după nume;
- filtre pe fiecare pagină de nomenclator: căutare text și stare, plus domeniu pentru categorii și layer pentru roluri;
- filtre suplimentare pentru Persoane: departament, sursă și stare;
- paginarea se aplică rezultatului filtrat, iar exportul Excel păstrează lista completă în ordinea nouă;
- fără migrare de bază de date.

## 0.4.3

- paginare pentru toate nomenclatoarele și pentru registrul Persoane, cu dimensiune selectabilă a paginii;
- export Excel pentru nomenclatorul curent, disponibil tuturor utilizatorilor cu permisiunea `nomenclatures.read`;
- exportul include toate rândurile active și inactive, nu numai pagina vizibilă;
- coloane relaționale în Excel pentru `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- export complet pentru persoane, inclusiv departament, sursă și cont AD;
- fără migrare de bază de date.

## 0.4.2

- corectată interogarea de citire a inventarului după ID: parametrul `id` este transmis către `QueryRowContext`;
- eliminată eroarea MariaDB `Error 1064 ... near '?' at line 1` la deschiderea fișei VM;
- inventarul curent și vederea structurată a JSON-ului agentului se încarcă din nou fără recollectare;
- fără migrare de bază de date.

## 0.4.1

- termenul vizibil **Categorie ITIL** este înlocuit cu **Categorie de serviciu**; cheia tehnică `itil_category` rămâne neschimbată pentru compatibilitate;
- integrare de tip director cu Active Directory, reutilizând gazdele LDAP, TLS-ul și contul bind deja configurate pentru autentificare;
- OU rădăcină configurabil, citire recursivă a utilizatorilor și afișare arborescentă după sub-OU-uri;
- filtrare obligatorie după atributul `department`, cu primul departament în ordine alfabetică selectat implicit sau cu un departament implicit configurabil;
- import multiplu și actualizare idempotentă a persoanelor din AD în registrul local de responsabilități, folosind `objectGUID` ca identitate stabilă;
- persoanele importate păstrează sursa LDAP și contul AD, iar reimportul actualizează numele, e-mailul, telefonul și departamentul;
- migrarea `017_service_category_ad_directory.up.sql` actualizează eticheta nomenclatorului și extinde tabelul `people` cu identitatea de director;
- migrarea `016_vm_service_classification.up.sql` este corectată astfel încât indexul nou să fie creat înainte de eliminarea indexului folosit de cheia externă.

## 0.4.0

- domeniul arhitectural și categoria de serviciu sunt mutate de la serviciul intern la asocierea VM–serviciu;
- formularul serviciului intern păstrează numai identitatea, descrierea, criticitatea și informațiile de documentare;
- fișa VM adaugă selectorul Categorie de serviciu între Domeniu și Serviciu intern;
- domeniul filtrează categoriile de serviciu, iar layer-ul filtrează rolurile tehnice;
- pagina și lista Servicii agregă automat încadrările domeniu–categorie din VM-uri;
- VM-urile din pagina serviciului afișează încadrarea folosită de fiecare asociere;
- validare backend pentru relația `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- migrarea `016_vm_service_classification.up.sql` păstrează încadrările existente și extinde cheia unică a asocierii.

## 0.3.9

- pagina Nomenclatoare nu mai afișează toate listele simultan;
- submeniu lateral grupat în Catalog servicii, Arhitectură tehnică, Operare VM și Responsabilități;
- se afișează o singură listă la un moment dat, cu numărul valorilor în submeniu;
- ruta păstrează categoria selectată, de exemplu `#nomenclatures/technical_role`;
- pe ecrane înguste, submeniul devine o grilă adaptivă de opțiuni;
- actualizarea este exclusiv de interfață și nu necesită migrare MariaDB.

## 0.3.8

- selecție în cascadă pe fișa VM: domeniu → serviciu intern → layer → rol tehnic;
- serviciile interne nu mai păstrează configurații layer–rol proprii; combinațiile observate sunt agregate automat din asocierile VM;
- validarea backend verifică serviciul și relația globală layer–rol, fără o restricție suplimentară la nivelul serviciului;
- selector multiplu cu căutare, stil Select2 și complet offline, pentru layer-ele permise ale unui rol tehnic;
- rolurile tehnice sunt ordonate după ordinea layer-ului, apoi după ordinea rolului;
- endpointul de modificare a combinațiilor layer–rol pe serviciu a fost eliminat din API și OpenAPI;
- actualizarea nu necesită migrare de schemă.

## 0.3.7

- fiecare rol tehnic este legat explicit de unul sau mai multe layer-e arhitecturale;
- rolurile sunt filtrate după layer în configurarea serviciului intern;
- validare server-side globală layer–rol, suplimentară față de validarea serviciului;
- relațiile deja folosite sunt migrate automat prin `015_layer_technical_role_mappings.up.sql`;
- relațiile utilizate nu pot fi eliminate accidental;
- Nomenclatoare afișează layer-ele permise pentru fiecare rol tehnic.

## 0.3.6

- relație multiplă VM–serviciu intern–layer–rol tehnic;
- mai multe servicii interne și mai multe roluri pentru același serviciu pe un singur VM;
- tip de utilizare `dedicated`, `shared` sau `dependency`, marcaj principal și observații pe asociere;
- profilul/data provisionării eliminate din modelul funcțional și din nomenclatoare;
- vechiul lifecycle `Retired` migrat la `Status operațional: Retras` și eliminat din interfața/API curent;
- cardul redundant „Rezumat ultimul inventar” eliminat;
- migrarea `014_multi_service_assignments.up.sql`, API, OpenAPI și documentație actualizate.

## 0.3.5

- fișa VM continuă să se încarce dacă datele operaționale sau sumarul de backup au o eroare;
- toate etapele de încărcare a fișei VM sunt jurnalizate cu `stage` și `vm_id`;
- versiunea din interfață este citită din `/version`, nu mai este hard-codată.

## 0.3.4

- pagina VM se încarcă degradat dacă datele agentului, snapshotul curent sau vederea structurată nu pot fi citite;
- erorile opționale din fișa VM sunt jurnalizate cu etapa exactă și `vm_id`;
- interfața afișează un avertisment fără a bloca datele vCenter și operaționale.

## 0.3.3

- secțiunile cu datele colectate de agent sunt restrânse implicit, inclusiv listele de obiecte din interior;
- istoricul inventarelor VM este paginat server-side, cu 10, 20, 50 sau 100 de înregistrări pe pagină;
- pagina Audit este paginată server-side, cu 25, 50, 100 sau 200 de evenimente pe pagină;
- endpointurile de inventar și audit acceptă `page` și `page_size` și întorc metadate de paginare;
- OpenAPI, testele și documentația de upgrade au fost actualizate;
- include corecția de compilare pentru funcția `nullableInt64Ptr` din 0.3.2.

## 0.3.2

- meniu principal **Servicii** pentru catalogul serviciilor interne;
- `Serviciu` ITIL este redenumit **Categorie de serviciu**, iar vechea `Componentă` devine **Serviciu intern**;
- ierarhie validată `Domeniu arhitectural → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- categoriile de serviciu sunt legate de domeniul arhitectural părinte;
- fiecare serviciu definește explicit combinațiile layer–rol permise;
- fișa VM folosește list-box-uri în cascadă și backendul respinge combinațiile incompatibile;
- pagina serviciului afișează descrierea, criticitatea, starea documentației, combinațiile permise și VM-urile asociate;
- migrare automată a datelor 0.3.1 și permisiuni RBAC `services.read` / `services.manage`;
- API și OpenAPI pentru catalogul serviciilor prin migrarea `013_internal_service_catalog.up.sql`.

## 0.3.1

- meniu nou **Nomenclatoare** pentru serviciu, componentă, domeniu arhitectural, layer, mediu, status operațional, profil de provisionare și clasificare;
- câmpurile controlate din fișa VM sunt list-box-uri și nu mai acceptă text liber;
- registru de persoane și mai multe responsabilități pe aceeași VM;
- secțiune separată **Backup și restaurare · Veeam**, cu model de date pregătit pentru sincronizarea prin API;
- migrarea automată a valorilor și responsabililor existenți din 0.3.0;
- endpointuri API, audit și OpenAPI pentru nomenclatoare și persoane;
- migrarea `012_nomenclatures_responsibilities_backup.up.sql`.

## 0.3.0

- pagină VM refăcută ca fișă tehnică structurată pe carduri și secțiuni pliabile;
- vedere sigură a inventarului agentului, cu mascarea câmpurilor sensibile;
- date operaționale separate de snapshoturile agentului și sincronizarea vCenter;
- tabel nou `vm_operational_metadata` prin migrarea 011;
- endpoint `PUT /api/v1/vms/{id}/operational` și audit `vm.operational.update`;
- formular pentru serviciu, componentă, domeniu, layer, mediu, status, scop, responsabili, provisionare, RPO/RTO, backup, clasificare și referințe;
- OpenAPI, documentație și teste actualizate.

## 0.2.2

- autoînregistrare pentru vm-doc-agent 1.1.0;
- heartbeat și stare online/offline fără creare manuală;
- push direct al inventarului;
- asociere automată cu VM după UUID;
- migrarea 010 și documentația de upgrade.


## 0.2.1

- căutare și filtre VM după nume/hostname, power, OS, IP, agent, `Retired` și sursă vCenter;
- paginare server-side și selector 25/50/100/200 înregistrări;
- statistici pentru rezultatele filtrate;
- export Excel `.xlsx` fără dependențe Go suplimentare;
- antet fix corect în tabelul VM, fără suprapunerea primului rând;
- API-ul `GET /api/v1/vms` întoarce un obiect paginat;
- endpoint nou `GET /api/v1/vms/export`;
- listele vCenter goale sunt serializate ca `[]`, nu `null`;
- rutele Swagger sunt înregistrate explicit ca `GET`, evitând panic în Go 1.23.

## 0.2.0

- vCenter devine sursa principală pentru lista de VM-uri;
- CRUD pentru surse vCenter, cu parolă criptată și verificare TLS;
- sincronizare manuală per sursă sau pentru toate sursele;
- scheduler zilnic configurabil per sursă, în fusul orar al aplicației;
- tabele `vcenter_sources`, `virtual_machines` și `vcenter_sync_runs`;
- VM-urile absente sunt marcate `missing_from_vcenter`, fără ștergere automată;
- lifecycle local `Retired`, cu dată, utilizator și notă;
- asociere automată după BIOS/DMI UUID, inclusiv ordinea SMBIOS legacy VMware;
- asociere manuală și dezlegare agent din fișa VM;
- stare agent și colectare manuală direct din fișa VM;
- parser pentru `agent.id`, `agent.version`, `collection.collectors`, FQDN și UUID-uri de corelare;
- listă VM, filtre, pagină de detaliu și istoric sincronizări în frontend;
- permisiuni RBAC noi: `vcenter.read`, `vcenter.manage`, `vms.manage`;
- OpenAPI 3.1 și documentație actualizate.

## 0.1.0

- două binare: `vm-doc-server` și `vm-doc-collector`;
- configurație YAML și secrete criptate AES-256-GCM;
- migrații MariaDB incluse în binar;
- autentificare LDAP și Keycloak/OIDC cu PKCE;
- sesiuni server-side, CSRF și RBAC;
- administrarea agenților și tokenuri criptate individual;
- joburi manuale și periodice cu lease;
- testare agent, colectare, UUID binding și validare schemă 2.x;
- snapshoturi brute, istoric, hash și stare online/offline;
- audit server/collector;
- frontend static fără Node.js;
- OpenAPI 3.1 și Swagger UI embedded;
- unități systemd și reverse proxy Nginx.
