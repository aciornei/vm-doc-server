package audit

import "testing"

func TestNormalizePagination(t *testing.T) {
	page, pageSize := NormalizePagination(-1, 0)
	if page != 1 || pageSize != 10 {
		t.Fatalf("unexpected defaults: page=%d pageSize=%d", page, pageSize)
	}
	page, pageSize = NormalizePagination(4, 999)
	if page != 4 || pageSize != 200 {
		t.Fatalf("unexpected normalized values: page=%d pageSize=%d", page, pageSize)
	}
}
