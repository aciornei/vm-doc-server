package audit

import (
	"context"
	"database/sql"
	"encoding/json"
	"strings"
	"time"
)

type Event struct {
	Source        string
	ActorUserID   *int64
	ActorUsername string
	Action        string
	ResourceType  string
	ResourceID    string
	Outcome       string
	RequestID     string
	IPAddress     string
	UserAgent     string
	Details       any
}

type Service struct{ DB *sql.DB }

func (s Service) Log(ctx context.Context, e Event) error {
	if e.Source == "" {
		e.Source = "server"
	}
	if e.Outcome == "" {
		e.Outcome = "success"
	}
	b, err := json.Marshal(e.Details)
	if err != nil {
		return err
	}
	if string(b) == "null" {
		b = []byte("{}")
	}
	_, err = s.DB.ExecContext(ctx, `INSERT INTO audit_events(occurred_at,source,actor_user_id,actor_username,action,resource_type,resource_id,outcome,request_id,ip_address,user_agent,details_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, time.Now().UTC(), e.Source, e.ActorUserID, e.ActorUsername, e.Action, e.ResourceType, e.ResourceID, e.Outcome, e.RequestID, e.IPAddress, e.UserAgent, b)
	return err
}

type Record struct {
	ID                int64           `json:"id"`
	OccurredAt        time.Time       `json:"occurred_at"`
	Source            string          `json:"source"`
	ActorUsername     string          `json:"actor_username"`
	Action            string          `json:"action"`
	ActionLabel       string          `json:"action_label"`
	ActionDescription string          `json:"action_description"`
	Operation         string          `json:"operation"`
	ResourceType      string          `json:"resource_type"`
	ResourceID        string          `json:"resource_id"`
	Outcome           string          `json:"outcome"`
	IPAddress         string          `json:"ip_address"`
	Details           json.RawMessage `json:"details"`
}

const (
	defaultPageSize = 10
	maxPageSize     = 200
)

type Page struct {
	Items    []Record `json:"items"`
	Page     int      `json:"page"`
	PageSize int      `json:"page_size"`
	Total    int      `json:"total"`
	Pages    int      `json:"pages"`
}

type Filter struct {
	Page         int
	PageSize     int
	Query        string
	Source       string
	Actor        string
	Action       string
	ResourceType string
	Outcome      string
	From         *time.Time
	To           *time.Time
}

type Facets struct {
	Sources       []string `json:"sources"`
	Actors        []string `json:"actors"`
	Actions       []string `json:"actions"`
	ResourceTypes []string `json:"resource_types"`
	Outcomes      []string `json:"outcomes"`
}

func NormalizePagination(page, pageSize int) (int, int) {
	if page < 1 {
		page = 1
	}
	if pageSize <= 0 {
		pageSize = defaultPageSize
	}
	if pageSize > maxPageSize {
		pageSize = maxPageSize
	}
	return page, pageSize
}

func (s Service) List(ctx context.Context, page, pageSize int) (Page, error) {
	return s.ListFiltered(ctx, Filter{Page: page, PageSize: pageSize})
}

func (s Service) ListFiltered(ctx context.Context, filter Filter) (Page, error) {
	filter.Page, filter.PageSize = NormalizePagination(filter.Page, filter.PageSize)
	where := make([]string, 0, 8)
	args := make([]any, 0, 12)
	if q := strings.TrimSpace(filter.Query); q != "" {
		like := "%" + q + "%"
		where = append(where, `(actor_username LIKE ? OR action LIKE ? OR resource_type LIKE ? OR resource_id LIKE ? OR ip_address LIKE ? OR details_json LIKE ?)`)
		args = append(args, like, like, like, like, like, like)
	}
	addEqual := func(column, value string) {
		if value = strings.TrimSpace(value); value != "" {
			where = append(where, column+"=?")
			args = append(args, value)
		}
	}
	addEqual("source", filter.Source)
	addEqual("actor_username", filter.Actor)
	addEqual("action", filter.Action)
	addEqual("resource_type", filter.ResourceType)
	addEqual("outcome", filter.Outcome)
	if filter.From != nil {
		where = append(where, "occurred_at>=?")
		args = append(args, *filter.From)
	}
	if filter.To != nil {
		where = append(where, "occurred_at<?")
		args = append(args, *filter.To)
	}
	clause := ""
	if len(where) > 0 {
		clause = " WHERE " + strings.Join(where, " AND ")
	}
	result := Page{Items: make([]Record, 0), Page: filter.Page, PageSize: filter.PageSize}
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM audit_events`+clause, args...).Scan(&result.Total); err != nil {
		return Page{}, err
	}
	if result.Total == 0 {
		return result, nil
	}
	result.Pages = (result.Total + result.PageSize - 1) / result.PageSize
	if result.Page > result.Pages {
		result.Page = result.Pages
	}
	offset := (result.Page - 1) * result.PageSize
	queryArgs := append(append([]any(nil), args...), result.PageSize, offset)
	rows, err := s.DB.QueryContext(ctx, `SELECT id,occurred_at,source,actor_username,action,resource_type,resource_id,outcome,ip_address,details_json FROM audit_events`+clause+` ORDER BY id DESC LIMIT ? OFFSET ?`, queryArgs...)
	if err != nil {
		return Page{}, err
	}
	defer rows.Close()
	for rows.Next() {
		var r Record
		if err := rows.Scan(&r.ID, &r.OccurredAt, &r.Source, &r.ActorUsername, &r.Action, &r.ResourceType, &r.ResourceID, &r.Outcome, &r.IPAddress, &r.Details); err != nil {
			return Page{}, err
		}
		r.ActionLabel, r.ActionDescription, r.Operation = DescribeAction(r.Action)
		result.Items = append(result.Items, r)
	}
	return result, rows.Err()
}

func (s Service) Facets(ctx context.Context) (Facets, error) {
	var out Facets
	queries := []struct {
		query  string
		target *[]string
	}{
		{`SELECT DISTINCT source FROM audit_events WHERE source<>'' ORDER BY source`, &out.Sources},
		{`SELECT DISTINCT actor_username FROM audit_events WHERE actor_username<>'' ORDER BY actor_username LIMIT 500`, &out.Actors},
		{`SELECT DISTINCT action FROM audit_events WHERE action<>'' ORDER BY action`, &out.Actions},
		{`SELECT DISTINCT resource_type FROM audit_events WHERE resource_type<>'' ORDER BY resource_type`, &out.ResourceTypes},
		{`SELECT DISTINCT outcome FROM audit_events WHERE outcome<>'' ORDER BY outcome`, &out.Outcomes},
	}
	for _, item := range queries {
		rows, err := s.DB.QueryContext(ctx, item.query)
		if err != nil {
			return Facets{}, err
		}
		values := make([]string, 0)
		for rows.Next() {
			var value string
			if err := rows.Scan(&value); err != nil {
				rows.Close()
				return Facets{}, err
			}
			values = append(values, value)
		}
		if err := rows.Close(); err != nil {
			return Facets{}, err
		}
		*item.target = values
	}
	return out, nil
}

func DescribeAction(action string) (label, description, operation string) {
	known := map[string][3]string{
		"agent.create":                       {"Agent adăugat", "A fost definit un agent nou în aplicație.", "created"},
		"agent.update":                       {"Agent modificat", "Configurația unui agent a fost modificată.", "updated"},
		"agent.delete":                       {"Agent șters", "Un agent a fost eliminat din aplicație.", "deleted"},
		"vm.update":                          {"VM modificat", "Atributele administrate local ale VM-ului au fost modificate.", "updated"},
		"vm.operational.update":              {"Date operaționale VM", "Datele operaționale, clasificarea sau responsabilitățile VM-ului au fost modificate.", "updated"},
		"vm.service_assignments.replace":     {"Servicii VM modificate", "Asocierile VM-ului la serviciile interne au fost înlocuite.", "updated"},
		"vm.primary_agent_service.update":    {"Serviciu principal VM", "Marcajul de serviciu software principal al VM-ului a fost modificat.", "updated"},
		"internal_service.create":            {"Serviciu adăugat", "A fost creat un serviciu intern.", "created"},
		"internal_service.update":            {"Serviciu modificat", "Datele serviciului intern au fost modificate.", "updated"},
		"nomenclature.item.create":           {"Valoare nomenclator adăugată", "A fost adăugată o valoare într-un nomenclator.", "created"},
		"nomenclature.item.update":           {"Valoare nomenclator modificată", "O valoare de nomenclator a fost modificată.", "updated"},
		"external_network.create":            {"Rețea externă adăugată", "A fost definită o rețea externă.", "created"},
		"external_network.update":            {"Rețea externă modificată", "Datele, culoarea sau clasificarea unei rețele externe au fost modificate.", "updated"},
		"external_network.delete":            {"Rețea externă ștearsă", "O rețea externă fără sisteme asociate a fost eliminată.", "deleted"},
		"external_system.create":             {"Sistem extern adăugat", "A fost definit un sistem extern.", "created"},
		"external_system.update":             {"Sistem extern modificat", "Datele unui sistem extern au fost modificate.", "updated"},
		"external_system.delete":             {"Sistem extern șters", "Un sistem extern și conexiunile sale au fost eliminate.", "deleted"},
		"external_connection.create":         {"Conexiune externă adăugată", "A fost definită o conexiune către sau dinspre un sistem extern.", "created"},
		"external_connection.update":         {"Conexiune externă modificată", "Parametrii unei conexiuni externe au fost modificați.", "updated"},
		"external_connection.delete":         {"Conexiune externă ștearsă", "O conexiune externă a fost eliminată.", "deleted"},
		"collection.queue":                   {"Colectare solicitată", "A fost introdus un job de test/colectare în coadă.", "operation"},
		"vm_document.generate":               {"Fișă VM generată", "A fost generată o fișă tehnică pentru un VM.", "operation"},
		"internal_service_document.generate": {"Fișă serviciu generată", "A fost generată documentația unui serviciu intern.", "operation"},
	}
	if item, ok := known[action]; ok {
		return item[0], item[1], item[2]
	}
	parts := strings.Split(action, ".")
	operation = "operation"
	if len(parts) > 0 {
		switch parts[len(parts)-1] {
		case "create", "publish", "add":
			operation = "created"
		case "update", "replace", "promote":
			operation = "updated"
		case "delete", "remove":
			operation = "deleted"
		}
	}
	label = strings.ReplaceAll(action, "_", " ")
	description = "Eveniment tehnic de audit: " + action + "."
	return label, description, operation
}
