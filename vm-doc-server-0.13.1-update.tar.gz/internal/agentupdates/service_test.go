package agentupdates

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestCompareVersions(t *testing.T) {
	if compareVersions("1.3.0", "1.2.9") <= 0 {
		t.Fatal("expected newer")
	}
	if compareVersions("1.3.0", "1.3.0") != 0 {
		t.Fatal("expected equal")
	}
}

func TestListPageFiltersAndPaginates(t *testing.T) {
	dir := t.TempDir()
	svc := Service{Directory: dir}
	if err := svc.Validate(); err != nil {
		t.Fatal(err)
	}
	files := filepath.Join(dir, "files")
	writeRelease := func(version, channel, osName, arch, notes string, valid bool) Release {
		agentName := "agent-" + version + "-" + channel + "-" + osName
		updaterName := "updater-" + version + "-" + channel + "-" + osName
		agent := []byte("agent-" + version)
		updater := []byte("updater-" + version)
		if valid {
			if err := os.WriteFile(filepath.Join(files, agentName), agent, 0644); err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(filepath.Join(files, updaterName), updater, 0644); err != nil {
				t.Fatal(err)
			}
		}
		ah := sha256.Sum256(agent)
		uh := sha256.Sum256(updater)
		return Release{Version: version, Channel: channel, OS: osName, Arch: arch, AgentFilename: agentName, AgentSHA256: hex.EncodeToString(ah[:]), AgentSizeBytes: int64(len(agent)), UpdaterFilename: updaterName, UpdaterSHA256: hex.EncodeToString(uh[:]), UpdaterSizeBytes: int64(len(updater)), PublishedAt: time.Now().UTC(), Notes: notes}
	}
	repo := Repository{Releases: []Release{
		writeRelease("1.3.3", "stable", "linux", "amd64", "production", true),
		writeRelease("1.3.4", "testing", "linux", "amd64", "pilot linux", true),
		writeRelease("1.3.4", "testing", "windows", "amd64", "pilot windows", false),
	}}
	raw, _ := json.Marshal(repo)
	if err := os.WriteFile(filepath.Join(dir, "releases.json"), raw, 0640); err != nil {
		t.Fatal(err)
	}

	page, err := svc.ListPage("pilot", "testing", "linux", "amd64", "valid", 1, 10)
	if err != nil {
		t.Fatal(err)
	}
	if page.Total != 1 || len(page.Items) != 1 || page.Items[0].OS != "linux" || !page.Items[0].Valid {
		t.Fatalf("unexpected filtered page: %+v", page)
	}
	invalid, err := svc.ListPage("", "testing", "windows", "amd64", "invalid", 1, 10)
	if err != nil {
		t.Fatal(err)
	}
	if invalid.Total != 1 || invalid.Items[0].Valid {
		t.Fatalf("unexpected invalid page: %+v", invalid)
	}
}
