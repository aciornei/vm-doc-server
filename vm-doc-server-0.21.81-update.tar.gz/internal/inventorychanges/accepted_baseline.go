package inventorychanges

import (
	"bytes"
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
)

// acceptedObjects resolves the per-VM accepted configuration. Unlike the old
// inventory_id watermark, this baseline is never advanced by routine collection.
// Only a deliberate review/ignore updates an individual object override.
func acceptedObjects(ctx context.Context, tx *sql.Tx, vmID int64, previousRaw []byte, primaryPorts map[portSelection]bool) (map[string]trackedObject, error) {
	var raw []byte
	err := tx.QueryRowContext(ctx, `SELECT raw_json FROM inventory_change_baseline_values WHERE vm_id=? FOR UPDATE`, vmID).Scan(&raw)
	if errors.Is(err, sql.ErrNoRows) {
		// Prefer the original baseline snapshot when it is still available. Older
		// installations may have pruned it, in which case use the prior snapshot.
		seed := append([]byte(nil), previousRaw...)
		var historical []byte
		lookupErr := tx.QueryRowContext(ctx, `SELECT i.raw_json FROM inventory_change_baselines b JOIN inventory_snapshots i ON i.id=b.inventory_id WHERE b.vm_id=?`, vmID).Scan(&historical)
		if lookupErr == nil && len(historical) > 0 {
			seed = historical
		} else if lookupErr != nil && !errors.Is(lookupErr, sql.ErrNoRows) {
			return nil, lookupErr
		}
		if _, err = tx.ExecContext(ctx, `INSERT IGNORE INTO inventory_change_baseline_values(vm_id,raw_json) VALUES(?,?)`, vmID, string(seed)); err != nil {
			return nil, err
		}
		if err = tx.QueryRowContext(ctx, `SELECT raw_json FROM inventory_change_baseline_values WHERE vm_id=? FOR UPDATE`, vmID).Scan(&raw); err != nil {
			return nil, err
		}
	} else if err != nil {
		return nil, err
	}
	base, err := extractTracked(raw)
	if err != nil {
		return nil, fmt.Errorf("accepted baseline inventory: %w", err)
	}
	base = semanticHistoryObjects(base, primaryPorts)
	rows, err := tx.QueryContext(ctx, `SELECT object_key,category,object_type,object_label,is_present,value_json FROM inventory_change_baseline_overrides WHERE vm_id=?`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var key, cat, typ, label string
		var present bool
		var value sql.NullString
		if err := rows.Scan(&key, &cat, &typ, &label, &present, &value); err != nil {
			return nil, err
		}
		if !present {
			delete(base, key)
			continue
		}
		var v any
		decoder := json.NewDecoder(strings.NewReader(value.String))
		decoder.UseNumber()
		if err := decoder.Decode(&v); err != nil {
			return nil, fmt.Errorf("baseline override %q: %w", key, err)
		}
		base[key] = trackedObject{Category: cat, Type: typ, Key: strings.TrimPrefix(key, cat+"|"+typ+"|"), Label: label, Value: v}
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return base, nil
}

func objectKeyHash(key string) string {
	sum := sha256.Sum256([]byte(key))
	return hex.EncodeToString(sum[:])
}

// acceptChange advances only the accepted version of this one object. The
// full-VM baseline is intentionally not replaced (other changes stay pending).
func acceptChange(ctx context.Context, tx *sql.Tx, vmID, userID int64, category, typ, key, label string, value []byte) error {
	var present int
	var val any
	if len(bytes.TrimSpace(value)) > 0 && string(bytes.TrimSpace(value)) != "null" {
		present = 1
		val = string(value)
	}
	var reviewer any
	if userID > 0 {
		reviewer = userID
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO inventory_change_baseline_overrides(vm_id,object_hash,object_key,category,object_type,object_label,is_present,value_json,accepted_by) VALUES(?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE object_key=VALUES(object_key),category=VALUES(category),object_type=VALUES(object_type),object_label=VALUES(object_label),is_present=VALUES(is_present),value_json=VALUES(value_json),accepted_by=VALUES(accepted_by),accepted_at=UTC_TIMESTAMP(6)`, vmID, objectKeyHash(key), key, category, typ, label, present, val, reviewer)
	return err
}

type pendingEvent struct {
	ID       int64
	Kind     string
	Old, New []byte
}

func pendingEvents(ctx context.Context, tx *sql.Tx, vmID int64) (map[string]pendingEvent, error) {
	rows, err := tx.QueryContext(ctx, `SELECT id,object_key,change_type,old_json,new_json FROM inventory_changes WHERE vm_id=? AND review_status='new' ORDER BY id DESC`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := map[string]pendingEvent{}
	for rows.Next() {
		var id int64
		var key, kind string
		var old, newv sql.NullString
		if err := rows.Scan(&id, &key, &kind, &old, &newv); err != nil {
			return nil, err
		}
		if _, ok := result[key]; ok {
			continue
		}
		result[key] = pendingEvent{ID: id, Kind: kind, Old: []byte(old.String), New: []byte(newv.String)}
	}
	return result, rows.Err()
}
