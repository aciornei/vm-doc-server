package inventorychanges

import "testing"

// Object-level baseline semantics: an unreviewed change remains outstanding
// even when the two latest inventories agree; reviewing one object does not
// accept an unrelated change on the same VM.
func TestAcceptedObjectBaselineDoesNotAdvanceUntilReview(t *testing.T) {
 basePort:=trackedObject{Category:"ports",Type:"listening_port",Key:"TCP/25",Label:"Port TCP/25",Value:map[string]any{"port":25}}
 changedPort:=trackedObject{Category:"ports",Type:"listening_port",Key:"TCP/25",Label:"Port TCP/25",Value:map[string]any{"port":25,"listening":true}}
 baseFirewall:=trackedObject{Category:"firewall",Type:"rule",Key:"fw-1",Label:"Regulă 1",Value:map[string]any{"action":"drop"}}
 changedFirewall:=trackedObject{Category:"firewall",Type:"rule",Key:"fw-1",Label:"Regulă 1",Value:map[string]any{"action":"accept"}}
 if !changedBetweenSnapshots(basePort,changedPort,true,true){t.Fatal("initial port change not detected")}
 // A week of identical incoming snapshots must not erase this difference.
 if !changedBetweenSnapshots(basePort,changedPort,true,true){t.Fatal("outstanding difference disappeared without review")}
 // Accepting the port alone leaves the firewall unreviewed.
 acceptedPort:=changedPort
 if changedBetweenSnapshots(acceptedPort,changedPort,true,true){t.Fatal("reviewed port remains active")}
 if !changedBetweenSnapshots(baseFirewall,changedFirewall,true,true){t.Fatal("unreviewed firewall change was hidden by unrelated port review")}
 // A return to accepted configuration is an automatic resolution.
 if changedBetweenSnapshots(baseFirewall,baseFirewall,true,true){t.Fatal("reverted difference should not stay in inbox")}
}
