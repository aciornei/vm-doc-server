package server

import (
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"vm-doc-server/internal/xlsx"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/inventorychanges"
)

// parseInventoryChangeFilter is used by both JSON list and Excel export so they
// share exactly the same VM / service / category / status filters.
func parseInventoryChangeFilter(r *http.Request) (inventorychanges.Filter, error) {
	q := r.URL.Query()
	f := inventorychanges.Filter{Query: q.Get("q"), SearchScope: q.Get("search_scope"), Category: q.Get("category"), ChangeType: q.Get("change_type"), DocumentationRequirement: q.Get("documentation_requirement"), ReviewStatus: q.Get("review_status"), Mode: q.Get("mode")}
	if v := q.Get("vm_id"); v != "" {
		id, err := strconv.ParseInt(v, 10, 64)
		if err != nil || id < 1 {
			return f, fmt.Errorf("invalid vm_id")
		}
		f.VMID = id
	}
	if v := q.Get("page"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 {
			return f, fmt.Errorf("invalid page")
		}
		f.Page = n
	}
	if v := q.Get("page_size"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 {
			return f, fmt.Errorf("invalid page_size")
		}
		f.PageSize = n
	}
	return f, nil
}

func (a *App) listInventoryChanges(w http.ResponseWriter, r *http.Request) {
	f, err := parseInventoryChangeFilter(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Changes.List(r.Context(), f)
	respond(w, value, err)
}

// exportInventoryChanges exports the full filtered result, not only the UI page.
// Never export inventory JSON: it may contain sensitive technical data and
// internal credential references intended to remain inside VM-DOC.
func (a *App) exportInventoryChanges(w http.ResponseWriter, r *http.Request) {
	f, err := parseInventoryChangeFilter(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	f.Page = 1
	f.PageSize = 200
	rows := [][]xlsx.Cell{{xlsx.Text("VM"), xlsx.Text("Hostname"), xlsx.Text("Detectat UTC"), xlsx.Text("Categorie"), xlsx.Text("Tip obiect"), xlsx.Text("Obiect"), xlsx.Text("Schimbare"), xlsx.Text("Rezumat"), xlsx.Text("Documentație"), xlsx.Text("Stare")}}
	const maxExportRows = 20000
	for {
		result, e := a.Changes.List(r.Context(), f)
		if e != nil {
			respond(w, nil, e)
			return
		}
		if result.Total > maxExportRows {
			badRequest(w, fmt.Errorf("exportul ar depăși %d de rânduri; restrânge filtrele", maxExportRows))
			return
		}
		for _, item := range result.Items {
			rows = append(rows, []xlsx.Cell{xlsx.Text(item.VMName), xlsx.Text(item.VMHostname), xlsx.Text(item.OccurredAt.UTC().Format("2006-01-02 15:04:05")), xlsx.Text(item.Category), xlsx.Text(item.ObjectType), xlsx.Text(item.ObjectLabel), xlsx.Text(item.ChangeType), xlsx.Text(item.Summary), xlsx.Text(item.DocumentationRequirement), xlsx.Text(item.ReviewStatus)})
		}
		if f.Page >= result.Pages || len(result.Items) == 0 {
			break
		}
		f.Page++
	}
	if err := writeXLSXResponse(w, "Modificari", "vm-doc-modificari", rows); err != nil {
		respond(w, nil, err)
	}
}

func (a *App) updateInventoryChange(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in inventorychanges.UpdateInput
	if err := decodeJSON(r, &in, 64<<10); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Changes.Update(r.Context(), id, user.ID, in)
	if err == nil {
		a.auditRequest(r, "inventory_change.review", "inventory_change", strconv.FormatInt(id, 10), "success", map[string]any{"documentation_requirement": value.DocumentationRequirement, "review_status": value.ReviewStatus, "notes": strings.TrimSpace(value.Notes)})
	}
	respond(w, value, err)
}

func (a *App) backfillInventoryChanges(w http.ResponseWriter, r *http.Request) {
	n, err := a.Changes.BackfillLatest(r.Context())
	if err == nil {
		a.auditRequest(r, "inventory_change.backfill", "inventory_change", "latest", "success", map[string]any{"inserted": n})
	}
	respond(w, map[string]any{"inserted": n}, err)
}

func (a *App) setInventoryChangesBaseline(w http.ResponseWriter, r *http.Request) {
	var in inventorychanges.BaselineInput
	if err := decodeJSON(r, &in, 16<<10); err != nil {
		badRequest(w, err)
		return
	}
	if in.VMID < 0 {
		badRequest(w, errors.New("invalid vm_id"))
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	n, err := a.Changes.SetBaseline(r.Context(), in.VMID, user.ID)
	if err == nil {
		target := "all"
		if in.VMID > 0 {
			target = strconv.FormatInt(in.VMID, 10)
		}
		a.auditRequest(r, "inventory_change.baseline", "inventory_change", target, "success", map[string]any{"vm_id": in.VMID, "vm_count": n})
	}
	respond(w, map[string]any{"vm_count": n}, err)
}
