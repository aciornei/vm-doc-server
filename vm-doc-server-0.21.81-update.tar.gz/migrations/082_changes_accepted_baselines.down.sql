DROP TABLE IF EXISTS inventory_change_baseline_overrides;
DROP TABLE IF EXISTS inventory_change_baseline_values;
-- Intentionally retain the safe inventory_id ON DELETE SET NULL FK; reverting
-- it to CASCADE risks permanent loss of review history during retention.
