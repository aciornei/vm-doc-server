-- Materialize the accepted inventory independently of snapshot retention.
-- The raw baseline preserves collection metadata; object-level overrides are
-- advanced only for individually reviewed or ignored differences.
CREATE TABLE IF NOT EXISTS inventory_change_baseline_values (
  vm_id BIGINT UNSIGNED NOT NULL,
  raw_json LONGTEXT NOT NULL,
  initialized_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (vm_id),
  CONSTRAINT fk_change_baseline_values_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inventory_change_baseline_overrides (
  vm_id BIGINT UNSIGNED NOT NULL,
  object_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  object_key VARCHAR(512) NOT NULL,
  category VARCHAR(64) NOT NULL,
  object_type VARCHAR(96) NOT NULL,
  object_label VARCHAR(512) NOT NULL,
  is_present TINYINT(1) NOT NULL,
  value_json MEDIUMTEXT NULL,
  accepted_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  accepted_by BIGINT UNSIGNED NULL,
  PRIMARY KEY (vm_id, object_hash),
  CONSTRAINT fk_change_baseline_override_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_change_baseline_override_user FOREIGN KEY (accepted_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Snapshot expiry must never cascade into the operator's review timeline.
ALTER TABLE inventory_changes DROP FOREIGN KEY fk_inventory_changes_inventory;
ALTER TABLE inventory_changes MODIFY COLUMN inventory_id BIGINT UNSIGNED NULL;
ALTER TABLE inventory_changes ADD CONSTRAINT fk_inventory_changes_inventory
  FOREIGN KEY (inventory_id) REFERENCES inventory_snapshots(id) ON DELETE SET NULL;
