# VM-DOC Server 0.21.81 — Baseline acceptat per obiect și timeline VM

## Comportament nou

- Inbox „Modificări” = evenimente **Nou**. Revizuit și Ignorat ies din inbox după salvare; nu sunt șterse din baza de date.
- Fiecare colectare validă este comparată semantic cu **starea acceptată a VM-ului**, nu doar cu snapshotul de ieri. Schimbările neanalizate rămân active chiar dacă se mențin mai multe săptămâni.
- Marcarea „Revizuit” acceptă doar valoarea **acelui obiect** în baseline. De exemplu, revizia unui port TCP nu acceptă simultan o regulă firewall nerevizuită. Marcarea „Ignorat” închide și acceptă obiectul fără a-l numi documentat.
- Înainte de revizie, o diferență persistentă produce **un singur rând activ per obiect**, actualizat cu valoarea cea mai nouă; dacă starea revine la baseline, diferența este închisă ca revenire automată.
- Fișa VM → Modificări include un **timeline paginat al reviziilor**, cu grupare calendaristică, autor (când e disponibil), dată, categoria, obiectul și dif-ul înainte/după.
- „Resetează baseline” rămâne o acțiune explicită pentru VM / toate VM-urile; acceptă întregul inventar curent și închide diferențele active ca ignorate. Nu este acțiunea implicită la revizie.
- Tabelul larg și help-ul derulează orizontal **în propriile containere**. Pagina nu capătă scrollbar orizontal de la modulul Modificări.

## Migrare 082 — executată de server la upgrade

- `inventory_change_baseline_values`: inventarul de plecare, reținut independent de rotația snapshoturilor.
- `inventory_change_baseline_overrides`: valorile acceptate individual prin review.
- `inventory_changes.inventory_id` devine nullable și cheia străină trece din `ON DELETE CASCADE` în `ON DELETE SET NULL`, pentru ca istoricul revizuit să nu fie șters odată cu snapshoturile brute.
- Migrarea **nu șterge** modificări, snapshoturi sau baseline-urile existente.
- La prima colectare după upgrade, baseline-ul persistent este inițializat din vechiul snapshot baseline dacă încă există. Dacă acel snapshot a fost deja curățat, baza pentru acel VM devine snapshotul precedent; prin urmare, diferențele dinainte de inițializare pot necesita verificare manuală.

## Semnificație workflow

- `Documentație = Necesită` + `Stare = Nou`: obligație încă nerevizuită.
- `Stare = Revizuit`: analizat, acceptat în baseline și mutat în timeline; **nu este echivalent cu Documentat**, nu publică automat în Outline.
- `Stare = Ignorat`: închis și acceptat fără obligație de documentare suplimentară. Pentru a evita un warning de completitudine, un eveniment fără impact trebuie clasificat `Nu necesită` înainte de a fi ignorat.
- „Documentat” rămâne dezvoltare ulterioară.

## Limitări și precauții

- Build integral Go necesită vendor disponibil pe serverul offline.
- Migrarea 082 și comportamentul cu MariaDB real / integrarea VCSA nu au fost testate în această sesiune. Testați într-un staging înainte de producție.
- Nu se modifică agentul (1.7.18), colectorii sau integrarea Forti/Veeam/Prometheus.
- Dacă se revine la un server mai vechi, recomandăm restaurarea întregii baze din backupul făcut înaintea migrării; `inventory_id` nullable nu este compatibil sigur cu versiunile vechi în toate situațiile.
