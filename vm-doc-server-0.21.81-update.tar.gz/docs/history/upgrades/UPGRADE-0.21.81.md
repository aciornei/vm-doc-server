# Upgrade VM-DOC Server 0.21.80 → 0.21.81

1. Oprește serviciul VM-DOC și colectorul dacă partajează aceeași bază. Fă backup MariaDB complet și backup al binarului și configurației.
2. Aplică `vm-doc-server-0.21.80-to-0.21.81.patch` sau extrage `vm-doc-server-0.21.81-update.tar.gz` peste sursele 0.21.80. Pachetul complet include și toate sursele.
3. În mediul offline cu `vendor/`: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
4. Instalează binarul recompilat cu `go:embed`, pornește serverul. Migrarea `082_changes_accepted_baselines.up.sql` se execută automat la pornire.
5. Verifică `journalctl -u vm-doc-server -n 100 --no-pager` și numărul noii migrări din istoricul DB. Verifică existența tabelelor `inventory_change_baseline_values` și `inventory_change_baseline_overrides`.
6. Rulează două colectări de test pentru o VM: schimbă controlat un obiect; el trebuie să apară ca „Nou”. Marchează „Revizuit” și verifică dispariția din lista de lucru și intrarea în timeline-ul VM. Schimbă alt obiect nerevizuit și confirmă că rămâne în inbox.
7. Verifică la lățimi diferite că tabela are scroll propriu, fără scroll pe întreaga pagină.

**Atenție:** nu face „Resetează baseline” pentru toate VM-urile dacă vrei să păstrezi restanțele; operația acceptă întregul inventar. Migrarea este aditivă pentru baza acceptată, dar modifică relația snapshot→istoric din CASCADE în SET NULL pentru protejarea reviziilor. Pentru rollback sigur la 0.21.80 restaurează backupul MariaDB și binarul anterior; scriptul `down` nu reactivează în mod intenționat vechea ștergere distructivă în cascadă.
