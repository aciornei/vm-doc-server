-- VM-DOC 0.21.60: candidates for OLD inventory_changes noise only.
-- Version 0.21.60 server prevents NEW noise; these statements do not modify snapshots.
-- PROTECTED: reviews, manual documentation decisions, manually entered notes.
-- Re-check preview on a MariaDB STAGING replica; keep a RESTORABLE backup.
DROP TEMPORARY TABLE IF EXISTS tmp_vm_doc_noise_02160;
CREATE TEMPORARY TABLE tmp_vm_doc_noise_02160 (
  id BIGINT NOT NULL PRIMARY KEY,
  reason VARCHAR(48) NOT NULL,
  KEY idx_reason (reason)
) ENGINE=InnoDB;

-- Docker: older 'modified' events where name and image/tag did not change.
-- Other metadata (MAC, IP, network ID, mounts, ports, digests) is irrelevant
-- only to this documentation change log, never to raw inventory/security.
INSERT IGNORE INTO tmp_vm_doc_noise_02160 (id,reason)
SELECT c.id, 'docker_metadata_only'
FROM inventory_changes c
WHERE c.review_status='new'
 AND c.documentation_requirement='unset'
 AND c.reviewed_at IS NULL
 AND COALESCE(TRIM(c.notes),'')=''
 AND c.category='docker' AND c.object_type='container' AND c.change_type='modified'
 AND CASE WHEN JSON_VALID(c.old_json)=1 AND JSON_VALID(c.new_json)=1
    THEN BINARY COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.name')),'')
       = BINARY COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.name')),'')
     AND BINARY SUBSTRING_INDEX(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.image')),''),'@sha256:',1)
       = BINARY SUBSTRING_INDEX(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.image')),''),'@sha256:',1)
    ELSE 0 END;

-- Version field contains collection-time [Warning]/[Error], not a version;
-- delete only when ALL the other fields of the JSON are unchanged.
INSERT IGNORE INTO tmp_vm_doc_noise_02160 (id,reason)
SELECT c.id, 'mysql_service_version_diagnostic'
FROM inventory_changes c
WHERE c.review_status='new'
 AND c.documentation_requirement='unset'
 AND c.reviewed_at IS NULL
 AND COALESCE(TRIM(c.notes),'')=''
 AND c.category IN ('databases','services') AND c.change_type='modified'
 AND CASE WHEN JSON_VALID(c.old_json)=1 AND JSON_VALID(c.new_json)=1
   THEN BINARY JSON_REMOVE(c.old_json,'$.version') = BINARY JSON_REMOVE(c.new_json,'$.version')
     AND (
       COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'') LIKE '%[Warning]%'
       OR COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'') LIKE '%[Warning]%'
       OR COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'') LIKE '%[Error]%'
       OR COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'') LIKE '%[Error]%'
     )
   ELSE 0 END;

-- UDP is excluded unless this exact VM/protocol/port was explicitly selected
-- as Principal. Applies to the 1024-49151 range as well as other UDP ports.
INSERT IGNORE INTO tmp_vm_doc_noise_02160 (id,reason)
SELECT c.id, 'udp_non_principal'
FROM inventory_changes c
WHERE c.review_status='new'
 AND c.documentation_requirement='unset'
 AND c.reviewed_at IS NULL
 AND COALESCE(TRIM(c.notes),'')=''
 AND c.category='ports' AND c.object_type='listening_port'
 AND c.object_key LIKE 'ports|listening_port|udp/%'
 AND NOT EXISTS (
   SELECT 1 FROM vm_primary_agent_ports pp
   WHERE pp.vm_id=c.vm_id AND LOWER(pp.protocol)='udp'
     AND pp.port=CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',-1),'/',2),'/',-1) AS UNSIGNED)
 );

-- nftables: exactly Docker-created NAT/POSTROUTING MASQUERADE with
-- br-<12hex> and a private IPv4 source CIDR. NOT general NAT or Docker-USER.
INSERT IGNORE INTO tmp_vm_doc_noise_02160 (id,reason)
SELECT c.id, 'nftables_docker_nat_masquerade'
FROM inventory_changes c
WHERE c.review_status='new'
 AND c.documentation_requirement='unset'
 AND c.reviewed_at IS NULL
 AND COALESCE(TRIM(c.notes),'')=''
 AND c.category='firewall' AND c.object_type='rule'
 AND c.change_type IN ('added','removed')
 AND c.object_key LIKE 'firewall|rule|nftables|%'
 AND c.object_key LIKE '%br-%'
 AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN
       JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.backend')) = 'nftables'
   AND JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.table')) = 'nat'
   AND JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.chain')) = 'POSTROUTING'
   AND JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.family')) IN ('ip','ipv4')
   AND TRIM(JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')))
     REGEXP '^ip saddr (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}|172[.](1[6-9]|2[0-9]|3[01])[.][0-9]{1,3}[.][0-9]{1,3}|192[.]168[.][0-9]{1,3}[.][0-9]{1,3})/[0-9]{1,2} (meta )?oifname != (["]br-[0-9a-fA-F]{12}["]|br-[0-9a-fA-F]{12}) (counter )?masquerade$'
   ELSE 0 END;

SELECT DATABASE() AS baza_curenta;
SELECT reason, COUNT(*) AS candidate_rows FROM tmp_vm_doc_noise_02160 GROUP BY reason ORDER BY candidate_rows DESC;
SELECT COUNT(*) AS total_candidati FROM tmp_vm_doc_noise_02160;
SELECT n.reason, c.vm_id, c.change_type, c.object_label, c.occurred_at
FROM tmp_vm_doc_noise_02160 n JOIN inventory_changes c ON c.id=n.id
ORDER BY c.occurred_at DESC LIMIT 60;
DROP TEMPORARY TABLE tmp_vm_doc_noise_02160;
