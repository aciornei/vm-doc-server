package inventorychanges

import (
	"encoding/json"
	"testing"
)

func TestDockerMinimalPolicyIgnoresNetworkComposeAndDigest(t *testing.T) {
	makeSnap := func(project, image, mac, ip string) []byte {
		b, _ := json.Marshal(map[string]any{"docker": map[string]any{"containers": []any{
			map[string]any{"name": "postgres", "image": image, "compose_project": project, "compose_service": "db", "image_digest": "sha256:deadbeef", "ports": []any{"5432"}, "mounts": []any{"/data"}, "networks": []any{map[string]any{"name": "front", "ip_address": ip, "mac_address": mac}}},
		}}})
		return b
	}
	a, _ := extractTracked(makeSnap("a", "postgres:16@sha256:aaa", "01", "172.18.0.2"))
	b, _ := extractTracked(makeSnap("b", "postgres:16@sha256:bbb", "02", "172.18.0.9"))
	key := "docker|container|postgres"
	if len(a) != 1 || len(b) != 1 || !canonicalEqual(a[key].Value, b[key].Value) {
		t.Fatalf("docker metadata created noise: %v vs %v", a, b)
	}
	c, _ := extractTracked(makeSnap("b", "postgres:17", "02", "172.18.0.9"))
	if canonicalEqual(a[key].Value, c[key].Value) {
		t.Fatal("image upgrade lost")
	}
	d, _ := extractTracked(makeSnap("b", "postgres-alt:16", "02", "172.18.0.9"))
	if canonicalEqual(a[key].Value, d[key].Value) {
		t.Fatal("image name changed without event")
	}
}

func TestMySQLTimestampWarningsNotSoftwareVersions(t *testing.T) {
	snap := func(version string) []byte {
		b, _ := json.Marshal(map[string]any{"databases": map[string]any{"instances": []any{
			map[string]any{"engine": "mysql", "product": "MySQL", "instance_name": "mysql", "version": version, "endpoints": []any{map[string]any{"port": 3306}}},
		}}})
		return b
	}
	warning := "261019 9:46:33 [Warning] Using unique option prefix key_buffer is deprecated"
	old, _ := extractTracked(snap("8.0.36"))
	noisy, _ := extractTracked(snap(warning))
	after, _ := extractTracked(snap("8.0.36"))
	upgraded, _ := extractTracked(snap("8.4.0"))
	var key string
	for k, v := range old {
		if v.Type == "database_instance" {
			key = k
		}
	}
	if key == "" {
		t.Fatal("missing database")
	}
	if !trackedObjectsEqual(old[key], noisy[key]) || !trackedObjectsEqual(noisy[key], after[key]) {
		t.Fatalf("warning created false DB change: %v vs %v", old[key], noisy[key])
	}
	if trackedObjectsEqual(old[key], upgraded[key]) {
		t.Fatal("real MySQL upgrade lost")
	}
	if _, has := noisy[key].Value.(map[string]any)["version"]; has {
		t.Fatal("warning in tracked version")
	}
}

func TestUDPUnselectedSuppressedTCPOrdinaryPreserved(t *testing.T) {
	mk := func(proto string, port int) trackedObject {
		return trackedObject{Category: "ports", Type: "listening_port", Value: map[string]any{"protocol": proto, "port": port}}
	}
	udp := mk("udp", 36761)
	if !suppressDynamicPortChange(udp, trackedObject{}, true, false, nil) {
		t.Fatal("unselected UDP must be suppressed")
	}
	if suppressDynamicPortChange(udp, trackedObject{}, true, false, map[portSelection]bool{{"udp", 36761}: true}) {
		t.Fatal("selected UDP must be kept")
	}
	if suppressDynamicPortChange(mk("tcp", 443), trackedObject{}, true, false, nil) {
		t.Fatal("stable TCP suppressed")
	}
	if !suppressDynamicPortChange(mk("tcp", 60000), trackedObject{}, true, false, nil) {
		t.Fatal("ephemeral TCP leaked")
	}
}

func TestNftDockerNATMasqueradePrecise(t *testing.T) {
	good := []string{
		`ip saddr 172.18.0.0/16 oifname != "br-f392b3fbdb12" counter masquerade`,
		`ip saddr 172.18.0.0/16 meta oifname != br-87894e600741 counter packets 2 bytes 96 masquerade # handle 21`,
		`ip saddr 10.10.0.0/16 oifname != "br-f392b3fbdb12" masquerade`,
	}
	for _, rule := range good {
		if !isGeneratedFirewallRule(map[string]any{"backend": "nftables", "family": "ip", "table": "nat", "chain": "POSTROUTING", "rule": rule}) {
			t.Fatalf("missed Docker NAT: %q", rule)
		}
	}
	bad := []struct{ table, chain, rule string }{
		{"filter", "POSTROUTING", good[0]},
		{"nat", "INPUT", good[0]},
		{"nat", "POSTROUTING", `ip saddr 8.8.8.0/24 oifname != "br-f392b3fbdb12" counter masquerade`},
		{"nat", "POSTROUTING", `ip saddr 172.18.0.0/16 oifname != "br-static" counter masquerade`},
		{"nat", "POSTROUTING", `ip saddr 172.18.0.0/16 oifname != "br-f392b3fbdb12" counter masquerade random`},
		{"nat", "POSTROUTING", `ip saddr 172.18.0.0/16 oifname != "br-f392b3fbdb12" counter accept`},
	}
	for _, tc := range bad {
		if isGeneratedFirewallRule(map[string]any{"backend": "nftables", "family": "ip", "table": tc.table, "chain": tc.chain, "rule": tc.rule}) {
			t.Fatalf("suppressed explicit firewall rule: %+v", tc)
		}
	}
	if isGeneratedFirewallRule(map[string]any{"backend": "nftables", "family": "ip", "table": "nat", "chain": "DOCKER-USER", "rule": good[0]}) {
		t.Fatal("DOCKER-USER policy lost")
	}
}
