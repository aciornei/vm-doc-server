# Upgrade VM-DOC Server 0.21.59 → 0.21.60

1. Faceți backup verificat de MariaDB, al binarului curent și al directorului de surse/config. Rețineți că această versiune este numai pentru server.
2. Despachetați sursele integrale sau aplicați **doar unul** dintre pachetele update TAR sau patch 0.21.59→0.21.60, fără să suprascrieți directorul `vendor/` existent.
3. În mediu staging offline: `GOPROXY=off GOSUMDB=off go test ./internal/inventorychanges ./internal/domain ./openapi ./web`; apoi `GOPROXY=off GOSUMDB=off go test ./...` și `make build` cu `vendor/`. Nu instalați un binar neverificat.
4. Testați două colectări Docker cu același name/tag și IP/MAC diferite: fără evenimente. Schimbați imaginea/tag: trebuie eveniment. Pentru UDP/36761 nemarcat Principal: fără evenimente. UDP Principal trebuie urmărit.
5. Testați MySQL cu `version` contaminat de timestamp `[Warning]` și cu schimbare reală de versiune. Pentru nftables NAT probați explicit `ip saddr 172.18.0.0/16 oifname != "br-..." counter masquerade` în nat/POSTROUTING și o regulă explicită de control. Nu ascundeți toate regulile NAT.
6. Dacă doriți curățarea istoricului: executați **PREVIEW** `scripts/preview-minimal-noise-02160.sql` pe copia staging a bazei; comparați numărul și mostrele. Opriți serverul/colectările, faceți backup restaurabil recent și executați **CLEANUP** `scripts/cleanup-minimal-noise-02160.sql`. Acestea sunt țintite, nu curățarea cumulativă 0.21.50–0.21.59. SQL-ul necesită drept `CREATE TEMPORARY TABLES` și mai multe comenzi pe aceeași conexiune.
7. Reporniți VM-DOC și urmăriți numai evenimentele apărute după upgrade, nu cele anterioare. Raportați mostrele exacte de nftables NAT care mai trec.

**Rollback aplicație:** restaurați binarul/sursele 0.21.59. **Rollback SQL după COMMIT:** restaurare din backup. Agent 1.7.18 nu se schimbă. Fără migrare SQL automată și fără schimbare API.
