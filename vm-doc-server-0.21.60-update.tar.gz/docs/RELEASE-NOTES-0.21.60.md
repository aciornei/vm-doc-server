# VM-DOC Server 0.21.60 — istoric Modificări minimal

Data: 2026-10-20. Bază 0.21.59. Doar server; vm-doc-agent 1.7.18 nemodificat.

## Politica nouă

- Docker `container`: se compară doar numele containerului (`name`) și imaginea (`image`, inclusiv tagul de versiune). Se elimină sufixul `@sha256:...` din valoarea comparată; nu se urmăresc ID, digest, MAC, IP, network_id, porturi, volume, Compose, stări runtime sau alte metadate. Numele este cheia per VM. Datele complete rămân în JSON-ul brut, inventarul Docker, configurațiile și rapoartele curente.
- UDP `listening_port`: numai porturile marcate explicit **Principal** generează modificări; regula anterioară pentru TCP >= 49152 rămâne. Atenție: inclusiv modificări UDP/53, UDP/123 nu vor mai intra în istoricul Modificări fără selectare Principal.
- MySQL/MariaDB: câmpurile `version` contaminate de `[Warning]` / `[Error]` cu timestamp sunt excluse din diff, inclusiv la instanțele DB. O versiune detectată valid comparată cu una lipsă/invalidă nu declanșează modificare falsă; două versiuni valide diferite produc eveniment.
- nftables NAT Docker: ignora exclusiv `ip saddr <RFC1918>/<prefix> (meta )?oifname != br-<12hex> (counter )?masquerade`, dacă `backend=nftables`, `family=ip/ipv4`, `table=nat`, `chain=POSTROUTING`. Contoare și `# handle` sunt normalizate. Reguli explicite, `DOCKER-USER`, alte chains/tables sunt păstrate.

## Impact / limitări

- Filtrarea afectează doar `inventory_changes`; nu schimbă inventarul brut, sincronizările, securitatea/monitorizarea, asocierea serviciilor/beneficiarilor, documentele și publicarea Outline.
- Detectarea schimbărilor de IP/port Docker este intenționat dezactivată în istoricul Modificări; aceste valori sunt în continuare disponibile în inventar.
- Nu sunt modificări API sau migrare SQL automată.
- SQL PREVIEW/CLEANUP *țintit* în `scripts/preview-minimal-noise-02160.sql`, `scripts/cleanup-minimal-noise-02160.sql`: executare manuală după backup verificat, pe staging întâi, cu VM-DOC oprit pentru CLEANUP. Protejează rândurile cu review/decizii/notițe. Nu șterge snapshoturile brute. Nu curăță generic toate regulile Docker, ci numai patternul confirmat.
- Subvarianta exactă a regulii nftables NAT nu a fost furnizată în JSON; sunt suportate variantele regex enumerate, nu se poate promite eliminarea tuturor NAT fără observarea unui exemplu rămas.

## Verificări

- Teste unitare Go noi pentru Docker, UDP, MySQL, nftables NAT; `GOPROXY=off GOSUMDB=off go test ./internal/inventorychanges ./internal/domain ./openapi ./web`.
- Testare SQL end-to-end pe MariaDB și build complet cu `vendor/` rămân necesare pe infrastructura offline.
