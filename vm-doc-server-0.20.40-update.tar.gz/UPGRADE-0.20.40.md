# Upgrade vm-doc-server 0.20.39 -> 0.20.40

Versiunea 0.20.40 este un fix UI pentru filtrele rapoartelor. Nu adaugă migrare DB și nu necesită update de vm-doc-agent.

## Schimbări

- `Rapoarte → Suport sisteme de operare`: carduri și filtre funcționale, `Caută / Aplică`, `Resetează`, Enter în căutare și export Excel filtrat.
- `Rapoarte → Outline · VM-uri`: carduri și filtre funcționale, inclusiv Pornit/Oprit, plus export Excel sincronizat cu filtrul curent.
- `Rapoarte → Outline · Servicii`: carduri și filtre funcționale, plus export Excel sincronizat cu filtrul curent.
- Cauza regresiei: listener-ele 0.20.39 erau evaluate înainte ca HTML-ul raportului să fie introdus în DOM. În 0.20.40 sunt legate după randare.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.39 \
      /usr/local/src/vm-doc-server-0.20.40

tar -xzf vm-doc-server-0.20.40-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.40

cd /usr/local/src/vm-doc-server-0.20.40

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După restart folosește `Ctrl+F5` pentru a încărca `app.js?v=0.20.40`.
