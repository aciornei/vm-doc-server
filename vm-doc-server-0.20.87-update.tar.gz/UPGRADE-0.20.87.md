# Upgrade vm-doc-server 0.20.86 → 0.20.87

Release exclusiv server-side. Nu adaugă migrare SQL și nu necesită update de agent.

## Schimbări

- Servicii → Outline: publicare individuală și bulk numai pentru servicii cu cel puțin un VM PROD.
- pagina Outline a serviciului conține numai datele PROD pentru secțiunile legate de VM;
- agregările tehnice sunt recalculate numai din PROD;
- serviciile fără PROD nu mai afișează butonul de publicare și sunt omise din preview-ul bulk;
- fișele DOCX/Markdown normale și exporturile rămân neschimbate.

## Upgrade offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.86 vm-doc-server-0.20.87
tar -xzf /cale/vm-doc-server-0.20.87-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.87
cd /usr/local/src/vm-doc-server-0.20.87

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build

systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

După restart, faceți `Ctrl+F5`.

## Verificare

1. Serviciu cu PROD + TEST: butonul Outline este disponibil, iar pagina publicată conține numai PROD.
2. Serviciu numai TEST/DEV: butonul Outline nu apare, iar API-ul refuză publicarea directă.
3. Documente → Publică în Outline → Servicii: preview-ul listează numai serviciile cu PROD și indică separat câte non-PROD au fost omise.
4. DOCX-ul normal al serviciului și exporturile trebuie să rămână neschimbate.
