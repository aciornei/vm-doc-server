package server

import (
	"testing"

	"vm-doc-server/internal/domain"
)

func TestFilterServiceOutlineAssignmentsKeepsOnlyCanonicalProd(t *testing.T) {
	values := []domain.InternalServiceVM{
		{ID: 10, Name: "app-prod", Environment: "TEST"},
		{ID: 20, Name: "app-test", Environment: "PROD"},
	}
	got := filterServiceOutlineAssignments(values, map[int64]string{10: "Producție"})
	if len(got) != 1 || got[0].ID != 10 {
		t.Fatalf("expected only VM 10, got %#v", got)
	}
	if got[0].Environment != "Producție" {
		t.Fatalf("expected canonical environment to replace cached value, got %q", got[0].Environment)
	}
}

func TestRecomputeServiceOutlineAggregatesUsesOnlyFilteredVMs(t *testing.T) {
	solutionID := int64(7)
	layerID := int64(8)
	roleID := int64(9)
	service := domain.InternalService{VMs: []domain.InternalServiceVM{
		{ID: 10, ArchitecturalDomainID: 1, ArchitecturalDomain: "Aplicații", ITILCategoryID: 2, ITILCategory: "Business", SolutionTypeID: &solutionID, SolutionType: "Open source", LayerID: &layerID, LayerName: "Application", TechnicalRoleID: &roleID, TechnicalRole: "API"},
		{ID: 11, ArchitecturalDomainID: 1, ArchitecturalDomain: "Aplicații", ITILCategoryID: 2, ITILCategory: "Business", SolutionTypeID: &solutionID, SolutionType: "Open source", LayerID: &layerID, LayerName: "Application", TechnicalRoleID: &roleID, TechnicalRole: "API"},
	}}
	recomputeServiceOutlineAggregates(&service)
	if service.VMCount != 2 || len(service.Classifications) != 1 || service.Classifications[0].VMCount != 2 || service.Classifications[0].AssignmentCount != 2 {
		t.Fatalf("unexpected classification aggregate: %#v", service)
	}
	if len(service.SolutionTypes) != 1 || service.SolutionTypes[0].VMCount != 2 || service.SolutionTypes[0].AssignmentCount != 2 {
		t.Fatalf("unexpected solution aggregate: %#v", service.SolutionTypes)
	}
	if len(service.RoleMappings) != 1 || service.RoleMappings[0].VMCount != 2 {
		t.Fatalf("unexpected role aggregate: %#v", service.RoleMappings)
	}
}

func TestProductionResourceAssignmentsExcludeNonProdForSameService(t *testing.T) {
	values := []domain.DockerServiceAssignment{
		{ServiceID: 5, Environment: "TEST"},
		{ServiceID: 6, Environment: "PROD"},
	}
	filtered, matched, prod := productionDockerAssignments(values, 5)
	if !matched || prod {
		t.Fatalf("expected service 5 to be matched but non-PROD, matched=%v prod=%v", matched, prod)
	}
	for _, item := range filtered {
		if item.ServiceID == 5 {
			t.Fatalf("non-PROD assignment leaked into filtered values: %#v", filtered)
		}
	}
}
