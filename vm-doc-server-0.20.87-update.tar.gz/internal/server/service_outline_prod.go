package server

import (
	"context"
	"errors"
	"sort"
	"strings"

	"vm-doc-server/internal/documents"
	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/external"
)

// serviceOutlineProductionVMIDs returns the VM assignments that make a service
// eligible for Outline publication. Environment is always resolved from the
// canonical VM operational nomenclature (with the legacy metadata fallback in
// vmOutlineEnvironment), never from the cached service report value.
func (a *App) serviceOutlineProductionVMIDs(ctx context.Context, serviceID int64) (map[int64]string, error) {
	if a.DB == nil {
		return nil, errors.New("database is unavailable")
	}
	rows, err := a.DB.QueryContext(ctx, `SELECT DISTINCT vm.id
		FROM vm_internal_service_assignments assignment
		JOIN virtual_machines vm ON vm.id=assignment.vm_id
		WHERE assignment.internal_service_id=? AND COALESCE(vm.retired,0)=0
		ORDER BY vm.id`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	ids := make([]int64, 0)
	for rows.Next() {
		var vmID int64
		if err := rows.Scan(&vmID); err != nil {
			return nil, err
		}
		ids = append(ids, vmID)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	out := make(map[int64]string, len(ids))
	for _, vmID := range ids {
		environment, err := a.vmOutlineEnvironment(ctx, vmID)
		if err != nil {
			return nil, err
		}
		if outlineBulkProductionEnvironment(environment) {
			out[vmID] = strings.TrimSpace(environment)
		}
	}
	return out, nil
}

func filterServiceOutlineAssignments(values []domain.InternalServiceVM, prod map[int64]string) []domain.InternalServiceVM {
	out := make([]domain.InternalServiceVM, 0, len(values))
	for _, item := range values {
		environment, ok := prod[item.ID]
		if !ok {
			continue
		}
		copyItem := item
		copyItem.Environment = environment
		out = append(out, copyItem)
	}
	return out
}

func recomputeServiceOutlineAggregates(service *domain.InternalService) {
	if service == nil {
		return
	}
	vmSeen := map[int64]bool{}
	for _, item := range service.VMs {
		vmSeen[item.ID] = true
	}
	service.VMCount = len(vmSeen)

	type classificationAgg struct {
		value domain.InternalServiceClassification
		vms   map[int64]bool
	}
	classByKey := map[string]*classificationAgg{}
	for _, item := range service.VMs {
		key := strings.Join([]string{strings.TrimSpace(item.ArchitecturalDomain), strings.TrimSpace(item.ITILCategory)}, "\x00")
		agg := classByKey[key]
		if agg == nil {
			agg = &classificationAgg{value: domain.InternalServiceClassification{
				ArchitecturalDomainID: item.ArchitecturalDomainID,
				ArchitecturalDomain:   item.ArchitecturalDomain,
				ITILCategoryID:        item.ITILCategoryID,
				ITILCategory:          item.ITILCategory,
			}, vms: map[int64]bool{}}
			classByKey[key] = agg
		}
		agg.value.AssignmentCount++
		agg.vms[item.ID] = true
	}
	service.Classifications = service.Classifications[:0]
	for _, agg := range classByKey {
		agg.value.VMCount = len(agg.vms)
		service.Classifications = append(service.Classifications, agg.value)
	}
	sort.SliceStable(service.Classifications, func(i, j int) bool {
		if service.Classifications[i].ArchitecturalDomain != service.Classifications[j].ArchitecturalDomain {
			return strings.ToLower(service.Classifications[i].ArchitecturalDomain) < strings.ToLower(service.Classifications[j].ArchitecturalDomain)
		}
		return strings.ToLower(service.Classifications[i].ITILCategory) < strings.ToLower(service.Classifications[j].ITILCategory)
	})
	service.ClassificationCount = len(service.Classifications)

	type solutionAgg struct {
		value domain.InternalServiceSolutionType
		vms   map[int64]bool
	}
	solutionByKey := map[string]*solutionAgg{}
	for _, item := range service.VMs {
		if item.SolutionTypeID == nil && strings.TrimSpace(item.SolutionType) == "" {
			continue
		}
		key := strings.ToLower(strings.TrimSpace(item.SolutionType))
		agg := solutionByKey[key]
		if agg == nil {
			id := int64(0)
			if item.SolutionTypeID != nil {
				id = *item.SolutionTypeID
			}
			agg = &solutionAgg{value: domain.InternalServiceSolutionType{SolutionTypeID: id, SolutionType: item.SolutionType}, vms: map[int64]bool{}}
			solutionByKey[key] = agg
		}
		agg.value.AssignmentCount++
		agg.vms[item.ID] = true
	}
	service.SolutionTypes = service.SolutionTypes[:0]
	for _, agg := range solutionByKey {
		agg.value.VMCount = len(agg.vms)
		service.SolutionTypes = append(service.SolutionTypes, agg.value)
	}
	sort.SliceStable(service.SolutionTypes, func(i, j int) bool {
		return strings.ToLower(service.SolutionTypes[i].SolutionType) < strings.ToLower(service.SolutionTypes[j].SolutionType)
	})
	service.SolutionTypeCount = len(service.SolutionTypes)

	type roleAgg struct {
		value domain.ServiceRoleMapping
		vms   map[int64]bool
	}
	roleByKey := map[string]*roleAgg{}
	for _, item := range service.VMs {
		if item.LayerID == nil && item.TechnicalRoleID == nil && strings.TrimSpace(item.LayerName) == "" && strings.TrimSpace(item.TechnicalRole) == "" {
			continue
		}
		layerID, roleID := int64(0), int64(0)
		if item.LayerID != nil {
			layerID = *item.LayerID
		}
		if item.TechnicalRoleID != nil {
			roleID = *item.TechnicalRoleID
		}
		key := strings.Join([]string{strings.TrimSpace(item.LayerName), strings.TrimSpace(item.TechnicalRole)}, "\x00")
		agg := roleByKey[key]
		if agg == nil {
			agg = &roleAgg{value: domain.ServiceRoleMapping{LayerID: layerID, LayerName: item.LayerName, TechnicalRoleID: roleID, TechnicalRole: item.TechnicalRole, Active: true}, vms: map[int64]bool{}}
			roleByKey[key] = agg
		}
		agg.vms[item.ID] = true
	}
	service.RoleMappings = service.RoleMappings[:0]
	for _, agg := range roleByKey {
		agg.value.VMCount = len(agg.vms)
		service.RoleMappings = append(service.RoleMappings, agg.value)
	}
	sort.SliceStable(service.RoleMappings, func(i, j int) bool {
		if service.RoleMappings[i].LayerName != service.RoleMappings[j].LayerName {
			return strings.ToLower(service.RoleMappings[i].LayerName) < strings.ToLower(service.RoleMappings[j].LayerName)
		}
		return strings.ToLower(service.RoleMappings[i].TechnicalRole) < strings.ToLower(service.RoleMappings[j].TechnicalRole)
	})
	service.RoleMappingCount = len(service.RoleMappings)
}

func productionDatabaseAssignments(values []domain.DatabaseServiceAssignment, serviceID int64) ([]domain.DatabaseServiceAssignment, bool, bool) {
	out := make([]domain.DatabaseServiceAssignment, 0, len(values))
	matched := false
	keep := false
	for _, item := range values {
		if item.ServiceID != serviceID {
			out = append(out, item)
			continue
		}
		matched = true
		if outlineBulkProductionEnvironment(item.Environment) {
			out = append(out, item)
			keep = true
		}
	}
	return out, matched, keep
}

func productionDockerAssignments(values []domain.DockerServiceAssignment, serviceID int64) ([]domain.DockerServiceAssignment, bool, bool) {
	out := make([]domain.DockerServiceAssignment, 0, len(values))
	matched := false
	keep := false
	for _, item := range values {
		if item.ServiceID != serviceID {
			out = append(out, item)
			continue
		}
		matched = true
		if outlineBulkProductionEnvironment(item.Environment) {
			out = append(out, item)
			keep = true
		}
	}
	return out, matched, keep
}

func productionWebAssignments(values []domain.WebServiceAssignment, serviceID int64) ([]domain.WebServiceAssignment, bool, bool) {
	out := make([]domain.WebServiceAssignment, 0, len(values))
	matched := false
	keep := false
	for _, item := range values {
		if item.ServiceID != serviceID {
			out = append(out, item)
			continue
		}
		matched = true
		if outlineBulkProductionEnvironment(item.Environment) {
			out = append(out, item)
			keep = true
		}
	}
	return out, matched, keep
}

func (a *App) filterServiceOutlineProductionData(ctx context.Context, data *documents.ServiceGenerationData, prod map[int64]string) error {
	if data == nil {
		return nil
	}
	serviceID := data.Service.ID
	data.Service.VMs = filterServiceOutlineAssignments(data.Service.VMs, prod)
	recomputeServiceOutlineAggregates(&data.Service)

	filterVMID := func(id int64) bool { _, ok := prod[id]; return ok }
	components := data.PrimaryComponents[:0]
	for _, item := range data.PrimaryComponents {
		if filterVMID(item.VMID) {
			if env, ok := prod[item.VMID]; ok {
				item.Environment = env
			}
			components = append(components, item)
		}
	}
	data.PrimaryComponents = components
	backups := data.Backups[:0]
	for _, item := range data.Backups {
		if filterVMID(item.VMID) {
			item.Environment = prod[item.VMID]
			backups = append(backups, item)
		}
	}
	data.Backups = backups
	monitorings := data.Monitorings[:0]
	for _, item := range data.Monitorings {
		if filterVMID(item.VMID) {
			item.Environment = prod[item.VMID]
			monitorings = append(monitorings, item)
		}
	}
	data.Monitorings = monitorings
	vmDocs := data.VMDocuments[:0]
	for _, item := range data.VMDocuments {
		if filterVMID(item.VMID) {
			item.Environment = prod[item.VMID]
			vmDocs = append(vmDocs, item)
		}
	}
	data.VMDocuments = vmDocs
	annexes := data.VMAnnexData[:0]
	for _, item := range data.VMAnnexData {
		if filterVMID(item.VM.ID) {
			annexes = append(annexes, item)
		}
	}
	data.VMAnnexData = annexes

	dbs := data.DatabaseResources[:0]
	for _, item := range data.DatabaseResources {
		filteredAssignments, matched, assignedProd := productionDatabaseAssignments(item.ServiceAssignments, serviceID)
		if (matched && !assignedProd) || (!matched && !filterVMID(item.VMID)) {
			continue
		}
		item.ServiceAssignments = filteredAssignments
		dbs = append(dbs, item)
	}
	data.DatabaseResources = dbs
	data.Service.DatabaseResources = dbs

	dockers := data.DockerContainers[:0]
	for _, item := range data.DockerContainers {
		filteredAssignments, matched, assignedProd := productionDockerAssignments(item.ServiceAssignments, serviceID)
		if (matched && !assignedProd) || (!matched && !filterVMID(item.VMID)) {
			continue
		}
		item.ServiceAssignments = filteredAssignments
		dockers = append(dockers, item)
	}
	data.DockerContainers = dockers
	data.Service.DockerContainers = dockers

	websites := data.WebSites[:0]
	for _, item := range data.WebSites {
		filteredAssignments, matched, assignedProd := productionWebAssignments(item.ServiceAssignments, serviceID)
		if (matched && !assignedProd) || (!matched && !filterVMID(item.VMID)) {
			continue
		}
		item.ServiceAssignments = filteredAssignments
		websites = append(websites, item)
	}
	data.WebSites = websites
	data.Service.WebSites = websites

	outgoing := data.Service.Dependencies[:0]
	for _, item := range data.Service.Dependencies {
		if strings.TrimSpace(item.SourceEnvironment) == "" || outlineBulkProductionEnvironment(item.SourceEnvironment) {
			outgoing = append(outgoing, item)
		}
	}
	data.Service.Dependencies = outgoing
	globals := data.Service.GlobalDependencies[:0]
	for _, item := range data.Service.GlobalDependencies {
		if strings.TrimSpace(item.SourceEnvironment) == "" || outlineBulkProductionEnvironment(item.SourceEnvironment) {
			globals = append(globals, item)
		}
	}
	data.Service.GlobalDependencies = globals
	dependents := data.Service.Dependents[:0]
	for _, item := range data.Service.Dependents {
		if strings.TrimSpace(item.TargetEnvironment) == "" || outlineBulkProductionEnvironment(item.TargetEnvironment) {
			dependents = append(dependents, item)
		}
	}
	data.Service.Dependents = dependents
	data.Service.DependencyCount = len(data.Service.Dependencies) + len(data.Service.GlobalDependencies)
	data.Service.DependentServiceCount = len(data.Service.Dependents)

	direct := data.Service.DirectVMDependents[:0]
	for _, item := range data.Service.DirectVMDependents {
		environment, err := a.vmOutlineEnvironment(ctx, item.VMID)
		if err != nil {
			return err
		}
		if outlineBulkProductionEnvironment(environment) {
			direct = append(direct, item)
		}
	}
	data.Service.DirectVMDependents = direct

	connections := make([]external.Connection, 0, len(data.ExternalConnections))
	for _, item := range data.ExternalConnections {
		if item.VMID == nil || *item.VMID <= 0 {
			connections = append(connections, item)
			continue
		}
		environment, err := a.vmOutlineEnvironment(ctx, *item.VMID)
		if err != nil {
			return err
		}
		if outlineBulkProductionEnvironment(environment) {
			connections = append(connections, item)
		}
	}
	data.ExternalConnections = connections
	return nil
}
