# VM-DOC Server 0.21.47 → 0.21.48

**Tip:** exclusiv interfață și metadate. **Agent:** 1.7.18, nemodificat. **SQL/API:** fără migrare sau contract nou.

1. Salvează binarul anterior, configurațiile, sursele și baza de date înainte de upgrade; păstrează `vendor/` din instalarea offline.
2. Aplică **o singură metodă** din rădăcina surselor 0.21.47:

   ```sh
   tar -xzf /cale/vm-doc-server-0.21.48-update.tar.gz
   # SAU, pe surse 0.21.47 nemodificate:
   git apply /cale/vm-doc-server-0.21.47-to-0.21.48.patch
   ```

3. Confirmă `cat VERSION` (`0.21.48`) și `bash scripts/cleanup-source-tree.sh --check`.
4. Pe serverul cu dependențe disponibile, rulează `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build`.
5. Verifică în staging harta VM și serviciu cu 100+ obiecte de adresă; extindere/restrângere și paginarea obiectelor, listele serviciilor din policy, porturile VM, highlight port/linie, export SVG și responsive.
6. Instalează binarul recompilat după testare, repornește serviciul și execută hard refresh Chrome.

**Rollback:** restaurează binarul și sursele 0.21.47; nu există migrare SQL de inversat.

**Limită verificări:** browser testat pe date simulate și Go independente, nu s-a verificat build-ul Go complet cu `vendor/` sau integrarea MariaDB/FortiGate reală.
