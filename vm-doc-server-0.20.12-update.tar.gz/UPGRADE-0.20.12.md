# Upgrade vm-doc-server 0.20.11 → 0.20.12

Release exclusiv server-side. Nu necesită update de agent și nu adaugă migrare SQL.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.11 vm-doc-server-0.20.12
tar -xzf /cale/vm-doc-server-0.20.12-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.12
cd /usr/local/src/vm-doc-server-0.20.12
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Apoi înlocuiești binarul conform fluxului tău normal și restartezi `vm-doc-server`.

Nu rula `go mod vendor` pe serverul izolat. Update-ul 0.20.12 nu modifică `go.mod`, `go.sum` sau `vendor/`.

## Verificări rapide după restart

1. În fișa unei VM, cardul `IP principal` apare sus.
2. În `Inventar agent` apar butoanele `Test` și `Colect` dacă VM-ul are agent și utilizatorul are dreptul `collections.run`.
3. La bifarea `Nu necesită documentare` pe Docker / DB / Web, procentul de completare se recalculează.
4. Marcarea unui serviciu sau port ca `Principal` influențează completitudinea.
5. La clickuri rapide între file/VM-uri nu mai trebuie să apară eroarea UI din răspunsuri stale.
