package inventory

import "testing"

func TestBuildDocumentViewOrdersAndRedacts(t *testing.T) {
	raw := []byte(`{"network":{"primary_ip":"10.0.0.1","api_token":"abc","bind_password_file":"/etc/secret"},"identity":{"hostname":"vm01"},"generated_at":"2026-08-31T10:00:00Z"}`)
	view, err := BuildDocumentView(raw)
	if err != nil {
		t.Fatal(err)
	}
	if len(view.Sections) != 2 || view.Sections[0].Key != "identity" || view.Sections[1].Key != "network" {
		t.Fatalf("unexpected sections: %#v", view.Sections)
	}
	network := view.Sections[1].Data.(map[string]any)
	if network["api_token"] != "[redactat]" || network["bind_password_file"] != "[redactat]" {
		t.Fatalf("secret was not redacted: %#v", network)
	}
}

func TestBuildDocumentViewTreatsUnsupportedCollectorsAsSuccessfulCollection(t *testing.T) {
	raw := []byte(`{"collection":{"status":"partial","collectors":{"system":{"status":"success"},"software":{"status":"unsupported"},"optional":{"status":"skipped"}}}}`)
	view, err := BuildDocumentView(raw)
	if err != nil {
		t.Fatal(err)
	}
	if len(view.Sections) != 1 || view.Sections[0].Key != "collection" {
		t.Fatalf("unexpected sections: %#v", view.Sections)
	}
	collection := view.Sections[0].Data.(map[string]any)
	if collection["status"] != "success" {
		t.Fatalf("benign partial collection was not normalized: %#v", collection)
	}
}

func TestBuildDocumentViewKeepsPartialWhenCollectorFailed(t *testing.T) {
	raw := []byte(`{"collection":{"status":"partial","collectors":{"system":{"status":"success"},"ntp":{"status":"failed"}}}}`)
	view, err := BuildDocumentView(raw)
	if err != nil {
		t.Fatal(err)
	}
	collection := view.Sections[0].Data.(map[string]any)
	if collection["status"] != "partial" {
		t.Fatalf("real collector failure was hidden: %#v", collection)
	}
}
