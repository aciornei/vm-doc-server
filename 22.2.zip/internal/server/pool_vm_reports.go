package server

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/documents"
)

// The pool audit state is deliberately used instead of virtual_machines as the
// driving VM set: newly discovered VMs in excluded pools have no VM-DOC row.
// Only the latest successful vCenter observation per source is eligible, so
// removed VMs do not survive forever in this current-state report.
type poolVMReportRow struct {
	SourceID    int64  `json:"source_id"`
	SourceName  string `json:"source_name"`
	PoolMoID    string `json:"pool_moid"`
	PoolName    string `json:"pool_name"`
	Included    bool   `json:"included"`
	PoolVMCount int    `json:"pool_vm_count"`
	VMID        int64  `json:"vm_id"`
	VMName      string `json:"vm_name"`
	VMExists    bool   `json:"vm_exists"`
	PoweredOn   bool   `json:"powered_on"`
	Imported    bool   `json:"imported"`
	Retired     bool   `json:"retired"`
	Environment string `json:"environment"`
	Observation string `json:"observation"`
}

type poolVMReportOption struct {
	Value string `json:"value"`
	Label string `json:"label"`
}

type poolVMReportFilters struct {
	Query, Source, Pool, Policy, Power, Environment, Import, Notes, Membership string
	Page, PageSize                                                             int
}

func readPoolVMReportFilters(r *http.Request) (poolVMReportFilters, error) {
	q := r.URL.Query()
	f := poolVMReportFilters{
		Query: strings.TrimSpace(q.Get("q")), Source: q.Get("source"), Pool: q.Get("pool"),
		Policy: q.Get("policy"), Power: q.Get("power"), Environment: strings.TrimSpace(q.Get("environment")),
		Import: q.Get("import"), Notes: q.Get("notes"), Membership: q.Get("membership"),
		Page: 1, PageSize: 50,
	}
	if len(f.Query) > 200 || len(f.Environment) > 128 || len(f.Pool) > 256 {
		return f, errors.New("filter too long")
	}
	valid := func(value string, allowed ...string) bool {
		for _, s := range allowed {
			if value == s {
				return true
			}
		}
		return false
	}
	if !valid(f.Policy, "", "included", "excluded") || !valid(f.Power, "", "on", "off") ||
		!valid(f.Import, "", "imported", "not_imported", "retired") || !valid(f.Notes, "", "yes", "no") ||
		!valid(f.Membership, "", "with_vm", "empty") {
		return f, errors.New("invalid report filter")
	}
	if f.Source != "" {
		if id, err := strconv.ParseInt(f.Source, 10, 64); err != nil || id <= 0 {
			return f, errors.New("invalid source filter")
		}
	}
	if f.Pool != "" {
		pieces := strings.SplitN(f.Pool, ":", 2)
		if len(pieces) != 2 || pieces[1] == "" {
			return f, errors.New("invalid pool filter")
		}
		if id, err := strconv.ParseInt(pieces[0], 10, 64); err != nil || id <= 0 {
			return f, errors.New("invalid pool source")
		}
	}
	if value := q.Get("page"); value != "" {
		n, err := strconv.Atoi(value)
		if err != nil || n < 1 {
			return f, errors.New("invalid page")
		}
		f.Page = n
	}
	if value := q.Get("page_size"); value != "" {
		n, err := strconv.Atoi(value)
		if err != nil || n < 1 || n > 200 {
			return f, errors.New("invalid page size (max 200)")
		}
		f.PageSize = n
	}
	return f, nil
}

const poolVMReportSQL = `
SELECT p.vcenter_source_id, src.name, p.moid, p.name, p.cluster_name, p.parent_moid, p.include_in_docs, p.vm_count,
       COALESCE(st.vcenter_moid,''), COALESCE(st.vm_name,''), COALESCE(st.powered_on,0),
       COALESCE(vm.id,0), COALESCE(vm.retired,0),
       COALESCE(NULLIF(env.item_code,''), NULLIF(env.name,''), NULLIF(op.environment,''),''), COALESCE(op.notes,'')
FROM vcenter_resource_pools p
JOIN vcenter_sources src ON src.id=p.vcenter_source_id
LEFT JOIN (
  SELECT vcenter_source_id,MAX(observed_at) AS observed_at
  FROM vcenter_pool_vm_audit_state GROUP BY vcenter_source_id
) latest ON latest.vcenter_source_id=p.vcenter_source_id
LEFT JOIN vcenter_pool_vm_audit_state st ON st.vcenter_source_id=p.vcenter_source_id
  AND st.pool_moid=p.moid AND st.observed_at=latest.observed_at
LEFT JOIN virtual_machines vm ON vm.vcenter_source_id=st.vcenter_source_id AND vm.vcenter_moid=st.vcenter_moid
LEFT JOIN vm_operational_metadata op ON op.vm_id=vm.id
LEFT JOIN vm_operational_nomenclatures ven ON ven.vm_id=vm.id AND ven.category_code='environment'
LEFT JOIN nomenclature_items env ON env.id=ven.item_id AND env.category_code='environment'
WHERE p.present_in_vcenter=1
ORDER BY src.name,p.name,p.moid,st.vm_name`

func (a *App) collectPoolVMReport(ctx context.Context) ([]poolVMReportRow, []poolVMReportOption, []poolVMReportOption, error) {
	rows, err := a.DB.QueryContext(ctx, poolVMReportSQL)
	if err != nil {
		return nil, nil, nil, err
	}
	defer rows.Close()
	type poolInfo struct {
		source                                      int64
		sourceName, moid, name, clusterName, parent string
	}
	infos := make(map[string]poolInfo)
	results := make([]poolVMReportRow, 0)
	sources := map[string]string{}
	for rows.Next() {
		var row poolVMReportRow
		var parent, clusterName, vcenterMoID string
		if err := rows.Scan(&row.SourceID, &row.SourceName, &row.PoolMoID, &row.PoolName, &clusterName, &parent, &row.Included, &row.PoolVMCount,
			&vcenterMoID, &row.VMName, &row.PoweredOn, &row.VMID, &row.Retired, &row.Environment, &row.Observation); err != nil {
			return nil, nil, nil, err
		}
		row.VMExists = vcenterMoID != ""
		row.Imported = row.VMID > 0
		if !row.VMExists {
			row.VMName = ""
			row.Observation = ""
		}
		key := fmt.Sprintf("%d:%s", row.SourceID, row.PoolMoID)
		infos[key] = poolInfo{row.SourceID, row.SourceName, row.PoolMoID, row.PoolName, clusterName, parent}
		sources[strconv.FormatInt(row.SourceID, 10)] = row.SourceName
		results = append(results, row)
		if len(results) > 100000 {
			return nil, nil, nil, errors.New("too many pool/VM rows; refine the source inventory")
		}
	}
	if err := rows.Err(); err != nil {
		return nil, nil, nil, err
	}
	// Distinguish identically named pools in different subtrees using their path.
	paths := make(map[string]string, len(infos))
	for key, info := range infos {
		parts := []string{displayPoolReportRootLabel(info.name, info.clusterName, info.parent)}
		seen := map[string]bool{key: true}
		parent := info.parent
		for parent != "" {
			pkey := fmt.Sprintf("%d:%s", info.source, parent)
			if seen[pkey] {
				break
			}
			seen[pkey] = true
			parentInfo, ok := infos[pkey]
			if !ok {
				break
			}
			parts = append([]string{parentInfo.name}, parts...)
			parent = parentInfo.parent
		}
		paths[key] = strings.Join(parts, " / ")
	}
	pools := make([]poolVMReportOption, 0, len(infos))
	for key, info := range infos {
		pools = append(pools, poolVMReportOption{key, info.sourceName + " · " + paths[key]})
	}
	sort.Slice(pools, func(i, j int) bool { return strings.ToLower(pools[i].Label) < strings.ToLower(pools[j].Label) })
	sourceOptions := make([]poolVMReportOption, 0, len(sources))
	for id, name := range sources {
		sourceOptions = append(sourceOptions, poolVMReportOption{id, name})
	}
	sort.Slice(sourceOptions, func(i, j int) bool { return sourceOptions[i].Label < sourceOptions[j].Label })
	for i := range results {
		key := fmt.Sprintf("%d:%s", results[i].SourceID, results[i].PoolMoID)
		results[i].PoolName = paths[key]
	}
	sortPoolVMReportRows(results)
	return results, sourceOptions, pools, nil
}

// Only a top-level Resources pool verified by its exact VCSA MoRef may be
// displayed under the real cluster name; nested/dedicated pool names do not
// change. Standalone host Roots and unknown cluster associations stay Resources.
func displayPoolReportRootLabel(name, clusterName, parentMoID string) string {
	if parentMoID == "" && strings.EqualFold(strings.TrimSpace(name), "Resources") {
		if cluster := strings.TrimSpace(clusterName); cluster != "" {
			return cluster
		}
	}
	return name
}

// Keep every real resource pool contiguous, including identically named pools.
// Both HTML rowspan and Word vMerge rely on this grouping order.
func sortPoolVMReportRows(results []poolVMReportRow) {
	sort.Slice(results, func(i, j int) bool {
		a, b := results[i], results[j]
		if !strings.EqualFold(a.SourceName, b.SourceName) {
			return strings.ToLower(a.SourceName) < strings.ToLower(b.SourceName)
		}
		if a.SourceID != b.SourceID {
			return a.SourceID < b.SourceID
		}
		if !strings.EqualFold(a.PoolName, b.PoolName) {
			return strings.ToLower(a.PoolName) < strings.ToLower(b.PoolName)
		}
		if a.PoolMoID != b.PoolMoID {
			return a.PoolMoID < b.PoolMoID
		}
		return strings.ToLower(a.VMName) < strings.ToLower(b.VMName)
	})
}

func filterPoolVMReport(items []poolVMReportRow, f poolVMReportFilters) []poolVMReportRow {
	out := make([]poolVMReportRow, 0, len(items))
	needle := strings.ToLower(f.Query)
	for _, row := range items {
		key := fmt.Sprintf("%d:%s", row.SourceID, row.PoolMoID)
		if f.Source != "" && f.Source != strconv.FormatInt(row.SourceID, 10) {
			continue
		}
		if f.Pool != "" && f.Pool != key {
			continue
		}
		if f.Policy == "included" && !row.Included || f.Policy == "excluded" && row.Included {
			continue
		}
		if f.Membership == "with_vm" && !row.VMExists || f.Membership == "empty" && row.VMExists {
			continue
		}
		if f.Power == "on" && (!row.VMExists || !row.PoweredOn) || f.Power == "off" && (!row.VMExists || row.PoweredOn) {
			continue
		}
		if f.Import == "imported" && !row.Imported || f.Import == "not_imported" && (!row.VMExists || row.Imported) || f.Import == "retired" && !row.Retired {
			continue
		}
		if f.Environment != "" {
			if f.Environment == "unspecified" {
				if strings.TrimSpace(row.Environment) != "" {
					continue
				}
			} else if rarCatalogEnvironmentCode(row.Environment) != rarCatalogEnvironmentCode(f.Environment) {
				continue
			}
		}
		if f.Notes == "yes" && strings.TrimSpace(row.Observation) == "" || f.Notes == "no" && strings.TrimSpace(row.Observation) != "" {
			continue
		}
		if needle != "" && !strings.Contains(strings.ToLower(row.PoolName+" "+row.VMName+" "+row.SourceName+" "+row.Observation), needle) {
			continue
		}
		out = append(out, row)
	}
	return out
}

func (a *App) reportsPoolVMs(w http.ResponseWriter, r *http.Request) {
	f, err := readPoolVMReportFilters(r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	all, sources, pools, err := a.collectPoolVMReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	filtered := filterPoolVMReport(all, f)
	total := len(filtered)
	pages := (total + f.PageSize - 1) / f.PageSize
	if pages < 1 {
		pages = 1
	}
	if f.Page > pages {
		f.Page = pages
	}
	start := (f.Page - 1) * f.PageSize
	end := start + f.PageSize
	if end > total {
		end = total
	}
	vmCount, notImported, excluded := 0, 0, 0
	for _, row := range filtered {
		if row.VMExists {
			vmCount++
			if !row.Imported {
				notImported++
			}
			if !row.Included {
				excluded++
			}
		}
	}
	optionsEnv := map[string]bool{}
	for _, row := range all {
		if value := rarCatalogEnvironmentCode(row.Environment); value != "" {
			optionsEnv[value] = true
		}
	}
	env := make([]string, 0, len(optionsEnv))
	for item := range optionsEnv {
		env = append(env, item)
	}
	sort.Strings(env)
	jsonResponse(w, http.StatusOK, map[string]any{
		"generated_at": time.Now().UTC(), "items": filtered[start:end], "total": total, "pages": pages,
		"page": f.Page, "page_size": f.PageSize, "sources": sources, "pools": pools, "environments": env,
		"summary": map[string]int{"rows": total, "vms": vmCount, "not_imported": notImported, "excluded_vms": excluded},
	})
}

func (a *App) exportReportPoolVMsWord(w http.ResponseWriter, r *http.Request) {
	f, err := readPoolVMReportFilters(r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	all, sources, pools, err := a.collectPoolVMReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	filtered := filterPoolVMReport(all, f)
	if len(filtered) > 25000 {
		http.Error(w, "prea multe randuri pentru Word (maxim 25000); aplica filtre", http.StatusRequestEntityTooLarge)
		return
	}
	docRows := make([]documents.PoolVMReportEntry, 0, len(filtered))
	for _, item := range filtered {
		vmName := item.VMName
		if !item.VMExists && item.PoolVMCount > 0 {
			vmName = "(sincronizare VCSA necesară)"
		}
		docRows = append(docRows, documents.PoolVMReportEntry{GroupKey: fmt.Sprintf("%d:%s", item.SourceID, item.PoolMoID), Pool: item.PoolName, VM: vmName, Observation: item.Observation})
	}
	labels := make([]string, 0)
	if f.Query != "" {
		labels = append(labels, "Căutare: "+f.Query)
	}
	if f.Source != "" {
		name := f.Source
		for _, option := range sources {
			if option.Value == f.Source {
				name = option.Label
				break
			}
		}
		labels = append(labels, "Sursă: "+name)
	}
	if f.Pool != "" {
		name := f.Pool
		for _, option := range pools {
			if option.Value == f.Pool {
				name = option.Label
				break
			}
		}
		labels = append(labels, "Pool: "+name)
	}
	if f.Policy != "" {
		labels = append(labels, "Includere: "+f.Policy)
	}
	if f.Power != "" {
		labels = append(labels, "Power: "+f.Power)
	}
	if f.Environment != "" {
		labels = append(labels, "Mediu: "+f.Environment)
	}
	if f.Import != "" {
		labels = append(labels, "Import: "+f.Import)
	}
	if f.Notes != "" {
		labels = append(labels, "Obs.: "+f.Notes)
	}
	if f.Membership != "" {
		labels = append(labels, "Pool: "+f.Membership)
	}
	data, err := documents.BuildPoolVMReportDOCX(docRows, labels, time.Now().UTC())
	if err != nil {
		respond(w, nil, err)
		return
	}
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="vm-doc-pool-vm-%s.docx"`, time.Now().UTC().Format("20060102-150405")))
	w.Header().Set("Content-Length", strconv.Itoa(len(data)))
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(data)
}
