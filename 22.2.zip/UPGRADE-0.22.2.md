# Upgrade VM-DOC Server 0.22.1 → 0.22.2

## Pregătire

1. Verifică **sursele**: `cat VERSION` trebuie să afișeze `0.22.1`.
2. Fă backup al bazei MariaDB, configurației, surselor și binarului efectiv (caută calea în `systemctl cat vm-doc-server`). Testează în staging înainte de PROD.
3. În această versiune **nu există migrare SQL nouă**. Tabelele catalogului introduse în 0.22.1 / migrarea 087 rămân neschimbate.

## Aplicare

Arhiva ZIP este direct extragibilă peste **sursele 0.22.1** (nu peste binarul instalat):

```bash
cd /CALE/CATRE/SURSE-VM-DOC
unzip -o /CALE/VM-DOC-UPDATE-221-222.zip -d .
cat VERSION # 0.22.2
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Verifică `systemctl cat vm-doc-server` pentru `ExecStart`, oprește serviciul, salvează binarul anterior și instalează binarul nou rezultat în **calea reală** configurată în unit. Repornește serviciul, verifică `journalctl -u vm-doc-server -n 70 --no-pager -l` și `/version` = `0.22.2`. Apoi fă `Ctrl+F5` în browser.

## Teste după instalare

- RAR Anexa 6 → VM-uri pe resource pool-uri: fără filtre, apoi `Mediu=PROD`, `Power=Pornite`; comparați cu VM-uri cunoscute din cluster. Verificați `Prod` / `Producție` / `Production`, TEST, DEV, Nespecificat, plus pool-uri excluse/neimportate.
- RAR Anexa 6 → A3. Produse software și servicii: aceleași filtre; lista și exportul Word să corespundă. Unele VM-uri neimportate pot să nu aibă mediu.
- Ambele pagini: testează filtrarea combinată, rezumatul filtrelor, resetarea, paginarea, schimbarea vCenter și selectarea pool-ului. În Word verifică toate rândurile filtrate, nu doar pagina vizibilă.
- Verifică vizual că în raportul Pool prima coloană rămâne îmbinată vertical în Word.

## Rollback

Fără schimbări de schemă; poți restaura binarul și sursele **0.22.1** dacă apare o regresie. Nu rula migrarea `.down.sql` pentru 087.

## Limitele validării

Au trecut testele izolate Go, sintaxa JS, simularea UI și verificarea patch-ului. Nu au putut fi validate aici build-ul complet și interogările pe MariaDB/VCSA reale (lipsește `vendor/`).
