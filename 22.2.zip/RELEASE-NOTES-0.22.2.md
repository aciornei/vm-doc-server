# VM-DOC Server 0.22.2 — Hotfix filtre RAR Anexa 6 (2026-11-17)

**Bază:** server 0.22.1. **Agent:** 1.7.18, nemodificat. **Schema DB:** fără migrare nouă (ultima este 087).

## Cauza

Rapoartele **VM-uri pe resource pool-uri** și **A3. Produse software și servicii** folosesc `filterPoolVMReport`, care compara strict `row.Environment` cu `f.Environment`, fără normalizare. Astfel, mediul `Producție` sau `Production` putea să nu fie recunoscut când utilizatorul filtra `PROD` împreună cu `Power=Pornite`. Raportul agregat de produse software fusese corectat deja în 0.21.100, dar celelalte două rapoarte nu îi reutilizau regula.

## Corecție

- Interogarea citește `nomenclature_items.item_code` cu prioritate, apoi numele din nomenclator și câmpul legacy `vm_operational_metadata.environment`. Îmbinarea este aplicată numai la mașinile importate în VM-DOC; VM-urile VCSA neimportate pot avea mediul nespecificat.
- Filtrul utilizează `rarCatalogEnvironmentCode` existent pentru echivalențe `PROD` / `Production` / `Productie` / `Producție` / `Producţie`, precum și `TEST` și `DEV`. Power rămâne bazat pe starea din ultima observare VCSA (`powered_on`).
- Valorile din dropdown-ul Mediu al raportului Pool sunt deduplicate după codul normalizat; nu mai apar separat `PROD` și `Producție`.
- Interfața celor două rapoarte folosește Căutare separat, grupuri «Surse și pool-uri», «Filtre VM», opțiuni suplimentare, resetare și rezumatul filtrelor active.
- Filtrarea din exportul Word este aceeași funcție backend ca în afișarea HTML; formatul DOCX, cele trei/șase coloane și contopirea verticală a numelui pool-ului rămân neschimbate.

## Fișiere schimbate

`internal/server/pool_vm_reports.go`, `internal/server/pool_vm_reports_test.go`, `web/static/js/app.js`, `web/static/index.html`, `web/static/releases.json`, `VERSION`, `openapi/openapi.yaml` (numai versiunea), `README.md`, `CHANGELOG.md`, `CONTEXT.md`, `VM-DOC-TODO.md`, `docs/TODO.md`, `RELEASE-NOTES-0.22.2.md` și `UPGRADE-0.22.2.md`.

## Verificări

- `node --check web/static/js/app.js` — PASS.
- Test Go izolat care compilează **funcțiile originale extrase** din sursă și regresia `TestRARPoolAndA3EnvironmentPowerCombined`: **PASS** pentru PROD+Pornite, PROD+Oprite, TEST, DEV și Nespecificat.
- Smoke UI în Node pe funcțiile originale de pagină: filtre/rezumat/query export Word — **PASS** pentru ambele rapoarte.
- `GOPROXY=off go test ./internal/documents ./internal/buildinfo` — **PASS**.
- Build-ul complet și testele de integrare MariaDB/VCSA nu au putut fi executate aici deoarece lipsesc modulele `vendor/`; testează în staging.

## Compatibilitate și limitări

Nu modifică vCenter, regulile de includere/excludere din pool-uri, datele persistente, migrarea 087, raportul agregat RAR, catalogul de componente sau agentul. Pentru VM-uri neimportate în VM-DOC nu se inventează mediu PROD; rezultatul cu filtru de mediu le poate exclude. La diferențe de număr între rapoarte, verifică starea ultimei sincronizări VCSA și dacă VM-ul este importat / are mediu atribuit.
