-- 0.19.14: PostgreSQL scheduled-job metadata (pgAgent / pg_cron).
-- SQL/script bodies are intentionally not stored.
ALTER TABLE database_instances
  ADD COLUMN scheduled_jobs_json LONGTEXT NULL AFTER catalog_discovery_reason,
  ADD COLUMN scheduled_job_discovery_status VARCHAR(64) NOT NULL DEFAULT '' AFTER scheduled_jobs_json,
  ADD COLUMN scheduled_job_discovery_reason VARCHAR(64) NOT NULL DEFAULT '' AFTER scheduled_job_discovery_status;
