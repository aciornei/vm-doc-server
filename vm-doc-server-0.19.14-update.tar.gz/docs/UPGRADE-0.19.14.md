# Upgrade vm-doc-server 0.19.13 → 0.19.14

0.19.14 adaugă persistarea și prezentarea metadata joburilor PostgreSQL `pgAgent` / `pg_cron` furnizate de vm-doc-agent 1.6.10.

## Noutăți

- VM → Baze de date afișează joburile PostgreSQL programate și statusul discovery per instanță;
- instanțele multi-instance sunt prezentate cu data directory, endpoint și socket;
- fișa VM și fișa serviciului includ metadata joburilor DB;
- SQL-ul/comanda/scriptul joburilor nu este colectat sau stocat;
- motive noi afișabile: `maintenance_database_missing`, `user_switch_unavailable`;
- migrare nouă: `044_database_scheduled_jobs.up.sql`.

## Upgrade server

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.13 vm-doc-server-0.19.14
tar -xzf /cale/vm-doc-server-0.19.14-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.14
cd /usr/local/src/vm-doc-server-0.19.14
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

La pornire se aplică automat migrarea `044_database_scheduled_jobs.up.sql`.

## Agent

Publicați vm-doc-agent 1.6.10 pentru `linux/amd64` și, unde este cazul, `linux/386`. Agentul 1.6.10 folosește `runuser` sau fallback `su`, tratează PostgreSQL per instanță și încearcă baza tehnică `postgres` apoi `template1`.

## Permisiuni pentru joburi PostgreSQL

Enumerarea bazelor poate funcționa chiar dacă metadata pgAgent/pg_cron nu este accesibilă. Dacă doriți inventarierea schedulerului, rolul `vm-doc-inventory` trebuie să poată face CONNECT la baza în care schedulerul este instalat și SELECT numai pe tabelele de metadata necesare. Exemple orientative:

```sql
GRANT USAGE ON SCHEMA pgagent TO "vm-doc-inventory";
GRANT SELECT ON pgagent.pga_job, pgagent.pga_schedule TO "vm-doc-inventory";

GRANT USAGE ON SCHEMA cron TO "vm-doc-inventory";
GRANT SELECT ON cron.job TO "vm-doc-inventory";
```

Acordați numai permisiunile pentru schedulerul existent și numai în baza unde este instalat. Nu sunt necesare drepturi asupra tabelelor aplicației.

## Verificări

1. `/version` trebuie să raporteze `0.19.14`.
2. După colectare cu agent 1.6.10, VM → Baze de date trebuie să arate separat instanțele PostgreSQL de pe porturi diferite.
3. Pe o instalație fără baza `postgres`, discovery trebuie să poată folosi `template1`.
4. Pe SUSE/SLES 11 fără `runuser`, discovery trebuie să folosească `su`.
5. Dacă există pgAgent/pg_cron și permisiunile permit, trebuie să apară `Joburi programate PostgreSQL`.
6. În inventar și DOCX nu trebuie să apară SQL-ul/comanda/scriptul jobului.
