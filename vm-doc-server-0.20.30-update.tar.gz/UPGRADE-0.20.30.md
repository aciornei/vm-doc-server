# Upgrade vm-doc-server 0.20.29 → 0.20.30

Versiunea 0.20.30 adaugă integrarea directă cu Outline.

## Ce se schimbă

- migrare nouă `056_outline_integration.up.sql`;
- setările Outline sunt administrate din **Documente → Outline**;
- API key-ul este criptat în baza de date cu cheia master VM-DOC;
- fiecare proiect devine un document Outline;
- VM-urile pot fi publicate ca documente copil sub proiect;
- publicare individuală din fișa Serviciului/VM și publicare în masă din Documente;
- nu există modificări pentru vm-doc-agent.

## Upgrade

```bash
cp -a /usr/local/src/vm-doc-server-0.20.29 \
      /usr/local/src/vm-doc-server-0.20.30

tar -xzf vm-doc-server-0.20.30-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.30

cd /usr/local/src/vm-doc-server-0.20.30

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

La prima pornire, migrarea 056 este aplicată automat.

## Configurare Outline

Nu este nevoie să modificați `secrets.enc`. Din UI:

1. **Documente → Outline**;
2. introduceți URL-ul instanței Outline, de exemplu `https://outline.exemplu.ro`;
3. introduceți `Collection ID` în care vor fi create proiectele;
4. opțional, introduceți ID-ul unui document părinte (de exemplu o pagină `VM-DOC`); dacă este definit, proiectele sunt create sub acel document;
5. introduceți API key-ul Outline;
6. păstrați verificarea TLS activă în mod normal;
7. salvați și apăsați **Testează conexiunea**.

Username-ul și parola Outline nu sunt necesare pentru API; VM-DOC folosește API key-ul.

## Structura creată

```text
Colecție / document părinte
└── Proiect — LIS
    ├── VM — lis-app01
    ├── VM — lis-db01
    └── VM — lis-worker01
```

Publicarea ulterioară actualizează aceleași documente, nu creează duplicate.
