package server

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/documents"
	outlineapi "vm-doc-server/internal/outline"
)

type outlinePublishInput struct {
	ServiceID     int64 `json:"service_id,omitempty"`
	IncludeVMs    bool  `json:"include_vms,omitempty"`
	PoweredOnOnly bool  `json:"powered_on_only,omitempty"`
}

type outlineBulkInput struct {
	IncludeVMs    bool `json:"include_vms"`
	PoweredOnOnly bool `json:"powered_on_only"`
}

type outlinePublishBundle struct {
	Project outlineapi.PublishResult   `json:"project"`
	VMs     []outlineapi.PublishResult `json:"vms,omitempty"`
	Errors  []string                   `json:"errors,omitempty"`
}

type outlineBulkJob struct {
	ID               string    `json:"id"`
	Status           string    `json:"status"`
	StartedAt        time.Time `json:"started_at"`
	FinishedAt       time.Time `json:"finished_at,omitempty"`
	TotalProjects    int       `json:"total_projects"`
	ProcessedProject int       `json:"processed_projects"`
	PublishedProject int       `json:"published_projects"`
	PublishedVMs     int       `json:"published_vms"`
	Errors           []string  `json:"errors,omitempty"`
	LastObject       string    `json:"last_object,omitempty"`
}

var outlineBulkJobs = struct {
	sync.RWMutex
	values map[string]*outlineBulkJob
}{values: map[string]*outlineBulkJob{}}

func (a *App) outlineSettings(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	value, err := a.Outline.GetSettings(r.Context())
	respond(w, value, err)
}

func (a *App) updateOutlineSettings(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	var input outlineapi.SettingsInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Outline.UpdateSettings(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "outline.settings.update", "outline_settings", "1", "success", map[string]any{"enabled": value.Enabled, "base_url": value.BaseURL, "collection_id": value.CollectionID, "parent_document_id": value.ParentDocumentID, "verify_tls": value.VerifyTLS, "allow_http": value.AllowHTTP})
	}
	respond(w, value, err)
}

func (a *App) testOutline(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	value, err := a.Outline.Test(r.Context())
	if err == nil {
		a.auditRequest(r, "outline.connection.test", "outline_settings", "1", "success", map[string]any{"collection_id": value.CollectionID, "collection_name": value.CollectionName})
	}
	respond(w, value, err)
}

func (a *App) publishServiceOutline(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input outlinePublishInput
	if r.ContentLength != 0 {
		if err := decodeJSON(r, &input, 1<<20); err != nil {
			badRequest(w, err)
			return
		}
	}
	bundle, err := a.publishServiceToOutline(r, serviceID, input.IncludeVMs, input.PoweredOnOnly)
	if err == nil {
		a.auditRequest(r, "outline.service.publish", "internal_service", strconv.FormatInt(serviceID, 10), "success", map[string]any{"internal_service_id": serviceID, "outline_document_id": bundle.Project.DocumentID, "outline_url": bundle.Project.URL, "vm_count": len(bundle.VMs), "errors": bundle.Errors})
	}
	respond(w, bundle, err)
}

func (a *App) publishVMOutline(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input outlinePublishInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.publishVMToOutline(r, vmID, input.ServiceID)
	if err == nil {
		a.auditRequest(r, "outline.vm.publish", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{"vm_id": vmID, "internal_service_id": result.ServiceID, "outline_document_id": result.DocumentID, "outline_url": result.URL})
	}
	respond(w, result, err)
}

func (a *App) outlineServiceMapping(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Outline.ServiceMapping(r.Context(), serviceID)
	if errors.Is(err, sql.ErrNoRows) {
		jsonResponse(w, http.StatusOK, map[string]any{"configured": false})
		return
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, map[string]any{"configured": true, "document_id": value.DocumentID, "url": value.URL})
}

func (a *App) outlineVMMapping(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	serviceID, err := strconv.ParseInt(strings.TrimSpace(r.URL.Query().Get("service_id")), 10, 64)
	if err != nil || serviceID <= 0 {
		badRequest(w, errors.New("service_id is required"))
		return
	}
	value, err := a.Outline.VMMapping(r.Context(), serviceID, vmID)
	if errors.Is(err, sql.ErrNoRows) {
		jsonResponse(w, http.StatusOK, map[string]any{"configured": false})
		return
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, map[string]any{"configured": true, "document_id": value.DocumentID, "url": value.URL})
}

func (a *App) startOutlineBulkPublish(w http.ResponseWriter, r *http.Request) {
	var input outlineBulkInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	if _, err := a.Outline.Test(r.Context()); err != nil {
		respond(w, nil, err)
		return
	}
	now := time.Now().UTC()
	id := fmt.Sprintf("outline-%d", now.UnixNano())
	job := &outlineBulkJob{ID: id, Status: "queued", StartedAt: now}
	outlineBulkJobs.Lock()
	for existingID, existing := range outlineBulkJobs.values {
		if !existing.FinishedAt.IsZero() && now.Sub(existing.FinishedAt) > 24*time.Hour {
			delete(outlineBulkJobs.values, existingID)
		}
	}
	outlineBulkJobs.values[id] = job
	outlineBulkJobs.Unlock()

	bgRequest := r.Clone(context.WithoutCancel(r.Context()))
	go a.runOutlineBulkPublish(bgRequest, job, input)
	jsonResponse(w, http.StatusAccepted, job)
}

func (a *App) getOutlineBulkJob(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimSpace(r.PathValue("id"))
	outlineBulkJobs.RLock()
	job := outlineBulkJobs.values[id]
	if job == nil {
		outlineBulkJobs.RUnlock()
		respond(w, nil, sql.ErrNoRows)
		return
	}
	copy := *job
	copy.Errors = append([]string(nil), job.Errors...)
	outlineBulkJobs.RUnlock()
	respond(w, copy, nil)
}

func (a *App) runOutlineBulkPublish(r *http.Request, job *outlineBulkJob, input outlineBulkInput) {
	update := func(fn func(*outlineBulkJob)) {
		outlineBulkJobs.Lock()
		fn(job)
		outlineBulkJobs.Unlock()
	}
	update(func(j *outlineBulkJob) { j.Status = "running" })
	services, err := a.Catalog.List(r.Context(), false)
	if err != nil {
		update(func(j *outlineBulkJob) {
			j.Status = "failed"
			j.FinishedAt = time.Now().UTC()
			j.Errors = append(j.Errors, err.Error())
		})
		return
	}
	update(func(j *outlineBulkJob) { j.TotalProjects = len(services) })
	for _, service := range services {
		update(func(j *outlineBulkJob) { j.LastObject = service.Name })
		bundle, publishErr := a.publishServiceToOutline(r, service.ID, input.IncludeVMs, input.PoweredOnOnly)
		update(func(j *outlineBulkJob) {
			j.ProcessedProject++
			if publishErr != nil {
				j.Errors = append(j.Errors, service.Name+": "+publishErr.Error())
				return
			}
			j.PublishedProject++
			j.PublishedVMs += len(bundle.VMs)
			for _, detail := range bundle.Errors {
				j.Errors = append(j.Errors, service.Name+": "+detail)
			}
		})
	}
	update(func(j *outlineBulkJob) {
		if len(j.Errors) > 0 {
			j.Status = "partial"
		} else {
			j.Status = "success"
		}
		j.FinishedAt = time.Now().UTC()
		j.LastObject = ""
	})
	a.auditRequest(r, "outline.bulk_publish", "outline", job.ID, "success", map[string]any{"projects": job.PublishedProject, "vms": job.PublishedVMs, "errors": len(job.Errors)})
}

func (a *App) publishServiceToOutline(r *http.Request, serviceID int64, includeVMs, poweredOnOnly bool) (outlinePublishBundle, error) {
	if a.Outline == nil {
		return outlinePublishBundle{}, errors.New("Outline integration is unavailable")
	}
	_, data, err := a.serviceDocumentGenerationData(r, serviceID, templateRequest{IncludeGeneratedBy: false}, false)
	if err != nil {
		return outlinePublishBundle{}, err
	}
	if generated, listErr := a.Documents.ListGeneratedService(r.Context(), serviceID); listErr == nil && len(generated) > 0 {
		data.DocumentNumber = generated[0].DocumentNumber
		data.GeneratedAt = generated[0].GeneratedAt
	}
	markdown := documents.RenderServiceMarkdown(data)
	title := "Proiect — " + firstServerNonEmpty(data.Service.Name, data.Service.ServiceCode)
	project, err := a.Outline.UpsertServiceDocument(r.Context(), serviceID, title, markdown)
	if err != nil {
		return outlinePublishBundle{}, err
	}
	bundle := outlinePublishBundle{Project: project}
	if !includeVMs {
		return bundle, nil
	}
	for _, vm := range data.Service.VMs {
		if poweredOnOnly && !strings.EqualFold(strings.TrimSpace(vm.PowerState), "POWERED_ON") {
			continue
		}
		result, vmErr := a.publishVMWithParent(r, vm.ID, serviceID, project.DocumentID)
		if vmErr != nil {
			bundle.Errors = append(bundle.Errors, firstServerNonEmpty(vm.GuestHostname, vm.Name, fmt.Sprintf("VM #%d", vm.ID))+": "+vmErr.Error())
			continue
		}
		bundle.VMs = append(bundle.VMs, result)
	}
	return bundle, nil
}

func (a *App) publishVMToOutline(r *http.Request, vmID, serviceID int64) (outlineapi.PublishResult, error) {
	if serviceID <= 0 {
		operational, err := a.VCenter.GetOperationalMetadata(r.Context(), vmID)
		if err != nil {
			return outlineapi.PublishResult{}, err
		}
		var primary int64
		for _, item := range operational.ServiceAssignments {
			if item.Primary {
				if primary != 0 && primary != item.InternalServiceID {
					return outlineapi.PublishResult{}, errors.New("VM-ul are mai multe proiecte principale; alege proiectul pentru Outline")
				}
				primary = item.InternalServiceID
			}
		}
		if primary > 0 {
			serviceID = primary
		} else if len(operational.ServiceAssignments) == 1 {
			serviceID = operational.ServiceAssignments[0].InternalServiceID
		} else if len(operational.ServiceAssignments) == 0 {
			return outlineapi.PublishResult{}, errors.New("VM-ul nu este asociat niciunui proiect")
		} else {
			return outlineapi.PublishResult{}, errors.New("VM-ul este asociat mai multor proiecte; alege proiectul pentru Outline")
		}
	}

	parentID, err := a.Outline.ServiceDocumentID(r.Context(), serviceID)
	if errors.Is(err, sql.ErrNoRows) {
		bundle, publishErr := a.publishServiceToOutline(r, serviceID, false, false)
		if publishErr != nil {
			return outlineapi.PublishResult{}, fmt.Errorf("create Outline project page: %w", publishErr)
		}
		parentID = bundle.Project.DocumentID
	} else if err != nil {
		return outlineapi.PublishResult{}, err
	}
	return a.publishVMWithParent(r, vmID, serviceID, parentID)
}

func (a *App) publishVMWithParent(r *http.Request, vmID, serviceID int64, parentID string) (outlineapi.PublishResult, error) {
	data, err := a.buildVMGenerationData(r, vmID)
	if err != nil {
		return outlineapi.PublishResult{}, err
	}
	if generated, listErr := a.Documents.ListGeneratedVM(r.Context(), vmID); listErr == nil && len(generated) > 0 {
		data.DocumentNumber = generated[0].DocumentNumber
		data.GeneratedAt = generated[0].GeneratedAt
	}
	data.IncludeGeneratedBy = false
	markdown := documents.RenderVMMarkdown(data)
	title := "VM — " + firstServerNonEmpty(data.VM.GuestHostname, data.VM.Name, fmt.Sprintf("VM %d", vmID))
	return a.Outline.UpsertVMDocument(r.Context(), serviceID, vmID, parentID, title, markdown)
}
