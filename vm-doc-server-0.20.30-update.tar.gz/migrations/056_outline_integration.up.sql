-- 0.20.30: integrare Outline pentru publicarea fișelor proiectelor și VM-urilor.

CREATE TABLE IF NOT EXISTS outline_settings (
  id TINYINT UNSIGNED NOT NULL DEFAULT 1,
  enabled TINYINT(1) NOT NULL DEFAULT 0,
  base_url VARCHAR(1024) NOT NULL DEFAULT '',
  collection_id VARCHAR(64) NOT NULL DEFAULT '',
  parent_document_id VARCHAR(64) NOT NULL DEFAULT '',
  api_key_secret_ref VARCHAR(64) NOT NULL DEFAULT '',
  api_key_ciphertext TEXT NULL,
  verify_tls TINYINT(1) NOT NULL DEFAULT 1,
  allow_http TINYINT(1) NOT NULL DEFAULT 0,
  request_timeout_seconds INT UNSIGNED NOT NULL DEFAULT 30,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  CONSTRAINT chk_outline_settings_singleton CHECK (id=1),
  CONSTRAINT fk_outline_settings_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_outline_settings_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO outline_settings(id) VALUES (1);

CREATE TABLE IF NOT EXISTS outline_service_documents (
  internal_service_id BIGINT UNSIGNED NOT NULL,
  document_id VARCHAR(64) NOT NULL,
  document_url VARCHAR(1024) NOT NULL DEFAULT '',
  content_hash CHAR(64) NOT NULL DEFAULT '',
  last_synced_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (internal_service_id),
  UNIQUE KEY uq_outline_service_document_id (document_id),
  CONSTRAINT fk_outline_service_document_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS outline_vm_documents (
  internal_service_id BIGINT UNSIGNED NOT NULL,
  vm_id BIGINT UNSIGNED NOT NULL,
  document_id VARCHAR(64) NOT NULL,
  document_url VARCHAR(1024) NOT NULL DEFAULT '',
  content_hash CHAR(64) NOT NULL DEFAULT '',
  last_synced_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (internal_service_id,vm_id),
  UNIQUE KEY uq_outline_vm_document_id (document_id),
  KEY idx_outline_vm_document_vm (vm_id),
  CONSTRAINT fk_outline_vm_document_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_outline_vm_document_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
