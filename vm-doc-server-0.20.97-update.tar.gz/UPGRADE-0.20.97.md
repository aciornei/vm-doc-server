# Upgrade VM-DOC Server 0.20.96 → 0.20.97

Nu există migrare DB și nu este necesar update de agent.

1. Oprește `vm-doc-server`.
2. Aplică arhiva incrementală peste sursa/instalarea 0.20.96.
3. Recompilează și repornește serverul conform procedurii curente.
4. Fă `Ctrl+F5` în browser pentru noul `app.js`/`app.css`.

După upgrade, filtrul **Stare VM** folosește Status operațional din nomenclator și va afișa `Retras` pentru VM-urile marcate astfel în Date operaționale.
