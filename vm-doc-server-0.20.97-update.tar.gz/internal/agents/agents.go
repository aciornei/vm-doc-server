package agents

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/url"
	"sort"
	"strings"
	"time"

	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/domain"
)

type Service struct {
	DB     *sql.DB
	Box    *cryptox.Box
	Config config.CollectorConfig
}

type Input struct {
	Name                      string `json:"name"`
	BaseURL                   string `json:"base_url"`
	Enabled                   *bool  `json:"enabled,omitempty"`
	VerifyTLS                 *bool  `json:"verify_tls,omitempty"`
	TLSServerName             string `json:"tls_server_name,omitempty"`
	Token                     string `json:"token,omitempty"`
	CollectionIntervalSeconds int    `json:"collection_interval_seconds,omitempty"`
	RequestTimeoutSeconds     int    `json:"request_timeout_seconds,omitempty"`
	OfflineAfterSeconds       int    `json:"offline_after_seconds,omitempty"`
}

type Record struct {
	domain.Agent
	TokenCiphertext string
}

type Page struct {
	Items                 []domain.Agent `json:"items"`
	Page                  int            `json:"page"`
	PageSize              int            `json:"page_size"`
	Total                 int            `json:"total"`
	Pages                 int            `json:"pages"`
	VMOperationalStatuses []string       `json:"vm_operational_statuses,omitempty"`
}

func (s Service) ListPage(ctx context.Context, query, status, channel, agentType, power, vmStatus string, page, pageSize int) (Page, error) {
	values, err := s.List(ctx)
	if err != nil {
		return Page{}, err
	}
	query = strings.ToLower(strings.TrimSpace(query))
	status = strings.ToLower(strings.TrimSpace(status))
	channel = strings.ToLower(strings.TrimSpace(channel))
	agentType = strings.ToLower(strings.TrimSpace(agentType))
	power = strings.ToUpper(strings.TrimSpace(power))
	vmStatus = strings.TrimSpace(vmStatus)

	statusSet := map[string]string{}
	for _, value := range values {
		name := strings.TrimSpace(value.VMOperationalStatus)
		if value.VMID != nil && name != "" {
			statusSet[strings.ToLower(name)] = name
		}
	}
	vmStatuses := make([]string, 0, len(statusSet))
	for _, name := range statusSet {
		vmStatuses = append(vmStatuses, name)
	}
	sort.Slice(vmStatuses, func(i, j int) bool { return strings.ToLower(vmStatuses[i]) < strings.ToLower(vmStatuses[j]) })

	filtered := make([]domain.Agent, 0, len(values))
	for _, value := range values {
		if status != "" && value.OperationalStatus != status {
			continue
		}
		if !agentPowerMatches(value, power) || !agentVMStatusMatches(value, vmStatus) {
			continue
		}
		if channel == "unknown" && value.Update.Channel != "" {
			continue
		}
		if channel != "" && channel != "unknown" && value.Update.Channel != channel {
			continue
		}
		if agentType == "unknown" {
			if value.AgentType != "unknown" && !strings.HasSuffix(value.AgentType, "-unknown") {
				continue
			}
		} else if agentType != "" && value.AgentType != agentType {
			continue
		}
		if query != "" {
			haystack := strings.ToLower(strings.Join([]string{value.Name, value.BaseURL, value.AgentUUID, value.AgentVersion, value.ManagementIP, value.RegistrationIP, strings.Join(value.ReportedIPs, " "), value.OSName, value.OSVersion, value.OSFamily, value.Architecture, value.AgentRuntimeName, value.AgentType, value.Status, value.OperationalStatus, value.VMName, value.VMPowerState, value.VMOperationalStatus, value.VMOperationalStatusCode, value.LastError, value.Update.Channel, value.Update.State, value.Update.AvailableVersion, value.Update.LastError}, " "))
			if !strings.Contains(haystack, query) {
				continue
			}
		}
		filtered = append(filtered, value)
	}
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 10
	}
	total := len(filtered)
	pages := 0
	if total > 0 {
		pages = (total + pageSize - 1) / pageSize
		if page > pages {
			page = pages
		}
	}
	start := (page - 1) * pageSize
	if start < 0 {
		start = 0
	}
	if start > total {
		start = total
	}
	end := start + pageSize
	if end > total {
		end = total
	}
	return Page{Items: filtered[start:end], Page: page, PageSize: pageSize, Total: total, Pages: pages, VMOperationalStatuses: vmStatuses}, nil
}

func (s Service) List(ctx context.Context) ([]domain.Agent, error) {
	rows, err := s.DB.QueryContext(ctx, agentSelect+` ORDER BY a.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.Agent, 0)
	for rows.Next() {
		r, err := scanAgent(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, r.Agent)
	}
	return out, rows.Err()
}

func (s Service) Get(ctx context.Context, id int64) (domain.Agent, error) {
	r, err := s.GetRecord(ctx, id)
	return r.Agent, err
}

func (s Service) GetRecord(ctx context.Context, id int64) (Record, error) {
	row := s.DB.QueryRowContext(ctx, agentSelect+` WHERE a.id=?`, id)
	return scanAgent(row)
}

func (s Service) Create(ctx context.Context, in Input, userID int64) (domain.Agent, error) {
	if err := s.normalizeAndValidate(&in, true); err != nil {
		return domain.Agent{}, err
	}
	secretRef, err := cryptox.RandomToken(24)
	if err != nil {
		return domain.Agent{}, err
	}
	ciphertext, err := s.Box.Encrypt([]byte(in.Token), "vm-doc-agent-token:"+secretRef)
	if err != nil {
		return domain.Agent{}, err
	}
	enabled, verify := true, true
	if in.Enabled != nil {
		enabled = *in.Enabled
	}
	if in.VerifyTLS != nil {
		verify = *in.VerifyTLS
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO agents(secret_ref,name,base_url,enabled,verify_tls,tls_server_name,token_ciphertext,collection_interval_seconds,request_timeout_seconds,offline_after_seconds,next_collection_at,last_error,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, secretRef, in.Name, strings.TrimRight(in.BaseURL, "/"), enabled, verify, in.TLSServerName, ciphertext, in.CollectionIntervalSeconds, in.RequestTimeoutSeconds, in.OfflineAfterSeconds, time.Now().UTC(), "", userID, userID)
	if err != nil {
		return domain.Agent{}, err
	}
	id, _ := res.LastInsertId()
	return s.Get(ctx, id)
}

func (s Service) Update(ctx context.Context, id int64, in Input, userID int64) (domain.Agent, error) {
	current, err := s.GetRecord(ctx, id)
	if err != nil {
		return domain.Agent{}, err
	}
	if in.Name == "" {
		in.Name = current.Name
	}
	if in.BaseURL == "" {
		in.BaseURL = current.BaseURL
	}
	if in.CollectionIntervalSeconds == 0 {
		in.CollectionIntervalSeconds = current.CollectionIntervalSeconds
	}
	if in.RequestTimeoutSeconds == 0 {
		in.RequestTimeoutSeconds = current.RequestTimeoutSeconds
	}
	if in.OfflineAfterSeconds == 0 {
		in.OfflineAfterSeconds = current.OfflineAfterSeconds
	}
	if in.Enabled == nil {
		v := current.Enabled
		in.Enabled = &v
	}
	if in.VerifyTLS == nil {
		v := current.VerifyTLS
		in.VerifyTLS = &v
	}
	if in.TLSServerName == "" {
		in.TLSServerName = current.TLSServerName
	}
	if err := s.normalizeAndValidate(&in, false); err != nil {
		return domain.Agent{}, err
	}
	ciphertext := current.TokenCiphertext
	if in.Token != "" {
		ciphertext, err = s.Box.Encrypt([]byte(in.Token), "vm-doc-agent-token:"+current.SecretRef)
		if err != nil {
			return domain.Agent{}, err
		}
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE agents SET name=?,base_url=?,enabled=?,verify_tls=?,tls_server_name=?,token_ciphertext=?,collection_interval_seconds=?,request_timeout_seconds=?,offline_after_seconds=?,updated_by=? WHERE id=?`, in.Name, strings.TrimRight(in.BaseURL, "/"), *in.Enabled, *in.VerifyTLS, in.TLSServerName, ciphertext, in.CollectionIntervalSeconds, in.RequestTimeoutSeconds, in.OfflineAfterSeconds, userID, id)
	if err != nil {
		return domain.Agent{}, err
	}
	return s.Get(ctx, id)
}

func (s Service) Delete(ctx context.Context, id int64) error {
	res, err := s.DB.ExecContext(ctx, `DELETE FROM agents WHERE id=?`, id)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) DecryptToken(r Record) (string, error) {
	plain, err := s.Box.Decrypt(r.TokenCiphertext, "vm-doc-agent-token:"+r.SecretRef)
	return string(plain), err
}

func (s Service) normalizeAndValidate(in *Input, create bool) error {
	in.Name = strings.TrimSpace(in.Name)
	in.BaseURL = strings.TrimSpace(in.BaseURL)
	if in.Name == "" || in.BaseURL == "" {
		return errors.New("name and base_url are required")
	}
	u, err := url.Parse(in.BaseURL)
	if err != nil || u.Host == "" {
		return errors.New("invalid base_url")
	}
	if u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return errors.New("base_url must contain only scheme, host and optional port")
	}
	if u.Scheme != "https" && !(s.Config.AllowHTTP && u.Scheme == "http") {
		return errors.New("base_url must use HTTPS")
	}
	if create && strings.TrimSpace(in.Token) == "" {
		return errors.New("token is required")
	}
	if in.CollectionIntervalSeconds == 0 {
		in.CollectionIntervalSeconds = int(s.Config.DefaultCollectionInterval.Value().Seconds())
	}
	if in.RequestTimeoutSeconds == 0 {
		in.RequestTimeoutSeconds = int(s.Config.DefaultRequestTimeout.Value().Seconds())
	}
	if in.OfflineAfterSeconds == 0 {
		in.OfflineAfterSeconds = int(s.Config.DefaultOfflineAfter.Value().Seconds())
	}
	if in.CollectionIntervalSeconds < 60 {
		return errors.New("collection interval must be at least 60 seconds")
	}
	if in.RequestTimeoutSeconds < 1 || in.RequestTimeoutSeconds > 600 {
		return errors.New("request timeout must be between 1 and 600 seconds")
	}
	requestBudget := time.Duration(in.RequestTimeoutSeconds) * time.Second
	if s.Config.RefreshBeforeCollect {
		requestBudget *= 2
	}
	if requestBudget+5*time.Second >= s.Config.LeaseDuration.Value() {
		return errors.New("request timeout is too large for collector.lease_duration")
	}
	if in.OfflineAfterSeconds < in.CollectionIntervalSeconds {
		return errors.New("offline_after must be greater than or equal to collection interval")
	}
	return nil
}

const agentSelect = `SELECT a.id,a.secret_ref,a.name,a.base_url,a.enabled,a.verify_tls,a.tls_server_name,a.token_ciphertext,a.agent_uuid,a.agent_version,COALESCE(a.last_advertised_ip,''),COALESCE(a.last_registration_ip,''),COALESCE(a.reported_ips_json,''),COALESCE(i.primary_ip,''),COALESCE(i.os_name,''),COALESCE(i.os_version,''),COALESCE(JSON_UNQUOTE(JSON_EXTRACT(i.raw_json,'$.os.family')),JSON_UNQUOTE(JSON_EXTRACT(i.raw_json,'$.system.os.family')),''),COALESCE(JSON_UNQUOTE(JSON_EXTRACT(i.raw_json,'$.system.architecture')),JSON_UNQUOTE(JSON_EXTRACT(i.raw_json,'$.os.architecture')),JSON_UNQUOTE(JSON_EXTRACT(i.raw_json,'$.architecture')),''),COALESCE(JSON_UNQUOTE(JSON_EXTRACT(i.raw_json,'$.agent.name')),JSON_UNQUOTE(JSON_EXTRACT(i.raw_json,'$.agent_name')),''),vm.id,COALESCE(vm.name,''),COALESCE(vm.power_state,''),COALESCE(vm.retired,0),COALESCE(vm.present_in_vcenter,0),COALESCE(vos_item.name,NULLIF(vom.operational_status,''),''),COALESCE(vos_item.item_code,''),a.update_channel,a.update_enabled,a.update_auto_install,a.update_state,a.update_available_version,a.update_last_check_at,a.update_last_success_at,COALESCE(a.update_last_error,''),a.update_status_checked_at,a.collection_interval_seconds,a.request_timeout_seconds,a.offline_after_seconds,a.next_collection_at,a.last_attempt_at,a.last_contact_at,a.last_success_at,a.last_error,a.current_inventory_id,a.created_at,a.updated_at FROM agents a LEFT JOIN inventory_snapshots i ON i.id=a.current_inventory_id LEFT JOIN (SELECT agent_id,COALESCE(MIN(CASE WHEN retired=0 THEN id END),MIN(id)) vm_id FROM virtual_machines WHERE agent_id IS NOT NULL GROUP BY agent_id) avm ON avm.agent_id=a.id LEFT JOIN virtual_machines vm ON vm.id=avm.vm_id LEFT JOIN vm_operational_metadata vom ON vom.vm_id=vm.id LEFT JOIN vm_operational_nomenclatures vos ON vos.vm_id=vm.id AND vos.category_code='operational_status' LEFT JOIN nomenclature_items vos_item ON vos_item.id=vos.item_id AND vos_item.category_code='operational_status'`

func effectiveManagementURL(raw, managementIP string) string {
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || u.Hostname() == "" {
		return raw
	}
	currentIP := net.ParseIP(strings.TrimSpace(u.Hostname()))
	management := net.ParseIP(strings.TrimSpace(managementIP))
	// Do not replace DNS names automatically: they can be intentional and
	// required for TLS/SNI. Only self-heal a literal-IP endpoint.
	if currentIP == nil || management == nil || currentIP.Equal(management) {
		return strings.TrimRight(raw, "/")
	}
	host := management.String()
	if port := u.Port(); port != "" {
		host = net.JoinHostPort(host, port)
	} else if management.To4() == nil {
		host = "[" + host + "]"
	}
	u.Host = host
	return strings.TrimRight(u.String(), "/")
}

type scanner interface{ Scan(dest ...any) error }

func scanAgent(s scanner) (Record, error) {
	var r Record
	var next, attempt, contact, success sql.NullTime
	var updateEnabled, updateAutoInstall sql.NullBool
	var updateLastCheck, updateLastSuccess, updateChecked sql.NullTime
	var current, vmID sql.NullInt64
	var vmRetired, vmPresent int
	var reportedIPsJSON, inventoryPrimaryIP string
	if err := s.Scan(&r.ID, &r.SecretRef, &r.Name, &r.BaseURL, &r.Enabled, &r.VerifyTLS, &r.TLSServerName, &r.TokenCiphertext, &r.AgentUUID, &r.AgentVersion, &r.ManagementIP, &r.RegistrationIP, &reportedIPsJSON, &inventoryPrimaryIP, &r.OSName, &r.OSVersion, &r.OSFamily, &r.Architecture, &r.AgentRuntimeName, &vmID, &r.VMName, &r.VMPowerState, &vmRetired, &vmPresent, &r.VMOperationalStatus, &r.VMOperationalStatusCode, &r.Update.Channel, &updateEnabled, &updateAutoInstall, &r.Update.State, &r.Update.AvailableVersion, &updateLastCheck, &updateLastSuccess, &r.Update.LastError, &updateChecked, &r.CollectionIntervalSeconds, &r.RequestTimeoutSeconds, &r.OfflineAfterSeconds, &next, &attempt, &contact, &success, &r.LastError, &current, &r.CreatedAt, &r.UpdatedAt); err != nil {
		return r, err
	}
	if strings.TrimSpace(r.ManagementIP) == "" {
		if parsed, err := url.Parse(r.BaseURL); err == nil {
			r.ManagementIP = strings.TrimSpace(parsed.Hostname())
		}
	}
	// Auto-registered agents can have an older/stale literal-IP base_url (for
	// example a Keepalived/VRRP VIP) while last_advertised_ip already contains
	// the node management address. Expose the effective management endpoint so
	// UI/actions never keep advertising the VIP as the agent endpoint.
	r.BaseURL = effectiveManagementURL(r.BaseURL, r.ManagementIP)
	if strings.TrimSpace(reportedIPsJSON) != "" {
		_ = json.Unmarshal([]byte(reportedIPsJSON), &r.ReportedIPs)
	}
	if len(r.ReportedIPs) == 0 && strings.TrimSpace(inventoryPrimaryIP) != "" {
		r.ReportedIPs = []string{strings.TrimSpace(inventoryPrimaryIP)}
	}
	r.Update.Known = updateChecked.Valid || r.Update.Channel != ""
	if updateEnabled.Valid {
		r.Update.Enabled = updateEnabled.Bool
	}
	if updateAutoInstall.Valid {
		r.Update.AutoInstall = updateAutoInstall.Bool
	}
	r.Update.CurrentVersion = r.AgentVersion
	if updateLastCheck.Valid {
		t := updateLastCheck.Time
		r.Update.LastCheckAt = &t
	}
	if updateLastSuccess.Valid {
		t := updateLastSuccess.Time
		r.Update.LastSuccessAt = &t
	}
	if updateChecked.Valid {
		t := updateChecked.Time
		r.Update.CheckedAt = &t
	}
	r.TokenConfigured = r.TokenCiphertext != ""
	if next.Valid {
		r.NextCollectionAt = &next.Time
	}
	if attempt.Valid {
		r.LastAttemptAt = &attempt.Time
	}
	if contact.Valid {
		r.LastContactAt = &contact.Time
	}
	if success.Valid {
		r.LastSuccessAt = &success.Time
	}
	if current.Valid {
		v := current.Int64
		r.CurrentInventoryID = &v
	}
	if vmID.Valid {
		v := vmID.Int64
		r.VMID = &v
	}
	r.VMRetired = vmRetired != 0
	r.VMPresentInVCenter = vmPresent != 0
	r.Architecture = normalizeAgentArchitecture(r.Architecture)
	r.AgentType = classifyAgentType(r.Agent)
	r.Status = calculateStatus(r.Agent)
	r.OperationalStatus = calculateOperationalStatus(r.Agent)
	return r, nil
}

func normalizeAgentArchitecture(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "amd64", "x86_64", "x86-64", "x64":
		return "amd64"
	case "386", "i386", "i486", "i586", "i686", "x86":
		return "386"
	case "arm64", "aarch64":
		return "arm64"
	default:
		return strings.ToLower(strings.TrimSpace(value))
	}
}

func classifyAgentType(a domain.Agent) string {
	runtimeName := strings.ToLower(strings.TrimSpace(a.AgentRuntimeName))
	osFamily := strings.ToLower(strings.TrimSpace(a.OSFamily))
	osText := strings.ToLower(strings.TrimSpace(a.OSName + " " + a.OSVersion))
	version := strings.ToLower(strings.TrimSpace(a.AgentVersion))
	arch := normalizeAgentArchitecture(a.Architecture)

	isWindows := osFamily == "windows" || strings.Contains(osText, "windows")
	isSUSE := osFamily == "suse" || strings.Contains(osFamily, "sles") || strings.Contains(osText, "suse") || strings.Contains(osText, "sles")
	isLinux := osFamily == "linux" || isSUSE || strings.Contains(osText, "linux") || strings.Contains(osText, "ubuntu") || strings.Contains(osText, "debian") || strings.Contains(osText, "centos") || strings.Contains(osText, "red hat") || strings.Contains(osText, "rhel") || strings.Contains(osText, "rocky") || strings.Contains(osText, "alma") || strings.Contains(osText, "oracle")
	isSLES9 := isSUSE && (strings.HasPrefix(strings.TrimSpace(a.OSVersion), "9") || strings.Contains(osText, "server 9") || strings.Contains(osText, "sles 9"))

	if isSLES9 && (strings.Contains(runtimeName, "legacy") || strings.HasPrefix(version, "1.0.")) {
		return "sles9-legacy"
	}
	if isWindows {
		if strings.Contains(runtimeName, "xp") || strings.Contains(osText, "windows xp") || version == "1.0.1" {
			return "windows-xp"
		}
		if strings.Contains(runtimeName, "legacy") || version == "1.0.2" || version == "1.0.0" {
			return "windows-legacy"
		}
		switch arch {
		case "amd64":
			return "windows-amd64"
		case "386":
			return "windows-386"
		case "":
			return "windows-unknown"
		default:
			return "windows-" + arch
		}
	}
	if isSLES9 {
		return "sles9-legacy"
	}
	if isLinux {
		switch arch {
		case "amd64":
			return "linux-amd64"
		case "386":
			return "linux-386"
		case "":
			return "linux-unknown"
		default:
			return "linux-" + arch
		}
	}
	return "unknown"
}

func agentPowerMatches(a domain.Agent, power string) bool {
	switch strings.ToUpper(strings.TrimSpace(power)) {
	case "":
		return true
	case "UNLINKED":
		return a.VMID == nil
	case "UNKNOWN":
		if a.VMID == nil {
			return false
		}
		value := strings.ToUpper(strings.TrimSpace(a.VMPowerState))
		return value != "POWERED_ON" && value != "POWERED_OFF" && value != "SUSPENDED"
	default:
		return a.VMID != nil && strings.EqualFold(strings.TrimSpace(a.VMPowerState), power)
	}
}

func agentVMIsRetired(a domain.Agent) bool {
	if a.VMRetired {
		return true
	}
	if strings.EqualFold(strings.TrimSpace(a.VMOperationalStatusCode), "retired") {
		return true
	}
	status := strings.ToLower(strings.TrimSpace(a.VMOperationalStatus))
	return status == "retired" || strings.HasPrefix(status, "retras") || strings.Contains(status, "scos din uz") || strings.Contains(status, "scoasă din uz")
}

func agentVMStatusMatches(a domain.Agent, status string) bool {
	status = strings.TrimSpace(status)
	switch strings.ToLower(status) {
	case "":
		return true
	case "active": // compatibilitate cu UI/API 0.20.96
		return a.VMID != nil && !agentVMIsRetired(a)
	case "retired": // compatibilitate cu UI/API 0.20.96
		return a.VMID != nil && agentVMIsRetired(a)
	case "unlinked", "__unlinked__":
		return a.VMID == nil
	case "__unspecified__":
		return a.VMID != nil && strings.TrimSpace(a.VMOperationalStatus) == "" && !a.VMRetired
	default:
		return a.VMID != nil && (strings.EqualFold(strings.TrimSpace(a.VMOperationalStatus), status) || strings.EqualFold(strings.TrimSpace(a.VMOperationalStatusCode), status))
	}
}

func calculateOperationalStatus(a domain.Agent) string {
	if !a.Enabled {
		return "disabled"
	}
	if a.VMID != nil && agentVMIsRetired(a) {
		return "retired"
	}
	if a.VMID != nil && strings.EqualFold(strings.TrimSpace(a.VMPowerState), "POWERED_OFF") && (a.Status == "offline" || a.Status == "unknown") {
		return "powered_off"
	}
	return a.Status
}

func (s Service) SaveUpdateStatus(ctx context.Context, id int64, status domain.AgentUpdateStatus) error {
	now := time.Now().UTC()
	_, err := s.DB.ExecContext(ctx, `UPDATE agents SET update_channel=?,update_enabled=?,update_auto_install=?,update_state=?,update_available_version=?,update_last_check_at=?,update_last_success_at=?,update_last_error=?,update_status_checked_at=? WHERE id=?`,
		strings.ToLower(strings.TrimSpace(status.Channel)), status.Enabled, status.AutoInstall, strings.TrimSpace(status.State), strings.TrimSpace(status.AvailableVersion), nullableTime(status.LastCheckAt), nullableTime(status.LastSuccessAt), truncate(status.LastError, 4000), now, id)
	return err
}

func (s Service) UpdateStatusRefreshDue(ctx context.Context, id int64, maxAge time.Duration) (bool, error) {
	var checked sql.NullTime
	if err := s.DB.QueryRowContext(ctx, `SELECT update_status_checked_at FROM agents WHERE id=?`, id).Scan(&checked); err != nil {
		return false, err
	}
	if !checked.Valid {
		return true, nil
	}
	return time.Since(checked.Time.UTC()) >= maxAge, nil
}

func nullableTime(value *time.Time) any {
	if value == nil {
		return nil
	}
	return value.UTC()
}

func calculateStatus(a domain.Agent) string {
	if !a.Enabled {
		return "disabled"
	}
	if a.LastContactAt == nil {
		return "unknown"
	}
	if time.Since(a.LastContactAt.UTC()) > time.Duration(a.OfflineAfterSeconds)*time.Second {
		return "offline"
	}
	return "online"
}

func (s Service) TouchFailure(ctx context.Context, id int64, message string) error {
	_, err := s.DB.ExecContext(ctx, `UPDATE agents SET last_attempt_at=?,last_error=? WHERE id=?`, time.Now().UTC(), truncate(message, 4000), id)
	return err
}

func (s Service) TouchContact(ctx context.Context, id int64) error {
	_, err := s.DB.ExecContext(ctx, `UPDATE agents SET last_attempt_at=?,last_contact_at=?,last_error='' WHERE id=?`, time.Now().UTC(), time.Now().UTC(), id)
	return err
}

func (s Service) TouchSeen(ctx context.Context, id int64) error {
	now := time.Now().UTC()
	_, err := s.DB.ExecContext(ctx, `UPDATE agents SET last_attempt_at=?,last_contact_at=? WHERE id=?`, now, now, id)
	return err
}

func (s Service) BindUUID(ctx context.Context, id int64, uuid string) error {
	if uuid == "" {
		return nil
	}
	var existing string
	if err := s.DB.QueryRowContext(ctx, `SELECT agent_uuid FROM agents WHERE id=?`, id).Scan(&existing); err != nil {
		return err
	}
	if existing != "" && existing != uuid {
		return fmt.Errorf("uuid_mismatch: expected %s, received %s", existing, uuid)
	}
	if existing == "" {
		_, err := s.DB.ExecContext(ctx, `UPDATE agents SET agent_uuid=? WHERE id=?`, uuid, id)
		return err
	}
	return nil
}

func truncate(v string, n int) string {
	if len(v) > n {
		return v[:n]
	}
	return v
}
