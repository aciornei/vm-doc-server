# VM-DOC Server 0.21.38 — Corecții vizuale pentru revizie colectivă și Grants

Bază: **0.21.37**. Agent: **1.7.18**. **Fără migrare SQL sau schimbări API.**

## Upgrade offline

1. Salvează sursele, binarul curent și un backup MariaDB; folosește staging.
2. Din rădăcina unei COPII a surselor `0.21.37` extrage `vm-doc-server-0.21.38-update.tar.gz` (nu înlocui `vendor/` sau fișiere de configurare).
3. Confirmă `cat VERSION` = `0.21.38`; execută `bash scripts/cleanup-source-tree.sh --check`.
4. Cu `vendor/` pe serverul offline rulează `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build`.
5. Testează pe staging revizia colectivă pentru Conturi, Users, Grants, HBA, Web și reviziile individuale, inclusiv evenimente de audit.
6. Deschide instanța PostgreSQL cu peste 20.000 de granturi; validează gruparea pe utilizator, butonul individual în antet și expandarea grupurilor tehnice, fără pierderi în export Excel.
7. Verifică vizibilitatea checkbox-ului, confirmării și butonului `Aplică revizia` la desktop/mobil, inclusiv când formularul necesită scroll.

## Rollback

Restaurează binarul și sursele 0.21.37; nu există migrații de inversat.

## Compatibilitate

Doar JS, CSS, versiune, cache-busting, changelog, documentație și `releases.json`. Contractele bulk/individual, permisiunile și cheile de revizie nu se schimbă. Agentul 1.7.18 și instanțele vechi rămân compatibile.

## Verificări

- `node --check` și Go OpenAPI/Web/Domain/XLSX/Buildinfo/Migrations OK.
- Chromium mock 20.000 granturi/40 utilizatori: 1595×900, 1024×768, 390×720, 390×510, 350×440; checkbox 18px, footer vizibil, confirmare/submit și expand/collapse OK.
- **Neconfirmate local:** build Go complet cu vendor și teste de integrare MariaDB/date reale.
