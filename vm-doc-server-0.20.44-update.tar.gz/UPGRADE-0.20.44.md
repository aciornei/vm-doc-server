# Upgrade vm-doc-server 0.20.43 -> 0.20.44

Versiunea 0.20.44 repară publicarea VM-urilor în masă către Outline. Nu adaugă migrare DB și nu necesită update de vm-doc-agent.

## Schimbări

- `Documente -> Publică în Outline -> Publică VM-urile` verifică explicit `virtual_machines.outline_documentation_disabled` pentru fiecare VM.
- VM-urile marcate `Nu se publică în Outline` sunt sărite înainte de apelul către Outline.
- Protecția există și în publicarea individuală, pentru a acoperi schimbarea bifei în timpul unui job.
- Progresul jobului afișează `publicate` și `sărite` separat.
- Auditul bulk include `skipped_vms`.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.43 \
      /usr/local/src/vm-doc-server-0.20.44

tar -xzf vm-doc-server-0.20.44-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.44

cd /usr/local/src/vm-doc-server-0.20.44
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După restart, folosește `Ctrl+F5` în browser pentru `app.js?v=0.20.44`.
