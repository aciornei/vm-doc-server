# VM-DOC Server 0.21.90 — Modificări / De documentat

**Bază:** 0.21.89 · **Data:** 2026-10-23 · **Agent:** 1.7.18, nemodificat.

## Modificări
- VM → Modificări → Modificări: textul modificării (denumire + descriere) deschide și închide panoul de diferențe. Butonul separat «Detalii» este eliminat în lista VM și în lista globală. Controalele Documentație, Stare și Salvare rămân separate.
- VM → Modificări → Modificări: stiluri suplimentare pentru eliminarea scrollului orizontal intern și limitarea lățimii datelor în panoul extins.
- Modificări globale: mai mult spațiu la stânga primei coloane VM, inclusiv în antet.
- «De documentat» (global și VM): paginarea este afișată inclusiv când există o singură pagină sau niciun rezultat; există butoane numerotate și selector Pe pagină (10/20/50/100). Paginarea rămâne server-side.

## Compatibilitate / instalare
- Doar JS/CSS/HTML și metadata de versiune. Fără migrare SQL sau modificare a API-ului, a agentului ori a datelor.
- Recompilarea serverului este obligatorie (`go:embed`). Verifică în browser încărcarea `app.js?v=0.21.90`, `app.css?v=0.21.90`.
