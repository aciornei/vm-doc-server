# Upgrade vm-doc-server 0.20.98 → 0.20.99

## Ce se schimbă

- pagina **Agenți** folosește același design de navigare ca **Monitorizare**;
- primul ecran se desenează înainte de finalizarea requestului de listare;
- listarea implicită este paginată direct în SQL și nu mai încarcă toți agenții înainte de `LIMIT/OFFSET`;
- filtrele avansate păstrează comportamentul existent.

## Bază de date / agent

Nu există migrare DB și nu este necesar update de agent.

## După upgrade

Reporniți `vm-doc-server`, apoi în browser folosiți **Ctrl+F5** pentru noul CSS/JS.
