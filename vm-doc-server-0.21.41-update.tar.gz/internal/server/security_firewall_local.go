package server

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"

	"vm-doc-server/internal/xlsx"
)

// A local firewall rule has an inventory-derived stable identity. The server
// validates a review against the currently collected inventory before saving.
type localFirewallRule struct {
	Backend string         `json:"backend"`
	Family  string         `json:"family"`
	Table   string         `json:"table"`
	Chain   string         `json:"chain"`
	Action  string         `json:"action"`
	Rule    string         `json:"rule"`
	Key     string         `json:"resource_key,omitempty"`
	Review  securityReview `json:"review"`
}
type localFirewallInventory struct {
	Backends    []string            `json:"backends"`
	ConfigFiles []string            `json:"config_files"`
	Rules       []localFirewallRule `json:"rules"`
}
type localFirewallResult struct {
	VMID   int64               `json:"vm_id"`
	VMName string              `json:"vm_name"`
	Rules  []localFirewallRule `json:"rules"`
}

func localFirewallRuleKey(r localFirewallRule) string {
	v := []string{r.Backend, r.Family, r.Table, r.Chain, r.Action, r.Rule}
	for i := range v {
		v[i] = strings.TrimSpace(v[i])
	}
	sum := sha256.Sum256([]byte(strings.Join(v, "\x00")))
	return "fwl:" + hex.EncodeToString(sum[:])
}
func localFirewallUserRules(x localFirewallInventory) []localFirewallRule {
	managed := map[string]bool{}
	for _, b := range x.Backends {
		switch strings.ToLower(b) {
		case "ufw", "firewalld", "susefirewall2":
			managed[strings.ToLower(b)] = true
		}
	}
	for _, cfg := range x.ConfigFiles {
		v := strings.ToLower(cfg)
		if strings.Contains(v, "ufw") {
			managed["ufw"] = true
		}
		if strings.Contains(v, "firewalld") {
			managed["firewalld"] = true
		}
		if strings.Contains(v, "susefirewall") {
			managed["susefirewall2"] = true
		}
	}
	for _, r := range x.Rules {
		v := strings.ToLower(r.Chain + " " + r.Rule)
		if strings.Contains(v, "ufw-") {
			managed["ufw"] = true
		}
		if strings.Contains(v, "firewalld") {
			managed["firewalld"] = true
		}
	}
	out := make([]localFirewallRule, 0, len(x.Rules))
	seen := map[string]bool{}
	for _, r := range x.Rules {
		if len(managed) > 0 {
			b := strings.ToLower(r.Backend)
			c := strings.ToLower(r.Chain)
			act := strings.ToLower(r.Action)
			if !managed[b] && !(managed["ufw"] && strings.Contains(c, "ufw-user-") && act != "jump" && act != "goto") {
				continue
			}
		}
		r.Key = localFirewallRuleKey(r)
		if seen[r.Key] {
			continue
		}
		seen[r.Key] = true
		out = append(out, r)
	}
	return out
}
func (a *App) readLocalFirewall(ctx context.Context, vmID int64) (localFirewallResult, error) {
	result := localFirewallResult{VMID: vmID, Rules: []localFirewallRule{}}
	var raw []byte
	err := a.DB.QueryRowContext(ctx, `SELECT vm.name,COALESCE(i.raw_json,'') FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0 AND vm.id=?`, vmID).Scan(&result.VMName, &raw)
	if err != nil {
		return result, err
	}
	if len(raw) == 0 {
		return result, nil
	}
	var envelope struct {
		Firewall localFirewallInventory `json:"firewall"`
	}
	if err = json.Unmarshal(raw, &envelope); err != nil {
		return result, err
	}
	result.Rules = localFirewallUserRules(envelope.Firewall)
	return result, nil
}
func (a *App) localFirewallRulesHandler(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.URL.Query().Get("vm_id"), 10, 64)
	if err != nil || id < 1 {
		badRequest(w, errors.New("alege o VM pentru firewall local"))
		return
	}
	result, err := a.readLocalFirewall(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	reviews, err := a.loadSecurityReviews(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	for i := range result.Rules {
		result.Rules[i].Review = reviewFor(reviews, id, "firewall_local", result.Rules[i].Key, 6)
	}
	respond(w, result, nil)
}
func (a *App) exportLocalFirewall(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.URL.Query().Get("vm_id"), 10, 64)
	if err != nil || id < 1 {
		badRequest(w, errors.New("vm_id invalid"))
		return
	}
	data, err := a.readLocalFirewall(r.Context(), id)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			badRequest(w, errors.New("VM indisponibilă"))
		} else {
			respond(w, nil, err)
		}
		return
	}
	reviews, err := a.loadSecurityReviews(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := [][]xlsx.Cell{{xlsx.Text("VM"), xlsx.Text("Acțiune"), xlsx.Text("Regulă"), xlsx.Text("Backend"), xlsx.Text("Familie"), xlsx.Text("Chain"), xlsx.Text("Review"), xlsx.Text("De"), xlsx.Text("Ultima revizie"), xlsx.Text("Următoarea revizie")}}
	for _, rule := range data.Rules {
		v := reviewFor(reviews, id, "firewall_local", rule.Key, 6)
		status := "Nerevizuit"
		if v.ReviewedAt != nil {
			status = "La zi"
			if v.Due {
				status = "Expirat"
			}
		}
		rows = append(rows, []xlsx.Cell{xlsx.Text(data.VMName), xlsx.Text(rule.Action), xlsx.Text(rule.Rule), xlsx.Text(rule.Backend), xlsx.Text(rule.Family), xlsx.Text(rule.Chain), xlsx.Text(status), xlsx.Text(v.ReviewedBy), xlsx.Text(exportTime(v.ReviewedAt)), xlsx.Text(exportTime(v.NextReviewAt))})
	}
	if err = writeXLSXResponse(w, "Firewall local", "firewall-local", rows); err != nil && a.Logger != nil {
		a.Logger.Error("local firewall export", "error", err)
	}
}
