package server

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/auth"
)

type securityBulkReviewInput struct {
	VMID           int64  `json:"vm_id"`
	Scope          string `json:"scope"`
	InstanceID     int64  `json:"instance_id"`
	IntervalMonths int    `json:"interval_months"`
	Justified      bool   `json:"justified"`
	Notes          string `json:"notes"`
	Confirmed      bool   `json:"confirmed"`
}

type securityBulkReviewTarget struct {
	Type string
	Key  string
}

// Targets are enumerated from current server-side inventory, not arbitrary
// keys supplied by a browser. PostgreSQL pg_* NOLOGIN builtins are excluded
// from the bulk operation, while custom NOLOGIN roles retain their reviews.
func securityBulkTargets(result securityResponse, scope string, instanceID int64) []securityBulkReviewTarget {
	targets := []securityBulkReviewTarget{}
	seen := map[string]bool{}
	add := func(typ, key string) {
		if key == "" || seen[typ+"|"+key] {
			return
		}
		seen[typ+"|"+key] = true
		targets = append(targets, securityBulkReviewTarget{typ, key})
	}
	switch scope {
	case "accounts":
		for _, acc := range result.Accounts {
			if securityAccountRelevant(acc) {
				add("vm_account", acc.Username)
			}
		}
	case "database_principals":
		for _, db := range result.Databases {
			if instanceID > 0 && db.ID != instanceID {
				continue
			}
			for _, principal := range db.Principals {
				if securityDatabaseBuiltInNoLogin(db.Engine, principal) {
					continue
				}
				add("database_principal", securityDBPrincipalReviewKey(db.ID, principal))
			}
		}
	case "database_grants", "database_hba":
		for _, db := range result.Databases {
			if db.ID != instanceID {
				continue
			}
			if scope == "database_grants" {
				for _, group := range db.GrantReviews {
					add("database_grants", group.Review.ResourceKey)
				}
			} else {
				if !strings.EqualFold(db.Engine, "postgresql") {
					continue
				}
				for _, rule := range db.HBARules {
					add("database_hba", rule.Review.ResourceKey)
				}
			}
		}
	case "firewall":
		for _, key := range result.FirewallKeys {
			add("firewall", key)
		}
	case "firewall_local":
		for _, key := range result.FirewallLocalKeys {
			add("firewall_local", key)
		}
	case "web":
		for _, site := range result.WebSites {
			add("web", strconv.FormatInt(site.ID, 10))
		}
	}
	return targets
}

func (a *App) bulkSecurityReview(w http.ResponseWriter, r *http.Request) {
	var in securityBulkReviewInput
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	in.Scope = strings.TrimSpace(in.Scope)
	in.Notes = strings.TrimSpace(in.Notes)
	if in.VMID < 1 || (in.Scope != "accounts" && in.Scope != "database_principals" && in.Scope != "database_grants" && in.Scope != "database_hba" && in.Scope != "web" && in.Scope != "firewall" && in.Scope != "firewall_local") || in.InstanceID < 0 || (in.InstanceID != 0 && in.Scope != "database_principals" && in.Scope != "database_grants" && in.Scope != "database_hba") || ((in.Scope == "database_grants" || in.Scope == "database_hba") && in.InstanceID < 1) || (in.IntervalMonths != 6 && in.IntervalMonths != 12) || !in.Confirmed {
		badRequest(w, errors.New("parametri revizie colectivă invalizi sau confirmare absentă"))
		return
	}
	if len([]rune(in.Notes)) < 10 || len(in.Notes) > 2000 {
		badRequest(w, errors.New("observațiile reviziei colective trebuie să conțină 10–2000 caractere"))
		return
	}
	ctx := r.Context()
	result := securityResponse{}
	reviews := map[string]securityReview{}
	var err error
	switch in.Scope {
	case "accounts":
		err = a.loadSecurityAccounts(ctx, reviews, &result, in.VMID)
	case "database_principals", "database_grants", "database_hba":
		err = a.loadSecurityDatabases(ctx, reviews, &result, in.VMID)
	case "firewall":
		for page := 1; ; page++ {
			if page > 20 {
				badRequest(w, errors.New("prea multe reguli FortiGate pentru revizie colectivă (maximum 10000)"))
				return
			}
			v, loadErr := a.FortiGate.ListRules(ctx, "", "", "", "", "", "", "", "", "", 0, in.VMID, page, 500)
			if loadErr != nil {
				respond(w, nil, loadErr)
				return
			}
			for _, rule := range v.Items {
				key := strings.TrimSpace(rule.Review.ResourceKey)
				if key != "" {
					result.FirewallKeys = append(result.FirewallKeys, key)
				}
			}
			if page >= v.Pages {
				break
			}
		}
	case "firewall_local":
		var data localFirewallResult
		data, err = a.readLocalFirewall(ctx, in.VMID)
		if err == nil {
			for _, rule := range data.Rules {
				result.FirewallLocalKeys = append(result.FirewallLocalKeys, rule.Key)
			}
		}
	case "web":
		err = a.loadSecurityWeb(ctx, reviews, &result, in.VMID)
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	targets := securityBulkTargets(result, in.Scope, in.InstanceID)
	if len(targets) == 0 {
		badRequest(w, errors.New("nu există obiecte eligibile în această secțiune/instanță DB"))
		return
	}
	if len(targets) > 10000 {
		badRequest(w, errors.New("prea multe obiecte pentru o singură revizie (maximum 10000)"))
		return
	}
	if err = a.writeBulkSecurityReviews(ctx, in, targets, securityBulkActorID(r)); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "security.access.review.bulk", "security_review", fmt.Sprintf("%d:%s:%d", in.VMID, in.Scope, in.InstanceID), "success", map[string]any{"vm_id": in.VMID, "scope": in.Scope, "instance_id": in.InstanceID, "count": len(targets), "interval_months": in.IntervalMonths, "justified": in.Justified})
	respond(w, map[string]any{"updated": len(targets), "vm_id": in.VMID, "scope": in.Scope, "instance_id": in.InstanceID}, nil)
}

func securityBulkActorID(r *http.Request) any {
	user, _ := auth.UserFromContext(r.Context())
	return user.ID
}

func (a *App) writeBulkSecurityReviews(ctx context.Context, in securityBulkReviewInput, targets []securityBulkReviewTarget, actor any) error {
	tx, err := a.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	stmt, err := tx.PrepareContext(ctx, `INSERT INTO security_reviews(vm_id,resource_type,resource_key,interval_months,justified,notes,reviewed_at,next_review_at,reviewed_by) VALUES(?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE interval_months=VALUES(interval_months),justified=VALUES(justified),notes=VALUES(notes),reviewed_at=VALUES(reviewed_at),next_review_at=VALUES(next_review_at),reviewed_by=VALUES(reviewed_by)`)
	if err != nil {
		return err
	}
	defer stmt.Close()
	now := time.Now().UTC()
	next := now.AddDate(0, in.IntervalMonths, 0)
	for _, target := range targets {
		if _, err = stmt.ExecContext(ctx, in.VMID, target.Type, target.Key, in.IntervalMonths, in.Justified, in.Notes, now, next, actor); err != nil {
			return err
		}
	}
	return tx.Commit()
}
