package server

import (
	"strings"
	"testing"
)

func TestLocalFirewallStableKeysAndDedup(t *testing.T) {
	r := localFirewallRule{Backend: "ufw", Chain: "ufw-user-input", Action: "ACCEPT", Rule: "from 10.0.0.0/8 to any port 443"}
	if got := localFirewallRuleKey(r); !strings.HasPrefix(got, "fwl:") || len(got) != 68 {
		t.Fatalf("invalid key %q", got)
	}
	if localFirewallRuleKey(r) != localFirewallRuleKey(r) {
		t.Fatal("unstable key")
	}
	rules := localFirewallUserRules(localFirewallInventory{Backends: []string{"ufw"}, Rules: []localFirewallRule{r, r, {Backend: "iptables", Chain: "ufw-before-input", Action: "jump", Rule: "jump ufw-user-input"}}})
	if len(rules) != 1 {
		t.Fatalf("expected one user rule, got %d", len(rules))
	}
	if rules[0].Key != localFirewallRuleKey(r) {
		t.Fatal("review key mismatch")
	}
}
func TestLocalFirewallKeepsDirectRules(t *testing.T) {
	r := localFirewallUserRules(localFirewallInventory{Rules: []localFirewallRule{{Backend: "iptables", Chain: "INPUT", Action: "DROP", Rule: "tcp dport 22 drop"}}})
	if len(r) != 1 || r[0].Action != "DROP" {
		t.Fatalf("direct rules lost: %+v", r)
	}
}
func TestFirewallBulkTargetsDeduplicate(t *testing.T) {
	r := securityResponse{FirewallKeys: []string{"forti:1", "forti:1", "forti:2"}, FirewallLocalKeys: []string{"fwl:one", "fwl:one"}}
	if got := securityBulkTargets(r, "firewall", 0); len(got) != 2 {
		t.Fatalf("Forti targets %d", len(got))
	}
	if got := securityBulkTargets(r, "firewall_local", 0); len(got) != 1 || got[0].Type != "firewall_local" {
		t.Fatalf("local targets %+v", got)
	}
}
