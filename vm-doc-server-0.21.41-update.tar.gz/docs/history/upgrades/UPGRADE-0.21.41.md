# Upgrade VM-DOC Server 0.21.40 → 0.21.41

1. Backup binar, surse, DB MariaDB și configurație.
2. În arborele **curat** de surse 0.21.40, aplică `tar -xzf vm-doc-server-0.21.41-update.tar.gz` sau `git apply vm-doc-server-0.21.40-to-0.21.41.patch` (alternative, nu amândouă).
3. Confirmă `cat VERSION` → `0.21.41`.
4. Rulează `bash scripts/cleanup-source-tree.sh --check`, `GOPROXY=off GOSUMDB=off go test ./...`, `GOPROXY=off GOSUMDB=off make build` folosind `vendor/` local.
5. Test în staging: Firewall global, fișa VM, moduri Forti/Local, exporturi XLSX, revizie individuală și colectivă, RBAC/CSRF, audit și rollback.

**Rollback:** restaurează binarul și sursele 0.21.40. Fără migrare SQL.
