# Upgrade vm-doc-server 0.19.3 → 0.19.4

0.19.4 adaugă curățarea definitivă a înregistrărilor VM care nu mai sunt prezente în vCenter. Nu introduce un mecanism nou de arhivare.

## Noutăți

- filtru `vCenter`: toate / prezente / lipsă din vCenter;
- VM-urile lipsă afișează `missing_since` și sunt ordonate de la cele mai vechi;
- ștergere definitivă individuală din lista VM și din fila **Infrastructură** a VM-ului;
- selecție și ștergere bulk pentru VM-urile lipsă de pe pagina curentă, maximum 200 per operație;
- endpoint de impact înainte de ștergere: asocieri servicii, fișe generate, backup, targeturi monitorizare, conexiuni externe, responsabilități și modificări inventar;
- serverul refuză ștergerea unei VM care este încă `present_in_vcenter=1`;
- ștergerea este tranzacțională; pentru bulk, dacă una dintre VM-uri este încă prezentă în vCenter, nu se șterge nimic;
- targeturile Prometheus/Blackbox nu sunt șterse: sunt decorelate și pot fi recorelate la următorul Sync;
- agentul asociat nu este șters automat;
- eveniment de audit `vm.delete.permanent` pentru fiecare VM eliminată.

## Bază de date

Nu există migrare DB nouă în 0.19.4. Sunt folosite FK-urile `ON DELETE CASCADE` / `ON DELETE SET NULL` existente.

## Pași

1. Actualizați sursa serverului la 0.19.4.
2. Rulați testele și buildul offline cu `vendor/`.
3. Înlocuiți binarul `vm-doc-server` și reporniți serviciul.
4. Faceți `Ctrl+F5` în browser.
5. Rulați mai întâi un Sync vCenter, ca `present_in_vcenter` și `missing_since` să fie actuale.
6. În **VM-uri → vCenter → Lipsă din vCenter**, verificați VM-urile vechi și ștergeți individual sau bulk.

`vm-doc-agent` rămâne 1.6.3.
