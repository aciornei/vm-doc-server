package buildinfo

var (
	Version = "0.19.4-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
