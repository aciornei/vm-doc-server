package vcenter

import (
	"strings"
	"testing"
)

func TestNormalizeVMFilter(t *testing.T) {
	got := NormalizeVMFilter(VMFilter{Page: -1, PageSize: 1000, Agent: " ONLINE ", Retired: " FALSE ", Presence: " MISSING "})
	if got.Page != 1 || got.PageSize != maxVMPageSize || got.Agent != "online" || got.Retired != "false" || got.Presence != "missing" {
		t.Fatalf("unexpected normalized filter: %+v", got)
	}
}

func TestBuildVMWhere(t *testing.T) {
	where, args, err := buildVMWhere(NormalizeVMFilter(VMFilter{
		Query: "ubuntu", Power: "POWERED_ON", Agent: "configured", Retired: "false", Presence: "missing", SourceID: 4, ServiceID: 7,
	}))
	if err != nil {
		t.Fatal(err)
	}
	for _, part := range []string{"vm.name LIKE ?", "vm.power_state=?", "vm.vcenter_source_id=?", "FIND_IN_SET(?,COALESCE(svcmap.service_ids,''))>0", "vm.retired=0", "vm.present_in_vcenter=0", "vm.agent_id IS NOT NULL"} {
		if !strings.Contains(where, part) {
			t.Errorf("where clause missing %q: %s", part, where)
		}
	}
	if len(args) != 16 {
		t.Fatalf("got %d args, want 16", len(args))
	}
}

func TestBuildVMWhereRejectsUnknownAgent(t *testing.T) {
	_, _, err := buildVMWhere(NormalizeVMFilter(VMFilter{Agent: "broken"}))
	if err == nil {
		t.Fatal("expected error")
	}
}

func TestBuildVMWhereRejectsUnknownPresence(t *testing.T) {
	_, _, err := buildVMWhere(NormalizeVMFilter(VMFilter{Presence: "ghost"}))
	if err == nil {
		t.Fatal("expected error")
	}
}

func TestNormalizeDeleteIDs(t *testing.T) {
	ids, err := normalizeDeleteIDs([]int64{9, 2, 9, 4})
	if err != nil {
		t.Fatal(err)
	}
	want := []int64{2, 4, 9}
	if len(ids) != len(want) {
		t.Fatalf("got %v, want %v", ids, want)
	}
	for i := range want {
		if ids[i] != want[i] {
			t.Fatalf("got %v, want %v", ids, want)
		}
	}
}
