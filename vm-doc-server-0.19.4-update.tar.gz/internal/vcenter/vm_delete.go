package vcenter

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"sort"
	"time"
)

var ErrVMPresentInVCenter = errors.New("VM is still present in vCenter; remove it from vCenter and run a sync before permanent deletion")

type VMDeleteImpact struct {
	ID                       int64      `json:"id"`
	Name                     string     `json:"name"`
	PresentInVCenter         bool       `json:"present_in_vcenter"`
	MissingSince             *time.Time `json:"missing_since,omitempty"`
	AgentID                  *int64     `json:"agent_id,omitempty"`
	DirectServiceAssignments int        `json:"direct_service_assignments"`
	ResourceServiceLinks     int        `json:"resource_service_links"`
	GeneratedDocuments       int        `json:"generated_documents"`
	MonitoringTargets        int        `json:"monitoring_targets"`
	BackupRecords            int        `json:"backup_records"`
	ExternalConnections      int        `json:"external_connections"`
	CommonDependencies       int        `json:"common_dependencies"`
	Responsibilities         int        `json:"responsibilities"`
	InventoryChanges         int        `json:"inventory_changes"`
	VCenterIPs               int        `json:"vcenter_ips"`
}

type VMDeleteResult struct {
	Deleted []VMDeleteImpact `json:"deleted"`
	Count   int              `json:"count"`
}

type vmImpactQuerier interface {
	QueryRowContext(context.Context, string, ...any) *sql.Row
}

const vmDeleteImpactSQL = `SELECT
 vm.id,vm.name,vm.present_in_vcenter,vm.missing_since,vm.agent_id,
 (SELECT COUNT(*) FROM vm_internal_service_assignments x WHERE x.vm_id=vm.id),
 ((SELECT COUNT(*) FROM docker_container_service_assignments a JOIN docker_containers c ON c.id=a.docker_container_id WHERE c.vm_id=vm.id)+
  (SELECT COUNT(*) FROM database_instance_service_assignments a JOIN database_instances d ON d.id=a.database_instance_id WHERE d.vm_id=vm.id)+
  (SELECT COUNT(*) FROM database_catalog_service_assignments a JOIN database_catalogs d ON d.id=a.database_catalog_id WHERE d.vm_id=vm.id)+
  (SELECT COUNT(*) FROM web_site_service_assignments a JOIN web_sites w ON w.id=a.web_site_id WHERE w.vm_id=vm.id)),
 (SELECT COUNT(*) FROM generated_documents x WHERE x.vm_id=vm.id),
 (SELECT COUNT(*) FROM monitoring_targets x WHERE x.matched_vm_id=vm.id),
 (SELECT COUNT(*) FROM vm_backup_summary x WHERE x.vm_id=vm.id),
 (SELECT COUNT(*) FROM external_connections x WHERE x.vm_id=vm.id),
 (SELECT COUNT(*) FROM vm_common_service_dependencies x WHERE x.vm_id=vm.id),
 (SELECT COUNT(*) FROM vm_responsibilities x WHERE x.vm_id=vm.id),
 (SELECT COUNT(*) FROM inventory_changes x WHERE x.vm_id=vm.id),
 (SELECT COUNT(*) FROM vcenter_vm_ips x WHERE x.vm_id=vm.id)
 FROM virtual_machines vm WHERE vm.id=?`

func getVMDeleteImpact(ctx context.Context, q vmImpactQuerier, id int64) (VMDeleteImpact, error) {
	var out VMDeleteImpact
	var missing sql.NullTime
	var agent sql.NullInt64
	err := q.QueryRowContext(ctx, vmDeleteImpactSQL, id).Scan(
		&out.ID, &out.Name, &out.PresentInVCenter, &missing, &agent,
		&out.DirectServiceAssignments, &out.ResourceServiceLinks, &out.GeneratedDocuments,
		&out.MonitoringTargets, &out.BackupRecords, &out.ExternalConnections,
		&out.CommonDependencies, &out.Responsibilities, &out.InventoryChanges, &out.VCenterIPs,
	)
	if err != nil {
		return VMDeleteImpact{}, err
	}
	if missing.Valid {
		value := missing.Time
		out.MissingSince = &value
	}
	if agent.Valid {
		value := agent.Int64
		out.AgentID = &value
	}
	return out, nil
}

func (s *Service) GetVMDeleteImpact(ctx context.Context, id int64) (VMDeleteImpact, error) {
	if id <= 0 {
		return VMDeleteImpact{}, errors.New("invalid VM id")
	}
	return getVMDeleteImpact(ctx, s.DB, id)
}

func normalizeDeleteIDs(ids []int64) ([]int64, error) {
	if len(ids) == 0 {
		return nil, errors.New("at least one VM id is required")
	}
	if len(ids) > 200 {
		return nil, errors.New("at most 200 VMs can be deleted at once")
	}
	set := make(map[int64]struct{}, len(ids))
	for _, id := range ids {
		if id <= 0 {
			return nil, errors.New("invalid VM id")
		}
		set[id] = struct{}{}
	}
	out := make([]int64, 0, len(set))
	for id := range set {
		out = append(out, id)
	}
	sort.Slice(out, func(i, j int) bool { return out[i] < out[j] })
	return out, nil
}

func (s *Service) DeleteVMs(ctx context.Context, ids []int64) (VMDeleteResult, error) {
	ids, err := normalizeDeleteIDs(ids)
	if err != nil {
		return VMDeleteResult{}, err
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return VMDeleteResult{}, err
	}
	defer tx.Rollback()

	result := VMDeleteResult{Deleted: make([]VMDeleteImpact, 0, len(ids))}
	for _, id := range ids {
		var present bool
		if err := tx.QueryRowContext(ctx, `SELECT present_in_vcenter FROM virtual_machines WHERE id=? FOR UPDATE`, id).Scan(&present); err != nil {
			return VMDeleteResult{}, err
		}
		if present {
			impact, _ := getVMDeleteImpact(ctx, tx, id)
			name := impact.Name
			if name == "" {
				name = fmt.Sprintf("#%d", id)
			}
			return VMDeleteResult{}, fmt.Errorf("%w: %s", ErrVMPresentInVCenter, name)
		}
		impact, err := getVMDeleteImpact(ctx, tx, id)
		if err != nil {
			return VMDeleteResult{}, err
		}
		if _, err := tx.ExecContext(ctx, `UPDATE monitoring_targets SET matched_vm_id=NULL,match_method='',match_value='',match_confidence='' WHERE matched_vm_id=?`, id); err != nil {
			return VMDeleteResult{}, err
		}
		if _, err := tx.ExecContext(ctx, `DELETE FROM virtual_machines WHERE id=?`, id); err != nil {
			return VMDeleteResult{}, err
		}
		result.Deleted = append(result.Deleted, impact)
	}
	if err := tx.Commit(); err != nil {
		return VMDeleteResult{}, err
	}
	result.Count = len(result.Deleted)
	return result, nil
}

func (s *Service) DeleteVM(ctx context.Context, id int64) (VMDeleteImpact, error) {
	result, err := s.DeleteVMs(ctx, []int64{id})
	if err != nil {
		return VMDeleteImpact{}, err
	}
	if len(result.Deleted) != 1 {
		return VMDeleteImpact{}, sql.ErrNoRows
	}
	return result.Deleted[0], nil
}
