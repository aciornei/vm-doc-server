package server

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	outlineapi "vm-doc-server/internal/outline"
)

const softwareComponentsOutlineTargetCode = "support_components"

type softwareComponentOutlineInput struct {
	Component string `json:"component,omitempty"`
}

type softwareComponentPublishGroup struct {
	Key      string
	Name     string
	Category string
	Rows     []softwareComponentReportRow
}

func softwareComponentOutlineTitle(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "comp-"
	}
	if len(value) >= 5 && strings.EqualFold(value[:5], "comp-") {
		return "comp-" + value[5:]
	}
	return "comp-" + value
}

// softwareComponentOutlineProductionRows applies the Outline publication policy
// without changing the software-component inventory report used by cards/table/XLSX.
// Environment is resolved from the canonical VM operational nomenclature first,
// with the legacy metadata value only as fallback, exactly like VM Outline publish.
func (a *App) softwareComponentOutlineProductionRows(ctx context.Context, rows []softwareComponentReportRow) ([]softwareComponentReportRow, int, error) {
	if len(rows) == 0 {
		return nil, 0, nil
	}
	seen := map[int64]bool{}
	vmIDs := make([]int64, 0)
	for _, row := range rows {
		if row.VMID > 0 && !seen[row.VMID] {
			seen[row.VMID] = true
			vmIDs = append(vmIDs, row.VMID)
		}
	}
	if len(vmIDs) == 0 {
		return nil, len(rows), nil
	}
	placeholders := strings.TrimSuffix(strings.Repeat("?,", len(vmIDs)), ",")
	args := make([]any, 0, len(vmIDs))
	for _, id := range vmIDs {
		args = append(args, id)
	}
	query := `SELECT vm.id,COALESCE(
		(SELECT n.name
		 FROM vm_operational_nomenclatures von
		 JOIN nomenclature_items n ON n.id=von.item_id AND n.category_code='environment'
		 WHERE von.vm_id=vm.id AND von.category_code='environment'
		 LIMIT 1),
		NULLIF(opm.environment,''),
		'')
		FROM virtual_machines vm
		LEFT JOIN vm_operational_metadata opm ON opm.vm_id=vm.id
		WHERE vm.id IN (` + placeholders + `)`
	dbRows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, 0, err
	}
	defer dbRows.Close()
	environmentByVM := make(map[int64]string, len(vmIDs))
	for dbRows.Next() {
		var vmID int64
		var environment string
		if err := dbRows.Scan(&vmID, &environment); err != nil {
			return nil, 0, err
		}
		environmentByVM[vmID] = strings.TrimSpace(environment)
	}
	if err := dbRows.Err(); err != nil {
		return nil, 0, err
	}
	out := make([]softwareComponentReportRow, 0, len(rows))
	skipped := 0
	for _, row := range rows {
		environment, ok := environmentByVM[row.VMID]
		if !ok {
			environment = strings.TrimSpace(row.Environment)
		}
		if !outlineBulkProductionEnvironment(environment) {
			skipped++
			continue
		}
		copyRow := row
		copyRow.Environment = environment
		out = append(out, copyRow)
	}
	return out, skipped, nil
}

func (a *App) startSoftwareComponentOutlinePublish(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		outlineRespond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	var input softwareComponentOutlineInput
	if r.ContentLength != 0 {
		if err := decodeJSON(r, &input, 1<<20); err != nil {
			badRequest(w, err)
			return
		}
	}
	settings, err := a.Outline.GetSettings(r.Context())
	if err != nil {
		outlineRespond(w, nil, err)
		return
	}
	if !settings.Enabled {
		badRequest(w, errors.New("Integrarea Outline este dezactivată"))
		return
	}
	target, err := a.Outline.GetPublicationTarget(r.Context(), softwareComponentsOutlineTargetCode)
	if err != nil {
		outlineRespond(w, nil, err)
		return
	}
	if !target.Active {
		badRequest(w, errors.New("Destinația Outline «Componente suport» este dezactivată"))
		return
	}
	if strings.TrimSpace(target.DocumentReference) == "" {
		badRequest(w, errors.New("Configurează mai întâi Documente → Configurare Outline → Componente suport"))
		return
	}
	if _, err := a.Outline.ResolveDocument(r.Context(), target.DocumentReference); err != nil {
		outlineRespond(w, nil, fmt.Errorf("verificare părinte Outline Componente suport: %w", err))
		return
	}

	report, err := a.softwareComponentReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	productionRows, skippedRows, err := a.softwareComponentOutlineProductionRows(r.Context(), report.Rows)
	if err != nil {
		respond(w, nil, fmt.Errorf("determinare mediu PROD pentru componente Outline: %w", err))
		return
	}
	groups := groupSoftwareComponentRowsForOutline(productionRows, input.Component)
	if len(groups) == 0 {
		if strings.TrimSpace(input.Component) != "" {
			badRequest(w, fmt.Errorf("componenta %q nu are instalări pe VM-uri PROD", strings.TrimSpace(input.Component)))
		} else {
			badRequest(w, errors.New("nu există componente software detectate pe VM-uri PROD pentru publicare"))
		}
		return
	}

	now := time.Now().UTC()
	id := fmt.Sprintf("outline-software-components-%d", now.UnixNano())
	job := &outlineBulkJob{ID: id, Kind: "software_components", Status: "queued", StartedAt: now, TotalComponents: len(groups)}
	outlineBulkJobs.Lock()
	for existingID, existing := range outlineBulkJobs.values {
		if !existing.FinishedAt.IsZero() && now.Sub(existing.FinishedAt) > 24*time.Hour {
			delete(outlineBulkJobs.values, existingID)
		}
	}
	outlineBulkJobs.values[id] = job
	outlineBulkJobs.Unlock()

	bgRequest := r.Clone(context.WithoutCancel(r.Context()))
	go a.runSoftwareComponentOutlinePublish(bgRequest, job, groups, strings.TrimSpace(input.Component), skippedRows)
	jsonResponse(w, http.StatusAccepted, job)
}

func groupSoftwareComponentRowsForOutline(rows []softwareComponentReportRow, component string) []softwareComponentPublishGroup {
	component = strings.ToLower(strings.TrimSpace(component))
	byKey := map[string]*softwareComponentPublishGroup{}
	for _, row := range rows {
		if !outlineBulkProductionEnvironment(row.Environment) {
			continue
		}
		if component != "" && strings.ToLower(row.ComponentKey) != component && strings.ToLower(row.ComponentName) != component {
			continue
		}
		group := byKey[row.ComponentKey]
		if group == nil {
			group = &softwareComponentPublishGroup{Key: row.ComponentKey, Name: row.ComponentName, Category: row.Category}
			byKey[row.ComponentKey] = group
		}
		group.Rows = append(group.Rows, row)
	}
	groups := make([]softwareComponentPublishGroup, 0, len(byKey))
	for _, group := range byKey {
		sort.SliceStable(group.Rows, func(i, j int) bool {
			if supportEnvironmentRank(group.Rows[i].Environment) != supportEnvironmentRank(group.Rows[j].Environment) {
				return supportEnvironmentRank(group.Rows[i].Environment) < supportEnvironmentRank(group.Rows[j].Environment)
			}
			return strings.ToLower(group.Rows[i].VMName) < strings.ToLower(group.Rows[j].VMName)
		})
		groups = append(groups, *group)
	}
	sort.SliceStable(groups, func(i, j int) bool { return strings.ToLower(groups[i].Name) < strings.ToLower(groups[j].Name) })
	return groups
}

func (a *App) runSoftwareComponentOutlinePublish(r *http.Request, job *outlineBulkJob, groups []softwareComponentPublishGroup, selectedComponent string, skippedRows int) {
	update := func(fn func(*outlineBulkJob)) {
		outlineBulkJobs.Lock()
		fn(job)
		outlineBulkJobs.Unlock()
	}
	update(func(j *outlineBulkJob) { j.Status = "running" })

	var last outlineapi.PublishResult
	for _, group := range groups {
		update(func(j *outlineBulkJob) { j.LastObject = group.Name })
		markdown := a.softwareComponentOutlineMarkdown(group)
		title := softwareComponentOutlineTitle(group.Name)
		result, err := a.Outline.UpsertSoftwareComponentDocument(r.Context(), softwareComponentsOutlineTargetCode, group.Key, title, []byte(markdown))
		update(func(j *outlineBulkJob) {
			j.ProcessedComponents++
			if err != nil {
				j.Errors = append(j.Errors, group.Name+": "+err.Error())
				return
			}
			j.PublishedComponents++
			last = result
			if len(groups) == 1 {
				j.ResultURL = result.URL
				j.ResultDocumentID = result.DocumentID
				j.ResultCreated = result.Created
			}
		})
	}
	update(func(j *outlineBulkJob) {
		j.LastObject = ""
		j.FinishedAt = time.Now().UTC()
		switch {
		case j.PublishedComponents == j.TotalComponents:
			j.Status = "success"
		case j.PublishedComponents > 0:
			j.Status = "partial"
		default:
			j.Status = "failed"
		}
	})

	outlineBulkJobs.RLock()
	published, total, finalStatus := job.PublishedComponents, job.TotalComponents, job.Status
	errorsCopy := append([]string(nil), job.Errors...)
	outlineBulkJobs.RUnlock()
	auditStatus := "success"
	if finalStatus == "failed" {
		auditStatus = "failed"
	} else if finalStatus == "partial" {
		auditStatus = "partial"
	}
	a.auditRequest(r, "outline.software_components.publish", "outline_publication_target", softwareComponentsOutlineTargetCode, auditStatus, map[string]any{
		"selected_component": selectedComponent,
		"prod_only":          true,
		"skipped_non_prod":   skippedRows,
		"total":              total,
		"published":          published,
		"errors":             len(errorsCopy),
		"last_document_id":   last.DocumentID,
		"last_outline_url":   last.URL,
	})
	if len(errorsCopy) > 0 && a.Logger != nil {
		a.Logger.Warn("Outline software components publish completed with errors", "published", published, "total", total, "errors", errorsCopy)
	}
}

func (a *App) softwareComponentOutlineMarkdown(group softwareComponentPublishGroup) string {
	location, err := time.LoadLocation(a.Config.App.Timezone)
	if err != nil {
		location = time.UTC
	}
	generatedAt := time.Now().In(location).Format("02.01.2006 15:04")
	vmSet := map[int64]bool{}
	for _, row := range group.Rows {
		vmSet[row.VMID] = true
	}
	var b strings.Builder
	b.WriteString("> Actualizat automat din VM-DOC la **")
	b.WriteString(generatedAt)
	b.WriteString("** · componentă **")
	b.WriteString(markdownTableCell(group.Name))
	b.WriteString("** · categorie **")
	b.WriteString(markdownTableCell(firstText(group.Category, "—")))
	b.WriteString("** · ")
	b.WriteString(strconv.Itoa(len(vmSet)))
	b.WriteString(" VM-uri PROD.\n\n")
	b.WriteString("| VM | Versiune | Power | Mediu | IP | Servicii / proiecte | Detectat din | Dovadă / stare |\n")
	b.WriteString("|---|---|---|---|---|---|---|---|\n")
	for _, row := range group.Rows {
		vmCell := markdownLink(strings.TrimSpace(row.VMName), row.VMOutlineURL)
		if strings.TrimSpace(row.Hostname) != "" && !strings.EqualFold(strings.TrimSpace(row.Hostname), strings.TrimSpace(row.VMName)) {
			vmCell += "<br>" + strings.TrimSpace(row.Hostname)
		}
		status := strings.TrimSpace(row.Status)
		if status == "" {
			status = "—"
		}
		if len(row.Evidence) > 0 {
			status += "<br>" + strings.Join(row.Evidence, " · ")
		}
		cells := []string{
			vmCell,
			firstText(row.Version, "—"),
			outlinePowerLabel(row.PowerState),
			outlineEnvironmentLabel(row.Environment),
			firstText(row.IP, "—"),
			softwareComponentServiceLinksMarkdown(row.ServiceLinks, row.Services),
			firstText(row.Source, "—"),
			status,
		}
		b.WriteString("|")
		for _, cell := range cells {
			b.WriteString(" ")
			b.WriteString(markdownTableCell(cell))
			b.WriteString(" |")
		}
		b.WriteString("\n")
	}
	return b.String()
}

func softwareComponentServiceLinksMarkdown(links []softwareComponentServiceLink, fallback string) string {
	if len(links) > 0 {
		values := make([]string, 0, len(links))
		for _, link := range links {
			if strings.TrimSpace(link.Name) == "" {
				continue
			}
			values = append(values, markdownLink(link.Name, link.URL))
		}
		if len(values) > 0 {
			return strings.Join(values, "<br>")
		}
	}
	if strings.TrimSpace(fallback) == "" {
		return "—"
	}
	parts := strings.Split(fallback, ",")
	values := make([]string, 0, len(parts))
	for _, part := range parts {
		if strings.TrimSpace(part) != "" {
			values = append(values, strings.TrimSpace(part))
		}
	}
	if len(values) == 0 {
		return "—"
	}
	return strings.Join(values, "<br>")
}
