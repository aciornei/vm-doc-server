# Upgrade vm-doc-server 0.20.85 → 0.20.86

Release exclusiv server-side. Nu adaugă migrare SQL și nu necesită update de agent.

## Schimbări

- Componente software → Outline: numai instalări de pe VM-uri PROD.
- paginile Outline ale componentelor folosesc prefixul `comp-`;
- conținutul publicat conține numai referințe aferente VM-urilor PROD;
- raportul UI, cardurile și exportul Excel rămân neschimbate.

## Upgrade offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.85 vm-doc-server-0.20.86
tar -xzf /cale/vm-doc-server-0.20.86-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.86
cd /usr/local/src/vm-doc-server-0.20.86

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build

systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

După restart, faceți `Ctrl+F5`.

## Verificare

1. Deschideți Rapoarte → Componente software: cardurile și Excel-ul trebuie să fie identice cu 0.20.85.
2. Publicați o componentă prezentă în PROD + TEST: pagina Outline trebuie să conțină numai rândurile PROD.
3. Titlul paginii trebuie să fie `comp-<nume componentă>`.
4. O componentă prezentă numai în TEST/DEV trebuie refuzată la publicare individuală și omisă din publicarea tuturor componentelor.
