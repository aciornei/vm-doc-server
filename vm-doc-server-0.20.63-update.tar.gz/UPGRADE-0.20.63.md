# Upgrade VM-DOC Server 0.20.62 → 0.20.63

0.20.63 nu adaugă migrare DB. Se recomandă vm-doc-agent 1.7.12 pentru privilegiile DB și datele noi de parolă.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.62 /usr/local/src/vm-doc-server-0.20.63
tar -xzf vm-doc-server-0.20.63-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.63
cd /usr/local/src/vm-doc-server-0.20.63
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește vm-doc-server, fă Ctrl+F5, publică agentul 1.7.12 și rulează o colectare nouă pe VM-urile dorite.
