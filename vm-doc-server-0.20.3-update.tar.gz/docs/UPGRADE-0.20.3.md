# Upgrade vm-doc-server 0.20.2 → 0.20.3

Versiunea 0.20.3 corectează comportamentul exportului **Markdown pentru Outline** când este activată opțiunea **Lipește anexele A1, A2… în același document**.

## Noutăți

- exportul `.md` include acum efectiv fișele VM complete ca secțiuni `A1`, `A2`, `A3` etc.;
- fiecare anexă include secțiunile disponibile din fișa VM: identificare și resurse, încadrare operațională, servicii/roluri, dependențe, conexiuni externe, componente software, porturi, software instalat principal, responsabilități, Docker, baze de date, Web, backup, monitorizare și inventar agent;
- când bifa nu este activată, comportamentul rămâne cel din 0.20.2: anexele pot fi listate ca referințe/linkuri;
- exportul Markdown este doar download și nu salvează o versiune nouă de fișă VM;
- nu există migrare DB;
- nu este necesară actualizarea agentului.

## Upgrade offline

Păstrați `go.mod`, `go.sum` și `vendor/` funcționale din instalarea 0.20.2.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.2 vm-doc-server-0.20.3
tar -xzf vm-doc-server-0.20.3-update.tar.gz -C vm-doc-server-0.20.3
cd vm-doc-server-0.20.3

GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

După instalarea binarului, faceți `Ctrl+F5` în browser pentru a încărca JavaScript-ul actualizat.

## Verificare

În pagina unui serviciu:

1. bifați **Lipește anexele A1, A2… în același document**;
2. apăsați **Markdown pentru Outline**;
3. în fișierul `.md`, după secțiunea `Anexe — fișe tehnice VM`, trebuie să apară `A1 — <VM>`, `A2 — <VM>` etc., fiecare cu tabelele și secțiunile fișei VM.
