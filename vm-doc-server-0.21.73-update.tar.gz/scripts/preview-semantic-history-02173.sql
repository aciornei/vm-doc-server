-- VM-DOC 0.21.73 - DIAGNOSTIC READ-ONLY, NU sterge nimic.
-- Evenimente salvate recent: distribuția pe domenii si exemple de zgomot.
SELECT category, object_type, change_type, COUNT(*) AS evenimente
FROM inventory_changes
WHERE occurred_at >= UTC_TIMESTAMP() - INTERVAL 14 DAY
GROUP BY category, object_type, change_type
ORDER BY evenimente DESC, category, object_type;

SELECT object_label, COUNT(*) AS evenimente, MIN(occurred_at) AS primul, MAX(occurred_at) AS ultimul
FROM inventory_changes
WHERE occurred_at >= UTC_TIMESTAMP() - INTERVAL 14 DAY
  AND category='ports'
GROUP BY object_label
ORDER BY evenimente DESC
LIMIT 35;

SELECT category, object_type, COUNT(*) AS de_revizuit
FROM inventory_changes
WHERE occurred_at >= UTC_TIMESTAMP() - INTERVAL 14 DAY
  AND review_status='new'
GROUP BY category, object_type
ORDER BY de_revizuit DESC;
