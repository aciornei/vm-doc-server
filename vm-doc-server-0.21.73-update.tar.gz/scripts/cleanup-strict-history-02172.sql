-- DEPRECATED din 0.21.73: politica STRICT 0.21.72 a fost inlocuita. Acest script ar sterge schimbari reale de firewall/servicii si NU se mai executa.
SELECT 'DEPRECATED: cleanup strict 0.21.72 dezactivat; nu s-a sters nimic' AS mesaj;
