# Upgrade 0.21.71 → 0.21.73 (direct, cumulativ)

1. **Nu instala 0.21.72**: 0.21.73 include modificările cumulative din 0.21.72, dar înlocuiește politica restrictivă cu comparație semantică pe domenii; documentele și istoricul nu sunt șterse.
2. Backup MariaDB verificat, backup binar 0.21.71, `config.yaml` și `vendor/`. Probează într-un staging conectat la cel puțin un agent Linux cu Docker/DB și un Windows cu software.
3. Aplică `vm-doc-server-0.21.71-to-0.21.73.patch` **sau** `vm-doc-server-0.21.73-update.tar.gz` direct peste sursele 0.21.71. Nu combina ambele. Alternativ folosește sursele complete 0.21.73.
4. Compilează offline folosind dependențele proprii: `GOPROXY=off GOSUMDB=off go test ./...`, apoi `GOPROXY=off GOSUMDB=off go build -o vm-doc-server ./cmd/vm-doc-server` (verifică punctul de intrare conform instalării tale). Nu există binar Go precompilat în ZIP.
5. Oprește serverul și înlocuiește binarul; pornește. Resursele JS sunt `go:embed`, deci este obligatoriu un nou build. Confirmă `app.js?v=0.21.73` și versiunea API. Fără migrare nouă.
6. Probează minimum 3 inventare succesive după o modificare controlată: `TCP/25` cu master/smtpd nu fluctuează, UDP/36761 nu apare, TCP/443 real apare/dispare, UDP/53 exclus implicit sau urmărit dacă Principal, modificare manuală a unei reguli firewall apare, Docker NAT generat nu apare.
7. Simulează `collection.collectors.firewall.status=partial` pe staging și verifică absența unui val de ștergeri. Similar pentru DB `catalog_discovery_status=metadata_only` și `access.status=partial`: nu ar trebui să apară ștergeri de baze, utilizatori ori HBA.
8. **Nu rula `cleanup-strict-history-02172.sql`** — nu mai reflectă noua politică. Folosește `scripts/preview-semantic-history-02173.sql` doar ca raport read-only. Dacă vrei să ascunzi zgomotul vechi fără ștergere, folosește baseline după validare.
9. Rollback: reinstalează binarul 0.21.71 și reîncarcă browserul; fără migrare DB nouă. Evenimentele deja inserate rămân, ca istoric al detectorului nou.

Limitare: schimbările **FortiGate, Veeam, Prometheus** nu intră automat în această etapă; ele sunt surse centrale pentru etapa 2. „Marchează documentat” și timeline-ul sunt etapa 3.
