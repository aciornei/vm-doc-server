# VM-DOC Server 0.21.73 — Detector semantic (Etapa 1)

> **UPGRADE DIRECT 0.21.71 → 0.21.73.** Nu este necesară instalarea 0.21.72. Versiunea 0.21.73 înlocuiește politica STRICT din 0.21.72, care ascundea servicii nemarcate și reguli individuale de firewall.

## Principiu

Agentul continuă să colecteze **inventarul complet**. În `inventory_changes` sunt înscrise doar diferențele semantice, confirmate de **două colectări consecutive complete ale domeniului**. Colecțiile cu `partial`, `error`, `timeout`, `disabled`, `truncated` sau metadatele de colecție incompatibile nu produc modificări pentru acel domeniu. Absența într-o colectare nereușită **nu înseamnă ștergere**.

- **Porturi:** cheia stabilă `TCP/25`, fără PID/procese (Postfix `master` versus `master+smtpd` rămâne identic). TCP sub 49152 este urmărit implicit, **cu excepția TCP/53, TCP/5353 și TCP/5355** (DNS/mDNS/LLMNR generate) — acestea necesită marcare Principal. **UDP (oricare, inclusiv UDP/36761 și UDP/53)** și TCP/RPC dinamic **49152–65535** sunt urmărite **numai dacă sunt marcate Principal**. Prin design, UDP real nemarcat nu va genera eveniment. Nivelul DNS/AD poate fi foarte dinamic; vezi și servicii/conturi de infrastructură.
- **Servicii OS:** toate serviciile stabile cu versiune și `enabled_state`, nu starea `running`/`active`. Familia helper `systemd-*` urmărește doar enable/disable, nu pachetele systemd redundante; `systemd-fsck` și serviciile efemere sunt în continuare excluse. Schimbări reale de versiune ale serviciilor de aplicație se detectează fără o selecție prealabilă în Componente suport.
- **Firewall local:** politicile implicite și regulile individuale explicit configurate sunt urmărite; regulile Docker regenerate/nftables/iptables, conteurii, handle-uri și chain-uri generate sunt ignorate. Schimbarea unei reguli prin înlocuire produce un removed + added (gruparea semantică în eveniment unic urmează într-o etapă ulterioară).
- **Baze de date:** instanță, versiune reală (inclusiv normalizarea bannerelor MariaDB), catalog **numai dacă enumerarea este reușită** și nu este sistem; utilizatori/roluri, granturi și `pg_hba.conf` (source/type/DB/user/address/method) doar cu `access.status=discovered` în toate cele trei inventare. Fără parole/hash-uri în eveniment.
- **Web:** site și elemente relevante de configurare; noi **reguli ACL** (action/source/scope/directive/config-file), nu rezultate de probe runtime.
- **Docker:** container name + image/tag; nu MAC, IP, network_id, volume, PID sau stare runtime.
- **Cron:** comandă/utilizator/sursă/orar și scripturi periodice, fără timestampuri de fișier.
- **Software:** aplicații Win32 desktop și Windows features raportate de agent; **nu AppX** și nu pachete Linux (agentul 1.7.18 nu are colector Linux software). Instalări/ștergeri/update-urile pachetelor ce chiar apar în collector sunt urmărite.
- **Conturi, DNS, OS, storage, configurații NTP/SSSD, integrare node_exporter:** păstrăm schimbările structurale în inventar, înregistrăm doar semantica stabilă.

## Ce NU este implementat în 0.21.73

- **FortiGate**, **Veeam** și **Prometheus centrale** au sincronizări independente ale agentului; încă nu sunt conectate la `inventory_changes`. Există date în paginile proprii, dar NU promitem detecția istorică de schimbări. Sunt **Etapa 2**.
- **Butonul „Documentat” și timeline-ul tip Facebook**, corelate pe VM/serviciu/proiect, sunt **Etapa 3**. Stările actuale `required`/`not_required` și `reviewed`/`ignored` rămân fără migrare.
- Nu se garantează detectarea unei schimbări care se produce și revine între două colectări, sau într-un colector indisponibil. `inventory_changes` nu înlocuiește auditul SIEM sau monitorizarea operațională.

## Impact și rollback

Fără migrare SQL nouă; Agent **1.7.18** neschimbat. API disponibil neschimbat; filtrele UI conțin categorii noi `db_security`, `web_acl`, `cron`, `software`. Nu se șterg automat evenimente istorice. **NU rula** SQL-ul de cleanup STRICT din 0.21.72 — ar putea elimina modificări legitime de firewall/servicii din istoric. Pentru valori vechi nefolositoare poți stabili un baseline, dar acesta doar ascunde, nu șterge.

Compilare completă și MariaDB live nu pot fi validate în mediul de construire fără vendor/dependințe: **test pe staging obligatoriu**. Semnalele de confirmare vor începe după cel puțin trei inventare reușite (vechi, nou, nou) pentru domeniul urmărit.
