package server

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/domain"
	outlineapi "vm-doc-server/internal/outline"
)

type vmOutlineServiceLink struct {
	Name string
	URL  string
}

type vmOutlineTableLinks struct {
	VMURLs   map[int64]string
	Services map[int64][]vmOutlineServiceLink
}

func (a *App) listOutlinePublicationTargets(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	values, err := a.Outline.ListPublicationTargets(r.Context())
	respond(w, values, err)
}

func (a *App) updateOutlinePublicationTarget(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	code := strings.TrimSpace(r.PathValue("code"))
	if code == "" {
		badRequest(w, errors.New("target code is required"))
		return
	}
	var input outlineapi.PublicationTargetInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Outline.UpdatePublicationTarget(r.Context(), user.ID, code, input)
	if err == nil {
		a.auditRequest(r, "outline.publication_target.update", "outline_publication_target", code, "success", map[string]any{
			"name":               value.Name,
			"document_reference": value.DocumentReference,
			"document_id":        value.DocumentID,
			"active":             value.Active,
		})
	}
	outlineRespond(w, value, err)
}

func (a *App) publishVMInventoryOutline(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		outlineRespond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	settings, err := a.Outline.GetSettings(r.Context())
	if err != nil {
		outlineRespond(w, nil, err)
		return
	}
	if !settings.Enabled {
		badRequest(w, errors.New("Outline integration is disabled"))
		return
	}
	target, err := a.Outline.GetPublicationTarget(r.Context(), "vm_inventory")
	if err != nil {
		outlineRespond(w, nil, err)
		return
	}
	if !target.Active {
		badRequest(w, errors.New("Outline publication target Inventar VM is disabled"))
		return
	}
	if strings.TrimSpace(target.DocumentReference) == "" {
		badRequest(w, errors.New("Outline publication target Inventar VM is not configured"))
		return
	}

	filter, err := vmFilterFromRequest(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	vms, err := a.VCenter.ExportVMs(r.Context(), filter)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if len(vms) == 0 {
		badRequest(w, errors.New("no VMs match the current filters; Outline page was not modified"))
		return
	}
	links, err := a.loadVMInventoryOutlineLinks(r.Context(), vms)
	if err != nil {
		respond(w, nil, err)
		return
	}
	markdown := a.vmInventoryOutlineMarkdown(vms, links)
	result, err := a.Outline.PublishTargetDocument(r.Context(), "vm_inventory", []byte(markdown))
	if err == nil {
		a.auditRequest(r, "outline.vm_inventory.publish", "outline_publication_target", "vm_inventory", "success", map[string]any{
			"rows":                len(vms),
			"outline_document_id": result.DocumentID,
			"outline_url":         result.URL,
			"filters":             r.URL.RawQuery,
		})
	}
	if err != nil && a.Logger != nil {
		a.Logger.Error("Outline VM inventory table publish failed", "error", err, "filters", r.URL.RawQuery)
	}
	outlineRespond(w, map[string]any{
		"result": result,
		"rows":   len(vms),
	}, err)
}

func (a *App) loadVMInventoryOutlineLinks(ctx context.Context, vms []domain.VirtualMachine) (vmOutlineTableLinks, error) {
	links := vmOutlineTableLinks{
		VMURLs:   make(map[int64]string, len(vms)),
		Services: make(map[int64][]vmOutlineServiceLink, len(vms)),
	}
	if len(vms) == 0 {
		return links, nil
	}
	ids := make([]int64, 0, len(vms))
	args := make([]any, 0, len(vms))
	for _, vm := range vms {
		ids = append(ids, vm.ID)
		args = append(args, vm.ID)
	}
	placeholders := strings.TrimSuffix(strings.Repeat("?,", len(ids)), ",")

	rows, err := a.DB.QueryContext(ctx, `SELECT vm.id,COALESCE(NULLIF(ovm.document_url,''),NULLIF(om.documentation_url,''),'')
		FROM virtual_machines vm
		LEFT JOIN outline_vm_documents_global ovm ON ovm.vm_id=vm.id AND ovm.target_code='virtualization'
		LEFT JOIN vm_operational_metadata om ON om.vm_id=vm.id
		WHERE vm.id IN (`+placeholders+`)`, args...)
	if err != nil {
		return links, err
	}
	for rows.Next() {
		var vmID int64
		var documentURL string
		if err := rows.Scan(&vmID, &documentURL); err != nil {
			rows.Close()
			return links, err
		}
		if strings.TrimSpace(documentURL) != "" {
			links.VMURLs[vmID] = strings.TrimSpace(documentURL)
		}
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return links, err
	}
	rows.Close()

	serviceQuery := `SELECT DISTINCT service_rows.vm_id,s.id,s.name,COALESCE(s.documentation_url,'')
		FROM (
			SELECT sa.vm_id,sa.internal_service_id AS service_id
			  FROM vm_internal_service_assignments sa
			UNION ALL
			SELECT c.vm_id,a2.internal_service_id
			  FROM docker_container_service_assignments a2
			  JOIN docker_containers c ON c.id=a2.docker_container_id AND c.present=1
			UNION ALL
			SELECT di.vm_id,a3.internal_service_id
			  FROM database_instance_service_assignments a3
			  JOIN database_instances di ON di.id=a3.database_instance_id AND di.present=1
			UNION ALL
			SELECT dc.vm_id,a4.internal_service_id
			  FROM database_catalog_service_assignments a4
			  JOIN database_catalogs dc ON dc.id=a4.database_catalog_id AND dc.present=1
			UNION ALL
			SELECT ws.vm_id,a5.internal_service_id
			  FROM web_site_service_assignments a5
			  JOIN web_sites ws ON ws.id=a5.web_site_id AND ws.present=1
		) service_rows
		JOIN internal_services s ON s.id=service_rows.service_id
		WHERE service_rows.vm_id IN (` + placeholders + `)
		ORDER BY service_rows.vm_id,s.name,s.id`
	rows, err = a.DB.QueryContext(ctx, serviceQuery, args...)
	if err != nil {
		return links, err
	}
	defer rows.Close()
	for rows.Next() {
		var vmID, serviceID int64
		var name, documentURL string
		if err := rows.Scan(&vmID, &serviceID, &name, &documentURL); err != nil {
			return links, err
		}
		_ = serviceID
		links.Services[vmID] = append(links.Services[vmID], vmOutlineServiceLink{Name: strings.TrimSpace(name), URL: strings.TrimSpace(documentURL)})
	}
	return links, rows.Err()
}

func (a *App) vmInventoryOutlineMarkdown(vms []domain.VirtualMachine, links vmOutlineTableLinks) string {
	location, err := time.LoadLocation(a.Config.App.Timezone)
	if err != nil {
		location = time.UTC
	}
	generatedAt := time.Now().In(location).Format("02.01.2006 15:04")
	var b strings.Builder
	b.WriteString("> Actualizat automat din VM-DOC la **")
	b.WriteString(generatedAt)
	b.WriteString("** · ")
	b.WriteString(strconv.Itoa(len(vms)))
	b.WriteString(" VM-uri conform filtrelor curente.\n\n")
	b.WriteString("| VM | Power | CPU / RAM | Mediu | OS | Suport OS | IP | Servicii | Outline | Ultima publicare Outline |\n")
	b.WriteString("|---|---|---|---|---|---|---|---|---|---|\n")
	for _, vm := range vms {
		osName := strings.TrimSpace(vm.InventoryOSName)
		if osName == "" {
			osName = strings.TrimSpace(vm.GuestOS)
		}
		osVersion := strings.TrimSpace(vm.InventoryOSVersion)
		osText := strings.TrimSpace(strings.TrimSpace(osName) + " " + osVersion)
		if osText == "" {
			osText = "—"
		}
		ip := strings.TrimSpace(vm.InventoryPrimaryIP)
		if ip == "" {
			ip = strings.TrimSpace(vm.PrimaryIP)
		}
		services := outlineServiceLinksMarkdown(links.Services[vm.ID], vm.ServiceNames)
		outlineState := "DA"
		if vm.OutlineDocumentationDisabled {
			outlineState = "NU"
		}
		lastOutline := formatOutlineTableTime(vm.OutlineLastSyncedAt, location)
		cpuRAM := fmt.Sprintf("%d / %s", vm.CPUCount, outlineMemory(vm.MemoryMiB))
		vmName := markdownLink(vm.Name, links.VMURLs[vm.ID])
		row := []string{
			vmName,
			outlinePowerLabel(vm.PowerState),
			cpuRAM,
			outlineEnvironmentLabel(vm.Environment),
			osText,
			osSupportTableLabel(vm.OSSupportStatus),
			firstText(ip, "—"),
			services,
			outlineState,
			lastOutline,
		}
		b.WriteString("|")
		for _, cell := range row {
			b.WriteString(" ")
			b.WriteString(markdownTableCell(cell))
			b.WriteString(" |")
		}
		b.WriteString("\n")
	}
	if len(vms) == 0 {
		b.WriteString("| _Niciun VM pentru filtrele curente_ | — | — | — | — | — | — | — | — | — |\n")
	}
	return b.String()
}

func outlineServiceLinksMarkdown(values []vmOutlineServiceLink, fallback []string) string {
	if len(values) > 0 {
		parts := make([]string, 0, len(values))
		for _, value := range values {
			name := strings.TrimSpace(value.Name)
			if name == "" {
				continue
			}
			parts = append(parts, markdownLink(name, value.URL))
		}
		if len(parts) > 0 {
			return strings.Join(parts, "<br>")
		}
	}
	parts := make([]string, 0, len(fallback))
	for _, value := range fallback {
		if strings.TrimSpace(value) != "" {
			parts = append(parts, strings.TrimSpace(value))
		}
	}
	if len(parts) == 0 {
		return "—"
	}
	return strings.Join(parts, "<br>")
}

func markdownLink(label, rawURL string) string {
	label = strings.TrimSpace(label)
	if label == "" {
		label = "—"
	}
	label = strings.ReplaceAll(label, "\\", "\\\\")
	label = strings.ReplaceAll(label, "[", "\\[")
	label = strings.ReplaceAll(label, "]", "\\]")
	rawURL = strings.TrimSpace(rawURL)
	if rawURL == "" {
		return label
	}
	rawURL = strings.ReplaceAll(rawURL, " ", "%20")
	rawURL = strings.ReplaceAll(rawURL, "(", "%28")
	rawURL = strings.ReplaceAll(rawURL, ")", "%29")
	return "[" + label + "](" + rawURL + ")"
}

func outlinePowerLabel(value string) string {
	normalized := strings.NewReplacer("_", "", "-", "", " ", "").Replace(strings.ToLower(strings.TrimSpace(value)))
	switch normalized {
	case "poweredon", "on":
		return "ON"
	case "poweredoff", "off":
		return "OFF"
	case "suspended", "suspend":
		return "SUSPENDED"
	default:
		if strings.TrimSpace(value) == "" {
			return "—"
		}
		return strings.ToUpper(strings.TrimSpace(value))
	}
}

func outlineEnvironmentLabel(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "—"
	}
	normalized := strings.ToLower(value)
	normalized = strings.NewReplacer("ă", "a", "â", "a", "î", "i", "ș", "s", "ş", "s", "ț", "t", "ţ", "t").Replace(normalized)
	switch normalized {
	case "prod", "production", "productie":
		return "PROD"
	case "test", "testing", "qa":
		return "TEST"
	case "dev", "development", "dezvoltare":
		return "DEV"
	default:
		return strings.ToUpper(value)
	}
}

func markdownTableCell(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "—"
	}
	value = strings.ReplaceAll(value, "|", "\\|")
	value = strings.ReplaceAll(value, "\r\n", "<br>")
	value = strings.ReplaceAll(value, "\n", "<br>")
	value = strings.ReplaceAll(value, "\r", "<br>")
	return value
}

func osSupportTableLabel(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "supported":
		return "DA"
	case "unsupported":
		return "NU"
	default:
		return "Nedeterminat"
	}
}

func formatOutlineTableTime(value *time.Time, location *time.Location) string {
	if value == nil {
		return "—"
	}
	return value.In(location).Format("02.01.2006 15:04")
}

func outlineMemory(mib int64) string {
	if mib <= 0 {
		return "—"
	}
	if mib >= 1024 {
		return fmt.Sprintf("%.1f GiB", float64(mib)/1024.0)
	}
	return fmt.Sprintf("%d MiB", mib)
}

func firstText(value, fallback string) string {
	if strings.TrimSpace(value) == "" {
		return fallback
	}
	return strings.TrimSpace(value)
}
