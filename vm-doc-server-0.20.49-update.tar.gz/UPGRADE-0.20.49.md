# Upgrade vm-doc-server 0.20.48 -> 0.20.49

0.20.49 elimină coloana **Hostname** din tabelul Inventar VM publicat în Outline.

Nu există migrare DB și nu este necesar update de vm-doc-agent.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.48 \
      /usr/local/src/vm-doc-server-0.20.49

tar -xzf vm-doc-server-0.20.49-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.49

cd /usr/local/src/vm-doc-server-0.20.49

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Înlocuiți binarul conform procedurii curente și reporniți serviciul.

După restart faceți **Ctrl+F5** pentru a încărca resursele `v=0.20.49`.
