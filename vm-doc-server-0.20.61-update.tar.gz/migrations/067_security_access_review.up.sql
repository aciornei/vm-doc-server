-- 0.20.61: Security / Access Review.
ALTER TABLE database_instances
  ADD COLUMN IF NOT EXISTS access_json LONGTEXT NULL AFTER detection_sources_json;

ALTER TABLE web_sites
  ADD COLUMN IF NOT EXISTS access_control_json LONGTEXT NULL AFTER detection_sources_json;

CREATE TABLE IF NOT EXISTS security_reviews (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  resource_type VARCHAR(64) NOT NULL,
  resource_key VARCHAR(768) NOT NULL,
  interval_months SMALLINT UNSIGNED NOT NULL DEFAULT 12,
  justified TINYINT(1) NOT NULL DEFAULT 1,
  notes VARCHAR(2000) NOT NULL DEFAULT '',
  reviewed_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  next_review_at DATETIME(6) NOT NULL,
  reviewed_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_security_review_resource (vm_id,resource_type,resource_key(500)),
  KEY idx_security_review_due (next_review_at,resource_type),
  KEY idx_security_review_user (reviewed_by),
  CONSTRAINT fk_security_review_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_security_review_user FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
