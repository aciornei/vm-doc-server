# Upgrade VM-DOC Server 0.20.60 → 0.20.61

## Modificări

0.20.61 adaugă **Securitate / Access Review**. Migrarea 067 adaugă stocarea metadata DB access, Web ACL și review-urile periodice.

Agentul 1.7.11 este necesar pentru noile date, dar serverul rămâne compatibil cu inventarele vechi.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.60 /usr/local/src/vm-doc-server-0.20.61
tar -xzf vm-doc-server-0.20.61-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.61
cd /usr/local/src/vm-doc-server-0.20.61
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server`; migrarea 067 se aplică la startup. Fă `Ctrl+F5` în browser.

După publicarea agentului 1.7.11, rulează o colectare pe VM-urile dorite și verifică meniul **Securitate**.
