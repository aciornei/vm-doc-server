# Upgrade vm-doc-server 0.20.47 -> 0.20.48

0.20.48 adaugă pagina **Releasuri** cu istoricul versiunilor aplicației.

Nu există migrare DB și nu este necesar update de vm-doc-agent.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.47 \
      /usr/local/src/vm-doc-server-0.20.48

tar -xzf vm-doc-server-0.20.48-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.48

cd /usr/local/src/vm-doc-server-0.20.48

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Înlocuiți binarul conform procedurii curente și reporniți serviciul.

După restart faceți **Ctrl+F5** pentru a încărca `app.js?v=0.20.48` și `app.css?v=0.20.48`.

Pagina nouă este disponibilă în meniul principal: **Releasuri**.
