# Upgrade vm-doc-server 0.13.5 -> 0.13.6

Versiunea 0.13.6 separă identitatea de management a agentului de adresele IP inventariate pe VM.

## Ce se schimbă

- coloana **IP agent / management** reprezintă adresa publicată de agent și folosită de server pentru Test / Colect / Update;
- coloana **IP-uri raportate VM** listează adresele de pe interfețele inventariate și poate include VIP-uri;
- dacă IP-ul sursă observat la register/heartbeat diferă de IP-ul de management, este afișat ca informație de diagnostic;
- sumarizarea inventarului preferă `src/prefsrc` al rutei implicite pentru `primary_ip`;
- migrarea 028 adaugă `agents.reported_ips_json`; valorile se populează la următoarea colectare/push de inventar.

## Upgrade

Oprește serviciile, extrage arhiva de update peste sursa instalată, reconstruiește offline în mediul tău cu dependențele Go deja disponibile și pornește serviciile. Migrarea este aplicată automat la pornire.

După upgrade, rulează **Colect** pe un agent pilot pentru a popula imediat lista `IP-uri raportate VM`.

## Compatibilitate

Serverul 0.13.6 rămâne compatibil cu agenții 1.3.6. Pentru selecția corectă automată a IP-ului de management în prezența VIP-urilor este recomandat agentul 1.3.7.
