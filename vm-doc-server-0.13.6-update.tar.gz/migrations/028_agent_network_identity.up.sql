-- 0.13.6: keep a compact list of interface IPs from the current agent inventory.
-- last_advertised_ip (migration 010) remains the management/agent IP.

ALTER TABLE agents
  ADD COLUMN IF NOT EXISTS reported_ips_json TEXT NULL AFTER last_registration_ip;
