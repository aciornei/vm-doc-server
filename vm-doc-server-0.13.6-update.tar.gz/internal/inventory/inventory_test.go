package inventory

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
	"io"
	"testing"
)

func TestSummarizeSchemaTwoInventory(t *testing.T) {
	raw := []byte(`{
	  "schema": {"name": "vm-doc-agent-inventory", "version": "2.0"},
	  "generated_at": "2026-08-25T08:30:00Z",
	  "identity": {"hostname": "vm-app-01", "uuid": "host-uuid-123"},
	  "os": {"name": "Ubuntu", "version": "20.04"},
	  "system": {"boot_time": "2026-08-20T06:00:00Z"},
	  "network": {
	    "interfaces": [
	      {"name": "lo", "addresses": ["127.0.0.1/8"]},
	      {"name": "eth0", "addresses": ["10.20.30.40/24"]}
	    ]
	  },
	  "storage": {"partitions": [{"name": "/", "uuid": "partition-uuid-wrong"}]},
	  "collectors": {
	    "system": {"status": "ok"},
	    "network": {"status": "ok"},
	    "filebeat": {"status": "error"},
	    "ntp": {"status": "timeout"}
	  }
	}`)

	s, err := Summarize(raw)
	if err != nil {
		t.Fatal(err)
	}
	if s.SchemaVersion != "2.0" || s.AgentUUID != "host-uuid-123" || s.Hostname != "vm-app-01" {
		t.Fatalf("unexpected identity summary: %+v", s)
	}
	if s.OSName != "Ubuntu" || s.OSVersion != "20.04" {
		t.Fatalf("unexpected OS summary: %+v", s)
	}
	if s.PrimaryIP != "10.20.30.40" {
		t.Fatalf("primary IP %q, want 10.20.30.40", s.PrimaryIP)
	}
	if s.CollectorTotal != 4 || s.CollectorOK != 2 || s.CollectorError != 1 || s.CollectorTimeout != 1 {
		t.Fatalf("unexpected collector counts: %+v", s)
	}
	if s.BootTime == nil || s.CollectedAt == nil {
		t.Fatalf("times were not parsed: %+v", s)
	}
}

func TestSummarizeDoesNotUseUnrelatedUUID(t *testing.T) {
	raw := []byte(`{"schema_version":"2.0","hostname":"vm1","storage":{"partitions":[{"uuid":"partition-only"}]}}`)
	s, err := Summarize(raw)
	if err != nil {
		t.Fatal(err)
	}
	if s.AgentUUID != "" {
		t.Fatalf("agent UUID %q was taken from an unrelated object", s.AgentUUID)
	}
}

func TestSummarizeRejectsTrailingJSON(t *testing.T) {
	if _, err := Summarize([]byte(`{"schema_version":"2.0"} {}`)); err == nil {
		t.Fatal("trailing JSON unexpectedly accepted")
	}
}

func TestSummarizeAgentOneInventoryShape(t *testing.T) {
	raw := []byte(`{
	  "schema_version":"2.0",
	  "agent":{"name":"vm-doc-agent","version":"1.0.0","id":"28a0858a-d2f7-4e69-9bfb-67f8c578ce86"},
	  "collected_at":"2026-08-25T13:21:33Z",
	  "collection":{"status":"success","collectors":{"system":{"status":"success"},"firewall":{"status":"success"},"ntp":{"status":"failed"}}},
	  "host":{"hostname":"DTI-ANSIBLE-01","fqdn":"DTI-ANSIBLE-01.example.ro","machine_id":"machine-1","product_uuid":"a89b0542-0022-9e75-e7bb-3ca7d543a975","correlation":{"smbios_legacy_byte_order":"42059ba8-2200-759e-e7bb-3ca7d543a975"}},
	  "os":{"pretty_name":"Ubuntu 24.04.3 LTS","version_id":"24.04"},
	  "network":{"interfaces":[{"name":"ens160","addresses":[{"address":"172.20.1.20","family":"ipv4"}]}]}
	}`)
	s, err := Summarize(raw)
	if err != nil {
		t.Fatal(err)
	}
	if s.AgentUUID != "28a0858a-d2f7-4e69-9bfb-67f8c578ce86" || s.AgentVersion != "1.0.0" {
		t.Fatalf("agent identity was not parsed: %+v", s)
	}
	if s.ProductUUID != "a89b0542-0022-9e75-e7bb-3ca7d543a975" || s.ProductUUIDLegacy == "" || s.FQDN == "" {
		t.Fatalf("VM correlation fields were not parsed: %+v", s)
	}
	if s.CollectorTotal != 3 || s.CollectorOK != 2 || s.CollectorError != 1 {
		t.Fatalf("nested collector statuses were not parsed: %+v", s)
	}
	if s.PrimaryIP != "172.20.1.20" {
		t.Fatalf("primary IP %q, want 172.20.1.20", s.PrimaryIP)
	}
}

func TestNormalizeHistoryPagination(t *testing.T) {
	page, pageSize := NormalizeHistoryPagination(0, 0)
	if page != 1 || pageSize != 10 {
		t.Fatalf("unexpected defaults: page=%d pageSize=%d", page, pageSize)
	}
	page, pageSize = NormalizeHistoryPagination(3, 1000)
	if page != 3 || pageSize != 100 {
		t.Fatalf("unexpected normalized values: page=%d pageSize=%d", page, pageSize)
	}
}

type inventoryCaptureDriver struct {
	args chan []driver.NamedValue
}

type inventoryCaptureConn struct {
	args chan []driver.NamedValue
}

type inventoryEmptyRows struct{}

func (d inventoryCaptureDriver) Open(string) (driver.Conn, error) {
	return inventoryCaptureConn{args: d.args}, nil
}

func (c inventoryCaptureConn) Prepare(string) (driver.Stmt, error) {
	return nil, errors.New("Prepare is not supported by the test driver")
}

func (c inventoryCaptureConn) Close() error { return nil }

func (c inventoryCaptureConn) Begin() (driver.Tx, error) {
	return nil, errors.New("Begin is not supported by the test driver")
}

func (c inventoryCaptureConn) QueryContext(_ context.Context, _ string, args []driver.NamedValue) (driver.Rows, error) {
	copied := append([]driver.NamedValue(nil), args...)
	c.args <- copied
	return inventoryEmptyRows{}, nil
}

func (inventoryEmptyRows) Columns() []string { return []string{"id"} }
func (inventoryEmptyRows) Close() error      { return nil }
func (inventoryEmptyRows) Next([]driver.Value) error {
	return io.EOF
}

func TestGetPassesInventoryIDToQuery(t *testing.T) {
	captured := make(chan []driver.NamedValue, 1)
	driverName := "inventory_get_argument_test"
	sql.Register(driverName, inventoryCaptureDriver{args: captured})

	db, err := sql.Open(driverName, "")
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	_, err = (Service{DB: db}).Get(context.Background(), 295, false)
	if !errors.Is(err, sql.ErrNoRows) {
		t.Fatalf("Get error = %v, want sql.ErrNoRows", err)
	}

	args := <-captured
	if len(args) != 1 {
		t.Fatalf("query received %d arguments, want 1", len(args))
	}
	if got, ok := args[0].Value.(int64); !ok || got != 295 {
		t.Fatalf("query argument = %#v, want int64(295)", args[0].Value)
	}
}

func TestSummarizePrefersDefaultRouteSourceAndKeepsVIPsReported(t *testing.T) {
	raw := []byte(`{
	  "schema_version":"2.0",
	  "agent":{"id":"agent-vip","version":"1.3.7"},
	  "network":{
	    "routes":[{"family":"ipv4","destination":"0.0.0.0/0","gateway":"10.20.30.1","interface":"ens160","source":"10.20.30.40","metric":100,"default":true}],
	    "interfaces":[{"name":"ens160","loopback":false,"addresses":[
	      {"address":"10.20.30.20","cidr":"10.20.30.20/24","family":"ipv4"},
	      {"address":"10.20.30.40","cidr":"10.20.30.40/24","family":"ipv4"}
	    ]}]
	  }
	}`)
	s, err := Summarize(raw)
	if err != nil {
		t.Fatal(err)
	}
	if s.PrimaryIP != "10.20.30.40" {
		t.Fatalf("primary IP = %q, want route source 10.20.30.40", s.PrimaryIP)
	}
	if len(s.ReportedIPs) != 2 || s.ReportedIPs[0] != "10.20.30.20" || s.ReportedIPs[1] != "10.20.30.40" {
		t.Fatalf("reported IPs = %#v", s.ReportedIPs)
	}
}
