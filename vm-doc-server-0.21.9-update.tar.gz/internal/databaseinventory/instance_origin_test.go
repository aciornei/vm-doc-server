package databaseinventory

import (
	"encoding/json"
	"testing"
)

func TestDockerInstancesWithSamePortAreDistinct(t *testing.T) {
	a := agentDatabaseInstance{Engine: "mongodb", Origin: "docker", ContainerID: "aaa123", InstanceName: "mongo", Endpoints: []agentDatabaseEndpoint{{Port: 27017}}}
	b := a
	b.ContainerID = "bbb456"
	if instanceIdentity(a) == instanceIdentity(b) {
		t.Fatal("distinct containers collapsed")
	}
	if legacyInstanceIdentity(a) != legacyInstanceIdentity(b) {
		t.Fatal("legacy scenario must collide for this regression test")
	}
}
func TestNativeInstanceIdentityUnaffected(t *testing.T) {
	v := agentDatabaseInstance{Engine: "postgresql", Origin: "native", InstanceName: "main", DataDir: "/pgdata", Endpoints: []agentDatabaseEndpoint{{Port: 5432}}}
	if instanceIdentity(v) != legacyInstanceIdentity(v) {
		t.Fatalf("changed legacy native identity: %q", instanceIdentity(v))
	}
}
func TestAgentOriginPayloadRoundtrip(t *testing.T) {
	input := []byte(`{"instances":[{"engine":"mongodb","origin":"docker","container_id":"123","container_name":"mongo-1","container_image":"mongo:4.4","compose_project":"demo","replica_set":"rs0","replica_role":"secondary","replica_primary":"mongo0:27017"}]}`)
	var value agentDatabaseInfo
	if err := json.Unmarshal(input, &value); err != nil {
		t.Fatal(err)
	}
	if len(value.Instances) != 1 || value.Instances[0].ReplicaRole != "secondary" || value.Instances[0].ContainerID != "123" {
		t.Fatalf("lost agent fields: %+v", value)
	}
}
