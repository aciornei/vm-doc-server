package server

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"strings"

	"vm-doc-server/internal/xlsx"
)

// exportVMResources exports the same currently documented Docker, database and
// web inventories as the VM tabs. It does not contact an agent or start collection.
func (a *App) exportVMResources(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	kind := r.URL.Query().Get("type")
	if kind != "docker" && kind != "databases" && kind != "web" {
		badRequest(w, errors.New("type must be docker, databases or web"))
		return
	}
	names, err := a.vmResourceBeneficiaryNames(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	cells := func(parts ...string) []xlsx.Cell {
		result := make([]xlsx.Cell, len(parts))
		for i, part := range parts {
			result[i] = xlsx.Text(part)
		}
		return result
	}
	formatAssignments := func(services []string) string { return strings.Join(services, "; ") }
	_ = formatAssignments
	var rows [][]xlsx.Cell
	switch kind {
	case "docker":
		view, e := a.Docker.GetVM(r.Context(), id)
		if e != nil {
			respond(w, nil, e)
			return
		}
		rows = append(rows, cells("Container", "Imagine", "Stare", "Compose", "Documentare", "Servicii / Mediu / Status / Tip soluție", "Beneficiari"))
		for _, item := range view.Containers {
			assignments := []string{}
			for _, x := range item.ServiceAssignments {
				assignments = append(assignments, serviceAssignmentExportLabel(x.ServiceName, x.Environment, x.OperationalStatus, x.SolutionType))
			}
			rows = append(rows, cells(item.Name, item.Image, item.State, item.ComposeProject, resourceDocumentationExportLabel(item.DocumentationExempt, len(assignments)), strings.Join(assignments, "; "), names[fmt.Sprintf("docker:%d", item.ID)]))
		}
	case "databases":
		view, e := a.Databases.GetVM(r.Context(), id)
		if e != nil {
			respond(w, nil, e)
			return
		}
		rows = append(rows, cells("Tip", "Nume", "Engine", "Versiune", "Origine", "Container", "Imagine Docker", "Proiect Compose", "Replica Set", "Rol replica", "PRIMARY", "Documentare", "Servicii / Mediu / Status / Tip soluție", "Beneficiari"))
		for _, instance := range view.Instances {
			assignments := []string{}
			for _, x := range instance.ServiceAssignments {
				assignments = append(assignments, serviceAssignmentExportLabel(x.ServiceName, x.Environment, x.OperationalStatus, x.SolutionType))
			}
			rows = append(rows, cells("Instanță", instance.InstanceName, instance.Product, instance.Version, instance.Origin, instance.ContainerName, instance.ContainerImage, instance.ComposeProject, instance.ReplicaSet, instance.ReplicaRole, instance.ReplicaPrimary, resourceDocumentationExportLabel(instance.DocumentationExempt, len(assignments)), strings.Join(assignments, "; "), ""))
			for _, catalog := range instance.Catalogs {
				if catalog.System {
					continue
				}
				assignments = []string{}
				for _, x := range catalog.ServiceAssignments {
					assignments = append(assignments, serviceAssignmentExportLabel(x.ServiceName, x.Environment, x.OperationalStatus, x.SolutionType))
				}
				rows = append(rows, cells("Bază", catalog.Name, instance.Product, instance.Version, instance.Origin, instance.ContainerName, instance.ContainerImage, instance.ComposeProject, instance.ReplicaSet, instance.ReplicaRole, instance.ReplicaPrimary, resourceDocumentationExportLabel(catalog.DocumentationExempt, len(assignments)), strings.Join(assignments, "; "), names[fmt.Sprintf("database:%d", catalog.ID)]))
			}
		}
	case "web":
		view, e := a.Web.GetVM(r.Context(), id)
		if e != nil {
			respond(w, nil, e)
			return
		}
		rows = append(rows, cells("Site", "Engine", "Server names", "Config", "Documentare", "Servicii / Mediu / Status / Tip soluție", "Beneficiari"))
		for _, item := range view.Sites {
			assignments := []string{}
			for _, x := range item.ServiceAssignments {
				assignments = append(assignments, serviceAssignmentExportLabel(x.ServiceName, x.Environment, x.OperationalStatus, x.SolutionType))
			}
			rows = append(rows, cells(item.Name, item.Product, strings.Join(item.ServerNames, ", "), item.ConfigFile, resourceDocumentationExportLabel(item.DocumentationExempt, len(assignments)), strings.Join(assignments, "; "), names[fmt.Sprintf("web:%d", item.ID)]))
		}
	}
	if err := writeXLSXResponse(w, kind, fmt.Sprintf("vm-%d-%s", id, kind), rows); err != nil && a.Logger != nil {
		a.Logger.Error("resource Excel export", "error", err)
	}
}

func resourceDocumentationExportLabel(exempt bool, count int) string {
	if exempt {
		return "Nu necesită documentare"
	}
	if count == 0 {
		return "Nedocumentat"
	}
	return "Documentat"
}
func serviceAssignmentExportLabel(service, env, status, solution string) string {
	return strings.Join(nonblankStrings(service, env, status, solution), " · ")
}
func nonblankStrings(parts ...string) []string {
	out := []string{}
	for _, p := range parts {
		if strings.TrimSpace(p) != "" {
			out = append(out, p)
		}
	}
	return out
}
func (a *App) vmResourceBeneficiaryNames(ctx context.Context, vmID int64) (map[string]string, error) {
	rows, err := a.DB.QueryContext(ctx, beneficiaryEffectiveSQL+" AND n.vm_id=? AND i.resource_type IN ('docker','database','web')", vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	data, err := scanBeneficiaryRows(rows)
	if err != nil {
		return nil, err
	}
	lists := map[string][]string{}
	for _, r := range data {
		key := fmt.Sprintf("%s:%d", r.ResourceType, r.ResourceID)
		duplicate := false
		for _, n := range lists[key] {
			if n == r.BeneficiaryName {
				duplicate = true
				break
			}
		}
		if !duplicate {
			lists[key] = append(lists[key], r.BeneficiaryName)
		}
	}
	result := map[string]string{}
	for k, v := range lists {
		result[k] = strings.Join(v, ", ")
	}
	return result, nil
}
