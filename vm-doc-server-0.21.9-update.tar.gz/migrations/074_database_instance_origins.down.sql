-- Reversal only if the operator deliberately wants to discard 0.21.9 metadata.
ALTER TABLE database_instances
  DROP KEY idx_db_instance_container,
  DROP COLUMN replica_primary,
  DROP COLUMN replica_role,
  DROP COLUMN replica_set,
  DROP COLUMN compose_project,
  DROP COLUMN container_image,
  DROP COLUMN container_name,
  DROP COLUMN container_id,
  DROP COLUMN origin;
