-- 0.21.9: DB engine inventory per instance, including Docker origin.
-- No extra DB privileges (no CREATE VIEW) and no destructive changes.
ALTER TABLE database_instances
  ADD COLUMN IF NOT EXISTS origin VARCHAR(32) NOT NULL DEFAULT '' AFTER engine,
  ADD COLUMN IF NOT EXISTS container_id VARCHAR(255) NOT NULL DEFAULT '' AFTER origin,
  ADD COLUMN IF NOT EXISTS container_name VARCHAR(255) NOT NULL DEFAULT '' AFTER container_id,
  ADD COLUMN IF NOT EXISTS container_image VARCHAR(1024) NOT NULL DEFAULT '' AFTER container_name,
  ADD COLUMN IF NOT EXISTS compose_project VARCHAR(255) NOT NULL DEFAULT '' AFTER container_image,
  ADD COLUMN IF NOT EXISTS replica_set VARCHAR(255) NOT NULL DEFAULT '' AFTER compose_project,
  ADD COLUMN IF NOT EXISTS replica_role VARCHAR(64) NOT NULL DEFAULT '' AFTER replica_set,
  ADD COLUMN IF NOT EXISTS replica_primary VARCHAR(255) NOT NULL DEFAULT '' AFTER replica_role,
  ADD KEY IF NOT EXISTS idx_db_instance_container (vm_id,container_id(64));
