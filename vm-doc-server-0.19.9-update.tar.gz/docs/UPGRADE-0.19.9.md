# Upgrade vm-doc-server 0.19.8 → 0.19.9

0.19.9 este un release de consistență UI și exporturi, cu o singură migrare DB aditivă pentru descrierea rich-text a serviciilor interne.

## Noutăți

- filtre/listbox-uri stabile în zonele de listare și paginare;
- procente în cardurile listei VM;
- Backup separat în `Backup` și `Surse & sincronizări`; export Excel pentru VM-urile Veeam;
- export Excel pentru VM-uri și targeturi în Monitorizare;
- Servicii: paginare, export Excel, fără coloana `Deschide / Editează`;
- Descriere serviciu rich-text, inclusiv în documentația DOCX;
- adăugarea sistemelor/rețelelor externe este colapsată; padding îmbunătățit la editare/conexiuni;
- filtre Agenți reașezate.

## Migrare DB

La pornirea serverului se aplică automat:

```text
042_service_description_rich_text.up.sql
```

Migrarea adaugă `internal_services.description_richtext`. Câmpul plain-text `description` rămâne neschimbat pentru compatibilitate, căutare și export.

## Upgrade

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.8 vm-doc-server-0.19.9
tar -xzf /home/andrei.ciornei/vm-doc-server-0.19.9-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.9
cd /usr/local/src/vm-doc-server-0.19.9
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

După upgrade folosiți `Ctrl+F5` pentru încărcarea CSS/JS 0.19.9.

## Verificări rapide

1. `/version` raportează `0.19.9`.
2. Lista VM afișează procente în cardurile de prezență/agent.
3. `Backup` are taburile `Backup` și `Surse & sincronizări`; exportul XLSX respectă filtrele.
4. Monitorizare are export XLSX pentru VM-uri și targeturi.
5. Servicii are paginare și export; coloana cu butoane `Deschide / Editează` nu mai există.
6. Descrierea unui serviciu permite bold/italic/underline/liste și apare formatată în DOCX.
7. În Conectivitate externă și Rețele externe, formularul `Adaugă` este colapsat implicit.
8. Filtrele de la Agenți/Backup/Monitorizare/Conectivitate nu se suprapun cu butoanele.

Nu este necesar upgrade de agent sau collector. `vm-doc-agent` rămâne 1.6.4.
