-- 0.19.9 · formatare rich-text pentru descrierea serviciului intern
-- Câmpul plain-text description rămâne pentru compatibilitate, căutare și export.
ALTER TABLE internal_services
  ADD COLUMN description_richtext LONGTEXT NULL AFTER description;
