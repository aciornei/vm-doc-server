package fortigate

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestClientInventoryUsesBearerAndVDOM(t *testing.T) {
	seen := 0
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get("Authorization"); got != "Bearer token-123" {
			t.Fatalf("authorization = %q", got)
		}
		if got := r.URL.Query().Get("vdom"); got != "root" {
			t.Fatalf("vdom = %q", got)
		}
		seen++
		fmt.Fprint(w, `{"status":"success","http_status":200,"results":[]}`)
	}))
	defer ts.Close()
	client, err := NewClient(ts.URL, "token-123", "root", true, "", 5*time.Second, true)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := client.Inventory(context.Background()); err != nil {
		t.Fatal(err)
	}
	if seen != 4 {
		t.Fatalf("expected 4 CMDB calls, got %d", seen)
	}
}

func TestClientInventoryPaginatesCMDBResults(t *testing.T) {
	calls := 0
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls++
		if got := r.Header.Get("Authorization"); got != "Bearer token-123" {
			t.Fatalf("authorization = %q", got)
		}
		if got := r.URL.Query().Get("vdom"); got != "root" {
			t.Fatalf("vdom = %q", got)
		}
		if got := r.URL.Query().Get("count"); got != "500" {
			t.Fatalf("count = %q", got)
		}
		switch r.URL.Path {
		case "/api/v2/cmdb/firewall/address":
			start := r.URL.Query().Get("start")
			switch start {
			case "0":
				fmt.Fprint(w, `{"status":"success","http_status":200,"limit_reached":true,"next_idx":1,"size":2,"results":[{"name":"A","type":"ipmask","subnet":"10.0.0.1 255.255.255.255"},{"name":"B","type":"ipmask","subnet":"10.0.0.2 255.255.255.255"}]}`)
			case "2":
				fmt.Fprint(w, `{"status":"success","http_status":200,"limit_reached":false,"next_idx":2,"size":1,"results":[{"name":"C","type":"ipmask","subnet":"10.0.0.3 255.255.255.255"}]}`)
			default:
				t.Fatalf("unexpected address start=%q", start)
			}
		default:
			fmt.Fprint(w, `{"status":"success","http_status":200,"limit_reached":false,"results":[]}`)
		}
	}))
	defer ts.Close()
	client, err := NewClient(ts.URL, "token-123", "root", true, "", 5*time.Second, true)
	if err != nil {
		t.Fatal(err)
	}
	inv, err := client.Inventory(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if got := len(inv.Addresses); got != 3 {
		t.Fatalf("addresses=%d want 3", got)
	}
	if inv.AddressPages != 2 {
		t.Fatalf("address pages=%d want 2", inv.AddressPages)
	}
	if calls != 5 {
		t.Fatalf("calls=%d want 5", calls)
	}
}
