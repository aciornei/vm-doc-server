package fortigate

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
)

type RawObject map[string]any
type Inventory struct {
	Addresses    []RawObject
	Groups       []RawObject
	Policies     []RawObject
	VIPs         []RawObject
	AddressPages int
	GroupPages   int
	PolicyPages  int
	VIPPages     int
}

type Address struct {
	Name, Type, Subnet, StartIP, EndIP, FQDN string
	Raw                                      json.RawMessage
}
type Group struct {
	Name    string
	Members []string
	Raw     json.RawMessage
}
type Policy struct {
	ID                                           int64
	Name, Status, Action, Schedule, Comments     string
	SrcIntf, DstIntf, SrcAddr, DstAddr, Services []string
	NAT                                          bool
	Raw                                          json.RawMessage
}
type VIP struct {
	Name, ExtIP, ExtIntf, Protocol, ExtPort, MappedPort string
	MappedIPs                                           []string
	PortForward                                         bool
	Raw                                                 json.RawMessage
}

func text(m RawObject, key string) string {
	if v, ok := m[key]; ok {
		switch x := v.(type) {
		case string:
			return strings.TrimSpace(x)
		case json.Number:
			return x.String()
		case float64:
			return strconv.FormatFloat(x, 'f', -1, 64)
		case bool:
			if x {
				return "true"
			}
			return "false"
		}
	}
	return ""
}
func boolValue(m RawObject, key string) bool {
	v := strings.ToLower(text(m, key))
	return v == "enable" || v == "enabled" || v == "true" || v == "1" || v == "yes"
}
func int64Value(m RawObject, key string) int64 {
	v := m[key]
	switch x := v.(type) {
	case float64:
		return int64(x)
	case json.Number:
		n, _ := x.Int64()
		return n
	case string:
		n, _ := strconv.ParseInt(strings.TrimSpace(x), 10, 64)
		return n
	}
	return 0
}
func names(v any) []string {
	var out []string
	switch x := v.(type) {
	case []any:
		for _, item := range x {
			switch y := item.(type) {
			case map[string]any:
				n := ""
				for _, k := range []string{"name", "q_origin_key", "range"} {
					if s, ok := y[k].(string); ok && strings.TrimSpace(s) != "" {
						n = strings.TrimSpace(s)
						break
					}
				}
				if n != "" {
					out = append(out, n)
				}
			case string:
				if strings.TrimSpace(y) != "" {
					out = append(out, strings.TrimSpace(y))
				}
			}
		}
	case string:
		if strings.TrimSpace(x) != "" {
			out = append(out, strings.TrimSpace(x))
		}
	}
	return out
}
func raw(m RawObject) json.RawMessage { b, _ := json.Marshal(m); return b }
func ParseAddress(m RawObject) Address {
	return Address{Name: text(m, "name"), Type: text(m, "type"), Subnet: text(m, "subnet"), StartIP: text(m, "start-ip"), EndIP: text(m, "end-ip"), FQDN: text(m, "fqdn"), Raw: raw(m)}
}
func ParseGroup(m RawObject) Group {
	return Group{Name: text(m, "name"), Members: names(m["member"]), Raw: raw(m)}
}
func ParsePolicy(m RawObject) Policy {
	return Policy{ID: int64Value(m, "policyid"), Name: text(m, "name"), Status: text(m, "status"), SrcIntf: names(m["srcintf"]), DstIntf: names(m["dstintf"]), SrcAddr: names(m["srcaddr"]), DstAddr: names(m["dstaddr"]), Services: names(m["service"]), Action: text(m, "action"), Schedule: text(m, "schedule"), NAT: boolValue(m, "nat"), Comments: text(m, "comments"), Raw: raw(m)}
}
func policyDisabled(status string) bool {
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "disable", "disabled", "off", "false", "0":
		return true
	default:
		return false
	}
}
func policyEnabled(p Policy) bool { return !policyDisabled(p.Status) }
func ParseVIP(m RawObject) VIP {
	mapped := names(m["mappedip"])
	if len(mapped) == 0 {
		mapped = names(m["mapped-ip"])
	}
	return VIP{Name: text(m, "name"), ExtIP: text(m, "extip"), MappedIPs: mapped, ExtIntf: text(m, "extintf"), Protocol: text(m, "protocol"), PortForward: boolValue(m, "portforward"), ExtPort: firstNonEmpty(text(m, "extport"), text(m, "extport-start")), MappedPort: firstNonEmpty(text(m, "mappedport"), text(m, "mappedport-start")), Raw: raw(m)}
}
func firstNonEmpty(v ...string) string {
	for _, s := range v {
		if strings.TrimSpace(s) != "" {
			return strings.TrimSpace(s)
		}
	}
	return ""
}
func MarshalStrings(v []string) string { b, _ := json.Marshal(v); return string(b) }
func MustRaw(v json.RawMessage) string {
	if len(v) == 0 {
		return "{}"
	}
	return string(v)
}
func policyLabel(p Policy) string {
	if p.Name != "" {
		return p.Name
	}
	return fmt.Sprintf("Policy %d", p.ID)
}
