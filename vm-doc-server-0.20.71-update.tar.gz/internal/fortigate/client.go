package fortigate

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

const maxResponseSize = 32 << 20
const cmdbPageSize = 500
const maxCMDBPages = 10000

type Client struct {
	base  *url.URL
	token string
	http  *http.Client
	vdom  string
}

type envelope struct {
	Status       string          `json:"status"`
	HTTPStatus   int             `json:"http_status"`
	Results      json.RawMessage `json:"results"`
	LimitReached bool            `json:"limit_reached"`
	NextIdx      int             `json:"next_idx"`
	Size         int             `json:"size"`
	MatchedCount int             `json:"matched_count"`
}

func NewClient(baseURL, token, vdom string, verifyTLS bool, tlsServerName string, timeout time.Duration, allowHTTP bool) (*Client, error) {
	u, err := url.Parse(strings.TrimRight(strings.TrimSpace(baseURL), "/"))
	if err != nil {
		return nil, err
	}
	if u.Scheme != "https" && !(allowHTTP && u.Scheme == "http") {
		return nil, fmt.Errorf("FortiGate URL must use HTTPS")
	}
	if u.Host == "" {
		return nil, fmt.Errorf("invalid FortiGate URL")
	}
	if strings.TrimSpace(token) == "" {
		return nil, fmt.Errorf("FortiGate API token is required")
	}
	if strings.TrimSpace(vdom) == "" {
		vdom = "root"
	}
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: !verifyTLS, ServerName: strings.TrimSpace(tlsServerName)} // #nosec G402 - explicit admin option
	return &Client{base: u, token: token, vdom: vdom, http: &http.Client{Timeout: timeout, Transport: tr}}, nil
}

func (c *Client) getPage(ctx context.Context, path string, start, count int, out any) (envelope, error) {
	u := *c.base
	u.Path = strings.TrimRight(c.base.Path, "/") + path
	q := u.Query()
	q.Set("vdom", c.vdom)
	if start >= 0 {
		q.Set("start", fmt.Sprintf("%d", start))
	}
	if count > 0 {
		q.Set("count", fmt.Sprintf("%d", count))
	}
	u.RawQuery = q.Encode()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return envelope{}, err
	}
	req.Header.Set("Authorization", "Bearer "+c.token)
	req.Header.Set("Accept", "application/json")
	res, err := c.http.Do(req)
	if err != nil {
		return envelope{}, err
	}
	defer res.Body.Close()
	b, err := io.ReadAll(io.LimitReader(res.Body, maxResponseSize+1))
	if err != nil {
		return envelope{}, err
	}
	if len(b) > maxResponseSize {
		return envelope{}, fmt.Errorf("FortiGate response too large")
	}
	if res.StatusCode < 200 || res.StatusCode >= 300 {
		return envelope{}, fmt.Errorf("FortiGate API %s: HTTP %d: %s", path, res.StatusCode, strings.TrimSpace(string(b)))
	}
	var env envelope
	if err := json.Unmarshal(b, &env); err != nil {
		return envelope{}, fmt.Errorf("decode FortiGate response: %w", err)
	}
	if env.Status != "" && !strings.EqualFold(env.Status, "success") {
		return envelope{}, fmt.Errorf("FortiGate API %s status %s", path, env.Status)
	}
	if len(env.Results) == 0 || string(env.Results) == "null" {
		return env, nil
	}
	if err := json.Unmarshal(env.Results, out); err != nil {
		return envelope{}, fmt.Errorf("decode FortiGate results %s: %w", path, err)
	}
	return env, nil
}

func (c *Client) getAllRaw(ctx context.Context, path string) ([]RawObject, int, error) {
	all := make([]RawObject, 0)
	start := 0
	pages := 0
	for {
		if pages >= maxCMDBPages {
			return nil, pages, fmt.Errorf("FortiGate API %s pagination exceeded %d pages", path, maxCMDBPages)
		}
		var page []RawObject
		env, err := c.getPage(ctx, path, start, cmdbPageSize, &page)
		if err != nil {
			return nil, pages, err
		}
		pages++
		all = append(all, page...)
		if !env.LimitReached {
			break
		}
		// FortiGate reports next_idx as the zero-based index of the last row in
		// the current page (for example size=17 -> next_idx=16). Continue at
		// the following row. Fall back to the number of rows received if a build
		// does not expose a useful next_idx.
		next := env.NextIdx + 1
		if next <= start {
			next = start + len(page)
		}
		if next <= start || len(page) == 0 {
			return nil, pages, fmt.Errorf("FortiGate API %s pagination did not advance (start=%d next_idx=%d size=%d)", path, start, env.NextIdx, len(page))
		}
		start = next
	}
	return all, pages, nil
}

func (c *Client) Inventory(ctx context.Context) (Inventory, error) {
	var out Inventory
	var err error
	if out.Addresses, out.AddressPages, err = c.getAllRaw(ctx, "/api/v2/cmdb/firewall/address"); err != nil {
		return out, err
	}
	if out.Groups, out.GroupPages, err = c.getAllRaw(ctx, "/api/v2/cmdb/firewall/addrgrp"); err != nil {
		return out, err
	}
	if out.Policies, out.PolicyPages, err = c.getAllRaw(ctx, "/api/v2/cmdb/firewall/policy"); err != nil {
		return out, err
	}
	if out.VIPs, out.VIPPages, err = c.getAllRaw(ctx, "/api/v2/cmdb/firewall/vip"); err != nil {
		return out, err
	}
	return out, nil
}

func (c *Client) Test(ctx context.Context) (map[string]int, error) {
	inv, err := c.Inventory(ctx)
	if err != nil {
		return nil, err
	}
	active, disabled := 0, 0
	for _, rawPolicy := range inv.Policies {
		p := ParsePolicy(rawPolicy)
		if p.ID == 0 {
			continue
		}
		if policyEnabled(p) {
			active++
		} else {
			disabled++
		}
	}
	matchableAddresses, ignoredAddresses := 0, 0
	for _, rawAddress := range inv.Addresses {
		a := ParseAddress(rawAddress)
		if a.Name == "" {
			continue
		}
		if addressMatchable(a) {
			matchableAddresses++
		} else {
			ignoredAddresses++
		}
	}
	return map[string]int{
		"addresses":           len(inv.Addresses),
		"addresses_matchable": matchableAddresses,
		"addresses_ignored":   ignoredAddresses,
		"groups":              len(inv.Groups),
		"policies":            active,
		"policies_disabled":   disabled,
		"vips":                len(inv.VIPs),
		"address_pages":       inv.AddressPages,
		"group_pages":         inv.GroupPages,
		"policy_pages":        inv.PolicyPages,
		"vip_pages":           inv.VIPPages,
	}, nil
}
