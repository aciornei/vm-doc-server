# Upgrade VM-DOC Server 0.20.70 → 0.20.71

0.20.71 corectează sincronizarea FortiGate atunci când inventarul CMDB depășește o singură pagină de rezultate.

## Important

Nu există migrare DB nouă.

După upgrade rulează **Securitate → Firewall central → Test**. În mesaj trebuie să vezi totalurile și numărul de pagini pentru:
- policies active;
- address objects;
- address groups;
- VIP-uri.

Apoi rulează **Sync** pentru fiecare sursă FortiGate (sau `Sync toate`). Corelările vor fi reconstruite folosind matcher-ul strict din 0.20.70, dar pe inventarul FortiGate complet.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.70 /usr/local/src/vm-doc-server-0.20.71
tar -xzf vm-doc-server-0.20.71-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.71
cd /usr/local/src/vm-doc-server-0.20.71
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server`, rulează **Test**, apoi **Sync**.

Dacă Test arată în continuare `0 adrese IP corelabile`, nu mai ajusta matcher-ul: verifică în log `FortiGate CMDB inventory fetched` și trimite valorile `addresses`, `address_pages`, `groups`, `policies_raw`, `policy_pages`. Asta ne spune imediat dacă problema este forma datelor returnate de FortiGate.

Agentul nu trebuie actualizat: `vm-doc-agent 1.7.12` rămâne recomandat.
