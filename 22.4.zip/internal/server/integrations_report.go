package server

import (
	"context"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/integrationreport"
	"vm-doc-server/internal/xlsx"
)

// Integrations report uses existing agent snapshots. No fresh probes run here.
type integrationsReportVM struct {
	VMID              int64  `json:"vm_id"`
	VMName            string `json:"vm_name"`
	Hostname          string `json:"hostname"`
	IP                string `json:"ip"`
	OS                string `json:"os"`
	Environment       string `json:"environment"`
	Power             string `json:"power"`
	OperationalStatus string `json:"operational_status"`
	VCenter           string `json:"vcenter"`
	SourceID          int64  `json:"source_id"`
	Present           bool   `json:"present"`
	Agent             bool   `json:"agent"`
	AgentStatus       string `json:"agent_status"`
	Baseline          bool   `json:"baseline"`
	Outline           bool   `json:"outline"`
	Published         bool   `json:"published"`
	OSSupport         string `json:"os_support"`
	OSVersion         string `json:"-"`
	ServiceIDs        string `json:"-"`
	InventoryAt       string `json:"inventory_at"`
	integrationreport.Details
}

type integrationOption struct {
	Value string `json:"value"`
	Label string `json:"label"`
}
type integrationsReportOptions struct {
	Sources             []integrationOption `json:"sources"`
	Environments        []string            `json:"environments"`
	OS                  []string            `json:"operating_systems"`
	OperationalStatuses []string            `json:"operational_statuses"`
	Services            []integrationOption `json:"services"`
}
type integrationsReportResponse struct {
	GeneratedAt time.Time                 `json:"generated_at"`
	Total       int                       `json:"total"`
	Page        int                       `json:"page"`
	PageSize    int                       `json:"page_size"`
	Pages       int                       `json:"pages"`
	Summary     map[string]int            `json:"summary"`
	Options     integrationsReportOptions `json:"options"`
	Items       []integrationsReportVM    `json:"items"`
}
type integrationFilters struct {
	Query, Power, Environment, Source, OS, Operational, Present, Agent, Baseline, ServiceID, Outline, Published, OSSupport, Auditbeat, Filebeat, Node, GLPI, Syslog string
	Page, PageSize                                                                                                                                                  int
}

func readIntegrationFilters(r *http.Request) (integrationFilters, error) {
	q := r.URL.Query()
	f := integrationFilters{Query: strings.TrimSpace(q.Get("q")), Power: q.Get("power"), Environment: q.Get("environment"), Source: q.Get("source"), OS: q.Get("os"), Operational: q.Get("operational"), Present: q.Get("presence"), Agent: q.Get("agent"), Baseline: q.Get("baseline"), ServiceID: q.Get("service_id"), Outline: q.Get("outline"), Published: q.Get("published"), OSSupport: q.Get("os_support"), Auditbeat: q.Get("auditbeat"), Filebeat: q.Get("filebeat"), Node: q.Get("node"), GLPI: q.Get("glpi"), Syslog: q.Get("syslog"), Page: 1, PageSize: 10}
	for _, v := range []string{f.Query, f.Environment, f.Source, f.OS, f.Operational} {
		if len(v) > 255 {
			return f, fmt.Errorf("filtru prea lung")
		}
	}
	valid := func(x string, allowed ...string) bool {
		for _, v := range allowed {
			if x == v {
				return true
			}
		}
		return false
	}
	if !valid(f.Power, "", "on", "off", "suspended") || !valid(f.Present, "", "yes", "no") || !valid(f.Agent, "", "yes", "no", "configured", "unconfigured", "online", "offline", "disabled", "unknown") || !valid(f.Baseline, "", "yes", "no") || !valid(f.Outline, "", "yes", "no") || !valid(f.Published, "", "yes", "no") || !valid(f.OSSupport, "", "yes", "no") {
		return f, fmt.Errorf("filtru VM invalid")
	}
	for _, v := range []string{f.Auditbeat, f.Filebeat, f.Node, f.GLPI, f.Syslog} {
		if !valid(v, "", "OK", "NU", "Necunoscut") {
			return f, fmt.Errorf("filtru de integrare invalid")
		}
	}
	if f.Source != "" {
		id, err := strconv.ParseInt(f.Source, 10, 64)
		if err != nil || id <= 0 {
			return f, fmt.Errorf("sursă vCenter invalidă")
		}
	}
	if f.ServiceID != "" {
		id, err := strconv.ParseInt(f.ServiceID, 10, 64)
		if err != nil || id <= 0 {
			return f, fmt.Errorf("serviciu invalid")
		}
	}
	if q.Get("page") != "" {
		v, err := strconv.Atoi(q.Get("page"))
		if err != nil || v < 1 {
			return f, fmt.Errorf("pagină invalidă")
		}
		f.Page = v
	}
	if q.Get("page_size") != "" {
		v, err := strconv.Atoi(q.Get("page_size"))
		if err != nil || v < 1 || v > 200 {
			return f, fmt.Errorf("page_size invalid (1–200)")
		}
		f.PageSize = v
	}
	return f, nil
}

const integrationsReportSQL = `SELECT vm.id,vm.name,
 COALESCE(NULLIF(i.hostname,''),NULLIF(vm.guest_hostname,''),''),
 COALESCE(NULLIF(op.preferred_ip,''),NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,''),''),
 COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),''),
 COALESCE(i.os_version,''),
 COALESCE(NULLIF(env.item_code,''),NULLIF(env.name,''),NULLIF(op.environment,''),''),
 COALESCE(vm.power_state,''),
 COALESCE(NULLIF(ops.item_code,''),NULLIF(ops.name,''),NULLIF(op.operational_status,''),''),
 COALESCE(vc.name,''),vm.vcenter_source_id,vm.present_in_vcenter,
 CASE WHEN vm.agent_id IS NULL THEN 0 ELSE 1 END,
 CASE WHEN vm.agent_id IS NULL THEN 'unconfigured' WHEN ag.enabled=0 THEN 'disabled'
 WHEN ag.last_contact_at IS NULL THEN 'unknown'
 WHEN ag.offline_after_seconds>0 AND TIMESTAMPDIFF(SECOND,ag.last_contact_at,UTC_TIMESTAMP())<=ag.offline_after_seconds THEN 'online'
 ELSE 'offline' END,
 EXISTS(SELECT 1 FROM inventory_change_baselines b WHERE b.vm_id=vm.id),
 CASE WHEN vm.outline_documentation_disabled=0 THEN 1 ELSE 0 END,
 EXISTS(SELECT 1 FROM outline_vm_documents_global doc WHERE doc.vm_id=vm.id AND doc.target_code='virtualization' AND doc.last_synced_at IS NOT NULL),
 COALESCE((SELECT GROUP_CONCAT(DISTINCT sa.internal_service_id ORDER BY sa.internal_service_id SEPARATOR ',') FROM vm_internal_service_assignments sa WHERE sa.vm_id=vm.id),''),
 COALESCE(DATE_FORMAT(i.received_at,'%Y-%m-%d %H:%i:%s'),''),
 COALESCE(i.raw_json,'')
 FROM virtual_machines vm
 LEFT JOIN vcenter_sources vc ON vc.id=vm.vcenter_source_id
 LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id
 LEFT JOIN agents ag ON ag.id=vm.agent_id
 LEFT JOIN vm_operational_metadata op ON op.vm_id=vm.id
 LEFT JOIN vm_operational_nomenclatures ven ON ven.vm_id=vm.id AND ven.category_code='environment'
 LEFT JOIN nomenclature_items env ON env.id=ven.item_id AND env.category_code='environment'
 LEFT JOIN vm_operational_nomenclatures vos ON vos.vm_id=vm.id AND vos.category_code='operational_status'
 LEFT JOIN nomenclature_items ops ON ops.id=vos.item_id AND ops.category_code='operational_status'
 WHERE vm.retired=0 AND vm.excluded_by_vcenter_pool=0 AND NOT EXISTS(SELECT 1 FROM lifecycle_archives la WHERE la.resource_type='vm' AND la.resource_id=vm.id) ORDER BY LOWER(vm.name),vm.id`

func (a *App) scanIntegrationVMs(ctx context.Context) ([]integrationsReportVM, error) {
	rows, err := a.DB.QueryContext(ctx, integrationsReportSQL)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]integrationsReportVM, 0, 512)
	for rows.Next() {
		var v integrationsReportVM
		var raw string
		if err := rows.Scan(&v.VMID, &v.VMName, &v.Hostname, &v.IP, &v.OS, &v.OSVersion, &v.Environment, &v.Power, &v.OperationalStatus, &v.VCenter, &v.SourceID, &v.Present, &v.Agent, &v.AgentStatus, &v.Baseline, &v.Outline, &v.Published, &v.ServiceIDs, &v.InventoryAt, &raw); err != nil {
			return nil, err
		}
		v.Details = integrationreport.Parse([]byte(raw))
		out = append(out, v)
	}
	return out, rows.Err()
}
func filterIntegrationVM(v integrationsReportVM, f integrationFilters) bool {
	if f.Power == "on" && v.Power != "POWERED_ON" || f.Power == "off" && v.Power != "POWERED_OFF" || f.Power == "suspended" && v.Power != "SUSPENDED" {
		return false
	}
	if f.Environment != "" && rarCatalogEnvironmentCode(v.Environment) != rarCatalogEnvironmentCode(f.Environment) {
		return false
	}
	if f.Source != "" && strconv.FormatInt(v.SourceID, 10) != f.Source {
		return false
	}
	if f.OS != "" && !strings.EqualFold(v.OS, f.OS) {
		return false
	}
	if f.Operational != "" && !strings.EqualFold(v.OperationalStatus, f.Operational) {
		return false
	}
	if f.Present == "yes" && !v.Present || f.Present == "no" && v.Present {
		return false
	}
	if f.Agent == "yes" && !v.Agent || f.Agent == "no" && v.Agent {
		return false
	}
	if f.Agent != "" && f.Agent != "yes" && f.Agent != "no" {
		if f.Agent == "configured" {
			if !v.Agent {
				return false
			}
		} else if f.Agent == "unconfigured" {
			if v.Agent {
				return false
			}
		} else if f.Agent != v.AgentStatus {
			return false
		}
	}
	if f.Baseline == "yes" && !v.Baseline || f.Baseline == "no" && v.Baseline {
		return false
	}
	if f.Outline == "yes" && !v.Outline || f.Outline == "no" && v.Outline {
		return false
	}
	if f.Published == "yes" && !v.Published || f.Published == "no" && v.Published {
		return false
	}
	if f.OSSupport == "yes" && v.OSSupport != "supported" || f.OSSupport == "no" && v.OSSupport != "unsupported" {
		return false
	}
	if f.ServiceID != "" {
		found := false
		for _, part := range strings.Split(v.ServiceIDs, ",") {
			if strings.TrimSpace(part) == f.ServiceID {
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}

	if f.Auditbeat != "" && v.AuditbeatDial != f.Auditbeat || f.Filebeat != "" && v.FilebeatDial != f.Filebeat || f.Node != "" && v.NodeExporter != f.Node || f.GLPI != "" && v.GLPIStatus != f.GLPI || f.Syslog != "" && v.SyslogStatus != f.Syslog {
		return false
	}
	if f.Query != "" {
		haystack := strings.ToLower(strings.Join([]string{v.VMName, v.Hostname, v.IP, v.OS, v.Environment, v.VCenter, v.AuditbeatIP, v.FilebeatIP, v.GLPIVersion, v.SyslogHost, v.SyslogProtocol}, " "))
		if !strings.Contains(haystack, strings.ToLower(f.Query)) {
			return false
		}
	}
	return true
}
func sortedKeys(set map[string]bool) []string {
	out := make([]string, 0, len(set))
	for k := range set {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
func integrationRowsAndOptions(ctx context.Context, a *App, f integrationFilters) ([]integrationsReportVM, integrationsReportOptions, error) {
	all, err := a.scanIntegrationVMs(ctx)
	if err != nil {
		return nil, integrationsReportOptions{}, err
	}
	opts := integrationsReportOptions{Sources: []integrationOption{}, Environments: []string{}, OS: []string{}, OperationalStatuses: []string{}}
	src := map[string]string{}
	envs := map[string]bool{}
	oss := map[string]bool{}
	opss := map[string]bool{}
	filtered := make([]integrationsReportVM, 0, len(all))
	rules, err := a.activeUnsupportedOSRules(ctx)
	if err != nil {
		return nil, opts, err
	}
	serviceRows, err := a.DB.QueryContext(ctx, `SELECT id,name FROM internal_services WHERE active=1 ORDER BY name,id`)
	if err != nil {
		return nil, opts, err
	}
	for serviceRows.Next() {
		var id int64
		var name string
		if err = serviceRows.Scan(&id, &name); err != nil {
			serviceRows.Close()
			return nil, opts, err
		}
		opts.Services = append(opts.Services, integrationOption{Value: strconv.FormatInt(id, 10), Label: name})
	}
	if err = serviceRows.Err(); err != nil {
		serviceRows.Close()
		return nil, opts, err
	}
	serviceRows.Close()
	for _, v := range all {
		if v.OS == "" {
			v.OSSupport = "undetermined"
		} else {
			v.OSSupport = "supported"
			for _, rule := range rules {
				if osRuleMatches(rule, v.OS, v.OSVersion) {
					v.OSSupport = "unsupported"
					break
				}
			}
		}
		src[strconv.FormatInt(v.SourceID, 10)] = v.VCenter
		if code := rarCatalogEnvironmentCode(v.Environment); code != "" {
			envs[code] = true
		}
		if v.OS != "" {
			oss[v.OS] = true
		}
		if v.OperationalStatus != "" {
			opss[v.OperationalStatus] = true
		}
		if filterIntegrationVM(v, f) {
			filtered = append(filtered, v)
		}
	}
	for _, k := range sortedKeys(envs) {
		opts.Environments = append(opts.Environments, k)
	}
	opts.OS = sortedKeys(oss)
	opts.OperationalStatuses = sortedKeys(opss)
	for id, label := range src {
		opts.Sources = append(opts.Sources, integrationOption{id, label})
	}
	sort.Slice(opts.Sources, func(i, j int) bool { return opts.Sources[i].Label < opts.Sources[j].Label })
	return filtered, opts, nil
}
func (a *App) reportsIntegrations(w http.ResponseWriter, r *http.Request) {
	f, err := readIntegrationFilters(r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	filtered, options, err := integrationRowsAndOptions(r.Context(), a, f)
	if err != nil {
		respond(w, nil, err)
		return
	}
	summary := map[string]int{"total": len(filtered), "audit_ok": 0, "audit_failed": 0, "filebeat_ok": 0, "filebeat_failed": 0, "node_ok": 0, "node_failed": 0, "glpi_ok": 0, "syslog_ok": 0, "no_inventory": 0}
	for _, v := range filtered {
		if v.AuditbeatDial == "OK" {
			summary["audit_ok"]++
		} else if v.AuditbeatDial == "NU" {
			summary["audit_failed"]++
		}
		if v.FilebeatDial == "OK" {
			summary["filebeat_ok"]++
		} else if v.FilebeatDial == "NU" {
			summary["filebeat_failed"]++
		}
		if v.NodeExporter == "OK" {
			summary["node_ok"]++
		} else if v.NodeExporter == "NU" {
			summary["node_failed"]++
		}
		if v.GLPIStatus == "OK" {
			summary["glpi_ok"]++
		}
		if v.SyslogStatus == "OK" {
			summary["syslog_ok"]++
		}
		if v.InventoryAt == "" {
			summary["no_inventory"]++
		}
	}
	pages := (len(filtered) + f.PageSize - 1) / f.PageSize
	if pages == 0 {
		pages = 1
	}
	if f.Page > pages {
		f.Page = pages
	}
	start := (f.Page - 1) * f.PageSize
	end := start + f.PageSize
	if end > len(filtered) {
		end = len(filtered)
	}
	jsonResponse(w, http.StatusOK, integrationsReportResponse{GeneratedAt: time.Now().UTC(), Total: len(filtered), Page: f.Page, PageSize: f.PageSize, Pages: pages, Summary: summary, Options: options, Items: filtered[start:end]})
}
func (a *App) exportReportIntegrations(w http.ResponseWriter, r *http.Request) {
	f, err := readIntegrationFilters(r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	filtered, _, err := integrationRowsAndOptions(r.Context(), a, f)
	if err != nil {
		respond(w, nil, err)
		return
	}
	cells := [][]xlsx.Cell{{xlsx.Text("VM"), xlsx.Text("Hostname"), xlsx.Text("IP VM"), xlsx.Text("OS"), xlsx.Text("Mediu"), xlsx.Text("Power"), xlsx.Text("Status operațional"), xlsx.Text("vCenter"), xlsx.Text("Auditbeat IP / destinație"), xlsx.Text("Auditbeat dial-up"), xlsx.Text("Filebeat IP / destinație"), xlsx.Text("Filebeat dial-up"), xlsx.Text("GLPI Agent versiune"), xlsx.Text("GLPI Agent stare"), xlsx.Text("Node Exporter activ"), xlsx.Text("Syslog remote host"), xlsx.Text("Syslog protocol"), xlsx.Text("Syslog configurat"), xlsx.Text("Agent asociat"), xlsx.Text("Stare agent"), xlsx.Text("Baseline"), xlsx.Text("Outline permis"), xlsx.Text("Publicat Outline"), xlsx.Text("OS suportat"), xlsx.Text("În vCenter"), xlsx.Text("Ultima colectare")}}
	for _, v := range filtered {
		cells = append(cells, []xlsx.Cell{xlsx.Text(v.VMName), xlsx.Text(v.Hostname), xlsx.Text(v.IP), xlsx.Text(v.OS), xlsx.Text(v.Environment), xlsx.Text(v.Power), xlsx.Text(v.OperationalStatus), xlsx.Text(v.VCenter), xlsx.Text(v.AuditbeatIP), xlsx.Text(v.AuditbeatDial), xlsx.Text(v.FilebeatIP), xlsx.Text(v.FilebeatDial), xlsx.Text(v.GLPIVersion), xlsx.Text(v.GLPIStatus), xlsx.Text(v.NodeExporter), xlsx.Text(v.SyslogHost), xlsx.Text(v.SyslogProtocol), xlsx.Text(v.SyslogStatus), xlsx.Text(yesNo(v.Agent)), xlsx.Text(v.AgentStatus), xlsx.Text(yesNo(v.Baseline)), xlsx.Text(yesNo(v.Outline)), xlsx.Text(yesNo(v.Published)), xlsx.Text(v.OSSupport), xlsx.Text(yesNo(v.Present)), xlsx.Text(v.InventoryAt)})
	}
	if err := writeXLSXResponse(w, "Integrări", "integrari", cells); err != nil && a.Logger != nil {
		a.Logger.Error("write integrations XLSX", "error", err)
	}
}
