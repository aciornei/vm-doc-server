// Package integrationreport reads the integration section of VM-DOC agent
// snapshots. A missing probe result is unknown, never a failed dial-up.
package integrationreport

import (
	"encoding/json"
	"fmt"
	"net"
	"net/url"
	"regexp"
	"sort"
	"strings"
)

type Details struct {
	AuditbeatIP    string `json:"auditbeat_ip"`
	AuditbeatDial  string `json:"auditbeat_dial"`
	FilebeatIP     string `json:"filebeat_ip"`
	FilebeatDial   string `json:"filebeat_dial"`
	GLPIVersion    string `json:"glpi_version"`
	GLPIStatus     string `json:"glpi_status"`
	NodeExporter   string `json:"node_exporter"`
	SyslogHost     string `json:"syslog_host"`
	SyslogStatus   string `json:"syslog_status"`
	SyslogProtocol string `json:"syslog_protocol"`
}

func stringValue(v any) string {
	switch x := v.(type) {
	case string:
		return strings.TrimSpace(x)
	case json.Number:
		return x.String()
	case float64:
		return fmt.Sprint(x)
	case bool:
		if x {
			return "true"
		}
		return "false"
	default:
		return ""
	}
}
func object(v any) map[string]any {
	if x, ok := v.(map[string]any); ok {
		return x
	}
	return nil
}
func value(m map[string]any, keys ...string) any {
	for _, k := range keys {
		if v, ok := m[k]; ok && v != nil {
			return v
		}
	}
	return nil
}
func text(m map[string]any, keys ...string) string { return stringValue(value(m, keys...)) }
func boolState(v any) string {
	switch x := v.(type) {
	case bool:
		if x {
			return "OK"
		}
		return "NU"
	case float64:
		if x != 0 {
			return "OK"
		}
		return "NU"
	case string:
		switch strings.ToLower(strings.TrimSpace(x)) {
		case "true", "yes", "ok", "1", "success", "connected", "running", "active", "up":
			return "OK"
		case "false", "no", "0", "failed", "error", "down", "stopped", "inactive", "dead":
			return "NU"
		}
	}
	return "Necunoscut"
}
func listStrings(v any) []string {
	switch a := v.(type) {
	case string:
		if strings.TrimSpace(a) != "" {
			return []string{strings.TrimSpace(a)}
		}
	case []any:
		res := []string{}
		for _, x := range a {
			if s := stringValue(x); s != "" {
				res = append(res, s)
			} else if m := object(x); m != nil {
				for _, key := range []string{"host", "address", "ip", "destination", "url", "server", "endpoint"} {
					if t := text(m, key); t != "" {
						res = append(res, t)
						break
					}
				}
			}
		}
		return res
	}
	return nil
}
func distinct(values ...string) string {
	set := map[string]bool{}
	s := []string{}
	for _, v := range values {
		for _, p := range strings.Split(v, ",") {
			p = strings.TrimSpace(p)
			if p != "" && !set[p] {
				set[p] = true
				s = append(s, p)
			}
		}
	}
	sort.Strings(s)
	return strings.Join(s, ", ")
}
func dest(m map[string]any) string {
	vals := []string{text(m, "output_host", "host", "destination", "remote_host", "server", "ip")}
	for _, key := range []string{"output_hosts", "hosts", "destinations", "remote_destinations", "servers", "metrics_endpoints"} {
		vals = append(vals, listStrings(m[key])...)
	}
	// Do not treat a generic service URL as a confirmed outgoing connection.
	return distinct(vals...)
}

// beatDestinations handles both flat fields and the nested output shapes used
// by different agent generations. A successful output test does not itself
// identify an address, so never substitute a guessed or VM IP.
func beatDestinations(m map[string]any) string {
	if m == nil {
		return ""
	}
	collected := []string{}
	add := func(v any) {
		for _, candidate := range listDestinationValues(v) {
			if safe := safeDestination(candidate); safe != "" {
				collected = append(collected, safe)
			}
		}
	}
	// Direct fields from earlier agents (one or more Logstash/Elasticsearch hosts).
	for _, k := range []string{"output_host", "output_hosts", "output_ip", "output_address", "output_url", "output_endpoint", "destination_ip", "destination_host", "destination", "destinations", "remote_host", "hosts", "host", "servers", "server", "logstash_hosts", "elasticsearch_hosts", "beat_output_hosts"} {
		if v, ok := m[k]; ok {
			add(v)
		}
	}
	// Newer collectors may nest output data in configuration or output type.
	for _, k := range []string{"output", "outputs", "output_config", "output_settings", "configured_output", "beat_output", "config", "configuration", "settings"} {
		if v, ok := m[k]; ok {
			collectBeatOutput(v, 0, &collected)
		}
	}
	// Flattened YAML keys from some JSON serializers: output.logstash.hosts.
	for k, v := range m {
		if strings.HasPrefix(strings.ToLower(k), "output.") && (strings.HasSuffix(k, ".hosts") || strings.HasSuffix(k, ".host") || strings.HasSuffix(k, ".servers")) {
			add(v)
		}
	}
	// The stdout of `filebeat test output`/`auditbeat test output` can identify
	// the remote endpoint even when the collector did not expose output_hosts.
	for _, k := range []string{"output_test_output", "output_test_details", "connection_test_output", "dial_up_output"} {
		if raw := text(m, k); raw != "" {
			collected = append(collected, beatTestDestinations(raw)...)
		}
	}
	return distinct(collected...)
}
func listDestinationValues(v any) []string {
	if v == nil {
		return nil
	}
	switch x := v.(type) {
	case string:
		if strings.Contains(x, ",") || (strings.HasPrefix(strings.TrimSpace(x), "[") && strings.HasSuffix(strings.TrimSpace(x), "]")) {
			return parseInlineHosts(x)
		}
		return []string{x}
	case []any:
		out := []string{}
		for _, item := range x {
			out = append(out, listDestinationValues(item)...)
		}
		return out
	case map[string]any:
		for _, k := range []string{"host", "hostname", "ip", "address", "url", "endpoint", "server", "destination"} {
			if v, ok := x[k]; ok {
				return listDestinationValues(v)
			}
		}
	}
	return nil
}
func collectBeatOutput(v any, depth int, results *[]string) {
	if depth > 5 {
		return
	}
	switch x := v.(type) {
	case string:
		// Some collectors store sanitized, minimal output configuration as YAML.
		for _, line := range strings.Split(x, "\n") {
			if match := beatHostsLine.FindStringSubmatch(line); len(match) > 1 {
				for _, v := range parseInlineHosts(match[1]) {
					if v = safeDestination(v); v != "" {
						*results = append(*results, v)
					}
				}
			}
		}
	case []any:
		for _, item := range x {
			collectBeatOutput(item, depth+1, results)
		}
	case map[string]any:
		for k, item := range x {
			low := strings.ToLower(k)
			switch low {
			case "host", "hosts", "output_host", "output_hosts", "address", "addresses", "ip", "server", "servers", "url", "endpoint", "endpoints", "destination", "destinations", "logstash_hosts", "elasticsearch_hosts":
				for _, v := range listDestinationValues(item) {
					if safe := safeDestination(v); safe != "" {
						*results = append(*results, safe)
					}
				}
			case "output", "outputs", "logstash", "elasticsearch", "kafka", "redis", "file", "config", "configuration", "settings", "beat_output", "configured_output":
				collectBeatOutput(item, depth+1, results)
			default:
				if strings.HasPrefix(low, "output.") && (strings.HasSuffix(low, "hosts") || strings.HasSuffix(low, "host")) {
					collectBeatOutput(map[string]any{"hosts": item}, depth+1, results)
				}
			}
		}
	}
}

var beatHostsLine = regexp.MustCompile(`(?i)^\s*(?:hosts|host|output_hosts|servers)\s*:\s*(.+?)\s*(?:#.*)?$`)
var beatTestDial = regexp.MustCompile(`(?i)\bdial\s+(?:tcp|udp)(?:4|6)?\s+(\[?[0-9a-f:.]+\]?:\d+)`)
var beatTestOutput = regexp.MustCompile(`(?i)^\s*(?:elasticsearch|logstash|kafka|redis)\s*:\s*(?:https?://)?(\[[0-9a-f:]+\]|[a-z0-9][a-z0-9._-]*)(?::(\d{2,5}))?\s*(?:\.\.\.|$|\s)`)

func parseInlineHosts(v string) []string {
	v = strings.TrimSpace(v)
	if strings.HasPrefix(v, "[") && strings.HasSuffix(v, "]") {
		v = strings.TrimSpace(v[1 : len(v)-1])
	}
	// Quoted comma-separated endpoints and conventional YAML arrays.
	parts := strings.Split(v, ",")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		part = strings.Trim(strings.TrimSpace(part), ` "'`)
		if part != "" {
			out = append(out, part)
		}
	}
	return out
}
func beatTestDestinations(output string) []string {
	found := []string{}
	for _, line := range strings.Split(output, "\n") {
		if m := beatTestDial.FindStringSubmatch(line); len(m) > 1 {
			if v := safeDestination(m[1]); v != "" {
				found = append(found, v)
			}
		}
		if m := beatTestOutput.FindStringSubmatch(line); len(m) > 1 {
			v := m[1]
			if len(m) > 2 && m[2] != "" {
				v += ":" + m[2]
			}
			if v = safeDestination(v); v != "" {
				found = append(found, v)
			}
		}
		if m := beatHostsLine.FindStringSubmatch(line); len(m) > 1 {
			for _, v := range parseInlineHosts(m[1]) {
				if v = safeDestination(v); v != "" {
					found = append(found, v)
				}
			}
		}
	}
	return found
}

// Strip URL credentials, queries, and paths so a diagnostic/configuration
// string never leaks secrets into a read-only report or its Excel export.
func safeDestination(raw string) string {
	raw = strings.TrimSpace(strings.Trim(raw, ` "'[]`))
	if raw == "" || strings.ContainsAny(raw, "\n\r\t") || len(raw) > 255 {
		return ""
	}
	if strings.Contains(raw, "://") {
		parsed, err := url.Parse(raw)
		if err != nil {
			return ""
		}
		raw = parsed.Host
	} else if strings.Contains(raw, "@") {
		raw = raw[strings.LastIndex(raw, "@")+1:]
	}
	if strings.ContainsAny(raw, "/?# ") {
		return ""
	}
	if strings.HasPrefix(raw, "[") && strings.Contains(raw, "]:") {
		if h, p, err := net.SplitHostPort(raw); err == nil {
			return net.JoinHostPort(h, p)
		}
	}
	// Keep IPv4/IPv6/FQDN plus optional port; reject generic log messages.
	if !regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9._:-]*$`).MatchString(raw) {
		return ""
	}
	return raw
}

func serviceState(m map[string]any) string {
	if m == nil {
		return "Necunoscut"
	}
	if v := value(m, "service_active", "active", "running", "service_running"); v != nil {
		return boolState(v)
	}
	if v := value(m, "installed"); v != nil && boolState(v) == "NU" {
		return "NU"
	}
	return "Necunoscut"
}
func parseSyslog(m map[string]any) (string, string) {
	if m == nil {
		return "", ""
	}
	hosts := []string{text(m, "destination_host", "remote_host", "destination", "output_host", "host", "server")}
	protocols := []string{text(m, "protocol", "transport", "proto")}
	for _, key := range []string{"destinations", "remote_destinations", "forwarders", "remote_servers", "targets"} {
		for _, v := range anyArray(m[key]) {
			item := object(v)
			if item == nil {
				hosts = append(hosts, stringValue(v))
				continue
			}
			hosts = append(hosts, text(item, "host", "address", "server", "ip", "destination"))
			protocols = append(protocols, text(item, "protocol", "transport", "proto"))
		}
	}
	return distinct(hosts...), distinct(protocols...)
}
func anyArray(v any) []any {
	if a, ok := v.([]any); ok {
		return a
	}
	if v != nil {
		return []any{v}
	}
	return nil
}

// Parse does not infer successful connectivity from configured hosts or a
// running service. Only an explicit output_test_ok/probe outcome is decisive.
func Parse(raw []byte) Details {
	out := Details{AuditbeatDial: "Necunoscut", FilebeatDial: "Necunoscut", GLPIStatus: "Necunoscut", NodeExporter: "Necunoscut", SyslogStatus: "Necunoscut"}
	var root map[string]any
	if len(raw) == 0 || json.Unmarshal(raw, &root) != nil {
		return out
	}
	ints := object(root["integrations"])
	if ints == nil {
		ints = root
	}
	a := object(ints["auditbeat"])
	f := object(ints["filebeat"])
	if a != nil {
		out.AuditbeatIP = beatDestinations(a)
		out.AuditbeatDial = boolState(value(a, "output_test_ok", "dial_up_ok", "dialup_ok", "connection_test_ok", "output_test_status"))
	}
	if f != nil {
		out.FilebeatIP = beatDestinations(f)
		out.FilebeatDial = boolState(value(f, "output_test_ok", "dial_up_ok", "dialup_ok", "connection_test_ok", "output_test_status"))
	}
	glpi := object(value(ints, "glpi_agent", "glpi", "glpiagent"))
	if glpi != nil {
		out.GLPIVersion = text(glpi, "package_version", "version", "agent_version")
		out.GLPIStatus = serviceState(glpi)
		if out.GLPIStatus == "Necunoscut" && out.GLPIVersion != "" {
			out.GLPIStatus = "OK"
		}
	}
	node := object(value(ints, "node_exporter", "nodeexporter"))
	if node != nil {
		out.NodeExporter = serviceState(node)
	}
	syslog := object(value(ints, "syslog", "rsyslog"))
	out.SyslogHost, out.SyslogProtocol = parseSyslog(syslog)
	out.SyslogStatus = "Necunoscut"
	if syslog != nil {
		out.SyslogStatus = "NU"
		if out.SyslogHost != "" {
			out.SyslogStatus = "OK"
		}
	}
	return out
}
