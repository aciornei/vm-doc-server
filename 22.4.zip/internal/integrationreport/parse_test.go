package integrationreport

import "testing"

func TestParse(t *testing.T) {
	v := Parse([]byte(`{"integrations":{"auditbeat":{"installed":true,"output_host":"10.0.0.1:5044","output_test_ok":true},"filebeat":{"output_hosts":["10.0.0.2:5044"],"output_test_ok":false},"glpi_agent":{"package_version":"1.15","service_active":"running"},"node_exporter":{"installed":true,"service_active":"active"},"syslog":{"destinations":[{"host":"log01:514","protocol":"tcp"},{"host":"log02:514","protocol":"udp"}]}}}`))
	if v.AuditbeatIP != "10.0.0.1:5044" || v.AuditbeatDial != "OK" || v.FilebeatDial != "NU" || v.GLPIVersion != "1.15" || v.NodeExporter != "OK" || v.SyslogProtocol != "tcp, udp" || v.SyslogStatus != "OK" {
		t.Fatalf("bad parse: %+v", v)
	}
}
func TestUnknownIsNotFailure(t *testing.T) {
	v := Parse([]byte(`{"integrations":{"auditbeat":{"installed":true,"output_host":"10.0.0.1"},"node_exporter":{"installed":false}}}`))
	if v.AuditbeatDial != "Necunoscut" || v.NodeExporter != "NU" {
		t.Fatalf("unexpected: %+v", v)
	}
}
func TestMissing(t *testing.T) {
	v := Parse(nil)
	if v.FilebeatDial != "Necunoscut" || v.NodeExporter != "Necunoscut" || v.SyslogStatus != "Necunoscut" {
		t.Fatalf("unexpected: %+v", v)
	}
}

func TestNestedBeatOutputHosts(t *testing.T) {
	v := Parse([]byte(`{"integrations":{"auditbeat":{"output":{"logstash":{"hosts":["10.15.1.20:5044","log02.example:5044"]}},"output_test_ok":true},"filebeat":{"config":{"output":{"elasticsearch":{"hosts":["https://user:secret@10.15.1.21:9200/_bulk?token=secret"]}}},"output_test_ok":true}}}`))
	if v.AuditbeatIP != "10.15.1.20:5044, log02.example:5044" || v.FilebeatIP != "10.15.1.21:9200" || v.AuditbeatDial != "OK" || v.FilebeatDial != "OK" {
		t.Fatalf("nested Beat endpoints not parsed correctly: %+v", v)
	}
}
func TestBeatTestOutputFallback(t *testing.T) {
	v := Parse([]byte(`{"integrations":{"auditbeat":{"output_test_ok":true,"output_test_output":"logstash: 10.22.7.8:5044...\n connection... OK"},"filebeat":{"output_test_ok":false,"output_test_output":"dial tcp 10.22.7.9:9200: connection refused"}}}`))
	if v.AuditbeatIP != "10.22.7.8:5044" || v.FilebeatIP != "10.22.7.9:9200" || v.AuditbeatDial != "OK" || v.FilebeatDial != "NU" {
		t.Fatalf("test output fallback failed: %+v", v)
	}
}
func TestSuccessfulTestWithoutDestinationStaysEmpty(t *testing.T) {
	v := Parse([]byte(`{"integrations":{"auditbeat":{"output_test_ok":true,"output_test_output":"OK"},"filebeat":{"output_test_ok":true}}}`))
	if v.AuditbeatIP != "" || v.FilebeatIP != "" || v.AuditbeatDial != "OK" || v.FilebeatDial != "OK" {
		t.Fatalf("must not infer host from successful test: %+v", v)
	}
}
func TestFlatBeatOutputKeys(t *testing.T) {
	v := Parse([]byte(`{"integrations":{"auditbeat":{"config":{"output.logstash.hosts":["syslog01:5044"]},"output_test_ok":true},"filebeat":{"output_hosts":["203.0.113.10:5044"],"output_test_ok":true}}}`))
	if v.AuditbeatIP != "syslog01:5044" || v.FilebeatIP != "203.0.113.10:5044" {
		t.Fatalf("flattened Beat config: %+v", v)
	}
}
