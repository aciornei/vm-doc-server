# Upgrade VM-DOC Server 0.22.3 → 0.22.4

## Pregătire

1. Verifică `cat VERSION` = `0.22.3` în **sursele** VM-DOC de pe server.
2. Fă backup pentru MariaDB, configurație, surse și binarul curent (verifică `ExecStart` din `systemctl cat vm-doc-server`).
3. Testează mai întâi pe staging.

## Aplicare incrementală

```bash
cd /CALE/CATRE/SURSE-VM-DOC
unzip -o /CALE/VM-DOC-UPDATE-223-224.zip -d .
cat VERSION  # 0.22.4
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Instalează binarul compilat în locația reală `ExecStart`, apoi repornește serviciul. Verifică versiunea și fă `Ctrl+F5` în browser.

## Testare funcțională

1. `Rapoarte → Monitorizare și integrări → Integrări`: antet compact cu data/ora, export și reîncărcare.
2. Verifică șase filtre principale vizibile, filtre VM suplimentare ascunse implicit și funcționalitatea toggle/reset.
3. Verifică șapte carduri pe un rând pe ecran mare și numere de pagină + selector 10/25/50/100/200.
4. Pe 2–3 VM-uri cu Auditbeat/Filebeat: compară `auditbeat_ip` și `filebeat_ip` cu datele reale din `inventory_snapshots.raw_json` (doar câmpurile nesensibile de destinație). `output_test_ok=true` nu garantează că snapshotul conține IP-ul.
5. Verifică Excel: aceeași destinație ca în UI, filtre identice, toate VM-urile filtrate, inclusiv paginile următoare.
6. Testează celelalte rapoarte și lista VM pentru regresii.

## Rollback

Revino la sursele, binarul și asset-urile 0.22.3. Nu există rollback SQL (nu s-au schimbat tabelele).

## Limitări

Fără `vendor/` și mediul MariaDB real, build-ul complet și validarea datelor agentului se fac la voi. Agentul nu se actualizează.
