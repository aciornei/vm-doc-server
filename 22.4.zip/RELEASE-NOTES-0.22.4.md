# VM-DOC Server 0.22.4 – Raport Integrări: destinații Beats și UI

Bază: **0.22.3**. Actualizare doar pe server, fără migrare SQL, fără modificarea agentului sau a API-ului public.

## Corecții date

- Auditbeat și Filebeat: raportul extrage acum destinația și din obiecte `output`, `outputs`, `output_config`, `config` / `configuration`, inclusiv `output.logstash.hosts` și `output.elasticsearch.hosts`.
- Când există, se interpretează și destinația indicată în rezultatul `output_test_output` (linii `logstash: ...`, `elasticsearch: ...`, `dial tcp ...`), fără a expune parole, URL-uri cu credențiale, query-uri sau tokenuri.
- Starea `output_test_ok` este păstrată independent de existența destinației: OK fără adresă nu conduce la un IP inventat.
- Coloanele și exportul Excel utilizează aceeași funcție de interpretare; filtrarea existentă rămâne neschimbată.

## Interfață

- Antet `Integrări [data/ora]` cu **Export Excel** și **Reîncarcă** în dreapta; explicația de sub titlu a fost eliminată.
- Filtre principale vizibile: Căutare, Auditbeat, Filebeat, GLPI Agent, Node Exporter, Syslog.
- Filtrele VM rămase sunt pliabile, cu indicatori pentru selecțiile active și buton Resetare.
- Paginare cu numere de pagină, Anterior / Următor și selector 10/25/50/100/200 ca în inventarul VM. Implicit: 10 rânduri.
- 7 KPI de dimensiune egală, pe un rând când spațiul permite; padding ameliorat pentru filtre, tabel și paginare.

## Verificare / limitări

- Testele Go `./internal/integrationreport` și `./internal/xlsx` și `node --check` au trecut.
- Smoke Chromium cu API simulat: filtre, carduri, panou avansat și paginare.
- **Nu am testat pe inventarul real al agentului și pe MariaDB de producție**. Dacă agentul transmite doar testul reușit, dar nicio destinație, raportul nu poate deduce IP-ul. Pentru cazul rămas, este necesară verificarea structurii JSON a snapshotului.
- Build Go complet cu `vendor/` și instalarea serviciului trebuie efectuate în mediul de staging / producție, cu backup.
