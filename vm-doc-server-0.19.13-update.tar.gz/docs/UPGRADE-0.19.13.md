# Upgrade vm-doc-server 0.19.12 → 0.19.13

0.19.13 adaugă în UI suportul de publicare/filtrare pentru release-uri `linux/386`. Backend-ul repository era deja multi-arhitectură și selectează release-ul după `channel + os + arch + version`. Nu există migrare DB.

## Upgrade

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.12 vm-doc-server-0.19.13
tar -xzf /cale/vm-doc-server-0.19.13-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.13
cd /usr/local/src/vm-doc-server-0.19.13
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

## Publicare agent 1.6.8

În **Agenți → Release-uri agent**, publicați separat aceeași versiune pentru:

- `linux / amd64` cu `vm-doc-agent-1.6.8-linux-amd64` și updaterul amd64;
- `linux / 386` cu `vm-doc-agent-1.6.8-linux-386` și updaterul 386.

Un agent 386 cere automat `arch=386`; un agent amd64 cere `arch=amd64`. Nu există fallback între arhitecturi, ceea ce previne instalarea unui ELF incompatibil.

După upgrade folosiți `Ctrl+F5`.
