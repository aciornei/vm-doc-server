package agentupdates

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestLatest(t *testing.T) {
	dir := t.TempDir()
	files := filepath.Join(dir, "files")
	if err := os.MkdirAll(files, 0755); err != nil {
		t.Fatal(err)
	}
	agent := []byte("agent")
	upd := []byte("updater")
	if err := os.WriteFile(filepath.Join(files, "agent.bin"), agent, 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(files, "updater.bin"), upd, 0644); err != nil {
		t.Fatal(err)
	}
	ah := sha256.Sum256(agent)
	uh := sha256.Sum256(upd)
	repo := Repository{Releases: []Release{{Version: "1.3.0", Channel: "stable", OS: "linux", Arch: "amd64", AgentFilename: "agent.bin", AgentSHA256: hex.EncodeToString(ah[:]), AgentSizeBytes: int64(len(agent)), UpdaterFilename: "updater.bin", UpdaterSHA256: hex.EncodeToString(uh[:]), UpdaterSizeBytes: int64(len(upd)), PublishedAt: time.Now().UTC()}}}
	raw, _ := json.Marshal(repo)
	if err := os.WriteFile(filepath.Join(dir, "releases.json"), raw, 0644); err != nil {
		t.Fatal(err)
	}
	svc := Service{Directory: dir}
	got, err := svc.Latest("stable", "linux", "amd64", "1.2.0")
	if err != nil {
		t.Fatal(err)
	}
	if !got.Available || got.Version != "1.3.0" {
		t.Fatalf("unexpected latest: %+v", got)
	}
	current, err := svc.Latest("stable", "linux", "amd64", "1.3.0")
	if err != nil {
		t.Fatal(err)
	}
	if current.Available {
		t.Fatalf("expected no update: %+v", current)
	}
}

func TestPublishPromoteDelete(t *testing.T) {
	dir := t.TempDir()
	svc := Service{Directory: dir}
	if err := svc.Validate(); err != nil {
		t.Fatal(err)
	}
	agentPath := filepath.Join(t.TempDir(), "agent")
	updaterPath := filepath.Join(t.TempDir(), "updater")
	if err := os.WriteFile(agentPath, []byte("agent-1.3.2"), 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(updaterPath, []byte("updater-1.3.2"), 0755); err != nil {
		t.Fatal(err)
	}
	release, err := svc.Publish(PublishInput{Version: "1.3.2", Channel: "testing", OS: "linux", Arch: "amd64", AgentPath: agentPath, UpdaterPath: updaterPath, Notes: "pilot"})
	if err != nil {
		t.Fatal(err)
	}
	if release.Channel != "testing" || release.Version != "1.3.2" {
		t.Fatalf("unexpected release: %+v", release)
	}
	promoted, err := svc.Promote("1.3.2", "linux", "amd64")
	if err != nil {
		t.Fatal(err)
	}
	if promoted.Channel != "stable" {
		t.Fatalf("unexpected promoted release: %+v", promoted)
	}
	list, err := svc.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(list) != 2 {
		t.Fatalf("expected testing + stable, got %d", len(list))
	}
	if err := svc.Delete("1.3.2", "testing", "linux", "amd64"); err != nil {
		t.Fatal(err)
	}
	list, err = svc.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(list) != 1 || list[0].Channel != "stable" {
		t.Fatalf("unexpected list after delete: %+v", list)
	}
	if err := svc.Delete("1.3.2", "stable", "linux", "amd64"); err != nil {
		t.Fatal(err)
	}
	if fileExists(filepath.Join(dir, "files", release.AgentFilename)) {
		t.Fatal("unreferenced agent artifact should be removed")
	}
}

func TestLatestSelectsExactArchitecture(t *testing.T) {
	dir := t.TempDir()
	files := filepath.Join(dir, "files")
	if err := os.MkdirAll(files, 0755); err != nil {
		t.Fatal(err)
	}
	mk := func(name, body string) (string, int64) {
		data := []byte(body)
		if err := os.WriteFile(filepath.Join(files, name), data, 0755); err != nil {
			t.Fatal(err)
		}
		h := sha256.Sum256(data)
		return hex.EncodeToString(h[:]), int64(len(data))
	}
	amdAgentHash, amdAgentSize := mk("agent-amd64", "agent-amd64")
	amdUpdaterHash, amdUpdaterSize := mk("updater-amd64", "updater-amd64")
	i386AgentHash, i386AgentSize := mk("agent-386", "agent-386")
	i386UpdaterHash, i386UpdaterSize := mk("updater-386", "updater-386")
	now := time.Now().UTC()
	repo := Repository{Releases: []Release{
		{Version: "1.6.8", Channel: "stable", OS: "linux", Arch: "amd64", AgentFilename: "agent-amd64", AgentSHA256: amdAgentHash, AgentSizeBytes: amdAgentSize, UpdaterFilename: "updater-amd64", UpdaterSHA256: amdUpdaterHash, UpdaterSizeBytes: amdUpdaterSize, PublishedAt: now},
		{Version: "1.6.8", Channel: "stable", OS: "linux", Arch: "386", AgentFilename: "agent-386", AgentSHA256: i386AgentHash, AgentSizeBytes: i386AgentSize, UpdaterFilename: "updater-386", UpdaterSHA256: i386UpdaterHash, UpdaterSizeBytes: i386UpdaterSize, PublishedAt: now},
	}}
	raw, _ := json.Marshal(repo)
	if err := os.WriteFile(filepath.Join(dir, "releases.json"), raw, 0644); err != nil {
		t.Fatal(err)
	}
	svc := Service{Directory: dir}
	got, err := svc.Latest("stable", "linux", "386", "1.6.7")
	if err != nil {
		t.Fatal(err)
	}
	if !got.Available || got.Arch != "386" || got.AgentURL != "/api/v1/agent-updates/download/agent-386" {
		t.Fatalf("expected exact 386 release, got %+v", got)
	}
}
