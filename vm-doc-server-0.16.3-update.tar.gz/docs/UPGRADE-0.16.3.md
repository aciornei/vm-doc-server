# Upgrade vm-doc-server 0.16.2 → 0.16.3

0.16.3 este un hotfix de interfață și generare DOCX. Nu adaugă migrare SQL și nu necesită schimbarea agentului.

## Pași

1. Faceți backup aplicației și bazei de date.
2. Aplicați `vm-doc-server-0.16.3-update.tar.gz` peste sursa 0.16.2 sau patch-ul 0.16.2 → 0.16.3.
3. Compilați: `go build -o vm-doc-server ./cmd/vm-doc-server`.
4. Înlocuiți binarul folosit de systemd și reporniți `vm-doc-server`.
5. Reîncărcați aplicația în browser; asset-urile au cache-bust `0.16.3`.

`vm-doc-agent 1.6.1` rămâne compatibil și suficient.
