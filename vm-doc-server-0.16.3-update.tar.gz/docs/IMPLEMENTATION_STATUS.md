# Implementation status 0.13.4

## Implementat

- retenție automată `inventory_snapshots` cu protecția snapshot-urilor curente/documentate;
- Audit paginat și filtrabil, cu detalii before/after pentru operațiile instrumentate;
- model complet Rețea externă → Sistem extern → Conexiune externă;
- culoare/risc/trust/CIDR pentru rețele externe și integrare în UI, rapoarte și DOCX;

- fișă VM compactă pe subsecțiuni navigabile, cu tab-uri sticky și păstrarea secțiunii în URL;
- scor de completare VM bazat pe 11 criterii esențiale, afișat în listă și export;
- paginare configurabilă și memorată per nomenclator;
- pagina Agenți separată în listare și release-uri, cu căutare fără pierderea focusului;
- schemă logică automată a Serviciilor interne, cu VM-uri unice și asocieri multiple în același nod;
- pictograme configurabile pentru nomenclatoare prin `icon_key`;

- surse vCenter cu secrete criptate, sincronizare asincronă și programare zilnică;
- upsert VM și marcaj `missing` când o mașină nu mai este văzută în vCenter;
- corelare automată sau manuală cu agentul;
- listă VM, fișă tehnică structurată, căutare, paginare și export Excel;
- date operaționale independente de inventarul automat;
- catalog de servicii interne independent de încadrarea arhitecturală;
- domeniu și categorie de serviciu salvate pe fiecare asociere VM–serviciu;
- agregarea automată a domeniilor și categoriilor în pagina serviciului;
- roluri tehnice legate global de unul sau mai multe layer-e;
- selecție `domeniu–categorie–serviciu–layer–rol–tip soluție` pe fișa VM;
- asocieri multiple, cu tip de utilizare, prioritate și observații;
- validare server-side a relației categorie–domeniu și layer–rol;
- nomenclatoare grupate în submeniuri;
- registru de persoane și responsabilități multiple pe VM;
- structură separată de backup, pregătită pentru Veeam API;
- inventar agent structurat și restrâns implicit, istoric și audit paginate;
- generare DOCX pe bază de șabloane, previzualizare și istoric pentru VM și Serviciu intern;
- editor rich-text pentru Scop și domeniu / Obiective, cu bullets, numerotare, indentare și stiluri reproduse în DOCX;
- evidențiere PROD / TEST-UAT / DEV în pagina și documentația Serviciului intern;
- legături către fișele VM și pachete ZIP de documentație cu anexe VM versionate;
- modul Rapoarte cu indicatori, donut/pie charts, bar charts, timeline și liste de completitudine;
- pagină Agenți cu căutare, filtrare și paginare;
- listă Servicii cu descriere scurtată și filtre operaționale;
- servicii comune / globale pentru AD, DNS, LDAP, NTP, PKI și alte infrastructuri partajate;
- relații Serviciu → Serviciu comun și excepții VM → Serviciu comun, cu analiză de impact;
- dependențe comune afișate în UI, schema logică și fișele DOCX VM/Serviciu;
- servicii software principale selectabile din inventarul agentului, cu versiuni și propagare în fișele VM/Serviciu;
- etichete contextuale în inventarul agentului pentru stocare, porturi, conturi, cron și servicii, plus uptime umanizat;
- șabloane separate pe tip de obiect (`vm` / `service`) și documente de serviciu numerotate `FSI-*`;
- agregarea automată a tipurilor de soluție în pagina Serviciului intern;
- inventar agent compact în DOCX, cu tabele specializate și randare stabilă Word/LibreOffice;
- migrații, audit, RBAC și OpenAPI actualizate.

## Hotfix 0.13.3

- clientul HTTP către agenți este inițializat atât în `vm-doc-server`, cât și în `vm-doc-collector`;
- refresh-ul statusului auto-update pornit de heartbeat nu mai poate declanșa `nil pointer dereference`;
- `agentclient` tratează defensiv cazul unui client nil și întoarce eroare explicită.


## Schimbări de model în 0.4.0

- serviciul intern nu mai are domeniu sau categorie de serviciu configurate manual;
- `vm_internal_service_assignments` păstrează domeniul și categoria alese pe VM;
- pagina serviciului agregă automat toate încadrările observate;
- același serviciu poate fi reutilizat în mai multe domenii și categorii;
- datele existente sunt migrate din vechea categorie a serviciului.

## Validare necesară în mediul offline final

Arhiva standard nu include `vendor/`. În sursa offline care păstrează dependențele executați:

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

## Limitări

- datele efective din Veeam API nu sunt încă sincronizate;
- serviciile nu au încă responsabilități proprii distincte de responsabilitățile VM-urilor;
- conversia PDF și semnarea digitală nu sunt încă implementate;
- custom attributes generale din vCenter nu sunt încă extrase;
- nu există încă worker automat pentru retenția inventarelor și auditului.

## 0.11.1

- publicare agent/updater prin multipart upload din UI;
- promovare testing → stable și ștergere release;
- SHA-256 și manifest atomic păstrate în backend;
- integrare cu vm-doc-agent 1.3.2 pentru versiuni de servicii.

## 0.11.0

- UI contextual pentru servicii, routes și firewall în pagina VM;
- Rapoarte pe subcategorii;
- Auto-update agent 1.3.0+ prin repository central stable/testing.


## Agent update status 0.13.2

- force update din UI prin `POST /api/v1/agents/{id}/update`;
- canal stable/testing cache-uit central;
- refresh la Test/Colect/Update și heartbeat;
- filtrare și export după canal.


## Hotfix 0.13.4

- statusul `installing` este reconciliat la primul register/heartbeat al binarului nou;
- lista Agenți urmărește pentru scurt timp finalizarea update-ului forțat;
- nu există migrare SQL nouă.
## Docker inventory · 0.14.0

- vm-doc-agent 1.4.0 colectează Docker Engine, containere, Compose projects, images, networks și volumes fără valori de environment/secrete/loguri;
- serverul normalizează inventarul în tabele dedicate;
- container → serviciu este many-to-many și independent de VM → serviciu, pentru hosturi Docker partajate;
- asocierile manuale supraviețuiesc redeploy-urilor atunci când identitatea logică a containerului rămâne stabilă;
- labels `vm-doc.service`, `vm-doc.services`, `vm-doc.component`, `vm-doc.role` pot crea asocieri automate;
- pagina VM are tab Docker; pagina serviciului agregă containerele asociate de pe orice VM gazdă;
- DOCX VM și DOCX serviciu includ datele Docker.


## Docker inventory hotfix · 0.14.1

- acceptă payload Docker atât pentru collector `success`, cât și `partial`;
- statusurile `disabled`, `error` și `timeout` păstrează ultimul inventar bun;
- tabul Docker poate reconstrui automat datele structurate din snapshot-ul curent deja salvat în istoric;
- fără migrare SQL nouă.

## Database inventory · 0.15.0

- vm-doc-agent 1.5.0 detectează engine-uri și instanțe PostgreSQL, MySQL, MariaDB, MongoDB, Oracle, SQL Server, Db2, Redis, Firebird și CockroachDB;
- bazele logice sunt enumerate best-effort pentru PostgreSQL, MySQL/MariaDB și MongoDB numai când accesul local existent permite interogarea fără parole configurate de vm-doc;
- serverul normalizează engine-uri, instanțe și baze logice în tabele dedicate;
- instanță → serviciu și bază logică → serviciu sunt many-to-many, independente de VM → serviciu;
- pagina VM, pagina serviciului și documentele DOCX expun inventarul DB;
- nu sunt colectate parole, connection strings, query-uri sau date din baze.


## Web inventory și documente dinamice · 0.16.0

- vm-doc-agent 1.6.0 detectează Nginx, Apache HTTP Server și HAProxy și colectează metadate secret-safe pentru site-uri, virtual hosts și frontends;
- serverul normalizează serverele și site-urile Web în tabele dedicate și păstrează asocierea site → serviciu independentă de VM → serviciu;
- pagina VM are tab Web, iar pagina serviciului agregă site-urile asociate;
- controalele de asociere Docker/DB/Web au layout responsive cu butoane explicite;
- fișa VM afișează Docker, Baze de date și Web numai dacă există date și folosește numerotare dinamică pentru Inventar agent și subsecțiunile sale;
- fișa serviciului tratează la fel capitolele DB/Docker/Web opționale;
- migrare `031_web_inventory.up.sql`.


## VM inventory / documentation UX hotfix · 0.16.1

- carduri compacte și contrast dark-mode pentru Docker/DB/Web;
- listarea VM agregă serviciile directe și serviciile asociate resurselor Docker/DB/Web și le poate filtra;
- procent de completare dinamic: resursele Docker/DB/Web sunt criterii doar când există;
- Power ON/OFF, OS compact și versiune agent în tabel.

## UI & document rendering refinements · 0.16.2

- VM list keeps agent version beside Online/Offline, aggregates services and keeps dynamic documentation completion;
- all single-value selects use a searchable combobox wrapper while preserving native select values/events;
- vCenter synchronization history is server-side paginated, default 10/page;
- Docker/DB/Web tabs have spacing after the VM navigation; external connection blocks and VM document preview received dedicated layout/padding;
- VM DOCX port inventory now reads nested `processes[]` to show process/PID/executable;
- firewall document rendering is backend-agnostic (nftables, iptables/ip6tables, firewalld, UFW, SuSEfirewall2) with legacy UFW fallback;
- local account rendering honors `system_account` and includes UID 1000 when it is a normal user;
- no SQL migration and no agent bump required; vm-doc-agent 1.6.1 remains compatible.

## UI / DOCX hotfix · 0.16.3

- dropdown-urile searchable folosesc un portal deasupra panourilor/tabelelor, cu repoziționare la scroll/resize, evitând clipping-ul de `overflow`/z-index;
- detaliile Docker au padding suplimentar;
- subsecțiunile Inventar agent sunt numerotate continuu și nu mai includ secțiunea tehnică goală `Schema inventar`;
- Heading2 are indent explicit în DOCX, astfel încât subsecțiunile precum 5.1 sunt vizual sub capitolul părinte;
- Porturi ascultate este deduplicat la un rând per port/protocol, păstrând cele mai complete date despre proces/executabil;
- fără migrare SQL; agentul 1.6.1 este suficient.
