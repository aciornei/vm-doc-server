package documents

import (
	"fmt"
	"sort"
	"strconv"
	"strings"

	"vm-doc-server/internal/domain"
)

// RenderServiceMarkdown builds a Markdown representation of the internal-service
// documentation intended for manual import/paste into wiki systems such as Outline.
// It mirrors the logical structure of the DOCX as closely as practical while
// keeping the output portable Markdown.
func RenderServiceMarkdown(data ServiceGenerationData) []byte {
	service := data.Service
	var out strings.Builder

	out.WriteString("# ")
	out.WriteString(markdownInline(firstNonEmpty(service.Name, "Serviciu intern")))
	out.WriteString("\n\n")
	out.WriteString("**Număr electronic document:** ")
	out.WriteString(markdownInline(data.DocumentNumber))
	out.WriteString("  \n**Data referință:** ")
	out.WriteString(markdownInline(formatTime(data.GeneratedAt)))
	if data.IncludeGeneratedBy {
		out.WriteString("  \n**Generat de:** ")
		out.WriteString(markdownInline(firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username, "sistem")))
	}
	out.WriteString("\n\n")

	markdownHeading(&out, 2, "1. Identificare serviciu")
	markdownKeyValueTable(&out, serviceIdentityRows(data))

	markdownHeading(&out, 2, "2. Descriere, scop, domeniu și obiective")
	markdownHeading(&out, 3, "Descriere")
	out.WriteString(markdownRichText(service.DescriptionRichText, service.Description))
	out.WriteString("\n\n")
	markdownHeading(&out, 3, "Scop și domeniu")
	out.WriteString(markdownRichText(service.PurposeRichText, service.Purpose))
	out.WriteString("\n\n")
	markdownHeading(&out, 3, "Obiective")
	out.WriteString(markdownRichText(service.ObjectivesRichText, service.Objectives))
	out.WriteString("\n\n")
	if len(data.Attachments) > 0 {
		markdownHeading(&out, 3, "Documentație suplimentară a serviciului")
		for _, attachment := range data.Attachments {
			markdownHeading(&out, 4, firstNonEmpty(attachment.Title, attachment.FileName, "Document suplimentar"))
			text := ""
			if len(attachment.Content) > 0 {
				if formatted, err := ExtractSupplementalDOCXMarkdown(attachment.Content); err == nil {
					text = formatted
				}
			}
			if strings.TrimSpace(text) == "" {
				text = markdownPlainParagraphs(attachment.ExtractedText)
			}
			if strings.TrimSpace(text) == "" {
				out.WriteString("_Conținut textual indisponibil._\n\n")
				continue
			}
			out.WriteString(text)
			out.WriteString("\n\n")
		}
	}

	markdownHeading(&out, 2, "3. Încadrare pe medii")
	markdownEnvironmentGroups(&out, service.VMs)

	markdownHeading(&out, 2, "4. Schemă logică a serviciului")
	if len(service.VMs) == 0 {
		out.WriteString("_Serviciul nu are VM-uri asociate._\n\n")
	} else {
		rows := serviceVMPreviewRows(service.VMs)
		markdownRowsTable(&out, "VM", "Mediu / rol tehnic", rows)
	}

	markdownHeading(&out, 2, "5. Dependențe și servicii comune")
	dependencies := serviceAllDependencies(service)
	if len(dependencies) == 0 {
		out.WriteString("_Nu sunt declarate dependențe comune sau globale._\n\n")
	} else {
		out.WriteString("| Serviciu | Tip dependență | Caracter | Detalii |\n|---|---|---|---|\n")
		for _, item := range dependencies {
			character := "Comun"
			if item.Global {
				character = "Global"
			}
			fmt.Fprintf(&out, "| %s | %s | %s | %s |\n", markdownTableCell(item.TargetServiceName), markdownTableCell(item.DependencyType), markdownTableCell(character), markdownTableCell(item.Notes))
		}
		out.WriteString("\n")
	}
	if len(data.ExternalConnections) > 0 {
		markdownHeading(&out, 3, "5.1 Conexiuni către sisteme externe")
		markdownRowsTable(&out, "Sistem extern", "Detalii", externalConnectionPreviewRows(data.ExternalConnections))
	}
	if service.IsCommon {
		rows := make([]PreviewRow, 0, len(service.Dependents)+len(service.DirectVMDependents)+1)
		if service.ImplicitGlobal {
			rows = append(rows, PreviewRow{Label: "Aplicabilitate globală", Value: fmt.Sprintf("%d servicii active pot fi afectate", service.DependentServiceCount)})
		}
		for _, item := range service.Dependents {
			rows = append(rows, PreviewRow{Label: item.SourceServiceName, Value: strings.TrimSpace(strings.Join(nonEmpty(item.DependencyType, item.Notes), " · "))})
		}
		for _, item := range service.DirectVMDependents {
			rows = append(rows, PreviewRow{Label: "VM direct · " + item.VMName, Value: strings.TrimSpace(strings.Join(nonEmpty(item.DependencyType, item.Notes), " · "))})
		}
		if len(rows) > 0 {
			markdownHeading(&out, 3, "5.2 Impact asupra serviciilor dependente")
			markdownRowsTable(&out, "Obiect dependent", "Detalii", rows)
		}
	}

	markdownHeading(&out, 2, "6. Domenii și categorii de serviciu")
	if len(service.Classifications) == 0 {
		out.WriteString("_Nu există clasificări observate._\n\n")
	} else {
		out.WriteString("| Domeniu | Categorie de serviciu | VM-uri | Asocieri |\n|---|---|---:|---:|\n")
		for _, item := range service.Classifications {
			fmt.Fprintf(&out, "| %s | %s | %d | %d |\n", markdownTableCell(item.ArchitecturalDomain), markdownTableCell(item.ITILCategory), item.VMCount, item.AssignmentCount)
		}
		out.WriteString("\n")
	}

	markdownHeading(&out, 2, "7. Tipuri de soluție")
	if len(service.SolutionTypes) == 0 {
		out.WriteString("_Nu există tipuri de soluție definite._\n\n")
	} else {
		out.WriteString("| Tip soluție | VM-uri | Asocieri |\n|---|---:|---:|\n")
		for _, item := range service.SolutionTypes {
			fmt.Fprintf(&out, "| %s | %d | %d |\n", markdownTableCell(item.SolutionType), item.VMCount, item.AssignmentCount)
		}
		out.WriteString("\n")
	}

	markdownHeading(&out, 2, "8. Arhitectură tehnică observată")
	if len(service.RoleMappings) == 0 {
		out.WriteString("_Nu există layer-e și roluri tehnice observate._\n\n")
	} else {
		out.WriteString("| Layer | Rol tehnic | VM-uri |\n|---|---|---:|\n")
		for _, item := range service.RoleMappings {
			fmt.Fprintf(&out, "| %s | %s | %d |\n", markdownTableCell(item.LayerName), markdownTableCell(item.TechnicalRole), item.VMCount)
		}
		out.WriteString("\n")
	}

	markdownHeading(&out, 2, "9. Componente software principale")
	if len(data.PrimaryComponents) == 0 {
		out.WriteString("_Nu sunt marcate componente software principale._\n\n")
	} else {
		out.WriteString("| VM | Mediu | Software / serviciu | Versiune | Pachet | Stare |\n|---|---|---|---|---|---|\n")
		for _, item := range data.PrimaryComponents {
			software := firstNonEmpty(item.SoftwareName, strings.TrimSuffix(item.ServiceName, ".service"), item.ServiceName)
			softwareService := software
			if strings.TrimSpace(item.ServiceName) != "" {
				softwareService = strings.TrimSpace(software + " · " + item.ServiceName)
			}
			state := strings.TrimSpace(strings.Join(nonEmpty(item.ActiveState, item.EnabledState), " · "))
			if !item.Detected {
				state = "Nedetectat în inventarul curent"
			}
			pkg := strings.TrimSpace(strings.Join(nonEmpty(item.PackageName, item.PackageVersion), " · "))
			fmt.Fprintf(&out, "| %s | %s | %s | %s | %s | %s |\n", markdownTableCell(item.VMName), markdownTableCell(environmentCode(item.Environment)), markdownTableCell(softwareService), markdownTableCell(firstNonEmpty(shortVersion(item.Version), "—")), markdownTableCell(pkg), markdownTableCell(state))
		}
		out.WriteString("\n")
	}

	sectionNumber := 10
	if len(data.DatabaseResources) > 0 {
		markdownHeading(&out, 2, fmt.Sprintf("%d. Baze de date", sectionNumber))
		rows := make([]PreviewRow, 0, len(data.DatabaseResources))
		for _, item := range data.DatabaseResources {
			label := firstNonEmpty(item.VMHostname, item.VMName) + " · " + firstNonEmpty(item.Product, item.Engine) + " / " + firstNonEmpty(item.InstanceName, "implicit")
			if item.ResourceType == "database" && item.DatabaseName != "" {
				label += " / " + item.DatabaseName
			}
			jobSummary := ""
			if len(item.ScheduledJobs) > 0 {
				jobSummary = fmt.Sprintf("%d joburi DB", len(item.ScheduledJobs))
			}
			rows = append(rows, PreviewRow{Label: label, Value: strings.TrimSpace(strings.Join(nonEmpty(shortVersion(item.Version), item.Status, databaseEndpointSummary(item.Endpoints), jobSummary, databaseAssignmentForService(item.ServiceAssignments, service.ID)), " · "))})
		}
		markdownRowsTable(&out, "Resursă", "Detalii", rows)
		sectionNumber++
	}
	if len(data.DockerContainers) > 0 {
		markdownHeading(&out, 2, fmt.Sprintf("%d. Componente Docker", sectionNumber))
		rows := make([]PreviewRow, 0, len(data.DockerContainers))
		for _, item := range data.DockerContainers {
			label := firstNonEmpty(item.VMHostname, item.VMName) + " · " + item.Name
			value := strings.TrimSpace(strings.Join(nonEmpty(item.Image, item.ComposeProject, item.State, dockerAssignmentForService(item.ServiceAssignments, service.ID)), " · "))
			rows = append(rows, PreviewRow{Label: label, Value: value})
		}
		markdownRowsTable(&out, "Container", "Detalii", rows)
		sectionNumber++
	}
	if len(data.WebSites) > 0 {
		markdownHeading(&out, 2, fmt.Sprintf("%d. Site-uri web și frontends", sectionNumber))
		rows := make([]PreviewRow, 0, len(data.WebSites))
		for _, item := range data.WebSites {
			label := firstNonEmpty(item.VMHostname, item.VMName) + " · " + firstNonEmpty(item.Name, "site")
			value := strings.TrimSpace(strings.Join(nonEmpty(firstNonEmpty(item.Product, item.Engine), strings.Join(item.ServerNames, ", "), webBindingSummary(item.Bindings), webTargetSummary(item), webAssignmentForService(item.ServiceAssignments, service.ID)), " · "))
			rows = append(rows, PreviewRow{Label: label, Value: value})
		}
		markdownRowsTable(&out, "Site / frontend", "Detalii", rows)
		sectionNumber++
	}

	markdownHeading(&out, 2, fmt.Sprintf("%d. Backup și restaurare", sectionNumber))
	if len(data.Backups) == 0 {
		out.WriteString("_Nu există date de backup._\n\n")
	} else {
		markdownRowsTable(&out, "VM", "Protecție / politică", serviceBackupPreviewRows(data.Backups))
	}
	sectionNumber++

	markdownHeading(&out, 2, fmt.Sprintf("%d. Monitorizare", sectionNumber))
	if len(data.Monitorings) == 0 {
		out.WriteString("_Nu există date de monitorizare._\n\n")
	} else {
		markdownRowsTable(&out, "VM", "Monitorizare", serviceMonitoringPreviewRows(data.Monitorings))
	}
	sectionNumber++

	markdownHeading(&out, 2, fmt.Sprintf("%d. VM-uri asociate", sectionNumber))
	if len(service.VMs) == 0 {
		out.WriteString("_Nu există VM-uri asociate._\n\n")
	} else {
		markdownRowsTable(&out, "VM", "Mediu / rol tehnic", serviceVMPreviewRows(service.VMs))
	}

	if data.EmbedVMAnnexes && len(data.VMAnnexData) > 0 {
		sectionNumber++
		markdownHeading(&out, 2, fmt.Sprintf("%d. Anexe — fișe tehnice VM", sectionNumber))
		for index, annex := range data.VMAnnexData {
			markdownHeading(&out, 3, fmt.Sprintf("A%d — %s", index+1, firstNonEmpty(annex.VM.Name, annex.VM.GuestHostname, "VM")))
			for _, section := range previewSections(annex) {
				markdownHeading(&out, 4, section.Title)
				markdownKeyValueTable(&out, section.Rows)
			}
			if annex.InventoryDocument != nil && len(annex.InventoryDocument.Sections) > 0 {
				markdownHeading(&out, 4, "Inventar agent — detaliu")
				for _, invSection := range annex.InventoryDocument.Sections {
					markdownHeading(&out, 5, invSection.Title)
					rows := make([]PreviewRow, 0)
					for _, item := range flattenValue(invSection.Data, 80) {
						rows = append(rows, PreviewRow{Label: item.Label, Value: item.Value})
					}
					if len(rows) > 0 {
						markdownKeyValueTable(&out, rows)
					} else {
						out.WriteString("_Nu există date._\n\n")
					}
				}
			}
		}
	} else if len(data.VMDocuments) > 0 {
		sectionNumber++
		markdownHeading(&out, 2, fmt.Sprintf("%d. Anexe — fișe tehnice VM", sectionNumber))
		for index, doc := range data.VMDocuments {
			label := fmt.Sprintf("A%d. %s", index+1, firstNonEmpty(doc.VMName, "VM"))
			out.WriteString("- **")
			out.WriteString(markdownInline(label))
			out.WriteString("** — ")
			out.WriteString(markdownInline(firstNonEmpty(doc.DocumentNumber, doc.FileName, "fișă VM")))
			if env := environmentCode(doc.Environment); env != "" {
				out.WriteString(" · ")
				out.WriteString(markdownInline(env))
			}
			if strings.TrimSpace(doc.DownloadURL) != "" {
				out.WriteString(" · [Deschide fișa VM](")
				out.WriteString(strings.TrimSpace(doc.DownloadURL))
				out.WriteString(")")
			}
			out.WriteString("\n")
		}
		out.WriteString("\n")
	}

	return []byte(strings.TrimSpace(out.String()) + "\n")
}

func markdownHeading(out *strings.Builder, level int, title string) {
	if level < 1 {
		level = 1
	}
	if level > 6 {
		level = 6
	}
	out.WriteString(strings.Repeat("#", level))
	out.WriteByte(' ')
	out.WriteString(markdownInline(title))
	out.WriteString("\n\n")
}

func markdownKeyValueTable(out *strings.Builder, rows []PreviewRow) {
	out.WriteString("| Câmp | Valoare |\n|---|---|\n")
	for _, row := range rows {
		fmt.Fprintf(out, "| %s | %s |\n", markdownTableCell(row.Label), markdownTableCell(row.Value))
	}
	out.WriteString("\n")
}

func markdownRowsTable(out *strings.Builder, leftHeader, rightHeader string, rows []PreviewRow) {
	if len(rows) == 0 {
		out.WriteString("_Nu există date._\n\n")
		return
	}
	fmt.Fprintf(out, "| %s | %s |\n|---|---|\n", markdownTableCell(leftHeader), markdownTableCell(rightHeader))
	for _, row := range rows {
		fmt.Fprintf(out, "| %s | %s |\n", markdownTableCell(row.Label), markdownTableCell(row.Value))
	}
	out.WriteString("\n")
}

func markdownEnvironmentGroups(out *strings.Builder, assignments []domain.InternalServiceVM) {
	byEnv := make(map[string]map[int64]domain.InternalServiceVM)
	for _, item := range assignments {
		env := environmentCode(item.Environment)
		if env == "" {
			env = "NESPECIFICAT"
		}
		if byEnv[env] == nil {
			byEnv[env] = make(map[int64]domain.InternalServiceVM)
		}
		if _, exists := byEnv[env][item.ID]; !exists {
			byEnv[env][item.ID] = item
		}
	}
	if len(byEnv) == 0 {
		out.WriteString("_Nu există VM-uri asociate._\n\n")
		return
	}
	keys := make([]string, 0, len(byEnv))
	for key := range byEnv {
		keys = append(keys, key)
	}
	sort.SliceStable(keys, func(i, j int) bool {
		ri, rj := serviceEnvironmentRank(keys[i]), serviceEnvironmentRank(keys[j])
		if ri != rj {
			return ri < rj
		}
		return keys[i] < keys[j]
	})
	for _, env := range keys {
		markdownHeading(out, 3, env)
		ids := make([]int64, 0, len(byEnv[env]))
		for id := range byEnv[env] {
			ids = append(ids, id)
		}
		sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })
		for _, id := range ids {
			item := byEnv[env][id]
			name := firstNonEmpty(item.GuestHostname, item.Name, "VM")
			out.WriteString("- **")
			out.WriteString(markdownInline(name))
			out.WriteString("**")
			if item.PrimaryIP != "" {
				out.WriteString(" — ")
				out.WriteString(markdownInline(item.PrimaryIP))
			}
			out.WriteString("\n")
		}
		out.WriteString("\n")
	}
}

func markdownRichText(doc *domain.RichTextDocument, fallback string) string {
	if doc == nil || len(doc.Blocks) == 0 {
		return markdownPlainParagraphs(fallback)
	}
	var out strings.Builder
	for index, block := range doc.Blocks {
		if index > 0 {
			out.WriteByte('\n')
		}
		level := block.Level
		if level < 0 {
			level = 0
		}
		prefix := ""
		switch block.Type {
		case "bullet":
			prefix = strings.Repeat("  ", level) + "- "
		case "number":
			prefix = strings.Repeat("  ", level) + "1. "
		}
		out.WriteString(prefix)
		for _, run := range block.Runs {
			out.WriteString(markdownStyledRun(run))
		}
		if block.Type == "paragraph" && len(block.Runs) == 0 {
			out.WriteString("  ")
		}
	}
	return strings.TrimSpace(out.String())
}

func markdownStyledRun(run domain.RichTextRun) string {
	text := run.Text
	leadingLen := len(text) - len(strings.TrimLeft(text, " \t"))
	trailingLen := len(text) - len(strings.TrimRight(text, " \t"))
	if leadingLen+trailingLen > len(text) {
		trailingLen = 0
	}
	leading := text[:leadingLen]
	coreEnd := len(text) - trailingLen
	core := text[leadingLen:coreEnd]
	trailing := text[coreEnd:]
	escaped := markdownInline(core)
	if escaped != "" {
		if run.Bold && run.Italic {
			escaped = "***" + escaped + "***"
		} else if run.Bold {
			escaped = "**" + escaped + "**"
		} else if run.Italic {
			escaped = "*" + escaped + "*"
		}
		if run.Underline {
			escaped = "<u>" + escaped + "</u>"
		}
	}
	return leading + escaped + trailing
}

func markdownPlainParagraphs(value string) string {
	value = strings.TrimSpace(strings.ReplaceAll(strings.ReplaceAll(value, "\r\n", "\n"), "\r", "\n"))
	if value == "" {
		return "_Necompletat._"
	}
	lines := strings.Split(value, "\n")
	for i, line := range lines {
		lines[i] = markdownInline(line)
	}
	return strings.Join(lines, "\n")
}

func markdownInline(value string) string {
	value = strings.ReplaceAll(value, "\\", "\\\\")
	value = strings.ReplaceAll(value, "`", "\\`")
	value = strings.ReplaceAll(value, "*", "\\*")
	value = strings.ReplaceAll(value, "_", "\\_")
	value = strings.ReplaceAll(value, "[", "\\[")
	value = strings.ReplaceAll(value, "]", "\\]")
	value = strings.ReplaceAll(value, "<", "&lt;")
	value = strings.ReplaceAll(value, ">", "&gt;")
	return value
}

func markdownTableCell(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "—"
	}
	value = strings.ReplaceAll(value, "|", "\\|")
	value = strings.ReplaceAll(value, "\r\n", "<br>")
	value = strings.ReplaceAll(value, "\r", "<br>")
	value = strings.ReplaceAll(value, "\n", "<br>")
	return value
}

func serviceMarkdownFileName(data ServiceGenerationData) string {
	name := firstNonEmpty(data.Service.ServiceCode, data.Service.Name, "service")
	base := strings.TrimSuffix(safeDocumentFileName(name, firstNonEmpty(data.DocumentNumber, strconv.FormatInt(data.Service.ID, 10)), "service"), ".docx")
	return base + ".md"
}

// ServiceMarkdownFileName returns a safe download name for the Markdown export.
func ServiceMarkdownFileName(data ServiceGenerationData) string { return serviceMarkdownFileName(data) }
