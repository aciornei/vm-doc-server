package documents

import (
	"regexp"
	"strings"
)

var shortVersionPattern = regexp.MustCompile(`(?i)(?:^|[^0-9])v?([0-9]+(?:\.[0-9]+){1,3})`)

func shortVersion(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return ""
	}
	if m := shortVersionPattern.FindStringSubmatch(value); len(m) > 1 {
		return m[1]
	}
	if i := strings.Index(value, " ("); i > 0 {
		value = value[:i]
	}
	if i := strings.Index(value, ","); i > 0 {
		value = value[:i]
	}
	return strings.TrimSpace(value)
}
