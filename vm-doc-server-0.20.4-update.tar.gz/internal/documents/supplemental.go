package documents

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"errors"
	"io"
	"strings"
)

// ExtractSupplementalDOCXText extracts human-readable text from a DOCX uploaded
// as supplemental service documentation. Paragraph and table row boundaries are
// retained so the generated service document can render the content in chapter 2.
func ExtractSupplementalDOCXText(content []byte) (string, error) {
	if len(content) == 0 {
		return "", errors.New("DOCX file is empty")
	}
	reader, err := zip.NewReader(bytes.NewReader(content), int64(len(content)))
	if err != nil {
		return "", errors.New("invalid DOCX archive")
	}
	var document []byte
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		rc, err := file.Open()
		if err != nil {
			return "", err
		}
		document, err = io.ReadAll(io.LimitReader(rc, 16<<20))
		rc.Close()
		if err != nil {
			return "", err
		}
		break
	}
	if len(document) == 0 {
		return "", errors.New("DOCX does not contain word/document.xml")
	}

	decoder := xml.NewDecoder(bytes.NewReader(document))
	var out strings.Builder
	var inText bool
	for {
		token, err := decoder.Token()
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			return "", errors.New("invalid DOCX document.xml")
		}
		switch value := token.(type) {
		case xml.StartElement:
			if value.Name.Local == "t" {
				inText = true
			}
		case xml.CharData:
			if inText {
				out.WriteString(string(value))
			}
		case xml.EndElement:
			switch value.Name.Local {
			case "t":
				inText = false
			case "tab":
				out.WriteByte('\t')
			case "br":
				out.WriteByte('\n')
			case "tc":
				if out.Len() > 0 && !strings.HasSuffix(out.String(), "\t") && !strings.HasSuffix(out.String(), "\n") {
					out.WriteByte('\t')
				}
			case "p", "tr":
				if out.Len() > 0 && !strings.HasSuffix(out.String(), "\n") {
					out.WriteByte('\n')
				}
			}
		}
	}

	lines := strings.Split(strings.ReplaceAll(out.String(), "\r\n", "\n"), "\n")
	clean := make([]string, 0, len(lines))
	blank := false
	for _, line := range lines {
		line = strings.TrimSpace(strings.TrimRight(line, "\t"))
		if line == "" {
			if len(clean) > 0 && !blank {
				clean = append(clean, "")
				blank = true
			}
			continue
		}
		clean = append(clean, line)
		blank = false
	}
	for len(clean) > 0 && clean[len(clean)-1] == "" {
		clean = clean[:len(clean)-1]
	}
	text := strings.TrimSpace(strings.Join(clean, "\n"))
	if text == "" {
		return "", errors.New("DOCX does not contain readable text")
	}
	return text, nil
}

// ExtractSupplementalDOCXMarkdown converts the useful Word structure of a supplemental
// DOCX to portable Markdown. It preserves paragraph boundaries, common headings,
// bold/italic runs and tables. Complex page-layout features remain specific to Word.
func ExtractSupplementalDOCXMarkdown(content []byte) (string, error) {
	if len(content) == 0 {
		return "", errors.New("DOCX file is empty")
	}
	reader, err := zip.NewReader(bytes.NewReader(content), int64(len(content)))
	if err != nil {
		return "", errors.New("invalid DOCX archive")
	}
	var document []byte
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		rc, err := file.Open()
		if err != nil {
			return "", err
		}
		document, err = io.ReadAll(io.LimitReader(rc, 16<<20))
		rc.Close()
		if err != nil {
			return "", err
		}
		break
	}
	if len(document) == 0 {
		return "", errors.New("DOCX does not contain word/document.xml")
	}
	dec := xml.NewDecoder(bytes.NewReader(document))
	var out strings.Builder
	var paragraph strings.Builder
	var cell strings.Builder
	var row []string
	inText, inCell, bold, italic, numbered := false, false, false, false, false
	style := ""
	flushParagraph := func() {
		text := strings.TrimSpace(paragraph.String())
		paragraph.Reset()
		if text == "" {
			return
		}
		prefix := ""
		low := strings.ToLower(style)
		if strings.HasPrefix(low, "heading") || strings.HasPrefix(low, "titlu") {
			level := 3
			for _, r := range style {
				if r >= '1' && r <= '6' {
					level = int(r-'0') + 2
					if level > 6 {
						level = 6
					}
					break
				}
			}
			prefix = strings.Repeat("#", level) + " "
		} else if numbered {
			prefix = "- "
		}
		if inCell {
			if cell.Len() > 0 {
				cell.WriteString("<br>")
			}
			cell.WriteString(prefix + text)
		} else {
			out.WriteString(prefix + text + "\n\n")
		}
		style = ""
		numbered = false
	}
	for {
		tok, err := dec.Token()
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			return "", errors.New("invalid DOCX document.xml")
		}
		switch v := tok.(type) {
		case xml.StartElement:
			switch v.Name.Local {
			case "tr":
				row = nil
			case "tc":
				inCell = true
				cell.Reset()
			case "t":
				inText = true
			case "b":
				bold = true
			case "i":
				italic = true
			case "numPr":
				numbered = true
			case "pStyle":
				for _, a := range v.Attr {
					if a.Name.Local == "val" {
						style = a.Value
					}
				}
			case "tab":
				paragraph.WriteString("    ")
			case "br":
				paragraph.WriteString("  \n")
			}
		case xml.CharData:
			if inText {
				t := string(v)
				if bold && italic {
					paragraph.WriteString("***" + t + "***")
				} else if bold {
					paragraph.WriteString("**" + t + "**")
				} else if italic {
					paragraph.WriteString("*" + t + "*")
				} else {
					paragraph.WriteString(t)
				}
			}
		case xml.EndElement:
			switch v.Name.Local {
			case "t":
				inText = false
			case "r":
				bold = false
				italic = false
			case "p":
				flushParagraph()
			case "tc":
				flushParagraph()
				row = append(row, strings.TrimSpace(cell.String()))
				inCell = false
			case "tr":
				if len(row) > 0 {
					out.WriteString("| " + strings.Join(row, " | ") + " |\n")
				}
			case "tbl":
				out.WriteString("\n")
			}
		}
	}
	result := strings.TrimSpace(out.String())
	if result == "" {
		return "", errors.New("DOCX does not contain readable text")
	}
	// Convert simple consecutive pipe rows into proper Markdown tables by inserting a separator after the first row.
	lines := strings.Split(result, "\n")
	rebuilt := make([]string, 0, len(lines)+8)
	inPipe := false
	for _, line := range lines {
		isPipe := strings.HasPrefix(strings.TrimSpace(line), "|") && strings.HasSuffix(strings.TrimSpace(line), "|")
		if isPipe && !inPipe {
			rebuilt = append(rebuilt, line)
			cols := strings.Count(line, "|") - 1
			sep := make([]string, cols)
			for i := range sep {
				sep[i] = "---"
			}
			rebuilt = append(rebuilt, "| "+strings.Join(sep, " | ")+" |")
			inPipe = true
			continue
		}
		if !isPipe {
			inPipe = false
		}
		rebuilt = append(rebuilt, line)
	}
	return strings.TrimSpace(strings.Join(rebuilt, "\n")), nil
}
