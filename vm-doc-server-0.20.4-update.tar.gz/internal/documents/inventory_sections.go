package documents

import (
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"

	"vm-doc-server/internal/inventory"
)

const inventoryTableWidth = 9500

func compactInventoryXML(view *inventory.DocumentView, prefix string) string {
	if view == nil {
		return ""
	}
	if strings.TrimSpace(prefix) == "" {
		prefix = "8"
	}
	sections := make(map[string]any, len(view.Sections))
	for _, section := range view.Sections {
		key := normalizeInventoryKey(section.Key)
		if key != "" {
			sections[key] = section.Data
		}
	}

	var out strings.Builder
	sectionNumber := 1
	addSection := func(title string, body string) {
		out.WriteString(heading(fmt.Sprintf("%s.%d %s", prefix, sectionNumber, title), 2))
		out.WriteString(body)
		sectionNumber++
	}

	// Schema/agent metadata is already summarized at the start of the Inventar
	// agent chapter. Do not emit an empty technical subsection and keep the
	// numbering continuous when intentionally omitted sections (for example
	// Proxy) are not part of the generated operational document.
	addSection("Sistem și hardware", renderMergedCompactKeyValues(sections, []string{"identity", "host", "system"}, map[string]bool{
		"uptimeseconds": true,
	}, 36))
	addSection("Sistem de operare", renderMergedCompactKeyValues(sections, []string{"os", "operatingsystem"}, nil, 24))
	addSection("Stocare", renderStorageTable(sections))
	addSection("Rețea", renderNetworkTable(sectionValue(sections, "network")))
	addSection("Servicii active", renderServicesTable(sectionValue(sections, "services")))
	addSection("Porturi ascultate", renderPortsTable(sectionValue(sections, "listeningports")))
	addSection("Firewall", renderFirewallTable(sectionValue(sections, "firewall")))
	addSection("Conturi importante", renderAccountsTable(sectionValue(sections, "accounts")))
	addSection("Integrare SSSD", renderSSSDTable(sectionValue(sections, "sssd")))
	addSection("Integrări operaționale", renderIntegrationsTable(sectionValue(sections, "integrations"), sections))
	addSection("Sarcini programate", renderCronTable(sectionValue(sections, "cron")))
	addSection("Sincronizare timp", renderNTPTable(sectionValue(sections, "ntp")))
	return out.String()
}

func sectionValue(sections map[string]any, keys ...string) any {
	for _, key := range keys {
		if value, ok := sections[normalizeInventoryKey(key)]; ok {
			return value
		}
	}
	return nil
}

func renderCompactKeyValues(value any, excluded map[string]bool, limit int) string {
	if value == nil {
		return paragraph("—", "IntenseQuote")
	}
	rows := flattenValue(value, limit)
	filtered := make([]PreviewRow, 0, len(rows))
	seen := make(map[string]bool)
	for _, row := range rows {
		key := normalizeInventoryKey(row.Label)
		if excluded != nil && excluded[key] {
			continue
		}
		if strings.Contains(key, "uptimeseconds") {
			continue
		}
		row.Label = compactLabel(row.Label)
		row.Value = humanizeValueForLabel(row.Label, row.Value)
		dedupe := normalizeInventoryKey(row.Label) + "\x00" + strings.TrimSpace(row.Value)
		if seen[dedupe] {
			continue
		}
		seen[dedupe] = true
		filtered = append(filtered, row)
	}
	if len(filtered) == 0 {
		return paragraph("—", "IntenseQuote")
	}
	return keyValueTable(filtered)
}

func renderMergedCompactKeyValues(sections map[string]any, keys []string, excluded map[string]bool, limit int) string {
	rows := make([]PreviewRow, 0)
	seen := make(map[string]bool)
	for _, key := range keys {
		value := sectionValue(sections, key)
		if value == nil {
			continue
		}
		for _, row := range flattenValue(value, limit) {
			normalized := normalizeInventoryKey(row.Label)
			if excluded != nil && excluded[normalized] {
				continue
			}
			if strings.Contains(normalized, "uptimeseconds") {
				continue
			}
			row.Label = compactLabel(row.Label)
			row.Value = humanizeValueForLabel(row.Label, row.Value)
			dedupe := normalizeInventoryKey(row.Label) + "\x00" + strings.TrimSpace(row.Value)
			if seen[dedupe] {
				continue
			}
			seen[dedupe] = true
			rows = append(rows, row)
			if len(rows) >= limit {
				break
			}
		}
	}
	if len(rows) == 0 {
		return paragraph("—", "IntenseQuote")
	}
	return keyValueTable(rows)
}

func renderStorageTable(sections map[string]any) string {
	values := []any{sectionValue(sections, "storage"), sectionValue(sections, "disks"), sectionValue(sections, "mounts")}
	type storageRow struct{ partition, filesystem, capacity string }
	rows := make([]storageRow, 0)
	seen := make(map[string]bool)
	for _, value := range values {
		walkRecordMaps(value, "", func(record map[string]any, hint string) {
			partition := firstMapText(record, "partition", "mount_point", "mountpoint", "mount", "device", "path", "name", "volume")
			if partition == "" {
				partition = hint
			}
			filesystem := firstMapText(record, "filesystem", "file_system", "fs_type", "fstype", "filesystem_type", "type")
			capacityValue, ok := firstMapValue(record, "capacity_bytes", "size_bytes", "total_bytes", "bytes_total", "capacity", "size", "total")
			capacity := ""
			if ok {
				capacity = humanCapacity(capacityValue)
			}
			if strings.TrimSpace(partition) == "" || (filesystem == "" && capacity == "") {
				return
			}
			key := strings.ToLower(partition + "\x00" + filesystem + "\x00" + capacity)
			if seen[key] {
				return
			}
			seen[key] = true
			rows = append(rows, storageRow{partition, filesystem, capacity})
		})
	}
	sort.SliceStable(rows, func(i, j int) bool { return strings.ToLower(rows[i].partition) < strings.ToLower(rows[j].partition) })
	tableRows := make([][]string, 0, len(rows))
	for _, row := range rows {
		tableRows = append(tableRows, []string{row.partition, row.filesystem, row.capacity})
	}
	if len(tableRows) == 0 {
		return paragraph("—", "IntenseQuote")
	}
	return tableWithWidths([]string{"Partiție", "Filesystem", "Capacitate"}, tableRows, []int{3300, 2800, 2900})
}

func renderNetworkTable(value any) string {
	type networkRow struct{ ip, maskGateway, dns, iface string }
	rows := make([]networkRow, 0)
	seen := make(map[string]bool)
	rootDNS := recursiveTextList(value, "dns", "dns_servers", "nameservers", "name_servers")
	rootGateway := recursiveFirstText(value, "gateway", "default_gateway", "gateway4", "gateway6")
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		iface := firstMapText(record, "interface_name", "interface", "ifname", "device", "name")
		if iface == "" && !genericHint(hint) {
			iface = hint
		}
		gateway := firstMapText(record, "gateway", "default_gateway", "gateway4", "gateway6")
		if gateway == "" {
			gateway = rootGateway
		}
		dns := strings.Join(uniqueStrings(append(textListFromMap(record, "dns", "dns_servers", "nameservers", "name_servers"), rootDNS...)), ", ")
		addresses := addressValues(record)
		if len(addresses) == 0 {
			ip := firstMapText(record, "primary_ip", "ip", "ip_address", "address")
			if ip != "" {
				addresses = append(addresses, networkAddress{IP: ip, Mask: firstMapText(record, "mask", "netmask", "prefix", "prefix_length", "cidr")})
			}
		}
		for _, address := range addresses {
			if address.IP == "" || strings.Contains(address.IP, ":") && strings.HasPrefix(strings.ToLower(address.IP), "fe80:") {
				continue
			}
			parts := make([]string, 0, 2)
			if address.Mask != "" {
				parts = append(parts, "mask "+address.Mask)
			}
			if gateway != "" {
				parts = append(parts, "gateway "+gateway)
			}
			row := networkRow{address.IP, strings.Join(parts, " · "), dns, iface}
			key := strings.ToLower(row.ip + "\x00" + row.maskGateway + "\x00" + row.iface)
			if seen[key] {
				continue
			}
			seen[key] = true
			rows = append(rows, row)
		}
	})
	if len(rows) == 0 {
		ip := recursiveFirstText(value, "primary_ip", "ip", "ip_address")
		if ip != "" {
			rows = append(rows, networkRow{ip, rootGateway, strings.Join(rootDNS, ", "), ""})
		}
	}
	tableRows := make([][]string, 0, len(rows))
	for _, row := range rows {
		tableRows = append(tableRows, []string{row.ip, row.maskGateway, row.dns, row.iface})
	}
	if len(tableRows) == 0 {
		return paragraph("—", "IntenseQuote")
	}
	return tableWithWidths([]string{"IP", "Mask / Gateway", "DNS", "Interfață"}, tableRows, []int{1900, 2700, 2600, 1800})
}

type networkAddress struct{ IP, Mask string }

func addressValues(record map[string]any) []networkAddress {
	value, ok := firstMapValue(record, "addresses", "ip_addresses", "address_list")
	if !ok {
		return nil
	}
	out := make([]networkAddress, 0)
	switch typed := value.(type) {
	case []any:
		for _, item := range typed {
			switch address := item.(type) {
			case string:
				out = append(out, splitCIDR(address))
			case map[string]any:
				ip := firstMapText(address, "ip", "address", "ip_address", "local")
				mask := firstMapText(address, "mask", "netmask", "prefix", "prefix_length", "cidr")
				if ip != "" {
					entry := splitCIDR(ip)
					if entry.Mask == "" {
						entry.Mask = mask
					}
					out = append(out, entry)
				}
			}
		}
	case []string:
		for _, item := range typed {
			out = append(out, splitCIDR(item))
		}
	case string:
		out = append(out, splitCIDR(typed))
	}
	return out
}

func splitCIDR(value string) networkAddress {
	value = strings.TrimSpace(value)
	if before, after, ok := strings.Cut(value, "/"); ok {
		return networkAddress{IP: strings.TrimSpace(before), Mask: "/" + strings.TrimSpace(after)}
	}
	return networkAddress{IP: value}
}

func renderServicesTable(value any) string {
	rows := make([][]string, 0)
	seen := make(map[string]bool)
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		name := firstMapText(record, "name", "service_name", "unit", "unit_name", "id")
		if name == "" && !genericHint(hint) {
			name = hint
		}
		if name == "" || !recordIsActive(record) {
			return
		}
		// vm-doc-agent 1.6.7+ classifies services conservatively. Only
		// entries explicitly classified as OS/system services are hidden here;
		// application, unknown and older snapshots without classification stay
		// visible so documentation never loses a potentially relevant service.
		if strings.EqualFold(firstMapText(record, "classification"), "system") {
			return
		}
		description := firstMapText(record, "description", "display_name", "unit_description", "summary")
		key := strings.ToLower(name)
		if seen[key] {
			return
		}
		seen[key] = true
		rows = append(rows, []string{name, description})
	})
	sort.SliceStable(rows, func(i, j int) bool { return strings.ToLower(rows[i][0]) < strings.ToLower(rows[j][0]) })
	if len(rows) == 0 {
		return paragraph("Nu au fost identificate servicii active de aplicație sau neclasificate.", "IntenseQuote")
	}
	return tableWithWidths([]string{"Nume", "Descriere"}, rows, []int{3200, 5800})
}

func renderPortsTable(value any) string {
	type portRow struct {
		name, executable, address, port, protocol string
		score                                     int
	}
	byPort := make(map[string]portRow)
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		port := firstMapText(record, "port", "local_port", "listen_port", "service_port")
		if port == "" {
			local := firstMapText(record, "local_address", "address", "listen")
			if local != "" {
				port = lastPort(local)
			}
		}
		if port == "" {
			return
		}
		protocol := strings.ToUpper(firstMapText(record, "protocol", "proto", "transport"))
		address := firstMapText(record, "address", "local_address", "listen")
		processes, _ := firstMapValue(record, "processes", "process_info", "owners")
		processRows := make([][]string, 0)
		walkRecordMaps(processes, "", func(proc map[string]any, procHint string) {
			name := firstMapText(proc, "name", "process", "process_name", "service", "program")
			if name == "" && !genericHint(procHint) {
				name = procHint
			}
			executable := firstMapText(proc, "executable", "exec", "exec_path", "binary", "path", "command")
			pid := firstMapText(proc, "pid", "process_id")
			if name == "" && executable == "" && pid == "" {
				return
			}
			if pid != "" && name != "" {
				name = name + " (PID " + pid + ")"
			}
			processRows = append(processRows, []string{name, executable})
		})
		if len(processRows) == 0 {
			name := firstMapText(record, "name", "process", "process_name", "service", "program")
			if name == "" && !genericHint(hint) {
				name = hint
			}
			executable := firstMapText(record, "executable", "exec", "exec_path", "binary", "path", "command")
			processRows = append(processRows, []string{name, executable})
		}
		for _, process := range processRows {
			candidate := portRow{name: process[0], executable: process[1], address: firstNonEmpty(address, "*"), port: port, protocol: protocol}
			if candidate.name != "" {
				candidate.score += 2
			}
			if candidate.executable != "" {
				candidate.score += 3
			}
			if candidate.address != "" && candidate.address != "*" {
				candidate.score++
			}
			key := strings.ToLower(port + "\x00" + protocol)
			if current, ok := byPort[key]; !ok || candidate.score > current.score {
				byPort[key] = candidate
			}
		}
	})
	if len(byPort) == 0 {
		return paragraph("—", "IntenseQuote")
	}
	values := make([]portRow, 0, len(byPort))
	for _, row := range byPort {
		values = append(values, row)
	}
	sort.SliceStable(values, func(i, j int) bool {
		pi, _ := strconv.Atoi(values[i].port)
		pj, _ := strconv.Atoi(values[j].port)
		if pi != pj {
			return pi < pj
		}
		return strings.ToLower(values[i].protocol) < strings.ToLower(values[j].protocol)
	})
	rows := make([][]string, 0, len(values))
	for _, row := range values {
		rows = append(rows, []string{row.name, row.executable, row.address, row.port, row.protocol})
	}
	return tableWithWidths([]string{"Nume / proces", "Executabil", "Adresă", "Port", "Protocol"}, rows, []int{2200, 3300, 1700, 900, 900})
}

func renderFirewallTable(value any) string {
	object := firstObject(value)
	if object == nil {
		return paragraph("—", "IntenseQuote")
	}
	var out strings.Builder
	backends := strings.Join(uniqueStrings(textListFromMap(object, "backends", "backend")), ", ")
	configs := strings.Join(uniqueStrings(textListFromMap(object, "config_files", "config_file", "configs")), ", ")
	active := "Nu"
	if boolFromMap(object, "active", "enabled", "running") {
		active = "Da"
	}
	detected := "Nu"
	if boolFromMap(object, "detected", "installed") || backends != "" {
		detected = "Da"
	}
	out.WriteString(keyValueTable([]PreviewRow{{Label: "Detectat", Value: detected}, {Label: "Activ", Value: active}, {Label: "Backend-uri", Value: firstNonEmpty(backends, "—")}, {Label: "Fișiere configurație", Value: firstNonEmpty(configs, "—")}}))

	if raw, ok := firstMapValue(object, "default_policies", "policies"); ok {
		if policies, ok := raw.(map[string]any); ok && len(policies) > 0 {
			keys := make([]string, 0, len(policies))
			for key := range policies {
				keys = append(keys, key)
			}
			sort.Strings(keys)
			rows := make([][]string, 0, len(keys))
			for _, key := range keys {
				rows = append(rows, []string{key, compactString(policies[key])})
			}
			out.WriteString(heading("Politici implicite", 3))
			out.WriteString(tableWithWidths([]string{"Context", "Politică"}, rows, []int{6000, 3000}))
		}
	}

	zoneRows := make([][]string, 0)
	if raw, ok := firstMapValue(object, "zones"); ok {
		walkRecordMaps(raw, "", func(zone map[string]any, hint string) {
			name := firstMapText(zone, "name", "zone")
			if name == "" && !genericHint(hint) {
				name = hint
			}
			if name == "" {
				return
			}
			state := "Nu"
			if boolFromMap(zone, "active", "enabled") {
				state = "Da"
			}
			interfaces := strings.Join(textListFromMap(zone, "interfaces", "interface"), ", ")
			sources := strings.Join(textListFromMap(zone, "sources", "source"), ", ")
			services := strings.Join(textListFromMap(zone, "services", "service"), ", ")
			ports := strings.Join(textListFromMap(zone, "ports", "port"), ", ")
			target := firstMapText(zone, "target", "policy")
			zoneRows = append(zoneRows, []string{name, state, interfaces, sources, services, ports, target})
		})
	}
	if len(zoneRows) > 0 {
		out.WriteString(heading("Zone firewalld", 3))
		out.WriteString(tableWithWidths([]string{"Zonă", "Activă", "Interfețe", "Surse", "Servicii", "Porturi", "Target"}, zoneRows, []int{1200, 800, 1400, 1700, 1500, 1400, 1000}))
	}

	ruleRows := make([][]string, 0)
	for _, rule := range firewallRelevantRules(object) {
		backend := firstMapText(rule, "backend")
		family := firstMapText(rule, "family")
		tableName := firstMapText(rule, "table")
		chain := firstMapText(rule, "chain")
		action := firstMapText(rule, "action", "decision", "target")
		text := firstMapText(rule, "rule", "raw", "expression", "line")
		if backend == "" && text == "" {
			continue
		}
		ruleRows = append(ruleRows, []string{backend, family, strings.Trim(strings.Join(nonEmpty(tableName, chain), " / "), " /"), action, text})
	}
	if len(ruleRows) > 0 {
		const maxRules = 200
		total := len(ruleRows)
		if len(ruleRows) > maxRules {
			ruleRows = ruleRows[:maxRules]
		}
		out.WriteString(heading("Reguli firewall configurate", 3))
		out.WriteString(tableWithWidths([]string{"Backend", "Familie", "Tabel / chain", "Acțiune", "Regulă"}, ruleRows, []int{1200, 900, 1700, 1000, 4200}))
		if total > maxRules {
			out.WriteString(paragraph(fmt.Sprintf("Sunt afișate primele %d din %d reguli.", maxRules, total), "IntenseQuote"))
		}
	}
	if len(zoneRows) == 0 && len(ruleRows) == 0 {
		legacyRows := make([][]string, 0)
		walkFirewall(value, "", &legacyRows, make(map[string]bool))
		if len(legacyRows) > 0 {
			out.WriteString(heading("Reguli UFW (format legacy)", 3))
			out.WriteString(tableWithWidths([]string{"Nr.", "Către", "Acțiune", "Din"}, legacyRows, []int{700, 3000, 1800, 3500}))
		} else if backends == "" {
			out.WriteString(paragraph("Nu au fost identificate reguli sau zone firewall.", "IntenseQuote"))
		}
	}
	return out.String()
}

func firewallRelevantRules(object map[string]any) []map[string]any {
	rules := make([]map[string]any, 0)
	if raw, ok := firstMapValue(object, "rules", "firewall_rules"); ok {
		walkRecordMaps(raw, "", func(rule map[string]any, _ string) {
			rules = append(rules, rule)
		})
	}
	if len(rules) == 0 {
		return rules
	}
	managed := map[string]bool{}
	for _, backend := range uniqueStrings(textListFromMap(object, "backends", "backend")) {
		switch strings.ToLower(strings.TrimSpace(backend)) {
		case "ufw", "firewalld", "susefirewall2":
			managed[strings.ToLower(strings.TrimSpace(backend))] = true
		}
	}
	if len(managed) == 0 {
		// Fără un manager high-level, regulile nftables/iptables sunt considerate
		// configurația efectivă a hostului și rămân documentate.
		return rules
	}
	filtered := make([]map[string]any, 0, len(rules))
	for _, rule := range rules {
		backend := strings.ToLower(strings.TrimSpace(firstMapText(rule, "backend")))
		if managed[backend] {
			filtered = append(filtered, rule)
		}
	}
	return filtered
}

func walkFirewall(value any, hint string, rows *[][]string, seen map[string]bool) {
	switch typed := value.(type) {
	case []any:
		for index, item := range typed {
			if text, ok := item.(string); ok {
				if row, valid := parseUFWLine(text, index+1); valid {
					key := strings.Join(row, "\x00")
					if !seen[key] {
						seen[key] = true
						*rows = append(*rows, row)
					}
				}
				continue
			}
			walkFirewall(item, hint, rows, seen)
		}
	case map[string]any:
		number := firstMapText(typed, "number", "rule_number", "index", "nr")
		to := firstMapText(typed, "to", "destination", "port", "rule", "target")
		action := firstMapText(typed, "action", "policy", "decision")
		from := firstMapText(typed, "from", "source", "source_address")
		if number != "" && (to != "" || action != "" || from != "") {
			row := []string{number, to, action, from}
			key := strings.Join(row, "\x00")
			if !seen[key] {
				seen[key] = true
				*rows = append(*rows, row)
			}
		}
		for key, child := range typed {
			n := normalizeInventoryKey(key)
			if strings.Contains(n, "numbered") || n == "rules" || n == "ufwrules" || n == "statusnumbered" {
				walkFirewall(child, key, rows, seen)
			}
		}
	case string:
		lines := strings.Split(typed, "\n")
		for index, line := range lines {
			if row, valid := parseUFWLine(line, index+1); valid {
				key := strings.Join(row, "\x00")
				if !seen[key] {
					seen[key] = true
					*rows = append(*rows, row)
				}
			}
		}
	}
}

func parseUFWLine(line string, fallback int) ([]string, bool) {
	line = strings.TrimSpace(line)
	if line == "" || !strings.Contains(line, "]") {
		return nil, false
	}
	left, right, ok := strings.Cut(line, "]")
	if !ok {
		return nil, false
	}
	number := strings.Trim(strings.TrimSpace(left), "[")
	if _, err := strconv.Atoi(strings.TrimSpace(number)); err != nil {
		number = strconv.Itoa(fallback)
	}
	fields := strings.Fields(strings.TrimSpace(right))
	if len(fields) < 2 {
		return nil, false
	}
	to := fields[0]
	actionIndex := -1
	for i, field := range fields {
		upper := strings.ToUpper(field)
		if upper == "ALLOW" || upper == "DENY" || upper == "REJECT" || upper == "LIMIT" {
			actionIndex = i
			break
		}
	}
	if actionIndex < 1 {
		return []string{number, to, strings.Join(fields[1:], " "), ""}, true
	}
	actionEnd := actionIndex + 1
	if actionEnd < len(fields) && (strings.EqualFold(fields[actionEnd], "IN") || strings.EqualFold(fields[actionEnd], "OUT")) {
		actionEnd++
	}
	action := strings.Join(fields[actionIndex:actionEnd], " ")
	from := strings.Join(fields[actionEnd:], " ")
	return []string{number, strings.Join(fields[:actionIndex], " "), action, from}, true
}

func renderAccountsTable(value any) string {
	rows := make([][]string, 0)
	seen := make(map[string]bool)
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		name := firstMapText(record, "username", "user", "name", "account")
		if name == "" && !genericHint(hint) {
			name = hint
		}
		uidText := firstMapText(record, "uid", "user_id")
		uid, _ := strconv.ParseInt(strings.TrimSpace(uidText), 10, 64)
		groups := strings.Join(textListFromMap(record, "groups", "group", "memberships"), ", ")
		admin := boolFromMap(record, "admin", "is_admin", "administrator", "sudo") || containsAdminGroup(groups)
		systemAccount := uid < 1000
		if raw, ok := firstMapValue(record, "system_account", "is_system_account"); ok {
			systemAccount = boolValue(raw)
		}
		if !strings.EqualFold(name, "root") && systemAccount && !admin {
			return
		}
		if name == "" {
			return
		}
		key := strings.ToLower(name)
		if seen[key] {
			return
		}
		seen[key] = true
		home := firstMapText(record, "home", "home_directory", "homedir")
		shell := firstMapText(record, "shell", "login_shell")
		rows = append(rows, []string{name, uidText, home, firstNonEmpty(groups, shell)})
	})
	sort.SliceStable(rows, func(i, j int) bool {
		if strings.EqualFold(rows[i][0], "root") != strings.EqualFold(rows[j][0], "root") {
			return strings.EqualFold(rows[i][0], "root")
		}
		return strings.ToLower(rows[i][0]) < strings.ToLower(rows[j][0])
	})
	if len(rows) == 0 {
		return paragraph("—", "IntenseQuote")
	}
	return tableWithWidths([]string{"Utilizator", "UID", "Home", "Grupuri / shell"}, rows, []int{2100, 900, 3000, 3000})
}

func renderSSSDTable(value any) string {
	object := firstObject(value)
	active := "Nu"
	if object != nil && recordIsActive(object) {
		active = "Da"
	}
	searchBase := recursiveFirstText(value, "ldap_search_base", "ldapsearchbase", "search_base", "base_dn")
	version := recursiveFirstText(value, "version", "sssd_version")
	return tableWithWidths([]string{"SSSD", "LDAP search base", "Versiune"}, [][]string{{active, searchBase, version}}, []int{1300, 5200, 2500})
}

func renderIntegrationsTable(value any, sections map[string]any) string {
	type integrationSpec struct {
		label   string
		aliases []string
	}
	specs := []integrationSpec{
		{"Auditbeat", []string{"auditbeat"}},
		{"Filebeat", []string{"filebeat"}},
		{"GLPI Agent", []string{"glpi", "glpi_agent", "glpiagent"}},
		{"Node Exporter", []string{"node_exporter", "nodeexporter"}},
		{"Syslog", []string{"syslog", "rsyslog"}},
	}
	rows := make([][]string, 0, len(specs))
	for _, spec := range specs {
		item := findNamedValue(value, spec.aliases...)
		if item == nil {
			item = findNamedValue(sections, spec.aliases...)
		}
		object := firstObject(item)
		active := "Nu"
		if object != nil && recordIsActive(object) {
			active = "Da"
		}
		version := shortVersion(recursiveFirstText(item, "version", "agent_version"))
		configOK := yesNoFromValue(recursiveFirstValue(item, "config_ok", "configuration_ok", "config_valid", "configured"))
		output := strings.Join(uniqueStrings(recursiveTextList(item, "output_host", "output_hosts", "host", "hosts", "server", "servers", "destination")), ", ")
		details := strings.Join(uniqueStrings(nonEmpty(
			recursiveFirstText(item, "details", "detail", "message", "notes"),
			recursiveFirstText(item, "config_file", "configuration_file", "conf_file"),
			recursiveFirstText(item, "error", "last_error"),
		)), " · ")
		rows = append(rows, []string{spec.label, active, version, configOK, output, details})
	}
	return tableWithWidths([]string{"Integrare", "Activ", "Versiune", "Config OK", "Output host", "Detalii"}, rows, []int{1500, 900, 1300, 1000, 1800, 2500})
}

func renderPolicies(value any) string {
	if value == nil || len(flattenValue(value, 10)) == 0 {
		return paragraph("—", "IntenseQuote")
	}
	return renderCompactKeyValues(value, nil, 12)
}

func renderCronTable(value any) string {
	rows := make([][]string, 0)
	seen := make(map[string]bool)
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		schedule := firstMapText(record, "schedule", "expression", "cron", "cron_expression", "timer", "when")
		command := firstMapText(record, "command", "cmd", "exec", "executable", "script")
		user := firstMapText(record, "user", "username", "owner", "run_as")
		if command == "" && !genericHint(hint) {
			command = hint
		}
		if schedule == "" && command == "" {
			return
		}
		key := strings.ToLower(schedule + "\x00" + command + "\x00" + user)
		if seen[key] {
			return
		}
		seen[key] = true
		rows = append(rows, []string{schedule, command, user})
	})
	if len(rows) == 0 {
		return paragraph("—", "IntenseQuote")
	}
	return tableWithWidths([]string{"Programare", "Comandă", "Utilizator"}, rows, []int{1900, 5200, 1900})
}

func renderNTPTable(value any) string {
	configFile := recursiveFirstText(value, "conf_file", "config_file", "configuration_file", "config")
	sources := strings.Join(uniqueStrings(recursiveTextList(value, "source", "sources", "server", "servers", "peer", "peers")), ", ")
	version := shortVersion(recursiveFirstText(value, "version", "chrony_version", "ntp_version"))
	return tableWithWidths([]string{"Fișier configurație", "Sursă", "Versiune"}, [][]string{{configFile, sources, version}}, []int{3300, 3600, 2100})
}

func walkRecordMaps(value any, hint string, visit func(map[string]any, string)) {
	switch typed := value.(type) {
	case map[string]any:
		if mapHasScalar(typed) {
			visit(typed, hint)
		}
		keys := make([]string, 0, len(typed))
		for key := range typed {
			keys = append(keys, key)
		}
		sort.Strings(keys)
		for _, key := range keys {
			child := typed[key]
			switch child.(type) {
			case map[string]any, []any:
				walkRecordMaps(child, key, visit)
			}
		}
	case []any:
		for _, child := range typed {
			walkRecordMaps(child, hint, visit)
		}
	}
}

func mapHasScalar(value map[string]any) bool {
	for _, child := range value {
		switch child.(type) {
		case map[string]any, []any:
		default:
			return true
		}
	}
	return false
}

func firstObject(value any) map[string]any {
	if object, ok := value.(map[string]any); ok {
		return object
	}
	if list, ok := value.([]any); ok {
		for _, item := range list {
			if object, ok := item.(map[string]any); ok {
				return object
			}
		}
	}
	return nil
}

func firstMapValue(record map[string]any, aliases ...string) (any, bool) {
	wanted := make(map[string]bool, len(aliases))
	for _, alias := range aliases {
		wanted[normalizeInventoryKey(alias)] = true
	}
	for key, value := range record {
		if wanted[normalizeInventoryKey(key)] {
			return value, true
		}
	}
	return nil, false
}

func firstMapText(record map[string]any, aliases ...string) string {
	value, ok := firstMapValue(record, aliases...)
	if !ok {
		return ""
	}
	return compactString(value)
}

func boolFromMap(record map[string]any, aliases ...string) bool {
	value, ok := firstMapValue(record, aliases...)
	if !ok {
		return false
	}
	return boolValue(value)
}

func recordIsActive(record map[string]any) bool {
	for _, alias := range []string{"active", "enabled", "running", "installed", "is_active", "is_enabled"} {
		if value, ok := firstMapValue(record, alias); ok {
			return boolValue(value)
		}
	}
	status := strings.ToLower(firstMapText(record, "status", "state", "active_state", "sub_state", "result"))
	if status == "" {
		return true
	}
	for _, negative := range []string{"inactive", "disabled", "stopped", "dead", "failed", "error", "not installed", "absent"} {
		if strings.Contains(status, negative) {
			return false
		}
	}
	for _, positive := range []string{"active", "running", "enabled", "started", "ok", "installed", "up"} {
		if strings.Contains(status, positive) {
			return true
		}
	}
	return true
}

func recursiveFirstText(value any, aliases ...string) string {
	if found := recursiveFirstValue(value, aliases...); found != nil {
		return compactString(found)
	}
	return ""
}

func recursiveFirstValue(value any, aliases ...string) any {
	wanted := make(map[string]bool, len(aliases))
	for _, alias := range aliases {
		wanted[normalizeInventoryKey(alias)] = true
	}
	var walk func(any) any
	walk = func(item any) any {
		switch typed := item.(type) {
		case map[string]any:
			keys := make([]string, 0, len(typed))
			for key := range typed {
				keys = append(keys, key)
			}
			sort.Strings(keys)
			for _, key := range keys {
				if wanted[normalizeInventoryKey(key)] {
					return typed[key]
				}
			}
			for _, key := range keys {
				if value := walk(typed[key]); value != nil {
					return value
				}
			}
		case []any:
			for _, child := range typed {
				if value := walk(child); value != nil {
					return value
				}
			}
		}
		return nil
	}
	return walk(value)
}

func recursiveTextList(value any, aliases ...string) []string {
	wanted := make(map[string]bool, len(aliases))
	for _, alias := range aliases {
		wanted[normalizeInventoryKey(alias)] = true
	}
	out := make([]string, 0)
	var walk func(any)
	walk = func(item any) {
		switch typed := item.(type) {
		case map[string]any:
			for key, child := range typed {
				if wanted[normalizeInventoryKey(key)] {
					out = append(out, valueStrings(child)...)
				} else {
					walk(child)
				}
			}
		case []any:
			for _, child := range typed {
				walk(child)
			}
		}
	}
	walk(value)
	return uniqueStrings(out)
}

func textListFromMap(record map[string]any, aliases ...string) []string {
	value, ok := firstMapValue(record, aliases...)
	if !ok {
		return nil
	}
	return valueStrings(value)
}

func valueStrings(value any) []string {
	switch typed := value.(type) {
	case nil:
		return nil
	case string:
		if strings.Contains(typed, "\n") {
			return nonEmpty(strings.Split(typed, "\n")...)
		}
		return nonEmpty(typed)
	case []any:
		out := make([]string, 0, len(typed))
		for _, item := range typed {
			out = append(out, valueStrings(item)...)
		}
		return out
	case map[string]any:
		out := make([]string, 0, len(typed))
		keys := make([]string, 0, len(typed))
		for key := range typed {
			keys = append(keys, key)
		}
		sort.Strings(keys)
		for _, key := range keys {
			text := compactString(typed[key])
			if text != "" {
				out = append(out, text)
			}
		}
		return out
	default:
		return nonEmpty(compactString(value))
	}
}

func findNamedValue(value any, aliases ...string) any {
	wanted := make(map[string]bool, len(aliases))
	for _, alias := range aliases {
		wanted[normalizeInventoryKey(alias)] = true
	}
	var walk func(any) any
	walk = func(item any) any {
		switch typed := item.(type) {
		case map[string]any:
			for key, child := range typed {
				if wanted[normalizeInventoryKey(key)] {
					return child
				}
			}
			for _, child := range typed {
				if found := walk(child); found != nil {
					return found
				}
			}
		case []any:
			for _, child := range typed {
				if found := walk(child); found != nil {
					return found
				}
			}
		}
		return nil
	}
	return walk(value)
}

func compactString(value any) string {
	switch typed := value.(type) {
	case nil:
		return ""
	case string:
		return strings.TrimSpace(typed)
	case bool:
		if typed {
			return "Da"
		}
		return "Nu"
	case json.Number:
		return typed.String()
	case float64:
		return strconv.FormatFloat(typed, 'f', -1, 64)
	case float32:
		return strconv.FormatFloat(float64(typed), 'f', -1, 32)
	case int:
		return strconv.Itoa(typed)
	case int64:
		return strconv.FormatInt(typed, 10)
	case int32:
		return strconv.FormatInt(int64(typed), 10)
	case uint64:
		return strconv.FormatUint(typed, 10)
	case []string:
		return strings.Join(typed, ", ")
	case []any:
		return strings.Join(valueStrings(typed), ", ")
	default:
		encoded, err := json.Marshal(typed)
		if err == nil {
			return string(encoded)
		}
		return fmt.Sprint(typed)
	}
}

func normalizeInventoryKey(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	var out strings.Builder
	for _, r := range value {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
			out.WriteRune(r)
		}
	}
	return out.String()
}

func compactLabel(value string) string {
	value = strings.TrimSpace(value)
	parts := strings.Split(value, " / ")
	if len(parts) > 1 {
		value = parts[len(parts)-1]
	}
	aliases := map[string]string{
		"hostname":     "Hostname",
		"fqdn":         "FQDN",
		"machineid":    "Machine ID",
		"productuuid":  "Product UUID",
		"architecture": "Arhitectură",
		"boottime":     "Pornire sistem",
		"cpucount":     "vCPU",
		"cpumodel":     "Model CPU",
		"memorybytes":  "Memorie",
		"memory":       "Memorie",
		"kernel":       "Kernel",
		"name":         "Nume",
		"prettyname":   "Denumire completă",
		"version":      "Versiune",
	}
	if label := aliases[normalizeInventoryKey(value)]; label != "" {
		return label
	}
	value = strings.ReplaceAll(strings.ReplaceAll(value, "_", " "), "-", " ")
	words := strings.Fields(value)
	for i, word := range words {
		lower := strings.ToLower(word)
		switch lower {
		case "ip", "fqdn", "uuid", "uid", "cpu", "ram", "os", "dns", "ntp", "sssd":
			words[i] = strings.ToUpper(lower)
		default:
			if word != "" {
				words[i] = strings.ToUpper(word[:1]) + word[1:]
			}
		}
	}
	return strings.Join(words, " ")
}

func humanizeValueForLabel(label, value string) string {
	normalized := normalizeInventoryKey(label)
	if strings.Contains(normalized, "bytes") || strings.Contains(normalized, "memory") || strings.Contains(normalized, "memorie") || strings.Contains(normalized, "capacity") || strings.Contains(normalized, "size") {
		if number, err := strconv.ParseFloat(strings.TrimSpace(value), 64); err == nil && number >= 1024 {
			return humanBytes(number)
		}
	}
	return value
}

func humanCapacity(value any) string {
	text := compactString(value)
	if text == "" {
		return ""
	}
	trimmed := strings.TrimSpace(strings.ToUpper(text))
	for _, suffix := range []string{"TB", "GB", "MB", "KB", "TIB", "GIB", "MIB", "KIB"} {
		if strings.Contains(trimmed, suffix) {
			return text
		}
	}
	if number, err := strconv.ParseFloat(strings.ReplaceAll(text, ",", "."), 64); err == nil {
		return humanBytes(number)
	}
	return text
}

func humanBytes(value float64) string {
	if value < 1024 {
		return fmt.Sprintf("%.0f B", value)
	}
	units := []string{"KB", "MB", "GB", "TB", "PB"}
	current := value
	for _, unit := range units {
		current /= 1024
		if current < 1024 || unit == units[len(units)-1] {
			if current >= 100 {
				return fmt.Sprintf("%.0f %s", current, unit)
			}
			if current >= 10 {
				return fmt.Sprintf("%.1f %s", current, unit)
			}
			return fmt.Sprintf("%.2f %s", current, unit)
		}
	}
	return fmt.Sprintf("%.0f B", value)
}

func boolValue(value any) bool {
	switch typed := value.(type) {
	case bool:
		return typed
	case string:
		text := strings.ToLower(strings.TrimSpace(typed))
		return text == "true" || text == "yes" || text == "da" || text == "1" || text == "active" || text == "enabled" || text == "running" || text == "ok" || text == "installed"
	case json.Number:
		return typed.String() != "0"
	case float64:
		return typed != 0
	case int:
		return typed != 0
	case int64:
		return typed != 0
	default:
		return false
	}
}

func yesNoFromValue(value any) string {
	if value == nil {
		return "—"
	}
	if boolValue(value) {
		return "Da"
	}
	return "Nu"
}

func containsAdminGroup(groups string) bool {
	groups = strings.ToLower(groups)
	for _, token := range []string{"sudo", "wheel", "admin", "administrators"} {
		if strings.Contains(groups, token) {
			return true
		}
	}
	return false
}

func uniqueStrings(values []string) []string {
	out := make([]string, 0, len(values))
	seen := make(map[string]bool)
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		key := strings.ToLower(value)
		if seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, value)
	}
	return out
}

func lastPort(value string) string {
	value = strings.TrimSpace(value)
	if index := strings.LastIndex(value, ":"); index >= 0 && index+1 < len(value) {
		return strings.Trim(value[index+1:], "[]")
	}
	return value
}

func genericHint(value string) bool {
	n := normalizeInventoryKey(value)
	for _, generic := range []string{"items", "entries", "list", "services", "interfaces", "addresses", "rules", "users", "accounts", "ports", "mounts", "disks", "filesystems", "integrations"} {
		if n == generic {
			return true
		}
	}
	return n == ""
}
