package server

import (
	"errors"
	"net/http"
	"strconv"
	"strings"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/dockerinventory"
)

type dockerAssignmentsRequest struct {
	Assignments []dockerinventory.AssignmentInput `json:"assignments"`
}

func (a *App) getVMDocker(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	view, err := a.Docker.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) replaceDockerContainerServices(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	containerID, err := strconv.ParseInt(strings.TrimSpace(r.PathValue("container_id")), 10, 64)
	if err != nil || containerID < 1 {
		badRequest(w, errors.New("invalid container_id"))
		return
	}
	var input dockerAssignmentsRequest
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Docker.ReplaceManualAssignments(r.Context(), vmID, containerID, user.ID, input.Assignments); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "docker.container.services.replace", "docker_container", strconv.FormatInt(containerID, 10), "success", map[string]any{"vm_id": vmID, "assignments": input.Assignments})
	view, err := a.Docker.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) assignDockerComposeProject(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	project := strings.TrimSpace(r.PathValue("project"))
	if project == "" {
		badRequest(w, errors.New("compose project is required"))
		return
	}
	var input dockerAssignmentsRequest
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if len(input.Assignments) == 0 {
		badRequest(w, errors.New("at least one assignment is required"))
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	changed, err := a.Docker.AssignComposeProject(r.Context(), vmID, project, user.ID, input.Assignments)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "docker.compose.services.assign", "docker_compose_project", project, "success", map[string]any{"vm_id": vmID, "assignments": input.Assignments, "changed": changed})
	jsonResponse(w, http.StatusOK, map[string]any{"changed": changed})
}

func (a *App) setDockerDocumentationExempt(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input struct {
		Exempt bool `json:"exempt"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if err := a.Docker.SetHostDocumentationExempt(r.Context(), vmID, input.Exempt); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "docker.host.documentation_exempt", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{"exempt": input.Exempt})
	view, err := a.Docker.GetVM(r.Context(), vmID)
	respond(w, view, err)
}
