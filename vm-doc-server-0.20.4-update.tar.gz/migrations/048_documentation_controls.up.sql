-- 0.20.4: controale de documentare și IP principal ales manual.
ALTER TABLE vm_operational_metadata
  ADD COLUMN preferred_ip VARCHAR(45) NOT NULL DEFAULT '' AFTER notes;

ALTER TABLE database_instances
  ADD COLUMN documentation_exempt TINYINT(1) NOT NULL DEFAULT 0 AFTER present;

ALTER TABLE web_servers
  ADD COLUMN documentation_exempt TINYINT(1) NOT NULL DEFAULT 0 AFTER installed;

ALTER TABLE docker_hosts
  ADD COLUMN documentation_exempt TINYINT(1) NOT NULL DEFAULT 0 AFTER installed;
