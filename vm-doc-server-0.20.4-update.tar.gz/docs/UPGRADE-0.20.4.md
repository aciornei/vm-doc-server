# Upgrade vm-doc-server 0.20.3 → 0.20.4

Versiunea 0.20.4 extinde controlul documentației VM/serviciu, alegerea IP-ului principal, RPO/RTO, excluderea controlată a resurselor care nu necesită documentare și îmbunătățește exportul DOCX/Markdown.

## Migrare DB

La pornirea serverului se aplică migrarea `048_documentation_controls.up.sql`:

- `vm_operational_metadata.preferred_ip` — IP-ul preferat pentru UI și documentație;
- `database_instances.documentation_exempt` — instanță DB care nu necesită documentare;
- `web_servers.documentation_exempt` — engine Web care nu necesită documentare;
- `docker_hosts.documentation_exempt` — host Docker care nu necesită documentare.

RPO/RTO folosesc câmpurile existente `vm_operational_metadata.rpo_minutes` și `rto_minutes` și sunt gestionate din **VM → Date operaționale**.

## Upgrade offline recomandat

Păstrați arborele 0.20.3 care compilează deja în rețeaua izolată, inclusiv `go.mod`, `go.sum` și `vendor/`.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.3 vm-doc-server-0.20.4

tar -xzf vm-doc-server-0.20.4-update.tar.gz \
  -C /usr/local/src/vm-doc-server-0.20.4

cd /usr/local/src/vm-doc-server-0.20.4
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Nu rulați `go mod vendor` pe serverul fără Internet.

După instalarea binarului, reporniți `vm-doc-server` și faceți `Ctrl+F5` în browser.

## Verificări recomandate

1. VM → Date operaționale: setați un IP principal, RPO și RTO și salvați.
2. Generați o fișă VM cu și fără bifa `Include „Generat de”`.
3. Verificați că `Data referință` apare în loc de `Data generării`.
4. Pentru o instanță PostgreSQL fără baze relevante, bifați `Nu necesită documentare` și verificați completitudinea/documentul.
5. Testați aceeași bifă pentru Docker și Apache/Nginx/HAProxy.
6. Generați fișa serviciului și exportul Markdown cu anexele A1/A2 activate.
7. Pentru un DOCX suplimentar, verificați headings/liste/tabele în Markdown și formatarea originală în DOCX.
