# Upgrade VM-DOC Server 0.20.64 → 0.20.65

0.20.65 adaugă filtre locale în pagina VM → Aplicație pentru Docker, Baze de date și Web. Nu există migrare DB și nu este necesar un agent nou.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.64 /usr/local/src/vm-doc-server-0.20.65
tar -xzf vm-doc-server-0.20.65-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.65
cd /usr/local/src/vm-doc-server-0.20.65
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server` și fă `Ctrl+F5` în browser. Agentul 1.7.12 rămâne versiunea recomandată.
