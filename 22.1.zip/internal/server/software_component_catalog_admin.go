package server

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"regexp"
	"sort"
	"strings"
)

// Editing this catalogue never changes raw inventory snapshots. Both regular
// Software Components and RAR use the same DB definitions at request time.
type softwareCatalogCategory struct {
	Name   string `json:"name"`
	Active bool   `json:"active"`
}
type softwareCatalogItem struct {
	Key        string   `json:"key"`
	Name       string   `json:"name"`
	Category   string   `json:"category"`
	Aliases    []string `json:"aliases"`
	Enabled    bool     `json:"enabled"`
	IncludeRAR bool     `json:"include_rar"`
	SortOrder  int      `json:"sort_order"`
}
type softwareCatalogResponse struct {
	Categories []softwareCatalogCategory `json:"categories"`
	Components []softwareCatalogItem     `json:"components"`
}

var softwareCatalogKeyRE = regexp.MustCompile(`^[a-z][a-z0-9-]{1,63}$`)

func (a *App) loadSoftwareCatalog(ctx context.Context) (softwareCatalogResponse, error) {
	result := softwareCatalogResponse{Categories: []softwareCatalogCategory{}, Components: []softwareCatalogItem{}}
	if a.DB == nil {
		return result, errors.New("database unavailable")
	}
	rows, err := a.DB.QueryContext(ctx, `SELECT name,active FROM software_component_categories ORDER BY LOWER(name)`)
	if err != nil {
		return result, err
	}
	for rows.Next() {
		var c softwareCatalogCategory
		if err = rows.Scan(&c.Name, &c.Active); err != nil {
			break
		}
		result.Categories = append(result.Categories, c)
	}
	if err == nil {
		err = rows.Err()
	}
	rows.Close()
	if err != nil {
		return result, err
	}
	rows, err = a.DB.QueryContext(ctx, `SELECT component_key,name,category_name,needles_json,enabled,include_rar,sort_order FROM software_component_catalog ORDER BY sort_order,component_key`)
	if err != nil {
		return result, err
	}
	for rows.Next() {
		var c softwareCatalogItem
		var data string
		if err = rows.Scan(&c.Key, &c.Name, &c.Category, &data, &c.Enabled, &c.IncludeRAR, &c.SortOrder); err != nil {
			break
		}
		if err = json.Unmarshal([]byte(data), &c.Aliases); err != nil {
			err = fmt.Errorf("catalog %s: %w", c.Key, err)
			break
		}
		if c.Aliases == nil {
			c.Aliases = []string{}
		}
		result.Components = append(result.Components, c)
	}
	if err == nil {
		err = rows.Err()
	}
	rows.Close()
	return result, err
}

func (a *App) softwareComponentCatalogForDetection(ctx context.Context) ([]softwareComponentDefinition, error) {
	data, err := a.loadSoftwareCatalog(ctx)
	if err != nil {
		return nil, err
	}
	activeCategories := make(map[string]bool, len(data.Categories))
	for _, c := range data.Categories {
		activeCategories[c.Name] = c.Active
	}
	defs := make([]softwareComponentDefinition, 0, len(data.Components))
	for _, c := range data.Components {
		if !c.Enabled || !activeCategories[c.Category] {
			continue
		}
		defs = append(defs, softwareComponentDefinition{Key: c.Key, Name: c.Name, Category: c.Category, Needles: c.Aliases})
	}
	return defs, nil
}

func (a *App) softwareCatalogGet(w http.ResponseWriter, r *http.Request) {
	data, err := a.loadSoftwareCatalog(r.Context())
	respond(w, data, err)
}

func validateSoftwareCatalogCategory(name string) error {
	if len([]rune(name)) < 2 || len([]rune(name)) > 120 || strings.ContainsAny(name, "\r\n\x00") {
		return errors.New("nume categorie invalid (2-120 caractere)")
	}
	return nil
}
func validateSoftwareCatalogItem(item *softwareCatalogItem) error {
	item.Key = strings.TrimSpace(item.Key)
	item.Name = strings.TrimSpace(item.Name)
	item.Category = strings.TrimSpace(item.Category)
	if !softwareCatalogKeyRE.MatchString(item.Key) {
		return errors.New("cheia tehnica trebuie sa aiba 2-64 caractere: a-z, 0-9, -")
	}
	if len([]rune(item.Name)) < 2 || len([]rune(item.Name)) > 190 || strings.ContainsAny(item.Name, "\r\n\x00") {
		return errors.New("nume componenta invalid")
	}
	if err := validateSoftwareCatalogCategory(item.Category); err != nil {
		return err
	}
	if len(item.Aliases) > 30 {
		return errors.New("maximum 30 aliasuri")
	}
	unique := map[string]bool{}
	// Prevent common single-token matches from flooding the inventory with
	// false components when an administrator adds a new detection alias.
	tooGeneric := map[string]bool{"app": true, "agent": true, "service": true, "server": true, "client": true, "system": true, "software": true, "application": true, "linux": true, "windows": true}
	normalized := make([]string, 0, len(item.Aliases))
	for _, value := range item.Aliases {
		value = strings.TrimSpace(value)
		if len([]rune(value)) < 3 || len([]rune(value)) > 100 || strings.ContainsAny(value, "\r\n\x00") {
			return errors.New("aliasul trebuie sa aiba 3-100 caractere, pe o singura linie")
		}
		key := normalizeComponentText(value)
		if tooGeneric[key] {
			return errors.New("alias prea generic: " + value)
		}
		if key == "" || unique[key] {
			continue
		}
		unique[key] = true
		normalized = append(normalized, value)
	}
	if len(normalized) == 0 {
		return errors.New("este necesar cel putin un alias de detectie")
	}
	// Aliases use the same token/prefix matching as the existing curated detector.
	item.Aliases = normalized
	if item.SortOrder < 0 || item.SortOrder > 1000000 {
		return errors.New("ordine de sortare invalida")
	}
	return nil
}

func (a *App) softwareCatalogSaveCategory(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Name   string `json:"name"`
		Active *bool  `json:"active"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	input.Name = strings.TrimSpace(input.Name)
	if err := validateSoftwareCatalogCategory(input.Name); err != nil {
		badRequest(w, err)
		return
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	if r.Method == http.MethodPost {
		_, err := a.DB.ExecContext(r.Context(), `INSERT INTO software_component_categories(name,active) VALUES (?,?)`, input.Name, active)
		if err != nil {
			respond(w, nil, err)
			return
		}
		a.auditRequest(r, "software.catalog.category.create", "software_category", input.Name, "success", map[string]any{"active": active})
		respondStatus(w, map[string]any{"name": input.Name, "active": active}, nil, http.StatusCreated)
		return
	}
	old := r.PathValue("name")
	if old == "" {
		badRequest(w, errors.New("categorie lipsa"))
		return
	}
	res, err := a.DB.ExecContext(r.Context(), `UPDATE software_component_categories SET name=?,active=? WHERE name=?`, input.Name, active, old)
	if err != nil {
		respond(w, nil, err)
		return
	}
	changed, _ := res.RowsAffected()
	if changed == 0 { // distinguish no-op from missing row
		var count int
		if err = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM software_component_categories WHERE name=?`, input.Name).Scan(&count); err != nil || count == 0 {
			badRequest(w, errors.New("categorie inexistenta"))
			return
		}
	}
	a.auditRequest(r, "software.catalog.category.update", "software_category", old, "success", map[string]any{"name": input.Name, "active": active})
	respond(w, map[string]any{"name": input.Name, "active": active}, nil)
}

// An identical alias on two active components would make the first-match
// detector order-dependent. Reject new collisions rather than misclassify VMs.
func softwareCatalogAliasConflict(input softwareCatalogItem, existing []softwareCatalogItem) string {
	own := map[string]bool{}
	for _, alias := range input.Aliases {
		own[normalizeComponentText(alias)] = true
	}
	for _, item := range existing {
		if item.Key == input.Key || !item.Enabled {
			continue
		}
		for _, alias := range item.Aliases {
			if own[normalizeComponentText(alias)] {
				return item.Name
			}
		}
	}
	return ""
}

func (a *App) softwareCatalogSaveItem(w http.ResponseWriter, r *http.Request) {
	var input softwareCatalogItem
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if r.Method == http.MethodPatch && r.PathValue("key") != input.Key {
		badRequest(w, errors.New("cheia tehnica este imutabila"))
		return
	}
	if err := validateSoftwareCatalogItem(&input); err != nil {
		badRequest(w, err)
		return
	}
	catalog, err := a.loadSoftwareCatalog(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	if owner := softwareCatalogAliasConflict(input, catalog.Components); owner != "" && input.Enabled {
		badRequest(w, fmt.Errorf("alias deja folosit de componenta %s", owner))
		return
	}
	var enabled int
	if err := a.DB.QueryRowContext(r.Context(), `SELECT active FROM software_component_categories WHERE name=?`, input.Category).Scan(&enabled); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			badRequest(w, errors.New("categoria nu exista"))
		} else {
			respond(w, nil, err)
		}
		return
	}
	if enabled == 0 && input.Enabled {
		badRequest(w, errors.New("activeaza mai intai categoria"))
		return
	}
	aliases, err := json.Marshal(input.Aliases)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if r.Method == http.MethodPost {
		_, err = a.DB.ExecContext(r.Context(), `INSERT INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES (?,?,?,?,?,?,?)`, input.Key, input.Name, input.Category, string(aliases), input.Enabled, input.IncludeRAR, input.SortOrder)
	} else {
		var result sql.Result
		result, err = a.DB.ExecContext(r.Context(), `UPDATE software_component_catalog SET name=?,category_name=?,needles_json=?,enabled=?,include_rar=?,sort_order=? WHERE component_key=?`, input.Name, input.Category, string(aliases), input.Enabled, input.IncludeRAR, input.SortOrder, input.Key)
		if err == nil {
			count, _ := result.RowsAffected()
			if count == 0 {
				var found int
				err = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM software_component_catalog WHERE component_key=?`, input.Key).Scan(&found)
				if err == nil && found == 0 {
					badRequest(w, errors.New("componenta inexistenta"))
					return
				}
			}
		}
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	action := "software.catalog.component.update"
	if r.Method == http.MethodPost {
		action = "software.catalog.component.create"
	}
	a.auditRequest(r, action, "software_component", input.Key, "success", map[string]any{"category": input.Category, "enabled": input.Enabled, "include_rar": input.IncludeRAR, "aliases": input.Aliases})
	status := http.StatusOK
	if r.Method == http.MethodPost {
		status = http.StatusCreated
	}
	respondStatus(w, input, nil, status)
}

// The regular report and the RAR report share names/categories/aliases. RAR
// applies a separate inclusion flag without hiding a component in other reports.
func filterSoftwareRowsForRAR(rows []softwareComponentReportRow, data softwareCatalogResponse) []softwareComponentReportRow {
	allowed := map[string]bool{}
	for _, item := range data.Components {
		if item.Enabled && item.IncludeRAR {
			allowed[item.Key] = true
		}
	}
	out := make([]softwareComponentReportRow, 0, len(rows))
	for _, row := range rows {
		if allowed[row.ComponentKey] {
			out = append(out, row)
		}
	}
	return out
}

// Used in tests to assert the precedence and override behavior of SQL-loaded definitions.
func resolveSoftwareComponent(catalog []softwareComponentDefinition, key, evidence string) (softwareComponentDefinition, bool) {
	for _, def := range catalog {
		if def.Key == key {
			return def, true
		}
	}
	if key != "" {
		return softwareComponentDefinition{}, false
	} // disabled specialized technology
	return identifySoftwareComponentFromCatalog(catalog, evidence)
}

func sortedSoftwareCatalogCategories(data softwareCatalogResponse) []softwareCatalogCategory {
	out := append([]softwareCatalogCategory(nil), data.Categories...)
	sort.Slice(out, func(i, j int) bool { return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name) })
	return out
}
