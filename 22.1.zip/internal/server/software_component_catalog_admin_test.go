package server

import "testing"

func TestSoftwareCatalogEditingPreservesDetectionAndRAR(t *testing.T) {
	original := []softwareComponentDefinition{
		{Key: "postgresql", Name: "PostgreSQL", Category: "Baze de date", Needles: []string{"postgresql", "postgres"}},
		{Key: "bitdefender", Name: "Bitdefender", Category: "Securitate endpoint", Needles: []string{"bitdefender endpoint security tools", "best agent"}},
	}
	if def, ok := resolveSoftwareComponent(original, "postgresql", "postgresql instance"); !ok || def.Name != "PostgreSQL" {
		t.Fatalf("specialized source must use DB catalog: %+v %v", def, ok)
	}
	if def, ok := identifySoftwareComponentFromCatalog(original, "Bitdefender Endpoint Security Tools 7.0"); !ok || def.Key != "bitdefender" {
		t.Fatalf("new alias is not detected: %+v %v", def, ok)
	}
	if _, ok := resolveSoftwareComponent(original, "mysql", "mysql 8.0"); ok {
		t.Fatal("disabled specialized engine reappeared")
	}
	items := softwareCatalogResponse{Components: []softwareCatalogItem{
		{Key: "postgresql", Enabled: true, IncludeRAR: true},
		{Key: "bitdefender", Enabled: true, IncludeRAR: false},
	}}
	rows := []softwareComponentReportRow{{ComponentKey: "postgresql", VMID: 1}, {ComponentKey: "bitdefender", VMID: 2}}
	got := filterSoftwareRowsForRAR(rows, items)
	if len(got) != 1 || got[0].ComponentKey != "postgresql" {
		t.Fatalf("RAR inclusion flag ignored: %+v", got)
	}
}
func TestSoftwareCatalogValidation(t *testing.T) {
	valid := softwareCatalogItem{Key: "my-internal-app", Name: "Aplicație internă", Category: "Aplicații interne", Aliases: []string{"my-internal-app", "My Internal App"}, Enabled: true, IncludeRAR: true}
	if err := validateSoftwareCatalogItem(&valid); err != nil {
		t.Fatal(err)
	}
	bad := valid
	bad.Aliases = []string{"app"}
	if err := validateSoftwareCatalogItem(&bad); err == nil {
		t.Fatal("generic alias must be rejected")
	}
	bad = valid
	bad.Aliases = []string{"ab"}
	if err := validateSoftwareCatalogItem(&bad); err == nil {
		t.Fatal("accepted ambiguous 2-char alias")
	}
	bad = valid
	bad.Key = "../etc"
	if err := validateSoftwareCatalogItem(&bad); err == nil {
		t.Fatal("accepted invalid key")
	}
	bad = valid
	bad.Aliases = []string{"component x", "Component X"}
	if err := validateSoftwareCatalogItem(&bad); err != nil || len(bad.Aliases) != 1 {
		t.Fatalf("aliases were not normalized: %+v %v", bad.Aliases, err)
	}
}

func TestSoftwareCatalogAliasConflict(t *testing.T) {
	existing := []softwareCatalogItem{{Key: "postgresql", Name: "PostgreSQL", Enabled: true, Aliases: []string{"postgresql", "postgres"}}}
	input := softwareCatalogItem{Key: "my-postgres", Enabled: true, Aliases: []string{"PostgreSQL"}}
	if softwareCatalogAliasConflict(input, existing) != "PostgreSQL" {
		t.Fatal("collision not found")
	}
	input.Aliases = []string{"my-service"}
	if softwareCatalogAliasConflict(input, existing) != "" {
		t.Fatal("false collision")
	}
}
