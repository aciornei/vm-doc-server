# VM-DOC Server 0.22.1 — catalog componente software în Nomenclatoare

**Bază:** 0.21.100. **Agent:** 1.7.18 (nemodificat). **Data:** 2026-11-16.

## Funcționalitate
- Nomenclatoare → Inventar tehnic → **Componente software · catalog**.
- Două registre: categorii software (creare, redenumire, activare/dezactivare) și componente (creare, editare, filtrare, paginare).
- Fiecare componentă are cheie tehnică persistentă, denumire, categorie, aliasuri de identificare, stare Activă, **Include în RAR Anexa 6** și ordine de potrivire.
- **47 componente și 13 categorii** sunt importate idempotent din catalogul 0.21.100, cu aceleași chei, aliasuri și prioritate. Nu se șterge sau modifică niciun inventar brut.
- Detectarea automată din colectorii DB/Web/Docker, software instalat și serviciile agentului utilizează acum catalogul SQL administrat în interfață. Colectorii specializați își păstrează prioritatea la versiuni.
- Raportul **Componente software** și **RAR → Produse software · Inventar agregat / Word** reflectă numele/categoriile configurate; opțiunea Include în RAR afectează doar RAR, nu raportul general.
- Componenta nouă apare în rapoarte numai dacă un alias se regăsește în datele existente; introducerea în catalog NU atestă instalarea și NU creează automat o asociere manuală VM–componentă.
- Validare pe server: nume, chei stabile, aliasuri 3–100 caractere, până la 30 aliasuri, prevenire duplicat exact și aliasuri prea generale; cheile existente nu pot fi schimbate.
- Acces: `nomenclatures.read` pentru citire; `nomenclatures.manage` + CSRF pentru mutații; Audit pentru creare/editare.

## Migrare 087
`087_software_component_catalog.up.sql` creează `software_component_categories` și `software_component_catalog` și le prepopulează cu valorile istorice. `INSERT IGNORE` permite reluarea după eroare și nu suprascrie alegerile operatorilor. Categorii referențiate prin FK ON UPDATE CASCADE, astfel redenumirea este propagată.

**Nu rulați** migrarea `.down.sql` în producție: ar elimina definițiile manuale. Un rollback al binarului 0.21.100 nu necesită eliminarea celor două tabele.

## Compatibilitate și limitări de verificare
- Nu sunt schimbate API-urile existente ale inventarelor, mecanismul VCSA, SQL pentru Modificări, autorizarea Outline, exporturile Word/PDF/DOCX și agenții.
- Nu sunt expediate binare Go compilate sau `vendor/`. Testele Go pure, OpenAPI, JS, UI Chromium pe date simulate și verificarea arhivelor au trecut. **Compilarea integrală cu `vendor/` și testele pe MariaDB reală / datele de producție rămân necesare.**
- Unele rapoarte derivate independente (de exemplu, clasarea beneficiarilor după motorul DB) folosesc încă recunoașterea predefinită; acelea nu sunt modificate în 0.22.1.
