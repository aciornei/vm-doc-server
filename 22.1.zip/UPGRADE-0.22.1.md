# Upgrade VM-DOC Server 0.21.100 → 0.22.1

## Înainte de upgrade
1. Confirmați **sursele**: `cat VERSION` trebuie să indice `0.21.100`.
2. Efectuați backup verificat pentru MariaDB (inclusiv tabelul `schema_migrations`), configurarea `/etc/vm-doc-server/config.yaml`, binarul efectiv și sursele. Recomandat staging.
3. Verificați `systemctl cat vm-doc-server` pentru calea `ExecStart` (nu presupuneți calea executabilului instalat).

## Aplicare surse (în directorul cu Makefile și vendor/)

```bash
cd /CALE/CATRE/SURSE-VM-DOC
unzip -o /CALE/VM-DOC-UPDATE-100-221.zip -d .
cat VERSION  # 0.22.1
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi opriți serviciul, instalați **binarul compilat** în calea exactă din `ExecStart` (salvând precedentul) și reporniți:

```bash
sudo systemctl stop vm-doc-server
# Salvați și înlocuiți binarul doar în calea reală din ExecStart.
sudo systemctl start vm-doc-server
sudo journalctl -u vm-doc-server -n 70 --no-pager -l
```

Migrarea **087** se aplică automat la pornire; nu o lansați manual. Aplicația trebuie să raporteze `0.22.1` la `/version`. Faceți `Ctrl+F5` în browser.

## Verificări
- Nomenclatoare → Inventar tehnic → Componente software · catalog: 47 componente / 13 categorii inițiale.
- Editare categorie, schimbare etichetă componentă, alias, marcaj RAR → salvare și Audit.
- Raportul Componente software: aceeași componentă după redenumire, păstrarea VM-urilor/versiunilor corelate.
- RAR Anexa 6 / Produse software: `include_rar=false` omite componenta doar din RAR; filtrul PROD + Pornite funcționează; exportul Word rămâne corect.
- Pentru un produs nou (ex. Bitdefender) adăugați categorie și aliasuri **exact cum apar în datele detectate**, apoi verificați câte VM-uri apar, fără a presupune instalarea.

## Rollback
La eșec, opriți serviciul și restaurați **binarul 0.21.100** din backup. Noul binar adaugă tabele, nu modifică tabelele vechi, deci rollbackul binar este compatibil. Nu executați `087_software_component_catalog.down.sql` pe date reale fără export și plan explicit. Dacă migrarea este parțial aplicată, remedierea trebuie analizată pe log și schema DB înainte de noi încercări.
