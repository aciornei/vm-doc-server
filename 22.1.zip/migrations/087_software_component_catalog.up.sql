-- 0.22.1: catalog administrabil pentru identificarea automata a componentelor.
-- Definitiile existente sunt importate o singura data, pastrand cheile, aliasurile si ordinea.
-- Inventarele brute si asocierile VM/servicii nu sunt modificate.
CREATE TABLE IF NOT EXISTS software_component_categories (
  name VARCHAR(120) NOT NULL PRIMARY KEY,
  active TINYINT(1) NOT NULL DEFAULT 1,
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS software_component_catalog (
  component_key VARCHAR(64) NOT NULL PRIMARY KEY,
  name VARCHAR(190) NOT NULL,
  category_name VARCHAR(120) NOT NULL,
  needles_json TEXT NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  include_rar TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 1000,
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  INDEX idx_software_catalog_category (category_name,enabled,sort_order),
  CONSTRAINT fk_software_catalog_category FOREIGN KEY (category_name)
    REFERENCES software_component_categories(name)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- INSERT IGNORE: nu rescrie modificarile operatorilor la reluarea migrarii.
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Application Server',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Baze de date',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Cache / Key-Value',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Containere',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Containere / Orchestrare',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Identity',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Mail',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Messaging',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Observability',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Platformă',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Runtime',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Search / Storage',1);
INSERT IGNORE INTO software_component_categories(name,active) VALUES ('Web / Reverse Proxy',1);

INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('postgresql','PostgreSQL','Baze de date','["postgresql", "postgres"]',1,1,10);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('mongodb','MongoDB','Baze de date','["mongodb", "mongod", "mongo db", "mongo"]',1,1,20);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('mariadb','MariaDB','Baze de date','["mariadb"]',1,1,30);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('mysql','MySQL','Baze de date','["mysql"]',1,1,40);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('oracle','Oracle Database','Baze de date','["oracle database", "oracle db", "oracle xe", "oracledb"]',1,1,50);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('sqlserver','Microsoft SQL Server','Baze de date','["sql server", "sqlserver", "mssql"]',1,1,60);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('redis','Redis','Cache / Key-Value','["redis"]',1,1,70);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('memcached','Memcached','Cache / Key-Value','["memcached"]',1,1,80);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('nginx','Nginx','Web / Reverse Proxy','["nginx"]',1,1,90);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('apache','Apache HTTP Server','Web / Reverse Proxy','["apache http", "apache2", "httpd"]',1,1,100);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('iis','Microsoft IIS','Web / Reverse Proxy','["internet information services", "microsoft iis", "iis web"]',1,1,110);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('haproxy','HAProxy','Web / Reverse Proxy','["haproxy"]',1,1,120);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('tomcat','Tomcat','Application Server','["tomcat"]',1,1,130);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('wildfly','JBoss / WildFly','Application Server','["wildfly", "jboss"]',1,1,140);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('weblogic','Oracle WebLogic','Application Server','["weblogic"]',1,1,150);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('websphere','IBM WebSphere','Application Server','["websphere"]',1,1,160);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('java','Java','Runtime','["openjdk", "jdk", "jre", "java runtime", "java tm", "java se"]',1,1,170);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('dotnet','.NET','Runtime','["dotnet", ".net runtime", ".net hosting", ".net sdk", "asp.net core"]',1,1,180);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('php','PHP','Runtime','["php"]',1,1,190);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('nodejs','Node.js','Runtime','["node.js", "nodejs"]',1,1,200);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('python','Python','Runtime','["python 3", "python3", "python 2", "python2"]',1,1,210);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('rabbitmq','RabbitMQ','Messaging','["rabbitmq"]',1,1,220);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('kafka','Kafka','Messaging','["apache kafka", "kafka"]',1,1,230);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('activemq','ActiveMQ','Messaging','["activemq"]',1,1,240);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('zookeeper','ZooKeeper','Messaging','["zookeeper"]',1,1,250);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('keycloak','Keycloak','Identity','["keycloak"]',1,1,260);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('openldap','OpenLDAP','Identity','["openldap", "slapd"]',1,1,270);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('postfix','Postfix','Mail','["postfix"]',1,1,280);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('dovecot','Dovecot','Mail','["dovecot"]',1,1,290);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('docker','Docker','Containere','["docker engine", "docker-ce", "docker ce", "docker desktop", "dockerd"]',1,1,300);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('podman','Podman','Containere','["podman"]',1,1,310);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('containerd','containerd','Containere','["containerd"]',1,1,320);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('kubernetes','Kubernetes','Containere / Orchestrare','["kubernetes", "kubelet", "kubeadm"]',1,1,330);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('nodeexporter','Node Exporter','Observability','["node exporter", "node_exporter", "node-exporter"]',1,1,340);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('prometheus','Prometheus','Observability','["prometheus"]',1,1,350);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('grafana','Grafana','Observability','["grafana"]',1,1,360);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('graylog','Graylog','Observability','["graylog"]',1,1,370);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('filebeat','Filebeat','Observability','["filebeat"]',1,1,380);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('auditbeat','Auditbeat','Observability','["auditbeat"]',1,1,390);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('elasticsearch','Elasticsearch','Search / Storage','["elasticsearch"]',1,1,400);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('opensearch','OpenSearch','Search / Storage','["opensearch"]',1,1,410);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('solr','Solr','Search / Storage','["solr"]',1,1,420);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('minio','MinIO','Search / Storage','["minio"]',1,1,430);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('meilisearch','Meilisearch','Search / Storage','["meilisearch"]',1,1,440);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('vault','Vault','Platformă','["hashicorp vault", "vault"]',1,1,450);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('consul','Consul','Platformă','["hashicorp consul", "consul"]',1,1,460);
INSERT IGNORE INTO software_component_catalog(component_key,name,category_name,needles_json,enabled,include_rar,sort_order) VALUES ('sentry','Sentry','Platformă','["sentry"]',1,1,470);
