-- Rollback explicit al schemei 087 (NU se ruleaza automat in productie).
-- Inainte de rollback exportati configuratia modificata de operatori.
DROP TABLE IF EXISTS software_component_catalog;
DROP TABLE IF EXISTS software_component_categories;
