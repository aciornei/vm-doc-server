const state={user:null,csrf:'',agents:[],sources:[],vms:[],documentTemplates:[],agentFilters:{q:'',status:'',channel:'',page:1,pageSize:10},agentReleaseFilters:{q:'',channel:'',os:'',arch:'',validity:'',page:1,pageSize:10},serviceFilters:{q:'',domain:'',category:'',criticality:'',docStatus:'',common:''},vmFilters:{q:'',power:'',agent:'',sourceId:'',page:1,pageSize:10},vmHistory:{vmId:0,page:1,pageSize:10},audit:{page:1,pageSize:10,q:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:null},externalFilters:{q:'',network:'',status:'active'},externalNetworkEdit:0,nomenclaturePaging:{},nomenclatureFilters:{},reportsData:null};
const content=document.getElementById('content');
const title=document.getElementById('pageTitle');
const subtitle=document.getElementById('pageSubtitle');
const agentDialog=document.getElementById('agentDialog');
const agentForm=document.getElementById('agentForm');
const vcenterDialog=document.getElementById('vcenterDialog');
const vcenterForm=document.getElementById('vcenterForm');
const nomenclatureDialog=document.getElementById('nomenclatureDialog');
const nomenclatureForm=document.getElementById('nomenclatureForm');
const personDialog=document.getElementById('personDialog');
const personForm=document.getElementById('personForm');
const directoryDialog=document.getElementById('directoryDialog');
const directoryForm=document.getElementById('directoryForm');
const internalServiceDialog=document.getElementById('internalServiceDialog');
const internalServiceForm=document.getElementById('internalServiceForm');
const documentTemplateDialog=document.getElementById('documentTemplateDialog');
const documentTemplateForm=document.getElementById('documentTemplateForm');
const documentPreviewDialog=document.getElementById('documentPreviewDialog');

const rolePermissions={
  admin:new Set(['*']),
  operator:new Set(['dashboard.read','reports.read','agents.read','agents.manage','collections.read','collections.run','inventories.read','inventories.raw.read','vcenter.read','vcenter.manage','vms.manage','nomenclatures.read','services.read','services.manage','documents.read','documents.manage','external.read','external.manage']),
  viewer:new Set(['dashboard.read','reports.read','agents.read','collections.read','inventories.read','vcenter.read','nomenclatures.read','services.read','documents.read','external.read']),
  auditor:new Set(['dashboard.read','reports.read','agents.read','collections.read','inventories.read','inventories.raw.read','audit.read','vcenter.read','nomenclatures.read','services.read','documents.read','external.read'])
};
function can(permission){return (state.user?.roles||[]).some(role=>rolePermissions[role]?.has('*')||rolePermissions[role]?.has(permission))}

async function api(path,options={}){
  const headers={Accept:'application/json',...(options.headers||{})};
  if(options.body&&!(options.body instanceof FormData)&&!headers['Content-Type'])headers['Content-Type']='application/json';
  if(!['GET','HEAD'].includes((options.method||'GET').toUpperCase())&&state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{...options,headers});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  const type=response.headers.get('content-type')||'';
  const body=response.status===204?null:type.includes('json')?await response.json():await response.text();
  if(!response.ok)throw new Error(body?.message||body?.error||`HTTP ${response.status}`);
  return body;
}
const e=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const dt=v=>v?new Date(v).toLocaleString('ro-RO'):'—';
const badge=v=>{const text=String(v??'unknown');return `<span class="badge ${e(text.toLowerCase().replaceAll('_','-'))}">${e(text)}</span>`};
const boolText=v=>v?'Da':'Nu';
const memory=v=>v?`${(Number(v)/1024).toFixed(Number(v)>=10240?0:1)} GB`:'—';
function toast(message,error=false){const box=document.getElementById('toast');box.textContent=message;box.className=`toast show${error?' error':''}`;setTimeout(()=>box.className='toast',3200)}
function pageMeta(name,sub){title.textContent=name;subtitle.textContent=sub||''}
function panel(head,body,tools=''){return `<section class="panel"><div class="panel-header"><h2>${head}</h2><div class="toolbar">${tools}</div></div>${body}</section>`}
function empty(text){return `<div class="empty">${e(text)}</div>`}
function detail(label,value,mono=false){return `<div class="detail-item"><span>${e(label)}</span><div class="${mono?'mono':''}">${value??'—'}</div></div>`}
function jsonSections(raw){const entries=raw&&typeof raw==='object'&&!Array.isArray(raw)?Object.entries(raw):[['inventory',raw]];return `<div class="json-sections">${entries.map(([name,value])=>`<details><summary>${e(name)}</summary><pre class="json">${e(JSON.stringify(value,null,2))}</pre></details>`).join('')}</div>`}


function richTextFromPlain(value){
  const text=String(value??'').replace(/\r\n?/g,'\n');if(!text)return {version:1,blocks:[]};
  return {version:1,blocks:text.split('\n').map(line=>{let type='paragraph',content=line;if(/^\s*[-*•]\s+/.test(line)){type='bullet';content=line.replace(/^\s*[-*•]\s+/,'')}else if(/^\s*\d+[.)]\s+/.test(line)){type='number';content=line.replace(/^\s*\d+[.)]\s+/,'')}return {type,level:0,runs:content?[{text:content}]:[]}})};
}
function normalizeRichTextDocument(value,fallback=''){
  const source=value&&typeof value==='object'&&Array.isArray(value.blocks)?value:richTextFromPlain(fallback);
  return {version:1,blocks:source.blocks.slice(0,250).map(block=>({type:['bullet','number'].includes(block?.type)?block.type:'paragraph',level:Math.max(0,Math.min(4,Number(block?.level||0))),runs:Array.isArray(block?.runs)?block.runs.map(run=>({text:String(run?.text??''),bold:!!run?.bold,italic:!!run?.italic,underline:!!run?.underline})).filter(run=>run.text!==''):[]}))};
}
function richTextPlain(value,fallback=''){
  const doc=normalizeRichTextDocument(value,fallback);const counters=[0,0,0,0,0];let prevType='',prevLevel=0;
  return doc.blocks.map(block=>{let prefix='';const level=Math.max(0,Math.min(4,Number(block.level||0)));if(block.type==='bullet')prefix=`${'  '.repeat(level)}• `;else if(block.type==='number'){if(prevType!=='number'||level>prevLevel)counters[level]=0;for(let i=level+1;i<counters.length;i++)counters[i]=0;counters[level]++;prefix=`${'  '.repeat(level)}${counters[level]}. `}prevType=block.type;prevLevel=level;return prefix+block.runs.map(run=>run.text).join('')}).join('\n').trim();
}
function richTextRunHTML(run){
  let html=e(run.text).replace(/\n/g,'<br>');if(run.underline)html=`<u>${html}</u>`;if(run.italic)html=`<em>${html}</em>`;if(run.bold)html=`<strong>${html}</strong>`;return html;
}
function richTextView(value,fallback=''){
  const doc=normalizeRichTextDocument(value,fallback);if(!doc.blocks.length)return '<div class="rich-text-readonly empty-rich">—</div>';
  const counters=[0,0,0,0,0];let prevType='',prevLevel=0;
  const blocks=doc.blocks.map(block=>{const level=Math.max(0,Math.min(4,Number(block.level||0)));let marker='';if(block.type==='bullet')marker='•';else if(block.type==='number'){if(prevType!=='number'||level>prevLevel)counters[level]=0;for(let i=level+1;i<counters.length;i++)counters[i]=0;counters[level]++;marker=`${counters[level]}.`}prevType=block.type;prevLevel=level;const body=block.runs.map(richTextRunHTML).join('')||'<br>';return `<div class="rich-text-block ${e(block.type)} level-${level}">${marker?`<span class="rich-text-marker">${e(marker)}</span>`:''}<div>${body}</div></div>`}).join('');
  return `<div class="rich-text-readonly">${blocks}</div>`;
}
function appendRichRuns(parent,runs){
  for(const run of runs||[]){let node=document.createTextNode(String(run.text??''));if(run.underline){const tag=document.createElement('u');tag.append(node);node=tag}if(run.italic){const tag=document.createElement('em');tag.append(node);node=tag}if(run.bold){const tag=document.createElement('strong');tag.append(node);node=tag}parent.append(node)}
}
function setRichTextEditor(id,value,fallback=''){
  const editor=document.getElementById(id);if(!editor)return;const doc=normalizeRichTextDocument(value,fallback);editor.replaceChildren();
  let index=0;while(index<doc.blocks.length){const block=doc.blocks[index];if(block.type==='paragraph'){const p=document.createElement('p');appendRichRuns(p,block.runs);if(!block.runs.length)p.append(document.createElement('br'));editor.append(p);index++;continue}
    const type=block.type,level=block.level;const list=document.createElement(type==='number'?'ol':'ul');list.dataset.rtLevel=String(level);list.classList.add(`rt-level-${level}`);while(index<doc.blocks.length&&doc.blocks[index].type===type&&Number(doc.blocks[index].level||0)===level){const li=document.createElement('li');appendRichRuns(li,doc.blocks[index].runs);if(!doc.blocks[index].runs.length)li.append(document.createElement('br'));list.append(li);index++}editor.append(list)}
}
function richRunStyle(node,parentStyle){
  const style={...parentStyle};if(node.nodeType!==Node.ELEMENT_NODE)return style;const tag=node.tagName.toLowerCase();if(tag==='b'||tag==='strong')style.bold=true;if(tag==='i'||tag==='em')style.italic=true;if(tag==='u')style.underline=true;const css=node.style||{};if(css.fontWeight&&(['bold','600','700','800','900'].includes(css.fontWeight)||Number(css.fontWeight)>=600))style.bold=true;if(css.fontStyle==='italic')style.italic=true;if(String(css.textDecoration||css.textDecorationLine||'').includes('underline'))style.underline=true;return style;
}
function collectRichRuns(node,style={}){
  const runs=[];const push=(text,current)=>{if(text==='')return;const next={text,bold:!!current.bold,italic:!!current.italic,underline:!!current.underline};const last=runs[runs.length-1];if(last&&last.bold===next.bold&&last.italic===next.italic&&last.underline===next.underline)last.text+=next.text;else runs.push(next)};
  const walk=(current,currentStyle)=>{if(current.nodeType===Node.TEXT_NODE){push(current.nodeValue||'',currentStyle);return}if(current.nodeType!==Node.ELEMENT_NODE)return;const tag=current.tagName.toLowerCase();if(tag==='ul'||tag==='ol')return;if(tag==='br'){push('\n',currentStyle);return}const childStyle=richRunStyle(current,currentStyle);for(const child of current.childNodes)walk(child,childStyle)};
  for(const child of node.childNodes)walk(child,style);return runs.map(run=>({...run,text:run.text.replace(/\u00a0/g,' ')})).filter(run=>run.text!=='');
}
function richTextDocumentFromEditor(id){
  const editor=document.getElementById(id);if(!editor)return {version:1,blocks:[]};const blocks=[];
  const addBlock=(type,node,level=0)=>{const runs=collectRichRuns(node);blocks.push({type,level:Math.max(0,Math.min(4,Number(level||0))),runs})};
  const process=node=>{if(node.nodeType===Node.TEXT_NODE){if((node.nodeValue||'').trim()){const holder=document.createElement('span');holder.textContent=node.nodeValue;addBlock('paragraph',holder,0)}return}if(node.nodeType!==Node.ELEMENT_NODE)return;const tag=node.tagName.toLowerCase();if(tag==='ul'||tag==='ol'){const type=tag==='ol'?'number':'bullet';const explicitRaw=node.dataset.rtLevel;let level=explicitRaw!==undefined&&explicitRaw!==''?Number(explicitRaw):NaN;if(!Number.isFinite(level)){level=0;let nesting=0,parent=node.parentElement;while(parent&&parent!==editor){if(parent.matches?.('ul,ol')){nesting++;const baseRaw=parent.dataset.rtLevel;const base=baseRaw!==undefined&&baseRaw!==''?Number(baseRaw):NaN;if(Number.isFinite(base)){level=base+nesting;break}level=nesting}parent=parent.parentElement}}for(const li of [...node.children].filter(child=>child.tagName?.toLowerCase()==='li')){addBlock(type,li,level);for(const nested of [...li.children].filter(child=>['ul','ol'].includes(child.tagName?.toLowerCase())))process(nested)}return}if(tag==='p'||tag==='div'||tag==='blockquote'){addBlock('paragraph',node,0);for(const nested of [...node.children].filter(child=>['ul','ol'].includes(child.tagName?.toLowerCase())))process(nested);return}for(const child of node.childNodes)process(child)};
  for(const child of editor.childNodes)process(child);return normalizeRichTextDocument({version:1,blocks});
}
function bindRichTextToolbars(){
  document.querySelectorAll('.rich-text-toolbar [data-rich-command]').forEach(button=>button.addEventListener('mousedown',event=>{event.preventDefault();const wrapper=button.closest('[data-rich-editor]');const editor=document.getElementById(wrapper?.dataset.richEditor||'');if(!editor)return;editor.focus();document.execCommand(button.dataset.richCommand,false,null)}));
}

async function init(){
  try{
    const versionElement=document.getElementById('appVersion');
    try{const build=await api('/version');if(versionElement)versionElement.textContent=`Server ${build.version||''}`.trim()}catch{if(versionElement)versionElement.textContent='Server'}
    state.user=await api('/api/v1/auth/me');state.csrf=state.user.csrf_token;
    document.getElementById('currentUser').textContent=state.user.display_name||state.user.username;
    document.querySelector('[data-page="audit"]').hidden=!can('audit.read');
    document.querySelector('[data-page="access"]').hidden=!can('rbac.manage');
    document.querySelector('[data-page="nomenclatures"]').hidden=!can('nomenclatures.read');
    document.querySelector('[data-page="services"]').hidden=!can('services.read');
    document.querySelector('[data-page="reports"]').hidden=!can('reports.read');
    document.querySelector('[data-page="documents"]').hidden=!can('documents.read');
    document.querySelector('[data-page="external"]').hidden=!can('external.read');
    document.body.classList.remove('booting');route();
  }catch{location.href='/login'}
}

async function route(){
  const raw=(location.hash||'#dashboard').slice(1);const [page,id,section]=raw.split('/');
  document.querySelectorAll('#nav a[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
  content.innerHTML='<div class="loading">Se încarcă…</div>';
  try{
    if(page==='dashboard')await dashboard();
    else if(page==='agents')await agentsPage(id||'list');
    else if(page==='vms'&&id)await vmDetail(Number(id),section||'overview');
    else if(page==='vms')await vmsPage();
    else if(page==='services'&&id)await internalServiceDetail(Number(id));
    else if(page==='services')await internalServicesPage();
    else if(page==='external')await externalSystemsPage(id||'');
    else if(page==='nomenclatures')await nomenclaturesPage(id||'');
    else if(page==='documents')await documentsPage();
    else if(page==='reports')await reportsPage(id||'overview');
    else if(page==='audit')await auditPage();
    else if(page==='access')await accessPage();
    else location.hash='#dashboard';
  }catch(err){content.innerHTML=empty(err.message);toast(err.message,true)}
}

async function dashboard(){
  pageMeta('Dashboard','Starea centralizată a platformei');
  const d=await api('/api/v1/dashboard');
  content.innerHTML=`<div class="cards">
    <div class="card"><div class="label">VM-uri din vCenter</div><div class="value">${d.vms}</div></div>
    <div class="card"><div class="label">Agenți configurați</div><div class="value">${d.agents_total}</div></div>
    <div class="card"><div class="label">Agenți online</div><div class="value">${d.agents_online}</div></div>
    <div class="card"><div class="label">Joburi în așteptare</div><div class="value">${d.jobs_pending}</div></div>
  </div>${panel('Fluxul 0 → inventar',`<div class="detail-grid">${detail('0. vCenter','Lista completă de VM-uri')}${detail('1. Corelare','BIOS UUID / hostname unic')}${detail('2. Agent','Colectare JSON și stare')}${detail('3. Operațional','Status, servicii interne și istoric')}</div>`)}`;
}

function agentSectionNavigation(selected){
  const items=[['list','Listare agenți','Inventar, stare și colectare'],['releases','Release-uri agent','Publicare și auto-update']];
  return `<nav class="agent-section-tabs" aria-label="Secțiuni agenți">${items.map(([code,label,help])=>`<a href="#agents/${code}" class="${selected===code?'active':''}"><strong>${e(label)}</strong><small>${e(help)}</small></a>`).join('')}</nav>`;
}
function agentOSLabel(agent){const name=String(agent.os_name||'').trim(),version=String(agent.os_version||'').trim();return name?`${e(name)}${version?`<div class="muted">${e(version)}</div>`:''}`:'—'}
function agentUpdateLabel(agent){
  const u=agent?.update||{};if(!u.known)return '<span class="muted" title="Se detectează la următorul Test, Colect sau heartbeat">—</span>';
  const channel=u.channel?badge(u.channel):'<span class="muted">necunoscut</span>';
  const detail=!u.enabled?' <span class="muted">(oprit)</span>':u.state&&u.state!=='idle'&&u.state!=='current'?`<div class="muted">${e(u.state)}${u.available_version?` · ${e(u.available_version)}`:''}</div>`:'';
  return `${channel}${detail}`;
}

function agentListTable(result){
  const f=state.agentFilters;state.agents=Array.isArray(result?.items)?result.items:[];f.page=Number(result?.page||1);
  const rows=state.agents.map(a=>{const actions=[can('collections.run')?`<button class="small secondary" data-action="test" data-id="${a.id}">Test</button><button class="small" data-action="collect" data-id="${a.id}">Colect</button>`:'',can('agents.manage')?`<button class="small" data-action="update" data-id="${a.id}">Update</button><button class="small secondary" data-action="edit" data-id="${a.id}">Edit</button><button class="small danger" data-action="delete" data-id="${a.id}">Del</button>`:''].join('');return `<tr><td><strong>${e(a.name)}</strong><div class="muted mono">${e(a.base_url)}</div></td><td>${badge(a.status)}</td><td>${agentOSLabel(a)}</td><td><strong>${e(a.agent_version||'—')}</strong></td><td>${agentUpdateLabel(a)}</td><td class="mono">${e(a.agent_uuid||'—')}</td><td>${dt(a.last_contact_at)}<div class="muted">Colect: ${dt(a.last_success_at)}</div></td><td class="muted agent-error-cell">${e(a.last_error||'—')}</td><td><div class="actions agent-row-actions">${actions||'—'}</div></td></tr>`}).join('');
  const total=Number(result?.total||0),pages=Number(result?.pages||0),startRow=total?(f.page-1)*f.pageSize+1:0,endRow=Math.min(f.page*f.pageSize,total);
  const pager=`<div class="pagination"><span>Afișate ${startRow.toLocaleString('ro-RO')}–${endRow.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="agentPageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'agent-page')}</div></div>`;
  return `${rows?`<div class="table-wrap agent-table-wrap"><table><thead><tr><th>Agent</th><th>Status</th><th>OS raportat</th><th>Versiune agent</th><th>Canal update</th><th>UUID</th><th>Contact / colectare</th><th>Ultima eroare</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există agenți pentru filtrele selectate.')}${pager}`;
}
function bindAgentTableActions(scope=document){
  scope.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>agentAction(b.dataset.action,Number(b.dataset.id)));
  scope.querySelectorAll('.agent-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.agentFilters.page){state.agentFilters.page=page;loadAgentList()}}));
  document.getElementById('agentPageSize')?.addEventListener('change',event=>{state.agentFilters.pageSize=Number(event.target.value);state.agentFilters.page=1;loadAgentList()});
}
function agentQuery(includePage=true){const f=state.agentFilters,p=new URLSearchParams();if(f.q)p.set('q',f.q);if(f.status)p.set('status',f.status);if(f.channel)p.set('channel',f.channel);if(includePage){p.set('page',String(f.page));p.set('page_size',String(f.pageSize))}return p.toString()}
async function loadAgentList(){
  const area=document.getElementById('agentTableArea');if(!area)return;
  area.classList.add('is-loading');
  try{const result=await api(`/api/v1/agents?${agentQuery(true)}`);area.innerHTML=agentListTable(result);bindAgentTableActions(area);const exportLink=document.getElementById('exportAgents');if(exportLink)exportLink.href=`/api/v1/agents/export?${agentQuery(false)}`}catch(err){area.innerHTML=empty(err.message);toast(err.message,true)}finally{area.classList.remove('is-loading')}
}
function agentReleaseQuery(includePage=true){const f=state.agentReleaseFilters,p=new URLSearchParams();[['q',f.q],['channel',f.channel],['os',f.os],['arch',f.arch],['validity',f.validity]].forEach(([k,v])=>{if(v)p.set(k,v)});if(includePage){p.set('page',String(f.page));p.set('page_size',String(f.pageSize))}return p.toString()}
function releaseListTable(result){
  const f=state.agentReleaseFilters,items=Array.isArray(result?.items)?result.items:[];f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
  const rows=items.map(r=>{const actions=can('agents.manage')?`<div class="actions">${r.channel==='testing'?`<button type="button" class="small agent-release-promote" data-version="${e(r.version)}" data-os="${e(r.os)}" data-arch="${e(r.arch)}">Promovează stable</button>`:''}<button type="button" class="small danger agent-release-delete" data-version="${e(r.version)}" data-channel="${e(r.channel)}" data-os="${e(r.os)}" data-arch="${e(r.arch)}">Șterge</button></div>`:'—';return `<tr><td><strong>${e(r.version)}</strong></td><td>${badge(r.channel)}</td><td>${e(r.os)} / ${e(r.arch)}</td><td>${r.valid?badge('ready'):badge('invalid')}</td><td>${dt(r.published_at)}</td><td class="muted">${e(r.notes||'—')}</td><td>${actions}</td></tr>`}).join('');
  const total=Number(result?.total||0),pages=Number(result?.pages||0),start=total?(f.page-1)*f.pageSize+1:0,end=Math.min(f.page*f.pageSize,total);
  const pager=`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="releasePageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'release-page')}</div></div>`;
  return `${rows?`<div class="table-wrap"><table><thead><tr><th>Versiune</th><th>Canal</th><th>Platformă</th><th>Repository</th><th>Publicat</th><th>Note</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există release-uri pentru filtrele selectate.')}${pager}`;
}
function bindReleaseTableActions(scope=document){
  scope.querySelectorAll('.agent-release-promote').forEach(button=>button.addEventListener('click',()=>promoteAgentRelease(button)));
  scope.querySelectorAll('.agent-release-delete').forEach(button=>button.addEventListener('click',()=>deleteAgentRelease(button)));
  scope.querySelectorAll('.release-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.agentReleaseFilters.page){state.agentReleaseFilters.page=page;loadReleaseList()}}));
  document.getElementById('releasePageSize')?.addEventListener('change',event=>{state.agentReleaseFilters.pageSize=Number(event.target.value);state.agentReleaseFilters.page=1;loadReleaseList()});
}
async function loadReleaseList(){
  const area=document.getElementById('releaseTableArea');if(!area)return;area.classList.add('is-loading');
  try{const result=await api(`/api/v1/agent-updates/releases?${agentReleaseQuery(true)}`);area.innerHTML=releaseListTable(result);bindReleaseTableActions(area);const exportLink=document.getElementById('exportAgentReleases');if(exportLink)exportLink.href=`/api/v1/agent-updates/releases/export?${agentReleaseQuery(false)}`}catch(err){area.innerHTML=empty(err.message);toast(err.message,true)}finally{area.classList.remove('is-loading')}
}
async function agentsPage(requestedSection='list'){
  const section=['list','releases'].includes(requestedSection)?requestedSection:'list';if(section!==requestedSection)history.replaceState(null,'',`#agents/${section}`);
  pageMeta('Agenți',section==='list'?'Inventar, stare și colectare':'Publicare versiuni și auto-update');
  let workspace='';
  if(section==='list'){
    const f=state.agentFilters,result=await api(`/api/v1/agents?${agentQuery(true)}`);
    const filter=`<div class="filterbar agent-filterbar"><label><span>Căutare</span><input id="agentSearch" type="search" value="${e(f.q)}" placeholder="Nume, URL, UUID, versiune, OS, canal sau eroare"></label><label><span>Status</span><select id="agentStatusFilter"><option value="">Toate</option><option value="online" ${f.status==='online'?'selected':''}>Online</option><option value="offline" ${f.status==='offline'?'selected':''}>Offline</option><option value="unknown" ${f.status==='unknown'?'selected':''}>Necunoscut</option><option value="disabled" ${f.status==='disabled'?'selected':''}>Dezactivat</option></select></label><label><span>Canal update</span><select id="agentChannelFilter"><option value="">Toate</option><option value="stable" ${f.channel==='stable'?'selected':''}>stable</option><option value="testing" ${f.channel==='testing'?'selected':''}>testing</option><option value="unknown" ${f.channel==='unknown'?'selected':''}>Necunoscut</option></select></label><button id="clearAgentFilters" type="button" class="secondary">Resetează</button></div>`;
    const tools=`<a id="exportAgents" class="button secondary" href="/api/v1/agents/export">Export Excel</a>${can('agents.manage')?'<button id="newAgent">Adaugă agent</button>':''}`;
    workspace=panel('Lista agenților',`${filter}<div id="agentTableArea">${agentListTable(result)}</div>`,tools);
  }else{
    const f=state.agentReleaseFilters,result=await api(`/api/v1/agent-updates/releases?${agentReleaseQuery(true)}`).catch(()=>({items:[],page:1,page_size:f.pageSize,total:0,pages:0}));
    const publishForm=can('agents.manage')?`<form id="agentReleaseForm" class="form-grid upload-form agent-release-form"><label><span>Versiune</span><input name="version" required placeholder="1.3.4"></label><label><span>Canal</span><select name="channel"><option value="testing">testing</option><option value="stable">stable</option></select></label><label><span>OS</span><select name="os"><option value="linux">Linux</option><option value="windows">Windows</option></select></label><label><span>Arhitectură</span><select name="arch"><option value="amd64">amd64</option></select></label><label class="span-2"><span>Agent</span><input name="agent" type="file" required></label><label class="span-2"><span>Updater</span><input name="updater" type="file" required></label><label class="span-2"><span>Note release</span><textarea name="notes" rows="2" placeholder="Modificările acestei versiuni"></textarea></label><div class="span-2 actions"><button type="submit">Publică în repository</button></div></form>`:'<p class="muted agent-release-form">Nu ai permisiunea agents.manage.</p>';
    const addRelease=`<details class="panel collapsible-panel agent-release-publish"><summary><span><strong>Adaugă release</strong><small>Închis implicit · deschide pentru publicare</small></span><span class="collapse-indicator">▾</span></summary><div class="collapsible-panel-body">${publishForm}<p class="muted panel-note">Publică mai întâi pe testing, validează pe un VM pilot, apoi promovează în stable.</p></div></details>`;
    const filters=`<div class="filterbar release-filterbar"><label class="release-search-field"><span>Căutare</span><input id="releaseSearch" type="search" value="${e(f.q)}" placeholder="Versiune, note sau fișier"></label><label><span>Canal</span><select id="releaseChannel"><option value="">Toate</option><option value="testing" ${f.channel==='testing'?'selected':''}>testing</option><option value="stable" ${f.channel==='stable'?'selected':''}>stable</option></select></label><label><span>OS</span><select id="releaseOS"><option value="">Toate</option><option value="linux" ${f.os==='linux'?'selected':''}>Linux</option><option value="windows" ${f.os==='windows'?'selected':''}>Windows</option></select></label><label><span>Arhitectură</span><select id="releaseArch"><option value="">Toate</option><option value="amd64" ${f.arch==='amd64'?'selected':''}>amd64</option></select></label><label><span>Repository</span><select id="releaseValidity"><option value="">Toate</option><option value="valid" ${f.validity==='valid'?'selected':''}>Ready</option><option value="invalid" ${f.validity==='invalid'?'selected':''}>Invalid</option></select></label><button id="clearReleaseFilters" type="button" class="secondary">Resetează</button></div>`;
    workspace=addRelease+panel('Release-uri publicate',`${filters}<div id="releaseTableArea">${releaseListTable(result)}</div>`,`<a id="exportAgentReleases" class="button secondary" href="/api/v1/agent-updates/releases/export">Export Excel</a>`);
  }
  content.innerHTML=`<div class="agent-layout">${agentSectionNavigation(section)}<div class="nomenclature-workspace">${workspace}</div></div>`;
  if(section==='list'){
    document.getElementById('newAgent')?.addEventListener('click',()=>openAgent());bindAgentTableActions(document.getElementById('agentTableArea')||document);const exportLink=document.getElementById('exportAgents');if(exportLink)exportLink.href=`/api/v1/agents/export?${agentQuery(false)}`;
    let timer;const search=document.getElementById('agentSearch');search?.addEventListener('input',event=>{clearTimeout(timer);const value=event.target.value;timer=setTimeout(()=>{state.agentFilters.q=value.trim();state.agentFilters.page=1;loadAgentList()},300)});
    document.getElementById('agentStatusFilter')?.addEventListener('change',event=>{state.agentFilters.status=event.target.value;state.agentFilters.page=1;loadAgentList()});document.getElementById('agentChannelFilter')?.addEventListener('change',event=>{state.agentFilters.channel=event.target.value;state.agentFilters.page=1;loadAgentList()});
    document.getElementById('clearAgentFilters')?.addEventListener('click',()=>{state.agentFilters={q:'',status:'',channel:'',page:1,pageSize:10};if(search)search.value='';const status=document.getElementById('agentStatusFilter');if(status)status.value='';const channel=document.getElementById('agentChannelFilter');if(channel)channel.value='';loadAgentList();search?.focus()});
  }else{
    document.getElementById('agentReleaseForm')?.addEventListener('submit',publishAgentRelease);bindReleaseTableActions(document.getElementById('releaseTableArea')||document);const exportLink=document.getElementById('exportAgentReleases');if(exportLink)exportLink.href=`/api/v1/agent-updates/releases/export?${agentReleaseQuery(false)}`;
    let timer;document.getElementById('releaseSearch')?.addEventListener('input',event=>{clearTimeout(timer);const value=event.target.value;timer=setTimeout(()=>{state.agentReleaseFilters.q=value.trim();state.agentReleaseFilters.page=1;loadReleaseList()},300)});
    [['releaseChannel','channel'],['releaseOS','os'],['releaseArch','arch'],['releaseValidity','validity']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{state.agentReleaseFilters[key]=event.target.value;state.agentReleaseFilters.page=1;loadReleaseList()}));
    document.getElementById('clearReleaseFilters')?.addEventListener('click',()=>{state.agentReleaseFilters={q:'',channel:'',os:'',arch:'',validity:'',page:1,pageSize:10};agentsPage('releases')});
  }
}
async function publishAgentRelease(event){
  event.preventDefault();const form=event.currentTarget;const data=new FormData(form);const button=form.querySelector('button[type=submit]');if(button)button.disabled=true;
  try{const release=await api('/api/v1/agent-updates/releases',{method:'POST',body:data});toast(`Agent ${release.version} publicat pe ${release.channel}.`);form.reset();await loadReleaseList()}catch(err){toast(err.message,true)}finally{if(button)button.disabled=false}
}
async function promoteAgentRelease(button){
  const {version,os,arch}=button.dataset;if(!confirm(`Promovezi agentul ${version} ${os}/${arch} din testing în stable?`))return;
  try{await api(`/api/v1/agent-updates/releases/${encodeURIComponent(version)}/promote?os=${encodeURIComponent(os)}&arch=${encodeURIComponent(arch)}`,{method:'POST'});toast(`Agent ${version} promovat în stable.`);loadReleaseList()}catch(err){toast(err.message,true)}
}
async function deleteAgentRelease(button){
  const {version,channel,os,arch}=button.dataset;if(!confirm(`Ștergi release-ul ${version} ${channel} ${os}/${arch}?`))return;
  try{await api(`/api/v1/agent-updates/releases/${encodeURIComponent(version)}?channel=${encodeURIComponent(channel)}&os=${encodeURIComponent(os)}&arch=${encodeURIComponent(arch)}`,{method:'DELETE'});toast('Release șters.');loadReleaseList()}catch(err){toast(err.message,true)}
}
function openAgent(agent=null){
  document.getElementById('agentDialogTitle').textContent=agent?'Editare agent':'Agent nou';
  document.getElementById('agentId').value=agent?.id||'';document.getElementById('agentName').value=agent?.name||'';document.getElementById('agentURL').value=agent?.base_url||'';document.getElementById('agentToken').value='';document.getElementById('agentToken').required=!agent;
  document.getElementById('agentInterval').value=agent?.collection_interval_seconds||900;document.getElementById('agentTimeout').value=agent?.request_timeout_seconds||45;document.getElementById('agentOffline').value=agent?.offline_after_seconds||2700;document.getElementById('agentEnabled').checked=agent?.enabled??true;document.getElementById('agentVerifyTLS').checked=agent?.verify_tls??true;agentDialog.showModal();
}
async function agentAction(action,id){
  const agent=state.agents.find(a=>a.id===id);
  if(action==='edit'){openAgent(agent);return}
  if(action==='delete'){if(!confirm(`Ștergi agentul ${agent.name}? Istoricul lui va fi șters.`))return;await api(`/api/v1/agents/${id}`,{method:'DELETE'});toast('Agent șters.');loadAgentList();return}
  if(action==='update'){
    const channel=agent?.update?.channel||'canalul configurat pe agent';if(!confirm(`Forțezi verificarea și instalarea update-ului pentru ${agent.name} pe ${channel}?`))return;
    try{const u=await api(`/api/v1/agents/${id}/update`,{method:'POST'});if(u.state==='disabled')toast(`Update dezactivat pe ${agent.name}.`,true);else if(u.state==='current')toast(`${agent.name} este deja la zi (${u.current_version||agent.agent_version||'versiune curentă'}) · ${u.channel||channel}.`);else if(u.state==='installing')toast(`Update ${u.available_version||''} pornit pe ${agent.name} · ${u.channel||channel}.`);else toast(`Update ${agent.name}: ${u.state||'verificare terminată'}${u.available_version?` · ${u.available_version}`:''}.`);[1200,3500,7000,15000].forEach(delay=>setTimeout(()=>{if(location.hash.startsWith('#agents/list'))loadAgentList()},delay))}catch(err){toast(err.message,true);setTimeout(loadAgentList,800)}return
  }
  const job=await api(`/api/v1/agents/${id}/${action==='test'?'test':'collect'}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(loadAgentList,1000);
}
agentForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('agentId').value||0);
  const body={name:document.getElementById('agentName').value.trim(),base_url:document.getElementById('agentURL').value.trim(),token:document.getElementById('agentToken').value,enabled:document.getElementById('agentEnabled').checked,verify_tls:document.getElementById('agentVerifyTLS').checked,collection_interval_seconds:Number(document.getElementById('agentInterval').value),request_timeout_seconds:Number(document.getElementById('agentTimeout').value),offline_after_seconds:Number(document.getElementById('agentOffline').value)};
  if(id&&!body.token)delete body.token;
  try{await api(id?`/api/v1/agents/${id}`:'/api/v1/agents',{method:id?'PATCH':'POST',body:JSON.stringify(body)});agentDialog.close();toast(id?'Agent actualizat.':'Agent creat.');agentsPage()}catch(err){toast(err.message,true)}
});

async function vmsPage(){
  pageMeta('VM-uri','Căutare, filtrare, paginare și export din inventarul vCenter');
  const requests=[can('vcenter.read')?api('/api/v1/vcenter/sources'):Promise.resolve([]),can('vcenter.read')?api('/api/v1/vcenter/sync-runs'):Promise.resolve([])];
  const results=await Promise.all(requests);state.sources=Array.isArray(results[0])?results[0]:[];const runs=Array.isArray(results[1])?results[1]:[];
  const filters=state.vmFilters;
  const tools=`<a id="exportVMs" class="button secondary" href="/api/v1/vms/export">Export Excel</a>${can('vcenter.manage')?'<button id="syncAll">Sincronizează vCenter</button><button id="newVCenter" class="secondary">Adaugă sursă</button>':''}`;
  const sourceOptions=state.sources.map(s=>`<option value="${s.id}" ${String(filters.sourceId)===String(s.id)?'selected':''}>${e(s.name)}</option>`).join('');
  const sourceRows=state.sources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${e(s.username)}</td><td>${s.daily_sync_enabled?`Zilnic ${e(s.daily_sync_time)}`:'Manual'}</td><td>${dt(s.last_success_at)}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions">${can('vcenter.manage')?`<button class="small secondary vc-action" data-action="test" data-id="${s.id}">Test</button><button class="small vc-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary vc-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger vc-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
  const runRows=runs.slice(0,15).map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.vcenter_source_name)}</td><td>${badge(r.status)}</td><td>${r.found_count}</td><td>+${r.created_count} / ~${r.updated_count} / lipsă ${r.missing_count}</td><td>${r.linked_agent_count}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');
  const filterBody=`<div class="filterbar vm-filterbar">
    <label class="vm-search-field"><span>Căutare</span><input id="vmSearch" value="${e(filters.q)}" placeholder="Nume, hostname, OS, IP, agent sau sursă"></label>
    <label><span>Power</span><select id="vmPower"><option value="">Toate</option><option value="POWERED_ON" ${filters.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${filters.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${filters.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label>
    <label><span>Agent</span><select id="vmAgentFilter"><option value="">Toți</option><option value="configured" ${filters.agent==='configured'?'selected':''}>Asociat</option><option value="unconfigured" ${filters.agent==='unconfigured'?'selected':''}>Fără agent</option><option value="online" ${filters.agent==='online'?'selected':''}>Online</option><option value="offline" ${filters.agent==='offline'?'selected':''}>Offline</option><option value="unknown" ${filters.agent==='unknown'?'selected':''}>Necunoscut</option><option value="disabled" ${filters.agent==='disabled'?'selected':''}>Dezactivat</option></select></label>
    <label><span>Sursă</span><select id="vmSource"><option value="">Toate sursele</option>${sourceOptions}</select></label>
    <label><span>Pe pagină</span><select id="vmPageSize">${[10,25,50,100,200].map(n=>`<option value="${n}" ${Number(filters.pageSize)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <button id="clearVMFilters" class="secondary vm-clear-filter" type="button">Curăță</button>
  </div><div id="vmTableArea" class="loading">Se încarcă VM-urile…</div>`;
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Rezultate</div><div id="vmTotal" class="value">—</div></div><div class="card"><div class="label">Prezente în vCenter</div><div id="vmPresent" class="value">—</div></div><div class="card"><div class="label">Cu agent asociat</div><div id="vmWithAgent" class="value">—</div></div></div>
  ${panel('Inventar VM',filterBody,tools)}
  ${can('vcenter.read')?panel('Surse vCenter',state.sources.length?`<div class="table-wrap"><table><thead><tr><th>Sursă</th><th>Utilizator</th><th>Program</th><th>Ultima sincronizare</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse vCenter configurate.')):''}
  ${can('vcenter.read')?panel('Ultimele sincronizări',runRows?`<div class="table-wrap"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Găsite</th><th>Modificări</th><th>Agenți legați</th><th>Eroare</th></tr></thead><tbody>${runRows}</tbody></table></div>`:empty('Nu există sincronizări.')):''}`;
  document.getElementById('syncAll')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/vcenter/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări introduse în coadă.`);setTimeout(vmsPage,1200)}catch(err){toast(err.message,true)}});
  document.getElementById('newVCenter')?.addEventListener('click',()=>openVCenter());
  content.querySelectorAll('.vc-action').forEach(b=>b.onclick=()=>vcenterAction(b.dataset.action,Number(b.dataset.id)));
  bindVMFilters();
  await loadVMPage();
}

function vmQuery(includePage=true){
  const f=state.vmFilters,params=new URLSearchParams();
  if(f.q)params.set('q',f.q);if(f.power)params.set('power',f.power);if(f.agent)params.set('agent',f.agent);if(f.sourceId)params.set('source_id',f.sourceId);
  if(includePage){params.set('page',String(f.page));params.set('page_size',String(f.pageSize))}
  return params.toString();
}

function bindVMFilters(){
  let timer;
  document.getElementById('vmSearch')?.addEventListener('input',event=>{clearTimeout(timer);timer=setTimeout(()=>{state.vmFilters.q=event.target.value.trim();state.vmFilters.page=1;loadVMPage()},300)});
  const bindings={vmPower:'power',vmAgentFilter:'agent',vmSource:'sourceId'};
  Object.entries(bindings).forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{state.vmFilters[key]=event.target.value;state.vmFilters.page=1;loadVMPage()}));
  document.getElementById('vmPageSize')?.addEventListener('change',event=>{state.vmFilters.pageSize=Number(event.target.value);state.vmFilters.page=1;loadVMPage()});
  document.getElementById('clearVMFilters')?.addEventListener('click',()=>{state.vmFilters={q:'',power:'',agent:'',sourceId:'',page:1,pageSize:10};vmsPage()});
}

async function loadVMPage(){
  const area=document.getElementById('vmTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă VM-urile…';
  try{
    const result=await api(`/api/v1/vms?${vmQuery(true)}`);state.vms=Array.isArray(result?.items)?result.items:[];state.vmFilters.page=Number(result?.page||1);
    document.getElementById('vmTotal').textContent=Number(result?.total||0).toLocaleString('ro-RO');document.getElementById('vmPresent').textContent=Number(result?.present_count||0).toLocaleString('ro-RO');document.getElementById('vmWithAgent').textContent=Number(result?.with_agent_count||0).toLocaleString('ro-RO');
    const exportLink=document.getElementById('exportVMs');if(exportLink)exportLink.href=`/api/v1/vms/export?${vmQuery(false)}`;
    area.className='';area.innerHTML=renderVMPage(result);
    area.querySelectorAll('.vm-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmFilters.page){state.vmFilters.page=page;loadVMPage();area.scrollIntoView({behavior:'smooth',block:'start'})}}));
  }catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}

function renderVMPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există VM-uri pentru filtrele selectate.');
  const rows=items.map(v=>{const completion=Math.max(0,Math.min(100,Number(v.completion_percent||0)));return `<tr><td><a href="#vms/${v.id}/overview"><strong>${e(v.name)}</strong></a><div class="muted mono">${e(v.vcenter_moid)} · ${e(v.vcenter_source_name)}</div></td><td>${badge(v.power_state||'unknown')}</td><td>${v.cpu_count||'—'} / ${memory(v.memory_mib)}</td><td>${e(v.inventory_os_name||v.guest_os||'—')}<div class="muted">${e(v.inventory_os_version||'')}</div></td><td class="mono">${e(v.inventory_primary_ip||v.primary_ip||'—')}</td><td>${badge(v.agent_status)}<div class="muted">${e(v.agent_name||'Fără agent')}</div></td><td><div class="completion-cell"><strong>${completion}%</strong><div class="completion-progress"><i style="width:${completion}%"></i></div></div></td><td>${dt(v.inventory_received_at)}</td><td>${v.present_in_vcenter?badge('present'):badge('missing')}</td></tr>`}).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||10),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap vm-table-wrap"><table><thead><tr><th>VM</th><th>Power</th><th>CPU / RAM</th><th>OS</th><th>IP</th><th>Agent</th><th>Completare</th><th>Ultimul JSON</th><th>vCenter</th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons">${paginationButtons(page,Number(result.pages||1))}</div></div>`;
}

function paginationButtons(page,pages,buttonClass='vm-page'){
  if(pages<=1)return '';
  const values=new Set([1,pages,page-2,page-1,page,page+1,page+2]);const valid=[...values].filter(n=>n>=1&&n<=pages).sort((a,b)=>a-b);let previous=0,html=`<button class="small secondary ${buttonClass}" data-page="${page-1}" ${page<=1?'disabled':''}>Anterior</button>`;
  valid.forEach(n=>{if(previous&&n>previous+1)html+='<span class="pagination-gap">…</span>';html+=`<button class="small ${n===page?'':'secondary'} ${buttonClass}" data-page="${n}" ${n===page?'disabled':''}>${n}</button>`;previous=n});
  return html+`<button class="small secondary ${buttonClass}" data-page="${page+1}" ${page>=pages?'disabled':''}>Următor</button>`;
}
function pageSizeOptions(selected,values=[10,20,50,100]){return values.map(value=>`<option value="${value}" ${Number(selected)===value?'selected':''}>${value}</option>`).join('')}

function nomenclaturePageInfo(code,total){
  const stored=Number(localStorage.getItem(`vm-doc:nomenclature-page-size:${code}`)||0);
  const current=state.nomenclaturePaging[code]||{page:1,pageSize:[10,20,50,100,200].includes(stored)?stored:10};
  current.pageSize=[10,20,50,100,200].includes(Number(current.pageSize))?Number(current.pageSize):10;
  const pages=Math.max(1,Math.ceil(total/current.pageSize));
  current.page=Math.min(Math.max(1,Number(current.page)||1),pages);
  state.nomenclaturePaging[code]=current;
  const offset=(current.page-1)*current.pageSize;
  return {page:current.page,pageSize:current.pageSize,pages,total,offset,end:Math.min(offset+current.pageSize,total)};
}
function nomenclaturePagination(code,info){
  if(!info.total)return '';
  const start=info.offset+1;
  return `<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${info.end.toLocaleString('ro-RO')} din ${info.total.toLocaleString('ro-RO')}</span><div class="pagination-buttons">${paginationButtons(info.page,info.pages,'nomenclature-page')}</div></div>`;
}

function openVCenter(source=null){
  document.getElementById('vcenterDialogTitle').textContent=source?'Editare sursă vCenter':'Sursă vCenter nouă';document.getElementById('vcenterId').value=source?.id||'';document.getElementById('vcenterName').value=source?.name||'';document.getElementById('vcenterURL').value=source?.base_url||'';document.getElementById('vcenterUsername').value=source?.username||'';document.getElementById('vcenterPassword').value='';document.getElementById('vcenterPassword').required=!source;document.getElementById('vcenterSyncTime').value=source?.daily_sync_time||'05:00';document.getElementById('vcenterTLSServerName').value=source?.tls_server_name||'';document.getElementById('vcenterEnabled').checked=source?.enabled??true;document.getElementById('vcenterVerifyTLS').checked=source?.verify_tls??true;document.getElementById('vcenterDailySync').checked=source?.daily_sync_enabled??true;vcenterDialog.showModal();
}
async function vcenterAction(action,id){
  const source=state.sources.find(s=>s.id===id);
  try{
    if(action==='edit'){openVCenter(source);return}
    if(action==='delete'){if(!confirm(`Ștergi sursa ${source.name} și VM-urile sincronizate din ea?`))return;await api(`/api/v1/vcenter/sources/${id}`,{method:'DELETE'});toast('Sursă vCenter ștearsă.');vmsPage();return}
    if(action==='test'){const r=await api(`/api/v1/vcenter/sources/${id}/test`,{method:'POST'});toast(`Conexiune reușită: ${r.vm_count} VM-uri vizibile.`);return}
    if(action==='sync'){const r=await api(`/api/v1/vcenter/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea ${r.id} a fost pornită.`);setTimeout(vmsPage,1200)}
  }catch(err){toast(err.message,true)}
}
vcenterForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('vcenterId').value||0);const body={name:document.getElementById('vcenterName').value.trim(),base_url:document.getElementById('vcenterURL').value.trim(),username:document.getElementById('vcenterUsername').value.trim(),password:document.getElementById('vcenterPassword').value,enabled:document.getElementById('vcenterEnabled').checked,verify_tls:document.getElementById('vcenterVerifyTLS').checked,tls_server_name:document.getElementById('vcenterTLSServerName').value.trim(),daily_sync_enabled:document.getElementById('vcenterDailySync').checked,daily_sync_time:document.getElementById('vcenterSyncTime').value};if(id&&!body.password)delete body.password;
  try{await api(id?`/api/v1/vcenter/sources/${id}`:'/api/v1/vcenter/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});vcenterDialog.close();toast(id?'Sursă actualizată.':'Sursă creată.');vmsPage()}catch(err){toast(err.message,true)}
});

function fieldLabel(key){
  const labels={hostname:'Hostname',fqdn:'FQDN',uuid:'UUID',product_uuid:'Product UUID',machine_id:'Machine ID',pretty_name:'Denumire OS',version_id:'Versiune',primary_ip:'IP principal',boot_time:'Pornire sistem',uptime_seconds:'Uptime',status:'Stare',name:'Nume',software_name:'Software',version:'Versiune',package_name:'Pachet',package_version:'Versiune pachet',version_source:'Sursă versiune',enabled:'Activ',active:'Activ',installed:'Instalat',service:'Serviciu',port:'Port',protocol:'Protocol',address:'Adresă',mount_point:'Mount point',username:'Username',command:'Comandă'};
  if(labels[key])return labels[key];
  return String(key||'').replaceAll('_',' ').replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase());
}
function humanUptimeSeconds(raw){
  let total=Math.max(0,Math.floor(Number(raw)||0));
  const units=[['an','ani',365*24*3600],['lună','luni',30*24*3600],['zi','zile',24*3600],['oră','ore',3600],['minut','minute',60]];
  const parts=[];
  for(const [one,many,size] of units){const value=Math.floor(total/size);if(value>0){parts.push(`${value} ${value===1?one:many}`);total-=value*size}if(parts.length>=4)break}
  return parts.length?parts.join(', '):'sub un minut';
}
function inventoryItemSummary(item,index,parentKey=''){
  if(item&&typeof item==='object'&&!Array.isArray(item)){
    if(item.mount_point!==undefined&&String(item.mount_point).trim()!=='')return String(item.mount_point);
    if(item.port!==undefined&&String(item.port).trim()!=='')return `${item.port}${item.protocol?` / ${item.protocol}`:''}`;
    if(item.username!==undefined&&String(item.username).trim()!=='')return String(item.username);
    if(item.command!==undefined&&String(item.command).trim()!=='')return String(item.command).length>90?String(item.command).slice(0,87)+'…':String(item.command);
    if(item.name!==undefined&&String(item.name).trim()!=='')return String(item.name);
    if(item.path!==undefined&&String(item.path).trim()!=='')return String(item.path);
    if(item.address!==undefined&&String(item.address).trim()!=='')return String(item.address);
  }
  return `Element ${index+1}`;
}
function serviceState(item,stale=false){
  if(stale||String(item?.active_state||'').toLowerCase()==='missing')return 'missing';
  return String(item?.active_state||'').toLowerCase()==='active'?'active':'inactive';
}
function serviceStateLabel(value){return value==='active'?'<span class="badge active">Activ</span>':value==='missing'?'<span class="badge missing">Nedetectat</span>':'<span class="badge disabled">Inactiv</span>'}
function serviceInventoryList(value,context={}){
  const selected=new Set((context.primaryServices||[]).map(item=>String(item.service_name||'').toLowerCase()));
  const observed=new Set((value||[]).map(item=>String(item?.name||'').toLowerCase()));
  const stale=(context.primaryServices||[]).filter(item=>!observed.has(String(item.service_name||'').toLowerCase()));
  const rows=[...(value||[]).map(item=>({item,stale:false})),...stale.map(item=>({item:{name:item.service_name,active_state:'missing',description:'Serviciu principal nedetectat în inventarul curent'},stale:true}))]
    .sort((a,b)=>{const ap=selected.has(String(a.item?.name||'').toLowerCase())?0:1,bp=selected.has(String(b.item?.name||'').toLowerCase())?0:1;return ap-bp||String(a.item?.name||'').localeCompare(String(b.item?.name||''),'ro')});
  if(!rows.length)return '<span class="muted">Listă goală</span>';
  const filter=`<div class="filterbar service-inventory-filterbar"><label><span>Caută serviciu</span><input id="vmAgentServiceSearch" type="search" placeholder="postfix, dovecot, nginx…"></label><label><span>Stare</span><select id="vmAgentServiceStatus"><option value="active" selected>Active</option><option value="inactive">Inactive</option><option value="missing">Nedetectate</option><option value="all">Toate</option></select></label><span id="vmAgentServiceCount" class="muted"></span></div>`;
  return `${filter}<div class="structured-list service-inventory-list">${rows.map(({item,stale})=>{const name=String(item?.name||'Serviciu');const checked=selected.has(name.toLowerCase());const version=item?.version||item?.package_version||'';const status=serviceState(item,stale);const search=[name,item?.software_name,item?.description,version,item?.package_name].filter(Boolean).join(' ').toLowerCase();const checkbox=context.canManage?`<label class="primary-service-check" title="Include ca serviciu software principal în documentație"><input type="checkbox" class="primary-agent-service-toggle" data-service="${e(name)}" ${checked?'checked':''}><span>Principal</span></label>`:(checked?'<span class="badge primary">Principal</span>':'');return `<details class="service-inventory-row ${stale?'stale-primary-service':''}" data-service-status="${status}" data-service-search="${e(search)}"><summary><span class="inventory-summary-main"><strong>${e(name)}</strong> ${serviceStateLabel(status)}${version?` <span class="muted">· ${e(version)}</span>`:''}</span>${checkbox}</summary>${structuredValue(item,1,{...context,parentKey:'services'})}</details>`}).join('')}</div>`;
}
function applyServiceInventoryFilters(){
  const search=document.getElementById('vmAgentServiceSearch'),status=document.getElementById('vmAgentServiceStatus'),rows=[...document.querySelectorAll('.service-inventory-row')];if(!rows.length)return;
  const q=String(search?.value||'').trim().toLowerCase(),wanted=status?.value||'active';let shown=0;
  rows.forEach(row=>{const okStatus=wanted==='all'||row.dataset.serviceStatus===wanted,okSearch=!q||String(row.dataset.serviceSearch||'').includes(q);row.hidden=!(okStatus&&okSearch);if(!row.hidden)shown++});
  const count=document.getElementById('vmAgentServiceCount');if(count)count.textContent=`${shown} din ${rows.length}`;
}
function bindServiceInventoryFilters(){
  const search=document.getElementById('vmAgentServiceSearch'),status=document.getElementById('vmAgentServiceStatus');let timer;
  search?.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(applyServiceInventoryFilters,120)});status?.addEventListener('change',applyServiceInventoryFilters);applyServiceInventoryFilters();
}
function routesInventoryTable(value){
  const rows=Array.isArray(value)?value:[];if(!rows.length)return '<span class="muted">Nu sunt rute raportate.</span>';
  return `<div class="table-wrap inventory-table"><table><thead><tr><th>Familie</th><th>Destinație</th><th>Gateway</th><th>Interfață</th><th>Protocol</th><th>Sursă</th><th>Default</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${e(r?.family||'—')}</td><td class="mono">${e(r?.destination||'—')}</td><td class="mono">${e(r?.gateway||'—')}</td><td>${e(r?.interface||'—')}</td><td>${e(r?.protocol||'—')}</td><td class="mono">${e(r?.source||'—')}</td><td>${r?.default?badge('Da'):'Nu'}</td></tr>`).join('')}</tbody></table></div>`;
}
function firewallRuleTable(rules){
  const rows=Array.isArray(rules)?rules:[];if(!rows.length)return '<span class="muted">Nu există reguli.</span>';
  return `<div class="table-wrap inventory-table"><table><thead><tr><th>Backend</th><th>Familie</th><th>Tabel</th><th>Chain</th><th>Acțiune</th><th>Regulă</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${e(r?.backend||'—')}</td><td>${e(r?.family||'—')}</td><td>${e(r?.table||'—')}</td><td>${e(r?.chain||'—')}</td><td>${e(r?.action||'—')}</td><td class="mono pre-wrap">${e(r?.rule||'—')}</td></tr>`).join('')}</tbody></table></div>`;
}
function firewallInventory(value,context={}){
  const data=value&&typeof value==='object'?value:{},backends=Array.isArray(data.backends)?data.backends:[],rules=Array.isArray(data.rules)?data.rules:[],ufw=backends.some(v=>String(v).toLowerCase()==='ufw'),explicit=ufw?rules.filter(r=>String(r?.backend||'').toLowerCase()==='ufw'):rules.filter(r=>['firewalld','susefirewall2'].includes(String(r?.backend||'').toLowerCase())),technical=rules.filter(r=>!explicit.includes(r));
  const policies=Object.entries(data.default_policies||{});const zones=Array.isArray(data.zones)?data.zones:[];
  const summary=`<div class="detail-grid firewall-summary">${detail('Detectat',data.detected?'Da':'Nu')}${detail('Activ',data.active?'Da':'Nu')}${detail('Backend-uri',backends.length?backends.map(e).join(', '):'—')}${detail('Reguli explicite',String(explicit.length))}</div>`;
  const policyHTML=policies.length?`<div class="table-wrap inventory-table"><table><thead><tr><th>Backend / chain</th><th>Politică</th></tr></thead><tbody>${policies.map(([k,v])=>`<tr><td class="mono">${e(k)}</td><td>${e(v)}</td></tr>`).join('')}</tbody></table></div>`:'<span class="muted">Nu sunt raportate politici implicite.</span>';
  const explicitHTML=explicit.length?firewallRuleTable(explicit):empty(ufw?'Nu există reguli UFW explicite.':'Nu există reguli explicite identificate.');
  const zoneHTML=zones.length?`<details class="firewall-extra"><summary>Zone firewalld (${zones.length})</summary>${structuredValue(zones,1,{...context,parentKey:'zones'})}</details>`:'';
  const techHTML=technical.length?`<details class="firewall-technical"><summary>Reguli tehnice backend (${technical.length})</summary><p class="muted">Reguli generate de nftables/iptables/ip6tables, inclusiv lanțuri interne create de UFW. Sunt ascunse implicit pentru a nu încărca fișa VM.</p>${firewallRuleTable(technical)}</details>`:'';
  const configs=Array.isArray(data.config_files)&&data.config_files.length?`<details class="firewall-extra"><summary>Fișiere configurare (${data.config_files.length})</summary>${structuredValue(data.config_files,1,{...context,parentKey:'config_files'})}</details>`:'';
  return `${summary}<h4>Politici implicite</h4>${policyHTML}<h4>Reguli configurate explicit</h4>${explicitHTML}${zoneHTML}${techHTML}${configs}`;
}
function structuredValue(value,depth=0,context={}){
  if(value===null||value===undefined||value==='')return '<span class="muted">—</span>';
  if(context.sectionKey==='firewall'&&depth===0&&value&&typeof value==='object'&&!Array.isArray(value))return firewallInventory(value,context);
  if(typeof value==='boolean')return value?badge('active'):badge('disabled');
  if(typeof value==='number'){
    if(context.parentKey==='uptime_seconds')return `<span>${e(humanUptimeSeconds(value))}</span>`;
    return `<span>${e(value)}</span>`;
  }
  if(typeof value==='string'){
    if(context.parentKey==='uptime_seconds'&&!Number.isNaN(Number(value)))return `<span>${e(humanUptimeSeconds(value))}</span>`;
    const low=value.toLowerCase();
    if(['ok','active','enabled','running','installed','success','succeeded','online','configured'].includes(low))return badge(low);
    if(['error','failed','disabled','stopped','missing','offline','not_installed','unconfigured','timeout'].includes(low))return badge(low);
    return `<span class="${value.length>70?'pre-wrap':''}">${e(value)}</span>`;
  }
  if(Array.isArray(value)){
    if(!value.length)return '<span class="muted">Listă goală</span>';
    if(context.sectionKey==='services'&&depth===0)return serviceInventoryList(value,context);
    if(context.sectionKey==='network'&&context.parentKey==='routes')return routesInventoryTable(value);
    const primitives=value.every(item=>item===null||['string','number','boolean'].includes(typeof item));
    if(primitives)return `<div class="value-list">${value.map(item=>`<span>${structuredValue(item,depth+1,context)}</span>`).join('')}</div>`;
    return `<div class="structured-list">${value.map((item,index)=>`<details><summary>${e(inventoryItemSummary(item,index,context.parentKey))}</summary>${structuredValue(item,depth+1,context)}</details>`).join('')}</div>`;
  }
  const entries=Object.entries(value);
  if(!entries.length)return '<span class="muted">Fără date</span>';
  return `<dl class="inventory-kv ${depth>1?'nested':''}">${entries.map(([key,item])=>`<div><dt>${e(fieldLabel(key))}</dt><dd>${structuredValue(item,depth+1,{...context,parentKey:key})}</dd></div>`).join('')}</dl>`;
}
function structuredInventory(documentView,{vmID=0,primaryServices=[],canManage=false}={}){
  const sections=Array.isArray(documentView?.sections)?documentView.sections:[];
  if(!sections.length)return empty('Agentul nu a furnizat încă date structurate.');
  return `<div class="inventory-sections">${sections.map(section=>`<details class="inventory-section"><summary><span>${e(section.title||fieldLabel(section.key))}</span>${section.status?badge(section.status):''}</summary><div class="inventory-section-body">${structuredValue(section.data,0,{sectionKey:section.key,vmID,primaryServices,canManage})}</div></details>`).join('')}</div>`;
}
function categoryItems(categories,code){return (categories||[]).find(item=>item.code===code)?.items||[]}
function selectOptions(items,selected,placeholder='— Neselectat —',label=value=>value.name){return `<option value="">${e(placeholder)}</option>${(items||[]).filter(item=>item.active||Number(item.id)===Number(selected)).map(item=>`<option value="${item.id}" ${Number(selected)===Number(item.id)?'selected':''}>${e(label(item))}${item.active?'':' (inactiv)'}</option>`).join('')}`}
function multiSelectOptions(items,selected=[]){const selectedSet=new Set((selected||[]).map(Number));return (items||[]).filter(item=>item.active||selectedSet.has(Number(item.id))).map(item=>`<option value="${item.id}" ${selectedSet.has(Number(item.id))?'selected':''}>${e(item.name)}${item.active?'':' (inactiv)'}</option>`).join('')}
const enhancedMultiSelects=new WeakMap();
function destroyEnhancedMultiSelect(select){
  const current=enhancedMultiSelects.get(select);if(!current)return;
  current.cleanup?.();current.wrapper.remove();select.hidden=false;select.classList.remove('select2-lite-source');enhancedMultiSelects.delete(select);
}
function enhanceMultiSelect(select,{placeholder='Alege valorile'}={}){
  destroyEnhancedMultiSelect(select);if(!select.multiple)return;
  select.hidden=true;select.classList.add('select2-lite-source');
  const wrapper=document.createElement('div');wrapper.className='select2-lite';
  wrapper.innerHTML=`<button type="button" class="select2-lite-control" aria-haspopup="listbox" aria-expanded="false"><span class="select2-lite-values"></span><span class="select2-lite-arrow">▾</span></button><div class="select2-lite-dropdown" hidden><input type="search" class="select2-lite-search" placeholder="Caută layer…" autocomplete="off"><div class="select2-lite-options" role="listbox" aria-multiselectable="true"></div></div>`;
  select.insertAdjacentElement('afterend',wrapper);
  const control=wrapper.querySelector('.select2-lite-control'),values=wrapper.querySelector('.select2-lite-values'),dropdown=wrapper.querySelector('.select2-lite-dropdown'),search=wrapper.querySelector('.select2-lite-search'),optionsArea=wrapper.querySelector('.select2-lite-options');
  function selectedOptions(){return [...select.options].filter(option=>option.selected)}
  function renderValues(){const selected=selectedOptions();values.innerHTML=selected.length?selected.map(option=>`<span class="select2-lite-chip">${e(option.textContent)}</span>`).join(''):`<span class="select2-lite-placeholder">${e(placeholder)}</span>`}
  function renderOptions(){const query=search.value.trim().toLocaleLowerCase('ro');const options=[...select.options].filter(option=>!query||option.textContent.toLocaleLowerCase('ro').includes(query));optionsArea.innerHTML=options.length?options.map(option=>`<label class="select2-lite-option"><input type="checkbox" value="${e(option.value)}" ${option.selected?'checked':''} ${option.disabled?'disabled':''}><span>${e(option.textContent)}</span></label>`).join(''):'<div class="select2-lite-empty">Niciun rezultat</div>'}
  function setOpen(open){dropdown.hidden=!open;control.setAttribute('aria-expanded',String(open));wrapper.classList.toggle('open',open);if(open){renderOptions();setTimeout(()=>search.focus(),0)}}
  control.addEventListener('click',()=>setOpen(dropdown.hidden));
  search.addEventListener('input',renderOptions);
  optionsArea.addEventListener('change',event=>{const checkbox=event.target.closest('input[type="checkbox"]');if(!checkbox)return;const option=[...select.options].find(item=>item.value===checkbox.value);if(option)option.selected=checkbox.checked;renderValues();select.dispatchEvent(new Event('change',{bubbles:true}))});
  const outsideClick=event=>{if(!wrapper.contains(event.target))setOpen(false)};document.addEventListener('click',outsideClick);
  renderValues();enhancedMultiSelects.set(select,{wrapper,cleanup(){document.removeEventListener('click',outsideClick)},refresh(){renderValues();renderOptions()}});
}
function nomenclatureOptions(categories,code,selected){return selectOptions(categoryItems(categories,code),selected)}
const responsibilityTypes={technical_admin:'Administrator tehnic',service_owner:'Responsabil serviciu',business_owner:'Responsabil business',application_owner:'Responsabil aplicație',infrastructure_owner:'Responsabil infrastructură',security_contact:'Contact securitate',backup_contact:'Contact backup',other:'Altă responsabilitate'};
function responsibilityTypeOptions(selected){return Object.entries(responsibilityTypes).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function peopleOptions(people,selected){return `<option value="">— Alege persoana —</option>${(people||[]).filter(person=>person.active||Number(person.id)===Number(selected)).map(person=>`<option value="${person.id}" ${Number(selected)===Number(person.id)?'selected':''}>${e(person.display_name)}${person.email?` · ${e(person.email)}`:''}${person.active?'':' (inactiv)'}</option>`).join('')}`}
function responsibilityRow(item,people,index){return `<div class="responsibility-row" data-index="${index}"><label>Persoană<select class="responsibility-person">${peopleOptions(people,item?.person_id)}</select></label><label>Rol<select class="responsibility-type">${responsibilityTypeOptions(item?.responsibility_type||'technical_admin')}</select></label><label class="responsibility-notes">Detalii<input class="responsibility-note" value="${e(item?.notes||'')}" placeholder="Opțional"></label><button type="button" class="small danger remove-responsibility">Elimină</button></div>`}
function responsibilitySummary(values){if(!values?.length)return '—';return `<div class="responsibility-summary">${values.map(item=>`<div><strong>${e(item.person_name)}</strong><span>${e(responsibilityTypes[item.responsibility_type]||item.responsibility_type)}${item.person_email?` · ${e(item.person_email)}`:''}</span></div>`).join('')}</div>`}
function minutesText(value){if(value===null||value===undefined)return '—';if(value<60)return `${value} min`;if(value%1440===0)return `${value/1440} zile`;if(value%60===0)return `${value/60} ore`;return `${value} min`}
function backupSection(backup){
  const hasData=backup&&(backup.synced_at||backup.policy_name||backup.job_name||backup.source_name||backup.error_message||backup.provider==='manual');
  if(!hasData)return empty('Integrarea Veeam nu a populat încă datele de backup pentru această VM. Secțiunea este pregătită pentru sincronizarea prin API.');
  return `<div class="detail-grid">${detail('Furnizor',e(backup.provider||'veeam'))}${detail('Sursă Veeam',e(backup.source_name||'—'))}${detail('Protejată',backup.protected?badge('protected'):badge('unprotected'))}${detail('Ultimul rezultat',backup.last_result?badge(backup.last_result):'—')}${detail('Job',e(backup.job_name||'—'))}${detail('Politică',e(backup.policy_name||'—'))}${detail('Repository',e(backup.repository_name||'—'))}${detail('Restore points',backup.restore_points??'—')}${detail('Ultimul backup',dt(backup.last_backup_at))}${detail('Următoarea rulare',dt(backup.next_run_at))}${detail('RPO',minutesText(backup.rpo_minutes))}${detail('RTO',minutesText(backup.rto_minutes))}${detail('Ultima sincronizare',dt(backup.synced_at))}${detail('Eroare',e(backup.error_message||'—'))}</div>`;
}

function bytesText(value){const size=Number(value||0);if(size<1024)return `${size} B`;if(size<1024*1024)return `${(size/1024).toFixed(1)} KB`;return `${(size/1024/1024).toFixed(1)} MB`}
function documentTemplateOptions(values){return (values||[]).filter(item=>item.active).map(item=>`<option value="${item.id}" ${item.is_default?'selected':''}>${e(item.name)}${item.is_default?' · implicit':''}</option>`).join('')}
function generatedDocumentRows(values,emptyMessage='Nu a fost generată încă nicio fișă pentru acest obiect.',servicePackage=false){
  if(!values?.length)return empty(emptyMessage);
  const rows=values.map(item=>`<tr><td><strong>${e(item.document_number)}</strong><div class="muted">${e(item.file_name)}</div></td><td>${e(item.template_name||'—')}</td><td>${dt(item.generated_at)}</td><td>${e(item.generated_by_name||'sistem')}</td><td>${bytesText(item.size_bytes)}</td><td><div class="actions"><a class="button-link small secondary" href="/api/v1/documents/${item.id}/download">DOCX</a>${servicePackage?`<a class="button-link small" href="/api/v1/documents/${item.id}/package">Pachet + anexe</a>`:''}</div></td></tr>`).join('');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Document</th><th>Șablon</th><th>Generat</th><th>Autor</th><th>Mărime</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function vmDocumentsPanel(vmID,templates,generated){
  const active=(templates||[]).filter(item=>item.active);
  const generator=can('documents.manage')?(active.length?`<form id="vmDocumentForm" class="document-generation-form"><label>Șablon DOCX<select id="vmDocumentTemplate">${documentTemplateOptions(active)}</select></label><div class="document-generation-actions"><button id="previewVMDocument" type="button" class="secondary">Previzualizează datele</button><button type="submit">Generează DOCX</button></div><p class="muted">Fișa este generată din datele vCenter, datele operaționale, servicii, responsabilități, backup și inventarul curent al agentului.</p></form>`:empty('Nu există niciun șablon DOCX activ. Activează sau încarcă un șablon din meniul Documente.')):'';
  return panel('Fișe tehnice generate',`${generator}<div class="generated-documents-history">${generatedDocumentRows(generated)}</div>`,can('documents.manage')?'<a class="button-link small secondary" href="#documents">Administrează șabloanele</a>':'');
}

function serviceDocumentsPanel(serviceID,templates,generated){
  const active=(templates||[]).filter(item=>item.active);
  const generator=can('documents.manage')?(active.length?`<form id="serviceDocumentForm" class="document-generation-form service-document-generation-form"><label>Șablon DOCX<select id="serviceDocumentTemplate">${documentTemplateOptions(active)}</select></label><div class="document-generation-actions"><button id="previewServiceDocument" type="button" class="secondary">Previzualizează datele</button><button type="submit">Generează documentația</button></div><div class="service-document-options"><label><input id="serviceIncludeVMAnnexes" type="checkbox" checked> Include fișele VM ca anexe</label><label><input id="serviceRegenerateVMAnnexes" type="checkbox"> Regenerează fișele VM înainte de anexare</label></div><p class="muted">Fișa evidențiază PROD / TEST / DEV, include legături către fișele VM și poate crea un pachet ZIP cu documentația serviciului plus fișele VM asociate ca anexe.</p></form>`:empty('Nu există niciun șablon DOCX activ pentru servicii interne.')):'';
  return panel('Fișe serviciu generate',`${generator}<div class="generated-documents-history">${generatedDocumentRows(generated,'Nu a fost generată încă nicio fișă pentru acest serviciu.',true)}</div>`,can('documents.manage')?'<a class="button-link small secondary" href="#documents">Administrează șabloanele</a>':'');
}
function serviceDocumentPreviewHTML(preview){
  const warnings=(preview.warnings||[]).length?`<div class="notice warning"><strong>Observații înainte de generare</strong><ul>${preview.warnings.map(item=>`<li>${e(item)}</li>`).join('')}</ul></div>`:'';
  const sections=(preview.sections||[]).map(section=>`<section class="document-preview-section"><h3>${e(section.title)}</h3><div class="detail-grid">${(section.rows||[]).map(row=>detail(row.label,e(row.value||'—'))).join('')}</div></section>`).join('');
  return `${warnings}<div class="document-preview-meta">${detail('Serviciu',e(preview.internal_service_name))}${detail('Șablon',e(preview.template_name))}${detail('Număr propus',e(preview.document_number),true)}${detail('Data generării',dt(preview.generated_at))}</div>${sections}`;
}
function bindServiceDocumentActions(serviceID){
  const selected=()=>Number(document.getElementById('serviceDocumentTemplate')?.value||0);
  const requestBody=()=>({template_id:selected(),include_vm_annexes:!!document.getElementById('serviceIncludeVMAnnexes')?.checked,regenerate_vm_annexes:!!document.getElementById('serviceRegenerateVMAnnexes')?.checked});
  document.getElementById('previewServiceDocument')?.addEventListener('click',async()=>{const body=requestBody();if(!body.template_id){toast('Alege un șablon DOCX.',true);return}try{const preview=await api(`/api/v1/services/${serviceID}/documents/preview`,{method:'POST',body:JSON.stringify(body)});document.querySelector('#documentPreviewDialog h2').textContent='Previzualizare fișă serviciu intern';document.getElementById('documentPreviewContent').innerHTML=serviceDocumentPreviewHTML(preview);documentPreviewDialog.showModal()}catch(err){toast(err.message,true)}});
  document.getElementById('serviceDocumentForm')?.addEventListener('submit',async event=>{event.preventDefault();const body=requestBody();if(!body.template_id){toast('Alege un șablon DOCX.',true);return}const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent=body.regenerate_vm_annexes?'Se generează fișele VM…':'Se generează…';try{const generated=await api(`/api/v1/services/${serviceID}/documents`,{method:'POST',body:JSON.stringify(body)});toast(`Documentația ${generated.document_number} a fost generată.`);const link=document.createElement('a');link.href=body.include_vm_annexes?`/api/v1/documents/${generated.id}/package`:`/api/v1/documents/${generated.id}/download`;link.click();setTimeout(()=>internalServiceDetail(serviceID),700)}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Generează documentația'}});
}
function documentPreviewHTML(preview){
  const warnings=(preview.warnings||[]).length?`<div class="notice warning"><strong>Observații înainte de generare</strong><ul>${preview.warnings.map(item=>`<li>${e(item)}</li>`).join('')}</ul></div>`:'';
  const sections=(preview.sections||[]).map(section=>`<section class="document-preview-section"><h3>${e(section.title)}</h3><div class="detail-grid">${(section.rows||[]).map(row=>detail(row.label,e(row.value||'—'))).join('')}</div></section>`).join('');
  return `${warnings}<div class="document-preview-meta">${detail('VM',e(preview.vm_name))}${detail('Șablon',e(preview.template_name))}${detail('Număr propus',e(preview.document_number),true)}${detail('Data generării',dt(preview.generated_at))}</div>${sections}`;
}
function selectedDocumentTemplateID(){return Number(document.getElementById('vmDocumentTemplate')?.value||0)}
function bindVMDocumentActions(vmID){
  document.getElementById('previewVMDocument')?.addEventListener('click',async()=>{const templateID=selectedDocumentTemplateID();if(!templateID){toast('Alege un șablon DOCX.',true);return}try{const preview=await api(`/api/v1/vms/${vmID}/documents/preview`,{method:'POST',body:JSON.stringify({template_id:templateID})});document.querySelector('#documentPreviewDialog h2').textContent='Previzualizare fișă VM';document.getElementById('documentPreviewContent').innerHTML=documentPreviewHTML(preview);documentPreviewDialog.showModal()}catch(err){toast(err.message,true)}});
  document.getElementById('vmDocumentForm')?.addEventListener('submit',async event=>{event.preventDefault();const templateID=selectedDocumentTemplateID();if(!templateID){toast('Alege un șablon DOCX.',true);return}const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent='Se generează…';try{const generated=await api(`/api/v1/vms/${vmID}/documents`,{method:'POST',body:JSON.stringify({template_id:templateID})});toast(`Fișa ${generated.document_number} a fost generată.`);const link=document.createElement('a');link.href=`/api/v1/documents/${generated.id}/download`;link.click();setTimeout(()=>vmDetail(vmID),500)}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Generează DOCX'}});
}
function sortNomenclatureValues(values){return [...(values||[])].sort((left,right)=>Number(left.sort_order||0)-Number(right.sort_order||0)||String(left.name||'').localeCompare(String(right.name||''),'ro',{sensitivity:'base'}))}
const serviceUsageLabels={dedicated:'Dedicat',shared:'Partajat',dependency:'Dependență'};
function domainAssignmentOptions(categories,selected){return selectOptions(sortNomenclatureValues(categoryItems(categories,'architectural_domain')),selected,'— Alege domeniul —')}
function categoryAssignmentOptions(categories,domainID,selected){const values=sortNomenclatureValues(categoryItems(categories,'itil_category').filter(item=>Number(item.parent_id)===Number(domainID)));return selectOptions(values,selected,domainID?'— Alege categoria de serviciu —':'— Alege domeniul —')}
function serviceAssignmentOptions(services,selected){const values=[...(services||[])].sort((left,right)=>String(left.name||'').localeCompare(String(right.name||''),'ro',{sensitivity:'base'}));return `<option value="">— Alege serviciul intern —</option>${values.filter(service=>service.active||Number(service.id)===Number(selected)).map(service=>`<option value="${service.id}" ${Number(selected)===Number(service.id)?'selected':''}>${e(service.name)}${service.service_code?` · ${e(service.service_code)}`:''}${service.active?'':' (inactiv)'}</option>`).join('')}`}
function serviceUsageOptions(selected='dedicated'){return Object.entries(serviceUsageLabels).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function solutionTypeAssignmentOptions(categories,selected){return selectOptions(sortNomenclatureValues(categoryItems(categories,'solution_type')),selected,'— Alege tipul soluției —')}
function serviceAssignmentRow(item,services,categories,index){
  const domainID=item?.architectural_domain_id||'',categoryID=item?.itil_category_id||'';
  return `<article class="vm-service-assignment-card" data-index="${index}">
    <div class="vm-service-assignment-head"><div><span class="assignment-kicker">Încadrare ${index+1}</span><strong>${e(item?.internal_service_name||'Serviciu intern nou')}</strong></div><div class="assignment-head-actions"><label class="assignment-primary"><input class="assignment-primary-input" type="checkbox" ${item?.is_primary?'checked':''}><span>Asociere principală</span></label>${can('vms.manage')?'<button type="button" class="small danger remove-service-assignment">Elimină</button>':''}</div></div>
    <div class="assignment-section"><h4>Clasificare serviciu</h4><div class="assignment-grid classification-grid"><label>Domeniu arhitectural<select class="assignment-domain" required>${domainAssignmentOptions(categories,domainID)}</select></label><label>Categorie de serviciu<select class="assignment-category" required>${categoryAssignmentOptions(categories,domainID,categoryID)}</select></label><label>Serviciu intern<select class="assignment-service" required>${serviceAssignmentOptions(services,item?.internal_service_id)}</select></label></div></div>
    <div class="assignment-section"><h4>Arhitectură tehnică</h4><div class="assignment-grid technical-grid"><label>Layer arhitectural<select class="assignment-layer" required></select></label><label>Rol tehnic<select class="assignment-role" required></select></label><label>Tip soluție<select class="assignment-solution-type" required>${solutionTypeAssignmentOptions(categories,item?.solution_type_id)}</select></label></div></div>
    <div class="assignment-section assignment-context"><h4>Context</h4><div class="assignment-grid context-grid"><label>Utilizare<select class="assignment-usage">${serviceUsageOptions(item?.usage_type||'dedicated')}</select></label><label class="assignment-notes">Observații<input class="assignment-note" maxlength="1000" value="${e(item?.notes||'')}" placeholder="Rolul acestei VM în serviciu, particularități, dependențe…"></label></div></div>
  </article>`
}
function wireServiceAssignmentRow(row,services,categories,initial={}){
  const domain=row.querySelector('.assignment-domain'),category=row.querySelector('.assignment-category'),service=row.querySelector('.assignment-service'),layer=row.querySelector('.assignment-layer'),role=row.querySelector('.assignment-role');
  const layers=sortNomenclatureValues(categoryItems(categories,'layer'));
  const roles=categoryItems(categories,'technical_role');
  function fillCategories(selected=''){category.innerHTML=categoryAssignmentOptions(categories,domain.value,selected);category.disabled=!domain.value}
  function fillServices(selected=''){service.innerHTML=serviceAssignmentOptions(services,selected);service.disabled=!category.value}
  function fillLayers(selected=''){let values=layers;if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.layer_name)values=[...values,{id:Number(selected),name:`${initial.layer_name} · inactiv`,active:false}];layer.innerHTML=selectOptions(values,selected,'— Alege layer-ul —')}
  function fillRoles(selected=''){let values=sortNomenclatureValues(roles.filter(item=>(item.layer_ids||[]).some(id=>Number(id)===Number(layer.value))));if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.technical_role)values=[...values,{id:Number(selected),name:`${initial.technical_role} · nemapat`,active:false}];role.innerHTML=selectOptions(values,selected,layer.value?'— Alege rolul tehnic —':'— Alege layer-ul —');role.disabled=!layer.value}
  fillCategories(initial.itil_category_id);fillServices(initial.internal_service_id);fillLayers(initial.layer_id);fillRoles(initial.technical_role_id);
  domain.addEventListener('change',()=>{fillCategories();fillServices()});category.addEventListener('change',()=>fillServices());layer.addEventListener('change',()=>fillRoles());
  service.addEventListener('change',()=>{const title=row.querySelector('.vm-service-assignment-head strong');const selected=services.find(item=>Number(item.id)===Number(service.value));if(title)title.textContent=selected?.name||'Serviciu intern nou'});
}
function serviceAssignmentsSummary(values){
  if(!values?.length)return '<span class="muted">Niciun serviciu intern asociat.</span>';
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie</th><th>Layer / Rol tehnic</th><th>Tip soluție</th><th>Utilizare</th><th></th></tr></thead><tbody>${values.map(item=>`<tr><td><a href="#services/${item.internal_service_id}">${e(item.internal_service_name)}</a></td><td>${e(item.architectural_domain||'—')}<div class="muted">${e(item.itil_category||'—')}</div></td><td>${e(item.layer_name||'—')}<div class="muted">${e(item.technical_role||'—')}</div></td><td>${e(item.solution_type||'—')}</td><td>${e(serviceUsageLabels[item.usage_type]||item.usage_type||'—')}</td><td>${item.is_primary?badge('principal'):''}</td></tr>`).join('')}</tbody></table></div>`;
}

function vmCommonDependencies(vmID,values,services,categories){
  const commonServices=(services||[]).filter(item=>item.active&&item.is_common),types=categoryItems(categories,'dependency_type');
  const form=can('vms.manage')&&commonServices.length&&types.length?`<form id="vmDependencyForm" class="service-dependency-form vm-dependency-form"><label>Serviciu comun<select id="vmDependencyTarget" required><option value="">— Alege serviciul —</option>${commonServices.map(item=>`<option value="${item.id}">${e(item.name)}${item.implicit_global?' · GLOBAL':''}</option>`).join('')}</select></label><label>Tip dependență<select id="vmDependencyType" required>${selectOptions(types,'','— Alege tipul —')}</select></label><label>Detalii<input id="vmDependencyNotes" maxlength="1000" placeholder="Excepție specifică acestei VM"></label><button type="submit">Adaugă direct</button></form>`:'';
  const list=values?.length?`<div class="common-dependency-list">${values.map(dep=>`<div class="common-dependency-item ${dep.global?'global':''}">${nomenclatureIcon(dep.dependency_type_icon||'integration','small')}<div><a href="#services/${dep.target_service_id}"><strong>${e(dep.target_service_name)}</strong></a><span>${e(dep.dependency_type||'Serviciu comun')} · ${dep.global?'Global':dep.direct?'Direct VM':'Comun'}</span><small>${e(dep.source_label||dep.source_service_name||'Dependență directă')}${dep.target_vm_names?` · Furnizat de: ${e(dep.target_vm_names)}`:''}${dep.notes?` · ${e(dep.notes)}`:''}</small></div><div class="common-dependency-actions"><b>${dep.target_vm_count||0} VM</b>${dep.direct&&dep.id&&can('vms.manage')?`<button type="button" class="small danger delete-vm-dependency" data-id="${dep.id}">Elimină</button>`:''}</div></div>`).join('')}</div>`:empty('Nu sunt identificate dependențe către infrastructura comună.');
  return `${form}${list}`;
}
function bindVMDependencyActions(vmID){
  document.getElementById('vmDependencyForm')?.addEventListener('submit',async event=>{event.preventDefault();const target=Number(document.getElementById('vmDependencyTarget').value||0),type=Number(document.getElementById('vmDependencyType').value||0),notes=document.getElementById('vmDependencyNotes').value.trim();if(!target||!type){toast('Alege serviciul comun și tipul dependenței.',true);return}try{await api(`/api/v1/vms/${vmID}/dependencies`,{method:'POST',body:JSON.stringify({target_service_id:target,dependency_type_id:type,notes})});toast('Dependența directă a VM-ului a fost adăugată.');vmDetail(vmID)}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.delete-vm-dependency').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Elimini dependența directă de pe această VM?'))return;try{await api(`/api/v1/vms/${vmID}/dependencies/${button.dataset.id}`,{method:'DELETE'});toast('Dependența directă a fost eliminată.');vmDetail(vmID)}catch(err){toast(err.message,true)}}));
}

function bindPrimaryAgentServiceActions(vmID){
  bindServiceInventoryFilters();
  document.querySelectorAll('.primary-agent-service-toggle').forEach(input=>{
    input.addEventListener('click',event=>event.stopPropagation());
    input.addEventListener('change',async event=>{
      event.stopPropagation();
      const serviceName=input.dataset.service||'';
      try{
        await api(`/api/v1/vms/${vmID}/primary-services`,{method:'POST',body:JSON.stringify({service_name:serviceName,primary:input.checked})});
        toast(input.checked?`${serviceName} marcat ca principal.`:`${serviceName} nu mai este principal.`);
      }catch(err){input.checked=!input.checked;toast(err.message,true)}
    });
  });
}

const vmDetailSections=[
  ['overview','Rezumat'],['services','Servicii'],['operational','Operațional'],['inventory','Inventar agent'],['continuity','Continuitate'],['infrastructure','Infrastructură'],['history','Istoric']
];
function vmDetailNavigation(vmID,selected){return `<nav class="vm-detail-tabs" aria-label="Secțiuni VM">${vmDetailSections.map(([code,label])=>`<a href="#vms/${vmID}/${code}" class="${selected===code?'active':''}">${e(label)}</a>`).join('')}</nav>`}
function vmCompletion(vm,inventory,operational){
  const checks=[
    ['Agent asociat',!!vm.agent_id],['Inventar agent',!!vm.current_inventory_id],['Hostname',!!(inventory.hostname||vm.guest_hostname)],['Sistem de operare',!!(inventory.os_name||vm.guest_os)],['IP principal',!!(inventory.primary_ip||vm.primary_ip)],
    ['Mediu',!!operational.environment_id],['Status operațional',!!operational.operational_status_id],['Clasificare',!!operational.classification_id],['Scop VM',!!String(operational.purpose||'').trim()],['Serviciu intern',Array.isArray(operational.service_assignments)&&operational.service_assignments.length>0],['Responsabilitate',Array.isArray(operational.responsibilities)&&operational.responsibilities.length>0]
  ];
  const done=checks.filter(([,ok])=>ok).length,percent=Math.round(done*100/checks.length);return {percent,done,total:checks.length,missing:checks.filter(([,ok])=>!ok).map(([label])=>label)};
}
function vmCompletionHTML(value){const missing=value.missing.length?`<div class="completion-missing"><strong>De completat</strong><div>${value.missing.map(label=>`<span>${e(label)}</span>`).join('')}</div></div>`:`<div class="completion-complete">Fișa are toate câmpurile esențiale completate.</div>`;return `<div class="completion-detail"><div class="completion-score"><strong>${value.percent}%</strong><span>${value.done} din ${value.total} criterii esențiale</span></div><div class="completion-progress large"><i style="width:${value.percent}%"></i></div>${missing}</div>`}
async function vmDetail(id,requestedSection=''){
  if(Number(state.vmHistory.vmId)!==Number(id))state.vmHistory={vmId:id,page:1,pageSize:10};
  const hashParts=(location.hash||'').slice(1).split('/');const hashSection=hashParts[0]==='vms'&&Number(hashParts[1])===Number(id)?hashParts[2]:'';
  const candidate=requestedSection||hashSection||'overview';const selectedSection=vmDetailSections.some(([code])=>code===candidate)?candidate:'overview';if(candidate!==selectedSection)history.replaceState(null,'',`#vms/${id}/${selectedSection}`);
  const [data,agents,categories,people,services,documentTemplates,generatedDocuments,externalSystems,externalConnections]=await Promise.all([api(`/api/v1/vms/${id}`),can('agents.read')?api('/api/v1/agents'):Promise.resolve([]),api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true'),api('/api/v1/services?include_inactive=true'),can('documents.read')?api('/api/v1/document-templates?object_type=vm'):Promise.resolve([]),can('documents.read')?api(`/api/v1/vms/${id}/documents`):Promise.resolve([]),can('external.read')?api('/api/v1/external-systems?active=active'):Promise.resolve([]),can('external.read')?api(`/api/v1/external-connections?vm_id=${id}`):Promise.resolve([])]);
  const vm=data.vm,v=data.inventory||{},op=data.operational||{},backup=data.backup||{},documentView=data.inventory_document||{},commonDependencies=Array.isArray(data.common_dependencies)?data.common_dependencies:[],primaryServices=Array.isArray(data.primary_agent_services)?data.primary_agent_services:[];
  const warningLabels={agent_data_unavailable:'Datele agentului asociat nu au putut fi încărcate.',inventory_data_unavailable:'Inventarul curent nu a putut fi încărcat.',inventory_document_unavailable:'Inventarul curent există, dar vederea structurată nu a putut fi generată.',operational_data_unavailable:'Datele operaționale nu au putut fi încărcate.',backup_data_unavailable:'Datele de backup nu au putut fi încărcate.',common_dependencies_unavailable:'Dependențele către infrastructura comună nu au putut fi încărcate.',primary_agent_services_unavailable:'Selecția serviciilor software principale nu a putut fi încărcată.'};
  const vmWarnings=(Array.isArray(data.warnings)?data.warnings:[]).map(code=>warningLabels[code]||code),assignments=Array.isArray(op.service_assignments)?op.service_assignments:[];
  const sectionLabel=vmDetailSections.find(([code])=>code===selectedSection)?.[1]||'Rezumat';pageMeta(vm.name,`${sectionLabel} · fișă tehnică VM`);
  const agentOptions=`<option value="">Fără agent</option>${agents.map(x=>`<option value="${x.id}" ${vm.agent_id===x.id?'selected':''}>${e(x.name)} (${e(x.status)})</option>`).join('')}`;
  const documentLink=op.documentation_url?`<a href="${e(op.documentation_url)}" target="_blank" rel="noopener">${e(op.documentation_url)}</a>`:'—',initialResponsibilities=Array.isArray(op.responsibilities)?op.responsibilities:[],assignmentRows=assignments.map((item,index)=>serviceAssignmentRow(item,services,categories,index)).join(''),vmDocumentPanel=can('documents.read')?vmDocumentsPanel(id,documentTemplates,generatedDocuments):'';
  const completion=vmCompletion(vm,v,op),serverCompletion=Number(vm.completion_percent);if(Number.isFinite(serverCompletion)&&serverCompletion>=0)completion.percent=serverCompletion;
  const overview=`${panel('Identificare și încadrare',`<div class="detail-grid">${detail('Nume VM',e(vm.name))}${detail('Hostname',e(v.hostname||vm.guest_hostname||'—'),true)}${detail('IP principal',e(v.primary_ip||vm.primary_ip||'—'),true)}${detail('Sistem de operare',`${e(v.os_name||vm.guest_os||'—')} ${e(v.os_version||'')}`)}${detail('Mediu',e(op.environment||'—'))}${detail('Status operațional',op.operational_status?badge(op.operational_status):'—')}${detail('Clasificare',e(op.classification||'—'))}${detail('Responsabilități',responsibilitySummary(op.responsibilities))}${detail('Documentație',documentLink)}${detail('Referință tichet',e(op.ticket_reference||'—'))}</div>`)}${panel('Completarea fișei',vmCompletionHTML(completion),'<span class="muted">Criterii tehnice și operaționale esențiale</span>')}`;
  const servicesSection=`${panel('Servicii interne și roluri tehnice',`<form id="serviceAssignmentsForm" class="service-assignments-form"><p class="muted">Fiecare asociere descrie unde se încadrează VM-ul în serviciu: clasificare, rol tehnic, tipul soluției și modul de utilizare.</p><div id="vmServiceAssignmentRows" class="vm-service-assignment-rows">${assignmentRows}</div>${can('vms.manage')?'<div class="form-actions"><button type="button" id="addServiceAssignment" class="secondary">Adaugă asociere</button><button type="submit">Salvează asocierile</button></div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}</form>`)}${panel('Dependențe infrastructură comună',vmCommonDependencies(id,commonDependencies,services,categories),'<span class="muted">Moștenite din servicii, globale implicit sau adăugate direct pe VM</span>')}`;
  const operationalSection=panel('Date operaționale',`<form id="operationalForm" class="operational-form"><div class="form-section"><h3>Încadrare operațională</h3><div class="form-grid"><label>Mediu<select id="opEnvironment">${nomenclatureOptions(categories,'environment',op.environment_id)}</select></label><label>Status operațional<select id="opStatus">${nomenclatureOptions(categories,'operational_status',op.operational_status_id)}</select></label><label>Clasificare<select id="opClassification">${nomenclatureOptions(categories,'classification',op.classification_id)}</select></label></div><label>Scopul VM-ului<textarea id="opPurpose" rows="3">${e(op.purpose||'')}</textarea></label></div><div class="form-section"><div class="section-heading"><h3>Responsabilități</h3>${can('vms.manage')?'<button type="button" id="addResponsibility" class="small secondary">Adaugă persoană</button>':''}</div><div id="responsibilityRows" class="responsibility-rows">${initialResponsibilities.map((item,index)=>responsibilityRow(item,people,index)).join('')}</div>${!people.length?'<p class="muted">Adaugă mai întâi persoane din meniul Nomenclatoare.</p>':''}</div><div class="form-section"><h3>Referințe și observații</h3><div class="form-grid"><label class="span-2">URL documentație<input id="opDocumentation" type="url" value="${e(op.documentation_url||'')}" placeholder="https://..."></label><label>Referință tichet<input id="opTicket" value="${e(op.ticket_reference||'')}"></label></div><label>Observații<textarea id="opNotes" rows="4">${e(op.notes||'')}</textarea></label></div>${can('vms.manage')?'<div class="form-actions"><button type="submit">Salvează datele operaționale</button></div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}</form>`);
  const inventorySection=`${panel('Date colectate de agent',structuredInventory(documentView,{vmID:id,primaryServices,canManage:can('vms.manage')}),v.id&&can('inventories.raw.read')?'<button id="latestRaw" class="secondary">Vezi JSON brut</button>':'')}<section id="rawPanel"></section>`;
  const continuitySection=`${vmDocumentPanel}${panel('Backup și restaurare · Veeam',backupSection(backup),'<span class="muted">Date separate de inventarul agentului</span>')}`;
  const infrastructureSection=`${panel('Date vCenter',`<div class="detail-grid">${detail('Sursă',e(vm.vcenter_source_name))}${detail('MoID',e(vm.vcenter_moid),true)}${detail('BIOS UUID',e(vm.bios_uuid||'—'),true)}${detail('Instance UUID',e(vm.instance_uuid||'—'),true)}${detail('CPU',e(vm.cpu_count))}${detail('RAM',memory(vm.memory_mib))}${detail('Hardware',e(vm.hardware_version||'—'))}${detail('Ultima vedere',dt(vm.last_seen_at))}${detail('Guest hostname',e(vm.guest_hostname||'—'))}${detail('Guest OS',e(vm.guest_os||'—'))}${detail('IP vCenter',e(vm.primary_ip||'—'),true)}${detail('Prezentă în vCenter',boolText(vm.present_in_vcenter))}</div>`)}${panel('Asociere agent',`<form id="vmManageForm" class="detail-grid"><label><span>Agent asociat</span><select id="vmAgent">${agentOptions}</select></label>${can('vms.manage')?'<label class="form-submit"><button type="submit">Salvează</button></label>':''}</form>`,can('collections.run')&&vm.agent_id?'<button id="testVMAgent" class="secondary">Testează agentul</button><button id="collectVM">Colectează acum</button>':'')}${can('external.read')?panel('Conexiuni către sisteme externe',scopedExternalConnectionPanel('vm',id,externalConnections,externalSystems),'<a class="button-link small secondary" href="#external">Sisteme externe</a>'):''}`;
  const historySection=`${panel('Istoric inventare','<div id="inventoryHistoryArea" class="loading">Se încarcă istoricul…</div>')}<section id="rawPanel"></section>`;
  const sectionBodies={overview,services:servicesSection,operational:operationalSection,inventory:inventorySection,continuity:continuitySection,infrastructure:infrastructureSection,history:historySection};
  const warnings=vmWarnings.length?`<div class="notice warning"><strong>Fișa a fost încărcată parțial.</strong><ul>${vmWarnings.map(message=>`<li>${e(message)}</li>`).join('')}</ul><span class="muted">Detaliul tehnic este în jurnalul serviciului vm-doc-server.</span></div>`:'';
  content.innerHTML=`${warnings}<div class="cards vm-summary-cards"><div class="card"><div class="label">Completare fișă</div><div class="value compact">${completion.percent}%</div><div class="completion-progress"><i style="width:${completion.percent}%"></i></div></div><div class="card"><div class="label">Power state</div><div class="value compact">${badge(vm.power_state||'unknown')}</div></div><div class="card"><div class="label">Agent</div><div class="value compact">${badge(vm.agent_status)}</div><div class="muted">${e(vm.agent_name||'Neasociat')}</div></div><div class="card"><div class="label">Mediu</div><div class="value compact">${e(op.environment||'—')}</div></div><div class="card"><div class="label">Status operațional</div><div class="value compact">${op.operational_status?badge(op.operational_status):'—'}</div></div></div>${vmDetailNavigation(id,selectedSection)}<div class="vm-detail-workspace">${sectionBodies[selectedSection]}</div>`;

  const assignmentContainer=document.getElementById('vmServiceAssignmentRows');
  assignmentContainer?.querySelectorAll('.vm-service-assignment-card').forEach((row,index)=>wireServiceAssignmentRow(row,services,categories,assignments[index]||{}));
  document.getElementById('addServiceAssignment')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=serviceAssignmentRow(null,services,categories,assignmentContainer.children.length);const row=wrapper.firstElementChild;assignmentContainer.appendChild(row);wireServiceAssignmentRow(row,services,categories,{})});
  assignmentContainer?.addEventListener('click',event=>{const button=event.target.closest('.remove-service-assignment');if(button)button.closest('.vm-service-assignment-card').remove()});
  assignmentContainer?.addEventListener('change',event=>{if(!event.target.classList.contains('assignment-primary-input')||!event.target.checked)return;assignmentContainer.querySelectorAll('.assignment-primary-input').forEach(input=>{if(input!==event.target)input.checked=false})});
  bindVMDependencyActions(id);bindPrimaryAgentServiceActions(id);
  document.getElementById('serviceAssignmentsForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const rows=[...assignmentContainer.querySelectorAll('.vm-service-assignment-card')];const values=rows.map((row,index)=>({architectural_domain_id:Number(row.querySelector('.assignment-domain').value||0),itil_category_id:Number(row.querySelector('.assignment-category').value||0),internal_service_id:Number(row.querySelector('.assignment-service').value||0),layer_id:Number(row.querySelector('.assignment-layer').value||0),technical_role_id:Number(row.querySelector('.assignment-role').value||0),solution_type_id:Number(row.querySelector('.assignment-solution-type').value||0),usage_type:row.querySelector('.assignment-usage').value,is_primary:row.querySelector('.assignment-primary-input').checked,notes:row.querySelector('.assignment-note').value.trim(),sort_order:index}));if(values.some(item=>!item.architectural_domain_id||!item.itil_category_id||!item.internal_service_id||!item.layer_id||!item.technical_role_id||!item.solution_type_id)){toast('Completează domeniul, categoria de serviciu, serviciul intern, layer-ul, rolul tehnic și tipul soluției pentru fiecare asociere.',true);return}try{await api(`/api/v1/vms/${id}/service-assignments`,{method:'PUT',body:JSON.stringify({assignments:values})});toast('Asocierile cu serviciile interne au fost salvate.');vmDetail(id,'services')}catch(err){toast(err.message,true)}});
  const responsibilityRows=document.getElementById('responsibilityRows');document.getElementById('addResponsibility')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=responsibilityRow(null,people,responsibilityRows.children.length);responsibilityRows.appendChild(wrapper.firstElementChild)});responsibilityRows?.addEventListener('click',event=>{const button=event.target.closest('.remove-responsibility');if(button)button.closest('.responsibility-row').remove()});
  document.getElementById('operationalForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const responsibilities=[...document.querySelectorAll('.responsibility-row')].map((row,index)=>({person_id:Number(row.querySelector('.responsibility-person').value||0),responsibility_type:row.querySelector('.responsibility-type').value,notes:row.querySelector('.responsibility-note').value.trim(),sort_order:index})).filter(item=>item.person_id>0);const selected=elementId=>{const value=document.getElementById(elementId).value;return value?Number(value):null};const body={environment_id:selected('opEnvironment'),operational_status_id:selected('opStatus'),purpose:document.getElementById('opPurpose').value.trim(),responsibilities,classification_id:selected('opClassification'),documentation_url:document.getElementById('opDocumentation').value.trim(),ticket_reference:document.getElementById('opTicket').value.trim(),notes:document.getElementById('opNotes').value.trim()};try{await api(`/api/v1/vms/${id}/operational`,{method:'PUT',body:JSON.stringify(body)});toast('Datele operaționale au fost salvate.');vmDetail(id,'operational')}catch(err){toast(err.message,true)}});
  document.getElementById('vmManageForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const selected=document.getElementById('vmAgent').value;const body={};if(selected)body.agent_id=Number(selected);else if(vm.agent_id)body.clear_agent=true;try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify(body)});toast('Asocierea agentului a fost actualizată.');vmDetail(id,'infrastructure')}catch(err){toast(err.message,true)}});
  document.getElementById('testVMAgent')?.addEventListener('click',()=>vmJob(id,'test-agent'));document.getElementById('collectVM')?.addEventListener('click',()=>vmJob(id,'collect'));bindVMDocumentActions(id);
  if(can('external.read'))bindScopedExternalConnectionActions('vm',id,()=>vmDetail(id,'infrastructure'));
  document.getElementById('latestRaw')?.addEventListener('click',async()=>{try{const raw=await api(`/api/v1/inventories/${v.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${v.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}});
  if(selectedSection==='history')await loadInventoryHistory(id);
}
function bindRawInventoryButtons(scope=document){scope.querySelectorAll('.show-raw').forEach(button=>button.onclick=async()=>{try{const raw=await api(`/api/v1/inventories/${button.dataset.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${button.dataset.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}})}
function renderInventoryHistoryPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există snapshoturi pentru această VM.');
  const rows=items.map(item=>`<tr><td>${dt(item.received_at)}</td><td>${e(item.hostname)}</td><td>${e(item.os_name)} ${e(item.os_version)}</td><td>${item.collector_ok}/${item.collector_total}</td><td>${item.changed_from_previous?badge('changed'):badge('same')}</td><td>${can('inventories.raw.read')?`<button class="small secondary show-raw" data-id="${item.id}">JSON</button>`:''}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||10),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Primit</th><th>Hostname</th><th>OS</th><th>Colectori</th><th>Schimbare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="inventoryHistoryPageSize">${pageSizeOptions(pageSize,[10,20,50,100])}</select></label>${paginationButtons(page,Number(result.pages||1),'inventory-history-page')}</div></div>`;
}
async function loadInventoryHistory(vmID){
  const area=document.getElementById('inventoryHistoryArea');if(!area)return;area.className='loading';area.textContent='Se încarcă istoricul…';
  try{const result=await api(`/api/v1/vms/${vmID}/inventories?page=${state.vmHistory.page}&page_size=${state.vmHistory.pageSize}`);state.vmHistory.page=Number(result?.page||1);state.vmHistory.pageSize=Number(result?.page_size||10);area.className='';area.innerHTML=renderInventoryHistoryPage(result);bindRawInventoryButtons(area);area.querySelectorAll('.inventory-history-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmHistory.page){state.vmHistory.page=page;loadInventoryHistory(vmID)}}));document.getElementById('inventoryHistoryPageSize')?.addEventListener('change',event=>{state.vmHistory.pageSize=Number(event.target.value);state.vmHistory.page=1;loadInventoryHistory(vmID)})}catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}
async function vmJob(id,action){try{const job=await api(`/api/v1/vms/${id}/${action}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(()=>vmDetail(id),1200)}catch(err){toast(err.message,true)}}

let internalServicesCache=[];
const criticalityLabels={low:'Scăzută',normal:'Normală',high:'Ridicată',critical:'Critică'};
const documentationStatusLabels={draft:'Draft',in_progress:'În lucru',review:'În verificare',approved:'Aprobată',obsolete:'Depășită'};
function criticalityBadge(value){return badge(value||'normal')}
function openInternalService(service=null){
  document.getElementById('internalServiceDialogTitle').textContent=service?'Editare serviciu intern':'Serviciu intern nou';
  document.getElementById('internalServiceId').value=service?.id||'';
  document.getElementById('internalServiceName').value=service?.name||'';
  document.getElementById('internalServiceCode').value=service?.service_code||'';
  document.getElementById('internalServiceCriticality').value=service?.criticality||'normal';
  document.getElementById('internalServiceDocStatus').value=service?.documentation_status||'draft';
  document.getElementById('internalServiceDescription').value=service?.description||'';
  setRichTextEditor('internalServicePurposeRich',service?.purpose_richtext,service?.purpose||'');
  setRichTextEditor('internalServiceObjectivesRich',service?.objectives_richtext,service?.objectives||'');
  document.getElementById('internalServiceDocumentationURL').value=service?.documentation_url||'';
  document.getElementById('internalServiceActive').checked=service?.active??true;
  document.getElementById('internalServiceCommon').checked=!!service?.is_common;
  document.getElementById('internalServiceImplicitGlobal').checked=!!service?.implicit_global;
  const dependencyType=document.getElementById('internalServiceCommonDependencyType');dependencyType.innerHTML=selectOptions(categoryItems(nomenclatureCache,'dependency_type'),service?.common_dependency_type_id,'— Alege tipul dependenței —');
  dependencyType.disabled=!document.getElementById('internalServiceCommon').checked;
  internalServiceDialog.showModal();
}
function serviceClassificationSummary(values){
  if(!values?.length)return '<span class="muted">Neîncadrat încă</span>';
  return `<div class="service-classification-summary">${values.map(item=>`<div><strong>${e(item.architectural_domain)}</strong><span>${e(item.itil_category)} · ${item.vm_count||0} VM</span></div>`).join('')}</div>`;
}
function serviceSolutionSummary(values){
  if(!values?.length)return '<span class="muted">Nespecificat</span>';
  return `<div class="service-solution-summary">${values.map(item=>`<span>${e(item.solution_type)} <b>${item.vm_count||0}</b></span>`).join('')}</div>`;
}
function observedServiceClassifications(values){
  if(!values?.length)return empty('Domeniul și categoria de serviciu vor apărea automat după prima asociere făcută din fișa unui VM.');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Domeniu arhitectural</th><th>Categorie de serviciu</th><th>VM-uri</th><th>Asocieri</th></tr></thead><tbody>${values.map(item=>`<tr><td>${e(item.architectural_domain)}</td><td>${e(item.itil_category)}</td><td>${item.vm_count||0}</td><td>${item.assignment_count||0}</td></tr>`).join('')}</tbody></table></div>`;
}
function observedServiceRoles(values){
  if(!values?.length)return empty('Nu există încă layer-e și roluri tehnice. Acestea apar automat după asocierea VM-urilor.');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Layer</th><th>Rol tehnic</th><th>VM-uri</th><th>Stare</th></tr></thead><tbody>${values.map(mapping=>`<tr><td>${e(mapping.layer_name)}</td><td>${e(mapping.technical_role)}</td><td>${mapping.vm_count||0}</td><td>${mapping.active?badge('active'):badge('disabled')}</td></tr>`).join('')}</tbody></table></div>`;
}
function observedServiceSolutionTypes(values){
  if(!values?.length)return empty('Tipul soluției va apărea automat după ce este ales pe asocierile VM ale serviciului.');
  return `<div class="service-solution-cards">${values.map(item=>`<div class="service-solution-card"><span>${e(item.solution_type)}</span><strong>${item.vm_count||0} VM</strong><small>${item.assignment_count||0} asocieri</small></div>`).join('')}</div>`;
}
function environmentKind(value){const v=String(value||'').toLocaleLowerCase('ro-RO');if(v.includes('prod')||v.includes('produc'))return 'prod';if(v.includes('test')||v.includes('uat')||v.includes('qa'))return 'test';if(v.includes('dev')||v.includes('dezvolt'))return 'dev';return v?'other':'missing'}
function environmentBadge(value){const kind=environmentKind(value),label=value||'Nespecificat';return `<span class="environment-badge ${kind}">${e(label)}</span>`}
function serviceEnvironmentStats(values){const unique=new Map();for(const item of values||[]){if(!unique.has(Number(item.id)))unique.set(Number(item.id),item)}const stats={prod:0,test:0,dev:0,other:0,missing:0,total:unique.size,groups:new Map()};for(const vm of unique.values()){const kind=environmentKind(vm.environment);stats[kind]=(stats[kind]||0)+1;const label=vm.environment||'Nespecificat';if(!stats.groups.has(label))stats.groups.set(label,[]);stats.groups.get(label).push(vm)}return stats}
function serviceEnvironmentPanel(values){const stats=serviceEnvironmentStats(values);if(!stats.total)return empty('Nu există VM-uri asociate.');const rows=[...stats.groups.entries()].sort((a,b)=>{const order={prod:1,test:2,dev:3,other:4,missing:5};return (order[environmentKind(a[0])]||9)-(order[environmentKind(b[0])]||9)||a[0].localeCompare(b[0],'ro')}).map(([env,vms])=>`<div class="service-environment-group"><div>${environmentBadge(env)}<strong>${vms.length} VM</strong></div><span>${vms.map(vm=>`<a href="#vms/${vm.id}">${e(vm.guest_hostname||vm.name)}</a>`).join(', ')}</span></div>`).join('');const kpis=[];if(stats.prod)kpis.push(`<div class="environment-kpi prod"><span>PROD</span><strong>${stats.prod}</strong></div>`);if(stats.test)kpis.push(`<div class="environment-kpi test"><span>TEST / UAT</span><strong>${stats.test}</strong></div>`);if(stats.dev)kpis.push(`<div class="environment-kpi dev"><span>DEV</span><strong>${stats.dev}</strong></div>`);if(stats.other+stats.missing)kpis.push(`<div class="environment-kpi other"><span>Altele / lipsă</span><strong>${stats.other+stats.missing}</strong></div>`);return `<div class="service-environment-summary">${kpis.length?`<div class="service-environment-kpis">${kpis.join('')}</div>`:''}<div class="service-environment-groups">${rows}</div></div>`}
function serviceTopCards(service){const stats=serviceEnvironmentStats(service.vms),cards=[`<div class="card"><div class="label">Criticitate</div><div class="value compact">${criticalityBadge(service.criticality)}</div></div>`,`<div class="card"><div class="label">Documentație</div><div class="value compact">${badge(service.documentation_status||'draft')}</div></div>`,`<div class="card"><div class="label">VM-uri</div><div class="value">${service.vm_count||0}</div></div>`];if(service.is_common){cards.push(`<div class="card common-service-card"><div class="label">Serviciu comun</div><div class="value compact">${service.implicit_global?badge('global'):badge('common')}</div></div>`);cards.push(`<div class="card common-service-card"><div class="label">Servicii afectate</div><div class="value">${service.dependent_service_count||0}</div></div>`);if((service.direct_vm_dependents||[]).length)cards.push(`<div class="card common-service-card"><div class="label">VM direct afectate</div><div class="value">${service.direct_vm_dependents.length}</div></div>`)}if(stats.prod)cards.push(`<div class="card environment-card prod"><div class="label">PROD</div><div class="value">${stats.prod}</div></div>`);if(stats.test)cards.push(`<div class="card environment-card test"><div class="label">TEST / UAT</div><div class="value">${stats.test}</div></div>`);if(stats.dev)cards.push(`<div class="card environment-card dev"><div class="label">DEV</div><div class="value">${stats.dev}</div></div>`);return `<div class="cards service-summary-cards">${cards.join('')}</div>`}

const nomenclatureIconGlyphs={domain:'🧭',category:'🗂️',layers:'🧱',role:'⚙️',app:'🧩',database:'🗄️',web:'🌐',integration:'🔌',monitor:'📈',shield:'🛡️',package:'📦',code:'⌨️',store:'🏢',environment:'🌍',status:'●',tag:'🏷️',server:'🖥️'};
function nomenclatureIcon(key,size='normal'){
  const normalized=String(key||'').trim();const glyph=nomenclatureIconGlyphs[normalized]||'◆';
  return `<span class="nomenclature-icon ${e(size)}" title="${e(normalized||'implicit')}">${glyph}</span>`;
}
function nomenclatureItemByID(categories,id){
  const numeric=Number(id||0);for(const category of (categories||[])){const found=(category.items||[]).find(item=>Number(item.id)===numeric);if(found)return found}return null;
}
function serviceAllDependencies(service){const out=[],seen=new Set();for(const item of [...(service.dependencies||[]),...(service.global_dependencies||[])]){const key=`${item.target_service_id}:${item.dependency_type_id}`;if(seen.has(key))continue;seen.add(key);out.push(item)}return out}
function serviceDependencyStrip(service){const deps=serviceAllDependencies(service);if(!deps.length)return '';return `<section class="service-common-diagram"><header><strong>Infrastructură comună / dependențe</strong><span>${deps.length} servicii</span></header><div class="service-common-nodes">${deps.map(dep=>`<a href="#services/${dep.target_service_id}" class="service-common-node ${dep.global?'global':''}">${nomenclatureIcon(dep.dependency_type_icon||'integration','small')}<div><strong>${e(dep.target_service_name)}</strong><span>${e(dep.dependency_type)}${dep.global?' · global':''}${dep.target_vm_names?` · ${e(dep.target_vm_names)}`:''}</span></div><b>${dep.target_vm_count||0} VM</b></a>`).join('')}</div><div class="dependency-arrow">↓ dependențe externe</div></section>`}
function serviceDependenciesPanel(service,services,categories){const explicit=service.dependencies||[],global=service.global_dependencies||[],all=serviceAllDependencies(service);const rows=all.map(dep=>`<tr><td><a href="#services/${dep.target_service_id}"><strong>${e(dep.target_service_name)}</strong></a>${dep.global?'<div class="muted">Serviciu global implicit</div>':''}</td><td>${nomenclatureIcon(dep.dependency_type_icon||'integration','tiny')} ${e(dep.dependency_type)}</td><td>${dep.target_vm_count||0}${dep.target_vm_names?`<div class="muted">${e(dep.target_vm_names)}</div>`:''}</td><td>${dep.global?badge('global'):badge('common')}</td><td>${e(dep.notes||'—')}</td><td>${dep.id&&can('services.manage')?`<button class="small danger delete-service-dependency" data-id="${dep.id}">Elimină</button>`:'—'}</td></tr>`).join('');const commonServices=(services||[]).filter(item=>item.active&&item.is_common&&Number(item.id)!==Number(service.id));const types=categoryItems(categories,'dependency_type');const form=can('services.manage')&&commonServices.length&&types.length?`<form id="serviceDependencyForm" class="service-dependency-form"><label>Serviciu comun<select id="serviceDependencyTarget" required><option value="">— Alege serviciul —</option>${commonServices.map(item=>`<option value="${item.id}">${e(item.name)}${item.implicit_global?' · GLOBAL':''}</option>`).join('')}</select></label><label>Tip dependență<select id="serviceDependencyType" required>${selectOptions(types,'','— Alege tipul —')}</select></label><label>Detalii<input id="serviceDependencyNotes" maxlength="1000" placeholder="Opțional"></label><button type="submit">Adaugă dependență</button></form>`:'';return `${form}${rows?`<div class="table-wrap"><table class="compact-table"><thead><tr><th>Serviciu comun</th><th>Tip</th><th>VM-uri</th><th>Caracter</th><th>Detalii</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există dependențe comune. Serviciile marcate Global implicit vor apărea automat aici.')}`}
function bindServiceDependencyActions(serviceID){document.getElementById('serviceDependencyForm')?.addEventListener('submit',async event=>{event.preventDefault();const body={target_service_id:Number(document.getElementById('serviceDependencyTarget').value),dependency_type_id:Number(document.getElementById('serviceDependencyType').value),notes:document.getElementById('serviceDependencyNotes').value.trim()};try{await api(`/api/v1/services/${serviceID}/dependencies`,{method:'POST',body:JSON.stringify(body)});toast('Dependența a fost adăugată.');internalServiceDetail(serviceID)}catch(err){toast(err.message,true)}});document.querySelectorAll('.delete-service-dependency').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Elimini această dependență?'))return;try{await api(`/api/v1/services/${serviceID}/dependencies/${button.dataset.id}`,{method:'DELETE'});toast('Dependența a fost eliminată.');internalServiceDetail(serviceID)}catch(err){toast(err.message,true)}}))}

function serviceDependentsPanel(service){
  if(!service.is_common)return '';
  const rows=(service.dependents||[]).map(dep=>`<tr><td><a href="#services/${dep.source_service_id}"><strong>${e(dep.source_service_name)}</strong></a></td><td>${nomenclatureIcon(dep.dependency_type_icon||'integration','tiny')} ${e(dep.dependency_type)}</td><td>${e(dep.notes||'—')}</td></tr>`).join('');
  const directRows=(service.direct_vm_dependents||[]).map(dep=>`<tr><td><a href="#vms/${dep.vm_id}"><strong>${e(dep.vm_name)}</strong></a></td><td>${e(dep.dependency_type)}</td><td>${e(dep.notes||'—')}</td></tr>`).join('');
  const global=service.implicit_global?`<div class="notice info"><strong>Serviciu global implicit.</strong> Este considerat dependență pentru toate celelalte servicii active (${service.dependent_service_count||0}). Relațiile explicite de mai jos sunt păstrate doar dacă au fost declarate separat.</div>`:'';
  const serviceTable=rows?`<div class="table-wrap"><table class="compact-table"><thead><tr><th>Serviciu dependent</th><th>Tip dependență</th><th>Detalii</th></tr></thead><tbody>${rows}</tbody></table></div>`:'';
  const vmTable=directRows?`<div class="common-direct-impact"><h3>VM-uri dependente direct</h3><div class="table-wrap"><table class="compact-table"><thead><tr><th>VM</th><th>Tip dependență</th><th>Detalii</th></tr></thead><tbody>${directRows}</tbody></table></div></div>`:'';
  return `${global}${serviceTable}${vmTable}${!rows&&!directRows&&!service.implicit_global?empty('Niciun serviciu și nicio VM nu declară încă această dependență.'):''}`;
}
function serviceDiagram(service,categories){
  const assignments=service.vms||[];const dependencyStrip=serviceDependencyStrip(service);if(!assignments.length)return dependencyStrip+empty('Schema proprie va apărea după ce asociezi cel puțin un VM serviciului.');
  const byVM=new Map();
  for(const item of assignments){
    const key=Number(item.id);if(!byVM.has(key))byVM.set(key,{id:key,name:item.name,hostname:item.guest_hostname,ip:item.primary_ip,power_state:item.power_state,environment:item.environment,assignments:[]});
    byVM.get(key).assignments.push(item);
  }
  const groups=new Map();
  for(const vm of byVM.values()){
    const layers=[...new Map(vm.assignments.filter(a=>a.layer_id).map(a=>[Number(a.layer_id),{id:Number(a.layer_id),name:a.layer_name}])).values()];
    let groupKey,groupName,groupIcon;
    if(layers.length===1){groupKey=`layer-${layers[0].id}`;groupName=layers[0].name||'Layer';groupIcon=nomenclatureItemByID(categories,layers[0].id)?.icon_key||'layers'}
    else if(layers.length>1){groupKey='multi';groupName='Multi-layer';groupIcon='layers'}
    else{groupKey='none';groupName='Fără layer';groupIcon='layers'}
    if(!groups.has(groupKey))groups.set(groupKey,{name:groupName,icon:groupIcon,vms:[]});groups.get(groupKey).vms.push(vm);
  }
  const lanes=[...groups.values()].sort((a,b)=>a.name==='Multi-layer'?1:b.name==='Multi-layer'?-1:a.name.localeCompare(b.name,'ro'));
  const laneHTML=lanes.map(lane=>`<section class="service-diagram-lane"><header>${nomenclatureIcon(lane.icon)}<div><strong>${e(lane.name)}</strong><span>${lane.vms.length} VM</span></div></header><div class="service-diagram-nodes">${lane.vms.map(vm=>serviceDiagramVM(vm,categories)).join('')}</div></section>`).join('');
  return `${dependencyStrip}<div class="service-diagram-toolbar"><div><strong>Schemă generată din asocierile VM</strong><span>${byVM.size} VM unice · ${assignments.length} asocieri</span></div><div class="service-diagram-legend">${nomenclatureIcon('server','small')} VM unic ${nomenclatureIcon('role','small')} rol ${nomenclatureIcon('database','small')} layer/rol specializat</div></div><div class="service-diagram">${laneHTML}</div>`;
}
function serviceDiagramVM(vm,categories){
  const associations=vm.assignments.map(a=>{
    const layer=nomenclatureItemByID(categories,a.layer_id);const role=nomenclatureItemByID(categories,a.technical_role_id);const solution=nomenclatureItemByID(categories,a.solution_type_id);
    const icon=role?.icon_key||layer?.icon_key||'role';
    return `<div class="service-diagram-association"><div class="service-diagram-role">${nomenclatureIcon(icon,'small')}<div><strong>${e(a.technical_role||'Rol nespecificat')}</strong><span>${e(a.layer_name||'Fără layer')}</span></div></div><div class="service-diagram-tags"><span>${nomenclatureIcon(solution?.icon_key||'package','tiny')}${e(a.solution_type||'—')}</span><span>${e(a.architectural_domain||'—')} / ${e(a.itil_category||'—')}</span>${a.is_primary?'<span class="primary-tag">principal</span>':''}</div></div>`;
  }).join('');
  return `<article class="service-diagram-vm ${environmentKind(vm.environment)}"><div class="service-diagram-vm-head">${nomenclatureIcon('server')}<div><a href="#vms/${vm.id}"><strong>${e(vm.name)}</strong></a><span>${e(vm.hostname||vm.ip||'—')}</span></div><div class="service-diagram-state">${environmentBadge(vm.environment)}${badge(vm.power_state||'unknown')}</div></div><div class="service-diagram-vm-meta"><span class="mono">${e(vm.ip||'IP —')}</span><span>${vm.assignments.length} ${vm.assignments.length===1?'asociere':'asocieri'}</span></div><div class="service-diagram-associations">${associations}</div></article>`;
}
function serviceVMRows(values){
  const grouped=new Map();for(const item of values||[]){const id=Number(item.id);if(!grouped.has(id))grouped.set(id,{...item,assignments:[]});grouped.get(id).assignments.push(item)}
  return [...grouped.values()].map(vm=>{const uniq=(items,key)=>[...new Set(items.map(key).filter(Boolean))];const classifications=uniq(vm.assignments,a=>[a.architectural_domain,a.itil_category].filter(Boolean).join(' / '));const roles=uniq(vm.assignments,a=>[a.layer_name,a.technical_role].filter(Boolean).join(' / '));const solutions=uniq(vm.assignments,a=>a.solution_type);const usages=uniq(vm.assignments,a=>serviceUsageLabels[a.usage_type]||a.usage_type);return `<tr><td><a href="#vms/${vm.id}"><strong>${e(vm.name)}</strong></a><div class="muted mono">${e(vm.guest_hostname||'—')}</div></td><td>${environmentBadge(vm.environment)}</td><td class="mono">${e(vm.primary_ip||'—')}</td><td>${classifications.map(e).join('<br>')||'—'}</td><td>${roles.map(e).join('<br>')||'—'}</td><td>${solutions.map(e).join('<br>')||'—'}</td><td>${usages.map(e).join('<br>')||'—'}</td><td>${vm.latest_document_id?`<a class="button-link tiny secondary" href="/api/v1/documents/${vm.latest_document_id}/download" title="${e(vm.latest_document_number||'Fișă VM')}">${e(vm.latest_document_number||'Fișă VM')}</a><div class="muted">${vm.latest_document_at?dt(vm.latest_document_at):''}</div>`:'<span class="muted">Fără fișă</span>'}</td><td>${vm.assignments.some(a=>a.is_primary)?badge('principal'):''}</td><td>${badge(vm.power_state||'unknown')}</td></tr>`}).join('');
}
function cropText(value,limit=150){const text=String(value||'').trim().replace(/\s+/g,' ');return text.length>limit?text.slice(0,limit-1).trimEnd()+'…':text}
function serviceMatchesFilters(service,f){const q=f.q.toLocaleLowerCase('ro');if(q&&!`${service.name} ${service.service_code||''} ${service.description||''}`.toLocaleLowerCase('ro').includes(q))return false;if(f.domain&&!(service.classifications||[]).some(x=>x.architectural_domain===f.domain))return false;if(f.category&&!(service.classifications||[]).some(x=>x.itil_category===f.category))return false;if(f.criticality&&service.criticality!==f.criticality)return false;if(f.docStatus&&service.documentation_status!==f.docStatus)return false;if(f.common==='common'&&(!service.is_common||service.implicit_global))return false;if(f.common==='global'&&!service.implicit_global)return false;if(f.common==='normal'&&service.is_common)return false;return true}
function renderInternalServicesCatalog(){const f=state.serviceFilters,filtered=internalServicesCache.filter(service=>serviceMatchesFilters(service,f));const active=internalServicesCache.filter(service=>service.active).length,linkedVMs=internalServicesCache.reduce((sum,service)=>sum+Number(service.vm_count||0),0),configured=internalServicesCache.filter(service=>Number(service.role_mapping_count||0)>0).length;const domains=[...new Set(internalServicesCache.flatMap(s=>(s.classifications||[]).map(c=>c.architectural_domain)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));const categories=[...new Set(internalServicesCache.flatMap(s=>(s.classifications||[]).map(c=>c.itil_category)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));const option=(v,current)=>`<option value="${e(v)}" ${v===current?'selected':''}>${e(v)}</option>`;const rows=filtered.map(service=>`<tr><td><a href="#services/${service.id}"><strong>${e(service.name)}</strong></a>${service.is_common?` <span class="common-service-pill ${service.implicit_global?'global':''}">${service.implicit_global?'GLOBAL':'COMUN'}</span>`:''}${service.description?`<div class="muted service-description-crop" title="${e(service.description)}">${e(cropText(service.description))}</div>`:''}</td><td>${serviceClassificationSummary(service.classifications)}</td><td>${serviceSolutionSummary(service.solution_types)}</td><td class="mono">${e(service.service_code||'—')}</td><td>${criticalityBadge(service.criticality)}</td><td>${badge(service.documentation_status||'draft')}</td><td>${service.vm_count||0}</td><td>${service.dependency_count||0}</td><td>${service.active?badge('active'):badge('disabled')}</td><td><div class="actions"><a class="button-link small secondary" href="#services/${service.id}">Deschide</a>${can('services.manage')?`<button class="small secondary edit-internal-service" data-id="${service.id}">Editează</button>`:''}</div></td></tr>`).join('');const filters=`<div class="filterbar service-filterbar"><label class="service-search-field"><span>Căutare</span><input id="serviceSearch" type="search" value="${e(f.q)}" placeholder="Denumire, cod sau descriere"></label><label><span>Domeniu</span><select id="serviceDomainFilter"><option value="">Toate</option>${domains.map(v=>option(v,f.domain)).join('')}</select></label><label><span>Categorie</span><select id="serviceCategoryFilter"><option value="">Toate</option>${categories.map(v=>option(v,f.category)).join('')}</select></label><label><span>Criticitate</span><select id="serviceCriticalityFilter"><option value="">Toate</option>${Object.entries(criticalityLabels).map(([v,l])=>`<option value="${v}" ${f.criticality===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label><span>Documentație</span><select id="serviceDocFilter"><option value="">Toate</option>${Object.entries(documentationStatusLabels).map(([v,l])=>`<option value="${v}" ${f.docStatus===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label><span>Tip</span><select id="serviceCommonFilter"><option value="">Toate</option><option value="normal" ${f.common==='normal'?'selected':''}>Servicii aplicație</option><option value="common" ${f.common==='common'?'selected':''}>Servicii comune</option><option value="global" ${f.common==='global'?'selected':''}>Globale implicite</option></select></label><button id="clearServiceFilters" type="button" class="secondary">Resetează</button></div>`;content.innerHTML=`<div class="cards"><div class="card"><div class="label">Servicii definite</div><div class="value">${internalServicesCache.length}</div></div><div class="card"><div class="label">Servicii active</div><div class="value">${active}</div></div><div class="card"><div class="label">VM-uri asociate</div><div class="value">${linkedVMs}</div></div><div class="card"><div class="label">Cu roluri observate</div><div class="value">${configured}</div></div></div>${panel('Catalog servicii interne',`${filters}<div class="service-filter-summary muted">${filtered.length} din ${internalServicesCache.length} servicii</div>${rows?`<div class="table-wrap"><table><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie</th><th>Tip soluție</th><th>Cod</th><th>Criticitate</th><th>Documentație</th><th>VM-uri</th><th>Dependențe</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există servicii pentru filtrele selectate.')}`,can('services.manage')?'<button id="newInternalService">Adaugă serviciu</button>':'')}${panel('Model de încadrare','<div class="service-flow"><span>Domeniu</span><b>→</b><span>Categorie</span><b>→</b><span>Serviciu intern</span><b>→</b><span>Layer</span><b>→</b><span>Rol tehnic</span><b>→</b><span>Tip soluție</span></div><p class="muted service-flow-note">Serviciile comune (AD, DNS, LDAP, NTP etc.) sunt modelate ca dependențe și pot fi globale implicit sau asociate explicit.</p>')}`;document.getElementById('newInternalService')?.addEventListener('click',()=>openInternalService());content.querySelectorAll('.edit-internal-service').forEach(button=>button.onclick=()=>openInternalService(internalServicesCache.find(service=>service.id===Number(button.dataset.id))));let timer;document.getElementById('serviceSearch')?.addEventListener('input',event=>{clearTimeout(timer);timer=setTimeout(()=>{f.q=event.target.value.trim();renderInternalServicesCatalog()},250)});[['serviceDomainFilter','domain'],['serviceCategoryFilter','category'],['serviceCriticalityFilter','criticality'],['serviceDocFilter','docStatus'],['serviceCommonFilter','common']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{f[key]=event.target.value;renderInternalServicesCatalog()}));document.getElementById('clearServiceFilters')?.addEventListener('click',()=>{state.serviceFilters={q:'',domain:'',category:'',criticality:'',docStatus:'',common:''};renderInternalServicesCatalog()})}
async function internalServicesPage(){pageMeta('Servicii','Catalog, filtre și dependențe comune');const [services,categories]=await Promise.all([api('/api/v1/services?include_inactive=true'),api('/api/v1/nomenclatures?include_inactive=true')]);internalServicesCache=services;nomenclatureCache=categories;renderInternalServicesCatalog()}

const externalTypeLabels={vm:'VM extern',server:'Server extern',endpoint:'Endpoint',network_service:'Serviciu de rețea'};
const externalDirectionLabels={outbound:'Ieșire → extern',inbound:'Intrare ← extern',bidirectional:'Bidirecțional ↔'};
const externalZoneTypeLabels={internet:'Internet',partner:'Partener',institution:'Altă instituție',cloud:'Cloud',external_dmz:'DMZ extern',other:'Altă rețea'};
const externalRiskLabels={unknown:'Necunoscut',low:'Scăzut',medium:'Mediu',high:'Ridicat',critical:'Critic'};
const externalTrustLabels={untrusted:'Untrusted',restricted:'Restricted',trusted:'Trusted'};
function safeExternalColor(value){const v=String(value||'').trim();return /^#[0-9a-fA-F]{6}$/.test(v)?v:'#6B7280'}
function externalNetworkBadge(item){const name=item.network_name||item.name||'Neclasificat',color=safeExternalColor(item.network_color||item.color),risk=item.network_risk_level||item.risk_level||'unknown';return `<span class="external-network-badge" style="--external-color:${color}"><i></i><span>${e(name)}</span><small>${e(externalRiskLabels[risk]||risk)}</small></span>`}
function externalRiskBadge(value){const v=String(value||'unknown');return `<span class="external-risk ${e(v)}">${e(externalRiskLabels[v]||v)}</span>`}
function externalDirectionBadge(value){const direction=String(value||'outbound');return `<span class="external-direction ${e(direction)}">${e(externalDirectionLabels[direction]||direction)}</span>`}
function externalConnectionEndpoint(item){const transport=[item.protocol||'tcp',item.port||''].filter(Boolean).join('/');return `<strong>${e(item.remote_service||'—')}</strong><div class="muted mono">${e(transport||'—')}${item.tls_enabled?' · TLS':''}</div>`}
function externalConnectionTable(values,{showSource=false,manage=false}={}){
  if(!values?.length)return empty('Nu există conexiuni externe definite.');
  const rows=values.map(item=>`<tr><td><a href="#external/${item.external_system_id}"><strong>${e(item.external_system_name)}</strong></a><div class="muted mono">${e(item.external_hostname||item.external_ip_addresses||'—')}</div>${externalNetworkBadge(item)}</td>${showSource?`<td>${item.internal_service_id?`Serviciu: <strong>${e(item.internal_service_name)}</strong>`:''}${item.internal_service_id&&item.vm_id?'<br>':''}${item.vm_id?`VM: <strong>${e(item.vm_name)}</strong>`:''}</td>`:''}<td>${externalDirectionBadge(item.direction)}</td><td>${externalConnectionEndpoint(item)}</td><td>${e(item.authentication||'—')}</td><td>${e(item.purpose||'—')}</td><td>${item.active?badge('active'):badge('disabled')}</td>${manage?`<td><button class="small danger delete-external-connection" data-id="${item.id}">Șterge</button></td>`:''}</tr>`).join('');
  return `<div class="table-wrap external-connections-table"><table><thead><tr><th>Sistem extern / rețea</th>${showSource?'<th>Sursă internă</th>':''}<th>Sens</th><th>Serviciu / port</th><th>Autentificare</th><th>Scop</th><th>Stare</th>${manage?'<th></th>':''}</tr></thead><tbody>${rows}</tbody></table></div>`;
}
function scopedExternalConnectionPanel(scopeType,scopeID,connections,systems){
  const sourceLabel=scopeType==='vm'?'VM':'serviciu intern';
  const form=can('external.manage')&&systems?.length?`<form id="scopedExternalConnectionForm" class="external-connection-form">
    <label>Sistem extern<select id="externalConnectionSystem" required><option value="">— Alege —</option>${systems.filter(x=>x.active).map(x=>`<option value="${x.id}">${e(x.name)} · ${e(x.network_name||'Neclasificat')}</option>`).join('')}</select></label>
    <label>Sens<select id="externalConnectionDirection"><option value="outbound">Ieșire → extern</option><option value="inbound">Intrare ← extern</option><option value="bidirectional">Bidirecțional ↔</option></select></label>
    <label>Serviciu destinație<input id="externalConnectionRemoteService" required placeholder="HTTPS API, SMTP, LDAP…"></label>
    <label>Protocol<input id="externalConnectionProtocol" value="tcp" placeholder="tcp"></label>
    <label>Port<input id="externalConnectionPort" type="number" min="1" max="65535" placeholder="443"></label>
    <label>Autentificare<input id="externalConnectionAuth" placeholder="mTLS, Basic, OAuth2…"></label>
    <label class="span-2">Scop<input id="externalConnectionPurpose" placeholder="De ce este necesară conexiunea"></label>
    <label class="check-inline"><input id="externalConnectionTLS" type="checkbox"> TLS</label>
    <button type="submit">Adaugă conexiune</button>
  </form>`:can('external.manage')?'<p class="muted">Definește mai întâi un sistem extern.</p>':'';
  return `${form}${externalConnectionTable(connections,{manage:can('external.manage')})}<p class="muted panel-note">Sensul este privit din perspectiva infrastructurii noastre: „Ieșire” înseamnă că ${sourceLabel} inițiază conexiunea către sistemul extern.</p>`;
}
function bindScopedExternalConnectionActions(scopeType,scopeID,refresh){
  document.getElementById('scopedExternalConnectionForm')?.addEventListener('submit',async event=>{event.preventDefault();const portValue=document.getElementById('externalConnectionPort').value;const body={external_system_id:Number(document.getElementById('externalConnectionSystem').value),direction:document.getElementById('externalConnectionDirection').value,remote_service:document.getElementById('externalConnectionRemoteService').value.trim(),protocol:document.getElementById('externalConnectionProtocol').value.trim(),port:portValue?Number(portValue):null,tls_enabled:document.getElementById('externalConnectionTLS').checked,authentication:document.getElementById('externalConnectionAuth').value.trim(),purpose:document.getElementById('externalConnectionPurpose').value.trim()};body[scopeType==='vm'?'vm_id':'internal_service_id']=Number(scopeID);try{await api('/api/v1/external-connections',{method:'POST',body:JSON.stringify(body)});toast('Conexiunea externă a fost adăugată.');refresh()}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.delete-external-connection').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi această conexiune externă?'))return;try{await api(`/api/v1/external-connections/${button.dataset.id}`,{method:'DELETE'});toast('Conexiunea externă a fost ștearsă.');refresh()}catch(err){toast(err.message,true)}}));
}
async function fetchAllVMsForSelect(){let page=1,items=[];for(;;){const result=await api(`/api/v1/vms?page=${page}&page_size=200&retired=false`);items.push(...(result.items||[]));if(page>=Number(result.pages||1))break;page++}return items}
function externalNetworkForm(network){return `<form id="externalNetworkForm" class="external-system-form"><div class="form-grid">
  <label>Denumire<input id="externalNetworkName" required value="${e(network?.name||'')}"></label><label>Cod<input id="externalNetworkCode" value="${e(network?.code||'')}" placeholder="internet, partner_x"></label>
  <label>Culoare<div class="external-color-input"><input id="externalNetworkColor" type="color" value="${safeExternalColor(network?.color||'#6B7280')}"><input id="externalNetworkColorText" class="mono" value="${safeExternalColor(network?.color||'#6B7280')}" maxlength="7"></div></label>
  <label>Tip zonă<select id="externalNetworkZoneType">${Object.entries(externalZoneTypeLabels).map(([v,l])=>`<option value="${v}" ${(network?.zone_type||'other')===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
  <label>Nivel risc<select id="externalNetworkRisk">${Object.entries(externalRiskLabels).map(([v,l])=>`<option value="${v}" ${(network?.risk_level||'unknown')===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
  <label>Trust<select id="externalNetworkTrust">${Object.entries(externalTrustLabels).map(([v,l])=>`<option value="${v}" ${(network?.trust_level||'restricted')===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
  <label class="span-2">CIDR-uri / intervale IP<textarea id="externalNetworkCIDRs" rows="2" placeholder="203.0.113.0/24, 2001:db8::/32">${e(network?.cidrs||'')}</textarea></label>
  <label class="span-2">Organizație / proprietar<input id="externalNetworkOwner" value="${e(network?.owner_organization||'')}"></label>
  <label class="span-2">Descriere<textarea id="externalNetworkDescription" rows="3">${e(network?.description||'')}</textarea></label>
  <label class="span-2">Observații securitate<textarea id="externalNetworkSecurity" rows="3">${e(network?.security_notes||'')}</textarea></label>
  </div><div class="checks"><label><input id="externalNetworkActive" type="checkbox" ${network?.active===false?'':'checked'}> Activ</label></div><div class="form-actions"><button type="submit">${network?'Salvează rețeaua':'Adaugă rețea'}</button>${network?'<button id="cancelExternalNetworkEdit" type="button" class="secondary">Renunță</button>':''}</div></form>`}
function readExternalNetworkForm(){return {name:document.getElementById('externalNetworkName').value.trim(),code:document.getElementById('externalNetworkCode').value.trim(),color:document.getElementById('externalNetworkColorText').value.trim(),zone_type:document.getElementById('externalNetworkZoneType').value,risk_level:document.getElementById('externalNetworkRisk').value,trust_level:document.getElementById('externalNetworkTrust').value,cidrs:document.getElementById('externalNetworkCIDRs').value.trim(),owner_organization:document.getElementById('externalNetworkOwner').value.trim(),description:document.getElementById('externalNetworkDescription').value.trim(),security_notes:document.getElementById('externalNetworkSecurity').value.trim(),active:document.getElementById('externalNetworkActive').checked}}
function bindExternalNetworkForm(network){const color=document.getElementById('externalNetworkColor'),text=document.getElementById('externalNetworkColorText');color?.addEventListener('input',()=>text.value=color.value.toUpperCase());text?.addEventListener('input',()=>{if(/^#[0-9a-fA-F]{6}$/.test(text.value))color.value=text.value});document.getElementById('externalNetworkForm')?.addEventListener('submit',async event=>{event.preventDefault();try{await api(network?`/api/v1/external-networks/${network.id}`:'/api/v1/external-networks',{method:network?'PATCH':'POST',body:JSON.stringify(readExternalNetworkForm())});toast(network?'Rețeaua externă a fost actualizată.':'Rețeaua externă a fost adăugată.');state.externalNetworkEdit=0;externalSystemsPage('networks')}catch(err){toast(err.message,true)}});document.getElementById('cancelExternalNetworkEdit')?.addEventListener('click',()=>{state.externalNetworkEdit=0;externalSystemsPage('networks')})}
function externalSystemForm(system,networks){return `<form id="externalSystemForm" class="external-system-form">
  <div class="form-grid"><label>Denumire<input id="externalSystemName" required value="${e(system?.name||'')}"></label><label>Tip<select id="externalSystemType"><option value="vm" ${system?.system_type==='vm'?'selected':''}>VM extern</option><option value="server" ${system?.system_type==='server'?'selected':''}>Server extern</option><option value="endpoint" ${system?.system_type==='endpoint'?'selected':''}>Endpoint</option><option value="network_service" ${system?.system_type==='network_service'?'selected':''}>Serviciu de rețea</option></select></label><label>Rețea externă<select id="externalSystemNetwork"><option value="">Neclasificat</option>${networks.filter(n=>n.active||Number(n.id)===Number(system?.network_id)).map(n=>`<option value="${n.id}" ${Number(system?.network_id)===Number(n.id)?'selected':''}>${e(n.name)} · ${e(externalRiskLabels[n.risk_level]||n.risk_level)}</option>`).join('')}</select></label><label>Hostname / FQDN<input id="externalSystemHostname" value="${e(system?.hostname||'')}"></label><label class="span-2">IP-uri<input id="externalSystemIPs" value="${e(system?.ip_addresses||'')}" placeholder="10.10.10.5, 2001:db8::5"></label><label>Organizație / proprietar<input id="externalSystemOwner" value="${e(system?.owner_organization||'')}"></label><label>URL documentație<input id="externalSystemDocumentation" type="url" value="${e(system?.documentation_url||'')}"></label></div>
  <label>Descriere<textarea id="externalSystemDescription" rows="3">${e(system?.description||'')}</textarea></label><div class="checks"><label><input id="externalSystemActive" type="checkbox" ${system?.active===false?'':'checked'}> Activ</label></div><div class="form-actions"><button type="submit">${system?'Salvează modificările':'Adaugă sistemul'}</button></div></form>`}
function readExternalSystemForm(){const network=document.getElementById('externalSystemNetwork').value;return {name:document.getElementById('externalSystemName').value.trim(),system_type:document.getElementById('externalSystemType').value,network_id:network?Number(network):null,hostname:document.getElementById('externalSystemHostname').value.trim(),ip_addresses:document.getElementById('externalSystemIPs').value.trim(),owner_organization:document.getElementById('externalSystemOwner').value.trim(),documentation_url:document.getElementById('externalSystemDocumentation').value.trim(),description:document.getElementById('externalSystemDescription').value.trim(),active:document.getElementById('externalSystemActive').checked}}
function bindExternalSystemForm(system){document.getElementById('externalSystemForm')?.addEventListener('submit',async event=>{event.preventDefault();try{const saved=await api(system?`/api/v1/external-systems/${system.id}`:'/api/v1/external-systems',{method:system?'PATCH':'POST',body:JSON.stringify(readExternalSystemForm())});toast(system?'Sistemul extern a fost actualizat.':'Sistemul extern a fost adăugat.');location.hash=`#external/${saved.id}`;if(system)externalSystemsPage(String(saved.id))}catch(err){toast(err.message,true)}})}
function externalSourceOptions(type,services,vms){if(type==='service')return services.filter(x=>x.active).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('');return vms.filter(x=>!x.retired).map(x=>`<option value="${x.id}">${e(x.name)}${x.guest_hostname?` · ${e(x.guest_hostname)}`:''}</option>`).join('')}
async function externalSystemDetailPage(id){
  const [system,networks,services,vms]=await Promise.all([api(`/api/v1/external-systems/${id}`),api('/api/v1/external-networks?active=all'),api('/api/v1/services?include_inactive=true'),fetchAllVMsForSelect()]);pageMeta(system.name,'Sistem extern, rețea și conexiuni cu infrastructura internă');
  const connectionForm=can('external.manage')?`<form id="externalSystemConnectionForm" class="external-connection-form extended"><label>Sursă<select id="externalSourceType"><option value="service">Serviciu intern</option><option value="vm">VM specific</option></select></label><label id="externalSourceValueLabel">Serviciu intern<select id="externalSourceValue"></select></label><label>Sens<select id="externalSystemConnectionDirection"><option value="outbound">Ieșire → extern</option><option value="inbound">Intrare ← extern</option><option value="bidirectional">Bidirecțional ↔</option></select></label><label>Serviciu destinație<input id="externalSystemConnectionService" required placeholder="HTTPS API, SMTP, LDAP…"></label><label>Protocol<input id="externalSystemConnectionProtocol" value="tcp"></label><label>Port<input id="externalSystemConnectionPort" type="number" min="1" max="65535"></label><label>Autentificare<input id="externalSystemConnectionAuth"></label><label class="span-2">Scop<input id="externalSystemConnectionPurpose"></label><label class="check-inline"><input id="externalSystemConnectionTLS" type="checkbox"> TLS</label><button type="submit">Adaugă conexiune</button></form>`:'';
  content.innerHTML=`<div class="service-detail-toolbar"><a href="#external/systems" class="button-link secondary">← Înapoi la sisteme externe</a>${can('external.manage')?'<button id="deleteExternalSystem" class="danger">Șterge sistemul</button>':''}</div><div class="cards"><div class="card"><div class="label">Tip</div><div class="value compact">${e(externalTypeLabels[system.system_type]||system.system_type)}</div></div><div class="card"><div class="label">Rețea</div><div class="value compact">${externalNetworkBadge(system)}</div></div><div class="card"><div class="label">Conexiuni</div><div class="value">${system.connection_count||0}</div></div><div class="card"><div class="label">Stare</div><div class="value compact">${system.active?badge('active'):badge('disabled')}</div></div></div>${system.network_id?panel('Clasificare rețea',`<div class="detail-grid">${detail('Rețea',externalNetworkBadge(system))}${detail('Tip zonă',e(externalZoneTypeLabels[system.network_zone_type]||system.network_zone_type||'—'))}${detail('Risc',externalRiskBadge(system.network_risk_level))}${detail('Trust',e(externalTrustLabels[system.network_trust_level]||system.network_trust_level||'—'))}</div>`):''}${panel('Identificare',can('external.manage')?externalSystemForm(system,networks):`<div class="detail-grid">${detail('Denumire',e(system.name))}${detail('Hostname',e(system.hostname||'—'),true)}${detail('IP-uri',e(system.ip_addresses||'—'),true)}${detail('Organizație',e(system.owner_organization||'—'))}${detail('Rețea',externalNetworkBadge(system))}${detail('Descriere',e(system.description||'—'))}</div>`)}${panel('Conexiuni',`${connectionForm}${externalConnectionTable(system.connections,{showSource:true,manage:can('external.manage')})}`)}`;
  bindExternalSystemForm(system);const sourceType=document.getElementById('externalSourceType'),sourceValue=document.getElementById('externalSourceValue'),sourceLabel=document.getElementById('externalSourceValueLabel');const refreshSource=()=>{const type=sourceType.value;sourceLabel.firstChild.textContent=type==='service'?'Serviciu intern':'VM specific';sourceValue.innerHTML=externalSourceOptions(type,services,vms)};sourceType?.addEventListener('change',refreshSource);if(sourceType)refreshSource();
  document.getElementById('externalSystemConnectionForm')?.addEventListener('submit',async event=>{event.preventDefault();const type=sourceType.value,idValue=Number(sourceValue.value||0),port=document.getElementById('externalSystemConnectionPort').value;if(!idValue){toast('Alege sursa internă.',true);return}const body={external_system_id:Number(system.id),direction:document.getElementById('externalSystemConnectionDirection').value,remote_service:document.getElementById('externalSystemConnectionService').value.trim(),protocol:document.getElementById('externalSystemConnectionProtocol').value.trim(),port:port?Number(port):null,tls_enabled:document.getElementById('externalSystemConnectionTLS').checked,authentication:document.getElementById('externalSystemConnectionAuth').value.trim(),purpose:document.getElementById('externalSystemConnectionPurpose').value.trim()};body[type==='service'?'internal_service_id':'vm_id']=idValue;try{await api('/api/v1/external-connections',{method:'POST',body:JSON.stringify(body)});toast('Conexiunea a fost adăugată.');externalSystemDetailPage(system.id)}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.delete-external-connection').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi conexiunea?'))return;try{await api(`/api/v1/external-connections/${button.dataset.id}`,{method:'DELETE'});externalSystemDetailPage(system.id)}catch(err){toast(err.message,true)}}));document.getElementById('deleteExternalSystem')?.addEventListener('click',async()=>{if(!confirm(`Ștergi sistemul extern ${system.name} și toate conexiunile lui?`))return;try{await api(`/api/v1/external-systems/${system.id}`,{method:'DELETE'});toast('Sistemul extern a fost șters.');location.hash='#external/systems'}catch(err){toast(err.message,true)}})
}
function externalSubnav(section){return `<nav class="subnav external-subnav"><a href="#external/systems" class="${section==='systems'?'active':''}">Sisteme externe</a><a href="#external/networks" class="${section==='networks'?'active':''}">Rețele externe</a></nav>`}
async function renderExternalNetworks(networks){const edit=networks.find(x=>Number(x.id)===Number(state.externalNetworkEdit))||null;const rows=networks.map(n=>`<tr><td>${externalNetworkBadge(n)}<div class="muted mono">${e(n.code)}</div></td><td>${e(externalZoneTypeLabels[n.zone_type]||n.zone_type)}</td><td>${externalRiskBadge(n.risk_level)}</td><td>${e(externalTrustLabels[n.trust_level]||n.trust_level)}</td><td class="mono">${e(n.cidrs||'—')}</td><td>${n.system_count||0}</td><td>${n.connection_count||0}</td><td>${n.active?badge('active'):badge('disabled')}</td>${can('external.manage')?`<td><div class="actions"><button class="small secondary edit-external-network" data-id="${n.id}">Editează</button><button class="small danger delete-external-network" data-id="${n.id}" ${Number(n.system_count||0)>0?'disabled title="Rețeaua are sisteme asociate"':''}>Șterge</button></div></td>`:''}</tr>`).join('');content.innerHTML+=`${can('external.manage')?panel(edit?'Editează rețeaua externă':'Adaugă rețea externă',externalNetworkForm(edit)):''}${panel('Rețele externe',rows?`<div class="table-wrap"><table><thead><tr><th>Rețea / culoare</th><th>Tip</th><th>Risc</th><th>Trust</th><th>CIDR</th><th>Sisteme</th><th>Conexiuni</th><th>Stare</th>${can('external.manage')?'<th></th>':''}</tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există rețele externe definite.'))}`;bindExternalNetworkForm(edit);document.querySelectorAll('.edit-external-network').forEach(b=>b.addEventListener('click',()=>{state.externalNetworkEdit=Number(b.dataset.id);externalSystemsPage('networks')}));document.querySelectorAll('.delete-external-network').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Ștergi această rețea externă?'))return;try{await api(`/api/v1/external-networks/${b.dataset.id}`,{method:'DELETE'});toast('Rețeaua externă a fost ștearsă.');externalSystemsPage('networks')}catch(err){toast(err.message,true)}}))}
async function renderExternalSystems(systems,networks){const f=state.externalFilters,q=f.q.toLocaleLowerCase('ro');const filtered=systems.filter(item=>(!q||`${item.name} ${item.hostname} ${item.ip_addresses} ${item.owner_organization}`.toLocaleLowerCase('ro').includes(q))&&(!f.network||String(item.network_id||'')===String(f.network))&&(f.status==='all'||(f.status==='active'?item.active:!item.active)));const internet=systems.filter(x=>x.active&&x.network_zone_type==='internet').length;const filters=`<div class="filterbar external-filterbar"><label><span>Caută</span><input id="externalSearch" type="search" value="${e(f.q)}" placeholder="Nume, hostname, IP, organizație"></label><label><span>Rețea</span><select id="externalNetworkFilter"><option value="">Toate</option>${networks.map(n=>`<option value="${n.id}" ${String(f.network)===String(n.id)?'selected':''}>${e(n.name)}</option>`).join('')}</select></label><label><span>Stare</span><select id="externalStatusFilter"><option value="active" ${f.status==='active'?'selected':''}>Active</option><option value="inactive" ${f.status==='inactive'?'selected':''}>Inactive</option><option value="all" ${f.status==='all'?'selected':''}>Toate</option></select></label><button id="externalReset" class="secondary" type="button">Resetează</button></div>`;const rows=filtered.map(item=>`<tr><td><a href="#external/${item.id}"><strong>${e(item.name)}</strong></a><div class="muted">${e(externalTypeLabels[item.system_type]||item.system_type)}</div></td><td class="mono">${e(item.hostname||item.ip_addresses||'—')}</td><td>${externalNetworkBadge(item)}</td><td>${externalRiskBadge(item.network_risk_level)}</td><td>${e(item.owner_organization||'—')}</td><td>${item.connection_count||0}</td><td>${item.active?badge('active'):badge('disabled')}</td><td><a class="button-link small secondary" href="#external/${item.id}">Deschide</a></td></tr>`).join('');content.innerHTML+=`<div class="cards"><div class="card"><div class="label">Sisteme definite</div><div class="value">${systems.length}</div></div><div class="card"><div class="label">Active</div><div class="value">${systems.filter(x=>x.active).length}</div></div><div class="card"><div class="label">În Internet</div><div class="value">${internet}</div></div><div class="card"><div class="label">Conexiuni</div><div class="value">${systems.reduce((n,x)=>n+Number(x.connection_count||0),0)}</div></div></div>${can('external.manage')?panel('Adaugă sistem extern',externalSystemForm(null,networks)):''}${panel('Sisteme externe',`${filters}${rows?`<div class="table-wrap"><table><thead><tr><th>Sistem</th><th>Adresă</th><th>Rețea</th><th>Risc</th><th>Organizație</th><th>Conexiuni</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există sisteme pentru filtrele selectate.')}`)}`;bindExternalSystemForm(null);let timer;document.getElementById('externalSearch')?.addEventListener('input',event=>{clearTimeout(timer);const input=event.currentTarget;timer=setTimeout(async()=>{const pos=input.selectionStart??input.value.length;f.q=input.value.trim();await externalSystemsPage('systems');const next=document.getElementById('externalSearch');if(next){next.focus();next.setSelectionRange(Math.min(pos,next.value.length),Math.min(pos,next.value.length))}},200)});document.getElementById('externalNetworkFilter')?.addEventListener('change',event=>{f.network=event.target.value;externalSystemsPage('systems')});document.getElementById('externalStatusFilter')?.addEventListener('change',event=>{f.status=event.target.value;externalSystemsPage('systems')});document.getElementById('externalReset')?.addEventListener('click',()=>{state.externalFilters={q:'',network:'',status:'active'};externalSystemsPage('systems')})}
async function externalSystemsPage(id=''){
  if(id&&Number(id)>0){await externalSystemDetailPage(Number(id));return}const section=id==='networks'?'networks':'systems';const [systems,networks]=await Promise.all([api('/api/v1/external-systems?active=all'),api('/api/v1/external-networks?active=all')]);pageMeta(section==='networks'?'Rețele externe':'Sisteme externe','Conectivitate către infrastructuri și servicii din afara rețelelor proprii');content.innerHTML=externalSubnav(section);if(section==='networks')await renderExternalNetworks(networks);else await renderExternalSystems(systems,networks)
}

async function internalServiceDetail(id){
  const [service,documentTemplates,generatedDocuments,diagramNomenclatures,allServices,externalSystems,externalConnections]=await Promise.all([api(`/api/v1/services/${id}`),can('documents.read')?api('/api/v1/document-templates?object_type=service'):Promise.resolve([]),can('documents.read')?api(`/api/v1/services/${id}/documents`):Promise.resolve([]),api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/services?include_inactive=true'),can('external.read')?api('/api/v1/external-systems?active=active'):Promise.resolve([]),can('external.read')?api(`/api/v1/external-connections?service_id=${id}`):Promise.resolve([])]);nomenclatureCache=diagramNomenclatures;internalServicesCache=allServices;
  const vmRows=serviceVMRows(service.vms);
  const documentationLink=service.documentation_url?`<a href="${e(service.documentation_url)}" target="_blank" rel="noopener">${e(service.documentation_url)}</a>`:'—';
  const serviceDocumentPanel=can('documents.read')?serviceDocumentsPanel(id,documentTemplates,generatedDocuments):'';
  pageMeta(service.name,'Serviciu intern, arhitectură logică, tipuri de soluție și documentație');
  content.innerHTML=`<div class="service-detail-toolbar"><a href="#services" class="button-link secondary">← Înapoi la servicii</a>${can('services.manage')?'<button id="editInternalService">Editează serviciul</button>':''}</div>
  ${serviceTopCards(service)}
  ${panel('Identificare serviciu',`<div class="detail-grid">${detail('Serviciu intern',e(service.name))}${detail('Cod intern',e(service.service_code||'—'),true)}${detail('Criticitate',criticalityLabels[service.criticality]||e(service.criticality))}${detail('Status documentație',documentationStatusLabels[service.documentation_status]||e(service.documentation_status))}${detail('Activ',service.active?badge('active'):badge('disabled'))}${detail('Tip serviciu',service.is_common?(service.implicit_global?badge('global'):badge('common')):'Serviciu aplicație')}${detail('Tip dependență comună',e(service.common_dependency_type||'—'))}${detail('Ultima actualizare',dt(service.updated_at))}${detail('Documentație existentă',documentationLink)}</div><div class="service-text-block service-narrative-block"><section><h3>Descriere</h3><p>${e(service.description||'—')}</p></section><section><h3>Scop și domeniu</h3>${richTextView(service.purpose_richtext,service.purpose||'')}</section><section><h3>Obiective</h3>${richTextView(service.objectives_richtext,service.objectives||'')}</section></div>`) }
  ${panel('Încadrare pe medii',serviceEnvironmentPanel(service.vms))}
  ${panel('Dependențe și servicii comune',serviceDependenciesPanel(service,allServices,diagramNomenclatures),service.is_common?'<span class="common-service-pill">Acest serviciu poate fi folosit ca dependență</span>':'')}
  ${can('external.read')?panel('Conexiuni către sisteme externe',scopedExternalConnectionPanel('service',id,externalConnections,externalSystems),'<a class="button-link small secondary" href="#external">Sisteme externe</a>'):''}
  ${service.is_common?panel('Impact · servicii dependente',serviceDependentsPanel(service),'<span class="muted">Relații care ar putea fi afectate de indisponibilitatea serviciului comun</span>'):''}
  ${panel('Domenii și categorii observate automat',`<p class="muted service-observed-note">Încadrarea este calculată exclusiv din fișele VM asociate serviciului.</p>${observedServiceClassifications(service.classifications)}`) }
  ${panel('Tipuri de soluție observate automat',`<p class="muted service-observed-note">Open source, dezvoltată intern sau comercială, conform alegerii făcute pe fiecare asociere VM.</p>${observedServiceSolutionTypes(service.solution_types)}`) }
  ${panel('Layer-e și roluri tehnice observate automat',`<p class="muted service-observed-note">Această vedere este calculată din asocierile VM-urilor. Nu se configurează manual la nivelul serviciului.</p>${observedServiceRoles(service.role_mappings)}`) }
  ${panel('Schemă serviciu',serviceDiagram(service,diagramNomenclatures))}
  ${panel('VM-uri asociate',vmRows?`<div class="table-wrap"><table><thead><tr><th>VM</th><th>Mediu</th><th>IP</th><th>Domeniu / Categorie</th><th>Layer / Rol</th><th>Tip soluție</th><th>Utilizare</th><th>Fișă VM</th><th></th><th>Power state</th></tr></thead><tbody>${vmRows}</tbody></table></div>`:empty('Niciun VM nu este asociat încă acestui serviciu. Asocierea se face din fișa VM.'))}
  ${serviceDocumentPanel}`;
  document.getElementById('editInternalService')?.addEventListener('click',()=>openInternalService(service));
  bindServiceDocumentActions(id);
  bindServiceDependencyActions(id);
  if(can('external.read'))bindScopedExternalConnectionActions('service',id,()=>internalServiceDetail(id));
}

internalServiceForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('services.manage'))return;
  const id=Number(document.getElementById('internalServiceId').value||0);
  const purposeRichText=richTextDocumentFromEditor('internalServicePurposeRich');const objectivesRichText=richTextDocumentFromEditor('internalServiceObjectivesRich');
  const isCommon=document.getElementById('internalServiceCommon').checked,implicitGlobal=document.getElementById('internalServiceImplicitGlobal').checked,commonTypeValue=document.getElementById('internalServiceCommonDependencyType').value;
  if((isCommon||implicitGlobal)&&!commonTypeValue){toast('Alege tipul dependenței pentru serviciul comun.',true);return}
  const body={name:document.getElementById('internalServiceName').value.trim(),service_code:document.getElementById('internalServiceCode').value.trim(),criticality:document.getElementById('internalServiceCriticality').value,documentation_status:document.getElementById('internalServiceDocStatus').value,description:document.getElementById('internalServiceDescription').value.trim(),purpose:richTextPlain(purposeRichText),purpose_richtext:purposeRichText,objectives:richTextPlain(objectivesRichText),objectives_richtext:objectivesRichText,documentation_url:document.getElementById('internalServiceDocumentationURL').value.trim(),active:document.getElementById('internalServiceActive').checked,is_common:isCommon||implicitGlobal,implicit_global:implicitGlobal,common_dependency_type_id:commonTypeValue?Number(commonTypeValue):null};
  try{const saved=await api(id?`/api/v1/services/${id}`:'/api/v1/services',{method:id?'PATCH':'POST',body:JSON.stringify(body)});internalServiceDialog.close();toast(id?'Serviciu actualizat.':'Serviciu creat.');location.hash=`#services/${saved.id}`;if(id===saved.id&&location.hash===`#services/${saved.id}`)internalServiceDetail(saved.id)}catch(err){toast(err.message,true)}
});

function syncCommonServiceForm(){
  const common=document.getElementById('internalServiceCommon'),global=document.getElementById('internalServiceImplicitGlobal'),type=document.getElementById('internalServiceCommonDependencyType');if(!common||!global||!type)return;
  if(global.checked)common.checked=true;
  if(!common.checked){global.checked=false;type.value=''}
  type.disabled=!common.checked;
}
document.getElementById('internalServiceCommon')?.addEventListener('change',syncCommonServiceForm);
document.getElementById('internalServiceImplicitGlobal')?.addEventListener('change',syncCommonServiceForm);

let nomenclatureCache=[];
let peopleCache=[];
let directoryDepartmentCache=null;
let directoryUsersCache=[];
function updateNomenclatureParent(selected=[]){
  const category=document.getElementById('nomenclatureCategory').value;
  const parentLabel=document.getElementById('nomenclatureParentLabel');
  const parentText=document.getElementById('nomenclatureParentText');
  const parentHelp=document.getElementById('nomenclatureParentHelp');
  const orderText=document.getElementById('nomenclatureOrderText');
  const orderHelp=document.getElementById('nomenclatureOrderHelp');
  const parent=document.getElementById('nomenclatureParent');
  const isServiceCategory=category==='itil_category';
  const isTechnicalRole=category==='technical_role';
  destroyEnhancedMultiSelect(parent);
  parentLabel.hidden=!(isServiceCategory||isTechnicalRole);
  parent.required=isServiceCategory;
  parent.multiple=isTechnicalRole;
  parent.removeAttribute('size');
  orderText.textContent=isTechnicalRole?'Ordine în layer':'Ordine';
  orderHelp.textContent=isTechnicalRole?'Rolurile sunt afișate după ordinea layer-ului, apoi după această valoare.':'';
  if(isServiceCategory){
    parentText.textContent='Domeniu arhitectural';
    parentHelp.textContent='Categoria de serviciu aparține unui singur domeniu arhitectural.';
    const domains=sortNomenclatureValues(categoryItems(nomenclatureCache,'architectural_domain'));
    parent.innerHTML=selectOptions(domains,Array.isArray(selected)?selected[0]:selected,'— Alege domeniul arhitectural —');
  }else if(isTechnicalRole){
    parentText.textContent='Layer-e permise';
    parentHelp.textContent='Selectează unul sau mai multe layer-e. Rolul va fi disponibil numai în layer-ele alese.';
    const layers=sortNomenclatureValues(categoryItems(nomenclatureCache,'layer'));
    parent.innerHTML=multiSelectOptions(layers,Array.isArray(selected)?selected:[]);
    enhanceMultiSelect(parent,{placeholder:'Alege layer-ele'});
  }else{
    parentText.textContent='Relație';
    parentHelp.textContent='';
    parent.innerHTML='<option value="">— Nu se aplică —</option>';
  }
}
function openNomenclature(item=null,categoryCode='architectural_domain'){
  const selectedCategory=item?.category_code||categoryCode;
  const categoryOptions=nomenclatureCache.map(category=>`<option value="${e(category.code)}" ${selectedCategory===category.code?'selected':''}>${e(category.label)}</option>`).join('');
  document.getElementById('nomenclatureDialogTitle').textContent=item?'Editare valoare':'Valoare nouă';
  document.getElementById('nomenclatureId').value=item?.id||'';
  const category=document.getElementById('nomenclatureCategory');
  category.innerHTML=categoryOptions;
  category.disabled=Boolean(item);
  document.getElementById('nomenclatureName').value=item?.name||'';
  document.getElementById('nomenclatureCode').value=item?.item_code||'';
  document.getElementById('nomenclatureIcon').value=item?.icon_key||'';
  document.getElementById('nomenclatureDescription').value=item?.description||'';
  document.getElementById('nomenclatureOrder').value=item?.sort_order??0;
  document.getElementById('nomenclatureActive').checked=item?.active??true;
  updateNomenclatureParent(selectedCategory==='technical_role'?(item?.layer_ids||[]):(item?.parent_id||''));
  nomenclatureDialog.showModal();
}
document.getElementById('nomenclatureCategory').addEventListener('change',()=>updateNomenclatureParent([]));
function openPerson(person=null){
  document.getElementById('personDialogTitle').textContent=person?'Editare persoană':'Persoană nouă';
  document.getElementById('personId').value=person?.id||'';
  document.getElementById('personName').value=person?.display_name||'';
  document.getElementById('personEmail').value=person?.email||'';
  document.getElementById('personPhone').value=person?.phone||'';
  document.getElementById('personDepartment').value=person?.department||'';
  document.getElementById('personActive').checked=person?.active??true;
  personDialog.showModal();
}
const nomenclatureNavigationGroups=[
  {label:'Catalog servicii',codes:['architectural_domain','itil_category']},
  {label:'Arhitectură tehnică',codes:['layer','technical_role','solution_type']},
  {label:'Dependențe și servicii comune',codes:['dependency_type']},
  {label:'Operare VM',codes:['environment','operational_status','classification']},
  {label:'Responsabilități',codes:['people']}
];
const nomenclatureDescriptions={
  architectural_domain:'Domeniile arhitecturale grupează categoriile de serviciu și serviciile interne.',
  itil_category:'Categoriile de serviciu aparțin unui domeniu arhitectural și grupează serviciile interne.',
  layer:'Layer-ele descriu zona arhitecturală în care o VM îndeplinește o funcție.',
  technical_role:'Rolurile tehnice sunt legate de layer-ele în care pot fi selectate.',
  solution_type:'Tipul soluției indică natura tehnologiei folosite de o asociere VM–serviciu: open source, dezvoltată intern sau comercială.',
  dependency_type:'Tipurile de dependență descriu relația cu serviciile comune: autentificare, DNS, directory, NTP, PKI, proxy, logging, backup și altele.',
  environment:'Mediile separă utilizarea VM-urilor, de exemplu producție, test sau dezvoltare.',
  operational_status:'Statusurile operaționale descriu starea curentă a unei VM în exploatare.',
  classification:'Clasificările permit marcarea nivelului sau tipului de informație gestionată.',
  people:'Registrul persoanelor care pot primi responsabilități pe fișele VM.'
};
function nomenclatureFilterState(code){
  if(!state.nomenclatureFilters[code])state.nomenclatureFilters[code]={q:'',status:'all',parent:'',layer:'',department:'',source:''};
  return state.nomenclatureFilters[code];
}
function normalizedFilterText(value){return String(value||'').trim().toLocaleLowerCase('ro-RO')}
function nomenclatureValueMatches(item,categoryCode,filter){
  if(filter.status==='active'&&!item.active)return false;
  if(filter.status==='inactive'&&item.active)return false;
  if(categoryCode==='itil_category'&&filter.parent&&Number(item.parent_id)!==Number(filter.parent))return false;
  if(categoryCode==='technical_role'&&filter.layer&&!(item.layer_ids||[]).some(id=>Number(id)===Number(filter.layer)))return false;
  const query=normalizedFilterText(filter.q);
  if(!query)return true;
  const haystack=[item.name,item.item_code,item.icon_key,item.description,item.parent_name,...(item.layer_names||[])].join(' ').toLocaleLowerCase('ro-RO');
  return haystack.includes(query);
}
function nomenclatureFilterForm(category,visibleCount,totalCount,pageSize){
  const filter=nomenclatureFilterState(category.code);
  const parentField=category.code==='itil_category'?`<label>Domeniu arhitectural<select name="parent"><option value="">Toate domeniile</option>${sortNomenclatureValues(categoryItems(nomenclatureCache,'architectural_domain')).map(item=>`<option value="${item.id}" ${String(filter.parent)===String(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}</select></label>`:'';
  const layerField=category.code==='technical_role'?`<label>Layer<select name="layer"><option value="">Toate layer-ele</option>${sortNomenclatureValues(categoryItems(nomenclatureCache,'layer')).map(item=>`<option value="${item.id}" ${String(filter.layer)===String(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}</select></label>`:'';
  return `<form id="nomenclatureFilters" class="nomenclature-filters">
    <label class="nomenclature-filter-search">Caută<input name="q" type="search" value="${e(filter.q)}" placeholder="Denumire, cod sau descriere"></label>
    ${parentField}${layerField}
    <label>Stare<select name="status"><option value="all" ${filter.status==='all'?'selected':''}>Toate</option><option value="active" ${filter.status==='active'?'selected':''}>Active</option><option value="inactive" ${filter.status==='inactive'?'selected':''}>Inactive</option></select></label>
    <label>Pe pagină<select name="page_size" id="nomenclatureTopPageSize">${pageSizeOptions(pageSize,[10,20,50,100,200])}</select></label>
    <div class="nomenclature-filter-actions"><button type="submit" class="small">Aplică filtre</button><button type="button" id="clearNomenclatureFilters" class="small secondary">Resetează</button></div>
    <span class="nomenclature-filter-summary">${visibleCount.toLocaleString('ro-RO')} rezultate din ${totalCount.toLocaleString('ro-RO')}</span>
  </form>`;
}
function nomenclaturePanel(category){
  const hasParent=category.code==='itil_category';
  const hasLayerLinks=category.code==='technical_role';
  const relationHead=hasParent?'<th>Domeniu arhitectural</th>':hasLayerLinks?'<th>Layer-e permise</th>':'';
  const head=`<tr><th>Denumire</th>${relationHead}<th>Cod</th><th>Pictogramă</th><th>Ordine</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  const filter=nomenclatureFilterState(category.code);
  const filteredItems=category.items.filter(item=>nomenclatureValueMatches(item,category.code,filter));
  const info=nomenclaturePageInfo(category.code,filteredItems.length);
  const visibleItems=filteredItems.slice(info.offset,info.end);
  const rows=visibleItems.map(item=>{
    const relation=hasParent?`<td>${e(item.parent_name||'—')}</td>`:hasLayerLinks?`<td>${item.layer_names?.length?e(item.layer_names.join(', ')):'<span class="muted">Nemapate</span>'}</td>`:'';
    return `<tr><td><strong>${e(item.name)}</strong>${item.description?`<div class="muted">${e(item.description)}</div>`:''}</td>${relation}<td class="mono">${e(item.item_code||'—')}</td><td>${nomenclatureIcon(item.icon_key,'small')} <span class="muted mono">${e(item.icon_key||'—')}</span></td><td>${item.sort_order}</td><td>${item.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-nomenclature" data-id="${item.id}">Editează</button></td>`:''}</tr>`;
  }).join('');
  const result=rows?`<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>${nomenclaturePagination(category.code,info)}`:empty(category.items.length?'Nu există valori pentru filtrele selectate.':'Nu există valori definite.');
  const body=`${nomenclatureFilterForm(category,filteredItems.length,category.items.length,info.pageSize)}${result}`;
  const tools=`<a class="button-link small secondary" href="/api/v1/nomenclatures/export?category=${encodeURIComponent(category.code)}&include_inactive=true">Export Excel</a>${can('nomenclatures.manage')?`<button class="small add-nomenclature" data-category="${e(category.code)}">Adaugă</button>`:''}`;
  return panel(e(category.label),body,tools);
}
async function loadDirectoryDepartments(force=false){
  if(directoryDepartmentCache&&!force)return directoryDepartmentCache;
  try{directoryDepartmentCache=await api('/api/v1/directory/departments')}
  catch(err){directoryDepartmentCache={enabled:false,departments:[],default_department:'',error:err.message}}
  return directoryDepartmentCache;
}
function directoryUserMatches(user,query){
  if(!query)return true;
  const haystack=[user.display_name,user.username,user.email,user.department,...(user.ou_path||[])].join(' ').toLocaleLowerCase('ro-RO');
  return haystack.includes(query.toLocaleLowerCase('ro-RO'));
}
function directoryUserRow(user){
  const imported=peopleCache.some(person=>person.source==='ldap'&&person.directory_username&&String(person.directory_username).toLocaleLowerCase('ro-RO')===String(user.username||'').toLocaleLowerCase('ro-RO'));
  return `<label class="directory-user"><input type="checkbox" class="directory-user-check" value="${e(user.distinguished_name)}"><span><strong>${e(user.display_name||user.username)}</strong><small>${e(user.username||'')}${user.email?` · ${e(user.email)}`:''}</small></span>${imported?'<em>importat</em>':''}</label>`;
}
function directoryTreeHTML(users){
  const root={children:new Map(),users:[]};
  for(const user of users){let node=root;for(const segment of (user.ou_path||[])){if(!node.children.has(segment))node.children.set(segment,{children:new Map(),users:[]});node=node.children.get(segment)}node.users.push(user)}
  const renderNode=(name,node,rootNode=false)=>{
    const childHTML=[...node.children.entries()].sort((a,b)=>a[0].localeCompare(b[0],'ro')).map(([childName,child])=>renderNode(childName,child)).join('');
    const userHTML=node.users.map(directoryUserRow).join('');
    const body=`${userHTML}${childHTML}`||'<div class="directory-empty muted">Fără utilizatori</div>';
    if(rootNode)return body;
    const count=(node.users?.length||0)+[...node.children.values()].reduce((sum,child)=>sum+directoryNodeCount(child),0);
    return `<details class="directory-ou" open><summary><span>${e(name)}</span><b>${count}</b></summary><div>${body}</div></details>`;
  };
  return renderNode('',root,true);
}
function directoryNodeCount(node){return (node.users?.length||0)+[...(node.children?.values?.()||[])].reduce((sum,child)=>sum+directoryNodeCount(child),0)}
function renderDirectoryUsers(){
  const query=document.getElementById('directorySearch').value.trim();
  const visible=directoryUsersCache.filter(user=>directoryUserMatches(user,query));
  document.getElementById('directorySummary').textContent=`${visible.length} utilizatori afișați din ${directoryUsersCache.length}`;
  document.getElementById('directoryUsers').innerHTML=visible.length?directoryTreeHTML(visible):empty('Nu există utilizatori pentru filtrul ales.');
}
async function loadDirectoryUsers(){
  const department=document.getElementById('directoryDepartment').value;
  const target=document.getElementById('directoryUsers');
  directoryUsersCache=[];
  target.innerHTML='<div class="loading">Se încarcă utilizatorii…</div>';
  document.getElementById('directorySummary').textContent='';
  if(!department){target.innerHTML=empty('Nu există departamente disponibile.');return}
  try{directoryUsersCache=await api(`/api/v1/directory/users?department=${encodeURIComponent(department)}`);renderDirectoryUsers()}
  catch(err){target.innerHTML=empty(err.message);toast(err.message,true)}
}
async function openDirectoryImport(){
  const info=await loadDirectoryDepartments();
  if(!info.enabled){toast(info.error||'Importul din Active Directory nu este activat.',true);return}
  const department=document.getElementById('directoryDepartment');
  department.innerHTML=(info.departments||[]).map(value=>`<option value="${e(value)}" ${value===info.default_department?'selected':''}>${e(value)}</option>`).join('');
  document.getElementById('directorySearch').value='';
  directoryDialog.showModal();
  await loadDirectoryUsers();
}
function personMatchesFilters(person,filter){
  if(filter.status==='active'&&!person.active)return false;
  if(filter.status==='inactive'&&person.active)return false;
  if(filter.department&&person.department!==filter.department)return false;
  if(filter.source&&person.source!==filter.source)return false;
  const query=normalizedFilterText(filter.q);
  if(!query)return true;
  return [person.display_name,person.department,person.email,person.phone,person.directory_username].join(' ').toLocaleLowerCase('ro-RO').includes(query);
}
function peopleFilterForm(visibleCount,totalCount,pageSize){
  const filter=nomenclatureFilterState('people');
  const departments=[...new Set(peopleCache.map(person=>String(person.department||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro',{sensitivity:'base'}));
  return `<form id="nomenclatureFilters" class="nomenclature-filters">
    <label class="nomenclature-filter-search">Caută<input name="q" type="search" value="${e(filter.q)}" placeholder="Nume, departament, email sau telefon"></label>
    <label>Departament<select name="department"><option value="">Toate departamentele</option>${departments.map(value=>`<option value="${e(value)}" ${filter.department===value?'selected':''}>${e(value)}</option>`).join('')}</select></label>
    <label>Sursă<select name="source"><option value="" ${!filter.source?'selected':''}>Toate</option><option value="ldap" ${filter.source==='ldap'?'selected':''}>Active Directory</option><option value="manual" ${filter.source==='manual'?'selected':''}>Manual</option></select></label>
    <label>Stare<select name="status"><option value="all" ${filter.status==='all'?'selected':''}>Toate</option><option value="active" ${filter.status==='active'?'selected':''}>Active</option><option value="inactive" ${filter.status==='inactive'?'selected':''}>Inactive</option></select></label>
    <label>Pe pagină<select name="page_size" id="nomenclatureTopPageSize">${pageSizeOptions(pageSize,[10,20,50,100,200])}</select></label>
    <div class="nomenclature-filter-actions"><button type="submit" class="small">Aplică filtre</button><button type="button" id="clearNomenclatureFilters" class="small secondary">Resetează</button></div>
    <span class="nomenclature-filter-summary">${visibleCount.toLocaleString('ro-RO')} rezultate din ${totalCount.toLocaleString('ro-RO')}</span>
  </form>`;
}
function peopleNomenclaturePanel(directoryInfo){
  const filter=nomenclatureFilterState('people');
  const filteredPeople=peopleCache.filter(person=>personMatchesFilters(person,filter));
  const info=nomenclaturePageInfo('people',filteredPeople.length);
  const visiblePeople=filteredPeople.slice(info.offset,info.end);
  const rows=visiblePeople.map(person=>`<tr><td><strong>${e(person.display_name)}</strong><div class="muted">${e(person.department||'')}</div></td><td>${e(person.email||'—')}</td><td>${e(person.phone||'—')}</td><td>${person.source==='ldap'?badge('AD'):badge('manual')}</td><td>${person.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-person" data-id="${person.id}">Editează</button></td>`:''}</tr>`).join('');
  const head=`<tr><th>Persoană</th><th>Email</th><th>Telefon</th><th>Sursă</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  const result=rows?`<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>${nomenclaturePagination('people',info)}`:empty(peopleCache.length?'Nu există persoane pentru filtrele selectate.':'Nu există persoane definite.');
  let body=`${peopleFilterForm(filteredPeople.length,peopleCache.length,info.pageSize)}${result}`;
  if(directoryInfo?.error)body=`<div class="notice warning">Active Directory nu a putut fi interogat: ${e(directoryInfo.error)}</div>${body}`;
  const tools=`<a class="button-link small secondary" href="/api/v1/nomenclatures/export?category=people&include_inactive=true">Export Excel</a>${can('nomenclatures.manage')?`<button id="addPerson" class="small secondary">Adaugă manual</button>${directoryInfo?.enabled?'<button id="importDirectoryPeople" class="small">Importă din AD</button>':''}`:''}`;
  return panel('Persoane',body,tools);
}
function nomenclatureNavigation(selectedCode){
  const categories=new Map(nomenclatureCache.map(category=>[category.code,category]));
  const rendered=new Set();
  const groups=nomenclatureNavigationGroups.map(group=>{
    const links=group.codes.map(code=>{
      if(code==='people'){
        rendered.add(code);
        return `<a href="#nomenclatures/people" class="${selectedCode==='people'?'active':''}"><span>Persoane</span><b>${peopleCache.length}</b></a>`;
      }
      const category=categories.get(code);if(!category)return '';
      rendered.add(code);
      return `<a href="#nomenclatures/${e(code)}" class="${selectedCode===code?'active':''}"><span>${e(category.label)}</span><b>${category.items.length}</b></a>`;
    }).join('');
    return links?`<section><h3>${e(group.label)}</h3>${links}</section>`:'';
  }).join('');
  const other=[...categories.values()].filter(category=>!rendered.has(category.code));
  const otherGroup=other.length?`<section><h3>Altele</h3>${other.map(category=>`<a href="#nomenclatures/${e(category.code)}" class="${selectedCode===category.code?'active':''}"><span>${e(category.label)}</span><b>${category.items.length}</b></a>`).join('')}</section>`:'';
  return `<aside class="nomenclature-submenu"><div class="nomenclature-submenu-title">Nomenclatoare</div>${groups}${otherGroup}</aside>`;
}
function refreshNomenclatureSection(code){
  const target=`#nomenclatures/${code}`;
  if(location.hash===target)nomenclaturesPage(code);else location.hash=target;
}
async function nomenclaturesPage(requestedCode=''){
  [nomenclatureCache,peopleCache]=await Promise.all([api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true')]);
  const allowedCodes=new Set([...nomenclatureCache.map(category=>category.code),'people']);
  const selectedCode=allowedCodes.has(requestedCode)?requestedCode:(nomenclatureCache[0]?.code||'people');
  if(requestedCode!==selectedCode)history.replaceState(null,'',`#nomenclatures/${selectedCode}`);
  const category=nomenclatureCache.find(value=>value.code===selectedCode);
  const label=selectedCode==='people'?'Persoane':category?.label||'Nomenclatoare';
  const description=nomenclatureDescriptions[selectedCode]||'Listă controlată folosită în fișele VM.';
  pageMeta('Nomenclatoare',`${label} · ${description}`);
  const directoryInfo=selectedCode==='people'?await loadDirectoryDepartments():null;
  const selectedPanel=selectedCode==='people'?peopleNomenclaturePanel(directoryInfo):nomenclaturePanel(category);
  content.innerHTML=`<div class="nomenclature-layout">
    ${nomenclatureNavigation(selectedCode)}
    <div class="nomenclature-workspace">
      <div class="nomenclature-context"><span>${e(label)}</span><p>${e(description)}</p></div>
      ${selectedPanel}
    </div>
  </div>`;
  content.querySelectorAll('.add-nomenclature').forEach(button=>button.onclick=()=>openNomenclature(null,button.dataset.category));
  content.querySelectorAll('.edit-nomenclature').forEach(button=>button.onclick=()=>{const item=nomenclatureCache.flatMap(value=>value.items).find(value=>value.id===Number(button.dataset.id));openNomenclature(item)});
  document.getElementById('addPerson')?.addEventListener('click',()=>openPerson());
  document.getElementById('importDirectoryPeople')?.addEventListener('click',openDirectoryImport);
  content.querySelectorAll('.edit-person').forEach(button=>button.onclick=()=>openPerson(peopleCache.find(person=>person.id===Number(button.dataset.id))));
  document.getElementById('nomenclatureFilters')?.addEventListener('submit',event=>{
    event.preventDefault();
    const values=Object.fromEntries(new FormData(event.currentTarget).entries());
    state.nomenclatureFilters[selectedCode]={q:String(values.q||'').trim(),status:String(values.status||'all'),parent:String(values.parent||''),layer:String(values.layer||''),department:String(values.department||''),source:String(values.source||'')};
    const requestedSize=Number(values.page_size||10),pageSize=[10,20,50,100,200].includes(requestedSize)?requestedSize:10;const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize};paging.page=1;paging.pageSize=pageSize;state.nomenclaturePaging[selectedCode]=paging;localStorage.setItem(`vm-doc:nomenclature-page-size:${selectedCode}`,String(pageSize));
    nomenclaturesPage(selectedCode);
  });
  document.getElementById('clearNomenclatureFilters')?.addEventListener('click',()=>{
    state.nomenclatureFilters[selectedCode]={q:'',status:'all',parent:'',layer:'',department:'',source:''};
    const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize:10};paging.page=1;state.nomenclaturePaging[selectedCode]=paging;
    nomenclaturesPage(selectedCode);
  });
  content.querySelectorAll('.nomenclature-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize:10};if(page>0&&page!==paging.page){paging.page=page;state.nomenclaturePaging[selectedCode]=paging;nomenclaturesPage(selectedCode)}}));
  document.getElementById('nomenclatureTopPageSize')?.addEventListener('change',event=>{const pageSize=Number(event.target.value);state.nomenclaturePaging[selectedCode]={page:1,pageSize};localStorage.setItem(`vm-doc:nomenclature-page-size:${selectedCode}`,String(pageSize));nomenclaturesPage(selectedCode)});
}

nomenclatureForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('nomenclatureId').value||0);
  const categoryCode=document.getElementById('nomenclatureCategory').value;
  const parent=document.getElementById('nomenclatureParent');
  const parentValue=parent.value;
  const layerIDs=categoryCode==='technical_role'?[...parent.selectedOptions].map(option=>Number(option.value)).filter(Boolean):[];
  if(categoryCode==='technical_role'&&!layerIDs.length){toast('Selectează cel puțin un layer pentru rolul tehnic.',true);return}
  const body={category_code:categoryCode,name:document.getElementById('nomenclatureName').value.trim(),item_code:document.getElementById('nomenclatureCode').value.trim(),description:document.getElementById('nomenclatureDescription').value.trim(),icon_key:document.getElementById('nomenclatureIcon').value.trim(),sort_order:Number(document.getElementById('nomenclatureOrder').value||0),active:document.getElementById('nomenclatureActive').checked,parent_id:categoryCode==='itil_category'&&parentValue?Number(parentValue):null,layer_ids:layerIDs};
  try{await api(id?`/api/v1/nomenclatures/items/${id}`:'/api/v1/nomenclatures/items',{method:id?'PATCH':'POST',body:JSON.stringify(body)});nomenclatureDialog.close();toast(id?'Valoare actualizată.':'Valoare creată.');refreshNomenclatureSection(categoryCode)}catch(err){toast(err.message,true)}
});
personForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('personId').value||0);const body={display_name:document.getElementById('personName').value.trim(),email:document.getElementById('personEmail').value.trim(),phone:document.getElementById('personPhone').value.trim(),department:document.getElementById('personDepartment').value.trim(),active:document.getElementById('personActive').checked};
  try{await api(id?`/api/v1/people/${id}`:'/api/v1/people',{method:id?'PATCH':'POST',body:JSON.stringify(body)});personDialog.close();toast(id?'Persoană actualizată.':'Persoană creată.');refreshNomenclatureSection('people')}catch(err){toast(err.message,true)}
});

document.getElementById('directoryDepartment').addEventListener('change',loadDirectoryUsers);
document.getElementById('directorySearch').addEventListener('input',renderDirectoryUsers);
document.getElementById('directoryToggleAll').addEventListener('click',()=>{
  const checks=[...document.querySelectorAll('#directoryUsers .directory-user-check')];
  const select=checks.some(check=>!check.checked);checks.forEach(check=>check.checked=select);
});
directoryForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const distinguishedNames=[...document.querySelectorAll('#directoryUsers .directory-user-check:checked')].map(check=>check.value);
  if(!distinguishedNames.length){toast('Selectează cel puțin un utilizator din Active Directory.',true);return}
  try{const imported=await api('/api/v1/people/import-directory',{method:'POST',body:JSON.stringify({distinguished_names:distinguishedNames})});directoryDialog.close();toast(`${imported.length} persoane importate sau actualizate din AD.`);refreshNomenclatureSection('people')}catch(err){toast(err.message,true)}
});


function documentObjectTypeLabel(value){return value==='service'?'Serviciu intern':'VM'}
function updateDocumentTemplateHelp(){
  const type=document.getElementById('documentTemplateObjectType')?.value||'vm';
  const help=document.getElementById('documentTemplateFileHelp');
  if(help)help.textContent=`Șablonul trebuie să conțină placeholderul ${type==='service'?'{{SERVICE_DOCUMENT_BODY}}':'{{VM_DOCUMENT_BODY}}'} într-un paragraf separat.`;
}
function openDocumentTemplate(template=null){
  document.getElementById('documentTemplateDialogTitle').textContent=template?'Editare șablon DOCX':'Șablon DOCX nou';
  document.getElementById('documentTemplateId').value=template?.id||'';
  document.getElementById('documentTemplateName').value=template?.name||'';
  document.getElementById('documentTemplateCode').value=template?.code||'';
  document.getElementById('documentTemplateDescription').value=template?.description||'';
  const objectType=document.getElementById('documentTemplateObjectType');objectType.value=template?.object_type||'vm';objectType.disabled=Boolean(template);
  document.getElementById('documentTemplateActive').checked=template?.active??true;
  document.getElementById('documentTemplateDefault').checked=template?.is_default??false;
  const file=document.getElementById('documentTemplateFile');file.value='';file.required=!template;
  document.getElementById('documentTemplateFileLabel').hidden=Boolean(template);
  updateDocumentTemplateHelp();
  documentTemplateDialog.showModal();
}
function documentTemplateRows(values){
  if(!values?.length)return empty('Nu există șabloane DOCX.');
  const rows=values.map(item=>`<tr><td><strong>${e(item.name)}</strong>${item.description?`<div class="muted">${e(item.description)}</div>`:''}</td><td>${badge(documentObjectTypeLabel(item.object_type))}</td><td class="mono">${e(item.code)}</td><td>${e(item.file_name)}</td><td>${bytesText(item.size_bytes)}</td><td>${item.is_default?badge('implicit'):''}</td><td>${item.active?badge('active'):badge('disabled')}</td><td><div class="actions"><a class="button-link small secondary" href="/api/v1/document-templates/${item.id}/download">Descarcă</a>${can('documents.manage')?`<button class="small secondary edit-document-template" data-id="${item.id}">Editează</button>`:''}</div></td></tr>`).join('');
  return `<div class="table-wrap"><table><thead><tr><th>Șablon</th><th>Tip fișă</th><th>Cod</th><th>Fișier</th><th>Mărime</th><th>Implicit</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
async function documentsPage(){
  pageMeta('Documente','Șabloane DOCX pentru fișele VM și serviciile interne');
  state.documentTemplates=await api(`/api/v1/document-templates${can('documents.manage')?'?include_inactive=true':''}`);
  const active=state.documentTemplates.filter(item=>item.active).length;
  const vmDefault=state.documentTemplates.find(item=>item.object_type==='vm'&&item.is_default);
  const serviceDefault=state.documentTemplates.find(item=>item.object_type==='service'&&item.is_default);
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Șabloane</div><div class="value">${state.documentTemplates.length}</div></div><div class="card"><div class="label">Șabloane active</div><div class="value">${active}</div></div><div class="card"><div class="label">Implicit VM</div><div class="value compact">${e(vmDefault?.name||'—')}</div></div><div class="card"><div class="label">Implicit serviciu</div><div class="value compact">${e(serviceDefault?.name||'—')}</div></div></div>${panel('Șabloane DOCX',documentTemplateRows(state.documentTemplates),can('documents.manage')?'<button id="newDocumentTemplate">Încarcă șablon</button>':'')}${panel('Placeholdere acceptate',`<div class="document-placeholders"><code>{{VM_DOCUMENT_BODY}}</code><span>corp obligatoriu pentru fișa VM</span><code>{{SERVICE_DOCUMENT_BODY}}</code><span>corp obligatoriu pentru fișa serviciului intern</span><code>{{document.number}}</code><span>numărul fișei</span><code>{{document.generated_at}}</code><span>data generării</span><code>{{document.generated_by}}</code><span>utilizatorul care generează</span><code>{{vm.name}}</code><span>numele VM-ului</span><code>{{vm.hostname}}</code><span>hostname</span><code>{{vm.ip}}</code><span>IP principal</span><code>{{vm.os}}</code><span>sistemul de operare</span><code>{{vm.environment}}</code><span>mediul</span><code>{{vm.status}}</code><span>status operațional</span><code>{{vm.classification}}</code><span>clasificarea</span><code>{{vm.purpose}}</code><span>scopul VM-ului</span><code>{{service.name}}</code><span>numele serviciului intern</span><code>{{service.code}}</code><span>codul serviciului</span><code>{{service.criticality}}</code><span>criticitatea serviciului</span><code>{{service.status}}</code><span>statusul documentației</span><code>{{service.description}}</code><span>descrierea serviciului</span><code>{{service.purpose}}</code><span>Scop și domeniu (compatibilitate)</span><code>{{service.scope_domain}}</code><span>Scop și domeniu</span><code>{{service.objectives}}</code><span>Obiectivele serviciului</span></div>`)} `;
  document.getElementById('newDocumentTemplate')?.addEventListener('click',()=>openDocumentTemplate());
  content.querySelectorAll('.edit-document-template').forEach(button=>button.addEventListener('click',()=>openDocumentTemplate(state.documentTemplates.find(item=>item.id===Number(button.dataset.id)))));
}

document.getElementById('documentTemplateObjectType')?.addEventListener('change',updateDocumentTemplateHelp);
documentTemplateForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('documents.manage'))return;
  const id=Number(document.getElementById('documentTemplateId').value||0);
  const name=document.getElementById('documentTemplateName').value.trim();
  const code=document.getElementById('documentTemplateCode').value.trim();
  const objectType=document.getElementById('documentTemplateObjectType').value;
  const description=document.getElementById('documentTemplateDescription').value.trim();
  const active=document.getElementById('documentTemplateActive').checked;
  const isDefault=document.getElementById('documentTemplateDefault').checked;
  try{
    if(id){await api(`/api/v1/document-templates/${id}`,{method:'PATCH',body:JSON.stringify({name,code,description,active,is_default:isDefault})})}
    else{const file=document.getElementById('documentTemplateFile').files[0];if(!file){toast('Alege fișierul DOCX.',true);return}const body=new FormData();body.set('name',name);body.set('code',code);body.set('object_type',objectType);body.set('description',description);body.set('active',String(active));body.set('is_default',String(isDefault));body.set('file',file);await api('/api/v1/document-templates',{method:'POST',body})}
    documentTemplateDialog.close();toast(id?'Șablon actualizat.':'Șablon încărcat.');documentsPage();
  }catch(err){toast(err.message,true)}
});

const reportPalette=['var(--accent)','var(--ok)','var(--warn)','var(--bad)','#8b5cf6','#06b6d4','var(--muted)','var(--text)'];
function reportSeriesPoints(points){return (points||[]).filter(item=>Number(item.value||0)>0)}
function reportDonut(title,points){const data=reportSeriesPoints(points);const total=data.reduce((s,p)=>s+Number(p.value||0),0);if(!total)return `<article class="report-chart">${empty('Fără date pentru '+title)}</article>`;let cursor=0;const stops=data.map((p,i)=>{const start=cursor;cursor+=Number(p.value)/total*100;return `${reportPalette[i%reportPalette.length]} ${start.toFixed(2)}% ${cursor.toFixed(2)}%`}).join(',');return `<article class="report-chart"><header><h3>${e(title)}</h3><strong>${total.toLocaleString('ro-RO')}</strong></header><div class="report-donut-wrap"><div class="report-donut" style="background:conic-gradient(${stops})"><span>${total.toLocaleString('ro-RO')}</span></div><div class="report-legend">${data.map((p,i)=>`<div><i style="background:${reportPalette[i%reportPalette.length]}"></i><span>${e(p.label)}</span><strong>${Number(p.value).toLocaleString('ro-RO')}</strong></div>`).join('')}</div></div></article>`}
function reportBars(title,points,limit=15){const data=reportSeriesPoints(points).slice(0,limit),max=Math.max(1,...data.map(p=>Number(p.value)));return `<article class="report-chart report-bar-chart"><header><h3>${e(title)}</h3></header>${data.length?`<div class="report-bars">${data.map(p=>`<div class="report-bar-row"><span title="${e(p.label)}">${e(p.label)}</span><div><i style="width:${Math.max(2,Number(p.value)/max*100)}%"></i></div><strong>${Number(p.value).toLocaleString('ro-RO')}</strong></div>`).join('')}</div>`:empty('Fără date.')}</article>`}
function reportTimeline(title,points){const data=points||[],max=Math.max(1,...data.map(p=>Number(p.vm||0)+Number(p.service||0)));return `<article class="report-chart report-timeline"><header><h3>${e(title)}</h3><span>ultimele 30 zile</span></header>${data.length?`<div class="timeline-bars">${data.map(p=>{const vm=Number(p.vm||0),sv=Number(p.service||0);return `<div class="timeline-day" title="${e(p.date)} · VM ${vm} · Servicii ${sv}"><div><i class="timeline-vm" style="height:${vm/max*100}%"></i><i class="timeline-service" style="height:${sv/max*100}%"></i></div><span>${e(p.date.slice(5))}</span></div>`}).join('')}</div><div class="timeline-legend"><span><i class="timeline-vm"></i> Fișe VM</span><span><i class="timeline-service"></i> Fișe servicii</span></div>`:empty('Nu au fost generate documente în ultimele 30 de zile.')}</article>`}
function reportSummaryCard(label,value,kind=''){return `<div class="card report-summary-card ${e(kind)}"><div class="label">${e(label)}</div><div class="value">${Number(value||0).toLocaleString('ro-RO')}</div></div>`}
function reportServiceIssues(rows){if(!rows?.length)return empty('Nu sunt identificate probleme de documentare la servicii.');return `<div class="table-wrap"><table><thead><tr><th>Serviciu</th><th>Criticitate</th><th>Status documentație</th><th>VM-uri</th><th>De completat</th></tr></thead><tbody>${rows.map(r=>`<tr><td><a href="#services/${r.id}"><strong>${e(r.name)}</strong></a></td><td>${criticalityBadge(r.criticality)}</td><td>${badge(r.documentation_status)}</td><td>${r.vm_count}</td><td class="warning-text">${e(r.issue)}</td></tr>`).join('')}</tbody></table></div>`}
function reportVMIssues(rows){if(!rows?.length)return empty('Nu sunt identificate probleme de documentare la VM-uri.');return `<div class="table-wrap"><table><thead><tr><th>VM</th><th>Mediu</th><th>Power</th><th>De completat</th></tr></thead><tbody>${rows.map(r=>`<tr><td><a href="#vms/${r.id}"><strong>${e(r.name)}</strong></a><div class="muted mono">${e(r.hostname||'—')}</div></td><td>${environmentBadge(r.environment)}</td><td>${badge(r.power_state||'unknown')}</td><td class="warning-text">${e(r.issue)}</td></tr>`).join('')}</tbody></table></div>`}
function reportInventoryStorage(stats){stats=stats||{};const agents=stats.top_agents||[];const rows=agents.map(a=>`<tr><td><strong>${e(a.agent_name||`Agent #${a.agent_id}`)}</strong></td><td>${Number(a.snapshots||0).toLocaleString('ro-RO')}</td><td>${bytesText(a.payload_bytes||0)}</td><td>${a.oldest_snapshot?dt(a.oldest_snapshot):'—'}</td><td>${a.newest_snapshot?dt(a.newest_snapshot):'—'}</td></tr>`).join('');return `<div class="cards inventory-storage-summary"><div class="card"><div class="label">Snapshot-uri</div><div class="value">${Number(stats.snapshots||0).toLocaleString('ro-RO')}</div></div><div class="card"><div class="label">Payload JSON</div><div class="value compact">${bytesText(stats.payload_bytes||0)}</div></div><div class="card"><div class="label">Date tabelă</div><div class="value compact">${bytesText(stats.table_data_bytes||0)}</div></div><div class="card"><div class="label">Indexuri</div><div class="value compact">${bytesText(stats.table_index_bytes||0)}</div></div></div><div class="inventory-storage-range"><span>Cel mai vechi: <strong>${stats.oldest_snapshot?dt(stats.oldest_snapshot):'—'}</strong></span><span>Cel mai nou: <strong>${stats.newest_snapshot?dt(stats.newest_snapshot):'—'}</strong></span></div>${rows?`<div class="table-wrap"><table><thead><tr><th>Agent</th><th>Snapshot-uri</th><th>Payload</th><th>Cel mai vechi</th><th>Cel mai nou</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există snapshot-uri de inventar.')}`}
const reportCategories=[
  {id:'overview',label:'Prezentare generală'},
  {id:'vms',label:'VM & resurse'},
  {id:'agents',label:'Agenți & inventar'},
  {id:'services',label:'Servicii & arhitectură'},
  {id:'software',label:'Software principal'},
  {id:'dependencies',label:'Dependențe & impact'},
  {id:'documents',label:'Documentație'}
];
function reportSubmenu(active){return `<aside class="nomenclature-submenu report-submenu"><div class="nomenclature-submenu-title">Rapoarte</div><section>${reportCategories.map(item=>`<a href="#reports/${item.id}" class="${active===item.id?'active':''}"><span>${e(item.label)}</span></a>`).join('')}</section></aside>`}
function reportCategoryBody(category,data){
  const s=data.summary||{},c=data.charts||{},topServicePoints=(data.top_services||[]).map(r=>({label:r.name,value:r.vm_count}));
  if(category==='vms')return `${panel('VM & resurse',`<div class="report-grid">${reportDonut('Power state',c.vm_power_state)}${reportDonut('Medii PROD / TEST / DEV',c.vm_environment)}${reportDonut('Status operațional',c.vm_operational_status)}${reportDonut('Dimensionare vCPU',c.vm_cpu_size)}${reportDonut('Dimensionare RAM',c.vm_memory_size)}${reportBars('Sisteme de operare',c.vm_os,12)}${reportBars('Distribuție pe vCenter',c.vm_source,12)}${reportBars('Versiuni hardware VM',c.vm_hardware_version,15)}</div>`)}`;
  if(category==='agents')return `${panel('Agenți & inventar',`<div class="report-grid">${reportDonut('Acoperire agent',c.agent_coverage)}${reportDonut('Prospețime inventar',c.inventory_freshness)}${reportDonut('Protecție backup',c.backup_protection)}</div>`)}${panel('Stocare inventory_snapshots',reportInventoryStorage(data.inventory_storage),'<span class="muted">Retenția implicită păstrează maximum 30 snapshot-uri/agent și maximum 90 zile; snapshot-urile curente și cele referite de documente generate sunt protejate.</span>')}`;
  if(category==='services')return `${panel('Servicii & arhitectură',`<div class="report-grid">${reportDonut('Criticitate servicii',c.service_criticality)}${reportDonut('Tip soluție',c.solution_type)}${reportDonut('Soluții omogene / mixte',c.service_solution_mix)}${reportDonut('Dimensiune servicii după VM-uri',c.service_vm_size)}${reportDonut('Tip utilizare asociere',c.assignment_usage)}${reportDonut('Asocieri principale / secundare',c.assignment_primary)}${reportDonut('Completitudine asocieri',c.assignment_completeness)}${reportBars('Servicii prezente pe medii',c.service_environment_presence,15)}${reportBars('Servicii pe domeniu',c.service_domain,15)}${reportBars('Servicii pe categorie',c.service_category,15)}${reportBars('VM-uri pe layer',c.layer_usage,15)}${reportBars('Roluri tehnice utilizate',c.technical_role_usage,20)}${reportBars('Servicii cu cele mai multe VM-uri',topServicePoints,20)}</div>`)}`;
  if(category==='software')return `${panel('Software principal',`<div class="report-grid">${reportBars('Servicii software marcate principal',c.primary_agent_software,30)}</div><p class="muted report-note">Selecțiile provin din serviciile observate de agent și marcate Principal pe fiecare VM.</p>`)}`;
  if(category==='dependencies')return `${panel('Servicii comune și analiză de impact',`<div class="report-grid">${reportDonut('Servicii comune / globale',c.common_service_kind)}${reportDonut('Tipuri de dependență declarate',c.dependency_type_usage)}${reportBars('Servicii dependente per serviciu comun',c.common_service_impact,20)}${reportBars('VM-uri potențial afectate',c.common_service_vm_impact,20)}${reportDonut('Sisteme externe pe rețele',c.external_network_usage)+reportDonut('Sisteme externe după risc',c.external_network_risk)}</div>`,'<span class="muted">Impactul global include serviciile active; conexiunile externe moștenesc rețeaua, riscul și nivelul de trust.</span>')}`;
  if(category==='documents')return `${panel('Documentație',`<div class="report-grid">${reportDonut('Fișe tehnice VM',c.vm_documentation)}${reportDonut('Status documentație servicii',c.service_documentation_status)}${reportDonut('Fișe servicii',c.service_documentation)}</div>`)}${panel('Activitate documentație',reportTimeline('Documente generate',data.document_timeline))}${panel('Servicii care necesită completări',reportServiceIssues(data.service_issues))}${panel('VM-uri care necesită completări',reportVMIssues(data.vm_issues))}`;
  return `<div class="cards report-summary">${reportSummaryCard('VM-uri active',s.vms_present)}${reportSummaryCard('VM-uri pornite',s.vms_powered_on)}${reportSummaryCard('Servicii active',s.services_active)}${reportSummaryCard('Servicii critice',s.services_critical,'danger')}${reportSummaryCard('Servicii comune',s.services_common)}${reportSummaryCard('Globale implicite',s.services_global)}${reportSummaryCard('Dependențe declarate',s.service_dependencies)}${reportSummaryCard('Rețele externe',s.external_networks)}${reportSummaryCard('Sisteme externe',s.external_systems)}${reportSummaryCard('Conexiuni externe',s.external_connections)}${reportSummaryCard('VM fără mediu',s.vms_without_environment,'warning')}${reportSummaryCard('VM fără serviciu',s.vms_without_service,'warning')}${reportSummaryCard('VM fără fișă',s.vms_without_document,'warning')}${reportSummaryCard('Servicii fără fișă',s.services_without_document,'warning')}</div>${panel('Indicatori cheie',`<div class="report-grid">${reportDonut('Power state',c.vm_power_state)}${reportDonut('Acoperire agent',c.agent_coverage)}${reportDonut('Criticitate servicii',c.service_criticality)}${reportDonut('Fișe tehnice VM',c.vm_documentation)}</div>`)}`;
}
async function reportsPage(category='overview'){
  if(!reportCategories.some(item=>item.id===category))category='overview';
  pageMeta('Rapoarte',reportCategories.find(item=>item.id===category)?.label||'Indicatori');
  if(!state.reportsData)state.reportsData=await api('/api/v1/reports/overview');const data=state.reportsData;
  content.innerHTML=`<div class="nomenclature-layout report-layout">${reportSubmenu(category)}<div class="nomenclature-workspace"><div class="report-header"><div><strong>${e(reportCategories.find(item=>item.id===category)?.label||'Rapoarte')}</strong><span>Generat ${dt(data.generated_at)}</span></div><button id="refreshReports" class="secondary">Reîncarcă</button></div>${reportCategoryBody(category,data)}</div></div>`;
  document.getElementById('refreshReports')?.addEventListener('click',async()=>{state.reportsData=null;await reportsPage(category)});
}

function auditOption(value,label,current){return `<option value="${e(value)}" ${String(current||'')===String(value)?'selected':''}>${e(label||value)}</option>`}
function auditOperationBadge(operation){const labels={created:'Adăugat',updated:'Modificat',deleted:'Șters',operation:'Operație'};return `<span class="audit-operation ${e(operation||'operation')}">${e(labels[operation]||'Operație')}</span>`}
function auditDetailsObject(raw){if(raw==null)return {};if(typeof raw==='object'&&!Array.isArray(raw))return raw;try{return JSON.parse(raw)||{}}catch{return {raw:String(raw)}}}
function auditSimpleValue(value){if(value==null||value==='')return '—';if(typeof value==='boolean')return value?'Da':'Nu';if(typeof value==='object')return JSON.stringify(value);return String(value)}
function auditChangedFields(before,after){before=(before&&typeof before==='object')?before:{};after=(after&&typeof after==='object')?after:{};const keys=[...new Set([...Object.keys(before),...Object.keys(after)])].filter(k=>!['updated_at','created_at','connections'].includes(k)).sort();return keys.filter(k=>JSON.stringify(before[k])!==JSON.stringify(after[k])).map(k=>({key:k,before:before[k],after:after[k]}))}
function auditChangeDetails(record){const details=auditDetailsObject(record.details),operation=record.operation||'operation';if(operation==='updated'&&details.before&&details.after){const changes=auditChangedFields(details.before,details.after);if(!changes.length)return `<p class="muted">Eveniment de modificare fără diferențe de câmp identificabile în payload-ul de audit.</p>`;return `<div class="table-wrap audit-change-table"><table><thead><tr><th>Câmp</th><th>Înainte</th><th>După</th></tr></thead><tbody>${changes.map(c=>`<tr><td class="mono">${e(c.key)}</td><td>${e(auditSimpleValue(c.before))}</td><td>${e(auditSimpleValue(c.after))}</td></tr>`).join('')}</tbody></table></div>`}
  const subject=details.created||details.deleted;if(subject&&typeof subject==='object'){const title=operation==='deleted'?'Date șterse':'Date adăugate';const rows=Object.entries(subject).filter(([k])=>!['created_at','updated_at','connections'].includes(k)).map(([k,v])=>`<tr><td class="mono">${e(k)}</td><td>${e(auditSimpleValue(v))}</td></tr>`).join('');return `<strong>${title}</strong><div class="table-wrap audit-change-table"><table><tbody>${rows}</tbody></table></div>`}
  const entries=Object.entries(details);if(!entries.length)return `<p class="muted">Acest eveniment vechi nu conține detalii suplimentare.</p>`;return `<details class="audit-raw"><summary>Detalii tehnice</summary><pre>${e(JSON.stringify(details,null,2))}</pre></details>`}
async function auditPage(){
  pageMeta('Audit','Cine a schimbat ce, când și cu ce rezultat');
  if(!state.audit.facets){try{state.audit.facets=await api('/api/v1/audit/facets')}catch{state.audit.facets={sources:[],actors:[],actions:[],resource_types:[],outcomes:[]}}}
  const f=state.audit,facets=state.audit.facets||{},filters=`<form id="auditFilters" class="audit-filters"><label class="span-2"><span>Caută</span><input id="auditSearch" type="search" value="${e(f.q)}" placeholder="actor, acțiune, resursă, IP sau detalii"></label><label><span>Actor</span><select id="auditActor"><option value="">Toți</option>${(facets.actors||[]).map(v=>auditOption(v,v,f.actor)).join('')}</select></label><label><span>Sursă</span><select id="auditSource"><option value="">Toate</option>${(facets.sources||[]).map(v=>auditOption(v,v,f.source)).join('')}</select></label><label><span>Acțiune</span><select id="auditAction"><option value="">Toate</option>${(facets.actions||[]).map(v=>auditOption(v,v,f.action)).join('')}</select></label><label><span>Resursă</span><select id="auditResourceType"><option value="">Toate</option>${(facets.resource_types||[]).map(v=>auditOption(v,v,f.resourceType)).join('')}</select></label><label><span>Rezultat</span><select id="auditOutcome"><option value="">Toate</option>${(facets.outcomes||[]).map(v=>auditOption(v,v,f.outcome)).join('')}</select></label><label><span>De la</span><input id="auditFrom" type="date" value="${e(f.from)}"></label><label><span>Până la</span><input id="auditTo" type="date" value="${e(f.to)}"></label><div class="filter-actions"><button type="submit">Aplică</button><button type="button" id="auditReset" class="secondary">Resetează</button></div></form>`;
  content.innerHTML=`${panel('Filtre audit',filters,'<span class="muted">Evenimentele noi de adăugare/modificare/ștergere pot păstra valorile înainte și după. Evenimentele istorice afișează numai datele care au fost salvate la momentul respectiv.</span>')}${panel('Evenimente de audit','<div id="auditTableArea" class="loading">Se încarcă evenimentele…</div>')}`;
  document.getElementById('auditFilters')?.addEventListener('submit',event=>{event.preventDefault();Object.assign(f,{q:document.getElementById('auditSearch').value.trim(),actor:document.getElementById('auditActor').value,source:document.getElementById('auditSource').value,action:document.getElementById('auditAction').value,resourceType:document.getElementById('auditResourceType').value,outcome:document.getElementById('auditOutcome').value,from:document.getElementById('auditFrom').value,to:document.getElementById('auditTo').value,page:1});loadAuditPage()});
  document.getElementById('auditReset')?.addEventListener('click',()=>{state.audit={page:1,pageSize:f.pageSize||10,q:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:state.audit.facets};auditPage()});
  await loadAuditPage()
}
function renderAuditPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există evenimente pentru filtrele selectate.');
  const rows=items.map(record=>`<tr class="audit-row"><td>${dt(record.occurred_at)}</td><td>${e(record.actor_username||'sistem')}<div class="muted mono">${e(record.ip_address||'')}</div></td><td><strong>${e(record.action_label||record.action)}</strong><div class="muted">${e(record.action_description||record.action)}</div><div class="muted mono">${e(record.action)}</div></td><td>${auditOperationBadge(record.operation)}<div>${e(record.resource_type)} ${record.resource_id?`<span class="mono">#${e(record.resource_id)}</span>`:''}</div></td><td>${badge(record.outcome)}</td><td><button class="small secondary audit-toggle" data-id="${record.id}">Detalii</button></td></tr><tr class="audit-detail-row" data-detail-id="${record.id}" hidden><td colspan="6"><div class="audit-detail-card"><div class="detail-grid compact">${detail('Sursă',e(record.source||'—'))}${detail('Acțiune',e(record.action))}${detail('Resursă',e(`${record.resource_type||''} ${record.resource_id||''}`.trim()||'—'))}${detail('IP',e(record.ip_address||'—'),true)}</div>${auditChangeDetails(record)}</div></td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Data</th><th>Actor</th><th>Acțiune</th><th>Resursă / operație</th><th>Rezultat</th><th></th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="auditPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result.pages||1),'audit-page')}</div></div>`;
}
async function loadAuditPage(){
  const area=document.getElementById('auditTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă evenimentele…';const f=state.audit,p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize)});[['q',f.q],['source',f.source],['actor',f.actor],['action',f.action],['resource_type',f.resourceType],['outcome',f.outcome],['from',f.from],['to',f.to]].forEach(([k,v])=>{if(v)p.set(k,v)});
  try{const result=await api(`/api/v1/audit/events?${p}`);f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||10);area.className='';area.innerHTML=renderAuditPage(result);area.querySelectorAll('.audit-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==f.page){f.page=page;loadAuditPage()}}));document.getElementById('auditPageSize')?.addEventListener('change',event=>{f.pageSize=Number(event.target.value);f.page=1;loadAuditPage()});area.querySelectorAll('.audit-toggle').forEach(button=>button.addEventListener('click',()=>{const row=area.querySelector(`[data-detail-id="${button.dataset.id}"]`);if(!row)return;row.hidden=!row.hidden;button.textContent=row.hidden?'Detalii':'Închide'}))}catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}

async function accessPage(){pageMeta('Acces','Mapări grupuri LDAP/OIDC către roluri');const [roles,maps]=await Promise.all([api('/api/v1/rbac/roles'),api('/api/v1/rbac/group-mappings')]);content.innerHTML=`${panel('Adaugă mapare',`<form id="mappingForm" class="detail-grid"><label>Provider<select id="mapProvider"><option value="ldap">LDAP</option><option value="oidc">OIDC</option><option value="any">Oricare</option></select></label><label>Grup<input id="mapGroup" required placeholder="VM-DOC-Operators"></label><label>Rol<select id="mapRole">${roles.map(r=>`<option value="${e(r.name)}">${e(r.name)}</option>`).join('')}</select></label><label class="form-submit"><button type="submit">Adaugă</button></label></form>`)}${panel('Mapări existente',maps.length?`<div class="table-wrap"><table><thead><tr><th>Provider</th><th>Grup</th><th>Rol</th><th></th></tr></thead><tbody>${maps.map(m=>`<tr><td>${e(m.provider)}</td><td class="mono">${e(m.group_name)}</td><td>${badge(m.role)}</td><td><button class="small danger del-map" data-id="${m.id}">Șterge</button></td></tr>`).join('')}</tbody></table></div>`:empty('Nu există mapări.'))}`;
  document.getElementById('mappingForm').onsubmit=async ev=>{ev.preventDefault();await api('/api/v1/rbac/group-mappings',{method:'POST',body:JSON.stringify({provider:document.getElementById('mapProvider').value,group_name:document.getElementById('mapGroup').value.trim(),role:document.getElementById('mapRole').value})});toast('Mapare creată.');accessPage()};content.querySelectorAll('.del-map').forEach(b=>b.onclick=async()=>{await api(`/api/v1/rbac/group-mappings/${b.dataset.id}`,{method:'DELETE'});toast('Mapare ștearsă.');accessPage()})
}

document.getElementById('logoutButton').onclick=async()=>{await api('/api/v1/auth/logout',{method:'POST'});location.href='/login'};
document.getElementById('themeButton').onclick=()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;localStorage.setItem('vm-doc-theme',next)};
const savedTheme=localStorage.getItem('vm-doc-theme');if(savedTheme)document.documentElement.dataset.theme=savedTheme;
bindRichTextToolbars();
window.addEventListener('hashchange',route);
document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
init();
