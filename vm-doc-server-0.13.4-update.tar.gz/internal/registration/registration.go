package registration

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/url"
	"strings"
	"time"

	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/inventory"
)

type Service struct {
	DB                        *sql.DB
	Box                       *cryptox.Box
	Inventory                 inventory.Service
	Token                     string
	AllowHTTPAgents           bool
	DefaultCollectionInterval time.Duration
	DefaultRequestTimeout     time.Duration
	DefaultOfflineAfter       time.Duration
	AcceptedSchemaMajor       int
}

type RegistrationRequest struct {
	ProtocolVersion          string            `json:"protocol_version"`
	Agent                    RegistrationAgent `json:"agent"`
	Host                     RegistrationHost  `json:"host"`
	BaseURL                  string            `json:"base_url"`
	AgentToken               string            `json:"agent_token"`
	RefreshIntervalSeconds   int64             `json:"refresh_interval_seconds"`
	HeartbeatIntervalSeconds int64             `json:"heartbeat_interval_seconds"`
	CollectedAt              time.Time         `json:"collected_at"`
}

type RegistrationAgent struct {
	Name      string `json:"name"`
	Version   string `json:"version"`
	ID        string `json:"id"`
	Commit    string `json:"commit,omitempty"`
	BuildDate string `json:"build_date,omitempty"`
}

type RegistrationHost struct {
	Hostname          string `json:"hostname"`
	FQDN              string `json:"fqdn,omitempty"`
	ProductUUID       string `json:"product_uuid,omitempty"`
	ProductUUIDLegacy string `json:"product_uuid_legacy,omitempty"`
	MachineID         string `json:"machine_id,omitempty"`
	PrimaryIP         string `json:"primary_ip,omitempty"`
}

type HeartbeatRequest struct {
	ProtocolVersion  string            `json:"protocol_version"`
	Agent            RegistrationAgent `json:"agent"`
	RuntimeStatus    string            `json:"runtime_status"`
	CollectionStatus string            `json:"collection_status,omitempty"`
	CollectedAt      time.Time         `json:"collected_at,omitempty"`
	InventorySHA256  string            `json:"inventory_sha256,omitempty"`
}

type RegistrationResponse struct {
	AgentID int64  `json:"agent_id"`
	VMID    *int64 `json:"vm_id,omitempty"`
	Created bool   `json:"created"`
	Linked  bool   `json:"linked"`
}

type HeartbeatResponse struct {
	AgentID    int64     `json:"agent_id"`
	ReceivedAt time.Time `json:"received_at"`
}

type InventoryResponse struct {
	AgentID     int64  `json:"agent_id"`
	InventoryID int64  `json:"inventory_id"`
	JobID       int64  `json:"job_id"`
	VMID        *int64 `json:"vm_id,omitempty"`
	Linked      bool   `json:"linked"`
}

func (s Service) Validate() error {
	if s.DB == nil || s.Box == nil {
		return errors.New("registration service is not initialized")
	}
	if len(strings.TrimSpace(s.Token)) < 24 {
		return errors.New("agent registration token must contain at least 24 characters")
	}
	if s.AcceptedSchemaMajor <= 0 {
		return errors.New("accepted schema major must be positive")
	}
	return nil
}

func (s Service) Authorized(header string) bool {
	provided := strings.TrimSpace(header)
	if len(provided) < 8 || !strings.EqualFold(provided[:7], "Bearer ") {
		return false
	}
	provided = strings.TrimSpace(provided[7:])
	expectedHash := sha256.Sum256([]byte(strings.TrimSpace(s.Token)))
	providedHash := sha256.Sum256([]byte(provided))
	return subtle.ConstantTimeCompare(expectedHash[:], providedHash[:]) == 1
}

func (s Service) Register(ctx context.Context, in RegistrationRequest, remoteIP string) (RegistrationResponse, error) {
	if err := s.validateRegistration(&in); err != nil {
		return RegistrationResponse{}, err
	}
	now := time.Now().UTC()
	collectionInterval := durationOrDefault(in.RefreshIntervalSeconds, s.DefaultCollectionInterval, time.Minute, 24*time.Hour)
	heartbeatInterval := durationOrDefault(in.HeartbeatIntervalSeconds, 5*time.Minute, 30*time.Second, 24*time.Hour)
	offlineAfter := 3 * heartbeatInterval
	if offlineAfter < 2*time.Minute {
		offlineAfter = 2 * time.Minute
	}
	if s.DefaultOfflineAfter > 0 && offlineAfter > s.DefaultOfflineAfter {
		offlineAfter = s.DefaultOfflineAfter
	}
	requestTimeout := s.DefaultRequestTimeout
	if requestTimeout <= 0 {
		requestTimeout = 45 * time.Second
	}

	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return RegistrationResponse{}, err
	}
	defer tx.Rollback()

	agentID, secretRef, existingCiphertext, found, err := findAgentByUUID(ctx, tx, in.Agent.ID)
	if err != nil {
		return RegistrationResponse{}, err
	}
	created := !found
	if !found {
		secretRef, err = cryptox.RandomToken(24)
		if err != nil {
			return RegistrationResponse{}, err
		}
	}
	ciphertext := existingCiphertext
	if strings.TrimSpace(in.AgentToken) != "" {
		ciphertext, err = s.Box.Encrypt([]byte(strings.TrimSpace(in.AgentToken)), "vm-doc-agent-token:"+secretRef)
		if err != nil {
			return RegistrationResponse{}, err
		}
	}
	name, err := uniqueAgentName(ctx, tx, preferredName(in), in.Agent.ID, agentID)
	if err != nil {
		return RegistrationResponse{}, err
	}
	advertisedIP := strings.TrimSpace(in.Host.PrimaryIP)
	if net.ParseIP(advertisedIP) == nil {
		advertisedIP = ""
	}
	remoteIP = normalizedIP(remoteIP)
	if !found {
		res, err := tx.ExecContext(ctx, `INSERT INTO agents(secret_ref,name,base_url,enabled,verify_tls,tls_server_name,token_ciphertext,agent_uuid,collection_interval_seconds,request_timeout_seconds,offline_after_seconds,next_collection_at,last_attempt_at,last_contact_at,last_success_at,last_error,created_by,updated_by,registration_source,registered_at,last_heartbeat_at,agent_version,host_hostname,host_fqdn,product_uuid,product_uuid_legacy,machine_id,last_advertised_ip,last_registration_ip) VALUES(?,?,?,1,1,'',?,?,?,?,?,NULL,?,?,NULL,'',NULL,NULL,'auto',?,?,?,?,?,?,?,?,?)`,
			secretRef, name, strings.TrimRight(in.BaseURL, "/"), ciphertext, in.Agent.ID, int(collectionInterval.Seconds()), int(requestTimeout.Seconds()), int(offlineAfter.Seconds()), now, now, now, in.Agent.Version, in.Host.Hostname, in.Host.FQDN, in.Host.ProductUUID, in.Host.ProductUUIDLegacy, in.Host.MachineID, advertisedIP, remoteIP)
		if err != nil {
			return RegistrationResponse{}, err
		}
		agentID, err = res.LastInsertId()
		if err != nil {
			return RegistrationResponse{}, err
		}
	} else {
		_, err = tx.ExecContext(ctx, `UPDATE agents SET name=?,base_url=?,enabled=1,token_ciphertext=?,collection_interval_seconds=?,request_timeout_seconds=?,offline_after_seconds=?,last_attempt_at=?,last_contact_at=?,last_error='',registration_source='auto',registered_at=COALESCE(registered_at,?),last_heartbeat_at=?,agent_version=?,host_hostname=?,host_fqdn=?,product_uuid=?,product_uuid_legacy=?,machine_id=?,last_advertised_ip=?,last_registration_ip=? WHERE id=?`,
			name, strings.TrimRight(in.BaseURL, "/"), ciphertext, int(collectionInterval.Seconds()), int(requestTimeout.Seconds()), int(offlineAfter.Seconds()), now, now, now, now, in.Agent.Version, in.Host.Hostname, in.Host.FQDN, in.Host.ProductUUID, in.Host.ProductUUIDLegacy, in.Host.MachineID, advertisedIP, remoteIP, agentID)
		if err != nil {
			return RegistrationResponse{}, err
		}
	}
	if err := reconcileReportedVersion(ctx, tx, agentID, in.Agent.Version, now); err != nil {
		return RegistrationResponse{}, err
	}
	vmID, linked, err := linkAgentToVM(ctx, tx, agentID, in.Host)
	if err != nil {
		return RegistrationResponse{}, err
	}
	if err := tx.Commit(); err != nil {
		return RegistrationResponse{}, err
	}
	return RegistrationResponse{AgentID: agentID, VMID: vmID, Created: created, Linked: linked}, nil
}

func (s Service) Heartbeat(ctx context.Context, in HeartbeatRequest, remoteIP string) (HeartbeatResponse, error) {
	if strings.TrimSpace(in.ProtocolVersion) != "1" {
		return HeartbeatResponse{}, errors.New("unsupported protocol_version")
	}
	in.Agent.ID = strings.TrimSpace(in.Agent.ID)
	if in.Agent.ID == "" {
		return HeartbeatResponse{}, errors.New("agent.id is required")
	}
	now := time.Now().UTC()
	res, err := s.DB.ExecContext(ctx, `UPDATE agents SET last_attempt_at=?,last_contact_at=?,last_heartbeat_at=?,last_error='',agent_version=?,last_registration_ip=? WHERE agent_uuid=?`, now, now, now, strings.TrimSpace(in.Agent.Version), normalizedIP(remoteIP), in.Agent.ID)
	if err != nil {
		return HeartbeatResponse{}, err
	}
	rows, _ := res.RowsAffected()
	if rows == 0 {
		return HeartbeatResponse{}, sql.ErrNoRows
	}
	var agentID int64
	if err := s.DB.QueryRowContext(ctx, `SELECT id FROM agents WHERE agent_uuid=? ORDER BY id LIMIT 1`, in.Agent.ID).Scan(&agentID); err != nil {
		return HeartbeatResponse{}, err
	}
	if err := reconcileReportedVersion(ctx, s.DB, agentID, in.Agent.Version, now); err != nil {
		return HeartbeatResponse{}, err
	}
	return HeartbeatResponse{AgentID: agentID, ReceivedAt: now}, nil
}

func (s Service) SaveInventory(ctx context.Context, raw []byte) (InventoryResponse, error) {
	summary, err := inventory.Summarize(raw)
	if err != nil {
		return InventoryResponse{}, fmt.Errorf("invalid inventory: %w", err)
	}
	if strings.TrimSpace(summary.AgentUUID) == "" {
		return InventoryResponse{}, errors.New("inventory does not contain agent.id")
	}
	if schemaMajor(summary.SchemaVersion) != s.AcceptedSchemaMajor {
		return InventoryResponse{}, fmt.Errorf("schema %s is not supported", summary.SchemaVersion)
	}
	var agentID int64
	if err := s.DB.QueryRowContext(ctx, `SELECT id FROM agents WHERE agent_uuid=? ORDER BY id LIMIT 1`, summary.AgentUUID).Scan(&agentID); err != nil {
		return InventoryResponse{}, err
	}
	now := time.Now().UTC()
	res, err := s.DB.ExecContext(ctx, `INSERT INTO collection_jobs(agent_id,kind,source,status,scheduled_at,started_at,attempt_count,error_message) VALUES(?,'collect','push','running',?,?,1,'')`, agentID, now, now)
	if err != nil {
		return InventoryResponse{}, err
	}
	jobID, err := res.LastInsertId()
	if err != nil {
		return InventoryResponse{}, err
	}
	inv, err := s.Inventory.Save(ctx, agentID, jobID, raw, summary)
	if err != nil {
		_, _ = s.DB.ExecContext(ctx, `UPDATE collection_jobs SET status='failed',finished_at=?,error_code='inventory_save_failed',error_message=? WHERE id=?`, time.Now().UTC(), truncate(err.Error(), 4000), jobID)
		return InventoryResponse{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE collection_jobs SET status='succeeded',finished_at=?,http_status=200,error_code='',error_message='' WHERE id=?`, time.Now().UTC(), jobID)
	if err != nil {
		return InventoryResponse{}, err
	}
	vmID, linked, err := currentVMForAgent(ctx, s.DB, agentID)
	if err != nil {
		return InventoryResponse{}, err
	}
	return InventoryResponse{AgentID: agentID, InventoryID: inv.ID, JobID: jobID, VMID: vmID, Linked: linked}, nil
}

type execContexter interface {
	ExecContext(context.Context, string, ...any) (sql.Result, error)
}

// reconcileReportedVersion closes a cached update transaction as soon as the
// restarted agent reports the version that had been marked as available.
// This is intentionally driven by the reported running binary version rather
// than by the 30-minute update-status cache TTL.
func reconcileReportedVersion(ctx context.Context, exec execContexter, agentID int64, reportedVersion string, now time.Time) error {
	reportedVersion = strings.TrimSpace(reportedVersion)
	if agentID < 1 || reportedVersion == "" {
		return nil
	}
	_, err := exec.ExecContext(ctx, `UPDATE agents
SET update_state='current',
    update_available_version='',
    update_last_success_at=?,
    update_last_error='',
    update_status_checked_at=?
WHERE id=?
  AND update_available_version<>''
  AND update_available_version=?`, now, now, agentID, reportedVersion)
	return err
}

func (s Service) validateRegistration(in *RegistrationRequest) error {
	in.ProtocolVersion = strings.TrimSpace(in.ProtocolVersion)
	in.Agent.ID = strings.TrimSpace(in.Agent.ID)
	in.Agent.Name = strings.TrimSpace(in.Agent.Name)
	in.Agent.Version = strings.TrimSpace(in.Agent.Version)
	in.Host.Hostname = strings.TrimSpace(in.Host.Hostname)
	in.Host.FQDN = strings.TrimSpace(in.Host.FQDN)
	in.BaseURL = strings.TrimSpace(in.BaseURL)
	in.AgentToken = strings.TrimSpace(in.AgentToken)
	if in.ProtocolVersion != "1" {
		return errors.New("unsupported protocol_version")
	}
	if in.Agent.ID == "" || len(in.Agent.ID) > 255 {
		return errors.New("agent.id is required and must be at most 255 characters")
	}
	if in.Host.Hostname == "" {
		return errors.New("host.hostname is required")
	}
	if len(in.AgentToken) < 24 {
		return errors.New("agent_token must contain at least 24 characters")
	}
	u, err := url.Parse(in.BaseURL)
	if err != nil || u.Hostname() == "" {
		return errors.New("base_url is invalid")
	}
	if u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return errors.New("base_url must contain only scheme, host and optional port")
	}
	if u.Scheme != "https" && !(s.AllowHTTPAgents && u.Scheme == "http") {
		return errors.New("base_url must use HTTPS")
	}
	return nil
}

func findAgentByUUID(ctx context.Context, tx *sql.Tx, uuid string) (id int64, secretRef, ciphertext string, found bool, err error) {
	rows, err := tx.QueryContext(ctx, `SELECT id,secret_ref,token_ciphertext FROM agents WHERE agent_uuid=? ORDER BY id LIMIT 2 FOR UPDATE`, uuid)
	if err != nil {
		return 0, "", "", false, err
	}
	defer rows.Close()
	count := 0
	for rows.Next() {
		count++
		if err := rows.Scan(&id, &secretRef, &ciphertext); err != nil {
			return 0, "", "", false, err
		}
	}
	if err := rows.Err(); err != nil {
		return 0, "", "", false, err
	}
	if count > 1 {
		return 0, "", "", false, errors.New("multiple agents use the same agent UUID")
	}
	return id, secretRef, ciphertext, count == 1, nil
}

func uniqueAgentName(ctx context.Context, tx *sql.Tx, preferred, agentUUID string, currentID int64) (string, error) {
	preferred = strings.TrimSpace(preferred)
	if preferred == "" {
		preferred = "vm-doc-agent"
	}
	if len(preferred) > 190 {
		preferred = preferred[:190]
	}
	candidate := preferred
	for i := 0; i < 100; i++ {
		var id int64
		err := tx.QueryRowContext(ctx, `SELECT id FROM agents WHERE name=? LIMIT 1`, candidate).Scan(&id)
		if errors.Is(err, sql.ErrNoRows) || (err == nil && id == currentID) {
			return candidate, nil
		}
		if err != nil {
			return "", err
		}
		suffix := shortID(agentUUID)
		if i > 0 {
			suffix = fmt.Sprintf("%s-%d", suffix, i+1)
		}
		maxBase := 190 - len(suffix) - 1
		base := preferred
		if len(base) > maxBase {
			base = base[:maxBase]
		}
		candidate = base + "-" + suffix
	}
	return "", errors.New("could not allocate a unique agent name")
}

func preferredName(in RegistrationRequest) string {
	return firstNonEmpty(in.Host.FQDN, in.Host.Hostname, in.Agent.ID)
}

func linkAgentToVM(ctx context.Context, tx *sql.Tx, agentID int64, host RegistrationHost) (*int64, bool, error) {
	values := uniqueNonEmpty(normalizeUUID(host.ProductUUID), normalizeUUID(host.ProductUUIDLegacy))
	if len(values) == 0 {
		return nil, false, nil
	}
	placeholders := strings.TrimRight(strings.Repeat("?,", len(values)), ",")
	args := make([]any, len(values))
	for i := range values {
		args[i] = values[i]
	}
	rows, err := tx.QueryContext(ctx, `SELECT id,agent_id FROM virtual_machines WHERE bios_uuid_normalized IN (`+placeholders+`)`, args...)
	if err != nil {
		return nil, false, err
	}
	defer rows.Close()
	type vmCandidate struct {
		id      int64
		agentID sql.NullInt64
	}
	var candidates []vmCandidate
	for rows.Next() {
		var c vmCandidate
		if err := rows.Scan(&c.id, &c.agentID); err != nil {
			return nil, false, err
		}
		candidates = append(candidates, c)
	}
	if err := rows.Err(); err != nil {
		return nil, false, err
	}
	if len(candidates) != 1 {
		return nil, false, nil
	}
	selected := candidates[0]
	if selected.agentID.Valid && selected.agentID.Int64 != agentID {
		return nil, false, nil
	}
	if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=NULL,current_inventory_id=NULL WHERE agent_id=? AND id<>?`, agentID, selected.id); err != nil {
		return nil, false, err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=? WHERE id=?`, agentID, selected.id); err != nil {
		return nil, false, err
	}
	id := selected.id
	return &id, true, nil
}

func currentVMForAgent(ctx context.Context, db *sql.DB, agentID int64) (*int64, bool, error) {
	var id int64
	err := db.QueryRowContext(ctx, `SELECT id FROM virtual_machines WHERE agent_id=? ORDER BY id LIMIT 1`, agentID).Scan(&id)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, false, nil
	}
	if err != nil {
		return nil, false, err
	}
	return &id, true, nil
}

func durationOrDefault(seconds int64, fallback, min, max time.Duration) time.Duration {
	value := time.Duration(seconds) * time.Second
	if value < min || value > max {
		return fallback
	}
	return value
}

func normalizedIP(value string) string {
	value = strings.TrimSpace(value)
	ip := net.ParseIP(value)
	if ip == nil {
		return ""
	}
	return ip.String()
}

func normalizeUUID(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	value = strings.Trim(value, "{}")
	return strings.ReplaceAll(value, " ", "")
}

func uniqueNonEmpty(values ...string) []string {
	seen := map[string]struct{}{}
	out := make([]string, 0, len(values))
	for _, value := range values {
		if value == "" {
			continue
		}
		if _, ok := seen[value]; ok {
			continue
		}
		seen[value] = struct{}{}
		out = append(out, value)
	}
	return out
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if value = strings.TrimSpace(value); value != "" {
			return value
		}
	}
	return ""
}

func shortID(value string) string {
	value = strings.NewReplacer("-", "", "_", "", " ", "").Replace(strings.ToLower(value))
	if len(value) > 8 {
		return value[:8]
	}
	if value == "" {
		return "auto"
	}
	return value
}

func schemaMajor(value string) int {
	var major int
	_, _ = fmt.Sscanf(strings.TrimSpace(value), "%d", &major)
	return major
}

func truncate(value string, max int) string {
	if len(value) > max {
		return value[:max]
	}
	return value
}

func MarshalForTest(v any) []byte {
	raw, _ := json.Marshal(v)
	return raw
}
