# Upgrade vm-doc-server 0.13.3 → 0.13.4

0.13.4 este un hotfix pentru statusul de auto-update rămas în `installing` după ce agentul s-a actualizat cu succes.

## Simptom reparat

În **Agenți → Listare agenți**, după apăsarea butonului **Update**, agentul ajunge corect la versiunea nouă, dar coloana **Canal update** putea rămâne de forma:

```text
stable
installing · 1.3.6
```

Cauza era cache-ul `update_state` din tabela `agents`: răspunsul inițial al agentului era salvat ca `installing`, iar heartbeat-ul imediat după restart nu forța refresh-ul deoarece `update_status_checked_at` era prea recent (TTL 30 minute).

## Ce face 0.13.4

- la register și heartbeat, versiunea raportată de agent este comparată cu `update_available_version`;
- dacă sunt egale, serverul consideră instalarea finalizată și setează `update_state='current'`;
- `update_available_version` este golit;
- `update_last_success_at` și `update_status_checked_at` sunt actualizate;
- UI-ul face câteva refresh-uri scurte după un Update forțat.

Nu există migrare SQL nouă și nu trebuie actualizat `vm-doc-agent 1.3.6`.

## Upgrade din sursă

```bash
systemctl stop vm-doc-server vm-doc-collector
cp -a /usr/local/src/vm-doc-server-0.13.3 /usr/local/src/vm-doc-server-0.13.4
tar -xzf vm-doc-server-0.13.4-update.tar.gz -C /usr/local/src/vm-doc-server-0.13.4
cd /usr/local/src/vm-doc-server-0.13.4
./scripts/build.sh
systemctl start vm-doc-server vm-doc-collector
```

## Corectarea imediată a statusurilor deja rămase în installing

După backup, poți rula o singură dată:

```sql
UPDATE agents
SET update_state='current',
    update_available_version='',
    update_last_success_at=UTC_TIMESTAMP(6),
    update_last_error='',
    update_status_checked_at=UTC_TIMESTAMP(6)
WHERE update_available_version <> ''
  AND update_available_version = agent_version
  AND update_state <> 'current';
```

Această comandă afectează doar agenții care raportează deja exact versiunea pe care serverul o avea ca versiune disponibilă.
