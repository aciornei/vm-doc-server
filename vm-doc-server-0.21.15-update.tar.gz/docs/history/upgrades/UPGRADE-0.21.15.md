# Upgrade VM-DOC Server 0.21.14 → 0.21.15

## Ce se schimbă

- **Migrarea SQL 076** adaugă `scope`, `technology`, `lifecycle`, `revision` la profiluri, operator la reguli și tabele pentru benchmarkuri și revizii publicate.
- Cele 6 profiluri OS și cele 25 de reguli existente rămân intacte și publicate. Asocierile VM și mapările CIS existente se păstrează.
- Nomenclatoare → Securitate → Hardening: **Benchmarkuri / Profiluri / Bibliotecă reguli**.
- Profilurile noi pornesc în Draft. Se pot edita, clona, atașa reguli și publica; publicarea salvează un snapshot. Profilurile publicate se clonează pentru schimbări structurale.
- Import/export JSON VM-DOC pentru profiluri interne; la import mapările CIS se marchează `pending`.
- Șabloanele pentru Apache/Nginx/MariaDB/MySQL/PostgreSQL/MongoDB/Docker sunt Draft, fără reguli active. **Nu se evaluează automat componentele** până nu avem dovezile corespunzătoare în agent.
- Comparatoare read-only (`eq`, `ne`, `in`, `not_in`, `gte`, `lte`, `gt`, `lt`, `exists`, `not_exists`) plus pragurile legacy.

## Upgrade offline (staging mai întâi)

Backup complet MariaDB înainte de primul start: 076 este o migrare aditivă. **Nu instala în producție înainte de build și testele din staging.**

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.14 vm-doc-server-0.21.15
cd vm-doc-server-0.21.15
tar -xzf /cale/vm-doc-server-0.21.15-update.tar.gz -C .
bash scripts/cleanup-source-tree.sh --check
GOPROXY=off GOFLAGS=-mod=vendor go test ./internal/... ./cmd/...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Păstrează `vendor/` din sursele funcționale 0.21.14. Nu rula `go mod vendor` pe serverul offline.

## Verificări după pornire

1. `/version` și istoric release = 0.21.15.
2. Confirmă aplicarea migrării 076 și existența celor 6 profiluri OS originale.
3. Nomenclatoare → Hardening: creează un profil Draft test; clonează un profil publicat și adaugă o regulă proprie (`manual.*` pentru verificare manuală).
4. Publică profilul Draft, verifică snapshotul și disponibilitatea în selecție numai pentru OS compatibil.
5. Verifică import/export JSON și blocarea modificării structurale a unui profil publicat.
6. Verifică `Swagger` și raportul Hardening; rulează o colectare cu agentul 1.7.18.

## Compatibilitate, securitate, limite

- Agent modern 1.7.18 neschimbat; legacy pot rămâne cu evidențe lipsă (`unknown`).
- Fără execuție de comenzi din reguli, fără remedieri automate, fără citire/parole Vault și fără exportarea acestora.
- Niciun ID de recomandare CIS nu a fost presupus sau importat în masă; mapările sunt metadata de validat.
- Profilele componentă sunt gestionate în catalog, dar evaluarea automată per instanță Apache/Nginx/DB/Docker și raportarea de acoperire integrală CIS sunt **etape viitoare**.
- Testele unitare Go (hardening/domain/xlsx), JavaScript, OpenAPI și testul UI simulat au trecut. Compilarea **integrală** și testele MariaDB reală rămân de executat la tine.

## Rollback

Oprește serviciul; restaurează binarul 0.21.14 și backupul bazei înainte de migrarea 076 dacă revii complet. Migrarea `076.down.sql` nu elimină date automat. Nu rula DROP pe tabelele de reguli în producție.
