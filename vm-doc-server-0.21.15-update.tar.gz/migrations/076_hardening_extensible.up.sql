-- VM-DOC 0.21.15: configurable internal hardening catalog, read-only evaluation.
-- Existing six profiles remain published and retain VM assignments and mappings.
ALTER TABLE hardening_profiles
 ADD COLUMN scope VARCHAR(16) NOT NULL DEFAULT 'os',
 ADD COLUMN technology VARCHAR(64) NOT NULL DEFAULT '',
 ADD COLUMN lifecycle VARCHAR(16) NOT NULL DEFAULT 'published',
 ADD COLUMN revision INT NOT NULL DEFAULT 1,
 ADD COLUMN updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6);
UPDATE hardening_profiles SET technology=os_match WHERE technology='';
ALTER TABLE hardening_rules ADD COLUMN operator VARCHAR(16) NOT NULL DEFAULT 'eq';
CREATE TABLE IF NOT EXISTS hardening_benchmarks (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(80) NOT NULL UNIQUE,
 name VARCHAR(255) NOT NULL,
 technology VARCHAR(64) NOT NULL,
 benchmark_version VARCHAR(40) NOT NULL,
 benchmark_url VARCHAR(1024) NOT NULL DEFAULT '',
 notes VARCHAR(1024) NOT NULL DEFAULT '',
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO hardening_benchmarks (code,name,technology,benchmark_version,benchmark_url)
 SELECT CONCAT('builtin-',code),benchmark,technology,benchmark_version,benchmark_url FROM hardening_profiles;
CREATE TABLE IF NOT EXISTS hardening_profile_revisions (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 profile_id BIGINT NOT NULL,
 revision INT NOT NULL,
 snapshot_json LONGTEXT NOT NULL,
 published_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uq_hpr_revision(profile_id,revision),
 CONSTRAINT fk_hardening_revision_profile FOREIGN KEY(profile_id) REFERENCES hardening_profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Starter templates are deliberately DRAFT with zero rules. They do not claim CIS compliance.
INSERT IGNORE INTO hardening_profiles (code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url,enabled,scope,technology,lifecycle,revision) VALUES
 ('nginx-starter','Nginx — Profil web (de configurat)','','','custom','CIS NGINX Benchmark','','https://www.cisecurity.org/benchmark/nginx',0,'component','nginx','draft',1),
 ('apache-httpd-starter','Apache HTTP Server — Profil web (de configurat)','','','custom','CIS Apache HTTP Server Benchmark','','https://www.cisecurity.org/benchmark/apache_http_server',0,'component','apache','draft',1),
 ('mariadb-starter','MariaDB — Profil DB (de configurat)','','','custom','CIS MariaDB Benchmark','','https://www.cisecurity.org/',0,'component','mariadb','draft',1),
 ('mysql-starter','MySQL — Profil DB (de configurat)','','','custom','CIS MySQL Benchmark','','https://www.cisecurity.org/',0,'component','mysql','draft',1),
 ('postgresql-starter','PostgreSQL — Profil DB (de configurat)','','','custom','CIS PostgreSQL Benchmark','','https://www.cisecurity.org/',0,'component','postgresql','draft',1),
 ('mongodb-starter','MongoDB — Profil DB (de configurat)','','','custom','CIS MongoDB Benchmark','','https://www.cisecurity.org/',0,'component','mongodb','draft',1),
 ('docker-starter','Docker — Profil containere (de configurat)','','','custom','CIS Docker Benchmark','','https://www.cisecurity.org/benchmark/docker',0,'component','docker','draft',1);
