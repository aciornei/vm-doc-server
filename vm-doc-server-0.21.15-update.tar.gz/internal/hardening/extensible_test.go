package hardening

import "testing"

func TestConfigurableOperators(t *testing.T) {
	raw := []byte(`{"hardening":{"evidence":[{"key":"linux.test","value":"15","source":"unit-test","status":"observed"}]}}`)
	cases := []struct{ operator, expected, status string }{
		{"eq", "15", "pass"}, {"ne", "12", "pass"}, {"gte", "10", "pass"}, {"lt", "10", "fail"},
		{"in", "10,15,20", "pass"}, {"not_in", "10,12", "pass"}, {"exists", "", "pass"},
		{"invalid", "15", "unknown"},
	}
	for _, c := range cases {
		r := Rule{Code: "CUSTOM", Name: "Test", CheckKey: "linux.test", Expected: c.expected, Operator: c.operator, Enabled: true}
		result := Evaluate(raw, []Rule{r})
		if len(result) != 1 || result[0].Status != c.status {
			t.Errorf("%s %s: got %+v, want %s", c.operator, c.expected, result, c.status)
		}
	}
}
func TestUnobservedNotCompliant(t *testing.T) {
	raw := []byte(`{"hardening":{"evidence":[{"key":"linux.test","value":"true","status":"unknown"}]}}`)
	r := Rule{Code: "CUSTOM", Name: "Test", CheckKey: "linux.test", Expected: "true", Operator: "eq", Enabled: true}
	if got := Evaluate(raw, []Rule{r})[0].Status; got != "unknown" {
		t.Fatalf("unknown collector marked %s", got)
	}
}
func TestDraftAndComponentNotAutoPicked(t *testing.T) {
	os := OSIdentity{ID: "ubuntu", Name: "Ubuntu Linux", Version: "24.04"}
	for _, p := range []Profile{
		{OSMatch: "ubuntu", VersionPrefix: "24.04", Scope: "os", Lifecycle: "draft", Enabled: true},
		{OSMatch: "ubuntu", VersionPrefix: "24.04", Scope: "component", Lifecycle: "published", Enabled: true},
		{OSMatch: "ubuntu", VersionPrefix: "24.04", Scope: "os", Lifecycle: "archived", Enabled: true},
	} {
		if Matches(p, os) {
			t.Fatalf("incorrect auto assign %+v", p)
		}
	}
	if !Matches(Profile{OSMatch: "ubuntu", VersionPrefix: "24.04", Scope: "os", Lifecycle: "published", Enabled: true}, os) {
		t.Fatal("published OS profile rejected")
	}
}
