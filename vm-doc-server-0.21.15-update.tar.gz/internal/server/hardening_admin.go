package server

// Configurable read-only hardening catalog. Published profiles are immutable:
// administrators clone them to create new revisions. No arbitrary commands are executed.
import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"regexp"
	"strconv"
	"strings"

	"vm-doc-server/internal/hardening"
)

type hardeningBenchmark struct {
	ID         int64  `json:"id"`
	Code       string `json:"code"`
	Name       string `json:"name"`
	Technology string `json:"technology"`
	Version    string `json:"benchmark_version"`
	URL        string `json:"benchmark_url"`
	Notes      string `json:"notes"`
}
type hardeningProfileInput struct {
	Code             string `json:"code"`
	Name             string `json:"name"`
	Scope            string `json:"scope"`
	Technology       string `json:"technology"`
	OSMatch          string `json:"os_match"`
	VersionPrefix    string `json:"version_prefix"`
	Level            string `json:"level"`
	Benchmark        string `json:"benchmark"`
	BenchmarkVersion string `json:"benchmark_version"`
	BenchmarkURL     string `json:"benchmark_url"`
}
type hardeningRuleInput struct {
	Code     string `json:"code"`
	Name     string `json:"name"`
	Category string `json:"category"`
	CheckKey string `json:"check_key"`
	Expected string `json:"expected"`
	Severity string `json:"severity"`
	Operator string `json:"operator"`
}
type hardeningProfileExport struct {
	Format   string                   `json:"format"`
	Profile  hardeningProfileInput    `json:"profile"`
	Rules    []hardeningRuleInput     `json:"rules"`
	Mappings []hardeningExportMapping `json:"mappings"`
}
type hardeningExportMapping struct {
	RuleCode         string `json:"rule_code"`
	RecommendationID string `json:"recommendation_id"`
	ControlID        string `json:"control_id"`
	Status           string `json:"status"`
	Note             string `json:"note"`
}

var hardeningSlug = regexp.MustCompile(`^[a-zA-Z][a-zA-Z0-9_.-]{2,79}$`)
var hardeningCheck = regexp.MustCompile(`^(linux|windows|firewall|ntp|accounts|services|manual|web|db|docker|hardening)\.[a-zA-Z0-9_.-]+$`)

func validHardeningProfile(p hardeningProfileInput) error {
	if !hardeningSlug.MatchString(p.Code) || len(p.Name) < 3 || len(p.Name) > 255 || len(p.Technology) > 64 || len(p.VersionPrefix) > 30 || len(p.Level) > 12 || len(p.Benchmark) > 255 || len(p.BenchmarkVersion) > 30 || len(p.BenchmarkURL) > 1024 {
		return errors.New("invalid profile fields")
	}
	if p.Scope != "os" && p.Scope != "component" {
		return errors.New("scope must be os or component")
	}
	if p.Technology == "" {
		return errors.New("technology is required")
	}
	if p.Scope == "os" && p.OSMatch != "ubuntu" && p.OSMatch != "debian" && p.OSMatch != "windows" && p.OSMatch != "linux" {
		return errors.New("OS family is unsupported for automatic assignment")
	}
	if p.Scope == "component" && p.OSMatch != "" {
		return errors.New("component profiles must not set OS family")
	}
	if p.Level == "" {
		return errors.New("level is required")
	}
	if p.BenchmarkURL != "" && !strings.HasPrefix(p.BenchmarkURL, "https://") {
		return errors.New("benchmark link must use HTTPS")
	}
	return nil
}
func validHardeningRule(v hardeningRuleInput) error {
	if !hardeningSlug.MatchString(v.Code) || len(v.Code) > 64 || len(v.Name) < 3 || len(v.Name) > 255 || v.Category == "" || len(v.Category) > 80 || !hardeningCheck.MatchString(v.CheckKey) || len(v.CheckKey) > 100 || len(v.Expected) > 80 {
		return errors.New("invalid hardening rule")
	}
	switch v.Severity {
	case "low", "medium", "high":
	default:
		return errors.New("severity must be low, medium or high")
	}
	switch v.Operator {
	case "eq", "ne", "in", "not_in", "exists", "not_exists", "gt", "gte", "lt", "lte":
	default:
		return errors.New("unsupported safe comparison operator")
	}
	if v.Operator != "exists" && v.Operator != "not_exists" && v.Expected == "" {
		return errors.New("expected value is required")
	}
	return nil
}
func (a *App) hardeningCreateBenchmark(w http.ResponseWriter, r *http.Request) {
	var b hardeningBenchmark
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&b); err != nil {
		badRequest(w, err)
		return
	}
	if !hardeningSlug.MatchString(b.Code) || len(b.Name) < 3 || len(b.Name) > 255 || len(b.Technology) == 0 || len(b.Technology) > 64 || len(b.Version) > 40 || len(b.URL) > 1024 || len(b.Notes) > 1024 || (b.URL != "" && !strings.HasPrefix(b.URL, "https://")) {
		badRequest(w, errors.New("invalid benchmark metadata"))
		return
	}
	res, err := a.DB.ExecContext(r.Context(), `INSERT INTO hardening_benchmarks(code,name,technology,benchmark_version,benchmark_url,notes) VALUES(?,?,?,?,?,?)`, b.Code, b.Name, b.Technology, b.Version, b.URL, b.Notes)
	if err != nil {
		respond(w, nil, err)
		return
	}
	id, _ := res.LastInsertId()
	a.auditRequest(r, "hardening.benchmark.create", "hardening_benchmark", fmt.Sprint(id), "success", map[string]any{"code": b.Code})
	jsonResponse(w, 201, map[string]any{"id": id, "ok": true})
}
func (a *App) hardeningCreateProfile(w http.ResponseWriter, r *http.Request) {
	var b hardeningProfileInput
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 32<<10)).Decode(&b); err != nil {
		badRequest(w, err)
		return
	}
	if err := validHardeningProfile(b); err != nil {
		badRequest(w, err)
		return
	}
	res, err := a.DB.ExecContext(r.Context(), `INSERT INTO hardening_profiles(code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url,enabled,scope,technology,lifecycle,revision) VALUES(?,?,?,?,?,?,?,?,0,?,?,'draft',1)`, b.Code, b.Name, b.OSMatch, b.VersionPrefix, b.Level, b.Benchmark, b.BenchmarkVersion, b.BenchmarkURL, b.Scope, b.Technology)
	if err != nil {
		respond(w, nil, err)
		return
	}
	id, _ := res.LastInsertId()
	a.auditRequest(r, "hardening.profile.create", "hardening_profile", fmt.Sprint(id), "success", map[string]any{"code": b.Code})
	jsonResponse(w, 201, map[string]any{"id": id, "status": "draft"})
}
func hardeningID(r *http.Request) (int64, error) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		return 0, errors.New("invalid profile id")
	}
	return id, nil
}
func (a *App) hardeningProfileDraft(ctx context.Context, id int64) error {
	var lifecycle string
	err := a.DB.QueryRowContext(ctx, `SELECT lifecycle FROM hardening_profiles WHERE id=?`, id).Scan(&lifecycle)
	if err != nil {
		return err
	}
	if lifecycle != "draft" {
		return errors.New("profile is immutable; clone it to make changes")
	}
	return nil
}
func (a *App) hardeningUpdateDraft(w http.ResponseWriter, r *http.Request) {
	id, err := hardeningID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	if err = a.hardeningProfileDraft(r.Context(), id); err != nil {
		badRequest(w, err)
		return
	}
	var b hardeningProfileInput
	if err = json.NewDecoder(http.MaxBytesReader(w, r.Body, 32<<10)).Decode(&b); err != nil {
		badRequest(w, err)
		return
	}
	if err = validHardeningProfile(b); err != nil {
		badRequest(w, err)
		return
	}
	// Code is stable: changing a draft code requires creating a separate draft.
	var code string
	if err = a.DB.QueryRowContext(r.Context(), `SELECT code FROM hardening_profiles WHERE id=?`, id).Scan(&code); err != nil {
		respond(w, nil, err)
		return
	}
	if b.Code != code {
		badRequest(w, errors.New("profile code cannot be changed"))
		return
	}
	_, err = a.DB.ExecContext(r.Context(), `UPDATE hardening_profiles SET name=?,scope=?,technology=?,os_match=?,version_prefix=?,level=?,benchmark=?,benchmark_version=?,benchmark_url=? WHERE id=? AND lifecycle='draft'`, b.Name, b.Scope, b.Technology, b.OSMatch, b.VersionPrefix, b.Level, b.Benchmark, b.BenchmarkVersion, b.BenchmarkURL, id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "hardening.profile.edit", "hardening_profile", fmt.Sprint(id), "success", nil)
	jsonResponse(w, 200, map[string]any{"ok": true})
}
func (a *App) hardeningCloneProfile(w http.ResponseWriter, r *http.Request) {
	id, err := hardeningID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var req struct {
		Code string `json:"code"`
		Name string `json:"name"`
	}
	if err = json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&req); err != nil {
		badRequest(w, err)
		return
	}
	if !hardeningSlug.MatchString(req.Code) || req.Name == "" || len(req.Name) > 255 {
		badRequest(w, errors.New("invalid clone code/name"))
		return
	}
	tx, err := a.DB.BeginTx(r.Context(), nil)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer tx.Rollback()
	var source hardening.Profile
	err = tx.QueryRowContext(r.Context(), `SELECT code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url,scope,technology,revision FROM hardening_profiles WHERE id=?`, id).Scan(&source.Code, &source.Name, &source.OSMatch, &source.VersionPrefix, &source.Level, &source.Benchmark, &source.BenchmarkVersion, &source.BenchmarkURL, &source.Scope, &source.Technology, &source.Revision)
	if err != nil {
		respond(w, nil, err)
		return
	}
	res, err := tx.ExecContext(r.Context(), `INSERT INTO hardening_profiles(code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url,enabled,scope,technology,lifecycle,revision) VALUES(?,?,?,?,?,?,?,?,0,?,?,'draft',?)`, req.Code, req.Name, source.OSMatch, source.VersionPrefix, source.Level, source.Benchmark, source.BenchmarkVersion, source.BenchmarkURL, source.Scope, source.Technology, source.Revision+1)
	if err != nil {
		respond(w, nil, err)
		return
	}
	newID, _ := res.LastInsertId()
	_, err = tx.ExecContext(r.Context(), `INSERT INTO hardening_profile_rules(profile_id,rule_code,enabled) SELECT ?,rule_code,enabled FROM hardening_profile_rules WHERE profile_id=?`, newID, id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	_, err = tx.ExecContext(r.Context(), `INSERT INTO hardening_cis_mappings(profile_id,rule_code,recommendation_id,control_id,status,note) SELECT ?,rule_code,recommendation_id,control_id,'pending',CONCAT('Preluat din profilul ',?,'; de revalidat') FROM hardening_cis_mappings WHERE profile_id=?`, newID, id, id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if err = tx.Commit(); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "hardening.profile.clone", "hardening_profile", fmt.Sprint(newID), "success", map[string]any{"source": id})
	jsonResponse(w, 201, map[string]any{"id": newID, "status": "draft"})
}
func (a *App) hardeningCreateRule(w http.ResponseWriter, r *http.Request) {
	var b hardeningRuleInput
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&b); err != nil {
		badRequest(w, err)
		return
	}
	if err := validHardeningRule(b); err != nil {
		badRequest(w, err)
		return
	}
	_, err := a.DB.ExecContext(r.Context(), `INSERT INTO hardening_rules(code,name,category,check_key,expected,severity,operator,enabled) VALUES(?,?,?,?,?,?,?,1)`, b.Code, b.Name, b.Category, b.CheckKey, b.Expected, b.Severity, b.Operator)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "hardening.rule.create", "hardening_rule", b.Code, "success", nil)
	jsonResponse(w, 201, map[string]any{"ok": true, "code": b.Code})
}
func (a *App) hardeningAttachRule(w http.ResponseWriter, r *http.Request) {
	id, err := hardeningID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	if err = a.hardeningProfileDraft(r.Context(), id); err != nil {
		badRequest(w, err)
		return
	}
	var b struct {
		RuleCode string `json:"rule_code"`
	}
	if err = json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&b); err != nil {
		badRequest(w, err)
		return
	}
	if !hardeningSlug.MatchString(b.RuleCode) || len(b.RuleCode) > 64 {
		badRequest(w, errors.New("invalid rule code"))
		return
	}
	tx, err := a.DB.BeginTx(r.Context(), nil)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer tx.Rollback()
	_, err = tx.ExecContext(r.Context(), `INSERT INTO hardening_profile_rules(profile_id,rule_code,enabled) VALUES(?,?,1)`, id, b.RuleCode)
	if err != nil {
		respond(w, nil, err)
		return
	}
	_, err = tx.ExecContext(r.Context(), `INSERT INTO hardening_cis_mappings(profile_id,rule_code,status,note) VALUES(?,?,'pending','ID CIS de validat în versiunea benchmarkului')`, id, b.RuleCode)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if err = tx.Commit(); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "hardening.profile.rule.attach", "hardening_profile", fmt.Sprint(id), "success", map[string]any{"rule": b.RuleCode})
	jsonResponse(w, 200, map[string]any{"ok": true})
}
func (a *App) hardeningDetachRule(w http.ResponseWriter, r *http.Request) {
	id, err := hardeningID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	if err = a.hardeningProfileDraft(r.Context(), id); err != nil {
		badRequest(w, err)
		return
	}
	code := r.PathValue("code")
	if !hardeningSlug.MatchString(code) || len(code) > 64 {
		badRequest(w, errors.New("invalid rule code"))
		return
	}
	_, err = a.DB.ExecContext(r.Context(), `DELETE FROM hardening_profile_rules WHERE profile_id=? AND rule_code=?`, id, code)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "hardening.profile.rule.detach", "hardening_profile", fmt.Sprint(id), "success", map[string]any{"rule": code})
	jsonResponse(w, 200, map[string]any{"ok": true})
}
func (a *App) hardeningPublishProfile(w http.ResponseWriter, r *http.Request) {
	id, err := hardeningID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	cat, err := a.getHardeningCatalog(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	var profile *hardening.Profile
	for _, p := range cat.Profiles {
		if p.ID == id {
			cp := p
			profile = &cp
			break
		}
	}
	if profile == nil || profile.Lifecycle != "draft" {
		badRequest(w, errors.New("only draft profiles can be published"))
		return
	}
	rules := []hardening.Rule{}
	for _, x := range cat.Rules {
		if x.ProfileID == id {
			rules = append(rules, x)
		}
	}
	if len(rules) == 0 {
		badRequest(w, errors.New("at least one rule is required"))
		return
	}
	// Guard against publishing a rule with an invalid or unknown safe operator.
	for _, x := range rules {
		if err = validHardeningRule(hardeningRuleInput{Code: x.Code, Name: x.Name, Category: x.Category, CheckKey: x.CheckKey, Expected: x.Expected, Severity: x.Severity, Operator: x.Operator}); err != nil {
			badRequest(w, err)
			return
		}
	}
	blob, err := json.Marshal(map[string]any{"profile": profile, "rules": rules})
	if err != nil {
		respond(w, nil, err)
		return
	}
	tx, err := a.DB.BeginTx(r.Context(), nil)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer tx.Rollback()
	result, err := tx.ExecContext(r.Context(), `UPDATE hardening_profiles SET lifecycle='published',enabled=1 WHERE id=? AND lifecycle='draft'`, id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	count, _ := result.RowsAffected()
	if count != 1 {
		badRequest(w, errors.New("draft no longer available"))
		return
	}
	_, err = tx.ExecContext(r.Context(), `INSERT INTO hardening_profile_revisions(profile_id,revision,snapshot_json) VALUES(?,?,?)`, id, profile.Revision, string(blob))
	if err != nil {
		respond(w, nil, err)
		return
	}
	if err = tx.Commit(); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "hardening.profile.publish", "hardening_profile", fmt.Sprint(id), "success", map[string]any{"revision": profile.Revision})
	jsonResponse(w, 200, map[string]any{"ok": true, "revision": profile.Revision})
}
func (a *App) hardeningArchiveProfile(w http.ResponseWriter, r *http.Request) {
	id, err := hardeningID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	_, err = a.DB.ExecContext(r.Context(), `UPDATE hardening_profiles SET lifecycle='archived',enabled=0 WHERE id=? AND lifecycle='published'`, id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "hardening.profile.archive", "hardening_profile", fmt.Sprint(id), "success", nil)
	jsonResponse(w, 200, map[string]any{"ok": true})
}
func (a *App) hardeningExportProfile(w http.ResponseWriter, r *http.Request) {
	id, err := hardeningID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var p hardeningProfileInput
	err = a.DB.QueryRowContext(r.Context(), `SELECT code,name,scope,technology,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url FROM hardening_profiles WHERE id=?`, id).Scan(&p.Code, &p.Name, &p.Scope, &p.Technology, &p.OSMatch, &p.VersionPrefix, &p.Level, &p.Benchmark, &p.BenchmarkVersion, &p.BenchmarkURL)
	if err != nil {
		respond(w, nil, err)
		return
	}
	result := hardeningProfileExport{Format: "vm-doc-hardening-profile-v1", Profile: p, Rules: []hardeningRuleInput{}, Mappings: []hardeningExportMapping{}}
	rows, err := a.DB.QueryContext(r.Context(), `SELECT r.code,r.name,r.category,r.check_key,r.expected,r.severity,r.operator,COALESCE(cm.recommendation_id,''),COALESCE(cm.control_id,''),COALESCE(cm.status,'pending'),COALESCE(cm.note,'') FROM hardening_profile_rules pr JOIN hardening_rules r ON r.code=pr.rule_code LEFT JOIN hardening_cis_mappings cm ON cm.profile_id=pr.profile_id AND cm.rule_code=pr.rule_code WHERE pr.profile_id=? ORDER BY r.code`, id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer rows.Close()
	for rows.Next() {
		var rule hardeningRuleInput
		var m hardeningExportMapping
		if err = rows.Scan(&rule.Code, &rule.Name, &rule.Category, &rule.CheckKey, &rule.Expected, &rule.Severity, &rule.Operator, &m.RecommendationID, &m.ControlID, &m.Status, &m.Note); err != nil {
			respond(w, nil, err)
			return
		}
		m.RuleCode = rule.Code
		result.Rules = append(result.Rules, rule)
		result.Mappings = append(result.Mappings, m)
	}
	if err = rows.Err(); err != nil {
		respond(w, nil, err)
		return
	}
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=hardening-%s.json", p.Code))
	jsonResponse(w, 200, result)
}
func (a *App) hardeningImportProfile(w http.ResponseWriter, r *http.Request) {
	var payload hardeningProfileExport
	dec := json.NewDecoder(http.MaxBytesReader(w, r.Body, 512<<10))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&payload); err != nil {
		badRequest(w, err)
		return
	}
	if payload.Format != "vm-doc-hardening-profile-v1" || len(payload.Rules) == 0 || len(payload.Rules) > 500 || len(payload.Mappings) > 500 {
		badRequest(w, errors.New("invalid profile import format or size"))
		return
	}
	if err := validHardeningProfile(payload.Profile); err != nil {
		badRequest(w, err)
		return
	}
	for _, v := range payload.Rules {
		if err := validHardeningRule(v); err != nil {
			badRequest(w, err)
			return
		}
	}
	// Imported mappings are always pending, irrespective of their exported state.
	m := map[string]hardeningExportMapping{}
	for _, v := range payload.Mappings {
		if len(v.Note) > 950 || len(v.RecommendationID) > 50 || len(v.ControlID) > 50 {
			badRequest(w, errors.New("invalid mapping"))
			return
		}
		m[v.RuleCode] = v
	}
	tx, err := a.DB.BeginTx(r.Context(), nil)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer tx.Rollback()
	p := payload.Profile
	res, err := tx.ExecContext(r.Context(), `INSERT INTO hardening_profiles(code,name,os_match,version_prefix,level,benchmark,benchmark_version,benchmark_url,enabled,scope,technology,lifecycle,revision) VALUES(?,?,?,?,?,?,?,?,0,?,?,'draft',1)`, p.Code, p.Name, p.OSMatch, p.VersionPrefix, p.Level, p.Benchmark, p.BenchmarkVersion, p.BenchmarkURL, p.Scope, p.Technology)
	if err != nil {
		respond(w, nil, err)
		return
	}
	id, _ := res.LastInsertId()
	for _, v := range payload.Rules {
		// Reuse only when the existing rule is semantically identical. No rewriting other profiles.
		var old hardeningRuleInput
		scanErr := tx.QueryRowContext(r.Context(), `SELECT code,name,category,check_key,expected,severity,operator FROM hardening_rules WHERE code=?`, v.Code).Scan(&old.Code, &old.Name, &old.Category, &old.CheckKey, &old.Expected, &old.Severity, &old.Operator)
		if scanErr == sql.ErrNoRows {
			_, err = tx.ExecContext(r.Context(), `INSERT INTO hardening_rules(code,name,category,check_key,expected,severity,operator,enabled) VALUES(?,?,?,?,?,?,?,1)`, v.Code, v.Name, v.Category, v.CheckKey, v.Expected, v.Severity, v.Operator)
		} else if scanErr != nil {
			err = scanErr
		} else if old != v {
			err = errors.New("rule code conflict with existing rule: " + v.Code)
		}
		if err != nil {
			respond(w, nil, err)
			return
		}
		_, err = tx.ExecContext(r.Context(), `INSERT INTO hardening_profile_rules(profile_id,rule_code,enabled) VALUES(?,?,1)`, id, v.Code)
		if err != nil {
			respond(w, nil, err)
			return
		}
		mapping := m[v.Code]
		_, err = tx.ExecContext(r.Context(), `INSERT INTO hardening_cis_mappings(profile_id,rule_code,recommendation_id,control_id,status,note) VALUES(?,?,NULLIF(?,''),NULLIF(?,''),'pending',?)`, id, v.Code, mapping.RecommendationID, mapping.ControlID, "Importat; validare CIS obligatorie. "+mapping.Note)
		if err != nil {
			respond(w, nil, err)
			return
		}
	}
	if err = tx.Commit(); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "hardening.profile.import", "hardening_profile", fmt.Sprint(id), "success", map[string]any{"rules": len(payload.Rules)})
	jsonResponse(w, 201, map[string]any{"id": id, "status": "draft"})
}
