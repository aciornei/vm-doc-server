package server

import (
	"strings"
	"testing"
)

func TestSecurityDBPrincipalReviewKeyStableAndScoped(t *testing.T) {
	user := securityDBPrincipal{Name: "app", Host: "%", Database: "shop", Login: true, Roles: []string{"readonly"}}
	first := securityDBPrincipalReviewKey(55, user)
	if !strings.HasPrefix(first, "dbp:55:") || len(first) != len("dbp:55:")+64 {
		t.Fatalf("unexpected review key format: %q", first)
	}
	if second := securityDBPrincipalReviewKey(55, user); second != first {
		t.Fatalf("unstable key: %q != %q", first, second)
	}
	user.Login = false
	user.Roles = []string{"admin"}
	if key := securityDBPrincipalReviewKey(55, user); key != first {
		t.Fatalf("access attribute changes must not alter principal identity: %q", key)
	}
	if key := securityDBPrincipalReviewKey(56, user); key == first {
		t.Fatal("different DB instances must not share the same review key")
	}
	user.Host = "localhost"
	if key := securityDBPrincipalReviewKey(55, user); key == first {
		t.Fatal("MySQL accounts with distinct host qualifiers must have distinct reviews")
	}
	user.Host = "%"
	user.Database = "reporting"
	if key := securityDBPrincipalReviewKey(55, user); key == first {
		t.Fatal("database-scoped principals must not collide")
	}
}
