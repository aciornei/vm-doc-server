# VM-DOC 0.21.32 — Upgrade de la 0.21.31

Schimbări: UI Securitate (Rezumat, Conturi VM) și revizie granulară a principalilor DB. Agent 1.7.18 neschimbat. **Fără migrare SQL nouă** — tipul `database_principal` este stocat în tabelul generic `security_reviews`.

Înainte de upgrade: backup MariaDB, backup binar și surse server 0.21.31. Nu este necesar să ștergi review-uri vechi `resource_type=database`.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.31 vm-doc-server-0.21.32
cd vm-doc-server-0.21.32
tar -xzf /cale/vm-doc-server-0.21.32-update.tar.gz -C .
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Instalează binarul numai după ce ambele comenzi au reușit. Repornește serviciul conform procedurii tale, apoi Ctrl+F5 în browser.

Verifică pe o VM cu utilizatori DB: review individual în `VM → Securitate → Baze`, separat pe nume+host/DB; filtrul Baze de date din raportul de revizii; confirmă că review-ul vechi al instanței nu apare implicit pe utilizatori. Pentru Conturi system, verifică absența coloanei Review și păstrarea conturilor relevante.

Rollback: restaurează binarul/sursele 0.21.31. Review-urile nou salvate ca `database_principal` rămân în tabel și sunt ignorate de UI-ul vechi; nu șterge rânduri din baza de date.
