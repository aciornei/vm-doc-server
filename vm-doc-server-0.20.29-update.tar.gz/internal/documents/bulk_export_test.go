package documents

import (
	"strings"
	"testing"
)

func TestBulkVMExportQueryPoweredOnFilter(t *testing.T) {
	filtered := bulkVMExportQuery(true)
	if !strings.Contains(filtered, "POWERED_ON") {
		t.Fatalf("powered-on bulk query must filter POWERED_ON: %s", filtered)
	}
	allActive := bulkVMExportQuery(false)
	if strings.Contains(allActive, "POWERED_ON") {
		t.Fatalf("unfiltered bulk query must not force POWERED_ON: %s", allActive)
	}
	if !strings.Contains(allActive, "vm.retired=0") {
		t.Fatalf("bulk query must always exclude retired VMs: %s", allActive)
	}
}
