package documents

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"
)

// BulkExportItem describes the latest generated document (if any) for one
// active documentation target. It intentionally carries no content so bulk
// exports can stream documents one by one without loading the whole archive
// into memory.
type BulkExportItem struct {
	ObjectType     string
	ObjectID       int64
	ObjectName     string
	DocumentID     *int64
	DocumentNumber string
	FileName       string
	GeneratedAt    *time.Time
}

func (s Service) ListBulkExportItems(ctx context.Context, objectType string, poweredOnOnly ...bool) ([]BulkExportItem, error) {
	switch normalizeObjectType(objectType) {
	case "vm":
		onlyPoweredOn := len(poweredOnOnly) > 0 && poweredOnOnly[0]
		return s.listBulkVMExportItems(ctx, onlyPoweredOn)
	case "service":
		return s.listBulkServiceExportItems(ctx)
	default:
		return nil, errors.New("bulk export object type must be vm or service")
	}
}

func (s Service) listBulkVMExportItems(ctx context.Context, poweredOnOnly bool) ([]BulkExportItem, error) {
	rows, err := s.DB.QueryContext(ctx, bulkVMExportQuery(poweredOnOnly))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanBulkExportItems(rows, "vm")
}

func bulkVMExportQuery(poweredOnOnly bool) string {
	query := `SELECT vm.id,vm.name,d.id,d.document_number,d.file_name,d.generated_at
        FROM virtual_machines vm
        LEFT JOIN generated_documents d ON d.id=(
            SELECT d2.id FROM generated_documents d2
            WHERE d2.object_type='vm' AND d2.vm_id=vm.id
            ORDER BY d2.id DESC LIMIT 1
        )
        WHERE vm.retired=0`
	if poweredOnOnly {
		query += ` AND UPPER(COALESCE(vm.power_state,''))='POWERED_ON'`
	}
	return query + ` ORDER BY LOWER(vm.name),vm.id`
}

func (s Service) listBulkServiceExportItems(ctx context.Context) ([]BulkExportItem, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT service.id,service.name,d.id,d.document_number,d.file_name,d.generated_at
        FROM internal_services service
        LEFT JOIN generated_documents d ON d.id=(
            SELECT d2.id FROM generated_documents d2
            WHERE d2.object_type='service' AND d2.internal_service_id=service.id
            ORDER BY d2.id DESC LIMIT 1
        )
        WHERE service.active=1
        ORDER BY LOWER(service.name),service.id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanBulkExportItems(rows, "service")
}

func scanBulkExportItems(rows *sql.Rows, objectType string) ([]BulkExportItem, error) {
	out := make([]BulkExportItem, 0)
	for rows.Next() {
		var item BulkExportItem
		var documentID sql.NullInt64
		var documentNumber, fileName sql.NullString
		var generatedAt sql.NullTime
		if err := rows.Scan(&item.ObjectID, &item.ObjectName, &documentID, &documentNumber, &fileName, &generatedAt); err != nil {
			return nil, err
		}
		item.ObjectType = objectType
		item.ObjectName = strings.TrimSpace(item.ObjectName)
		if documentID.Valid {
			id := documentID.Int64
			item.DocumentID = &id
		}
		if documentNumber.Valid {
			item.DocumentNumber = documentNumber.String
		}
		if fileName.Valid {
			item.FileName = fileName.String
		}
		if generatedAt.Valid {
			value := generatedAt.Time
			item.GeneratedAt = &value
		}
		out = append(out, item)
	}
	return out, rows.Err()
}
