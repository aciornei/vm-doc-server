# Upgrade vm-doc-server 0.20.28 → 0.20.29

Versiunea 0.20.29 rafinează numai exportul bulk **DOCX** din pagina Documente. Nu există migrare de bază de date și nu este necesar update de agent.

## Noutăți

- VM DOCX: checkbox **Doar VM-uri pornite**, bifat implicit. Bifat = numai `POWERED_ON`; debifat = toate VM-urile active/neretrase.
- Checkbox-ul existent **Regenerează toate fișele VM înainte de export** rămâne implicit debifat și se aplică doar VM-urilor selectate de filtrul de mai sus.
- Proiecte DOCX: checkbox nou **Regenerează toate fișele proiectelor înainte de export**, implicit debifat.
- Regenerarea proiectelor creează o versiune nouă pentru fiecare proiect activ cu șablonul implicit și fără `Generat de`.
- Dacă sunt bifate simultan **Regenerează** și **Generează fișa proiectului dacă nu există**, regenerarea tuturor are prioritate.
- **Generează fișa proiectului dacă nu există** și **Include și fișele VM asociate proiectelor** rămân implicit debifate.
- Exporturile PDF nu sunt modificate în această versiune.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.28 \
      /usr/local/src/vm-doc-server-0.20.29

tar -xzf vm-doc-server-0.20.29-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.29

cd /usr/local/src/vm-doc-server-0.20.29

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi înlocuiește binarul conform procedurii curente și repornește `vm-doc-server`. Agentul nu necesită restart/update.

## Verificare funcțională

1. Deschide **Documente → Export în masă**.
2. La VM-uri verifică faptul că **Doar VM-uri pornite** este bifat implicit, iar **Regenerează** este debifat.
3. Exportă VM DOCX cu filtrul bifat și verifică în `_manifest.csv` că apar numai VM-uri `POWERED_ON`; debifează și verifică includerea VM-urilor oprite.
4. La Proiecte verifică faptul că toate cele trei opțiuni sunt implicit debifate.
5. Bifează **Regenerează toate fișele proiectelor înainte de export** și verifică apariția unei versiuni noi pentru fiecare proiect activ; documentele noi nu trebuie să afișeze `Generat de`.
6. PDF-urile trebuie să se comporte identic cu 0.20.28.
