package fortigate

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestClientInventoryUsesBearerAndVDOMWithoutArtificialPagination(t *testing.T) {
	seen := 0
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get("Authorization"); got != "Bearer token-123" {
			t.Fatalf("authorization = %q", got)
		}
		if got := r.URL.Query().Get("vdom"); got != "root" {
			t.Fatalf("vdom = %q", got)
		}
		if got := r.URL.Query().Get("start"); got != "" {
			t.Fatalf("unexpected start=%q", got)
		}
		if got := r.URL.Query().Get("count"); got != "" {
			t.Fatalf("unexpected count=%q", got)
		}
		seen++
		fmt.Fprint(w, `{"status":"success","http_status":200,"limit_reached":false,"results":[]}`)
	}))
	defer ts.Close()
	client, err := NewClient(ts.URL, "token-123", "root", true, "", 5*time.Second, true)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := client.Inventory(context.Background()); err != nil {
		t.Fatal(err)
	}
	if seen != 4 {
		t.Fatalf("expected 4 CMDB calls, got %d", seen)
	}
}

func TestClientRejectsPartialCMDBInventory(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/v2/cmdb/firewall/address" {
			fmt.Fprint(w, `{"status":"success","http_status":200,"limit_reached":true,"next_idx":499,"size":500,"matched_count":517,"results":[]}`)
			return
		}
		fmt.Fprint(w, `{"status":"success","http_status":200,"limit_reached":false,"results":[]}`)
	}))
	defer ts.Close()
	client, err := NewClient(ts.URL, "token-123", "root", true, "", 5*time.Second, true)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := client.Inventory(context.Background()); err == nil {
		t.Fatal("partial CMDB inventory must be rejected")
	}
}
