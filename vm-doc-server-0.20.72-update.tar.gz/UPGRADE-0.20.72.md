# Upgrade VM-DOC Server 0.20.71 → 0.20.72

0.20.72 corectează inventarul FortiGate tăiat la 500 de policy-uri și extinde matching-ul sigur pentru `interface-subnet` / `wildcard`.

Nu există migrare DB nouă. Agentul rămâne 1.7.12.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.71 /usr/local/src/vm-doc-server-0.20.72
tar -xzf vm-doc-server-0.20.72-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.72
cd /usr/local/src/vm-doc-server-0.20.72
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi restart server, Ctrl+F5 și în **Securitate → Firewall central** rulează mai întâi **Test**, apoi **Sync**.

La Test, totalul `active + disabled` trebuie să revină la inventarul real FortiGate (nu exact 500). Dacă FortiGate răspunde cu `limit_reached=true`, 0.20.72 oprește sync-ul și afișează eroare explicită, pentru a nu salva date incomplete.
