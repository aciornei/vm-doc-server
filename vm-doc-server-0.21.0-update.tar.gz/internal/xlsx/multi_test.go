package xlsx

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"fmt"
	"strings"
	"testing"
)

func TestWriteSheetsWorkbook(t *testing.T) {
	var b bytes.Buffer
	sheets := []Sheet{{Name: "Sumar", Rows: [][]Cell{{Text("Categorie"), Text("Total")}, {Text("VM"), Number(3)}}}, {Name: "Servicii", Rows: [][]Cell{{Text("Serviciu")}, {Text("Portal")}}}}
	if err := WriteSheets(&b, sheets); err != nil {
		t.Fatal(err)
	}
	zr, err := zip.NewReader(bytes.NewReader(b.Bytes()), int64(b.Len()))
	if err != nil {
		t.Fatal(err)
	}
	content := map[string]string{}
	for _, f := range zr.File {
		rc, err := f.Open()
		if err != nil {
			t.Fatal(err)
		}
		var result bytes.Buffer
		_, err = result.ReadFrom(rc)
		rc.Close()
		if err != nil {
			t.Fatal(err)
		}
		content[f.Name] = result.String()
		if strings.HasSuffix(f.Name, ".xml") {
			decoder := xml.NewDecoder(strings.NewReader(content[f.Name]))
			for {
				_, err := decoder.Token()
				if err != nil {
					if err.Error() == "EOF" {
						break
					}
					t.Fatalf("invalid XML %s: %v", f.Name, err)
				}
			}
		}
	}
	for i := 1; i <= 2; i++ {
		if _, ok := content[fmt.Sprintf("xl/worksheets/sheet%d.xml", i)]; !ok {
			t.Fatalf("missing sheet %d", i)
		}
	}
	if !strings.Contains(content["xl/workbook.xml"], "Servicii") {
		t.Fatal("workbook did not enumerate the 2nd sheet")
	}
}
