package xlsx

import (
	"archive/zip"
	"fmt"
	"io"
	"strings"
	"time"
	"unicode/utf8"
)

type Sheet struct {
	Name string
	Rows [][]Cell
}

// WriteSheets produces a single Office Open XML workbook containing all sheets.
// It reuses the existing worksheet formatter so export behavior stays consistent.
func WriteSheets(w io.Writer, sheets []Sheet) error {
	if len(sheets) == 0 {
		return fmt.Errorf("workbook requires at least one sheet")
	}
	names := make(map[string]bool, len(sheets))
	var workbook, rels, types strings.Builder
	workbook.WriteString(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>`)
	rels.WriteString(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">`)
	types.WriteString(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>`)
	for i, sheet := range sheets {
		name := strings.TrimSpace(sheet.Name)
		if name == "" {
			name = fmt.Sprintf("Sheet %d", i+1)
		}
		if utf8.RuneCountInString(name) > 31 {
			name = string([]rune(name)[:31])
		}
		if names[strings.ToLower(name)] {
			return fmt.Errorf("duplicate worksheet name %s", name)
		}
		names[strings.ToLower(name)] = true
		fmt.Fprintf(&workbook, `<sheet name="%s" sheetId="%d" r:id="rId%d"/>`, escapeXML(name), i+1, i+1)
		fmt.Fprintf(&rels, `<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>`, i+1, i+1)
		fmt.Fprintf(&types, `<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`, i+1)
	}
	workbook.WriteString(`</sheets></workbook>`)
	fmt.Fprintf(&rels, `<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`, len(sheets)+1)
	types.WriteString(`<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`)
	zw := zip.NewWriter(w)
	write := func(name, value string) error {
		f, err := zw.Create(name)
		if err != nil {
			return err
		}
		_, err = io.WriteString(f, value)
		return err
	}
	files := []struct{ name, data string }{{"[Content_Types].xml", types.String()}, {"_rels/.rels", rootRels}, {"docProps/app.xml", appXML}, {"docProps/core.xml", coreXML(time.Now().UTC())}, {"xl/workbook.xml", workbook.String()}, {"xl/_rels/workbook.xml.rels", rels.String()}, {"xl/styles.xml", stylesXML}}
	for _, f := range files {
		if err := write(f.name, f.data); err != nil {
			return err
		}
	}
	for i, sheet := range sheets {
		if err := write(fmt.Sprintf("xl/worksheets/sheet%d.xml", i+1), worksheetXML(sheet.Rows)); err != nil {
			return err
		}
	}
	return zw.Close()
}
