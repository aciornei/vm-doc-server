# Upgrade VM-DOC Server 0.20.99 → 0.21.0

## Cerințe
- Snapshot/backup MariaDB înainte de upgrade; migrarea **071** creează 3 tabele noi.
- Păstrează directorul `vendor/` funcțional din 0.20.99 și fișierele tale de configurare/secrete.
- Nu este necesară o versiune nouă de agent.
- Aplicația rămâne disponibilă offline. Nu folosi `go mod vendor` pe serverul izolat.

## Instalare offline, pe un arbore sursă copie

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.99 vm-doc-server-0.21.0
tar -xzf /cale/vm-doc-server-0.21.0-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.0
cd vm-doc-server-0.21.0
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

**Nu actualiza binarul în producție dacă testele sau compilarea eșuează.**
După compilare, oprește serverul, instalează binarul nou conform instalării tale existente, pornește serviciul și verifică `/version`. La prima pornire aplicația aplică migrarea 071; verifică logurile.

## Verificare funcțională în staging
1. `/version` raportează `0.21.0` și Swagger afișează rutele Beneficiari.
2. Nomenclatoare → Beneficiari: adaugă manual un departament și o persoană; verifică sursa Manual.
3. Configurează OU-uri sub Base DN existent; selectează un subarbore și sincronizează; verifică AD și ierarhia.
4. Alocă doi beneficiari aceluiași Docker / VM / catalog DB / Web.
5. Verifică beneficiarii calculați la serviciul asociat și la componenta suport, precum și originea lor.
6. Verifică faptul că un beneficiar Docker nu se propagă altui container de pe aceeași VM.
7. Rapoarte → Beneficiari: verifică cele șase categorii, filtrele OU copii și XLSX (Sumar + 6 foi).
8. Testează eliminarea unei asocieri directe; cele calculate se elimină automat la recalculare.

## Note operaționale
- Căutarea OU-urilor și persoanelor folosește doar Base DN + filtrul de utilizatori LDAP configurat.
- Marcarea ca inactive la sincronizare se aplică **numai intrărilor AD din ramurile selectate** și numai după citirea integrală, reușită, din LDAP.
- Atribuirea unui beneficiar unui container nu înseamnă că alte containere de pe aceeași gazdă au acel beneficiar.
- Relațiile către componente suport pentru Docker/DB/Web se folosesc doar când există un nume componentă declarat explicit și potrivit.
- Beneficiarii direcți ai VM-ului se văd în componentele suport și în serviciile cărora VM-ul le este asociat.
- AD rămâne read-only: sincronizarea nu scrie în AD.
- Dependențele (`vendor/`) și `go.mod`/`go.sum` nu sunt modificate.

## Rollback
Revino la binarul și sursele 0.20.99. Migrarea 071 adaugă tabele independente; datele istorice ale aplicației nu se modifică. Nu șterge tabelele beneficiare dacă vrei să păstrezi asocierile.
