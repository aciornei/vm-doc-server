-- Beneficiaries foundation. Source AD records are keyed by full DN (OU) / GUID (person).
-- Do not apply independently of the completed beneficiary application release.
CREATE TABLE IF NOT EXISTS beneficiary_departments (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(255) NOT NULL,
 source VARCHAR(16) NOT NULL,
 ldap_dn VARCHAR(1024) NULL,
 ldap_dn_hash CHAR(64) NULL,
 ad_object_guid CHAR(36) NULL,
 parent_id BIGINT UNSIGNED NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
 KEY idx_beneficiary_department_dn_hash (ldap_dn_hash),
 UNIQUE KEY uq_beneficiary_department_guid (ad_object_guid),
 KEY idx_beneficiary_department_parent (parent_id),
 CONSTRAINT fk_beneficiary_department_parent FOREIGN KEY(parent_id) REFERENCES beneficiary_departments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS beneficiary_people (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 display_name VARCHAR(255) NOT NULL,
 email VARCHAR(255) NOT NULL DEFAULT '',
 source VARCHAR(16) NOT NULL,
 ad_object_guid CHAR(36) NULL,
 ldap_dn VARCHAR(1024) NULL,
 department_id BIGINT UNSIGNED NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
 UNIQUE KEY uq_beneficiary_person_guid (ad_object_guid),
 KEY idx_beneficiary_person_department (department_id),
 CONSTRAINT fk_beneficiary_person_department FOREIGN KEY(department_id) REFERENCES beneficiary_departments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS beneficiary_assignments (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 resource_type VARCHAR(32) NOT NULL,
 resource_id BIGINT UNSIGNED NOT NULL,
 beneficiary_type VARCHAR(16) NOT NULL,
 beneficiary_id BIGINT UNSIGNED NOT NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uq_beneficiary_assignment (resource_type,resource_id,beneficiary_type,beneficiary_id),
 KEY idx_beneficiary_reverse (beneficiary_type,beneficiary_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
