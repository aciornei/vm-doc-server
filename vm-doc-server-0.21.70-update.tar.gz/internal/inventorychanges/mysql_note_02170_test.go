package inventorychanges

import (
	"encoding/json"
	"testing"
)

func TestMySQLNoteStartupTimestampAndPIDDontChangeVersion(t *testing.T) {
	makeSnap := func(version string) []byte {
		raw, err := json.Marshal(map[string]any{"databases": map[string]any{"instances": []any{
			map[string]any{"engine": "mysql", "product": "MySQL", "instance_name": "mysql", "version": version, "status": "running", "endpoints": []any{map[string]any{"port": 3306}}},
		}}})
		if err != nil {
			t.Fatal(err)
		}
		return raw
	}
	prior := "261021 14:04:10 [Note] /usr/libexec/mysqld (mysqld 5.5.56-MariaDB) starting as process 59985 ..."
	next := "261021 14:04:12 [Note] /usr/libexec/mysqld (mysqld 5.5.56-MariaDB) starting as process 60001 ..."
	snapshots := []string{prior, next, "5.5.56-MariaDB", "261022 11:00:00 [Note] /usr/libexec/mysqld (mysqld 5.5.57-MariaDB) starting as process 60004 ..."}
	objects := make([]trackedObject, 0, len(snapshots))
	for _, ver := range snapshots {
		tracked, err := extractTracked(makeSnap(ver))
		if err != nil {
			t.Fatal(err)
		}
		if len(tracked) != 1 {
			t.Fatalf("want 1 object; got %d", len(tracked))
		}
		for _, v := range tracked {
			objects = append(objects, v)
		}
	}
	if !trackedObjectsEqual(objects[0], objects[1]) || !trackedObjectsEqual(objects[1], objects[2]) {
		t.Fatalf("same MySQL version should not change: %+v / %+v / %+v", objects[0], objects[1], objects[2])
	}
	if trackedObjectsEqual(objects[2], objects[3]) {
		t.Fatal("real MariaDB 5.5.56 -> 5.5.57 upgrade was lost")
	}
	if got := objects[0].Value.(map[string]any)["version"]; got != "5.5.56-MariaDB" {
		t.Fatalf("expected semantic version, got %#v", got)
	}
	if got := objects[3].Value.(map[string]any)["version"]; got != "5.5.57-MariaDB" {
		t.Fatalf("expected upgraded version, got %#v", got)
	}
	if string(makeSnap(prior)) == string(makeSnap("5.5.56-MariaDB")) {
		t.Fatal("raw snapshots must keep the original log text")
	}
}

func TestMySQLNoteWithoutSoftwareVersionIgnored(t *testing.T) {
	note := "261021 14:04:12 [Note] /usr/libexec/mysqld starting process 60001"
	v := map[string]any{"engine": "mysql", "version": note, "product": "MySQL"}
	normalizeTrackedVersionField(v, "version")
	if _, ok := v["version"]; ok {
		t.Fatalf("note must not be tracked as version: %+v", v)
	}
}

func TestMySQLNotePreservesActualVersionLine(t *testing.T) {
	value := map[string]any{"engine": "mysql", "version": "261021 14:04:12 [Note] /usr/libexec/mysqld (mysqld 5.5.56-MariaDB) starting as process 59985\n5.5.56-MariaDB"}
	normalizeTrackedVersionField(value, "version")
	if value["version"] != "5.5.56-MariaDB" {
		t.Fatalf("unexpected mixed-output version: %v", value["version"])
	}
}

func TestMySQLUnrecognizedNoteNotNormalizedOtherDatabasesUnaffected(t *testing.T) {
	raw := "This is an informational [Note] of PostgreSQL 15.4"
	for _, engine := range []string{"postgresql", "mysql"} {
		value := map[string]any{"engine": engine, "version": raw}
		normalizeTrackedVersionField(value, "version")
		if value["version"] != raw {
			t.Fatalf("should retain unrecognized note for %s: %+v", engine, value)
		}
	}
}

func TestMySQLWarningRegressionAndRealPlainUpgrade(t *testing.T) {
	value := map[string]any{"engine": "mysql", "version": "261021 14:04:10 [Warning] Using unique option prefix key_buffer"}
	normalizeTrackedVersionField(value, "version")
	if _, ok := value["version"]; ok {
		t.Fatal("previous warning normalization regressed")
	}
	real := map[string]any{"engine": "mysql", "version": "8.0.36"}
	normalizeTrackedVersionField(real, "version")
	if real["version"] != "8.0.36" {
		t.Fatal("real version was lost")
	}
}
