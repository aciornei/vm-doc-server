-- VM-DOC 0.21.70: ONLY historical MySQL/MariaDB instance_version
-- false changes caused by dated startup [Note] (mysqld VERSION) + PID.
-- Does NOT change inventory_snapshots; does NOT touch reviewed/annotated events.
-- This targeted SQL recognizes the YYMMDD MySQL 5.5-style startup log shown
-- in the captured UI. Other log styles require separate validation.
-- IMPORTANT: validate on MariaDB staging; backup before any DELETE.
DROP TEMPORARY TABLE IF EXISTS tmp_vmdoc_mysql_note_02170;
CREATE TEMPORARY TABLE tmp_vmdoc_mysql_note_02170 (
 id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
 reason VARCHAR(64) NOT NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO tmp_vmdoc_mysql_note_02170(id,reason)
SELECT c.id, 'mysql_mariadb_same_version_note'
FROM inventory_changes c
WHERE c.category='databases'
  AND c.object_type='database_instance'
  AND c.change_type='modified'
  AND c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL AND c.reviewed_by IS NULL
  AND COALESCE(TRIM(c.notes),'')=''
  AND JSON_VALID(c.old_json)=1 AND JSON_VALID(c.new_json)=1
  AND CASE WHEN JSON_VALID(c.old_json)=1 AND JSON_VALID(c.new_json)=1 THEN
    BINARY JSON_REMOVE(c.old_json,'$.version') = BINARY JSON_REMOVE(c.new_json,'$.version')
    AND LOWER(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.engine'))) IN ('mysql','mariadb')
    AND BINARY COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.engine')),'')
        = BINARY COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.engine')),'')
    AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'')
      REGEXP '^[0-9]{6}[[:space:]]+[0-9]{1,2}:[0-9]{2}:[0-9]{2}[[:space:]]+[[]Note[]][[:space:]]+.*[(]mysqld[[:space:]]+[0-9]+([.][0-9]+){2,5}(-[A-Za-z0-9._-]+)?[)][[:space:]]+starting as process[[:space:]]+[0-9]+'
    AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'')
      REGEXP '^[0-9]{6}[[:space:]]+[0-9]{1,2}:[0-9]{2}:[0-9]{2}[[:space:]]+[[]Note[]][[:space:]]+.*[(]mysqld[[:space:]]+[0-9]+([.][0-9]+){2,5}(-[A-Za-z0-9._-]+)?[)][[:space:]]+starting as process[[:space:]]+[0-9]+'
    -- Critical guard: only matching ACTUAL software versions may be removed.
    AND BINARY SUBSTRING_INDEX(SUBSTRING_INDEX(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')), '(mysqld ', -1), ')', 1)
       = BINARY SUBSTRING_INDEX(SUBSTRING_INDEX(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')), '(mysqld ', -1), ')', 1)
  ELSE 0 END;

SELECT DATABASE() AS database_name;
SELECT reason,COUNT(*) AS candidate_rows FROM tmp_vmdoc_mysql_note_02170 GROUP BY reason;
SELECT COUNT(*) AS total_candidates FROM tmp_vmdoc_mysql_note_02170;
SELECT c.id,c.vm_id,c.occurred_at,c.object_label,
 SUBSTRING_INDEX(SUBSTRING_INDEX(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')), '(mysqld ', -1), ')', 1) AS normalized_version,
 LEFT(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),180) AS old_version,
 LEFT(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),180) AS new_version
FROM inventory_changes c JOIN tmp_vmdoc_mysql_note_02170 t ON t.id=c.id
ORDER BY c.occurred_at DESC LIMIT 80;
DROP TEMPORARY TABLE tmp_vmdoc_mysql_note_02170;
