# Upgrade VM-DOC Server 0.21.69 → 0.21.70

1. Fă backup recuperabil la binarul server, configurație și MariaDB; testează întâi în staging.
2. Aplică **fie** `vm-doc-server-0.21.69-to-0.21.70.patch`, **fie** `vm-doc-server-0.21.70-update.tar.gz` peste sursele 0.21.69, nu ambele. Alternativ, folosește source.zip.
3. Recompilează cu `vendor/` disponibil offline: `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off go build -o vm-doc-server ./cmd/vm-doc-server` (adaptează numele binarului la configurația instalată).
4. Înlocuiește binarul, repornește serverul și confirmă versiunea `0.21.70`. Nu există migrare SQL nouă; agentul rămâne 1.7.18.
5. Pe VM-ul cu MySQL/MariaDB, colectează de două ori. La `database_instance` raportul `[Note] ... (mysqld 5.5.56-MariaDB) starting as process ...` trebuie comparat ca `5.5.56-MariaDB`, fără inserare în `inventory_changes` dacă se schimbă numai timestampul/PID-ul. Un upgrade real trebuie să rămână vizibil.
6. **Istoric**: rulează `scripts/preview-mysql-note-version-02170.sql` doar ca lectură pe o copie MariaDB din staging; verifică lista exactă și backupul. Oprește vm-doc-server și scrierile înainte de `scripts/cleanup-mysql-note-version-02170.sql`, și execută-l manual numai după validarea PREVIEW. Aceste scripturi NU sunt migrații și NU se aplică automat. SQL-ul țintit acoperă numai perechi de mesaje MySQL `[Note]` YYMMDD cu aceeași versiune și restul JSON identic. Note/revizii/decizii sunt protejate.
7. Rollback: revino la binarul anterior 0.21.69 (fără migrare de revenire); pot reapărea evenimente false. SQL cleanup deja confirmat se inversează numai restaurând backupul DB.

**Limitări:** build/teste full Go (fără vendor în mediul de împachetare) și execuție SQL reală MariaDB nevalidate aici; obligatorii în staging. Nu se modifică inventarul brut, agentul sau API-ul.
