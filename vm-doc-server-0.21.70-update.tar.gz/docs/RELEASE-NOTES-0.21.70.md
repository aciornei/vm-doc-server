# VM-DOC Server 0.21.70 — MySQL/MariaDB [Note] startup version noise

## Defect observat
În `Modificări` → `Baze de date` → `database_instance`, câmpul `version` alternează între șiruri tip `261021 14:04:10 [Note] /usr/libexec/mysqld (mysqld 5.5.56-MariaDB) starting as process 59985 ...`. Detectorul vechi ignora `[Warning]` și `[Error]`, nu și `[Note]`. Timestampul și PID-ul erau tratate greșit drept upgrade.

## Corecție
- Normalizare strictă a logului datat de startup pentru engine `mysql/mariadb` la versiunea utilă `5.5.56-MariaDB`, înainte de comparația `inventory_changes`.
- Upgrade-ul real al acestei versiuni rămâne vizibil. Mesajele `[Warning]/[Error]` și comparațiile MySQL existente rămân neschimbate.
- Snapshotul/inventarul brut rămâne integral, fără filtrare de UI și fără SQL automat.
- PREVIEW/CLEANUP SQL țintite, numai manual, pentru istoricul existent, cu protecția evenimentelor revizuite/adnotate.
- Agent 1.7.18 neschimbat; fără migrare sau schimbări de API.

## Testare
Teste Go unitare/regresie pentru timestamp/PID, bannerul normalizat, upgrade real, valori fără versiune, alt motor de DB, warning anterior. Teste MariaDB și build offline complet de realizat în staging.
