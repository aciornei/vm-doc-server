package documents

import (
	"archive/zip"
	"bytes"
	"io"
	"os"
	"strings"
	"testing"
	"time"
)

func TestRARCatalogDOCX(t *testing.T) {
	input := RARCatalogContent{OperatingSystems: []RARCatalogItem{{Name: "Windows Server 2019"}, {Name: "Ubuntu 24.04"}, {Name: "SUSE Linux Enterprise Server 11 SP1"}}, Categories: []RARCatalogGroup{{Name: "Baze de date", Items: []RARCatalogItem{{Name: "PostgreSQL", Versions: []string{"14.1", "16.4"}}, {Name: "MongoDB"}, {Name: "Oracle Database"}}}, {Name: "Web / Reverse Proxy", Items: []RARCatalogItem{{Name: "Nginx"}, {Name: "Apache HTTP Server"}}}}}
	data, err := BuildRARCatalogDOCX(input, time.Date(2026, 11, 16, 12, 0, 0, 0, time.UTC))
	if err != nil {
		t.Fatal(err)
	}
	archive, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, file := range archive.File {
		if file.Name != "word/document.xml" {
			continue
		}
		found = true
		r, e := file.Open()
		if e != nil {
			t.Fatal(e)
		}
		body, e := io.ReadAll(r)
		r.Close()
		if e != nil {
			t.Fatal(e)
		}
		for _, expect := range []string{"Produse software", "Sisteme de operare", "Windows Server 2019", "Baze de date", "PostgreSQL", "versiuni: 14.1, 16.4", "Web / Reverse Proxy", "w:ind"} {
			if !strings.Contains(string(body), expect) {
				t.Fatalf("missing %q", expect)
			}
		}
	}
	if !found {
		t.Fatal("missing word/document.xml")
	}
	if path := os.Getenv("RAR_CATALOG_TEST_OUTPUT"); path != "" {
		if err := os.WriteFile(path, data, 0644); err != nil {
			t.Fatal(err)
		}
	}
}
