package documents

import (
	"archive/zip"
	"bytes"
	"fmt"
	"io"
	"strings"
	"time"
)

type RARCatalogItem struct {
	Name     string
	Versions []string
}
type RARCatalogGroup struct {
	Name  string
	Items []RARCatalogItem
}
type RARCatalogContent struct {
	OperatingSystems []RARCatalogItem
	Categories       []RARCatalogGroup
}

// Editable Word paragraphs, with two explicit bullet levels matching the
// source annex. XML special characters and invalid controls are escaped.
func rarCatalogBullet(label string, indent int, square bool) string {
	bullet := "•"
	if square {
		bullet = "▪"
	}
	text := safePoolReportText(strings.TrimSpace(label))
	return fmt.Sprintf(`<w:p><w:pPr><w:spacing w:before="0" w:after="100"/><w:ind w:left="%d" w:hanging="350"/><w:keepTogether/></w:pPr><w:r><w:rPr><w:sz w:val="23"/></w:rPr><w:t>%s</w:t></w:r><w:r><w:tab/><w:rPr><w:sz w:val="23"/></w:rPr><w:t xml:space="preserve">%s</w:t></w:r></w:p>`, indent, bullet, text)
}
func rarCatalogBody(data RARCatalogContent, when time.Time) string {
	var b strings.Builder
	b.WriteString(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>`)
	b.WriteString(`<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>Produse software</w:t></w:r></w:p>`)
	b.WriteString(poolReportParagraph("RAR Anexa 6 · Generat: "+when.UTC().Format("02.01.2006 15:04")+" UTC", false))
	b.WriteString(`<w:p><w:pPr><w:spacing w:before="220" w:after="120"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="28"/></w:rPr><w:t>Inventar software utilizat</w:t></w:r></w:p>`)
	if len(data.OperatingSystems) > 0 {
		b.WriteString(rarCatalogBullet("Sisteme de operare:", 420, false))
		for _, item := range data.OperatingSystems {
			b.WriteString(rarCatalogBullet(item.Name, 960, true))
		}
	}
	for _, category := range data.Categories {
		b.WriteString(rarCatalogBullet(category.Name+":", 420, false))
		for _, item := range category.Items {
			name := item.Name
			if len(item.Versions) > 0 {
				name += " (versiuni: " + strings.Join(item.Versions, ", ") + ")"
			}
			b.WriteString(rarCatalogBullet(name, 960, true))
		}
	}
	if len(data.OperatingSystems) == 0 && len(data.Categories) == 0 {
		b.WriteString(poolReportParagraph("Nu există date care să corespundă filtrelor selectate.", false))
	}
	b.WriteString(`<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1100" w:right="1150" w:bottom="1100" w:left="1150"/></w:sectPr></w:body></w:document>`)
	return b.String()
}
func BuildRARCatalogDOCX(data RARCatalogContent, when time.Time) ([]byte, error) {
	tpl, err := DefaultTemplate()
	if err != nil {
		return nil, err
	}
	r, err := zip.NewReader(bytes.NewReader(tpl), int64(len(tpl)))
	if err != nil {
		return nil, err
	}
	var buf bytes.Buffer
	w := zip.NewWriter(&buf)
	for _, f := range r.File {
		entry, e := w.Create(f.Name)
		if e != nil {
			return nil, e
		}
		if f.Name == "word/document.xml" {
			_, e = io.WriteString(entry, rarCatalogBody(data, when))
		} else {
			in, e2 := f.Open()
			if e2 != nil {
				return nil, e2
			}
			_, e = io.Copy(entry, in)
			in.Close()
		}
		if e != nil {
			return nil, e
		}
	}
	if err = w.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}
