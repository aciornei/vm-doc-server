package server

import (
	"strings"
	"testing"
)

func TestRARCatalogAggregatesOSAndComponents(t *testing.T) {
	vms := []rarCatalogVM{
		{ID: 1, SourceID: 10, OS: "Windows Server 2019", Environment: "PROD", Power: "POWERED_ON"},
		{ID: 2, SourceID: 10, OS: "Windows Server 2019", Environment: "PROD", Power: "POWERED_OFF"},
		{ID: 3, SourceID: 20, OS: "Ubuntu 24.04", Environment: "TEST", Power: "POWERED_ON"},
	}
	rows := []softwareComponentReportRow{
		{VMID: 1, ComponentKey: "postgresql", ComponentName: "PostgreSQL", Category: "Baze de date", Versions: []string{"16.4"}},
		{VMID: 2, ComponentKey: "postgresql", ComponentName: "PostgreSQL", Category: "Baze de date", Versions: []string{"15.7"}},
		{VMID: 3, ComponentKey: "mongodb", ComponentName: "MongoDB", Category: "Baze de date", Versions: []string{"7.0"}},
		{VMID: 3, ComponentKey: "nginx", ComponentName: "Nginx", Category: "Web / Reverse Proxy"},
		// Same component from multiple discovery sources on the same VM.
		{VMID: 1, ComponentKey: "postgresql", ComponentName: "PostgreSQL", Category: "Baze de date", Versions: []string{"16.4"}},
	}
	all := buildRARCatalogReport(vms, rows, nil, rarCatalogFilters{Versions: true})
	if all.Summary.OS != 2 || all.Summary.VMs != 3 || all.Summary.Categories != 2 || all.Summary.Components != 3 {
		t.Fatalf("bad summary %+v", all.Summary)
	}
	if len(all.Categories[0].Components) != 2 {
		t.Fatalf("category %+v", all.Categories)
	}
	if all.Categories[0].Components[1].VMCount != 2 {
		t.Errorf("dedupe failure %+v", all.Categories[0])
	}
	if strings.Join(all.Categories[0].Components[1].Versions, ",") != "15.7,16.4" {
		t.Fatalf("versions %+v", all.Categories[0].Components[1])
	}
	prod := buildRARCatalogReport(vms, rows, nil, rarCatalogFilters{Environment: "PROD", Versions: false})
	if prod.Summary.OS != 1 || prod.Summary.Components != 1 || prod.Categories[0].Components[0].VMCount != 2 || len(prod.Categories[0].Components[0].Versions) != 0 {
		t.Fatalf("PROD failure %+v", prod)
	}
	category := buildRARCatalogReport(vms, rows, nil, rarCatalogFilters{Category: "Web / Reverse Proxy"})
	if category.Summary.Categories != 1 || category.Summary.OS != 2 {
		t.Fatalf("OS must stay independent of category filter %+v", category.Summary)
	}
	vmOS := buildRARCatalogReport(vms, rows, nil, rarCatalogFilters{OS: "Ubuntu 24.04"})
	if vmOS.Summary.VMs != 1 || vmOS.Summary.Components != 2 {
		t.Fatalf("OS filter failure %+v", vmOS.Summary)
	}
	search := buildRARCatalogReport(vms, rows, nil, rarCatalogFilters{Query: "Mongo"})
	if search.Summary.Components != 1 || search.Summary.OS != 0 {
		t.Fatalf("search failure %+v", search.Summary)
	}
}
func TestRARCatalogOSName(t *testing.T) {
	for _, c := range []struct{ n, v, want string }{
		{"SUSE Linux Enterprise Server 11 SP1", "11 SP1", "SUSE Linux Enterprise Server 11 SP1"},
		{"Ubuntu", "24.04", "Ubuntu 24.04"},
		{"Windows XP", "", "Windows XP"},
		{"", "11", ""},
	} {
		if got := rarCatalogOSName(c.n, c.v); got != c.want {
			t.Errorf("%s %s: %q", c.n, c.v, got)
		}
	}
}
