# Upgrade 0.21.98 → 0.21.99 (RAR Anexa 6)

Acest pachet ZIP este **direct extractabil** în directorul *surselor* existente 0.21.98. Nu conține un TAR.GZ suplimentar. Nu extrage în directorul binarului instalat.

1. Verifică versiunea surselor: `cat VERSION` trebuie să fie `0.21.98`. Fă backup binar și configurație și asigură-te că ai un backup MariaDB recuperabil (deși nu există migrare nouă).
2. Din directorul surselor, execută:

   ```bash
   unzip -o /cale/VM-DOC-UPDATE-098-099.zip -d .
   cat VERSION
   ```

   Rezultat așteptat: `0.21.99`.

3. Recompilează în mediul cu `vendor/`:

   ```bash
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
   ```

4. Verifică calea reală a binarului din `systemctl cat vm-doc-server` (`ExecStart`). Oprește serviciul, păstrează backup-ul binarului, instalează `bin/vm-doc-server` în acea cale și repornește serviciul.
5. Verifică `GET /version` → `0.21.99`, fă refresh `Ctrl+F5` și deschide **Rapoarte → RAR Anexa 6 → Produse software · Inventar agregat**.
6. Compară câteva OS și componente cu rapoartele existente; testează exportul Word pentru filtrele PROD și pentru o categorie cu mai multe componente.

Rollback: restaurează binarul surselor 0.21.98 și recompilează/repune binarul anterior. Nu există rollback SQL.

**Limitare validare:** sursele 0.21.99 nu au fost compilate integral sau testate pe MariaDB/VCSA reale în mediul de generare a pachetului. Testul în staging este necesar.
