## Validare după 0.21.99 — RAR Anexa 6 · Produse software
- [ ] Pe MariaDB reală, comparați numărul OS/componente/categorii cu rapoartele VM și Componente software pentru 3–5 VM-uri alese.
- [ ] Verificați VM-urile fără agent dar cu guest OS din VCSA, cele oprite, cele retrase și cele dispărute după ultima sincronizare.
- [ ] Verificați că filtrele vCenter/Power/Mediu/OS se aplică ambelor secțiuni și filtrele Categorie/Componentă numai componentelor; exportul DOCX trebuie să fie identic cu selecția afișată.
- [ ] Verificați catalogul real al produselor de securitate; dacă ele lipsesc din raportul Componente software, analizați extinderea catalogului într-un release separat, nu adăugați valori presupuse.
- [ ] Compilați integral `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...` și `make build` pe serverul offline; verificați UI mobil/desktop și Office real.

# VM-DOC — TODO / backlog

> Actualizat: 2026-10-19, după VM-DOC Server 0.21.49. Acest fișier păstrează funcționalitățile **amânate**, nu descrie funcții implementate.

## De verificat în staging — Hartă rețea 0.21.49

- [ ] Verifică numele/IP-urile VM-urilor externe în Sursă și Destinație: `VM(IP)` pe un rând, apoi `Obiecte FortiGate:` cu lista completă, fără dubluri de identitate.
- [ ] Verifică antetele SURSĂ/DESTINAȚIE, porturi TCP din VM cu spațiere mărită și nota „Interpretare” cu margine stânga.
- [ ] Exportă SVG pentru VM cu peste 100 de obiecte și nume foarte lungi: toate trebuie păstrate integral, fără butoane Extinde/Restrânge, pe fundal/casete albe; viewer SVG/PDF independent de tema browserului.
- [ ] Confirmă că în UI rămân limitele și controalele de navigare a obiectelor, iar click port ↔ policy/linie și excluderile UDP/DNS funcționează ca înainte.
- [ ] Confirmă `go test ./...`, `make build` cu `vendor/`, apoi test pe inventarul real FortiGate și pagini desktop/mobil.

## De verificat în staging — Hartă rețea 0.21.48

- [ ] Compară policy FortiGate cu 0.21.46: număr vizibil, servicii/porturi enumerate sub număr, VDOM/NAT în tooltip și detaliile complete.
- [ ] Testează 100+ obiecte în Sursă/Destinație: primele 4 vizibile, Extinde pentru ferestre de 16, Anterioare/Următoarele și Restrânge accesibile până la ultimul obiect, fără SVG uriaș.
- [ ] Verifică porturi `9078/tcp` fără descrierea generică „port ascultat”, dar cu nume tehnice relevante păstrate.
- [ ] Confirmă export SVG, click port ↔ linie/policy/nod, regulile UDP și DNS, două VM-uri și fluxuri bidirecționale, inclusiv pe dispozitive înguste.

## De verificat în staging — Hartă rețea 0.21.47

- [ ] Testează port selectat și toate legăturile FortiGate spre acel port, inclusiv multiple reguli spre același port, apoi selecție inversă din linie/policy.
- [ ] Testează fluxuri fără port TCP corelabil: nu evidenția un port arbitrar; tooltip/panoul de detalii păstrează datele complete.
- [ ] Verifică cele opt KPI într-un singur rând la 1595/1366px și comportamentul la 1024/390/350 px; nu trebuie să existe overflow orizontal global.
- [ ] Verifică numele VM lungi, 10+ porturi, două VM-uri într-un serviciu, lizibilitatea policy-urilor și exportul SVG.

## De verificat în staging — Hartă rețea 0.21.46

- [ ] Verifică în Chrome/Firefox la 1595/1366/1024/390 px scrollul numai în diagramă, fără intercalare cu navigarea laterală sticky.
- [ ] Verifică în SVG VM cu un singur nod și servicii/porturi multe, precum și hartă de serviciu cu două sau mai multe VM-uri; conexiunile către porturi trebuie să rămână la nodul corect.
- [ ] Verifică fluxuri FortiGate cu multe obiecte sursă/destinație și servicii, expandare/restrângere liste, inclusiv alinierea dintre DECLARAT și Corelate.
- [ ] Verifică exportul SVG, opțiunea +N pentru adresele din diagramă, linkurile din noduri și panourile DECLARAT/Corelate.

## De verificat în staging — Server 0.21.45

- [ ] Verifică VM → Securitate → Hardening pe date reale: trei carduri compacte aliniate (Profil de evaluare / Evaluare curentă / Profil aplicat), funcționalitatea Salvează profilul, RBAC fără drept de editare și actualizarea corectă a datelor după salvare.
- [ ] Verifică Export Excel în dreapta antetului „Controale evaluate”, fișierul descărcat per VM și compatibilitatea cu modurile light/dark.
- [ ] Verifică marcajul roșu BETA ca semn de carte în colțul superior drept (VM, raport Securitate, Nomenclatoare) și nota de validare de jos, fără suprapuneri sau interpretare drept eroare tehnică.
- [ ] Verifică Hardening → Securitate pe date reale: **BETA** vizibil, KPI corecți, search/filtre limitate la pagina curentă, Reset, paginare 10/25/50/100, export și RBAC.
- [ ] Verifică Hardening pe fișa VM și în Nomenclatoare (marcaj BETA, meniuri, salvare profil Draft/clone, fără schimbări de calcul).
- [ ] Verifică Firewall central/per VM (FortiGate și Local): nu mai există săgeata `↕` izolată; reviziile în trei coloane și detaliile policy rămân funcționale.
- [ ] Confirmă în staging Chrome/Firefox la 1595/1024/390 px și contrastul dark/light, inclusiv meniul sticky.
- [ ] Verifică în Firefox/Chrome la rezoluțiile reale că FortiGate/Local sunt în stânga pe același rând cu celelalte carduri în dreapta și există distanța centrală dorită; testează și pagina centrală, și fișa VM.
- [ ] Verifică indicatorul „Revizuite X din Y” aliniat la dreapta și fără atingerea marginii tabelului, inclusiv la redimensionare.
- [ ] Verifică Policy # aliniat cu celelalte celule și expandarea detaliilor, fără schimbări ale scrollului sau reviziilor.
- [ ] Confirmă `GOPROXY=off go test ./...` și `make build` cu `vendor/` local; testează pe MariaDB reală.

## Amânate explicit — reluăm după maturizarea aplicației

### 1. Integrare Wazuh prin API — AMÂNAT

- Scop: Wazuh ca sursă externă pentru Security Configuration Assessment (SCA), politici CIS-referenced și ulterior vulnerabilități.
- VM-DOC rămâne proprietarul inventarului de VM/servicii/beneficiari și al rapoartelor de impact; nu devine scanner de securitate complet.
- Corelare agenți Wazuh cu VM-DOC prin ID legat persistent, FQDN/hostname/IP cu rezolvare manuală a ambiguităților.
- API read-only pentru agenți, politici și rezultate SCA; sincronizare programată, stare sursă, erori/timeout, paginare, export și Swagger.
- Autentificare cu permisiuni minime, TLS verificat și secrete ținute numai în server (niciodată în exporturi, Outline sau documente).
- Raportarea distinge explicit **Wazuh SCA** de **VM-DOC Baseline**. Scorurile nu se adună ca și cum ar folosi același set de reguli.
- Fază separată pentru vulnerabilități/CVE și impact pe VM, servicii și departamente.
- **Nu se implementează acum.** Hardening-ul existent rămâne baseline pentru VM-uri fără agent Wazuh, inclusiv legacy. Șabloanele draft Apache/Nginx/DB rămân pentru viitor, fără pretenție de conformitate CIS completă.

### 2. Consolă shell SSH din fișa VM, chei prin Vault — AMÂNAT

- Scop: sesiune SSH interactivă către VM din interfața VM-DOC, folosind credențiale/chei gestionate în Vault.
- Design obligatoriu înainte de implementare: RBAC separat, permisiuni pe VM/mediu, MFA/reautentificare după caz, aprobare pentru acces privilegiat.
- Sesiuni proxy prin backend controlat; nici cheia SSH, nici tokenul Vault nu sunt expuse browserului, jurnalelor sau documentației exportate.
- Audit sesiune (cine, VM, timp, acțiuni și rezultat), limite de timp, revocare, izolare, rate-limit; gestiunea înregistrării sesiunii după politica de confidențialitate.
- Verificări anti-SSRF/host-key și control destinație; nu permite comenzi arbitrare prin funcția obișnuită de colectare agent.
- **Nu se implementează acum.** Necesită model de securitate, review și test de intruziune înainte de activare PROD.

### Verificări pentru Firewall 0.21.41 — de făcut în staging

- [ ] Verifică ambele moduri FortiGate/Local în Firewall central și fișa VM, inclusiv VM-uri fără inventar local, reguli UFW/firewalld/SuSEfirewall2 și reguli nftables/iptables directe.
- [ ] Verifică revizia individuală a firewall-ului local, revizia colectivă pe un singur VM, auditul, rollback-ul, comportamentul cu reguli șterse/recolectate și faptul că filtrele vizuale nu limitează greșit revizia.
- [ ] Compară exporturile XLSX FortiGate și Local cu inventarul real, mai ales policy/VDOM/NAT, obiecte/servicii multiple și datele reviziilor.
- [ ] Testează compactarea la 1595/1024/390 px și navigarea cu tastatura pe tabelul scrollabil; măsoară memoria Chrome și verifică absența suprapunerii cu meniul global.

## Validare 0.21.42 — staging

- [ ] Verifică în interfața reală Securitate → Firewall: FortiGate/Local ca două carduri, butoane Export/Revizuiește în panel-header, Policy # cu expandarea detaliilor sub rând, fără coloană Detalii.
- [ ] Verifică reviziile individuale FortiGate și locale în cele trei coloane (Revizuit / De / Next review), inclusiv cazuri expirate și fără revizie; verifică după salvare progresul „Revizuite X din Y”.
- [ ] Verifică în Database Access numărătoarea per principal Users/Grants și per regulă HBA; în Web ACL numărătoarea per site. Nu confunda cele 20.000 de granturi obiect cu unitățile de revizie per principal.
- [ ] Testează exporturile și bulk review existente cu RBAC/CSRF și date MariaDB reale. Confirmă că patchul JS/CSS nu schimbă identitatea/istoricul reviziilor.

## Următoarea direcție activă

1. [ ] Verifică vizual în staging **Securitate 0.21.41**, cu date reale: Dashboard, Conturi VM (politică parole și conturi system colapsabile fără checkbox, popup review), Database Access (revizii pe principal DB), Web ACL, Firewall/Caută, Surse & Sync, Analiză și Hardening. Verifică panourile la 1595/1024/390 px, selecțiile active, review-urile și resetarea filtrelor.
2. [ ] Testează în staging salvarea și raportarea review-urilor DB per principal: utilizatori omonimi pe instanțe diferite, user@host, reconciliere după colectare, date istorice de review pe instanță; verifică lipsa modificărilor de review ale conturilor system.
3. [ ] Confirmă `go test ./...` și `make build` cu `vendor/` pe serverul offline; optimizează eventualele ecrane lente pe date MariaDB reale.
4. [ ] Confirmă migrarea 078 și beneficiarii Compose, precum și afișarea beneficiarilor DB agregați; nu modifica retrospectiv asocierile existente.
5. [ ] Păstrează backlogurile Wazuh și Shell SSH prin Vault amânate până la maturizarea aplicației și aprobarea măsurilor de securitate.

- [ ] Validează în staging formularul popup de revizie pentru cont relevant, principal DB, Web ACL și Firewall: revizor/date server-side, precompletare, anulare, drepturi RBAC, afișare Next review și tratarea erorilor API.

- [ ] Validează UI 0.21.34: trei coloane Revizuit/De/Next review la Conturi VM (inclusiv system), DB principals, Web ACL, Firewall; data+ora pe un rând, rândurile nerevizuite colspan=3 și nume VM/cont corecte în popup. Testează salvarea cu RBAC și MariaDB real.

- [ ] **0.21.35:** testează pe serverul offline cu `vendor/`: `go test ./...`, `make build`, noul endpoint `PUT /api/v1/security/review/bulk`, autentificarea, drepturile, CSRF și tranzacțiile MySQL/MariaDB. Încearcă operații bulk pe VM/instanțe DB cu review deja existent, apoi review individual și verifică auditul.
- [ ] **0.21.35:** în staging, compară gruparea 2.000+ granturi cu inventarul brut `access_json` la PostgreSQL, verifică păstrarea `DENY` / `GRANT OPTION` / `source`, roluri custom NOLOGIN și filtrele în Calendar revizii.
- [ ] **0.21.35:** verifică paginile Securitate Database Access, Conturi, Web ACL la lățimile 1595 / 1024 / 390 cu date reale și performanța la tabele foarte mari. Confirma popup-ul bulk cu observații obligatorii și corelația cu VM-ul selectat.

- [ ] **0.21.36:** execută `go test ./...` și `make build` cu vendor/ offline; testează GET `/api/v1/security/databases/export` cu 1, 2, 3 sheet-uri, 20.000+ grants și `vm_id`; confirmă că workbook include toate granturile fără trunchiere.
- [ ] **0.21.36:** validează DB bulk pe `database_principals`, `database_grants` și `database_hba` exclusiv per instanță; asigură că review-ul Users nu afectează Grants/HBA, că cele individuale pot suprascrie colectivul și că drepturile RBAC/CSRF/audit funcționează.
- [ ] **0.21.36:** testează identitatea granturilor după resync și reconcilierea HBA după schimbarea numerelor de linie; decide dacă este dorit un mecanism explicit de invalidare automată a review-ului pe apariția de privilegii noi.
- [ ] **0.21.36:** în Chromium cu inventar real: un server cu 20k grants / 282 grupuri în versiunea anterioară, grupare efectiv per user, expand și încărcare câte 200; PostgreSQL HBA explicat fără warnings redundante; MySQL fără HBA.

- [ ] **0.21.37 · P1 memorie:** profilare cu Chrome Task Manager (Shift+Esc), DevTools → Memory (heap snapshots și Detached DOM), Performance Monitor, compară 0.21.36 vs 0.21.37 pe aceleași VM-uri: Securitate Dashboard, Conturi, DB PostgreSQL 20k+ grants, pagini VM și navigări repetate. Notează memory footprint/JS heap per tab și response size /api/v1/security?section=... .
- [ ] **0.21.37:** verifică proiectarea API și consistența KPI la toate secțiunile cu MariaDB reală; verifică pagina Review după schimbarea secțiunii, Export Excel și aplicațiile care consumă vechiul GET /api/v1/security fără parametrul section.
- [ ] **Optimizare viitoare:** endpoint paginat server-side pentru DB Access, cu granturi încărcate per instanță/utilizator numai la expand; noua proiecție secțiune încă transportă toate DB/grants când fila Database Access este deschisă. Implementare cu filtre/căutare server-side și test de stabilitate 20k+.

- [ ] **0.21.38:** verifică vizibilitatea permanentă a butonului „Aplică revizia” și a checkbox-ului la zoom 100%/125%/150%, pe 390/1024/1595 px, inclusiv în ferestre Chrome cu înălțime mică, cu texte lungi și erori API.
- [ ] **0.21.38:** verifică revizia individuală Grants pe roluri/user@host reale, păstrarea datei/verificatorului, extensia exclusivă a grupurilor tehnice și memoria la 20k+ granturi.

- [ ] **Validare Web ACL 0.21.39:** verifică site-uri Nginx/Apache cu/fără ACL, ALLOW ALL, review în summary, revizie colectivă, export global și per VM. Confirmă numărul de rânduri din Excel, sursele include și memoria Chrome după navigare.

- [ ] **0.21.40 · Web ACL UI:** validează în staging panoul Filtre global și per VM la 1595/1024/390/350 px; ambele butoane vizibile când panoul este restrâns, căutare generală, bifa Doar cele cu ACL, reset, schimbare VM, filtre persistente în același VM. Confirmă că revizia globală fără VM selectat nu se execută și că filtrarea UI nu limitează scopul reviziei colective sau exportul Excel.
