# VM-DOC Server 0.21.99 — RAR Anexa 6 · Produse software

**Bază:** 0.21.98. **Agent:** 1.7.18, nemodificat. **Migrare SQL nouă:** niciuna.

În **Rapoarte → RAR Anexa 6** apare a treia intrare: **Produse software · Inventar agregat**. Cele două rapoarte anterioare (Pool / VM / Obs. și A3. Produse software și servicii) rămân nemodificate.

## Conținut
- Sisteme de operare: valori observate în `inventory_snapshots.os_name/os_version`, cu fallback `virtual_machines.guest_os`; un singur element distinct per denumire.
- Categorii și componente: **exact detectorul existent** din `Rapoarte → Componente software`, cu deduplicare per componentă și numărul de VM-uri afectate.
- Versiunile sunt opționale și apar exclusiv când există în inventar. Nu sunt inventate componente, versiuni sau categorii.
- Sunt incluse VM-uri neretrase și **prezente la ultima sincronizare VCSA**; cele dispărute / retrase nu intră în centralizator. Componentele sunt limitate la acele VM-uri.

## Filtre
Căutare text (OS/categorie/componentă/versiune), vCenter, mediu, Power, OS, categorie, componentă și afișarea versiunilor. Filtrele pe VM/OS afectează ambele secțiuni; filtrele pe categorie/componentă afectează numai componentele. Căutarea text selectează independent rândurile vizibile ale fiecărei secțiuni.

## Export Word
GET `/api/v1/reports/rar-catalog/export/docx` reutilizează filtrele din UI, produce DOCX editabil A4 portret, cu bullet-uri de nivel 1 pentru «Sisteme de operare» și fiecare categorie, bullet-uri de nivel 2 pentru elemente. Documentul nu conține linkuri Vault sau alte secrete.

## Compatibilitate și validare
- API read-only, protejat de `reports.read`, rute noi `/api/v1/reports/rar-catalog` și `/export/docx`.
- Fișierele modificate: backend nou raport, generator Word nou, JS/CSS, router, OpenAPI, metadate VERSION, releases, documentație; fără schimbări în schema DB, inventar, agenți, VCSA sync și celelalte două rapoarte.
- Testele Go ale generatorului DOCX au trecut. Testele funcției de agregare au trecut într-un modul Go izolat cu stub-uri, deoarece dependențele modulelor server nu există aici. `node --check`, JSON și YAML OpenAPI au trecut. DOCX-ul QA a fost randat și inspectat vizual.
- **Nevalidate:** build complet cu `vendor/`, query-urile pe MariaDB de producție, UI în browser real și export din date reale. Se recomandă staging și backup înainte de instalare.
