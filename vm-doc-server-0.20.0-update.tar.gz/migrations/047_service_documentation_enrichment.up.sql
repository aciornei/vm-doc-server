-- 0.20.0 · metadate serviciu, tip soluție pe resurse și documentație suplimentară DOCX.

ALTER TABLE internal_services
  ADD COLUMN short_description TEXT NOT NULL DEFAULT '' AFTER service_code,
  ADD COLUMN authentication TEXT NOT NULL DEFAULT '' AFTER objectives_richtext,
  ADD COLUMN service_url VARCHAR(2048) NOT NULL DEFAULT '' AFTER authentication,
  ADD COLUMN technologies TEXT NOT NULL DEFAULT '' AFTER service_url;

UPDATE internal_services
SET short_description = LEFT(description, 2000)
WHERE short_description = '' AND description <> '';

ALTER TABLE docker_container_service_assignments
  ADD COLUMN solution_type_id BIGINT UNSIGNED NULL AFTER operational_status_id,
  ADD KEY idx_docker_service_assignment_solution_type (solution_type_id),
  ADD CONSTRAINT fk_docker_service_assignment_solution_type FOREIGN KEY (solution_type_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL;

ALTER TABLE database_instance_service_assignments
  ADD COLUMN solution_type_id BIGINT UNSIGNED NULL AFTER operational_status_id,
  ADD KEY idx_database_instance_service_solution_type (solution_type_id),
  ADD CONSTRAINT fk_database_instance_service_solution_type FOREIGN KEY (solution_type_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL;

ALTER TABLE database_catalog_service_assignments
  ADD COLUMN solution_type_id BIGINT UNSIGNED NULL AFTER operational_status_id,
  ADD KEY idx_database_catalog_service_solution_type (solution_type_id),
  ADD CONSTRAINT fk_database_catalog_service_solution_type FOREIGN KEY (solution_type_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL;

ALTER TABLE web_site_service_assignments
  ADD COLUMN solution_type_id BIGINT UNSIGNED NULL AFTER operational_status_id,
  ADD KEY idx_web_site_service_solution_type (solution_type_id),
  ADD CONSTRAINT fk_web_site_service_solution_type FOREIGN KEY (solution_type_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS internal_service_attachments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  internal_service_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(255) NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(190) NOT NULL DEFAULT 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  content LONGBLOB NOT NULL,
  extracted_text LONGTEXT NOT NULL,
  sha256 CHAR(64) NOT NULL,
  size_bytes BIGINT UNSIGNED NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  KEY idx_internal_service_attachments_service (internal_service_id,created_at,id),
  CONSTRAINT fk_internal_service_attachments_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_internal_service_attachments_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
