package server

import (
	"errors"
	"fmt"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/documents"
)

const serviceAttachmentMaxBytes int64 = 20 << 20

func (a *App) listInternalServiceAttachments(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	values, err := a.Catalog.ListAttachments(r.Context(), serviceID, false)
	respond(w, values, err)
}

func (a *App) uploadInternalServiceAttachment(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	max := serviceAttachmentMaxBytes
	if a.Config.Server.MaxRequestBody > 0 && a.Config.Server.MaxRequestBody < max {
		max = a.Config.Server.MaxRequestBody
	}
	r.Body = http.MaxBytesReader(w, r.Body, max+(1<<20))
	if err := r.ParseMultipartForm(max); err != nil {
		badRequest(w, fmt.Errorf("invalid multipart upload: %w", err))
		return
	}
	file, header, err := r.FormFile("file")
	if err != nil {
		badRequest(w, errors.New("DOCX file is required"))
		return
	}
	defer file.Close()
	if !strings.EqualFold(filepath.Ext(header.Filename), ".docx") {
		badRequest(w, errors.New("only .docx files are accepted"))
		return
	}
	content, err := readMultipartFile(file, max)
	if err != nil {
		badRequest(w, err)
		return
	}
	extracted, err := documents.ExtractSupplementalDOCXText(content)
	if err != nil {
		badRequest(w, err)
		return
	}
	title := strings.TrimSpace(r.FormValue("title"))
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Catalog.CreateAttachment(r.Context(), serviceID, user.ID, title, filepath.Base(header.Filename), content, extracted)
	if err == nil {
		a.auditRequest(r, "internal_service_attachment.create", "internal_service_attachment", strconv.FormatInt(value.ID, 10), "success", map[string]any{"internal_service_id": serviceID, "file_name": value.FileName, "sha256": value.SHA256, "size_bytes": value.SizeBytes})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) downloadInternalServiceAttachment(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	attachmentID, err := strconv.ParseInt(strings.TrimSpace(r.PathValue("attachment_id")), 10, 64)
	if err != nil || attachmentID < 1 {
		badRequest(w, errors.New("invalid attachment id"))
		return
	}
	value, err := a.Catalog.GetAttachment(r.Context(), serviceID, attachmentID, true)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "internal_service_attachment.download", "internal_service_attachment", strconv.FormatInt(value.ID, 10), "success", map[string]any{"internal_service_id": serviceID})
	writeDownload(w, value.MIMEType, value.FileName, value.Content)
}

func (a *App) deleteInternalServiceAttachment(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	attachmentID, err := strconv.ParseInt(strings.TrimSpace(r.PathValue("attachment_id")), 10, 64)
	if err != nil || attachmentID < 1 {
		badRequest(w, errors.New("invalid attachment id"))
		return
	}
	if err := a.Catalog.DeleteAttachment(r.Context(), serviceID, attachmentID); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "internal_service_attachment.delete", "internal_service_attachment", strconv.FormatInt(attachmentID, 10), "success", map[string]any{"internal_service_id": serviceID})
	w.WriteHeader(http.StatusNoContent)
}
