package documents

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"errors"
	"io"
	"strings"
)

// ExtractSupplementalDOCXText extracts human-readable text from a DOCX uploaded
// as supplemental service documentation. Paragraph and table row boundaries are
// retained so the generated service document can render the content in chapter 2.
func ExtractSupplementalDOCXText(content []byte) (string, error) {
	if len(content) == 0 {
		return "", errors.New("DOCX file is empty")
	}
	reader, err := zip.NewReader(bytes.NewReader(content), int64(len(content)))
	if err != nil {
		return "", errors.New("invalid DOCX archive")
	}
	var document []byte
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		rc, err := file.Open()
		if err != nil {
			return "", err
		}
		document, err = io.ReadAll(io.LimitReader(rc, 16<<20))
		rc.Close()
		if err != nil {
			return "", err
		}
		break
	}
	if len(document) == 0 {
		return "", errors.New("DOCX does not contain word/document.xml")
	}

	decoder := xml.NewDecoder(bytes.NewReader(document))
	var out strings.Builder
	var inText bool
	for {
		token, err := decoder.Token()
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			return "", errors.New("invalid DOCX document.xml")
		}
		switch value := token.(type) {
		case xml.StartElement:
			if value.Name.Local == "t" {
				inText = true
			}
		case xml.CharData:
			if inText {
				out.WriteString(string(value))
			}
		case xml.EndElement:
			switch value.Name.Local {
			case "t":
				inText = false
			case "tab":
				out.WriteByte('\t')
			case "br":
				out.WriteByte('\n')
			case "tc":
				if out.Len() > 0 && !strings.HasSuffix(out.String(), "\t") && !strings.HasSuffix(out.String(), "\n") {
					out.WriteByte('\t')
				}
			case "p", "tr":
				if out.Len() > 0 && !strings.HasSuffix(out.String(), "\n") {
					out.WriteByte('\n')
				}
			}
		}
	}

	lines := strings.Split(strings.ReplaceAll(out.String(), "\r\n", "\n"), "\n")
	clean := make([]string, 0, len(lines))
	blank := false
	for _, line := range lines {
		line = strings.TrimSpace(strings.TrimRight(line, "\t"))
		if line == "" {
			if len(clean) > 0 && !blank {
				clean = append(clean, "")
				blank = true
			}
			continue
		}
		clean = append(clean, line)
		blank = false
	}
	for len(clean) > 0 && clean[len(clean)-1] == "" {
		clean = clean[:len(clean)-1]
	}
	text := strings.TrimSpace(strings.Join(clean, "\n"))
	if text == "" {
		return "", errors.New("DOCX does not contain readable text")
	}
	return text, nil
}
