package catalog

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"errors"
	"strings"

	"vm-doc-server/internal/domain"
)

const supplementalDOCXMIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

func (s Service) ListAttachments(ctx context.Context, serviceID int64, includeContent bool) ([]domain.InternalServiceAttachment, error) {
	if serviceID < 1 {
		return nil, errors.New("invalid service id")
	}
	columns := `a.id,a.internal_service_id,a.title,a.file_name,a.mime_type,a.sha256,a.size_bytes,a.created_by,COALESCE(u.display_name,u.username,''),a.created_at,a.extracted_text`
	if includeContent {
		columns += `,a.content`
	}
	rows, err := s.DB.QueryContext(ctx, `SELECT `+columns+` FROM internal_service_attachments a LEFT JOIN users u ON u.id=a.created_by WHERE a.internal_service_id=? ORDER BY a.created_at,a.id`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.InternalServiceAttachment{}
	for rows.Next() {
		var value domain.InternalServiceAttachment
		var createdBy sql.NullInt64
		if includeContent {
			err = rows.Scan(&value.ID, &value.InternalServiceID, &value.Title, &value.FileName, &value.MIMEType, &value.SHA256, &value.SizeBytes, &createdBy, &value.CreatedByName, &value.CreatedAt, &value.ExtractedText, &value.Content)
		} else {
			err = rows.Scan(&value.ID, &value.InternalServiceID, &value.Title, &value.FileName, &value.MIMEType, &value.SHA256, &value.SizeBytes, &createdBy, &value.CreatedByName, &value.CreatedAt, &value.ExtractedText)
		}
		if err != nil {
			return nil, err
		}
		if createdBy.Valid {
			id := createdBy.Int64
			value.CreatedBy = &id
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) GetAttachment(ctx context.Context, serviceID, attachmentID int64, includeContent bool) (domain.InternalServiceAttachment, error) {
	values, err := s.ListAttachments(ctx, serviceID, includeContent)
	if err != nil {
		return domain.InternalServiceAttachment{}, err
	}
	for _, value := range values {
		if value.ID == attachmentID {
			return value, nil
		}
	}
	return domain.InternalServiceAttachment{}, sql.ErrNoRows
}

func (s Service) CreateAttachment(ctx context.Context, serviceID, userID int64, title, fileName string, content []byte, extractedText string) (domain.InternalServiceAttachment, error) {
	if serviceID < 1 {
		return domain.InternalServiceAttachment{}, errors.New("invalid service id")
	}
	var exists int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM internal_services WHERE id=?`, serviceID).Scan(&exists); err != nil {
		return domain.InternalServiceAttachment{}, err
	}
	if exists == 0 {
		return domain.InternalServiceAttachment{}, sql.ErrNoRows
	}
	title = strings.TrimSpace(title)
	fileName = strings.TrimSpace(fileName)
	extractedText = strings.TrimSpace(extractedText)
	if title == "" {
		title = strings.TrimSuffix(fileName, ".docx")
	}
	if title == "" || fileName == "" || len(content) == 0 || extractedText == "" {
		return domain.InternalServiceAttachment{}, errors.New("title, DOCX file and extracted text are required")
	}
	if len([]rune(title)) > 255 || len([]rune(fileName)) > 255 {
		return domain.InternalServiceAttachment{}, errors.New("attachment title or file name is too long")
	}
	hash := sha256.Sum256(content)
	result, err := s.DB.ExecContext(ctx, `INSERT INTO internal_service_attachments(internal_service_id,title,file_name,mime_type,content,extracted_text,sha256,size_bytes,created_by) VALUES(?,?,?,?,?,?,?,?,?)`, serviceID, title, fileName, supplementalDOCXMIME, content, extractedText, hex.EncodeToString(hash[:]), len(content), userID)
	if err != nil {
		return domain.InternalServiceAttachment{}, err
	}
	id, err := result.LastInsertId()
	if err != nil {
		return domain.InternalServiceAttachment{}, err
	}
	return s.GetAttachment(ctx, serviceID, id, false)
}

func (s Service) DeleteAttachment(ctx context.Context, serviceID, attachmentID int64) error {
	result, err := s.DB.ExecContext(ctx, `DELETE FROM internal_service_attachments WHERE id=? AND internal_service_id=?`, attachmentID, serviceID)
	if err != nil {
		return err
	}
	count, _ := result.RowsAffected()
	if count == 0 {
		return sql.ErrNoRows
	}
	return nil
}
