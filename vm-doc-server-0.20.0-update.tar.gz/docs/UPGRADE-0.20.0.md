# Upgrade vm-doc-server 0.19.16 → 0.20.0

0.20.0 este un update de server/UI/documentație. Nu necesită o versiune nouă de vm-doc-agent.

## Noutăți

- Docker / Baze de date / Web: asocierile manuale la servicii au selector **Tip soluție** din nomenclator;
- Detalii serviciu: câmpuri noi **Descriere scurtă**, **Autentificare**, **Link serviciu**, **Tehnologii folosite**;
- **Documentație suplimentară a serviciului**: se pot încărca fișiere DOCX (maxim 20 MB implicit), păstrate în original și folosite ca sursă de text pentru capitolul 2;
- `Număr document` devine **Număr electronic document**;
- titlul fișei include numele serviciului, iar tabelul de identificare nu îl mai repetă;
- descrierea detaliată rich-text își păstrează formatarea în DOCX;
- capitolul 3 afișează câte un VM pe rând;
- din dependențe dispare coloana `VM-uri furnizor`;
- fișele VM sunt prezentate în secțiunea **Anexe — fișe tehnice VM**;
- fontul normal al documentelor este Arial 12;
- migrare nouă `047_service_documentation_enrichment.up.sql`.

## Upgrade

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.16 vm-doc-server-0.20.0
tar -xzf /cale/vm-doc-server-0.20.0-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.0
cd /usr/local/src/vm-doc-server-0.20.0

# în mediul offline, folosiți vendor-ul vostru existent
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build

systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

Migrarea 047 se aplică automat la pornire. După upgrade folosiți `Ctrl+F5` în browser.

## Verificare

1. `/version` trebuie să raporteze `0.20.0`.
2. Editați un serviciu și completați Descriere scurtă, Autentificare, Link și Tehnologii.
3. Pe o asociere Docker/DB/Web verificați selectorul Tip soluție.
4. Încărcați un DOCX în **Documentație suplimentară a serviciului** și regenerați fișa.
5. Verificați în fișă capitolul 2, listarea VM-urilor pe rând la capitolul 3 și Anexele VM de la final.
6. Verificați că textul normal este Arial 12.

## Compatibilitate

- datele existente sunt păstrate; noile câmpuri pornesc goale;
- asocierile Docker/DB/Web existente rămân valide cu `solution_type_id = NULL`;
- documentele suplimentare sunt stocate în baza de date împreună cu textul extras și hash SHA-256;
- nu este necesar update de agent.
