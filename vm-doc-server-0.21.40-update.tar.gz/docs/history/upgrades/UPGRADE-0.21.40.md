# Upgrade VM-DOC Server 0.21.39 → 0.21.40

1. Salvează backup-ul MariaDB, binarul, sursele și directorul `vendor/` din instalarea 0.21.39.
2. Aplică `vm-doc-server-0.21.39-to-0.21.40.patch` cu `git apply` sau extrage `vm-doc-server-0.21.40-update.tar.gz` peste o **copie curată** a surselor 0.21.39, nu ambele.
3. Verifică `cat VERSION` = `0.21.40` și rulează `bash scripts/cleanup-source-tree.sh --check`.
4. În mediul offline cu `vendor/` disponibil:

```bash
GOPROXY=off GOSUMDB=off go test ./...
GOPROXY=off GOSUMDB=off make build
```

5. Instalează binarul în staging și testează Securitate → Web Access Control + VM → Securitate → Web ACL: cele două butoane permanent vizibile, săgeată dreapta sus, căutare, numai cu ACL, filtrele vechi, alegerea VM la revizia globală, individual și bulk, export complet global/per VM.
6. Confirma într-un browser real că această UI nu generează duplicări, nu crește memoria anormal și este accesibilă la 1595/1024/390/350px. După validare, instalează în producție după procedura internă.

Rollback: restaurează binarul 0.21.39. Nu există migrare SQL de reversat. Agent 1.7.18 nu necesită update.

**Nu se distribuie binar Go precompilat sau vendor/**. JS/CSS și metadate/versioning numai; nu există modificări funcționale backend/API.
