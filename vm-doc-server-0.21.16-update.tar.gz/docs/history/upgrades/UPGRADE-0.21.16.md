# Upgrade VM-DOC Server 0.21.15 → 0.21.16

**Tip:** UI/UX + documentare TODO; **migrare DB:** nu; **agent:** neschimbat 1.7.18; **API:** neschimbat; **go.mod/go.sum:** neschimbate.

## Recomandare

1. Backup fișiere/configurație și DB (procedura curentă).
2. Copiază sursele 0.21.15 în director nou și aplică update-ul `0.21.16-update.tar.gz`, păstrând `vendor/` existent.
3. Verifică `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și `GOPROXY=off GOFLAGS=-mod=vendor make build` în acel director.
4. Înlocuiește binarul doar după validare, repornește serviciul conform procedurii interne.
5. Reîncarcă browserul cu Ctrl+F5; activele CSS/JS sunt versionate `?v=0.21.16`.
6. Verifică light/dark și meniul la 1440/1024/390 px, apoi VM-uri, Servicii, Rapoarte, Securitate, FortiGate și Documente cu date reale.

**Rollback:** restaurează binarul și directorul 0.21.15 (nu este nevoie de rollback SQL).

**Notă:** dacă folderul 0.21.15 conține copii imbricate istorice, rulează întâi `scripts/cleanup-source-tree.sh --check`; nu elimina `vendor/`.
