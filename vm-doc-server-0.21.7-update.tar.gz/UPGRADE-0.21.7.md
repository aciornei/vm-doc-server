# Upgrade VM-DOC Server 0.21.6 → 0.21.7

Actualizare exclusiv UI, fără migrare SQL, modificare `go.mod`, `go.sum`, `vendor/` ori agent.

## Instalare offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.6 vm-doc-server-0.21.7
tar -xzf /cale/vm-doc-server-0.21.7-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.7
cd /usr/local/src/vm-doc-server-0.21.7
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Instalează binarul compilat folosind fluxul uzual și repornește serviciul. Verifică `/version` (0.21.7) și reîncarcă pagina din browser.

## Verificări

1. Nomenclatoare → Responsabilități: Beneficiari apare sub Persoane și are contor cu totalul departamentelor importate sau manuale (inclusiv inactive).
2. VM → Docker → Proiecte Docker Compose: există spațiu deasupra celor 4 listbox-uri; nu apar Servicii și Beneficiari sub rândul proiectului.
3. Un proiect deja asociat uniform păstrează selectate Serviciu, Mediu, Status operațional și Tip soluție la fiecare reîncărcare.
4. Un proiect care are asocieri diferite/parțiale pe containere afișează Valori diferite și cere selecții explicite înainte de salvare.
5. Linkurile către servicii și beneficiarii resurselor rămân vizibile în tabelul individual de containere.

Nu există migrare MariaDB nouă și nu se modifică agentul.
