-- VM-DOC 0.21.27: beneficiari la nivel de proiect Docker Compose.
-- Asocierea este legată de VM + numele proiectului, nu de ID-ul volatil al containerului.
CREATE TABLE IF NOT EXISTS docker_compose_beneficiaries (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  vm_id BIGINT UNSIGNED NOT NULL,
  project_name VARCHAR(255) NOT NULL,
  beneficiary_type VARCHAR(16) NOT NULL,
  beneficiary_id BIGINT UNSIGNED NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_docker_compose_beneficiary (vm_id, project_name, beneficiary_type, beneficiary_id),
  KEY idx_docker_compose_beneficiary_reverse (beneficiary_type, beneficiary_id),
  CONSTRAINT fk_docker_compose_beneficiary_vm FOREIGN KEY (vm_id)
    REFERENCES virtual_machines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
