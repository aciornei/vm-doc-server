DROP TABLE IF EXISTS docker_compose_beneficiaries;
