package server

import "testing"

func TestNormalizeComposeBeneficiaries(t *testing.T) {
	result, err := normalizeComposeBeneficiaries([]composeBeneficiaryInput{
		{BeneficiaryType: "department", BeneficiaryID: 12},
		{BeneficiaryType: "department", BeneficiaryID: 12},
		{BeneficiaryType: "person", BeneficiaryID: 3},
	})
	if err != nil || len(result) != 2 {
		t.Fatalf("deduplicate: got %v, %v", result, err)
	}
	for _, invalid := range []composeBeneficiaryInput{{BeneficiaryType: "docker", BeneficiaryID: 4}, {BeneficiaryType: "person", BeneficiaryID: 0}} {
		if _, err := normalizeComposeBeneficiaries([]composeBeneficiaryInput{invalid}); err == nil {
			t.Fatalf("accepted invalid beneficiary %+v", invalid)
		}
	}
	if result, err := normalizeComposeBeneficiaries(nil); err != nil || len(result) != 0 {
		t.Fatal("empty selection must support clearing")
	}
	if _, err := normalizeComposeBeneficiaries(make([]composeBeneficiaryInput, 201)); err == nil {
		t.Fatal("expected size limit")
	}
}
