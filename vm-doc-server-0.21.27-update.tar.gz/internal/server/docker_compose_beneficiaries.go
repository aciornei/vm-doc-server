package server

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
)

// Stored per (VM, Compose project), not per volatile Docker container ID.
// Effective beneficiary relationships to containers, VM and services are derived
// by beneficiaryEffectiveSQL, without overwriting per-container assignments.
type composeBeneficiaryInput struct {
	BeneficiaryType string `json:"beneficiary_type"`
	BeneficiaryID   int64  `json:"beneficiary_id"`
}
type composeBeneficiaryPayload struct {
	Beneficiaries []composeBeneficiaryInput `json:"beneficiaries"`
}
type composeBeneficiaryView struct {
	BeneficiaryType string `json:"beneficiary_type"`
	BeneficiaryID   int64  `json:"beneficiary_id"`
	Name            string `json:"name"`
	Source          string `json:"source"`
}

func normalizeComposeBeneficiaries(values []composeBeneficiaryInput) ([]composeBeneficiaryInput, error) {
	if len(values) > 200 {
		return nil, errors.New("too many beneficiaries (maximum 200)")
	}
	seen := map[string]bool{}
	out := make([]composeBeneficiaryInput, 0, len(values))
	for _, v := range values {
		if !beneficiaryTypes[v.BeneficiaryType] || v.BeneficiaryID <= 0 {
			return nil, errors.New("invalid beneficiary type or id")
		}
		key := v.BeneficiaryType + ":" + strconv.FormatInt(v.BeneficiaryID, 10)
		if !seen[key] {
			seen[key] = true
			out = append(out, v)
		}
	}
	return out, nil
}

func (a *App) listVMComposeBeneficiaries(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	rows, err := a.DB.QueryContext(r.Context(), `
      SELECT b.project_name,b.beneficiary_type,b.beneficiary_id,
             COALESCE(d.name,p.display_name,''),
             COALESCE(d.source,IF(p.source='ldap','ad',p.source),'')
      FROM docker_compose_beneficiaries b
      LEFT JOIN beneficiary_departments d ON b.beneficiary_type='department' AND d.id=b.beneficiary_id
      LEFT JOIN people p ON b.beneficiary_type='person' AND p.id=b.beneficiary_id
      WHERE b.vm_id=? ORDER BY b.project_name,4`, vmID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer rows.Close()
	result := map[string][]composeBeneficiaryView{}
	for rows.Next() {
		var project string
		var v composeBeneficiaryView
		if err := rows.Scan(&project, &v.BeneficiaryType, &v.BeneficiaryID, &v.Name, &v.Source); err != nil {
			respond(w, nil, err)
			return
		}
		if v.Name != "" {
			result[project] = append(result[project], v)
		}
	}
	respond(w, map[string]any{"projects": result}, rows.Err())
}

func validateComposeBeneficiary(ctx context.Context, tx *sql.Tx, v composeBeneficiaryInput) error {
	table := beneficiaryTable(v.BeneficiaryType) // only validated department/person
	var exists int
	if err := tx.QueryRowContext(ctx, "SELECT 1 FROM "+table+" WHERE id=? AND active=1", v.BeneficiaryID).Scan(&exists); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return errors.New("beneficiary does not exist or is inactive")
		}
		return err
	}
	return nil
}

func (a *App) replaceVMComposeBeneficiaries(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	project := strings.TrimSpace(r.PathValue("project"))
	if project == "" || len(project) > 255 || strings.ContainsAny(project, "/\\") {
		badRequest(w, errors.New("invalid Compose project"))
		return
	}
	var payload composeBeneficiaryPayload
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 65536)).Decode(&payload); err != nil {
		badRequest(w, err)
		return
	}
	values, err := normalizeComposeBeneficiaries(payload.Beneficiaries)
	if err != nil {
		badRequest(w, err)
		return
	}
	tx, err := a.DB.BeginTx(r.Context(), nil)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer tx.Rollback()
	var found int
	// Serialize updates to the same VM and verify that the project exists.
	err = tx.QueryRowContext(r.Context(), "SELECT 1 FROM virtual_machines WHERE id=? FOR UPDATE", vmID).Scan(&found)
	if errors.Is(err, sql.ErrNoRows) {
		badRequest(w, errors.New("VM not found"))
		return
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	err = tx.QueryRowContext(r.Context(), "SELECT 1 FROM docker_containers WHERE vm_id=? AND compose_project=? AND present=1 LIMIT 1", vmID, project).Scan(&found)
	if errors.Is(err, sql.ErrNoRows) {
		badRequest(w, errors.New("Compose project not present in current Docker inventory"))
		return
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	for _, v := range values {
		if err = validateComposeBeneficiary(r.Context(), tx, v); err != nil {
			badRequest(w, err)
			return
		}
	}
	if _, err = tx.ExecContext(r.Context(), "DELETE FROM docker_compose_beneficiaries WHERE vm_id=? AND project_name=?", vmID, project); err != nil {
		respond(w, nil, err)
		return
	}
	for _, v := range values {
		if _, err = tx.ExecContext(r.Context(), "INSERT INTO docker_compose_beneficiaries(vm_id,project_name,beneficiary_type,beneficiary_id) VALUES(?,?,?,?)", vmID, project, v.BeneficiaryType, v.BeneficiaryID); err != nil {
			respond(w, nil, err)
			return
		}
	}
	if err = tx.Commit(); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "docker.compose.beneficiaries.replace", "docker_compose_project", project, "success", map[string]any{"vm_id": vmID, "count": len(values), "beneficiaries": values})
	jsonResponse(w, http.StatusOK, map[string]any{"project": project, "count": len(values), "status": "ok"})
}
