# Upgrade VM-DOC Server 0.21.26 → 0.21.27

**Nou: migrarea SQL `078_docker_compose_beneficiaries.up.sql`.** Faceți backup MariaDB și testați întâi în staging. Nu este nevoie de agent nou (1.7.18 rămâne).

1. Copiați sursele 0.21.26 în 0.21.27 (păstrați `vendor/`), extrageți arhiva de update peste copie; nu ștergeți configurațiile.
2. Rulați `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și apoi `GOPROXY=off GOFLAGS=-mod=vendor make build`. Nu publicați binarul înainte să treacă.
3. Faceți backup MariaDB; în staging porniți serverul și verificați că migrarea 078 a fost aplicată.
4. În VM → Docker → Proiecte Docker Compose verificați directorul și toate fișierele YAML; butoanele Copiază trebuie să copieze doar calea.
5. Deschideți popup „Configurează beneficiari…”, asociați două departamente/persoane, salvați și verificați beneficiarii calculați pe container/VM/serviciu și în rapoarte. După recrearea containerului, asocierea proiectului trebuie să rămână.
6. Testați filtrele Docker (Stare Docker, resetare, selecție afișată în bară) și listele verticale din Engine și obiecte.
7. După activarea binarului în staging faceți Ctrl+F5 în browser. Dacă totul este corect, programați instalarea în producție.

**Limitări ale verificării în mediul de construire:** testele UI au fost efectuate cu date simulate și API simulat. Nici migrarea MariaDB, nici build-ul complet Go cu `vendor/` nu au fost confirmate local; cereți confirmarea lor înainte de PROD.
