package server

import (
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
)

type primaryServiceRequest struct {
	ServiceName string `json:"service_name"`
	Primary     bool   `json:"primary"`
}

func (a *App) setVMPrimaryService(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input primaryServiceRequest
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Inventory.SetPrimaryAgentService(r.Context(), vmID, user.ID, input.ServiceName, input.Primary); err != nil {
		if a.Logger != nil {
			a.Logger.Error("VM primary agent service could not be updated", "vm_id", vmID, "service_name", input.ServiceName, "primary", input.Primary, "error", err)
		}
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "vm.primary_agent_service.update", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{"service_name": input.ServiceName, "primary": input.Primary})
	jsonResponse(w, http.StatusOK, map[string]any{"vm_id": vmID, "service_name": input.ServiceName, "primary": input.Primary})
}

type agentServicesReviewedRequest struct {
	Reviewed bool `json:"reviewed"`
}

func (a *App) setVMAgentServicesReviewed(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input agentServicesReviewedRequest
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Inventory.SetAgentServicesReviewed(r.Context(), vmID, user.ID, input.Reviewed); err != nil {
		if a.Logger != nil {
			a.Logger.Error("VM agent services review could not be updated", "vm_id", vmID, "reviewed", input.Reviewed, "error", err)
		}
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "vm.agent_services_review.update", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{"reviewed": input.Reviewed})
	jsonResponse(w, http.StatusOK, map[string]any{"vm_id": vmID, "reviewed": input.Reviewed})
}
