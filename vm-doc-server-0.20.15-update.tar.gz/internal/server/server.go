package server

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log/slog"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	swgui "github.com/swaggest/swgui/v5emb"
	"vm-doc-server/internal/agents"
	"vm-doc-server/internal/agentupdates"
	"vm-doc-server/internal/audit"
	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/catalog"
	"vm-doc-server/internal/collection"
	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/database"
	"vm-doc-server/internal/databaseinventory"
	"vm-doc-server/internal/directory"
	"vm-doc-server/internal/dockerinventory"
	"vm-doc-server/internal/documents"
	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/external"
	"vm-doc-server/internal/inventory"
	"vm-doc-server/internal/inventorychanges"
	"vm-doc-server/internal/monitoring"
	"vm-doc-server/internal/nomenclature"
	"vm-doc-server/internal/rbac"
	"vm-doc-server/internal/registration"
	"vm-doc-server/internal/softwareinventory"
	"vm-doc-server/internal/vcenter"
	"vm-doc-server/internal/veeam"
	"vm-doc-server/internal/webinventory"
	"vm-doc-server/internal/xlsx"
	openapifs "vm-doc-server/openapi"
	webfs "vm-doc-server/web"
)

type App struct {
	Config        config.Config
	DB            *sql.DB
	Auth          *auth.Service
	Agents        agents.Service
	AgentUpdates  *agentupdates.Service
	Collection    *collection.Service
	Inventory     inventory.Service
	VCenter       *vcenter.Service
	Veeam         *veeam.Service
	Monitoring    *monitoring.Service
	Nomenclatures nomenclature.Service
	Directory     directory.Service
	Documents     documents.Service
	Catalog       catalog.Service
	Docker        dockerinventory.Service
	Databases     databaseinventory.Service
	Web           webinventory.Service
	Software      softwareinventory.Service
	Changes       inventorychanges.Service
	External      external.Service
	Registration  *registration.Service
	Audit         audit.Service
	Logger        *slog.Logger
	Version       string
}

func (a *App) Handler() (http.Handler, error) {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) { jsonResponse(w, 200, map[string]any{"status": "ok"}) })
	mux.HandleFunc("GET /readyz", a.ready)
	mux.HandleFunc("GET /version", func(w http.ResponseWriter, _ *http.Request) {
		jsonResponse(w, 200, map[string]any{"version": a.Version, "timezone": a.Config.App.Timezone})
	})
	mux.HandleFunc("GET /api/v1/auth/providers", a.Auth.Providers)
	mux.HandleFunc("POST /api/v1/auth/ldap/login", a.Auth.LDAPLogin)
	mux.HandleFunc("GET /api/v1/auth/oidc/start", a.Auth.OIDCStart)
	mux.HandleFunc("GET /api/v1/auth/oidc/callback", a.Auth.OIDCCallback)
	mux.Handle("GET /api/v1/auth/me", a.protected("", http.HandlerFunc(a.Auth.Me)))
	mux.Handle("POST /api/v1/auth/logout", a.protected("", a.Auth.RequireCSRF(http.HandlerFunc(a.Auth.Logout))))

	if a.Registration != nil {
		mux.Handle("POST /api/v1/agent-registration/register", a.agentRegistrationAuth(http.HandlerFunc(a.registerAgent)))
		mux.Handle("POST /api/v1/agent-registration/heartbeat", a.agentRegistrationAuth(http.HandlerFunc(a.agentHeartbeat)))
		mux.Handle("POST /api/v1/agent-registration/inventory", a.agentRegistrationAuth(http.HandlerFunc(a.agentInventoryPush)))
	}
	if a.AgentUpdates != nil {
		mux.Handle("GET /api/v1/agent-updates/latest", a.agentRegistrationAuth(http.HandlerFunc(a.latestAgentUpdate)))
		mux.Handle("GET /api/v1/agent-updates/download/{filename}", a.agentRegistrationAuth(http.HandlerFunc(a.downloadAgentUpdateArtifact)))
		mux.Handle("GET /api/v1/agent-updates/releases", a.protected("agents.read", http.HandlerFunc(a.listAgentUpdateReleases)))
		mux.Handle("GET /api/v1/agent-updates/releases/export", a.protected("agents.read", http.HandlerFunc(a.exportAgentUpdateReleases)))
		mux.Handle("POST /api/v1/agent-updates/releases", a.protectedMutation("agents.manage", http.HandlerFunc(a.publishAgentUpdateRelease)))
		mux.Handle("POST /api/v1/agent-updates/releases/{version}/promote", a.protectedMutation("agents.manage", http.HandlerFunc(a.promoteAgentUpdateRelease)))
		mux.Handle("DELETE /api/v1/agent-updates/releases/{version}", a.protectedMutation("agents.manage", http.HandlerFunc(a.deleteAgentUpdateRelease)))
	}

	mux.Handle("GET /api/v1/dashboard", a.protected("dashboard.read", http.HandlerFunc(a.dashboard)))
	mux.Handle("GET /api/v1/reports/overview", a.protected("reports.read", http.HandlerFunc(a.reportsOverview)))
	mux.Handle("GET /api/v1/agents", a.protected("agents.read", http.HandlerFunc(a.listAgents)))
	mux.Handle("GET /api/v1/agents/export", a.protected("agents.read", http.HandlerFunc(a.exportAgents)))
	mux.Handle("POST /api/v1/agents", a.protectedMutation("agents.manage", http.HandlerFunc(a.createAgent)))
	mux.Handle("GET /api/v1/agents/{id}", a.protected("agents.read", http.HandlerFunc(a.getAgent)))
	mux.Handle("PATCH /api/v1/agents/{id}", a.protectedMutation("agents.manage", http.HandlerFunc(a.updateAgent)))
	mux.Handle("DELETE /api/v1/agents/{id}", a.protectedMutation("agents.manage", http.HandlerFunc(a.deleteAgent)))
	mux.Handle("POST /api/v1/agents/{id}/test", a.protectedMutation("collections.run", http.HandlerFunc(a.queueTest)))
	mux.Handle("POST /api/v1/agents/{id}/collect", a.protectedMutation("collections.run", http.HandlerFunc(a.queueCollect)))
	mux.Handle("POST /api/v1/agents/{id}/update", a.protectedMutation("agents.manage", http.HandlerFunc(a.forceAgentUpdate)))
	mux.Handle("GET /api/v1/agents/{id}/jobs", a.protected("collections.read", http.HandlerFunc(a.agentJobs)))
	mux.Handle("GET /api/v1/jobs/{id}", a.protected("collections.read", http.HandlerFunc(a.getJob)))

	mux.Handle("GET /api/v1/changes", a.protected("inventories.read", http.HandlerFunc(a.listInventoryChanges)))
	mux.Handle("PATCH /api/v1/changes/{id}", a.protectedMutation("vms.manage", http.HandlerFunc(a.updateInventoryChange)))
	mux.Handle("POST /api/v1/changes/backfill", a.protectedMutation("vms.manage", http.HandlerFunc(a.backfillInventoryChanges)))
	mux.Handle("POST /api/v1/changes/baseline", a.protectedMutation("vms.manage", http.HandlerFunc(a.setInventoryChangesBaseline)))
	mux.Handle("GET /api/v1/vms", a.protected("inventories.read", http.HandlerFunc(a.listVMs)))
	mux.Handle("GET /api/v1/vms/export", a.protected("inventories.read", http.HandlerFunc(a.exportVMs)))
	mux.Handle("POST /api/v1/vms/delete-bulk", a.protectedMutation("vms.manage", http.HandlerFunc(a.deleteVMsBulk)))
	mux.Handle("GET /api/v1/vms/{id}", a.protected("inventories.read", http.HandlerFunc(a.getVM)))
	mux.Handle("GET /api/v1/vms/{id}/delete-impact", a.protected("vms.manage", http.HandlerFunc(a.getVMDeleteImpact)))
	mux.Handle("DELETE /api/v1/vms/{id}", a.protectedMutation("vms.manage", http.HandlerFunc(a.deleteVM)))
	mux.Handle("PUT /api/v1/vms/{id}/backup-settings", a.protectedMutation("vms.manage", http.HandlerFunc(a.updateVMBackupSettings)))
	mux.Handle("PATCH /api/v1/vms/{id}", a.protectedMutation("vms.manage", http.HandlerFunc(a.updateVM)))
	mux.Handle("PUT /api/v1/vms/{id}/operational", a.protectedMutation("vms.manage", http.HandlerFunc(a.updateVMOperational)))
	mux.Handle("PUT /api/v1/vms/{id}/service-assignments", a.protectedMutation("vms.manage", http.HandlerFunc(a.replaceVMServiceAssignments)))
	mux.Handle("GET /api/v1/vms/{id}/docker", a.protected("inventories.read", http.HandlerFunc(a.getVMDocker)))
	mux.Handle("PUT /api/v1/vms/{id}/docker/documentation-exempt", a.protectedMutation("vms.manage", http.HandlerFunc(a.setDockerDocumentationExempt)))
	mux.Handle("PUT /api/v1/vms/{id}/docker/containers/{container_id}/documentation-exempt", a.protectedMutation("vms.manage", http.HandlerFunc(a.setDockerContainerDocumentationExempt)))
	mux.Handle("PUT /api/v1/vms/{id}/docker/containers/{container_id}/services", a.protectedMutation("vms.manage", http.HandlerFunc(a.replaceDockerContainerServices)))
	mux.Handle("PUT /api/v1/vms/{id}/docker/compose/{project}/services", a.protectedMutation("vms.manage", http.HandlerFunc(a.assignDockerComposeProject)))
	mux.Handle("GET /api/v1/vms/{id}/databases", a.protected("inventories.read", http.HandlerFunc(a.getVMDatabaseInventory)))
	mux.Handle("PUT /api/v1/vms/{id}/databases/instances/{instance_id}/documentation-exempt", a.protectedMutation("vms.manage", http.HandlerFunc(a.setDatabaseInstanceDocumentationExempt)))
	mux.Handle("PUT /api/v1/vms/{id}/databases/catalogs/{catalog_id}/documentation-exempt", a.protectedMutation("vms.manage", http.HandlerFunc(a.setDatabaseCatalogDocumentationExempt)))
	mux.Handle("PUT /api/v1/vms/{id}/databases/instances/{instance_id}/services", a.protectedMutation("vms.manage", http.HandlerFunc(a.replaceDatabaseInstanceServices)))
	mux.Handle("PUT /api/v1/vms/{id}/databases/catalogs/{catalog_id}/services", a.protectedMutation("vms.manage", http.HandlerFunc(a.replaceDatabaseCatalogServices)))
	mux.Handle("GET /api/v1/vms/{id}/web", a.protected("inventories.read", http.HandlerFunc(a.getVMWebInventory)))
	mux.Handle("GET /api/v1/vms/{id}/software", a.protected("inventories.read", http.HandlerFunc(a.getVMSoftwareInventory)))
	mux.Handle("GET /api/v1/vms/{id}/software/export", a.protected("inventories.read", http.HandlerFunc(a.exportVMSoftware)))
	mux.Handle("POST /api/v1/vms/{id}/software/{software_id}/primary", a.protectedMutation("vms.manage", http.HandlerFunc(a.setVMSoftwarePrimary)))
	mux.Handle("PUT /api/v1/vms/{id}/web/servers/{server_id}/documentation-exempt", a.protectedMutation("vms.manage", http.HandlerFunc(a.setWebServerDocumentationExempt)))
	mux.Handle("PUT /api/v1/vms/{id}/web/sites/{site_id}/documentation-exempt", a.protectedMutation("vms.manage", http.HandlerFunc(a.setWebSiteDocumentationExempt)))
	mux.Handle("PUT /api/v1/vms/{id}/web/sites/{site_id}/services", a.protectedMutation("vms.manage", http.HandlerFunc(a.replaceWebSiteServices)))
	mux.Handle("POST /api/v1/vms/{id}/dependencies", a.protectedMutation("vms.manage", http.HandlerFunc(a.createVMDependency)))
	mux.Handle("DELETE /api/v1/vms/{id}/dependencies/{dependency_id}", a.protectedMutation("vms.manage", http.HandlerFunc(a.deleteVMDependency)))
	mux.Handle("POST /api/v1/vms/{id}/primary-services", a.protectedMutation("vms.manage", http.HandlerFunc(a.setVMPrimaryService)))
	mux.Handle("PUT /api/v1/vms/{id}/agent-services/reviewed", a.protectedMutation("vms.manage", http.HandlerFunc(a.setVMAgentServicesReviewed)))
	mux.Handle("POST /api/v1/vms/{id}/primary-ports", a.protectedMutation("vms.manage", http.HandlerFunc(a.setVMPrimaryPort)))
	mux.Handle("POST /api/v1/vms/{id}/test-agent", a.protectedMutation("collections.run", http.HandlerFunc(a.testVMAgent)))
	mux.Handle("POST /api/v1/vms/{id}/collect", a.protectedMutation("collections.run", http.HandlerFunc(a.collectVM)))
	mux.Handle("GET /api/v1/vms/{id}/inventories", a.protected("inventories.read", http.HandlerFunc(a.inventoryHistory)))
	mux.Handle("GET /api/v1/vms/{id}/documents", a.protected("documents.read", http.HandlerFunc(a.listVMDocuments)))
	mux.Handle("POST /api/v1/vms/{id}/documents/preview", a.protectedMutation("documents.manage", http.HandlerFunc(a.previewVMDocument)))
	mux.Handle("POST /api/v1/vms/{id}/documents", a.protectedMutation("documents.manage", http.HandlerFunc(a.generateVMDocument)))
	mux.Handle("GET /api/v1/documents/{id}/download", a.protected("documents.read", http.HandlerFunc(a.downloadGeneratedDocument)))
	mux.Handle("GET /api/v1/documents/{id}/package", a.protected("documents.read", http.HandlerFunc(a.downloadGeneratedServicePackage)))
	mux.Handle("GET /api/v1/document-templates", a.protected("documents.read", http.HandlerFunc(a.listDocumentTemplates)))
	mux.Handle("POST /api/v1/document-templates", a.protectedMutation("documents.manage", http.HandlerFunc(a.createDocumentTemplate)))
	mux.Handle("PATCH /api/v1/document-templates/{id}", a.protectedMutation("documents.manage", http.HandlerFunc(a.updateDocumentTemplate)))
	mux.Handle("GET /api/v1/document-templates/{id}/download", a.protected("documents.read", http.HandlerFunc(a.downloadDocumentTemplate)))

	mux.Handle("GET /api/v1/vcenter/sources", a.protected("vcenter.read", http.HandlerFunc(a.listVCenterSources)))
	mux.Handle("POST /api/v1/vcenter/sources", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.createVCenterSource)))
	mux.Handle("GET /api/v1/vcenter/sources/{id}", a.protected("vcenter.read", http.HandlerFunc(a.getVCenterSource)))
	mux.Handle("PATCH /api/v1/vcenter/sources/{id}", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.updateVCenterSource)))
	mux.Handle("DELETE /api/v1/vcenter/sources/{id}", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.deleteVCenterSource)))
	mux.Handle("POST /api/v1/vcenter/sources/{id}/test", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.testVCenterSource)))
	mux.Handle("POST /api/v1/vcenter/sources/{id}/sync", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.syncVCenterSource)))
	mux.Handle("POST /api/v1/vcenter/sync", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.syncAllVCenters)))
	mux.Handle("GET /api/v1/vcenter/sync-runs", a.protected("vcenter.read", http.HandlerFunc(a.listVCenterRuns)))

	mux.Handle("GET /api/v1/veeam/summary", a.protected("veeam.read", http.HandlerFunc(a.veeamSummary)))
	mux.Handle("GET /api/v1/veeam/vms", a.protected("veeam.read", http.HandlerFunc(a.listVeeamVMBackups)))
	mux.Handle("GET /api/v1/veeam/vms/export", a.protected("veeam.read", http.HandlerFunc(a.exportVeeamVMBackups)))
	mux.Handle("GET /api/v1/veeam/sources", a.protected("veeam.read", http.HandlerFunc(a.listVeeamSources)))
	mux.Handle("POST /api/v1/veeam/sources", a.protectedMutation("veeam.manage", http.HandlerFunc(a.createVeeamSource)))
	mux.Handle("GET /api/v1/veeam/sources/{id}", a.protected("veeam.read", http.HandlerFunc(a.getVeeamSource)))
	mux.Handle("PATCH /api/v1/veeam/sources/{id}", a.protectedMutation("veeam.manage", http.HandlerFunc(a.updateVeeamSource)))
	mux.Handle("DELETE /api/v1/veeam/sources/{id}", a.protectedMutation("veeam.manage", http.HandlerFunc(a.deleteVeeamSource)))
	mux.Handle("POST /api/v1/veeam/sources/{id}/test", a.protectedMutation("veeam.manage", http.HandlerFunc(a.testVeeamSource)))
	mux.Handle("POST /api/v1/veeam/sources/{id}/sync", a.protectedMutation("veeam.manage", http.HandlerFunc(a.syncVeeamSource)))
	mux.Handle("POST /api/v1/veeam/sync", a.protectedMutation("veeam.manage", http.HandlerFunc(a.syncAllVeeam)))
	mux.Handle("GET /api/v1/veeam/sync-runs", a.protected("veeam.read", http.HandlerFunc(a.listVeeamRuns)))
	mux.Handle("GET /api/v1/monitoring/vms", a.protected("monitoring.read", http.HandlerFunc(a.listMonitoringVMs)))
	mux.Handle("GET /api/v1/monitoring/vms/export", a.protected("monitoring.read", http.HandlerFunc(a.exportMonitoringVMs)))
	mux.Handle("GET /api/v1/monitoring/targets", a.protected("monitoring.read", http.HandlerFunc(a.listMonitoringTargets)))
	mux.Handle("GET /api/v1/monitoring/targets/export", a.protected("monitoring.read", http.HandlerFunc(a.exportMonitoringTargets)))
	mux.Handle("GET /api/v1/monitoring/agent-options", a.protected("monitoring.read", http.HandlerFunc(a.listMonitoringAgentOptions)))
	mux.Handle("GET /api/v1/monitoring/sources", a.protected("monitoring.read", http.HandlerFunc(a.listPrometheusSources)))
	mux.Handle("POST /api/v1/monitoring/sources", a.protectedMutation("monitoring.manage", http.HandlerFunc(a.createPrometheusSource)))
	mux.Handle("GET /api/v1/monitoring/sources/{id}", a.protected("monitoring.read", http.HandlerFunc(a.getPrometheusSource)))
	mux.Handle("PATCH /api/v1/monitoring/sources/{id}", a.protectedMutation("monitoring.manage", http.HandlerFunc(a.updatePrometheusSource)))
	mux.Handle("DELETE /api/v1/monitoring/sources/{id}", a.protectedMutation("monitoring.manage", http.HandlerFunc(a.deletePrometheusSource)))
	mux.Handle("POST /api/v1/monitoring/sources/{id}/test", a.protectedMutation("monitoring.manage", http.HandlerFunc(a.testPrometheusSource)))
	mux.Handle("POST /api/v1/monitoring/sources/{id}/sync", a.protectedMutation("monitoring.manage", http.HandlerFunc(a.syncPrometheusSource)))
	mux.Handle("POST /api/v1/monitoring/sync", a.protectedMutation("monitoring.manage", http.HandlerFunc(a.syncAllPrometheus)))
	mux.Handle("GET /api/v1/monitoring/sync-runs", a.protected("monitoring.read", http.HandlerFunc(a.listPrometheusRuns)))
	mux.Handle("GET /api/v1/vms/{id}/monitoring", a.protected("monitoring.read", http.HandlerFunc(a.getVMMonitoring)))
	mux.Handle("PUT /api/v1/vms/{id}/monitoring/aliases", a.protectedMutation("monitoring.manage", http.HandlerFunc(a.updateVMMonitoringAliases)))
	mux.Handle("GET /api/v1/inventories/{id}", a.protected("inventories.read", http.HandlerFunc(a.getInventory)))
	mux.Handle("GET /api/v1/inventories/{id}/raw", a.protected("inventories.raw.read", http.HandlerFunc(a.getInventoryRaw)))

	mux.Handle("GET /api/v1/services", a.protected("services.read", http.HandlerFunc(a.listInternalServices)))
	mux.Handle("GET /api/v1/services/export", a.protected("services.read", http.HandlerFunc(a.exportInternalServices)))
	mux.Handle("POST /api/v1/services", a.protectedMutation("services.manage", http.HandlerFunc(a.createInternalService)))
	mux.Handle("GET /api/v1/services/{id}", a.protected("services.read", http.HandlerFunc(a.getInternalService)))
	mux.Handle("PATCH /api/v1/services/{id}", a.protectedMutation("services.manage", http.HandlerFunc(a.updateInternalService)))
	mux.Handle("POST /api/v1/services/{id}/dependencies", a.protectedMutation("services.manage", http.HandlerFunc(a.createServiceDependency)))
	mux.Handle("DELETE /api/v1/services/{id}/dependencies/{dependency_id}", a.protectedMutation("services.manage", http.HandlerFunc(a.deleteServiceDependency)))
	mux.Handle("GET /api/v1/services/{id}/documents", a.protected("documents.read", http.HandlerFunc(a.listInternalServiceDocuments)))
	mux.Handle("POST /api/v1/services/{id}/documents/preview", a.protectedMutation("documents.manage", http.HandlerFunc(a.previewInternalServiceDocument)))
	mux.Handle("POST /api/v1/services/{id}/documents", a.protectedMutation("documents.manage", http.HandlerFunc(a.generateInternalServiceDocument)))
	mux.Handle("POST /api/v1/services/{id}/documents/markdown", a.protectedMutation("documents.manage", http.HandlerFunc(a.downloadInternalServiceMarkdown)))
	mux.Handle("GET /api/v1/services/{id}/attachments", a.protected("documents.read", http.HandlerFunc(a.listInternalServiceAttachments)))
	mux.Handle("POST /api/v1/services/{id}/attachments", a.protectedMutation("documents.manage", http.HandlerFunc(a.uploadInternalServiceAttachment)))
	mux.Handle("GET /api/v1/services/{id}/attachments/{attachment_id}", a.protected("documents.read", http.HandlerFunc(a.downloadInternalServiceAttachment)))
	mux.Handle("DELETE /api/v1/services/{id}/attachments/{attachment_id}", a.protectedMutation("documents.manage", http.HandlerFunc(a.deleteInternalServiceAttachment)))

	mux.Handle("GET /api/v1/external-networks", a.protected("external.read", http.HandlerFunc(a.listExternalNetworks)))
	mux.Handle("POST /api/v1/external-networks", a.protectedMutation("external.manage", http.HandlerFunc(a.createExternalNetwork)))
	mux.Handle("GET /api/v1/external-networks/{id}", a.protected("external.read", http.HandlerFunc(a.getExternalNetwork)))
	mux.Handle("PATCH /api/v1/external-networks/{id}", a.protectedMutation("external.manage", http.HandlerFunc(a.updateExternalNetwork)))
	mux.Handle("DELETE /api/v1/external-networks/{id}", a.protectedMutation("external.manage", http.HandlerFunc(a.deleteExternalNetwork)))
	mux.Handle("GET /api/v1/external-systems", a.protected("external.read", http.HandlerFunc(a.listExternalSystems)))
	mux.Handle("POST /api/v1/external-systems", a.protectedMutation("external.manage", http.HandlerFunc(a.createExternalSystem)))
	mux.Handle("GET /api/v1/external-systems/{id}", a.protected("external.read", http.HandlerFunc(a.getExternalSystem)))
	mux.Handle("PATCH /api/v1/external-systems/{id}", a.protectedMutation("external.manage", http.HandlerFunc(a.updateExternalSystem)))
	mux.Handle("DELETE /api/v1/external-systems/{id}", a.protectedMutation("external.manage", http.HandlerFunc(a.deleteExternalSystem)))
	mux.Handle("GET /api/v1/external-connections", a.protected("external.read", http.HandlerFunc(a.listExternalConnections)))
	mux.Handle("POST /api/v1/external-connections", a.protectedMutation("external.manage", http.HandlerFunc(a.createExternalConnection)))
	mux.Handle("PATCH /api/v1/external-connections/{id}", a.protectedMutation("external.manage", http.HandlerFunc(a.updateExternalConnection)))
	mux.Handle("DELETE /api/v1/external-connections/{id}", a.protectedMutation("external.manage", http.HandlerFunc(a.deleteExternalConnection)))

	mux.Handle("GET /api/v1/nomenclatures", a.protected("nomenclatures.read", http.HandlerFunc(a.listNomenclatures)))
	mux.Handle("GET /api/v1/nomenclatures/export", a.protected("nomenclatures.read", http.HandlerFunc(a.exportNomenclatures)))
	mux.Handle("POST /api/v1/nomenclatures/items", a.protectedMutation("nomenclatures.manage", http.HandlerFunc(a.createNomenclatureItem)))
	mux.Handle("PATCH /api/v1/nomenclatures/items/{id}", a.protectedMutation("nomenclatures.manage", http.HandlerFunc(a.updateNomenclatureItem)))
	mux.Handle("GET /api/v1/people", a.protected("nomenclatures.read", http.HandlerFunc(a.listPeople)))
	mux.Handle("POST /api/v1/people", a.protectedMutation("nomenclatures.manage", http.HandlerFunc(a.createPerson)))
	mux.Handle("PATCH /api/v1/people/{id}", a.protectedMutation("nomenclatures.manage", http.HandlerFunc(a.updatePerson)))
	mux.Handle("GET /api/v1/directory/departments", a.protected("nomenclatures.read", http.HandlerFunc(a.directoryDepartments)))
	mux.Handle("GET /api/v1/directory/users", a.protected("nomenclatures.read", http.HandlerFunc(a.directoryUsers)))
	mux.Handle("POST /api/v1/people/import-directory", a.protectedMutation("nomenclatures.manage", http.HandlerFunc(a.importDirectoryPeople)))

	mux.Handle("GET /api/v1/audit/events", a.protected("audit.read", http.HandlerFunc(a.auditEvents)))
	mux.Handle("GET /api/v1/audit/facets", a.protected("audit.read", http.HandlerFunc(a.auditFacets)))
	mux.Handle("GET /api/v1/rbac/roles", a.protected("rbac.manage", http.HandlerFunc(a.roles)))
	mux.Handle("GET /api/v1/rbac/group-mappings", a.protected("rbac.manage", http.HandlerFunc(a.groupMappings)))
	mux.Handle("POST /api/v1/rbac/group-mappings", a.protectedMutation("rbac.manage", http.HandlerFunc(a.createGroupMapping)))
	mux.Handle("DELETE /api/v1/rbac/group-mappings/{id}", a.protectedMutation("rbac.manage", http.HandlerFunc(a.deleteGroupMapping)))

	mux.Handle("GET /api/openapi.yaml", a.protected("", http.HandlerFunc(a.openapi)))
	if a.Config.OpenAPI.Enabled {
		docsPath := "/" + strings.Trim(a.Config.OpenAPI.SwaggerPath, "/")
		docsPrefix := docsPath + "/"
		docs := swgui.New(a.Config.App.Name+" API", "/api/openapi.yaml", docsPath)
		mux.Handle("GET "+docsPrefix, a.protected("", docs))
		mux.Handle("GET "+docsPath, a.protected("", http.RedirectHandler(docsPrefix, http.StatusMovedPermanently)))
	}

	staticRoot, err := fs.Sub(webfs.Static, "static")
	if err != nil {
		return nil, err
	}
	files := http.FileServer(http.FS(staticRoot))
	mux.Handle("GET /static/", http.StripPrefix("/static/", files))
	mux.HandleFunc("GET /login", func(w http.ResponseWriter, r *http.Request) { serveEmbedded(w, staticRoot, "login.html") })
	mux.HandleFunc("GET /", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		serveEmbedded(w, staticRoot, "index.html")
	})

	return a.middleware(a.Auth.Middleware(mux)), nil
}

func (a *App) agentRegistrationAuth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if a.Registration == nil || !a.Registration.Authorized(r.Header.Get("Authorization")) {
			w.Header().Set("WWW-Authenticate", `Bearer realm="vm-doc-agent-registration"`)
			jsonResponse(w, http.StatusUnauthorized, map[string]any{"error": "unauthorized"})
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (a *App) protected(permission string, h http.Handler) http.Handler {
	if permission != "" {
		h = rbac.Require(permission, h)
	}
	return a.Auth.RequireAuth(h)
}

func (a *App) protectedMutation(permission string, h http.Handler) http.Handler {
	return a.protected(permission, a.Auth.RequireCSRF(h))
}

func (a *App) middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		requestID, _ := cryptox.RandomToken(12)
		w.Header().Set("X-Request-ID", requestID)
		r.Header.Set("X-Request-ID", requestID)
		r.Header.Set("X-VM-Doc-Client-IP", resolvedClientIP(r, a.Config.Server.TrustedProxies))
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "same-origin")
		w.Header().Set("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
		scriptPolicy := "script-src 'self'"
		docsPath := "/" + strings.Trim(a.Config.OpenAPI.SwaggerPath, "/")
		if a.Config.OpenAPI.Enabled && (r.URL.Path == docsPath || strings.HasPrefix(r.URL.Path, docsPath+"/")) {
			scriptPolicy += " 'unsafe-inline'"
		}
		w.Header().Set("Content-Security-Policy", "default-src 'self'; "+scriptPolicy+"; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
		if a.Config.App.Environment == "production" {
			w.Header().Set("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
		}
		if strings.HasPrefix(r.URL.Path, "/api/") {
			w.Header().Set("Cache-Control", "no-store")
		}
		defer func() {
			if recovered := recover(); recovered != nil {
				a.Logger.Error("panic recovered", "request_id", requestID, "panic", recovered)
				jsonResponse(w, 500, map[string]any{"error": "internal_error", "request_id": requestID})
			}
			a.Logger.Info("http request", "request_id", requestID, "method", r.Method, "path", r.URL.Path, "duration_ms", time.Since(start).Milliseconds())
		}()
		next.ServeHTTP(w, r)
	})
}

func (a *App) registerAgent(w http.ResponseWriter, r *http.Request) {
	var in registration.RegistrationRequest
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.Registration.Register(r.Context(), in, resolvedClientIP(r, a.Config.Server.TrustedProxies))
	if a.Logger != nil {
		if err != nil {
			a.Logger.Error("agent registration failed", "error", err)
		} else {
			a.Logger.Info("agent registered", "agent_id", result.AgentID, "vm_id", result.VMID, "created", result.Created, "linked", result.Linked)
		}
	}
	respondStatus(w, result, err, http.StatusOK)
}

func (a *App) agentHeartbeat(w http.ResponseWriter, r *http.Request) {
	var in registration.HeartbeatRequest
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.Registration.Heartbeat(r.Context(), in, resolvedClientIP(r, a.Config.Server.TrustedProxies))
	if err != nil && a.Logger != nil {
		a.Logger.Error("agent heartbeat failed", "error", err)
	}
	if err == nil && a.Collection != nil {
		agentID := result.AgentID
		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 6*time.Second)
			defer cancel()
			if _, refreshErr := a.Collection.RefreshAgentUpdateStatus(ctx, agentID, false); refreshErr != nil && a.Logger != nil {
				a.Logger.Debug("refresh auto-registered agent update status", "agent_id", agentID, "error", refreshErr)
			}
		}()
	}
	respond(w, result, err)
}

func (a *App) agentInventoryPush(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()
	limit := a.Config.AgentRegistration.MaxRequestBody
	raw, err := io.ReadAll(io.LimitReader(r.Body, limit+1))
	if err != nil {
		badRequest(w, err)
		return
	}
	if int64(len(raw)) > limit {
		jsonResponse(w, http.StatusRequestEntityTooLarge, map[string]any{"error": "payload_too_large"})
		return
	}
	result, err := a.Registration.SaveInventory(r.Context(), raw)
	if a.Logger != nil {
		if err != nil {
			a.Logger.Error("agent inventory push failed", "error", err, "bytes", len(raw))
		} else {
			a.Logger.Info("agent inventory received", "agent_id", result.AgentID, "inventory_id", result.InventoryID, "vm_id", result.VMID, "linked", result.Linked)
		}
	}
	respondStatus(w, result, err, http.StatusCreated)
}

func (a *App) latestAgentUpdate(w http.ResponseWriter, r *http.Request) {
	result, err := a.AgentUpdates.Latest(r.URL.Query().Get("channel"), r.URL.Query().Get("os"), r.URL.Query().Get("arch"), r.URL.Query().Get("current"))
	respond(w, result, err)
}

func (a *App) downloadAgentUpdateArtifact(w http.ResponseWriter, r *http.Request) {
	file, size, err := a.AgentUpdates.Artifact(r.PathValue("filename"))
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			http.NotFound(w, r)
			return
		}
		badRequest(w, err)
		return
	}
	defer file.Close()
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename=%q`, filepath.Base(r.PathValue("filename"))))
	w.Header().Set("Content-Length", strconv.FormatInt(size, 10))
	w.Header().Set("Cache-Control", "private, no-store")
	w.WriteHeader(http.StatusOK)
	if _, err := io.Copy(w, file); err != nil && a.Logger != nil {
		a.Logger.Warn("agent update download failed", "error", err)
	}
}

func (a *App) listAgentUpdateReleases(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	if query.Get("q") == "" && query.Get("channel") == "" && query.Get("os") == "" && query.Get("arch") == "" && query.Get("validity") == "" && query.Get("page") == "" && query.Get("page_size") == "" {
		releases, err := a.AgentUpdates.List()
		respond(w, releases, err)
		return
	}
	page, pageSize, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	releases, err := a.AgentUpdates.ListPage(query.Get("q"), query.Get("channel"), query.Get("os"), query.Get("arch"), query.Get("validity"), page, pageSize)
	respond(w, releases, err)
}

func (a *App) exportAgentUpdateReleases(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	releases, err := a.AgentUpdates.Filter(query.Get("q"), query.Get("channel"), query.Get("os"), query.Get("arch"), query.Get("validity"))
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := agentReleaseExportRows(releases)
	var output bytes.Buffer
	if err := xlsx.Write(&output, "Release-uri agent", rows); err != nil {
		respond(w, nil, err)
		return
	}
	filename := "agent-releases-" + time.Now().Format("20060102-150405") + ".xlsx"
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
	w.Header().Set("Content-Length", strconv.Itoa(output.Len()))
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(output.Bytes())
}

func (a *App) publishAgentUpdateRelease(w http.ResponseWriter, r *http.Request) {
	const maxUpload = int64(300 << 20)
	r.Body = http.MaxBytesReader(w, r.Body, maxUpload)
	if err := r.ParseMultipartForm(maxUpload); err != nil {
		badRequest(w, fmt.Errorf("invalid multipart upload: %w", err))
		return
	}
	version := strings.TrimSpace(r.FormValue("version"))
	channel := strings.TrimSpace(r.FormValue("channel"))
	osName := strings.TrimSpace(r.FormValue("os"))
	arch := strings.TrimSpace(r.FormValue("arch"))
	notes := strings.TrimSpace(r.FormValue("notes"))
	if version == "" || osName == "" || arch == "" {
		badRequest(w, errors.New("version, os and arch are required"))
		return
	}
	agentPath, agentCleanup, err := saveAgentUpdateUpload(r, "agent")
	if err != nil {
		badRequest(w, err)
		return
	}
	defer agentCleanup()
	updaterPath, updaterCleanup, err := saveAgentUpdateUpload(r, "updater")
	if err != nil {
		badRequest(w, err)
		return
	}
	defer updaterCleanup()
	release, err := a.AgentUpdates.Publish(agentupdates.PublishInput{Version: version, Channel: channel, OS: osName, Arch: arch, AgentPath: agentPath, UpdaterPath: updaterPath, Notes: notes})
	if err == nil {
		a.auditRequest(r, "agent_update.publish", "agent_release", release.Version+":"+release.Channel+":"+release.OS+":"+release.Arch, "success", map[string]any{"version": release.Version, "channel": release.Channel, "os": release.OS, "arch": release.Arch})
	}
	respondStatus(w, release, err, http.StatusCreated)
}

func saveAgentUpdateUpload(r *http.Request, field string) (string, func(), error) {
	file, header, err := r.FormFile(field)
	if err != nil {
		return "", func() {}, fmt.Errorf("%s file is required: %w", field, err)
	}
	defer file.Close()
	if header.Size <= 0 {
		return "", func() {}, fmt.Errorf("%s file is empty", field)
	}
	tmp, err := os.CreateTemp("", "vm-doc-agent-update-*")
	if err != nil {
		return "", func() {}, err
	}
	path := tmp.Name()
	cleanup := func() { _ = os.Remove(path) }
	if _, err := io.Copy(tmp, file); err != nil {
		tmp.Close()
		cleanup()
		return "", func() {}, err
	}
	if err := tmp.Close(); err != nil {
		cleanup()
		return "", func() {}, err
	}
	return path, cleanup, nil
}

func (a *App) promoteAgentUpdateRelease(w http.ResponseWriter, r *http.Request) {
	release, err := a.AgentUpdates.Promote(r.PathValue("version"), r.URL.Query().Get("os"), r.URL.Query().Get("arch"))
	if err == nil {
		a.auditRequest(r, "agent_update.promote", "agent_release", release.Version+":stable:"+release.OS+":"+release.Arch, "success", map[string]any{"version": release.Version, "os": release.OS, "arch": release.Arch})
	}
	respond(w, release, err)
}

func (a *App) deleteAgentUpdateRelease(w http.ResponseWriter, r *http.Request) {
	version := r.PathValue("version")
	channel, osName, arch := r.URL.Query().Get("channel"), r.URL.Query().Get("os"), r.URL.Query().Get("arch")
	err := a.AgentUpdates.Delete(version, channel, osName, arch)
	if err == nil {
		a.auditRequest(r, "agent_update.delete", "agent_release", version+":"+channel+":"+osName+":"+arch, "success", nil)
		w.WriteHeader(http.StatusNoContent)
		return
	}
	if errors.Is(err, os.ErrNotExist) {
		http.NotFound(w, r)
		return
	}
	badRequest(w, err)
}

func (a *App) ready(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 2*time.Second)
	defer cancel()
	if err := a.DB.PingContext(ctx); err != nil {
		a.Logger.Error("readiness database check failed", "error", err)
		jsonResponse(w, 503, map[string]any{"status": "not_ready", "database": "unavailable"})
		return
	}
	jsonResponse(w, 200, map[string]any{"status": "ready"})
}

func (a *App) dashboard(w http.ResponseWriter, r *http.Request) {
	var agentsTotal, agentsOnline, vms, jobsQueued int
	_ = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM agents`).Scan(&agentsTotal)
	_ = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM agents WHERE enabled=1 AND last_contact_at IS NOT NULL AND TIMESTAMPDIFF(SECOND,last_contact_at,UTC_TIMESTAMP())<=offline_after_seconds`).Scan(&agentsOnline)
	_ = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM virtual_machines`).Scan(&vms)
	_ = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM collection_jobs WHERE status IN ('queued','running')`).Scan(&jobsQueued)
	jsonResponse(w, 200, map[string]any{"agents_total": agentsTotal, "agents_online": agentsOnline, "vms": vms, "jobs_pending": jobsQueued})
}

func (a *App) listAgents(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	if query.Get("q") == "" && query.Get("status") == "" && query.Get("channel") == "" && query.Get("page") == "" && query.Get("page_size") == "" {
		v, err := a.Agents.List(r.Context())
		respond(w, v, err)
		return
	}
	page, pageSize, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Agents.ListPage(r.Context(), query.Get("q"), query.Get("status"), query.Get("channel"), page, pageSize)
	respond(w, v, err)
}
func (a *App) exportAgents(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	page, err := a.Agents.ListPage(r.Context(), query.Get("q"), query.Get("status"), query.Get("channel"), 1, 1000000)
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := agentExportRows(page.Items)
	var output bytes.Buffer
	if err := xlsx.Write(&output, "Agenți", rows); err != nil {
		respond(w, nil, err)
		return
	}
	filename := "agents-" + time.Now().Format("20060102-150405") + ".xlsx"
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
	w.Header().Set("Content-Length", strconv.Itoa(output.Len()))
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(output.Bytes())
}

func (a *App) getAgent(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Agents.Get(r.Context(), id)
	respond(w, v, err)
}
func (a *App) createAgent(w http.ResponseWriter, r *http.Request) {
	var in agents.Input
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.Agents.Create(r.Context(), in, u.ID)
	if err == nil {
		a.auditRequest(r, "agent.create", "agent", strconv.FormatInt(v.ID, 10), "success", map[string]any{"created": v})
	}
	respondStatus(w, v, err, 201)
}
func (a *App) updateAgent(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in agents.Input
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.Agents.Get(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.Agents.Update(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "agent.update", "agent", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": v})
	}
	respond(w, v, err)
}
func (a *App) deleteAgent(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.Agents.Get(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	err = a.Agents.Delete(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "agent.delete", "agent", strconv.FormatInt(id, 10), "success", map[string]any{"deleted": before})
		w.WriteHeader(204)
		return
	}
	respond(w, nil, err)
}
func (a *App) queueTest(w http.ResponseWriter, r *http.Request)    { a.queueJob(w, r, "test") }
func (a *App) queueCollect(w http.ResponseWriter, r *http.Request) { a.queueJob(w, r, "collect") }

func (a *App) forceAgentUpdate(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, _ := a.Agents.Get(r.Context(), id)
	status, err := a.Collection.ForceAgentUpdate(r.Context(), id)
	details := map[string]any{"channel": status.Channel, "state": status.State, "current_version": status.CurrentVersion, "available_version": status.AvailableVersion, "enabled": status.Enabled}
	if err != nil {
		details["error"] = err.Error()
		a.auditRequest(r, "agent.update.force", "agent", strconv.FormatInt(id, 10), "failure", details)
		jsonResponse(w, http.StatusBadGateway, map[string]any{"error": err.Error(), "update": status})
		return
	}
	if before.Update.Channel != "" {
		details["previous_channel"] = before.Update.Channel
	}
	a.auditRequest(r, "agent.update.force", "agent", strconv.FormatInt(id, 10), "success", details)
	respond(w, status, nil)
}
func (a *App) queueJob(w http.ResponseWriter, r *http.Request, kind string) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	job, err := a.Collection.Queue(r.Context(), id, kind, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "collection.queue", "agent", strconv.FormatInt(id, 10), "success", map[string]any{"job_id": job.ID, "kind": kind})
	}
	respondStatus(w, job, err, 202)
}
func (a *App) agentJobs(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Collection.ListForAgent(r.Context(), id, 100)
	respond(w, v, err)
}
func (a *App) getJob(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Collection.Get(r.Context(), id)
	respond(w, v, err)
}
func (a *App) listVMs(w http.ResponseWriter, r *http.Request) {
	filter, err := vmFilterFromRequest(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.VCenter.ListVMs(r.Context(), filter)
	respond(w, v, err)
}

func (a *App) getVMDeleteImpact(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.VCenter.GetVMDeleteImpact(r.Context(), id)
	respond(w, value, err)
}

func (a *App) deleteVM(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.VCenter.DeleteVM(r.Context(), id)
	if errors.Is(err, vcenter.ErrVMPresentInVCenter) {
		jsonResponse(w, http.StatusConflict, map[string]any{"error": "vm_present_in_vcenter", "message": err.Error()})
		return
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "vm.delete.permanent", "virtual_machine", strconv.FormatInt(id, 10), "success", map[string]any{"deleted": value})
	jsonResponse(w, http.StatusOK, value)
}

func (a *App) deleteVMsBulk(w http.ResponseWriter, r *http.Request) {
	var input struct {
		IDs []int64 `json:"ids"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.VCenter.DeleteVMs(r.Context(), input.IDs)
	if errors.Is(err, vcenter.ErrVMPresentInVCenter) {
		jsonResponse(w, http.StatusConflict, map[string]any{"error": "vm_present_in_vcenter", "message": err.Error()})
		return
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	for _, value := range result.Deleted {
		a.auditRequest(r, "vm.delete.permanent", "virtual_machine", strconv.FormatInt(value.ID, 10), "success", map[string]any{"deleted": value, "bulk": true})
	}
	jsonResponse(w, http.StatusOK, result)
}

func (a *App) exportVMs(w http.ResponseWriter, r *http.Request) {
	filter, err := vmFilterFromRequest(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	vms, err := a.VCenter.ExportVMs(r.Context(), filter)
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := vmExportRows(vms)
	var output bytes.Buffer
	if err := xlsx.Write(&output, "VM-uri", rows); err != nil {
		respond(w, nil, err)
		return
	}
	filename := "vm-inventory-" + time.Now().Format("20060102-150405") + ".xlsx"
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
	w.Header().Set("Content-Length", strconv.Itoa(output.Len()))
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(output.Bytes())
}

func vmFilterFromRequest(r *http.Request) (vcenter.VMFilter, error) {
	query := r.URL.Query()
	filter := vcenter.VMFilter{
		Query:    query.Get("q"),
		Power:    query.Get("power"),
		Agent:    query.Get("agent"),
		Retired:  query.Get("retired"),
		Presence: query.Get("presence"),
		Baseline: query.Get("baseline"),
	}
	var err error
	if value := query.Get("source_id"); value != "" {
		filter.SourceID, err = strconv.ParseInt(value, 10, 64)
		if err != nil || filter.SourceID < 1 {
			return filter, errors.New("invalid source_id")
		}
	}
	if value := query.Get("service_id"); value != "" {
		filter.ServiceID, err = strconv.ParseInt(value, 10, 64)
		if err != nil || filter.ServiceID < 1 {
			return filter, errors.New("invalid service_id")
		}
	}
	if value := query.Get("page"); value != "" {
		filter.Page, err = strconv.Atoi(value)
		if err != nil || filter.Page < 1 {
			return filter, errors.New("invalid page")
		}
	}
	if value := query.Get("page_size"); value != "" {
		filter.PageSize, err = strconv.Atoi(value)
		if err != nil || filter.PageSize < 1 {
			return filter, errors.New("invalid page_size")
		}
	}
	return filter, nil
}

func paginationFromRequest(r *http.Request, defaultPageSize, maxPageSize int) (int, int, error) {
	page := 1
	pageSize := defaultPageSize
	query := r.URL.Query()
	if value := query.Get("page"); value != "" {
		parsed, err := strconv.Atoi(value)
		if err != nil || parsed < 1 {
			return 0, 0, errors.New("invalid page")
		}
		page = parsed
	}
	if value := query.Get("page_size"); value != "" {
		parsed, err := strconv.Atoi(value)
		if err != nil || parsed < 1 {
			return 0, 0, errors.New("invalid page_size")
		}
		pageSize = parsed
	}
	if pageSize > maxPageSize {
		pageSize = maxPageSize
	}
	return page, pageSize, nil
}

func agentExportRows(values []domain.Agent) [][]xlsx.Cell {
	headers := []string{"Agent", "Status", "IP management", "IP sursă register/heartbeat", "OS raportat", "Versiune OS", "Versiune agent", "Canal update", "Update activ", "Auto install", "Stare update", "Versiune disponibilă", "Ultima verificare update", "Status update citit la", "Ultima eroare update", "UUID", "URL", "Activ", "Ultimul contact", "Ultima colectare reușită", "Ultima încercare", "Următoarea colectare", "Interval colectare (s)", "Timeout (s)", "Offline după (s)", "Ultima eroare"}
	rows := make([][]xlsx.Cell, 0, len(values)+1)
	header := make([]xlsx.Cell, 0, len(headers))
	for _, value := range headers {
		header = append(header, xlsx.Text(value))
	}
	rows = append(rows, header)
	for _, value := range values {
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(value.Name), xlsx.Text(value.Status), xlsx.Text(value.ManagementIP), xlsx.Text(value.RegistrationIP), xlsx.Text(value.OSName), xlsx.Text(value.OSVersion), xlsx.Text(value.AgentVersion), xlsx.Text(value.Update.Channel), xlsx.Text(knownYesNo(value.Update.Known, value.Update.Enabled)), xlsx.Text(knownYesNo(value.Update.Known, value.Update.AutoInstall)), xlsx.Text(value.Update.State), xlsx.Text(value.Update.AvailableVersion), xlsx.Text(exportTime(value.Update.LastCheckAt)), xlsx.Text(exportTime(value.Update.CheckedAt)), xlsx.Text(value.Update.LastError), xlsx.Text(value.AgentUUID), xlsx.Text(value.BaseURL), xlsx.Text(yesNo(value.Enabled)),
			xlsx.Text(exportTime(value.LastContactAt)), xlsx.Text(exportTime(value.LastSuccessAt)), xlsx.Text(exportTime(value.LastAttemptAt)), xlsx.Text(exportTime(value.NextCollectionAt)),
			xlsx.Number(float64(value.CollectionIntervalSeconds)), xlsx.Number(float64(value.RequestTimeoutSeconds)), xlsx.Number(float64(value.OfflineAfterSeconds)), xlsx.Text(value.LastError),
		})
	}
	return rows
}

func agentReleaseExportRows(values []agentupdates.ReleaseStatus) [][]xlsx.Cell {
	headers := []string{"Versiune", "Canal", "OS", "Arhitectură", "Repository", "Publicat", "Note", "Fișier agent", "SHA256 agent", "Dimensiune agent", "Fișier updater", "SHA256 updater", "Dimensiune updater"}
	rows := make([][]xlsx.Cell, 0, len(values)+1)
	header := make([]xlsx.Cell, 0, len(headers))
	for _, value := range headers {
		header = append(header, xlsx.Text(value))
	}
	rows = append(rows, header)
	for _, value := range values {
		repositoryStatus := "Invalid"
		if value.Valid {
			repositoryStatus = "Ready"
		}
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(value.Version), xlsx.Text(value.Channel), xlsx.Text(value.OS), xlsx.Text(value.Arch), xlsx.Text(repositoryStatus), xlsx.Text(value.PublishedAt.UTC().Format(time.RFC3339)), xlsx.Text(value.Notes),
			xlsx.Text(value.AgentFilename), xlsx.Text(value.AgentSHA256), xlsx.Number(float64(value.AgentSizeBytes)), xlsx.Text(value.UpdaterFilename), xlsx.Text(value.UpdaterSHA256), xlsx.Number(float64(value.UpdaterSizeBytes)),
		})
	}
	return rows
}

func vmExportRows(vms []domain.VirtualMachine) [][]xlsx.Cell {
	headers := []string{
		"Nume VM", "Sursă vCenter", "Power", "CPU", "RAM MiB", "OS", "Versiune OS", "Hostname", "IP",
		"Agent", "Versiune agent", "Stare agent", "Servicii asociate", "Ultimul contact agent", "Ultimul JSON", "Completare documentație %", "Baseline", "Prezentă în vCenter",
		"MoID", "Instance UUID", "BIOS UUID", "Ultima sincronizare vCenter",
	}
	rows := make([][]xlsx.Cell, 0, len(vms)+1)
	headerRow := make([]xlsx.Cell, 0, len(headers))
	for _, header := range headers {
		headerRow = append(headerRow, xlsx.Text(header))
	}
	rows = append(rows, headerRow)
	for _, vm := range vms {
		osName := vm.InventoryOSName
		if osName == "" {
			osName = vm.GuestOS
		}
		hostname := vm.InventoryHostname
		if hostname == "" {
			hostname = vm.GuestHostname
		}
		ip := vm.InventoryPrimaryIP
		if ip == "" {
			ip = vm.PrimaryIP
		}
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(vm.Name), xlsx.Text(vm.VCenterSourceName), xlsx.Text(vm.PowerState), xlsx.Number(float64(vm.CPUCount)), xlsx.Number(float64(vm.MemoryMiB)),
			xlsx.Text(osName), xlsx.Text(vm.InventoryOSVersion), xlsx.Text(hostname), xlsx.Text(ip), xlsx.Text(vm.AgentName), xlsx.Text(vm.AgentVersion), xlsx.Text(vm.AgentStatus), xlsx.Text(strings.Join(vm.ServiceNames, ", ")),
			xlsx.Text(exportTime(vm.AgentLastContactAt)), xlsx.Text(exportTime(vm.InventoryReceivedAt)), xlsx.Number(float64(vm.CompletionPercent)), xlsx.Text(yesNo(vm.BaselineEstablished)), xlsx.Text(yesNo(vm.PresentInVCenter)),
			xlsx.Text(vm.VCenterMoID), xlsx.Text(vm.InstanceUUID), xlsx.Text(vm.BIOSUUID), xlsx.Text(exportTime(vm.LastVCenterSyncAt)),
		})
	}
	return rows
}

func exportTime(value *time.Time) string {
	if value == nil {
		return ""
	}
	return value.Format(time.RFC3339)
}

func knownYesNo(known, value bool) string {
	if !known {
		return ""
	}
	return yesNo(value)
}

func yesNo(value bool) string {
	if value {
		return "Da"
	}
	return "Nu"
}
func (a *App) getVM(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}

	warnings := make([]string, 0)
	vm, err := a.VCenter.GetVM(r.Context(), id)
	if err != nil {
		a.logVMDetailError("vm", id, err)
		respond(w, nil, err)
		return
	}

	operational := domain.VMOperationalMetadata{VMID: id, Responsibilities: make([]domain.VMResponsibility, 0)}
	if value, operationalErr := a.VCenter.GetOperationalMetadata(r.Context(), id); operationalErr != nil {
		a.logVMDetailError("operational", id, operationalErr)
		warnings = append(warnings, "operational_data_unavailable")
	} else {
		operational = value
	}

	backup := domain.VMBackupSummary{VMID: id, Provider: "veeam"}
	if value, backupErr := a.VCenter.GetBackupSummary(r.Context(), id); backupErr != nil {
		a.logVMDetailError("backup", id, backupErr)
		warnings = append(warnings, "backup_data_unavailable")
	} else {
		backup = value
	}

	var agent any
	var inv any
	var documentView any
	var inventoryRaw []byte
	if vm.AgentID != nil {
		agentValue, agentErr := a.Agents.Get(r.Context(), *vm.AgentID)
		if agentErr != nil {
			a.logVMDetailError("agent", id, agentErr)
			warnings = append(warnings, "agent_data_unavailable")
		} else {
			agent = agentValue
		}
	}
	if vm.CurrentInventoryID != nil {
		inventoryValue, inventoryErr := a.Inventory.Get(r.Context(), *vm.CurrentInventoryID, true)
		if inventoryErr != nil {
			a.logVMDetailError("inventory", id, inventoryErr)
			warnings = append(warnings, "inventory_data_unavailable")
		} else {
			inventoryRaw = append([]byte(nil), inventoryValue.RawJSON...)
			documentValue, documentErr := inventory.BuildDocumentView(inventoryValue.RawJSON)
			inventoryValue.RawJSON = nil
			inv = inventoryValue
			if documentErr != nil {
				a.logVMDetailError("inventory_document", id, documentErr)
				warnings = append(warnings, "inventory_document_unavailable")
			} else {
				documentView = documentValue
			}
		}
	}
	primaryServices := make([]domain.PrimaryAgentService, 0)
	primaryPorts := make([]domain.PrimaryAgentPort, 0)
	agentServicesReviewed := false
	if a.Inventory.DB != nil {
		if values, primaryErr := a.Inventory.ListPrimaryAgentServices(r.Context(), id, inventoryRaw); primaryErr != nil {
			a.logVMDetailError("primary_agent_services", id, primaryErr)
			warnings = append(warnings, "primary_agent_services_unavailable")
		} else {
			primaryServices = values
		}
		if values, primaryErr := a.Inventory.ListPrimaryAgentPorts(r.Context(), id, inventoryRaw); primaryErr != nil {
			a.logVMDetailError("primary_agent_ports", id, primaryErr)
			warnings = append(warnings, "primary_agent_ports_unavailable")
		} else {
			primaryPorts = values
		}
		if reviewed, reviewErr := a.Inventory.AgentServicesReviewed(r.Context(), id); reviewErr != nil {
			a.logVMDetailError("agent_services_review", id, reviewErr)
			warnings = append(warnings, "agent_services_review_unavailable")
		} else {
			agentServicesReviewed = reviewed
		}
	}

	commonDependencies := make([]domain.ServiceDependency, 0)
	if a.Catalog.DB != nil {
		if values, dependencyErr := a.Catalog.ListVMDependencies(r.Context(), id); dependencyErr != nil {
			a.logVMDetailError("common_dependencies", id, dependencyErr)
			warnings = append(warnings, "common_dependencies_unavailable")
		} else {
			commonDependencies = values
		}
	}
	var backupDetails any
	if len(backup.RawJSON) > 0 {
		if err := json.Unmarshal(backup.RawJSON, &backupDetails); err != nil {
			a.logVMDetailError("backup_raw", id, err)
			warnings = append(warnings, "backup_details_unavailable")
		}
	}
	ips, ipErr := a.VCenter.ListVMIPs(r.Context(), id)
	if ipErr != nil {
		a.logVMDetailError("ip_addresses", id, ipErr)
		warnings = append(warnings, "ip_addresses_unavailable")
	}
	if operational.PreferredIP != "" {
		vm.PrimaryIP = operational.PreferredIP
	}
	jsonResponse(w, http.StatusOK, map[string]any{
		"vm":                      vm,
		"ip_addresses":            ips,
		"agent":                   agent,
		"inventory":               inv,
		"inventory_document":      documentView,
		"operational":             operational,
		"backup":                  backup,
		"backup_details":          backupDetails,
		"common_dependencies":     commonDependencies,
		"primary_agent_services":  primaryServices,
		"primary_agent_ports":     primaryPorts,
		"agent_services_reviewed": agentServicesReviewed,
		"warnings":                warnings,
	})
}

func (a *App) logVMDetailError(stage string, vmID int64, err error) {
	if a.Logger == nil {
		return
	}
	a.Logger.Error("VM detail optional data could not be loaded", "stage", stage, "vm_id", vmID, "error", err)
}

func (a *App) updateVMOperational(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input vcenter.OperationalMetadataInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.VCenter.GetOperationalMetadata(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.VCenter.SaveOperationalMetadata(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "vm.operational.update", "virtual_machine", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": value})
	}
	respond(w, value, err)
}

func (a *App) replaceVMServiceAssignments(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input struct {
		Assignments []vcenter.ServiceAssignmentInput `json:"assignments"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	values, err := a.VCenter.ReplaceVMServiceAssignments(r.Context(), id, user.ID, input.Assignments)
	if err == nil {
		a.auditRequest(r, "vm.service_assignments.replace", "virtual_machine", strconv.FormatInt(id, 10), "success", map[string]any{"count": len(values)})
	}
	respond(w, values, err)
}
func (a *App) updateVM(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in vcenter.VMUpdate
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.VCenter.GetVM(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	vm, err := a.VCenter.UpdateVM(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "vm.update", "virtual_machine", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": vm})
	}
	respond(w, vm, err)
}
func (a *App) testVMAgent(w http.ResponseWriter, r *http.Request) { a.queueVMJob(w, r, "test") }
func (a *App) collectVM(w http.ResponseWriter, r *http.Request)   { a.queueVMJob(w, r, "collect") }
func (a *App) queueVMJob(w http.ResponseWriter, r *http.Request, kind string) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	vm, err := a.VCenter.GetVM(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if vm.AgentID == nil {
		badRequest(w, errors.New("VM does not have an associated agent"))
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	job, err := a.Collection.Queue(r.Context(), *vm.AgentID, kind, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "collection.queue", "virtual_machine", strconv.FormatInt(id, 10), "success", map[string]any{"job_id": job.ID, "kind": kind, "agent_id": *vm.AgentID})
	}
	respondStatus(w, job, err, http.StatusAccepted)
}
func (a *App) inventoryHistory(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	page, pageSize, err := paginationFromRequest(r, 10, 100)
	if err != nil {
		badRequest(w, err)
		return
	}
	vm, err := a.VCenter.GetVM(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if vm.AgentID == nil {
		jsonResponse(w, http.StatusOK, inventory.HistoryPage{Items: make([]domain.Inventory, 0), Page: page, PageSize: pageSize})
		return
	}
	v, err := a.Inventory.History(r.Context(), *vm.AgentID, page, pageSize)
	respond(w, v, err)
}

func (a *App) listVCenterSources(w http.ResponseWriter, r *http.Request) {
	v, err := a.VCenter.ListSources(r.Context())
	respond(w, v, err)
}
func (a *App) getVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.VCenter.GetSource(r.Context(), id)
	respond(w, v, err)
}
func (a *App) createVCenterSource(w http.ResponseWriter, r *http.Request) {
	var in vcenter.SourceInput
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.VCenter.CreateSource(r.Context(), in, u.ID)
	if err == nil {
		a.auditRequest(r, "vcenter.source.create", "vcenter_source", strconv.FormatInt(v.ID, 10), "success", map[string]any{"name": v.Name})
	}
	respondStatus(w, v, err, http.StatusCreated)
}
func (a *App) updateVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in vcenter.SourceInput
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.VCenter.UpdateSource(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "vcenter.source.update", "vcenter_source", strconv.FormatInt(id, 10), "success", map[string]any{"name": v.Name})
	}
	respond(w, v, err)
}
func (a *App) deleteVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	err = a.VCenter.DeleteSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "vcenter.source.delete", "vcenter_source", strconv.FormatInt(id, 10), "success", nil)
		w.WriteHeader(http.StatusNoContent)
		return
	}
	respond(w, nil, err)
}
func (a *App) testVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.VCenter.TestSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "vcenter.source.test", "vcenter_source", strconv.FormatInt(id, 10), "success", v)
	}
	respond(w, v, err)
}
func (a *App) syncVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	run, err := a.VCenter.StartSync(r.Context(), id, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "vcenter.sync.queue", "vcenter_source", strconv.FormatInt(id, 10), "success", map[string]any{"run_id": run.ID})
	}
	respondStatus(w, run, err, http.StatusAccepted)
}
func (a *App) syncAllVCenters(w http.ResponseWriter, r *http.Request) {
	u, _ := auth.UserFromContext(r.Context())
	runs, err := a.VCenter.StartAll(r.Context(), &u.ID)
	if err == nil {
		a.auditRequest(r, "vcenter.sync.queue_all", "vcenter", "all", "success", map[string]any{"runs": len(runs)})
	}
	respondStatus(w, runs, err, http.StatusAccepted)
}
func (a *App) listVCenterRuns(w http.ResponseWriter, r *http.Request) {
	page, pageSize, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.VCenter.ListRunsPage(r.Context(), page, pageSize)
	respond(w, v, err)
}
func (a *App) getInventory(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Inventory.Get(r.Context(), id, false)
	respond(w, v, err)
}
func (a *App) getInventoryRaw(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Inventory.Get(r.Context(), id, true)
	if err != nil {
		respond(w, nil, err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(200)
	_, _ = w.Write(v.RawJSON)
}
func (a *App) auditEvents(w http.ResponseWriter, r *http.Request) {
	page, pageSize, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	query := r.URL.Query()
	from, err := auditDate(query.Get("from"), false)
	if err != nil {
		badRequest(w, err)
		return
	}
	to, err := auditDate(query.Get("to"), true)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Audit.ListFiltered(r.Context(), audit.Filter{
		Page: page, PageSize: pageSize, Query: query.Get("q"), Source: query.Get("source"),
		Actor: query.Get("actor"), Action: query.Get("action"), ResourceType: query.Get("resource_type"),
		Outcome: query.Get("outcome"), From: from, To: to,
	})
	respond(w, v, err)
}

func (a *App) auditFacets(w http.ResponseWriter, r *http.Request) {
	v, err := a.Audit.Facets(r.Context())
	respond(w, v, err)
}

func auditDate(value string, endExclusive bool) (*time.Time, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return nil, nil
	}
	if parsed, err := time.Parse(time.RFC3339, value); err == nil {
		return &parsed, nil
	}
	parsed, err := time.Parse("2006-01-02", value)
	if err != nil {
		return nil, errors.New("audit date must be YYYY-MM-DD or RFC3339")
	}
	if endExclusive {
		parsed = parsed.AddDate(0, 0, 1)
	}
	return &parsed, nil
}

func (a *App) roles(w http.ResponseWriter, r *http.Request) {
	rows, err := a.DB.QueryContext(r.Context(), `SELECT id,name,description FROM roles ORDER BY name`)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer rows.Close()
	out := make([]map[string]any, 0)
	for rows.Next() {
		var id int64
		var name, desc string
		if err := rows.Scan(&id, &name, &desc); err != nil {
			respond(w, nil, err)
			return
		}
		out = append(out, map[string]any{"id": id, "name": name, "description": desc})
	}
	jsonResponse(w, 200, out)
}
func (a *App) groupMappings(w http.ResponseWriter, r *http.Request) {
	rows, err := a.DB.QueryContext(r.Context(), `SELECT gm.id,gm.provider,gm.group_name,r.name FROM group_role_mappings gm JOIN roles r ON r.id=gm.role_id ORDER BY gm.provider,gm.group_name`)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer rows.Close()
	out := make([]map[string]any, 0)
	for rows.Next() {
		var id int64
		var provider, group, role string
		if err := rows.Scan(&id, &provider, &group, &role); err != nil {
			respond(w, nil, err)
			return
		}
		out = append(out, map[string]any{"id": id, "provider": provider, "group_name": group, "role": role})
	}
	jsonResponse(w, 200, out)
}
func (a *App) createGroupMapping(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Provider  string `json:"provider"`
		GroupName string `json:"group_name"`
		Role      string `json:"role"`
	}
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	in.Provider = strings.ToLower(strings.TrimSpace(in.Provider))
	in.GroupName = strings.TrimSpace(in.GroupName)
	in.Role = strings.ToLower(strings.TrimSpace(in.Role))
	if in.Provider != "ldap" && in.Provider != "oidc" && in.Provider != "any" {
		badRequest(w, errors.New("provider must be ldap, oidc or any"))
		return
	}
	if in.GroupName == "" || in.Role == "" {
		badRequest(w, errors.New("group_name and role are required"))
		return
	}
	res, err := a.DB.ExecContext(r.Context(), `INSERT INTO group_role_mappings(provider,group_name,role_id) SELECT ?,?,id FROM roles WHERE name=?`, in.Provider, in.GroupName, in.Role)
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows, err := res.RowsAffected()
	if err != nil {
		respond(w, nil, err)
		return
	}
	if rows == 0 {
		badRequest(w, errors.New("invalid role"))
		return
	}
	id, _ := res.LastInsertId()
	a.auditRequest(r, "rbac.mapping.create", "group_role_mapping", strconv.FormatInt(id, 10), "success", in)
	jsonResponse(w, 201, map[string]any{"id": id})
}
func (a *App) deleteGroupMapping(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	res, err := a.DB.ExecContext(r.Context(), `DELETE FROM group_role_mappings WHERE id=?`, id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		respond(w, nil, sql.ErrNoRows)
		return
	}
	a.auditRequest(r, "rbac.mapping.delete", "group_role_mapping", strconv.FormatInt(id, 10), "success", nil)
	w.WriteHeader(204)
}

func includeInactive(r *http.Request) bool {
	value := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("include_inactive")))
	return value == "1" || value == "true" || value == "yes"
}

func (a *App) listInternalServices(w http.ResponseWriter, r *http.Request) {
	values, err := a.Catalog.List(r.Context(), includeInactive(r))
	respond(w, values, err)
}

func (a *App) getInternalService(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Catalog.Get(r.Context(), id)
	if err == nil && a.Docker.DB != nil {
		value.DockerContainers, err = a.Docker.ListForService(r.Context(), id)
	}
	if err == nil && a.Databases.DB != nil {
		value.DatabaseResources, err = a.Databases.ListForService(r.Context(), id)
	}
	if err == nil && a.Web.DB != nil {
		value.WebSites, err = a.Web.ListForService(r.Context(), id)
	}
	respond(w, value, err)
}

func (a *App) createInternalService(w http.ResponseWriter, r *http.Request) {
	var input catalog.InternalServiceInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Catalog.Create(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "internal_service.create", "internal_service", strconv.FormatInt(value.ID, 10), "success", map[string]any{"created": value})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updateInternalService(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input catalog.InternalServiceInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.Catalog.Get(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Catalog.Update(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "internal_service.update", "internal_service", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": value})
	}
	respond(w, value, err)
}

func (a *App) createVMDependency(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input catalog.VMDependencyInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Catalog.AddVMDependency(r.Context(), vmID, user.ID, input)
	if err == nil {
		a.auditRequest(r, "vm.dependency.create", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{"target_service_id": input.TargetServiceID, "dependency_type_id": input.DependencyTypeID})
	} else if a.Logger != nil {
		a.Logger.Error("VM common dependency could not be created", "vm_id", vmID, "target_service_id", input.TargetServiceID, "dependency_type_id", input.DependencyTypeID, "error", err)
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) deleteVMDependency(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	dependencyID, err := strconv.ParseInt(r.PathValue("dependency_id"), 10, 64)
	if err != nil || dependencyID <= 0 {
		badRequest(w, errors.New("invalid dependency id"))
		return
	}
	err = a.Catalog.DeleteVMDependency(r.Context(), vmID, dependencyID)
	if err == nil {
		a.auditRequest(r, "vm.dependency.delete", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{"dependency_id": dependencyID})
		w.WriteHeader(http.StatusNoContent)
		return
	}
	respond(w, nil, err)
}

func (a *App) createServiceDependency(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input catalog.DependencyInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Catalog.AddDependency(r.Context(), serviceID, user.ID, input)
	if err == nil {
		a.auditRequest(r, "service.dependency.create", "internal_service", strconv.FormatInt(serviceID, 10), "success", map[string]any{"target_service_id": input.TargetServiceID, "dependency_type_id": input.DependencyTypeID})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) deleteServiceDependency(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	dependencyID, err := strconv.ParseInt(r.PathValue("dependency_id"), 10, 64)
	if err != nil || dependencyID <= 0 {
		badRequest(w, errors.New("invalid dependency id"))
		return
	}
	err = a.Catalog.DeleteDependency(r.Context(), serviceID, dependencyID)
	if err == nil {
		a.auditRequest(r, "service.dependency.delete", "internal_service", strconv.FormatInt(serviceID, 10), "success", map[string]any{"dependency_id": dependencyID})
		w.WriteHeader(http.StatusNoContent)
		return
	}
	respond(w, nil, err)
}

func (a *App) listNomenclatures(w http.ResponseWriter, r *http.Request) {
	values, err := a.Nomenclatures.ListCategories(r.Context(), includeInactive(r))
	respond(w, values, err)
}

func (a *App) createNomenclatureItem(w http.ResponseWriter, r *http.Request) {
	var input nomenclature.ItemInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Nomenclatures.CreateItem(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "nomenclature.item.create", "nomenclature_item", strconv.FormatInt(value.ID, 10), "success", map[string]any{"created": value})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updateNomenclatureItem(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input nomenclature.ItemInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.Nomenclatures.GetItem(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Nomenclatures.UpdateItem(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "nomenclature.item.update", "nomenclature_item", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": value})
	}
	respond(w, value, err)
}

func (a *App) listPeople(w http.ResponseWriter, r *http.Request) {
	values, err := a.Nomenclatures.ListPeople(r.Context(), includeInactive(r))
	respond(w, values, err)
}

func (a *App) createPerson(w http.ResponseWriter, r *http.Request) {
	var input nomenclature.PersonInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Nomenclatures.CreatePerson(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "person.create", "person", strconv.FormatInt(value.ID, 10), "success", map[string]any{"created": value})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updatePerson(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input nomenclature.PersonInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.Nomenclatures.GetPerson(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Nomenclatures.UpdatePerson(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "person.update", "person", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": value})
	}
	respond(w, value, err)
}

func (a *App) directoryDepartments(w http.ResponseWriter, _ *http.Request) {
	value, err := a.Directory.Departments()
	respond(w, value, err)
}

func (a *App) directoryUsers(w http.ResponseWriter, r *http.Request) {
	department := strings.TrimSpace(r.URL.Query().Get("department"))
	if department == "" {
		badRequest(w, errors.New("department is required"))
		return
	}
	values, err := a.Directory.Users(department)
	respond(w, values, err)
}

func (a *App) importDirectoryPeople(w http.ResponseWriter, r *http.Request) {
	var input struct {
		DistinguishedNames []string `json:"distinguished_names"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	directoryUsers, err := a.Directory.UsersByDN(input.DistinguishedNames)
	if err != nil {
		respond(w, nil, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	values, err := a.Nomenclatures.ImportDirectoryUsers(r.Context(), user.ID, directoryUsers)
	if err == nil {
		a.auditRequest(r, "person.directory.import", "person", "multiple", "success", map[string]any{"count": len(values)})
	}
	respondStatus(w, values, err, http.StatusCreated)
}

func (a *App) openapi(w http.ResponseWriter, r *http.Request) {
	b, err := openapifs.Files.ReadFile("openapi.yaml")
	if err != nil {
		respond(w, nil, err)
		return
	}
	w.Header().Set("Content-Type", "application/yaml")
	_, _ = w.Write(b)
}
func (a *App) auditRequest(r *http.Request, action, resourceType, resourceID, outcome string, details any) {
	u, _ := auth.UserFromContext(r.Context())
	id := u.ID
	_ = a.Audit.Log(r.Context(), audit.Event{Source: "server", ActorUserID: &id, ActorUsername: u.Username, Action: action, ResourceType: resourceType, ResourceID: resourceID, Outcome: outcome, RequestID: r.Header.Get("X-Request-ID"), IPAddress: clientIP(r), UserAgent: r.UserAgent(), Details: details})
}

func serveEmbedded(w http.ResponseWriter, root fs.FS, name string) {
	b, err := fs.ReadFile(root, name)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_, _ = w.Write(b)
}
func pathID(r *http.Request) (int64, error) {
	v := r.PathValue("id")
	id, err := strconv.ParseInt(v, 10, 64)
	if err != nil || id <= 0 {
		return 0, fmt.Errorf("invalid id")
	}
	return id, nil
}
func decodeJSON(r *http.Request, v any, max int64) error {
	defer r.Body.Close()
	dec := json.NewDecoder(io.LimitReader(r.Body, max))
	dec.DisallowUnknownFields()
	return dec.Decode(v)
}
func badRequest(w http.ResponseWriter, err error) {
	jsonResponse(w, 400, map[string]any{"error": "bad_request", "message": err.Error()})
}
func respond(w http.ResponseWriter, v any, err error) { respondStatus(w, v, err, 200) }
func respondStatus(w http.ResponseWriter, v any, err error, status int) {
	if err == nil {
		jsonResponse(w, status, v)
		return
	}
	if errors.Is(err, sql.ErrNoRows) {
		jsonResponse(w, 404, map[string]any{"error": "not_found"})
		return
	}
	msg := err.Error()
	lower := strings.ToLower(msg)
	if database.IsDuplicate(err) || strings.Contains(lower, "already running") {
		jsonResponse(w, http.StatusConflict, map[string]any{"error": "conflict", "message": msg})
		return
	}
	if strings.Contains(lower, "required") || strings.Contains(lower, "invalid") || strings.Contains(lower, "must ") || strings.Contains(lower, "between") || strings.Contains(lower, "at least") {
		jsonResponse(w, http.StatusBadRequest, map[string]any{"error": "bad_request", "message": msg})
		return
	}
	jsonResponse(w, http.StatusInternalServerError, map[string]any{"error": "internal_error", "message": "internal server error"})
}
func jsonResponse(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func clientIP(r *http.Request) string {
	if value := strings.TrimSpace(r.Header.Get("X-VM-Doc-Client-IP")); value != "" {
		return value
	}
	return remoteIP(r.RemoteAddr)
}

func resolvedClientIP(r *http.Request, trustedCIDRs []string) string {
	remote := remoteIP(r.RemoteAddr)
	remoteParsed := net.ParseIP(remote)
	if remoteParsed == nil || !ipInCIDRs(remoteParsed, trustedCIDRs) {
		return remote
	}
	chain := make([]string, 0, 8)
	for _, raw := range strings.Split(r.Header.Get("X-Forwarded-For"), ",") {
		if value := strings.TrimSpace(raw); net.ParseIP(value) != nil {
			chain = append(chain, value)
		}
	}
	chain = append(chain, remote)
	for i := len(chain) - 1; i >= 0; i-- {
		ip := net.ParseIP(chain[i])
		if ip == nil {
			continue
		}
		if i == len(chain)-1 || ipInCIDRs(ip, trustedCIDRs) {
			continue
		}
		return ip.String()
	}
	if len(chain) > 0 {
		return chain[0]
	}
	return remote
}

func ipInCIDRs(ip net.IP, cidrs []string) bool {
	for _, raw := range cidrs {
		_, network, err := net.ParseCIDR(raw)
		if err == nil && network.Contains(ip) {
			return true
		}
	}
	return false
}

func remoteIP(address string) string {
	host, _, err := net.SplitHostPort(address)
	if err == nil {
		return host
	}
	return strings.TrimSpace(address)
}
