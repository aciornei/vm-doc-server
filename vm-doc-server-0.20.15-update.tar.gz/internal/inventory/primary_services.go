package inventory

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"sort"
	"strings"

	"vm-doc-server/internal/domain"
)

const maxPrimaryServiceNameLength = 255

const agentServicesReviewCategory = "agent_services"

// SetAgentServicesReviewed persistă faptul că operatorul a verificat categoria
// Servicii din inventarul agentului. Marcajul poate satisface criteriul de
// completare atunci când VM-ul Linux nu are niciun serviciu marcat Principal.
func (s Service) SetAgentServicesReviewed(ctx context.Context, vmID, userID int64, reviewed bool) error {
	if reviewed {
		_, err := s.DB.ExecContext(ctx, `INSERT INTO vm_documentation_reviews(vm_id,category_code,reviewed_by) VALUES(?,?,?) ON DUPLICATE KEY UPDATE reviewed_by=VALUES(reviewed_by),reviewed_at=CURRENT_TIMESTAMP(6),updated_at=CURRENT_TIMESTAMP(6)`, vmID, agentServicesReviewCategory, userID)
		return err
	}
	_, err := s.DB.ExecContext(ctx, `DELETE FROM vm_documentation_reviews WHERE vm_id=? AND category_code=?`, vmID, agentServicesReviewCategory)
	return err
}

// AgentServicesReviewed indică dacă operatorul a confirmat că a verificat
// serviciile agentului pentru această VM.
func (s Service) AgentServicesReviewed(ctx context.Context, vmID int64) (bool, error) {
	var reviewed bool
	err := s.DB.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM vm_documentation_reviews WHERE vm_id=? AND category_code=?)`, vmID, agentServicesReviewCategory).Scan(&reviewed)
	return reviewed, err
}

// SetPrimaryAgentService marchează sau demarchează un serviciu raportat de agent
// ca fiind componentă software principală a VM-ului. Alegerea este independentă
// de snapshotul curent și supraviețuiește colectărilor ulterioare.
func (s Service) SetPrimaryAgentService(ctx context.Context, vmID, userID int64, serviceName string, primary bool) error {
	serviceName = strings.TrimSpace(serviceName)
	if serviceName == "" {
		return errors.New("service_name is required")
	}
	if len(serviceName) > maxPrimaryServiceNameLength {
		return fmt.Errorf("service_name is too long (max %d characters)", maxPrimaryServiceNameLength)
	}
	if primary {
		_, err := s.DB.ExecContext(ctx, `INSERT INTO vm_primary_agent_services(vm_id,service_name,selected_by) VALUES(?,?,?) ON DUPLICATE KEY UPDATE selected_by=VALUES(selected_by),updated_at=CURRENT_TIMESTAMP(6)`, vmID, serviceName, userID)
		return err
	}
	_, err := s.DB.ExecContext(ctx, `DELETE FROM vm_primary_agent_services WHERE vm_id=? AND service_name=?`, vmID, serviceName)
	return err
}

func (s Service) PrimaryAgentServiceNames(ctx context.Context, vmID int64) ([]string, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT service_name FROM vm_primary_agent_services WHERE vm_id=? ORDER BY LOWER(service_name),service_name`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]string, 0)
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			return nil, err
		}
		out = append(out, name)
	}
	return out, rows.Err()
}

// ListPrimaryAgentServices întoarce selecțiile persistente îmbogățite cu
// metadatele din inventarul curent. Dacă un serviciu nu mai este raportat,
// selecția rămâne vizibilă cu Detected=false.
func (s Service) ListPrimaryAgentServices(ctx context.Context, vmID int64, raw []byte) ([]domain.PrimaryAgentService, error) {
	names, err := s.PrimaryAgentServiceNames(ctx, vmID)
	if err != nil {
		return nil, err
	}
	observed, err := parseAgentServices(raw)
	if err != nil && len(raw) > 0 {
		return nil, err
	}
	out := make([]domain.PrimaryAgentService, 0, len(names))
	for _, name := range names {
		key := strings.ToLower(strings.TrimSpace(name))
		if value, ok := observed[key]; ok {
			value.Detected = true
			out = append(out, value)
			continue
		}
		out = append(out, domain.PrimaryAgentService{ServiceName: name, Detected: false})
	}
	sort.SliceStable(out, func(i, j int) bool {
		return strings.ToLower(out[i].ServiceName) < strings.ToLower(out[j].ServiceName)
	})
	return out, nil
}

func parseAgentServices(raw []byte) (map[string]domain.PrimaryAgentService, error) {
	out := make(map[string]domain.PrimaryAgentService)
	if len(bytes.TrimSpace(raw)) == 0 {
		return out, nil
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var root map[string]any
	if err := decoder.Decode(&root); err != nil {
		return nil, fmt.Errorf("decode inventory for primary services: %w", err)
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return nil, errors.New("inventory JSON contains trailing data")
	}
	services, _ := root["services"].([]any)
	for _, rawItem := range services {
		item, ok := rawItem.(map[string]any)
		if !ok {
			continue
		}
		name := mapString(item, "name")
		if name == "" {
			continue
		}
		value := domain.PrimaryAgentService{
			ServiceName:          name,
			SoftwareName:         mapString(item, "software_name"),
			Version:              mapString(item, "version"),
			PackageName:          mapString(item, "package_name"),
			PackageVersion:       mapString(item, "package_version"),
			VersionSource:        mapString(item, "version_source"),
			Manager:              mapString(item, "manager"),
			ActiveState:          mapString(item, "active_state"),
			SubState:             mapString(item, "sub_state"),
			EnabledState:         mapString(item, "enabled_state"),
			Description:          mapString(item, "description"),
			Classification:       mapString(item, "classification"),
			ClassificationReason: mapString(item, "classification_reason"),
			Detected:             true,
		}
		out[strings.ToLower(strings.TrimSpace(name))] = value
	}
	return out, nil
}

func mapString(value map[string]any, key string) string {
	if text, ok := value[key].(string); ok {
		return strings.TrimSpace(text)
	}
	return ""
}
