# Upgrade vm-doc-server 0.20.14 → 0.20.15

## Ce se schimbă

0.20.15 adaugă confirmarea persistentă **Servicii verificate** în Inventar → Servicii. Pentru VM-urile Linux/non-Windows, lipsa unui serviciu marcat **Principal** nu mai penalizează criteriul respectiv numai după ce operatorul confirmă manual că a verificat categoria.

## Migrare DB

La pornirea serverului se aplică automat:

```text
051_vm_documentation_reviews.up.sql
```

Migrarea creează tabelul `vm_documentation_reviews`. Nu șterge și nu modifică selecțiile `Principal` existente.

## Instalare

Peste arborele 0.20.14:

```bash
tar -xzf vm-doc-server-0.20.15-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.15
cd /usr/local/src/vm-doc-server-0.20.15
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După instalare, repornește `vm-doc-server`. Migrarea 051 este aplicată automat la startup.

## Verificare funcțională

1. Deschide o VM Linux cu inventar.
2. În Inventar → Servicii, lasă toate serviciile nemarcate `Principal`.
3. Verifică faptul că procentul semnalează criteriul serviciilor ca lipsă.
4. Bifează `Servicii verificate`.
5. Procentul trebuie recalculat imediat și criteriul serviciilor trebuie considerat îndeplinit.
6. Debifează marcajul: dacă nu există niciun serviciu `Principal`, penalizarea trebuie să reapară.

0.20.15 include și corecția testului `TestVMExportRowsUsesInventoryValues`, care așteaptă acum 22 de coloane după introducerea coloanei `Baseline` în 0.20.14.

Nu este necesar update de agent.
