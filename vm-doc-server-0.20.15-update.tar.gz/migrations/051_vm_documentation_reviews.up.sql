CREATE TABLE IF NOT EXISTS vm_documentation_reviews (
  vm_id BIGINT UNSIGNED NOT NULL,
  category_code VARCHAR(64) NOT NULL,
  reviewed_by BIGINT UNSIGNED NULL,
  reviewed_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (vm_id, category_code),
  KEY idx_vm_documentation_reviews_category (category_code),
  KEY idx_vm_documentation_reviews_user (reviewed_by),
  CONSTRAINT fk_vm_documentation_reviews_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_documentation_reviews_user FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
