package server

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/documents"
	outlineapi "vm-doc-server/internal/outline"
)

type outlineBulkInput struct {
	PoweredOnOnly bool `json:"powered_on_only"`
}

type outlineBulkJob struct {
	ID                string    `json:"id"`
	Kind              string    `json:"kind"`
	Status            string    `json:"status"`
	StartedAt         time.Time `json:"started_at"`
	FinishedAt        time.Time `json:"finished_at,omitempty"`
	TotalVMs          int       `json:"total_vms,omitempty"`
	ProcessedVMs      int       `json:"processed_vms,omitempty"`
	PublishedVMs      int       `json:"published_vms,omitempty"`
	TotalServices     int       `json:"total_services,omitempty"`
	ProcessedServices int       `json:"processed_services,omitempty"`
	PublishedServices int       `json:"published_services,omitempty"`
	SkippedServices   int       `json:"skipped_services,omitempty"`
	Errors            []string  `json:"errors,omitempty"`
	LastObject        string    `json:"last_object,omitempty"`
}

var outlineBulkJobs = struct {
	sync.RWMutex
	values map[string]*outlineBulkJob
}{values: map[string]*outlineBulkJob{}}

func (a *App) outlineSettings(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	value, err := a.Outline.GetSettings(r.Context())
	respond(w, value, err)
}

func (a *App) updateOutlineSettings(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	var input outlineapi.SettingsInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Outline.UpdateSettings(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "outline.settings.update", "outline_settings", "1", "success", map[string]any{
			"enabled":                           value.Enabled,
			"base_url":                          value.BaseURL,
			"collection_id":                     value.CollectionID,
			"virtualization_parent_document_id": value.VirtualizationParentDocumentID,
			"verify_tls":                        value.VerifyTLS,
			"allow_http":                        value.AllowHTTP,
		})
	}
	if err != nil && a.Logger != nil {
		a.Logger.Error("Outline settings update failed", "error", err)
	}
	outlineRespond(w, value, err)
}

func (a *App) testOutline(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		outlineRespond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	settings, settingsErr := a.Outline.GetSettings(r.Context())
	if settingsErr != nil {
		outlineRespond(w, nil, settingsErr)
		return
	}
	if !settings.Enabled {
		badRequest(w, errors.New("Integrarea Outline este dezactivată. Bifează «Activează integrarea Outline» și salvează setările înainte de test"))
		return
	}
	value, err := a.Outline.Test(r.Context())
	if err == nil {
		a.auditRequest(r, "outline.connection.test", "outline_settings", "1", "success", map[string]any{
			"parent_document_id":    value.ParentDocumentID,
			"parent_document_title": value.ParentDocumentTitle,
		})
	} else if a.Logger != nil {
		a.Logger.Error("Outline connection test failed", "error", err)
	}
	outlineRespond(w, value, err)
}

func (a *App) publishVMOutline(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.publishVMToOutline(r, vmID)
	if err == nil {
		a.auditRequest(r, "outline.vm.publish", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{
			"vm_id":               vmID,
			"outline_target":      "virtualization",
			"outline_document_id": result.DocumentID,
			"outline_url":         result.URL,
		})
	}
	if err != nil && a.Logger != nil {
		a.Logger.Error("Outline VM publish failed", "vm_id", vmID, "error", err)
	}
	outlineRespond(w, result, err)
}

func (a *App) outlineVMMapping(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Outline.VMMapping(r.Context(), vmID)
	if errors.Is(err, sql.ErrNoRows) {
		jsonResponse(w, http.StatusOK, map[string]any{"configured": false})
		return
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, map[string]any{"configured": true, "document_id": value.DocumentID, "url": value.URL})
}

func (a *App) publishServiceOutline(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.publishServiceToOutline(r, serviceID)
	if err == nil {
		a.auditRequest(r, "outline.service.publish", "internal_service", strconv.FormatInt(serviceID, 10), "success", map[string]any{
			"service_id":          serviceID,
			"outline_document_id": result.DocumentID,
			"outline_url":         result.URL,
		})
	} else if a.Logger != nil {
		a.Logger.Error("Outline service publish failed", "service_id", serviceID, "error", err)
	}
	outlineRespond(w, result, err)
}

func (a *App) outlineServiceMapping(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Outline.ServiceMapping(r.Context(), serviceID)
	if errors.Is(err, sql.ErrNoRows) {
		jsonResponse(w, http.StatusOK, map[string]any{"configured": false})
		return
	}
	if err != nil {
		outlineRespond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, map[string]any{"configured": true, "document_id": value.DocumentID, "url": value.URL})
}

func (a *App) startOutlineBulkPublish(w http.ResponseWriter, r *http.Request) {
	var input outlineBulkInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	if _, err := a.Outline.Test(r.Context()); err != nil {
		outlineRespond(w, nil, err)
		return
	}
	now := time.Now().UTC()
	id := fmt.Sprintf("outline-%d", now.UnixNano())
	job := &outlineBulkJob{ID: id, Kind: "vm", Status: "queued", StartedAt: now}
	outlineBulkJobs.Lock()
	for existingID, existing := range outlineBulkJobs.values {
		if !existing.FinishedAt.IsZero() && now.Sub(existing.FinishedAt) > 24*time.Hour {
			delete(outlineBulkJobs.values, existingID)
		}
	}
	outlineBulkJobs.values[id] = job
	outlineBulkJobs.Unlock()

	bgRequest := r.Clone(context.WithoutCancel(r.Context()))
	go a.runOutlineBulkPublish(bgRequest, job, input)
	jsonResponse(w, http.StatusAccepted, job)
}

func (a *App) startOutlineServiceBulkPublish(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		outlineRespond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	if _, err := a.Outline.Test(r.Context()); err != nil {
		outlineRespond(w, nil, err)
		return
	}
	now := time.Now().UTC()
	id := fmt.Sprintf("outline-services-%d", now.UnixNano())
	job := &outlineBulkJob{ID: id, Kind: "service", Status: "queued", StartedAt: now}
	outlineBulkJobs.Lock()
	for existingID, existing := range outlineBulkJobs.values {
		if !existing.FinishedAt.IsZero() && now.Sub(existing.FinishedAt) > 24*time.Hour {
			delete(outlineBulkJobs.values, existingID)
		}
	}
	outlineBulkJobs.values[id] = job
	outlineBulkJobs.Unlock()

	bgRequest := r.Clone(context.WithoutCancel(r.Context()))
	go a.runOutlineServiceBulkPublish(bgRequest, job)
	jsonResponse(w, http.StatusAccepted, job)
}

func (a *App) getOutlineBulkJob(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimSpace(r.PathValue("id"))
	outlineBulkJobs.RLock()
	job := outlineBulkJobs.values[id]
	if job == nil {
		outlineBulkJobs.RUnlock()
		respond(w, nil, sql.ErrNoRows)
		return
	}
	copy := *job
	copy.Errors = append([]string(nil), job.Errors...)
	outlineBulkJobs.RUnlock()
	respond(w, copy, nil)
}

func (a *App) runOutlineBulkPublish(r *http.Request, job *outlineBulkJob, input outlineBulkInput) {
	update := func(fn func(*outlineBulkJob)) {
		outlineBulkJobs.Lock()
		fn(job)
		outlineBulkJobs.Unlock()
	}
	update(func(j *outlineBulkJob) { j.Status = "running" })
	items, err := a.Documents.ListBulkExportItems(r.Context(), "vm", input.PoweredOnOnly)
	if err != nil {
		update(func(j *outlineBulkJob) {
			j.Status = "failed"
			j.FinishedAt = time.Now().UTC()
			j.Errors = append(j.Errors, err.Error())
		})
		return
	}
	update(func(j *outlineBulkJob) { j.TotalVMs = len(items) })
	for _, item := range items {
		update(func(j *outlineBulkJob) { j.LastObject = item.ObjectName })
		_, publishErr := a.publishVMToOutline(r, item.ObjectID)
		update(func(j *outlineBulkJob) {
			j.ProcessedVMs++
			if publishErr != nil {
				j.Errors = append(j.Errors, item.ObjectName+": "+publishErr.Error())
				return
			}
			j.PublishedVMs++
		})
	}
	update(func(j *outlineBulkJob) {
		if len(j.Errors) > 0 {
			j.Status = "partial"
		} else {
			j.Status = "success"
		}
		j.FinishedAt = time.Now().UTC()
		j.LastObject = ""
	})
	a.auditRequest(r, "outline.bulk_publish", "outline", job.ID, "success", map[string]any{
		"target":          "virtualization",
		"powered_on_only": input.PoweredOnOnly,
		"vms":             job.PublishedVMs,
		"errors":          len(job.Errors),
	})
}

func (a *App) runOutlineServiceBulkPublish(r *http.Request, job *outlineBulkJob) {
	update := func(fn func(*outlineBulkJob)) {
		outlineBulkJobs.Lock()
		fn(job)
		outlineBulkJobs.Unlock()
	}
	update(func(j *outlineBulkJob) { j.Status = "running" })
	items, err := a.Catalog.List(r.Context(), false)
	if err != nil {
		update(func(j *outlineBulkJob) {
			j.Status = "failed"
			j.FinishedAt = time.Now().UTC()
			j.Errors = append(j.Errors, err.Error())
		})
		return
	}
	update(func(j *outlineBulkJob) { j.TotalServices = len(items) })
	for _, item := range items {
		update(func(j *outlineBulkJob) { j.LastObject = item.Name })
		if item.Retired || item.OutlineDocumentationDisabled || strings.TrimSpace(item.DocumentationURL) == "" {
			update(func(j *outlineBulkJob) {
				j.ProcessedServices++
				j.SkippedServices++
			})
			continue
		}
		_, publishErr := a.publishServiceToOutline(r, item.ID)
		update(func(j *outlineBulkJob) {
			j.ProcessedServices++
			if publishErr != nil {
				j.Errors = append(j.Errors, item.Name+": "+publishErr.Error())
				return
			}
			j.PublishedServices++
		})
	}
	update(func(j *outlineBulkJob) {
		if len(j.Errors) > 0 {
			j.Status = "partial"
		} else {
			j.Status = "success"
		}
		j.FinishedAt = time.Now().UTC()
		j.LastObject = ""
	})
	a.auditRequest(r, "outline.service_bulk_publish", "outline", job.ID, "success", map[string]any{
		"services": job.PublishedServices,
		"skipped":  job.SkippedServices,
		"errors":   len(job.Errors),
	})
}

func (a *App) publishServiceToOutline(r *http.Request, serviceID int64) (outlineapi.PublishResult, error) {
	if a.Outline == nil {
		return outlineapi.PublishResult{}, errors.New("Outline integration is unavailable")
	}
	service, err := a.Catalog.Get(r.Context(), serviceID)
	if err != nil {
		return outlineapi.PublishResult{}, err
	}
	if service.Retired {
		return outlineapi.PublishResult{}, errors.New("serviciul este retras și nu se publică în Outline")
	}
	if service.OutlineDocumentationDisabled {
		return outlineapi.PublishResult{}, errors.New("serviciul este marcat «Nu se documentează în Outline»")
	}
	if strings.TrimSpace(service.DocumentationURL) == "" {
		return outlineapi.PublishResult{}, errors.New("Link documentație nu este configurat pentru acest serviciu")
	}
	_, data, err := a.serviceDocumentGenerationData(r, serviceID, templateRequest{IncludeGeneratedBy: false}, false)
	if err != nil {
		return outlineapi.PublishResult{}, err
	}
	if generated, listErr := a.Documents.ListGeneratedService(r.Context(), serviceID); listErr == nil && len(generated) > 0 {
		data.DocumentNumber = generated[0].DocumentNumber
		data.GeneratedAt = generated[0].GeneratedAt
	}
	data.IncludeGeneratedBy = false
	data.OutlineMode = true
	attachments, attachmentErr := a.Catalog.ListAttachments(r.Context(), serviceID, true)
	if attachmentErr != nil {
		return outlineapi.PublishResult{}, fmt.Errorf("load service supplemental documentation for Outline: %w", attachmentErr)
	}
	data.Attachments = attachments
	vmIDs := make([]int64, 0, len(data.Service.VMs))
	seen := map[int64]bool{}
	for _, vm := range data.Service.VMs {
		if vm.ID > 0 && !seen[vm.ID] {
			seen[vm.ID] = true
			vmIDs = append(vmIDs, vm.ID)
		}
	}
	data.OutlineVMURLs, err = a.Outline.VMURLs(r.Context(), vmIDs)
	if err != nil {
		return outlineapi.PublishResult{}, fmt.Errorf("load Outline VM links: %w", err)
	}
	markdown := documents.RenderServiceMarkdown(data)
	return a.Outline.UpdateLinkedServiceDocument(r.Context(), serviceID, service.DocumentationURL, markdown)
}

func (a *App) publishVMToOutline(r *http.Request, vmID int64) (outlineapi.PublishResult, error) {
	if a.Outline == nil {
		return outlineapi.PublishResult{}, errors.New("Outline integration is unavailable")
	}
	data, err := a.buildVMGenerationData(r, vmID)
	if err != nil {
		return outlineapi.PublishResult{}, err
	}
	if generated, listErr := a.Documents.ListGeneratedVM(r.Context(), vmID); listErr == nil && len(generated) > 0 {
		data.DocumentNumber = generated[0].DocumentNumber
		data.GeneratedAt = generated[0].GeneratedAt
	}
	data.IncludeGeneratedBy = false
	data.OutlineMode = true
	serviceIDs := make([]int64, 0, len(data.Operational.ServiceAssignments))
	seenServices := map[int64]bool{}
	for _, assignment := range data.Operational.ServiceAssignments {
		if assignment.InternalServiceID > 0 && !seenServices[assignment.InternalServiceID] {
			seenServices[assignment.InternalServiceID] = true
			serviceIDs = append(serviceIDs, assignment.InternalServiceID)
		}
	}
	data.OutlineServiceURLs, err = a.Outline.ServiceOutlineURLs(r.Context(), serviceIDs)
	if err != nil {
		return outlineapi.PublishResult{}, fmt.Errorf("load Outline service links: %w", err)
	}
	markdown := documents.RenderVMMarkdown(data)
	title := firstServerNonEmpty(data.VM.Name, data.VM.GuestHostname, fmt.Sprintf("VM %d", vmID))
	return a.Outline.UpsertVMDocument(r.Context(), vmID, title, markdown)
}

func outlineRespond(w http.ResponseWriter, value any, err error) {
	if err == nil {
		jsonResponse(w, http.StatusOK, value)
		return
	}
	if status, message, ok := outlineapi.RemoteErrorDetails(err); ok {
		if status < 400 || status > 599 {
			status = http.StatusBadGateway
		}
		jsonResponse(w, status, map[string]any{"error": "outline_error", "message": message})
		return
	}
	lower := strings.ToLower(err.Error())
	if strings.Contains(lower, "disabled") || strings.Contains(lower, "not configured") || strings.Contains(lower, "link documentație") || strings.Contains(lower, "outline document") || strings.Contains(lower, "outline instance") {
		badRequest(w, err)
		return
	}
	respond(w, value, err)
}
