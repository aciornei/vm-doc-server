-- 0.20.33: lifecycle servicii și control explicit pentru publicarea Outline.

INSERT IGNORE INTO nomenclature_categories(code,label,sort_order,active)
VALUES ('service_retirement_reason','Motiv retragere serviciu',110,1);

INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,icon_key,sort_order,active) VALUES
('service_retirement_reason','Scos din uz','decommissioned','Serviciul a fost dezafectat și nu mai este utilizat.','status',10,1),
('service_retirement_reason','Înlocuit / migrat','replaced','Serviciul a fost înlocuit, migrat sau consolidat într-o altă soluție.','integration',20,1),
('service_retirement_reason','Proiect / serviciu închis','closed','Serviciul nu mai este necesar deoarece proiectul sau activitatea a fost închisă.','package',30,1),
('service_retirement_reason','Contract / furnizor încheiat','contract_ended','Serviciul a fost retras după încetarea contractului sau a relației cu furnizorul.','store',40,1),
('service_retirement_reason','Alt motiv','other','Alt motiv de retragere din exploatare.','status',999,1);

ALTER TABLE internal_services
  ADD COLUMN IF NOT EXISTS retired TINYINT(1) NOT NULL DEFAULT 0 AFTER active,
  ADD COLUMN IF NOT EXISTS retirement_reason_id BIGINT UNSIGNED NULL AFTER retired,
  ADD COLUMN IF NOT EXISTS retired_at DATE NULL AFTER retirement_reason_id,
  ADD COLUMN IF NOT EXISTS outline_documentation_disabled TINYINT(1) NOT NULL DEFAULT 0 AFTER retired_at;

ALTER TABLE internal_services
  ADD INDEX IF NOT EXISTS idx_internal_service_retired (retired,retired_at),
  ADD INDEX IF NOT EXISTS idx_internal_service_outline_disabled (outline_documentation_disabled);

SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA=DATABASE()
     AND TABLE_NAME='internal_services'
     AND CONSTRAINT_NAME='fk_internal_service_retirement_reason')=0,
  'ALTER TABLE internal_services ADD CONSTRAINT fk_internal_service_retirement_reason FOREIGN KEY (retirement_reason_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
