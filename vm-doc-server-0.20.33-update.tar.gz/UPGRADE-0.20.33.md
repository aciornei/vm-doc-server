# Upgrade vm-doc-server 0.20.32 -> 0.20.33

Versiunea 0.20.33 adaugă o migrare DB pentru lifecycle-ul serviciilor și controlul publicării Outline. Nu necesită update de vm-doc-agent.

## Schimbări

- Exporturile PDF sunt ascunse temporar din interfață; endpoint-urile backend nu sunt eliminate.
- Serviciile pot fi marcate `Retras / scos din uz`, cu motiv din nomenclator și dată opțională.
- Un serviciu retras este setat automat inactiv și nu este publicat în Outline.
- Bifa `Nu se documentează în Outline` exclude separat un serviciu, chiar dacă este activ.
- Butoanele Outline din fișa VM și Serviciu apar numai dacă integrarea este activată în Documente.
- Fișele serviciilor includ starea lifecycle, motivul și data retragerii.
- Migrare nouă: `058_service_lifecycle_outline_controls.up.sql`.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.32 \
      /usr/local/src/vm-doc-server-0.20.33

tar -xzf vm-doc-server-0.20.33-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.33

cd /usr/local/src/vm-doc-server-0.20.33

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

La prima pornire, serverul aplică automat migrarea 058. Păstrează directorul `vendor/` din instalarea curentă pentru build offline.
