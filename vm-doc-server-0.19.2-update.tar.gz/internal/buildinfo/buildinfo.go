package buildinfo

var (
	Version = "0.19.2-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
