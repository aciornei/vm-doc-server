package server

import (
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/monitoring"
)

func (a *App) listMonitoringVMs(w http.ResponseWriter, r *http.Request) {
	page, pageSize, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Monitoring.ListVMs(r.Context(), r.URL.Query().Get("q"), r.URL.Query().Get("state"), r.URL.Query().Get("power"), page, pageSize)
	respond(w, v, err)
}

func (a *App) listMonitoringTargets(w http.ResponseWriter, r *http.Request) {
	page, pageSize, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Monitoring.ListTargets(r.Context(), r.URL.Query().Get("q"), r.URL.Query().Get("source_type"), r.URL.Query().Get("health"), r.URL.Query().Get("matched"), page, pageSize)
	respond(w, v, err)
}

func (a *App) listMonitoringAgentOptions(w http.ResponseWriter, r *http.Request) {
	v, err := a.Monitoring.ListAgentOptions(r.Context())
	respond(w, v, err)
}

func (a *App) listPrometheusSources(w http.ResponseWriter, r *http.Request) {
	v, err := a.Monitoring.ListSources(r.Context())
	respond(w, v, err)
}
func (a *App) getPrometheusSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Monitoring.GetSource(r.Context(), id)
	respond(w, v, err)
}

func (a *App) createPrometheusSource(w http.ResponseWriter, r *http.Request) {
	var in monitoring.SourceInput
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.Monitoring.CreateSource(r.Context(), in, u.ID)
	if err == nil {
		a.auditRequest(r, "monitoring.source.create", "prometheus_source", strconv.FormatInt(v.ID, 10), "success", map[string]any{"name": v.Name, "base_url": v.BaseURL, "source_type": v.SourceType})
	}
	respondStatus(w, v, err, http.StatusCreated)
}
func (a *App) updatePrometheusSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in monitoring.SourceInput
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.Monitoring.UpdateSource(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "monitoring.source.update", "prometheus_source", strconv.FormatInt(id, 10), "success", map[string]any{"name": v.Name, "base_url": v.BaseURL, "source_type": v.SourceType})
	}
	respond(w, v, err)
}
func (a *App) deletePrometheusSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	err = a.Monitoring.DeleteSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "monitoring.source.delete", "prometheus_source", strconv.FormatInt(id, 10), "success", nil)
	}
	respond(w, map[string]any{"deleted": err == nil}, err)
}
func (a *App) testPrometheusSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Monitoring.TestSource(r.Context(), id)
	if err != nil && a.Logger != nil {
		a.Logger.Error("Prometheus connection test failed", "source_id", id, "error", err)
	}
	if err == nil {
		a.auditRequest(r, "monitoring.source.test", "prometheus_source", strconv.FormatInt(id, 10), "success", v)
	}
	respond(w, v, err)
}
func (a *App) syncPrometheusSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	run, err := a.Monitoring.StartSync(r.Context(), id, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "monitoring.sync.queue", "prometheus_source", strconv.FormatInt(id, 10), "success", map[string]any{"run_id": run.ID})
	}
	respondStatus(w, run, err, http.StatusAccepted)
}
func (a *App) syncAllPrometheus(w http.ResponseWriter, r *http.Request) {
	u, _ := auth.UserFromContext(r.Context())
	runs, err := a.Monitoring.StartAll(r.Context(), &u.ID)
	if err == nil {
		a.auditRequest(r, "monitoring.sync.queue_all", "prometheus", "all", "success", map[string]any{"runs": len(runs)})
	}
	respondStatus(w, runs, err, http.StatusAccepted)
}
func (a *App) listPrometheusRuns(w http.ResponseWriter, r *http.Request) {
	page, pageSize, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Monitoring.ListRunsPage(r.Context(), page, pageSize)
	respond(w, v, err)
}
func (a *App) getVMMonitoring(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Monitoring.GetVM(r.Context(), id)
	respond(w, v, err)
}
func (a *App) updateVMMonitoringAliases(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in monitoring.AliasInput
	if err := decodeJSON(r, &in, 128<<10); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	err = a.Monitoring.UpdateAliases(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "monitoring.aliases.update", "virtual_machine", strconv.FormatInt(id, 10), "success", map[string]any{"aliases": in.Aliases})
	}
	respond(w, map[string]any{"updated": err == nil}, err)
}
