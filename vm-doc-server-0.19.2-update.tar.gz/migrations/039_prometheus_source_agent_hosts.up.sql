-- 0.19.2: source Prometheus -> agent local pentru rezolvarea /etc/hosts.

ALTER TABLE prometheus_sources
  ADD COLUMN IF NOT EXISTS agent_id BIGINT UNSIGNED NULL AFTER target_label;

CREATE INDEX IF NOT EXISTS idx_prometheus_sources_agent ON prometheus_sources(agent_id);

ALTER TABLE prometheus_sources
  ADD CONSTRAINT fk_prometheus_sources_agent FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE SET NULL;
