# Upgrade vm-doc-server 0.19.1 → 0.19.2

0.19.2 adaugă asocierea explicită sursă Prometheus → agent și corelarea targeturilor prin `/etc/hosts` raportat de vm-doc-agent 1.6.3.

## Pași

1. Actualizați vm-doc-server la 0.19.2 și porniți serviciul; se aplică migrarea `039_prometheus_source_agent_hosts.up.sql`.
2. Publicați vm-doc-agent 1.6.3 și actualizați cel puțin serverele Prometheus.
3. Forțați o colectare pe agentul Prometheus și verificați că inventarul conține `hosts.entries`.
4. În Monitorizare → Surse Prometheus, editați fiecare sursă și selectați explicit agentul instalat pe acel Prometheus. Pentru două surse metrics/blackbox care folosesc același Prometheus, selectați același agent.
5. Rulați Test; răspunsul trebuie să indice `hosts_available=true` și un număr de intrări dacă `/etc/hosts` conține aliasuri utile.
6. Rulați Sync pe metrics și blackbox. Targeturile care înainte erau necorelate din cauza aliasurilor locale trebuie să apară cu metoda `prometheus_hosts`.

Nu este necesară golirea tabelelor de monitorizare.
