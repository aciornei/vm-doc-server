package server

import (
	"strings"
	"testing"
)

func TestSecurityBulkTargetsRelevantAccountsOnly(t *testing.T) {
	rows := securityResponse{Accounts: []securityAccount{
		{Username: "root", SystemAccount: true},
		{Username: "daemon", SystemAccount: true, LoginCapable: false},
		{Username: "operator", LoginCapable: true},
		{Username: "root", SystemAccount: true},
	}}
	got := securityBulkTargets(rows, "accounts", 0)
	if len(got) != 2 || got[0].Key != "root" || got[1].Key != "operator" {
		t.Fatalf("incorrect eligible accounts: %+v", got)
	}
}

func TestSecurityBulkTargetsDBInstanceAndNOLOGIN(t *testing.T) {
	rows := securityResponse{Databases: []securityDatabase{
		{ID: 11, Engine: "postgresql", Principals: []securityDBPrincipal{
			{Name: "pg_read_all_data", Login: false},
			{Name: "project_role", Login: false},
			{Name: "app_user", Login: true, Roles: []string{"project_role"}},
		}},
		{ID: 12, Engine: "postgresql", Principals: []securityDBPrincipal{{Name: "app_user", Login: true}}},
	}}
	got := securityBulkTargets(rows, "database_principals", 11)
	if len(got) != 2 {
		t.Fatalf("wanted two principals from instance 11: %+v", got)
	}
	for _, target := range got {
		if !strings.HasPrefix(target.Key, "dbp:11:") {
			t.Fatalf("wrong instance: %+v", got)
		}
	}
	if len(securityBulkTargets(rows, "database_principals", 0)) != 3 {
		t.Fatal("VM-scoped database bulk omitted custom NOLOGIN or cross-instance user")
	}
}

func TestSecurityBulkTargetsWeb(t *testing.T) {
	rows := securityResponse{WebSites: []securityWebSite{{ID: 4}, {ID: 8}}}
	got := securityBulkTargets(rows, "web", 0)
	if len(got) != 2 || got[0].Key != "4" || got[1].Key != "8" {
		t.Fatalf("invalid web targets: %+v", got)
	}
	if len(securityBulkTargets(rows, "other", 0)) != 0 {
		t.Fatal("unknown bulk scope accepted")
	}
}
