# VM-DOC Server 0.21.35 — 16 octombrie 2026

Versiune de pornire: 0.21.34. Componenta agent rămâne 1.7.18. Nu există migrare SQL.

## Database Access

- Titlu și badge-uri clare pentru instanță.
- 3 categorii: Users / Roles, Grants, Conectare / HBA.
- Max. 4 roluri/privilegii server pe verticală, restul prin Extinde.
- PostgreSQL: ascundere roluri interne `pg_*` NOLOGIN din Securitate/revizii (fără ștergere din access_json).
- Granturi grupate după principal, host, scope, bază, schemă, privilegiu, state, grantable; fiecare grup prezintă toate înregistrările originale. Eliminată limita de afișare 500.

## Revizie colectivă

- `Revizuiește secțiunea` pentru Conturi relevante, DB (VM sau o instanță), Web ACL, fără anularea reviziilor individuale.
- API nou `PUT /api/v1/security/review/bulk`, documentat în OpenAPI; autentificare, CSRF, RBAC `vms.manage` identice cu review-ul individual.
- 6/12 luni, Da/Nu justificare, observații de minimum 10 caractere, confirmare explicită de suprascriere. Numai o VM per operație; cheile sunt construite de server din inventarul actual. Scriere atomică în tranzacție și audit sumar.
- Revizia colectivă **suprascrie review-urile existente** pentru țintele selectate; nu este o simplă bifă de confirmare pentru întregul catalog. Operația necesită verificarea efectivă a obiectelor înainte de folosire.

## Upgrade offline

1. Fă backup MariaDB și păstrează aplicația/sursele 0.21.34 pentru rollback.
2. Într-o **copie** a surselor 0.21.34, extrage `vm-doc-server-0.21.35-update.tar.gz` din directorul rădăcină al proiectului (fără să suprascrii `vendor/`, configurația și datele).
3. Confirmă `cat VERSION` = `0.21.35` și rulează `bash scripts/cleanup-source-tree.sh --check`.
4. În mediul offline cu `vendor/`, rulează `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build` conform procedurii locale.
5. Deploy întâi în staging, apoi reîncarcă JS/CSS prin hard refresh; verifică Securitate DB, Conturi VM și Web ACL.

Nu aplica update-ul 0.21.35 direct peste 0.21.33 fără upgrade-ul intermediar 0.21.34. Pentru rollback restaurează binarul și sursele 0.21.34 și păstrează un backup tranzacțional al tabelei `security_reviews` dacă ai executat revizii colective. Nu este nevoie de rollback de schemă SQL.

## Testare efectuată

- JavaScript sintactic OK; Chromium date simulate la 1595, 1024 și 390 px, grupare 2.000 grants, taburi și roluri OK.
- Popup de review colectiv: request mock către endpoint, payload/confirmare OK.
- `go test` OpenAPI/Web/Buildinfo/Domain/XLSX/Migrations OK.
- `go test ./internal/server` și build complet **neexecutabile local** deoarece pachetele externe lipsesc din cache; trebuie rulate cu `vendor/` pe server.
- MariaDB reală / audit / RBAC E2E neconfirmate.
