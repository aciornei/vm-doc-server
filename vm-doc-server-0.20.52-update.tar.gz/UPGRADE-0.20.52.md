# Upgrade vm-doc-server 0.20.51 → 0.20.52

Versiunea 0.20.52 adaugă verificarea/dry-run înainte de publicarea în masă a serviciilor în Outline. Nu există migrare de bază de date și vm-doc-agent nu se modifică.

## Pași

```bash
cp -a /usr/local/src/vm-doc-server-0.20.51 /usr/local/src/vm-doc-server-0.20.52
tar -xzf vm-doc-server-0.20.52-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.52
cd /usr/local/src/vm-doc-server-0.20.52

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi actualizează serviciul/systemd către binarul 0.20.52, repornește serverul și fă `Ctrl+F5` în browser.

## Comportament nou

În `Documente → Publică în Outline → Servicii`, rulează **Verifică serviciile**. Numai serviciile marcate eligibile pot fi trimise prin **Publică serviciile eligibile**. După finalizarea unui job, rulează din nou verificarea înainte de o nouă publicare.
