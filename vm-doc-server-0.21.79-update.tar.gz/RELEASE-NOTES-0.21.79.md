# VM-DOC 0.21.79 — ajustări UI Modificări

## Schimbări

- Căutarea păstrează domeniile VM / Peste tot / Serviciu / Obiect, dar selectorul este limitat la circa 112–150 px. Câmpul de text ocupă tot spațiul rămas. Butonul Caută este compact, iar săgeata pentru filtrele secundare este la extrema dreaptă, după Export Excel.
- Categorie, Tip, Documentație și Stare sunt pliate implicit; săgeata de la capătul barei le extinde și le închide.
- Iconițele „i” pentru Documentație/Stare devin elemente interactive native: clic sau Enter/Space deschide explicația, fără a depinde de `title`. Se evită tăierea popup-urilor de `overflow:hidden` al panoului.
- „Cum funcționează detectorul semantic?” și „Ce este baseline-ul?” sunt mutați sub tabel, la baza paginii și cu margine superioară; rămân colapsați implicit.
- Tabelul Detalii este lipit de marginile celulei părinte, fără padding lateral și fără rotunjire sus; colțurile de jos rămân rotunjite.
- Aceleași corecții de căutare/detalii și în fila VM → Modificări; explicația detectorului se mută după tabel.

## Fără schimbări de backend

Nu se schimbă semantica Documentație și Stare, nici API, endpointul Excel, detectorul semantic 1:1, bazele de date, baseline-urile, istoricul sau agentul (1.7.18). Nu există migrare SQL.

## Limitări de verificare

Testate: Chromium headless cu date demonstrative, calcul geometric al controalelor și rândului de detalii; click pe săgeată și info, căutarea și interogarea transmisă; teste Node.js și teste Go independente. Nevalidate: integrarea efectivă cu MariaDB și binarul complet construit cu vendor pe serverul utilizatorului.
