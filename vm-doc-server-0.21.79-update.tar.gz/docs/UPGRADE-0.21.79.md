# Upgrade VM-DOC 0.21.78 → 0.21.79

1. Faceți backup la cod, configurația curentă și binarul instalat. Nu este necesară migrare a bazei de date.
2. Pentru update incremental, extrageți `vm-doc-server-0.21.79-update.tar.gz` în rădăcina surselor **0.21.78**; alternativ aplicați patch-ul cu `patch -p1` sau utilizați ZIP-ul cu surse complete.
3. Rulați `bash scripts/cleanup-source-tree.sh --check`. Dacă există fișiere istorice nestructurate, verificați mai întâi `--dry-run`, apoi `--apply`.
4. În mediul offline, compilați cu dependențele vendor: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`. Instalați noul binar conform serviciului systemd existent, apoi reporniți serviciul.
5. În browser confirmați încărcarea `app.js?v=0.21.79` și `app.css?v=0.21.79`. La Modificări verificați că dropdown-ul este compact, câmpul de text lat, iar săgeata din dreapta extinde filtrele.
6. Deschideți info la Documentație și Stare. Extindeți un rând Detalii și verificați alinierea marginilor. Explicațiile despre detector și baseline trebuie să fie la finalul paginii.

**Rollback:** restaurați binarul 0.21.78 și sursele anterioare; nu există rollback SQL sau migrare de reversat.
