# Upgrade vm-doc-server 0.20.34 -> 0.20.35

Versiunea 0.20.35 adaugă inventarul manual asistat pentru **Componente suport** și raportarea centralizată a acestora. Nu necesită update de vm-doc-agent.

## Schimbări

- În **VM → Inventar → Servicii**, fiecare serviciu observat de agent are o bifă nouă `Componentă suport`, independentă de `Principal`.
- La bifare se propune automat numele canonic al tehnologiei. Poate fi editat pentru orice produs nou sau serviciu custom.
- Versiunea vine automat din inventarul agentului (`version`, apoi `package_version`). Poate fi suprascrisă manual.
- Porturile sunt corelate automat atunci când procesul/executabilul poate fi asociat sigur; există câmp manual pentru unul sau mai multe porturi.
- În **Rapoarte → Componente suport** datele sunt grupate `Componentă → Versiune → Mediu` și includ VM, hostname, IP, porturi, serviciile/proiectele asociate și serviciul agent.
- Raportul are filtre și export Excel.
- Migrare nouă: `059_vm_support_components.up.sql`.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.34 \
      /usr/local/src/vm-doc-server-0.20.35

tar -xzf vm-doc-server-0.20.35-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.35

cd /usr/local/src/vm-doc-server-0.20.35
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Păstrează directorul `vendor/` complet din instalarea curentă. În mediul de lucru folosit pentru generarea acestui update, sursa 0.20.34 nu conținea directorul `vendor/`, de aceea testarea locală completă cu `-mod=vendor` nu a putut fi executată aici.

La prima pornire, serverul aplică automat migrarea 059. După restart folosește `Ctrl+F5` pentru `app.js?v=0.20.35`.

## Verificare funcțională

1. Deschide un VM cu agent și intră în **Inventar → Servicii**.
2. Bifează, de exemplu, `postgresql*.service` ca **Componentă suport**.
3. Verifică numele canonic `PostgreSQL`; lasă versiunea goală pentru detecție automată.
4. Dacă portul nu este dedus, completează `5432` sau valoarea reală și salvează.
5. Deschide **Rapoarte → Componente suport** și verifică gruparea Componentă → Versiune → Mediu.
6. Verifică exportul Excel.
