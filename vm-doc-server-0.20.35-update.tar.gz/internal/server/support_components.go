package server

import (
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/inventory"
)

func (a *App) setVMSupportComponent(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input inventory.SupportComponentInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Inventory.SaveSupportComponent(r.Context(), vmID, user.ID, input); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "vm.support_component.update", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{
		"service_name":     input.ServiceName,
		"component_name":   input.ComponentName,
		"version_override": input.VersionOverride,
		"port_override":    input.PortOverride,
		"enabled":          input.Enabled,
	})
	jsonResponse(w, http.StatusOK, map[string]any{"vm_id": vmID, "service_name": input.ServiceName, "enabled": input.Enabled})
}
