package server

import (
	"context"
	"net/http"
	"sort"
	"strings"
	"time"

	"vm-doc-server/internal/xlsx"
)

type supportComponentReportRow struct {
	ComponentName string `json:"component_name"`
	Version       string `json:"version"`
	Environment   string `json:"environment"`
	VMID          int64  `json:"vm_id"`
	VMName        string `json:"vm_name"`
	Hostname      string `json:"hostname"`
	IP            string `json:"ip"`
	Ports         string `json:"ports"`
	Services      string `json:"services"`
	AgentService  string `json:"agent_service"`
	SoftwareName  string `json:"software_name,omitempty"`
	Detected      bool   `json:"detected"`
	VersionSource string `json:"version_source,omitempty"`
}

type supportComponentReportSummary struct {
	Components    int `json:"components"`
	Versions      int `json:"versions"`
	Installations int `json:"installations"`
	VMs           int `json:"vms"`
}

type supportComponentReportResponse struct {
	GeneratedAt time.Time                     `json:"generated_at"`
	Summary     supportComponentReportSummary `json:"summary"`
	Rows        []supportComponentReportRow   `json:"support_components"`
}

type supportComponentVMSource struct {
	ID          int64
	Name        string
	Hostname    string
	Environment string
	IP          string
	Services    string
	Raw         []byte
}

func (a *App) reportsSupportComponents(w http.ResponseWriter, r *http.Request) {
	value, err := a.supportComponentReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	component := strings.TrimSpace(r.URL.Query().Get("component"))
	version := strings.TrimSpace(r.URL.Query().Get("version"))
	environment := strings.TrimSpace(r.URL.Query().Get("environment"))
	if q != "" || component != "" || version != "" || environment != "" {
		value.Rows = filterSupportComponentRows(value.Rows, q, component, version, environment)
		value.Summary = summarizeSupportComponentRows(value.Rows)
	}
	jsonResponse(w, http.StatusOK, value)
}

func (a *App) supportComponentReport(ctx context.Context) (supportComponentReportResponse, error) {
	out := supportComponentReportResponse{GeneratedAt: time.Now().UTC(), Rows: []supportComponentReportRow{}}
	rows, err := a.DB.QueryContext(ctx, `SELECT vm.id,vm.name,
		COALESCE(NULLIF(i.hostname,''),NULLIF(vm.guest_hostname,''),''),
		COALESCE(m.environment,''),
		COALESCE(NULLIF(m.preferred_ip,''),NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,''),''),
		COALESCE((SELECT GROUP_CONCAT(DISTINCT s.name ORDER BY s.name SEPARATOR ', ') FROM vm_internal_service_assignments a JOIN internal_services s ON s.id=a.internal_service_id AND s.active=1 WHERE a.vm_id=vm.id),''),
		COALESCE(i.raw_json,'')
		FROM virtual_machines vm
		JOIN (SELECT DISTINCT vm_id FROM vm_support_components) selected ON selected.vm_id=vm.id
		LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id
		LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id
		WHERE vm.retired=0
		ORDER BY LOWER(vm.name),vm.id`)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	sources := make([]supportComponentVMSource, 0)
	for rows.Next() {
		var item supportComponentVMSource
		if err := rows.Scan(&item.ID, &item.Name, &item.Hostname, &item.Environment, &item.IP, &item.Services, &item.Raw); err != nil {
			return out, err
		}
		sources = append(sources, item)
	}
	if err := rows.Err(); err != nil {
		return out, err
	}
	for _, source := range sources {
		components, err := a.Inventory.ListSupportComponents(ctx, source.ID, source.Raw)
		if err != nil {
			return out, err
		}
		for _, component := range components {
			out.Rows = append(out.Rows, supportComponentReportRow{
				ComponentName: strings.TrimSpace(component.ComponentName),
				Version:       strings.TrimSpace(component.EffectiveVersion),
				Environment:   strings.TrimSpace(source.Environment),
				VMID:          source.ID,
				VMName:        source.Name,
				Hostname:      source.Hostname,
				IP:            source.IP,
				Ports:         strings.TrimSpace(component.EffectivePorts),
				Services:      source.Services,
				AgentService:  component.ServiceName,
				SoftwareName:  component.SoftwareName,
				Detected:      component.Detected,
				VersionSource: component.VersionSource,
			})
		}
	}
	sortSupportComponentRows(out.Rows)
	out.Summary = summarizeSupportComponentRows(out.Rows)
	return out, nil
}

func sortSupportComponentRows(rows []supportComponentReportRow) {
	sort.SliceStable(rows, func(i, j int) bool {
		a, b := rows[i], rows[j]
		if c := strings.Compare(strings.ToLower(a.ComponentName), strings.ToLower(b.ComponentName)); c != 0 {
			return c < 0
		}
		av, bv := strings.ToLower(a.Version), strings.ToLower(b.Version)
		if av != bv {
			if av == "" {
				return false
			}
			if bv == "" {
				return true
			}
			return av < bv
		}
		ae, be := supportEnvironmentRank(a.Environment), supportEnvironmentRank(b.Environment)
		if ae != be {
			return ae < be
		}
		if strings.ToLower(a.Environment) != strings.ToLower(b.Environment) {
			return strings.ToLower(a.Environment) < strings.ToLower(b.Environment)
		}
		return strings.ToLower(a.VMName) < strings.ToLower(b.VMName)
	})
}

func supportEnvironmentRank(value string) int {
	switch strings.ToUpper(strings.TrimSpace(value)) {
	case "PROD", "PRODUCTION", "PRODUCTIE", "PRODUCȚIE":
		return 0
	case "TEST", "TST":
		return 1
	case "DEV", "DEVELOPMENT":
		return 2
	case "DR", "DISASTER RECOVERY":
		return 3
	case "":
		return 99
	default:
		return 10
	}
}

func summarizeSupportComponentRows(rows []supportComponentReportRow) supportComponentReportSummary {
	components := map[string]bool{}
	versions := map[string]bool{}
	vms := map[int64]bool{}
	for _, row := range rows {
		component := strings.ToLower(strings.TrimSpace(row.ComponentName))
		components[component] = true
		versions[component+"\x00"+strings.ToLower(strings.TrimSpace(row.Version))] = true
		vms[row.VMID] = true
	}
	return supportComponentReportSummary{Components: len(components), Versions: len(versions), Installations: len(rows), VMs: len(vms)}
}

func filterSupportComponentRows(rows []supportComponentReportRow, q, component, version, environment string) []supportComponentReportRow {
	q = strings.ToLower(strings.TrimSpace(q))
	component = strings.ToLower(strings.TrimSpace(component))
	version = strings.ToLower(strings.TrimSpace(version))
	environment = strings.ToLower(strings.TrimSpace(environment))
	out := make([]supportComponentReportRow, 0, len(rows))
	for _, row := range rows {
		if component != "" && strings.ToLower(row.ComponentName) != component {
			continue
		}
		if version != "" && strings.ToLower(row.Version) != version {
			continue
		}
		if environment != "" && strings.ToLower(row.Environment) != environment {
			continue
		}
		if q != "" {
			haystack := strings.ToLower(strings.Join([]string{row.ComponentName, row.Version, row.Environment, row.VMName, row.Hostname, row.IP, row.Ports, row.Services, row.AgentService, row.SoftwareName}, " "))
			if !strings.Contains(haystack, q) {
				continue
			}
		}
		out = append(out, row)
	}
	return out
}

func (a *App) exportReportSupportComponents(w http.ResponseWriter, r *http.Request) {
	value, err := a.supportComponentReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	items := filterSupportComponentRows(value.Rows, r.URL.Query().Get("q"), r.URL.Query().Get("component"), r.URL.Query().Get("version"), r.URL.Query().Get("environment"))
	rows := [][]xlsx.Cell{{
		xlsx.Text("Componentă"), xlsx.Text("Versiune"), xlsx.Text("Mediu"), xlsx.Text("Amplasare / VM"), xlsx.Text("Hostname"), xlsx.Text("IP"), xlsx.Text("Port(uri)"), xlsx.Text("Servicii / proiecte"), xlsx.Text("Serviciu agent"), xlsx.Text("Software detectat"), xlsx.Text("Detectat acum"),
	}}
	for _, item := range items {
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(item.ComponentName), xlsx.Text(item.Version), xlsx.Text(item.Environment), xlsx.Text(item.VMName), xlsx.Text(item.Hostname), xlsx.Text(item.IP), xlsx.Text(item.Ports), xlsx.Text(item.Services), xlsx.Text(item.AgentService), xlsx.Text(item.SoftwareName), xlsx.Text(yesNo(item.Detected)),
		})
	}
	if err := writeXLSXResponse(w, "Componente suport", "componente-suport", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write support components report XLSX", "error", err)
	}
}
