package inventory

import (
	"bytes"
	"context"
	"errors"
	"sort"
	"strings"
	"unicode"

	"vm-doc-server/internal/domain"
)

const (
	maxSupportComponentNameLength = 255
	maxSupportOverrideLength      = 255
)

type SupportComponentInput struct {
	ServiceName     string `json:"service_name"`
	ComponentName   string `json:"component_name"`
	VersionOverride string `json:"version_override"`
	PortOverride    string `json:"port_override"`
	Enabled         bool   `json:"enabled"`
}

func cleanSupportText(value string, max int) string {
	value = strings.TrimSpace(value)
	if len(value) > max {
		value = value[:max]
	}
	return value
}

// SaveSupportComponent marchează/demarchează un serviciu observat de agent ca
// tehnologie suport. Numele componentei este explicit și reprezintă cheia de
// grupare din raport (PostgreSQL, Redis, Keycloak etc.).
func (s Service) SaveSupportComponent(ctx context.Context, vmID, userID int64, in SupportComponentInput) error {
	if s.DB == nil {
		return errors.New("inventory database is unavailable")
	}
	serviceName := cleanSupportText(in.ServiceName, 255)
	if serviceName == "" {
		return errors.New("service_name is required")
	}
	if !in.Enabled {
		_, err := s.DB.ExecContext(ctx, `DELETE FROM vm_support_components WHERE vm_id=? AND service_name=?`, vmID, serviceName)
		return err
	}
	componentName := cleanSupportText(in.ComponentName, maxSupportComponentNameLength)
	if componentName == "" {
		componentName = GuessSupportComponentName(serviceName, "")
	}
	if componentName == "" {
		return errors.New("component_name is required")
	}
	versionOverride := cleanSupportText(in.VersionOverride, maxSupportOverrideLength)
	portOverride := cleanSupportText(in.PortOverride, maxSupportOverrideLength)
	_, err := s.DB.ExecContext(ctx, `INSERT INTO vm_support_components(vm_id,service_name,component_name,version_override,port_override,selected_by) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE component_name=VALUES(component_name),version_override=VALUES(version_override),port_override=VALUES(port_override),selected_by=VALUES(selected_by),updated_at=CURRENT_TIMESTAMP(6)`, vmID, serviceName, componentName, versionOverride, portOverride, userID)
	return err
}

// ListSupportComponents întoarce selecțiile persistente și le îmbogățește cu
// versiunea și porturile detectate în inventarul curent. Override-urile manuale
// au prioritate, dar valorile detectate rămân vizibile în UI.
func (s Service) ListSupportComponents(ctx context.Context, vmID int64, raw []byte) ([]domain.SupportComponent, error) {
	if s.DB == nil {
		return []domain.SupportComponent{}, nil
	}
	rows, err := s.DB.QueryContext(ctx, `SELECT id,vm_id,service_name,component_name,version_override,port_override FROM vm_support_components WHERE vm_id=? ORDER BY LOWER(component_name),LOWER(service_name)`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.SupportComponent, 0)
	for rows.Next() {
		var item domain.SupportComponent
		if err := rows.Scan(&item.ID, &item.VMID, &item.ServiceName, &item.ComponentName, &item.VersionOverride, &item.PortOverride); err != nil {
			return nil, err
		}
		out = append(out, item)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return EnrichSupportComponents(raw, out), nil
}

// EnrichSupportComponents nu accesează DB și este reutilizat de rapoarte.
func EnrichSupportComponents(raw []byte, values []domain.SupportComponent) []domain.SupportComponent {
	observedServices, _ := parseAgentServices(raw)
	observedPorts, _ := parseAgentPorts(raw)
	for i := range values {
		item := &values[i]
		observed, ok := observedServices[strings.ToLower(strings.TrimSpace(item.ServiceName))]
		if ok {
			item.Detected = true
			item.SoftwareName = observed.SoftwareName
			item.VersionSource = observed.VersionSource
			item.DetectedVersion = firstSupportValue(observed.Version, observed.PackageVersion)
		}
		if strings.TrimSpace(item.ComponentName) == "" {
			item.ComponentName = GuessSupportComponentName(item.ServiceName, observed.SoftwareName)
		}
		item.DetectedPorts = detectSupportComponentPorts(*item, observed, observedPorts)
		item.EffectiveVersion = firstSupportValue(item.VersionOverride, item.DetectedVersion)
		item.EffectivePorts = firstSupportValue(item.PortOverride, item.DetectedPorts)
	}
	return values
}

func firstSupportValue(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}

// GuessSupportComponentName normalizează denumirile uzuale, dar păstrează un
// fallback generic pentru tehnologii noi pe care serverul nu le cunoaște încă.
func GuessSupportComponentName(serviceName, softwareName string) string {
	joined := strings.ToLower(strings.TrimSpace(serviceName + " " + softwareName))
	known := []struct {
		needles []string
		name    string
	}{
		{[]string{"postgresql", "postgres"}, "PostgreSQL"},
		{[]string{"redis"}, "Redis"},
		{[]string{"meilisearch"}, "Meilisearch"},
		{[]string{"minio"}, "MinIO"},
		{[]string{"docmosis"}, "Docmosis"},
		{[]string{"sentry"}, "Sentry"},
		{[]string{"keycloak"}, "Keycloak"},
		{[]string{"mariadb"}, "MariaDB"},
		{[]string{"mysql"}, "MySQL"},
		{[]string{"mongodb", "mongod"}, "MongoDB"},
		{[]string{"rabbitmq"}, "RabbitMQ"},
		{[]string{"elasticsearch"}, "Elasticsearch"},
		{[]string{"opensearch"}, "OpenSearch"},
		{[]string{"zookeeper"}, "ZooKeeper"},
		{[]string{"kafka"}, "Kafka"},
		{[]string{"graylog"}, "Graylog"},
		{[]string{"vault"}, "Vault"},
		{[]string{"consul"}, "Consul"},
		{[]string{"prometheus"}, "Prometheus"},
		{[]string{"grafana"}, "Grafana"},
		{[]string{"haproxy"}, "HAProxy"},
		{[]string{"nginx"}, "Nginx"},
		{[]string{"httpd", "apache"}, "Apache HTTP Server"},
		{[]string{"tomcat"}, "Tomcat"},
		{[]string{"solr"}, "Solr"},
	}
	for _, entry := range known {
		for _, needle := range entry.needles {
			if strings.Contains(joined, needle) {
				return entry.name
			}
		}
	}
	if strings.TrimSpace(softwareName) != "" {
		return strings.TrimSpace(softwareName)
	}
	base := strings.TrimSpace(serviceName)
	base = strings.TrimSuffix(base, ".service")
	if at := strings.Index(base, "@"); at > 0 {
		base = base[:at]
	}
	base = strings.Trim(base, "-_ .")
	if base == "" {
		return "Componentă suport"
	}
	return strings.ToUpper(base[:1]) + base[1:]
}

func detectSupportComponentPorts(component domain.SupportComponent, service domain.PrimaryAgentService, observed map[string]domain.PrimaryAgentPort) string {
	aliases := supportAliases(component.ComponentName, component.ServiceName, service.SoftwareName, service.PackageName)
	found := make([]domain.PrimaryAgentPort, 0)
	for _, port := range observed {
		haystack := normalizeSupportToken(strings.Join([]string{port.ProcessName, port.Executable}, " "))
		if haystack == "" {
			continue
		}
		matched := false
		for _, alias := range aliases {
			if len(alias) >= 4 && strings.Contains(haystack, alias) {
				matched = true
				break
			}
		}
		if matched {
			found = append(found, port)
		}
	}
	sort.SliceStable(found, func(i, j int) bool {
		if found[i].Port != found[j].Port {
			return found[i].Port < found[j].Port
		}
		return found[i].Protocol < found[j].Protocol
	})
	parts := make([]string, 0, len(found))
	seen := map[string]bool{}
	for _, port := range found {
		label := strings.TrimSpace(strings.Join([]string{itoaSupport(port.Port), strings.ToUpper(port.Protocol)}, "/"))
		if !seen[label] {
			seen[label] = true
			parts = append(parts, label)
		}
	}
	return strings.Join(parts, ", ")
}

func itoaSupport(value int) string {
	if value <= 0 {
		return ""
	}
	// small local conversion avoids another public dependency/helper.
	digits := [20]byte{}
	i := len(digits)
	for value > 0 {
		i--
		digits[i] = byte('0' + value%10)
		value /= 10
	}
	return string(digits[i:])
}

func supportAliases(values ...string) []string {
	seen := map[string]bool{}
	out := make([]string, 0)
	for _, value := range values {
		n := normalizeSupportToken(value)
		if n == "" {
			continue
		}
		candidates := []string{n}
		if strings.Contains(n, "postgresql") {
			candidates = append(candidates, "postgres")
		}
		if strings.Contains(n, "redisserver") {
			candidates = append(candidates, "redis")
		}
		for _, candidate := range candidates {
			if !seen[candidate] {
				seen[candidate] = true
				out = append(out, candidate)
			}
		}
	}
	return out
}

func normalizeSupportToken(value string) string {
	var b bytes.Buffer
	for _, r := range strings.ToLower(value) {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			b.WriteRune(r)
		}
	}
	return b.String()
}
