package inventory

import (
	"testing"

	"vm-doc-server/internal/domain"
)

func TestGuessSupportComponentName(t *testing.T) {
	cases := map[string]string{
		"postgresql-14.service": "PostgreSQL",
		"redis-server.service":  "Redis",
		"meilisearch.service":   "Meilisearch",
		"minio.service":         "MinIO",
		"docmosis.service":      "Docmosis",
		"sentry-web.service":    "Sentry",
		"keycloak.service":      "Keycloak",
	}
	for service, want := range cases {
		if got := GuessSupportComponentName(service, ""); got != want {
			t.Fatalf("%s: got %q want %q", service, got, want)
		}
	}
}

func TestEnrichSupportComponentsUsesDetectedVersionAndMatchingPort(t *testing.T) {
	raw := []byte(`{
		"services":[{"name":"postgresql-14.service","software_name":"PostgreSQL","version":"14.12","package_version":"14.12-1","version_source":"postgres --version"}],
		"listening_ports":[{"address":"0.0.0.0","port":5432,"protocol":"tcp","processes":[{"pid":123,"name":"postgres","executable":"/usr/lib/postgresql/14/bin/postgres"}]}]
	}`)
	values := EnrichSupportComponents(raw, []domain.SupportComponent{{ServiceName: "postgresql-14.service", ComponentName: "PostgreSQL"}})
	if len(values) != 1 {
		t.Fatalf("got %d values", len(values))
	}
	got := values[0]
	if !got.Detected || got.EffectiveVersion != "14.12" || got.EffectivePorts != "5432/TCP" {
		t.Fatalf("unexpected enriched value: %#v", got)
	}
}

func TestEnrichSupportComponentsOverridesWin(t *testing.T) {
	raw := []byte(`{"services":[{"name":"keycloak.service","software_name":"Keycloak","version":"26.5.7"}]}`)
	values := EnrichSupportComponents(raw, []domain.SupportComponent{{ServiceName: "keycloak.service", ComponentName: "Keycloak", VersionOverride: "26.5.8-custom", PortOverride: "8443"}})
	got := values[0]
	if got.EffectiveVersion != "26.5.8-custom" || got.EffectivePorts != "8443" {
		t.Fatalf("override not applied: %#v", got)
	}
}
