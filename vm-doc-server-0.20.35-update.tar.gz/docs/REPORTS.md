# Rapoarte

Meniul **Rapoarte** oferă o vedere agregată asupra infrastructurii, a Serviciilor interne și a gradului de documentare. Graficele sunt randate direct de interfața vm-doc-server și nu necesită biblioteci JavaScript externe sau acces la Internet.

## Indicatori principali

- VM-uri active și pornite;
- servicii active și critice;
- VM-uri fără mediu, fără serviciu și fără fișă tehnică;
- servicii fără fișă generată.

## Infrastructură VM

- power state;
- medii PROD / TEST / UAT / DEV;
- status operațional;
- acoperire și stare agent;
- protecție backup;
- prospețime inventar;
- acoperire cu fișe tehnice;
- dimensionare vCPU și RAM;
- sisteme de operare;
- distribuție pe surse vCenter;
- versiuni hardware VM.

## Servicii interne

- criticitate;
- status documentație;
- acoperire cu fișe de serviciu;
- tipuri de soluție și servicii cu tehnologie mixtă;
- număr de VM-uri per serviciu;
- medii în care sunt prezente serviciile;
- tip de utilizare dedicat / partajat / dependență;
- asociere principală / secundară;
- completitudinea asocierilor (layer, rol tehnic, tip soluție);
- distribuție pe domenii și categorii;
- utilizare layer-e și roluri tehnice;
- servicii cu cele mai multe VM-uri.

## Documentație și calitatea datelor

- timeline al fișelor VM și fișelor de serviciu generate în ultimele 30 de zile;
- servicii cu Scop și domeniu, Obiective, mediu, VM sau fișă lipsă;
- VM-uri cu mediu, inventar, serviciu, fișă sau agent lipsă.

Rapoartele folosesc datele operaționale curente și sunt destinate atât verificării documentației, cât și identificării rapide a zonelor care necesită completare.

## Servicii comune și impact (0.9.0)

Rapoartele includ:

- numărul serviciilor comune și globale;
- distribuția serviciilor comune vs. globale implicit;
- tipurile de dependență folosite;
- numărul serviciilor dependente pentru fiecare serviciu comun;
- numărul VM-urilor potențial afectate de indisponibilitatea unui serviciu comun.

Pentru un serviciu `Global implicit`, impactul la nivel de serviciu include toate celelalte servicii active. Pentru un serviciu comun normal sunt folosite relațiile declarate explicit.

Impactul VM pentru un serviciu comun include și excepțiile declarate direct prin `VM → Serviciu comun`, fără a dubla VM-urile deja afectate prin relațiile serviciului lor.

## Navigare 0.11.0

Pagina Rapoarte este împărțită în: Prezentare generală, VM & resurse, Agenți & inventar, Servicii & arhitectură, Software principal, Dependențe & impact și Documentație. Datele provin din același endpoint agregat, dar interfața încarcă vizual numai categoria selectată.

Raportul Software principal folosește selecțiile persistente din `vm_primary_agent_services`.

## 0.13.0 - inventar și conectivitate externă

În **Agenți & inventar** sunt afișate numărul de snapshot-uri, mărimea payloadurilor JSON, mărimea tabelului/indexurilor și agenții cu cel mai mare consum.

Rapoartele de dependențe includ distribuția sistemelor externe pe rețele și niveluri de risc. Indicatorii generali includ numărul de rețele, sisteme și conexiuni externe active.
## 0.20.23 - persoane și lipsuri operaționale

Categoria **Persoane & responsabilități** prezintă câte un rând pentru fiecare combinație persoană / VM / tip de responsabilitate. Sunt disponibile filtre după text, rol, departament și mediu, iar exportul Excel păstrează aceeași structură pentru filtrare ulterioară.

Categoria **Lipsuri operaționale** funcționează ca listă de lucru pentru VM-uri și semnalează: lipsă responsabil, serviciu sau mediu, lipsă agent, agent offline, inventar lipsă ori mai vechi de 7 zile, backup neacoperit, lipsă target de monitorizare, lipsă baseline și lipsă fișă VM. Raportul poate fi filtrat după fiecare tip de problemă și exportat în Excel.


## 0.20.24 - integrare cu dashboardul operațional

Dashboardul poate deschide direct **Lipsuri operaționale** cu filtrul relevant pentru inventar vechi, backup, monitorizare, responsabilități, servicii, mediu, baseline sau fișa VM.

Filtrul nou **Documentație incompletă** grupează VM-urile care au cel puțin una dintre lipsurile: responsabil, serviciu, mediu, baseline sau fișă VM. Același filtru este respectat de exportul Excel.

Indicatorii de acoperire de pe prima pagină folosesc aceleași surse de date ca rapoartele: asociere serviciu, responsabilități, backup, targeturi de monitorizare, baseline și documente generate.

## Componente suport (0.20.35)

Serviciile observate de agent pot fi marcate pe fiecare VM drept **Componentă suport**. Raportul dedicat grupează instalările în ordinea **Componentă → Versiune → Mediu** și afișează amplasarea/VM-ul, hostname-ul, IP-ul preferat, porturile, serviciile/proiectele asociate și serviciul tehnic detectat de agent. Versiunea este preluată din inventarul curent, iar versiunea/porturile pot fi suprascrise manual atunci când detecția automată nu este suficientă. Raportul poate fi filtrat și exportat în Excel.
