# Upgrade vm-doc-server 0.20.19 → 0.20.20

## Ce se schimbă

0.20.20 completează mecanismul HA / cluster introdus în 0.20.19.

Pe lângă serviciile/rolurile VM și documentația operațională, un membru poate moșteni acum și **documentarea logică a resurselor Docker / baze de date / Web** de la VM-ul sursă.

Inventarul tehnic nu este copiat. VM-DOC caută o resursă echivalentă deja detectată pe membru și propagă doar metadatele de documentare/asocierile.

## Migrare DB

La pornire se aplică automat:

```text
054_vm_resource_inheritance.up.sql
```

Migrarea adaugă coloana:

```text
vm_documentation_inheritance.inherit_resource_assignments
```

Relațiile HA create în 0.20.19 rămân valide; moștenirea Docker/DB/Web este inițial dezactivată pentru acestea și poate fi activată din UI.

## Instalare offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.19 \
      /usr/local/src/vm-doc-server-0.20.20

tar -xzf vm-doc-server-0.20.20-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.20

cd /usr/local/src/vm-doc-server-0.20.20

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Înlocuiește binarul și repornește `vm-doc-server`. Migrarea este executată la startup.

## Verificare recomandată – două LB-uri

Exemplu `LB01` (sursă) și `LB02` (membru):

1. Ambele VM-uri trebuie să aibă inventarul propriu colectat.
2. Pe `LB01`, asociază frontend-urile HAProxy/Web, bazele sau containerele cu proiectul/serviciul dorit.
3. Deschide `LB02 → Configurare → Servicii → Cluster / grup HA`.
4. Selectează `LB01` ca sursă și bifează:
   - Moștenește servicii, clasificare, layer, rol și tip soluție;
   - Moștenește documentația operațională comună;
   - Moștenește asocierile și documentarea Docker / DB / Web.
5. Salvează grupul HA.
6. Deschide pe `LB02` filele Docker, Baze de date și Web. Inventarul trebuie să fie cel al LB02, iar resursele echivalente trebuie să aibă asocierile/documentarea de pe LB01.
7. Modifică apoi o asociere pe LB01 și verifică actualizarea LB02.

Dacă o resursă nu există pe LB02 sau potrivirea nu este unică, VM-DOC nu inventează și nu suprascrie o resursă arbitrară.

## UI

Zona `VM → Configurare` are padding suplimentar pe desktop și mobil.

## Agent

`vm-doc-agent 1.7.9` rămâne neschimbat.
