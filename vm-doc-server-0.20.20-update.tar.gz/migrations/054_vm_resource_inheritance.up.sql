-- 0.20.20 · moștenire documentație/asocieri resurse aplicație pentru noduri HA / cluster.
-- Inventarul tehnic Docker/DB/Web rămâne local; se propagă doar metadatele de documentare
-- și asocierile către serviciile interne pentru resurse potrivite univoc pe VM-ul membru.
ALTER TABLE vm_documentation_inheritance
  ADD COLUMN inherit_resource_assignments TINYINT(1) NOT NULL DEFAULT 0 AFTER inherit_operational_metadata;
