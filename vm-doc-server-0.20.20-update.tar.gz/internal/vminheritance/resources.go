package vminheritance

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
)

// ResourceSyncResult summarizes logical documentation/resource mappings copied
// between HA/cluster members. It never copies technical inventory rows.
type ResourceSyncResult struct {
	DockerMatched     int `json:"docker_matched"`
	DockerUnmatched   int `json:"docker_unmatched"`
	DatabaseMatched   int `json:"database_matched"`
	DatabaseUnmatched int `json:"database_unmatched"`
	DatabaseCatalogs  int `json:"database_catalogs_matched"`
	WebMatched        int `json:"web_matched"`
	WebUnmatched      int `json:"web_unmatched"`
}

func normalize(value string) string { return strings.ToLower(strings.TrimSpace(value)) }

func uniqueLookup(index map[string][]int64, key string, used map[int64]bool) (int64, bool) {
	key = strings.TrimSpace(key)
	if key == "" {
		return 0, false
	}
	candidate := int64(0)
	for _, id := range index[key] {
		if used[id] {
			continue
		}
		if candidate != 0 {
			return 0, false
		}
		candidate = id
	}
	return candidate, candidate != 0
}

func addIndex(index map[string][]int64, key string, id int64) {
	if key = strings.TrimSpace(key); key != "" && id > 0 {
		index[key] = append(index[key], id)
	}
}

type dockerResource struct {
	ID             int64
	IdentityKey    string
	Name           string
	ComposeProject string
	ComposeService string
	Exempt         bool
}

func dockerKeys(v dockerResource) []string {
	keys := make([]string, 0, 3)
	if p, s := normalize(v.ComposeProject), normalize(v.ComposeService); p != "" && s != "" {
		keys = append(keys, "compose|"+p+"|"+s)
	}
	if identity := normalize(v.IdentityKey); identity != "" {
		keys = append(keys, "identity|"+identity)
	}
	if name := normalize(v.Name); name != "" {
		keys = append(keys, "name|"+name)
	}
	return keys
}

func loadDockerResources(ctx context.Context, tx *sql.Tx, vmID int64) ([]dockerResource, error) {
	rows, err := tx.QueryContext(ctx, `SELECT id,identity_key,name,compose_project,compose_service,documentation_exempt FROM docker_containers WHERE vm_id=? AND present=1 ORDER BY id`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]dockerResource, 0)
	for rows.Next() {
		var value dockerResource
		if err := rows.Scan(&value.ID, &value.IdentityKey, &value.Name, &value.ComposeProject, &value.ComposeService, &value.Exempt); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func copyDockerAssignments(ctx context.Context, tx *sql.Tx, sourceID, targetID int64) error {
	if _, err := tx.ExecContext(ctx, `DELETE FROM docker_container_service_assignments WHERE docker_container_id=? AND assignment_source='manual'`, targetID); err != nil {
		return err
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO docker_container_service_assignments(docker_container_id,internal_service_id,environment_id,operational_status_id,solution_type_id,assignment_source,component_name,role_name,notes,created_by,updated_by)
		SELECT ?,internal_service_id,environment_id,operational_status_id,solution_type_id,'manual',component_name,role_name,notes,created_by,updated_by
		FROM docker_container_service_assignments WHERE docker_container_id=? AND assignment_source='manual'`, targetID, sourceID)
	return err
}

func syncDocker(ctx context.Context, tx *sql.Tx, sourceVMID, targetVMID int64) (matched, unmatched int, err error) {
	if _, err = tx.ExecContext(ctx, `UPDATE docker_hosts target JOIN docker_hosts source ON source.vm_id=? SET target.documentation_exempt=source.documentation_exempt WHERE target.vm_id=?`, sourceVMID, targetVMID); err != nil {
		return 0, 0, err
	}
	sources, err := loadDockerResources(ctx, tx, sourceVMID)
	if err != nil {
		return 0, 0, err
	}
	targets, err := loadDockerResources(ctx, tx, targetVMID)
	if err != nil {
		return 0, 0, err
	}
	index := map[string][]int64{}
	for _, target := range targets {
		for _, key := range dockerKeys(target) {
			addIndex(index, key, target.ID)
		}
	}
	used := map[int64]bool{}
	for _, source := range sources {
		var targetID int64
		var ok bool
		for _, key := range dockerKeys(source) {
			if targetID, ok = uniqueLookup(index, key, used); ok {
				break
			}
		}
		if !ok {
			unmatched++
			continue
		}
		used[targetID] = true
		matched++
		if _, err := tx.ExecContext(ctx, `UPDATE docker_containers SET documentation_exempt=? WHERE id=?`, source.Exempt, targetID); err != nil {
			return matched, unmatched, err
		}
		if err := copyDockerAssignments(ctx, tx, source.ID, targetID); err != nil {
			return matched, unmatched, err
		}
	}
	return matched, unmatched, nil
}

type databaseInstance struct {
	ID           int64
	IdentityKey  string
	Engine       string
	InstanceName string
	ServiceName  string
	Endpoints    string
	Exempt       bool
}

func firstEndpointPort(raw string) string {
	if strings.TrimSpace(raw) == "" {
		return ""
	}
	var values []map[string]any
	if err := json.Unmarshal([]byte(raw), &values); err != nil {
		return ""
	}
	for _, item := range values {
		switch v := item["port"].(type) {
		case float64:
			if v > 0 {
				return strconv.Itoa(int(v))
			}
		case string:
			if value := strings.TrimSpace(v); value != "" && value != "0" {
				return value
			}
		}
	}
	return ""
}

func databaseInstanceKeys(v databaseInstance) []string {
	engine, name, service, port := normalize(v.Engine), normalize(v.InstanceName), normalize(v.ServiceName), firstEndpointPort(v.Endpoints)
	keys := make([]string, 0, 5)
	if identity := normalize(v.IdentityKey); identity != "" {
		keys = append(keys, "identity|"+identity)
	}
	if engine != "" && name != "" && port != "" {
		keys = append(keys, "engine-name-port|"+engine+"|"+name+"|"+port)
	}
	if engine != "" && name != "" {
		keys = append(keys, "engine-name|"+engine+"|"+name)
	}
	if engine != "" && service != "" {
		keys = append(keys, "engine-service|"+engine+"|"+service)
	}
	if engine != "" && port != "" {
		keys = append(keys, "engine-port|"+engine+"|"+port)
	}
	return keys
}

func loadDatabaseInstances(ctx context.Context, tx *sql.Tx, vmID int64) ([]databaseInstance, error) {
	rows, err := tx.QueryContext(ctx, `SELECT id,identity_key,engine,instance_name,service_name,COALESCE(endpoints_json,''),documentation_exempt FROM database_instances WHERE vm_id=? AND present=1 ORDER BY id`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]databaseInstance, 0)
	for rows.Next() {
		var value databaseInstance
		if err := rows.Scan(&value.ID, &value.IdentityKey, &value.Engine, &value.InstanceName, &value.ServiceName, &value.Endpoints, &value.Exempt); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func copyDatabaseInstanceAssignments(ctx context.Context, tx *sql.Tx, sourceID, targetID int64) error {
	if _, err := tx.ExecContext(ctx, `DELETE FROM database_instance_service_assignments WHERE database_instance_id=?`, targetID); err != nil {
		return err
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO database_instance_service_assignments(database_instance_id,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by)
		SELECT ?,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by
		FROM database_instance_service_assignments WHERE database_instance_id=?`, targetID, sourceID)
	return err
}

type databaseCatalog struct {
	ID         int64
	InstanceID int64
	Name       string
	Kind       string
	Exempt     bool
}

func loadDatabaseCatalogs(ctx context.Context, tx *sql.Tx, vmID int64) ([]databaseCatalog, error) {
	rows, err := tx.QueryContext(ctx, `SELECT id,database_instance_id,name,catalog_kind,documentation_exempt FROM database_catalogs WHERE vm_id=? AND present=1 ORDER BY id`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]databaseCatalog, 0)
	for rows.Next() {
		var value databaseCatalog
		if err := rows.Scan(&value.ID, &value.InstanceID, &value.Name, &value.Kind, &value.Exempt); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func catalogKey(v databaseCatalog) string { return normalize(v.Kind) + "|" + normalize(v.Name) }

func copyDatabaseCatalogAssignments(ctx context.Context, tx *sql.Tx, sourceID, targetID int64) error {
	if _, err := tx.ExecContext(ctx, `DELETE FROM database_catalog_service_assignments WHERE database_catalog_id=?`, targetID); err != nil {
		return err
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO database_catalog_service_assignments(database_catalog_id,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by)
		SELECT ?,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by
		FROM database_catalog_service_assignments WHERE database_catalog_id=?`, targetID, sourceID)
	return err
}

func syncDatabase(ctx context.Context, tx *sql.Tx, sourceVMID, targetVMID int64) (matched, unmatched, catalogsMatched int, err error) {
	sources, err := loadDatabaseInstances(ctx, tx, sourceVMID)
	if err != nil {
		return 0, 0, 0, err
	}
	targets, err := loadDatabaseInstances(ctx, tx, targetVMID)
	if err != nil {
		return 0, 0, 0, err
	}
	index := map[string][]int64{}
	for _, target := range targets {
		for _, key := range databaseInstanceKeys(target) {
			addIndex(index, key, target.ID)
		}
	}
	used := map[int64]bool{}
	instancePairs := map[int64]int64{}
	for _, source := range sources {
		var targetID int64
		var ok bool
		for _, key := range databaseInstanceKeys(source) {
			if targetID, ok = uniqueLookup(index, key, used); ok {
				break
			}
		}
		if !ok {
			unmatched++
			continue
		}
		used[targetID] = true
		matched++
		instancePairs[source.ID] = targetID
		if _, err := tx.ExecContext(ctx, `UPDATE database_instances SET documentation_exempt=? WHERE id=?`, source.Exempt, targetID); err != nil {
			return matched, unmatched, catalogsMatched, err
		}
		if err := copyDatabaseInstanceAssignments(ctx, tx, source.ID, targetID); err != nil {
			return matched, unmatched, catalogsMatched, err
		}
	}

	sourceCatalogs, err := loadDatabaseCatalogs(ctx, tx, sourceVMID)
	if err != nil {
		return matched, unmatched, catalogsMatched, err
	}
	targetCatalogs, err := loadDatabaseCatalogs(ctx, tx, targetVMID)
	if err != nil {
		return matched, unmatched, catalogsMatched, err
	}
	targetCatalogIndex := map[int64]map[string][]int64{}
	for _, target := range targetCatalogs {
		if targetCatalogIndex[target.InstanceID] == nil {
			targetCatalogIndex[target.InstanceID] = map[string][]int64{}
		}
		addIndex(targetCatalogIndex[target.InstanceID], catalogKey(target), target.ID)
	}
	usedCatalogs := map[int64]bool{}
	for _, source := range sourceCatalogs {
		targetInstanceID, ok := instancePairs[source.InstanceID]
		if !ok {
			continue
		}
		targetID, ok := uniqueLookup(targetCatalogIndex[targetInstanceID], catalogKey(source), usedCatalogs)
		if !ok {
			continue
		}
		usedCatalogs[targetID] = true
		catalogsMatched++
		if _, err := tx.ExecContext(ctx, `UPDATE database_catalogs SET documentation_exempt=? WHERE id=?`, source.Exempt, targetID); err != nil {
			return matched, unmatched, catalogsMatched, err
		}
		if err := copyDatabaseCatalogAssignments(ctx, tx, source.ID, targetID); err != nil {
			return matched, unmatched, catalogsMatched, err
		}
	}
	return matched, unmatched, catalogsMatched, nil
}

type webSite struct {
	ID          int64
	IdentityKey string
	Engine      string
	SiteType    string
	Name        string
	Exempt      bool
}

func webSiteKeys(v webSite) []string {
	engine, kind, name := normalize(v.Engine), normalize(v.SiteType), normalize(v.Name)
	keys := make([]string, 0, 3)
	if engine != "" && kind != "" && name != "" {
		keys = append(keys, "engine-kind-name|"+engine+"|"+kind+"|"+name)
	}
	if engine != "" && name != "" {
		keys = append(keys, "engine-name|"+engine+"|"+name)
	}
	if identity := normalize(v.IdentityKey); identity != "" {
		keys = append(keys, "identity|"+identity)
	}
	return keys
}

func loadWebSites(ctx context.Context, tx *sql.Tx, vmID int64) ([]webSite, error) {
	rows, err := tx.QueryContext(ctx, `SELECT id,identity_key,engine,site_type,name,documentation_exempt FROM web_sites WHERE vm_id=? AND present=1 ORDER BY id`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]webSite, 0)
	for rows.Next() {
		var value webSite
		if err := rows.Scan(&value.ID, &value.IdentityKey, &value.Engine, &value.SiteType, &value.Name, &value.Exempt); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func copyWebAssignments(ctx context.Context, tx *sql.Tx, sourceID, targetID int64) error {
	if _, err := tx.ExecContext(ctx, `DELETE FROM web_site_service_assignments WHERE web_site_id=?`, targetID); err != nil {
		return err
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO web_site_service_assignments(web_site_id,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by)
		SELECT ?,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by
		FROM web_site_service_assignments WHERE web_site_id=?`, targetID, sourceID)
	return err
}

func syncWeb(ctx context.Context, tx *sql.Tx, sourceVMID, targetVMID int64) (matched, unmatched int, err error) {
	if _, err = tx.ExecContext(ctx, `UPDATE web_servers target JOIN web_servers source ON source.vm_id=? AND target.vm_id=? AND target.engine=source.engine AND target.present=1 AND source.present=1 SET target.documentation_exempt=source.documentation_exempt`, sourceVMID, targetVMID); err != nil {
		return 0, 0, err
	}
	sources, err := loadWebSites(ctx, tx, sourceVMID)
	if err != nil {
		return 0, 0, err
	}
	targets, err := loadWebSites(ctx, tx, targetVMID)
	if err != nil {
		return 0, 0, err
	}
	index := map[string][]int64{}
	for _, target := range targets {
		for _, key := range webSiteKeys(target) {
			addIndex(index, key, target.ID)
		}
	}
	used := map[int64]bool{}
	for _, source := range sources {
		var targetID int64
		var ok bool
		for _, key := range webSiteKeys(source) {
			if targetID, ok = uniqueLookup(index, key, used); ok {
				break
			}
		}
		if !ok {
			unmatched++
			continue
		}
		used[targetID] = true
		matched++
		if _, err := tx.ExecContext(ctx, `UPDATE web_sites SET documentation_exempt=? WHERE id=?`, source.Exempt, targetID); err != nil {
			return matched, unmatched, err
		}
		if err := copyWebAssignments(ctx, tx, source.ID, targetID); err != nil {
			return matched, unmatched, err
		}
	}
	return matched, unmatched, nil
}

// SyncResourcesFromSourceTx mirrors documentation metadata and logical service
// mappings only for resources that can be matched unambiguously on the target.
// Technical inventory rows are never created or copied.
func SyncResourcesFromSourceTx(ctx context.Context, tx *sql.Tx, sourceVMID, targetVMID int64) (ResourceSyncResult, error) {
	var result ResourceSyncResult
	if tx == nil || sourceVMID <= 0 || targetVMID <= 0 || sourceVMID == targetVMID {
		return result, errors.New("invalid source/target VM for resource inheritance")
	}
	var err error
	result.DockerMatched, result.DockerUnmatched, err = syncDocker(ctx, tx, sourceVMID, targetVMID)
	if err != nil {
		return result, fmt.Errorf("sync inherited Docker resources: %w", err)
	}
	result.DatabaseMatched, result.DatabaseUnmatched, result.DatabaseCatalogs, err = syncDatabase(ctx, tx, sourceVMID, targetVMID)
	if err != nil {
		return result, fmt.Errorf("sync inherited database resources: %w", err)
	}
	result.WebMatched, result.WebUnmatched, err = syncWeb(ctx, tx, sourceVMID, targetVMID)
	if err != nil {
		return result, fmt.Errorf("sync inherited web resources: %w", err)
	}
	return result, nil
}

func childVMs(ctx context.Context, tx *sql.Tx, sourceVMID int64) ([]int64, error) {
	rows, err := tx.QueryContext(ctx, `SELECT vm_id FROM vm_documentation_inheritance WHERE source_vm_id=? AND inherit_resource_assignments=1 ORDER BY vm_id`, sourceVMID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]int64, 0)
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		out = append(out, id)
	}
	return out, rows.Err()
}

func SyncResourcesToChildrenTx(ctx context.Context, tx *sql.Tx, sourceVMID int64) error {
	children, err := childVMs(ctx, tx, sourceVMID)
	if err != nil {
		return err
	}
	for _, childID := range children {
		if _, err := SyncResourcesFromSourceTx(ctx, tx, sourceVMID, childID); err != nil {
			return err
		}
	}
	return nil
}

// SyncResourcesForInventoryTx is called after a VM receives fresh technical
// inventory. If it is a member, newly discovered matching resources inherit
// metadata from its source. If it is a source, newly discovered source
// resources are propagated to all members.
func SyncResourcesForInventoryTx(ctx context.Context, tx *sql.Tx, vmID int64) error {
	if tx == nil || vmID <= 0 {
		return nil
	}
	var sourceID int64
	err := tx.QueryRowContext(ctx, `SELECT source_vm_id FROM vm_documentation_inheritance WHERE vm_id=? AND inherit_resource_assignments=1`, vmID).Scan(&sourceID)
	if err == nil {
		if _, err := SyncResourcesFromSourceTx(ctx, tx, sourceID, vmID); err != nil {
			return err
		}
	} else if !errors.Is(err, sql.ErrNoRows) {
		return err
	}
	return SyncResourcesToChildrenTx(ctx, tx, vmID)
}
