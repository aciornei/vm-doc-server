package vminheritance

import "testing"

func TestDockerKeysPreferCompose(t *testing.T) {
	keys := dockerKeys(dockerResource{IdentityKey: "abc", Name: "lb", ComposeProject: "Portal", ComposeService: "Proxy"})
	if len(keys) < 1 || keys[0] != "compose|portal|proxy" {
		t.Fatalf("unexpected docker keys: %#v", keys)
	}
}

func TestDatabaseInstanceKeysContainEngineNamePort(t *testing.T) {
	keys := databaseInstanceKeys(databaseInstance{Engine: "postgresql", InstanceName: "main", Endpoints: `[{"port":5432}]`})
	found := false
	for _, key := range keys {
		if key == "engine-name-port|postgresql|main|5432" {
			found = true
		}
	}
	if !found {
		t.Fatalf("missing engine/name/port key: %#v", keys)
	}
}

func TestUniqueLookupRejectsAmbiguousTargets(t *testing.T) {
	index := map[string][]int64{"x": {2, 3}}
	if id, ok := uniqueLookup(index, "x", map[int64]bool{}); ok || id != 0 {
		t.Fatalf("ambiguous match should be rejected, got id=%d ok=%v", id, ok)
	}
}
