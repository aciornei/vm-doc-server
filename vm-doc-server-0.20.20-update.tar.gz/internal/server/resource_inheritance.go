package server

import (
	"context"
	"errors"
)

func (a *App) ensureResourceDocumentationWritable(ctx context.Context, vmID int64) error {
	if a == nil || a.DB == nil || vmID <= 0 {
		return nil
	}
	var inherited int
	if err := a.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM vm_documentation_inheritance WHERE vm_id=? AND inherit_resource_assignments=1`, vmID).Scan(&inherited); err != nil {
		return err
	}
	if inherited > 0 {
		return errors.New("Docker/DB/Web documentation is inherited from the HA/cluster source; edit the source VM or disable resource inheritance")
	}
	return nil
}

func (a *App) propagateInheritedResourceDocumentation(ctx context.Context, sourceVMID int64) error {
	if a == nil || a.VCenter == nil || sourceVMID <= 0 {
		return nil
	}
	return a.VCenter.SyncInheritedResourceAssignments(ctx, sourceVMID)
}
