package server

import (
	"errors"
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/webinventory"
)

type webAssignmentsRequest struct {
	Assignments []webinventory.AssignmentInput `json:"assignments"`
}

func (a *App) getVMWebInventory(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	view, err := a.Web.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) replaceWebSiteServices(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	if err := a.ensureResourceDocumentationWritable(r.Context(), vmID); err != nil {
		badRequest(w, err)
		return
	}
	siteID, err := strconv.ParseInt(r.PathValue("site_id"), 10, 64)
	if err != nil || siteID < 1 {
		badRequest(w, errors.New("invalid site_id"))
		return
	}
	var input webAssignmentsRequest
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Web.ReplaceSiteAssignments(r.Context(), vmID, siteID, user.ID, input.Assignments); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.propagateInheritedResourceDocumentation(r.Context(), vmID); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "web.site.services.replace", "web_site", strconv.FormatInt(siteID, 10), "success", map[string]any{"vm_id": vmID, "assignments": input.Assignments})
	view, err := a.Web.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) setWebServerDocumentationExempt(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	if err := a.ensureResourceDocumentationWritable(r.Context(), vmID); err != nil {
		badRequest(w, err)
		return
	}
	serverID, err := strconv.ParseInt(r.PathValue("server_id"), 10, 64)
	if err != nil || serverID < 1 {
		badRequest(w, errors.New("invalid server_id"))
		return
	}
	var input struct {
		Exempt bool `json:"exempt"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if err := a.Web.SetServerDocumentationExempt(r.Context(), vmID, serverID, input.Exempt); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.propagateInheritedResourceDocumentation(r.Context(), vmID); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "web.server.documentation_exempt", "web_server", strconv.FormatInt(serverID, 10), "success", map[string]any{"vm_id": vmID, "exempt": input.Exempt})
	view, err := a.Web.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) setWebSiteDocumentationExempt(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	if err := a.ensureResourceDocumentationWritable(r.Context(), vmID); err != nil {
		badRequest(w, err)
		return
	}
	siteID, err := strconv.ParseInt(r.PathValue("site_id"), 10, 64)
	if err != nil || siteID < 1 {
		badRequest(w, errors.New("invalid site_id"))
		return
	}
	var input struct {
		Exempt bool `json:"exempt"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if err := a.Web.SetSiteDocumentationExempt(r.Context(), vmID, siteID, input.Exempt); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.propagateInheritedResourceDocumentation(r.Context(), vmID); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "web.site.documentation_exempt", "web_site", strconv.FormatInt(siteID, 10), "success", map[string]any{"vm_id": vmID, "exempt": input.Exempt})
	view, err := a.Web.GetVM(r.Context(), vmID)
	respond(w, view, err)
}
