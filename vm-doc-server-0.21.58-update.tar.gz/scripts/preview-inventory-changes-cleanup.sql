-- VM-DOC 0.21.58 · analiza/curatare zgomot inventory_changes
-- Ruleaza EXCLUSIV pe MariaDB-ul VM-DOC; operatorul trebuie sa selecteze baza corecta.
-- Protejeaza review-urile, deciziile de documentare si orice observatie manuala.
-- Criterii identice in PREVIEW si DELETE (sunt generate din aceeasi lista).
-- OPRITI vm-doc-server in timpul curatarii si faceti backup inainte.
-- NU afecteaza inventory_snapshots sau inventarul brut al agentului.

SELECT DATABASE() AS baza_curenta;
SELECT COUNT(*) AS toate_modificarile FROM inventory_changes;

SELECT 'porturi_dinamice' AS motiv, COUNT(*) AS candidati FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'ports' AND c.object_type = 'listening_port' AND c.change_type IN ('added','removed')
AND c.object_label REGEXP '^Port [A-Za-z]+/[0-9]+$'
AND CAST(SUBSTRING_INDEX(c.object_label,'/',-1) AS UNSIGNED) BETWEEN 49152 AND 65535
AND NOT EXISTS (
 SELECT 1 FROM vm_primary_agent_ports pp WHERE pp.vm_id = c.vm_id
 AND LOWER(pp.protocol) = LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_label,' ', -1),'/',1))
 AND pp.port = CAST(SUBSTRING_INDEX(c.object_label,'/',-1) AS UNSIGNED)
));

SELECT 'firewall_generat' AS motiv, COUNT(*) AS candidati FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'firewall' AND c.object_type = 'rule' AND c.change_type IN ('added','removed')
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',3),'|',-1)) IN ('nftables','iptables','ip6tables')
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',6),'|',-1)) REGEXP '^(ufw-(before|after|track|logging|skip|reject|not-local)(-|$)|docker(-|$)|cni-|kube-|libvirt)'
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',6),'|',-1)) NOT LIKE 'docker-user%');

SELECT 'servicii_efemere' AS motiv, COUNT(*) AS candidati FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'services' AND c.object_type = 'service'
AND SUBSTRING_INDEX(c.object_key,'|',-1) REGEXP '^(user|user-runtime-dir)@[0-9]+[.]service$|^lxd-installer@[0-9]+(-[0-9]+)*[.]service$');

SELECT 'stare_runtime_servicii' AS motiv, COUNT(*) AS candidati FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='services' AND c.object_type='service' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND BINARY JSON_REMOVE(c.old_json,'$.active_state','$.sub_state') =
    BINARY JSON_REMOVE(c.new_json,'$.active_state','$.sub_state'));

SELECT 'stare_runtime_ntp' AS motiv, COUNT(*) AS candidati FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='time' AND c.object_type='ntp' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND BINARY JSON_REMOVE(c.old_json,'$.service_active','$.synchronized','$.current_source') =
    BINARY JSON_REMOVE(c.new_json,'$.service_active','$.synchronized','$.current_source'));

SELECT 'probe_runtime_integrari' AS motiv, COUNT(*) AS candidati FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='integrations' AND c.object_type='integration' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND BINARY JSON_REMOVE(c.old_json,'$.service_active','$.config_valid','$.config_check_output','$.output_test_ok','$.output_test_output') =
    BINARY JSON_REMOVE(c.new_json,'$.service_active','$.config_valid','$.config_check_output','$.output_test_ok','$.output_test_output'));


-- Extins in 0.21.54: + P9RdrService, NPSMSvc, DeviceAssociationBrokerSvc. Restul criteriilor raman nemodificate.
-- Noi in 0.21.51: instanțe Windows per-user, eroare versiunii MySQL

SELECT 'instante_windows_per_user' AS motiv, COUNT(*) AS candidati FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='services' AND c.object_type='service' AND LOWER(SUBSTRING_INDEX(c.object_key,'|',-1)) REGEXP '^(aarsvc|bcastdvruserservice|bluetoothuserservice|captureservice|cbdhsvc|cdpusersvc|cloudbackuprestoresvc|consentuxusersvc|credentialenrollmentmanagerusersvc|devicepickerusersvc|devicesflowusersvc|deviceassociationbrokersvc|npsmsvc|p9rdrservice|messagingservice|onesyncsvc|pimindexmaintenancesvc|printworkflowusersvc|udkusersvc|unistoresvc|userdatasvc|webthreatdefusersvc|wpnuserservice)_[0-9a-f]{5,12}$');

SELECT 'warning_versiune_mysql' AS motiv, COUNT(*) AS candidati FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='services' AND c.object_type='service' AND c.change_type='modified'
 AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
 AND LOWER(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'')) LIKE '%[warning]%'
 AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'') REGEXP '^[0-9]{6} [0-9]{1,2}:[0-9]{2}:[0-9]{2} '
 AND LOCATE(CHAR(10),COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'')) = 0
 AND LOWER(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'')) LIKE '%[warning]%'
 AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'') REGEXP '^[0-9]{6} [0-9]{1,2}:[0-9]{2}:[0-9]{2} '
 AND LOCATE(CHAR(10),COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'')) = 0
 AND BINARY JSON_REMOVE(c.old_json,'$.version') = BINARY JSON_REMOVE(c.new_json,'$.version'));

-- Valorile sunt numar de randuri candidati; regulile de mai sus sunt separate pentru raportare.

-- Fluctuații confirmate: perechi opuse același VM + obiect + JSON identic,
-- în 10 minute. Include TCP/80 apache2; NU șterge evenimente revizuite.
SELECT 'fluctuatii_porturi_confirmate' AS motiv, COUNT(*) AS candidati
FROM inventory_changes c
WHERE c.review_status='new' AND c.documentation_requirement='unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'')=''
AND (c.category='ports' AND c.object_type='listening_port' AND c.change_type IN ('added','removed')
AND EXISTS (
    SELECT 1 FROM inventory_changes pair
    WHERE pair.id<>c.id AND pair.vm_id=c.vm_id
      AND pair.category=c.category AND pair.object_type=c.object_type
      AND pair.object_key=c.object_key AND pair.object_label=c.object_label
      AND pair.change_type=IF(c.change_type='added','removed','added')
      AND pair.occurred_at BETWEEN c.occurred_at - INTERVAL 10 MINUTE AND c.occurred_at + INTERVAL 10 MINUTE
      AND BINARY COALESCE(c.new_json,c.old_json,'') = BINARY COALESCE(pair.new_json,pair.old_json,'')
      AND pair.review_status='new' AND pair.documentation_requirement='unset'
      AND pair.reviewed_at IS NULL AND COALESCE(TRIM(pair.notes),'')=''
));

-- Atenție: unele categorii se pot suprapune; totalurile pe motive nu sunt neapărat aditive.

-- 0.21.53: virtual ethernet peers cu nume automat, doar istoric, nu inventar brut.
-- reviewed/decizie/notes sunt excluse identic cu celelalte categorii.
SELECT 'interfete_veth_efemere' AS motiv, COUNT(*) AS candidati
FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'network' AND c.object_type = 'interface'
AND LOWER(TRIM(SUBSTRING_INDEX(c.object_key,'|',-1))) REGEXP '^veth[0-9a-f]{5,}(@if[0-9]+)?$');


-- 0.21.55: doar modificari in software_name ale serviciilor Windows SCM.
-- Modificari de versiune, enabled_state, manager sau alte campuri NU sunt candidate.
SELECT 'software_name_windows_scm' AS motiv, COUNT(*) AS candidati FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'services' AND c.object_type = 'service' AND c.change_type = 'modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND LOWER(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.manager')),'')) = 'windows_scm'
AND LOWER(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.manager')),'')) = 'windows_scm'
AND NOT (JSON_EXTRACT(c.old_json,'$.software_name') <=> JSON_EXTRACT(c.new_json,'$.software_name'))
AND BINARY JSON_REMOVE(c.old_json,'$.software_name') = BINARY JSON_REMOVE(c.new_json,'$.software_name'));


-- 0.21.56: porturi Apache cu worker-count diferit -> chei diferite,
-- dar JSON identic, intr-un SINGUR inventar. Ignora numai perechea completa.
SELECT 'porturi_cheie_workeri_duplicate' AS motiv, COUNT(*) AS candidati
FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='ports' AND c.object_type='listening_port' AND c.change_type IN ('added','removed')
AND EXISTS (
  SELECT 1 FROM inventory_changes pair
  WHERE pair.id<>c.id
    AND pair.vm_id=c.vm_id AND pair.inventory_id=c.inventory_id
    AND pair.category='ports' AND pair.object_type='listening_port'
    AND pair.object_label=c.object_label AND pair.object_key<>c.object_key
    AND pair.change_type=IF(c.change_type='added','removed','added')
    AND BINARY COALESCE(pair.new_json,pair.old_json,'')=BINARY COALESCE(c.new_json,c.old_json,'')
    AND pair.review_status='new' AND pair.documentation_requirement='unset'
    AND pair.reviewed_at IS NULL AND COALESCE(TRIM(pair.notes),'')=''
));

-- 0.21.56: guard Docker nftables automat regenerat la schimbarea bridge-ului.
-- Strict: RFC1918 + br-<12 hex> + counter drop + backend nftables, fara DOCKER-USER.
SELECT 'nftables_docker_bridge_guard' AS motiv, COUNT(*) AS candidati
FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='firewall' AND c.object_type='rule' AND c.change_type IN ('added','removed')
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',3),'|',-1))='nftables'
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',6),'|',-1)) NOT LIKE 'docker-user%'
AND (CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json)) THEN LOWER(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')),'')) ELSE '' END) REGEXP '^ip daddr (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}|172[.](1[6-9]|2[0-9]|3[01])[.][0-9]{1,3}[.][0-9]{1,3}|192[.]168[.][0-9]{1,3}[.][0-9]{1,3}) (meta )?iifname != ("br-[0-9a-f]{12}"|br-[0-9a-f]{12}) counter( packets [0-9]+ bytes [0-9]+)? drop( # handle [0-9]+)?$');

-- Nu aduna orbește categoriile cumulative; unele criterii se pot suprapune.
-- SQL PREVIEW nu modifica datele. Compara cu evenimentele existente si review-urile.

-- 0.21.57: Docker - schimbare doar de MAC in retelele containerului.
-- Limita de 16 atasamente previne orice stergere pentru structuri neacoperite.
-- Se verifica absolut toate celelalte proprietati din JSON, inclusiv IP,
-- gateway, network_id, image, ports, mounts si numele containerului.

-- 0.21.58: interfețe Docker bridge cu identificatori auto (nu bridge-uri stabile).
SELECT 'interfete_bridge_docker_efemere' AS motiv, COUNT(*) AS candidati
FROM inventory_changes c
WHERE c.review_status='new' AND c.documentation_requirement='unset' AND c.reviewed_at IS NULL
 AND COALESCE(TRIM(c.notes),'')=''
 AND c.category='network' AND c.object_type='interface'
 AND c.change_type IN ('added','removed')
 AND LOWER(SUBSTRING_INDEX(c.object_key,'|',-1)) REGEXP '^br-[0-9a-f]{12}$';

SELECT 'docker_doar_mac_retea' AS motiv, COUNT(*) AS candidati
FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset'
AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND c.category='docker' AND c.object_type='container' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND JSON_TYPE(JSON_EXTRACT(c.old_json,'$.networks'))='ARRAY'
AND JSON_TYPE(JSON_EXTRACT(c.new_json,'$.networks'))='ARRAY'
AND JSON_LENGTH(JSON_EXTRACT(c.old_json,'$.networks')) BETWEEN 1 AND 16
AND JSON_LENGTH(JSON_EXTRACT(c.new_json,'$.networks')) BETWEEN 1 AND 16
AND NOT (JSON_EXTRACT(c.old_json,'$.networks') <=> JSON_EXTRACT(c.new_json,'$.networks'))
AND BINARY JSON_REMOVE(c.old_json,'$.networks[0].mac_address','$.networks[1].mac_address','$.networks[2].mac_address','$.networks[3].mac_address','$.networks[4].mac_address','$.networks[5].mac_address','$.networks[6].mac_address','$.networks[7].mac_address','$.networks[8].mac_address','$.networks[9].mac_address','$.networks[10].mac_address','$.networks[11].mac_address','$.networks[12].mac_address','$.networks[13].mac_address','$.networks[14].mac_address','$.networks[15].mac_address') =
    BINARY JSON_REMOVE(c.new_json,'$.networks[0].mac_address','$.networks[1].mac_address','$.networks[2].mac_address','$.networks[3].mac_address','$.networks[4].mac_address','$.networks[5].mac_address','$.networks[6].mac_address','$.networks[7].mac_address','$.networks[8].mac_address','$.networks[9].mac_address','$.networks[10].mac_address','$.networks[11].mac_address','$.networks[12].mac_address','$.networks[13].mac_address','$.networks[14].mac_address','$.networks[15].mac_address');
