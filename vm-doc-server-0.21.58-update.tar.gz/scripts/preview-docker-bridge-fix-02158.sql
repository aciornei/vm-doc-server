-- VM-DOC 0.21.58: reparatie SQL tintita pentru bridge Docker br-hex si guard nftables.
-- object_key contine prefix: 'firewall|rule|nftables|...' / 'network|interface|br-...'.
-- PASTREAZA review-uri, decizii, observatii, inventar brut, porturi/conturi si reguli explicite.
-- Fara migrari automate; testati in staging si faceti backup verificabil.
-- Numai SELECT, fara modificari.
SELECT DATABASE() AS baza_curenta;
SELECT 'docker_bridge_interface' AS motiv,COUNT(*) AS candidati FROM inventory_changes c WHERE c.review_status='new' AND c.documentation_requirement='unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'')=''
AND c.category='network' AND c.object_type='interface' AND c.change_type IN ('added','removed')
AND LOWER(SUBSTRING_INDEX(c.object_key,'|',-1)) REGEXP '^br-[0-9a-f]{12}$';
SELECT 'nftables_docker_guard' AS motiv,COUNT(*) AS candidati FROM inventory_changes c WHERE c.review_status='new' AND c.documentation_requirement='unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'')=''
AND c.category='firewall' AND c.object_type='rule' AND c.change_type IN ('added','removed')
AND c.object_key LIKE 'firewall|rule|nftables|%'
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',6),'|',-1)) NOT LIKE 'docker-user%'
AND JSON_VALID(COALESCE(c.new_json,c.old_json))
AND LOWER(TRIM(JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule'))))
 REGEXP '^ip daddr (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}|172[.](1[6-9]|2[0-9]|3[01])[.][0-9]{1,3}[.][0-9]{1,3}|192[.]168[.][0-9]{1,3}[.][0-9]{1,3}) (meta )?iifname != ("br-[0-9a-f]{12}"|br-[0-9a-f]{12}) counter( packets [0-9]+ bytes [0-9]+)? drop( # handle [0-9]+)?$';

SELECT c.id,c.vm_id,c.occurred_at,c.change_type,c.object_key,c.review_status,c.documentation_requirement,
  JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')) AS regula
FROM inventory_changes c
WHERE c.category='firewall' AND c.object_type='rule'
  AND c.object_key LIKE 'firewall|rule|nftables|%'
  AND c.object_key LIKE '%br-%'
ORDER BY c.occurred_at DESC,c.id DESC LIMIT 20;

-- Daca PREVIEW are zero candidati, acest sumar indica daca evenimentele
-- exista dar sunt protejate de o revizie, decizie sau observatie.
SELECT c.category,c.object_type,c.review_status,c.documentation_requirement,
       COUNT(*) AS randuri_cu_bridge
FROM inventory_changes c
WHERE (c.category='network' AND c.object_type='interface'
       AND LOWER(SUBSTRING_INDEX(c.object_key,'|',-1)) REGEXP '^br-[0-9a-f]{12}$')
   OR (c.category='firewall' AND c.object_type='rule'
       AND c.object_key LIKE 'firewall|rule|nftables|%'
       AND c.object_key LIKE '%br-%')
GROUP BY c.category,c.object_type,c.review_status,c.documentation_requirement
ORDER BY randuri_cu_bridge DESC;
