package inventorychanges

import (
	"encoding/json"
	"testing"
)

func TestGeneratedDockerBridgeDoesNotCreateNetworkChange(t *testing.T) {
	build := func(bridge string) []byte {
		body := map[string]any{"network": map[string]any{"interfaces": []any{
			map[string]any{"name": bridge, "mac": "02:42:01:01:01:01", "mtu": 1500},
			map[string]any{"name": "docker0", "mtu": 1500},
			map[string]any{"name": "br-backup", "mtu": 1400},
			map[string]any{"name": "ens192", "mtu": 1500},
		}}}
		b, _ := json.Marshal(body)
		return b
	}
	a := build("br-f392b3fbdb12")
	b := build("br-87894e600741")
	x, err := extractTracked(a)
	if err != nil {
		t.Fatal(err)
	}
	y, err := extractTracked(b)
	if err != nil {
		t.Fatal(err)
	}
	if _, ok := x["network|interface|br-f392b3fbdb12"]; ok {
		t.Fatal("dynamic bridge should not be tracked")
	}
	if _, ok := y["network|interface|br-87894e600741"]; ok {
		t.Fatal("new dynamic bridge should not be tracked")
	}
	for _, name := range []string{"docker0", "br-backup", "ens192"} {
		key := "network|interface|" + name
		if _, ok := x[key]; !ok {
			t.Fatalf("stable interface %s missing", name)
		}
		if !canonicalEqual(x[key].Value, y[key].Value) {
			t.Fatalf("stable interface %s changed", name)
		}
	}
	if len(x) != len(y) {
		t.Fatalf("unexpected count %d %d", len(x), len(y))
	}
	var raw map[string]any
	if err := json.Unmarshal(a, &raw); err != nil {
		t.Fatal(err)
	}
	if _, ok := raw["network"]; !ok {
		t.Fatal("raw inventory mutated")
	}
}

func TestDockerBridgeFilterIsPrecise(t *testing.T) {
	good := []string{"br-f392b3fbdb12", "br-87894e600741", "BR-ABCDEF012345"}
	for _, name := range good {
		if !isEphemeralDockerBridgeInterface(name) {
			t.Fatalf("missed %s", name)
		}
	}
	bad := []string{"docker0", "br-backup", "br-12345", "br-123456789abcdef", "br-123456789abz", "ens192", "vethabcdef"}
	for _, name := range bad {
		if isEphemeralDockerBridgeInterface(name) {
			t.Fatalf("excluded stable %s", name)
		}
	}
}
