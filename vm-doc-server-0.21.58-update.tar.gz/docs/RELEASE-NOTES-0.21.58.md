# VM-DOC Server 0.21.58 — Docker bridge cleanup fix

**Cauza:** `inventory_changes.object_key` conține prefixul `categorie|tip|cheie`. Scripturile vechi de curățare căutau `nftables|...` în loc de `firewall|rule|nftables|...` și căutau `veth...` ca întreaga cheie, deși cheia este `network|interface|veth...`. În consecință rândurile rămâneau în MariaDB.

**Corecție cod:** `br-<12 hex>` creat automat de Docker este exclus din compararea semantică a interfețelor; `docker0`, interfețele normale și bridge-urile cu nume stabile rămân, la fel ca datele brute. Filtrul nftables deja existent rămâne conservator.

**Corecție SQL:** corectate pozițiile backend/chain și numele interfețelor în PREVIEW/CLEANUP cumulative; sunt incluse PREVIEW/CLEANUP separat numai pentru guard-urile nftables Docker și bridge-urile generate (recomandate pentru problema curentă). A fost corectat și diagnosticul read-only.

Nu se șterg evenimente revizuite, cu decizie explicită sau cu observații. Nu se ating `inventory_snapshots`, conturile locale, porturile TCP obișnuite sau regulile firewall explicit configurate. Nu se execută ștergerea automat la upgrade.

**Compatibilitate:** server 0.21.57 → 0.21.58; agent 1.7.18 și legacy nemodificate; fără migrare SQL sau modificări API. Full build și MariaDB live necesită verificări în staging.
