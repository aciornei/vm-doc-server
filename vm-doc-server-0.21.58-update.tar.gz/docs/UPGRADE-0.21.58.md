# Upgrade VM-DOC Server 0.21.57 → 0.21.58

1. Confirmă versiunea de pornire 0.21.57 și fă backup/restaurare testată a bazei MariaDB, binarului și surselor; verifică directorul `vendor/`.
2. Aplică **fie** update-ul TAR, **fie** patch-ul pe sursele 0.21.57; nu le aplica împreună.
3. Rulează `GOPROXY=off GOSUMDB=off go test ./internal/inventorychanges ./internal/domain ./openapi ./web` și apoi `go test ./...` + `make build` cu `vendor/` în mediul offline. Validează în staging înainte de a înlocui binarul.
4. Filtrul nou ignoră numai interfețele `br-[0-9a-f]{12}`, nu `docker0`, bridge-uri denumite manual sau regulile firewall explicite. Inventarul brut este păstrat.
5. Pentru **ștergerea rândurilor vechi** folosește mai întâi `scripts/preview-docker-bridge-fix-02158.sql` (doar SELECT). Dacă rezultatele corespund problemei, oprește vm-doc-server și execută manual `scripts/cleanup-docker-bridge-fix-02158.sql`, numai după backup și staging. Vezi `ROW_COUNT()` pentru categoriile individuale.
6. PREVIEW/CLEANUP cumulative sunt reparate, dar acoperă și celelalte tipuri de zgomot; pentru problema actuală recomandăm **doar varianta țintită**, fără a rula ambele curățări.
7. Repornește și verifică în `inventory_changes` noi evenimente pe `network/interface` + `firewall/rule` create după instalare. Dacă persistă, examinează `backend`, `chain`, `old_json/new_json`, agentul și timestampurile, nu presupune că înregistrările sunt noi.

**Rollback cod:** revino la binarul și sursele 0.21.57. **Rollback ștergere:** doar din backup. Nu există migrare SQL automată sau update de agent.
