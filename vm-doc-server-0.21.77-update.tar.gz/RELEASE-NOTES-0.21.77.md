# VM-DOC Server 0.21.77 — Modificări: interfață și căutare

- „Detalii” se extinde pe un **rând dedicat**, cu `colspan` pe întregul tabel. Coloanele Documentație, Stare și Acțiune rămân vizibile în rândul principal.
- Eliminată coloana editabilă Observații; butonul Salvează îi ia locul. **Observațiile deja salvate în DB nu sunt șterse** la PATCH fără câmpul `notes`.
- Căutare cu buton **Caută →**, debounce 350 ms, Enter, feedback de rezultate și selector de domeniu: Peste tot / VM / Serviciu / Obiect.
- Căutarea backend cu `search_scope=service` include numele/codul serviciilor asociate direct și prin Docker, DB sau Web; toate interogările sunt parametrizate.
- Ajutor în filtre: „Documentație” reprezintă decizia dacă fișa trebuie actualizată, „Stare” reprezintă revizuirea modificării. „Revizuit” nu este „Documentat”.
- Fără modificări în detectorul semantic, în comparația 1:1 sau în restricțiile UDP/DNS.
- Fără migrare SQL. Fără ștergeri. Agent 1.7.18 neschimbat.
