# Upgrade VM-DOC 0.21.76 → 0.21.77

1. Opriți serverul și realizați backup al binarului, configurației și bazei MariaDB.
2. Aplicați update-ul TAR doar peste sursele complete **0.21.76**, sau extrageți arhiva cu surse complete 0.21.77.
3. Verificați structura: `bash scripts/cleanup-source-tree.sh --check`.
4. Compilați offline cu `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build` (necesită `vendor/` preexistent și complet).
5. Instalați binarul rezultat conform `ExecStart` din unitatea systemd și reporniți.
6. Verificați `app.js?v=0.21.77` și testați pagina globală Modificări și VM → Modificări.
7. Testați „Detalii”, selecțiile Documentație/Stare, Salvare fără ștergerea observațiilor vechi și căutarea unui serviciu asociat.

**Rollback**: restaurați binarul 0.21.76. Nu există migrare SQL sau modificări de configurare, deci rollback-ul nu necesită migrare inversă.

**Atenție**: căutarea după serviciile asociate poate necesita interogări corelate costisitoare când istoria are multe evenimente. Verificați performanța pe MariaDB înainte de producție.

**Limitări de testare**: compilarea completă și executarea în browser + MariaDB reală nu au fost verificate în mediul de pregătire; validați în staging.
