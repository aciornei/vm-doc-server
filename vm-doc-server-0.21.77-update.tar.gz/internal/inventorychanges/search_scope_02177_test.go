package inventorychanges

import (
 "strings"
 "testing"
)

func TestChangeSearchScopeSQL(t *testing.T) {
 for _, tc := range []struct{ scope string; placeholders int; wants []string; excludes []string }{
  {"all",10,[]string{"vm.name LIKE ?","internal_services svc","c.object_label LIKE ?"},nil},
  {"vm",2,[]string{"vm.name LIKE ?"},[]string{"internal_services svc","c.object_label LIKE ?"}},
  {"service",2,[]string{"internal_services svc","docker_container_service_assignments","database_instance_service_assignments","database_catalog_service_assignments","web_site_service_assignments"},[]string{"c.object_label LIKE ?"}},
  {"object",6,[]string{"c.object_label LIKE ?","c.object_key LIKE ?"},[]string{"internal_services svc","vm.name LIKE ?"}},
 } {
  t.Run(tc.scope,func(t *testing.T){
   query,args:=buildChangeSearchSQL("postgres",tc.scope)
   if n:=strings.Count(query,"?"); n!=tc.placeholders || len(args)!=n {t.Fatalf("placeholders=%d args=%d expected=%d",n,len(args),tc.placeholders)}
   for _,term:=range tc.wants {if !strings.Contains(query,term){t.Errorf("expected %q in SQL",term)}}
   for _,term:=range tc.excludes {if strings.Contains(query,term){t.Errorf("unexpected %q in SQL",term)}}
   for _,arg:=range args {if arg!="%postgres%" {t.Errorf("unexpected argument %v",arg)}}
   if strings.Contains(query,"postgres") {t.Error("user input interpolated into SQL instead of parameterized")}
  })
 }
}

func TestChangeSearchScopeNormalized(t *testing.T) {
 for _,tc :=range []struct{input,want string}{{"SeRvIcE","service"},{"object","object"},{"bogus","all"},{"",""}} {
  got:=normalizeFilter(Filter{SearchScope:tc.input,Query:"  server  "})
  if got.SearchScope!=tc.want || got.Query!="server" {t.Errorf("input %q: %+v",tc.input,got)}
 }
}
