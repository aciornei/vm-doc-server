package server

import (
	"errors"
	"net/http"
	"strconv"
	"strings"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/inventorychanges"
)

func (a *App) listInventoryChanges(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	f := inventorychanges.Filter{Query: q.Get("q"), SearchScope: q.Get("search_scope"), Category: q.Get("category"), ChangeType: q.Get("change_type"), DocumentationRequirement: q.Get("documentation_requirement"), ReviewStatus: q.Get("review_status")}
	var err error
	if v := q.Get("vm_id"); v != "" {
		f.VMID, err = strconv.ParseInt(v, 10, 64)
		if err != nil || f.VMID < 1 {
			badRequest(w, errors.New("invalid vm_id"))
			return
		}
	}
	if v := q.Get("page"); v != "" {
		f.Page, err = strconv.Atoi(v)
		if err != nil || f.Page < 1 {
			badRequest(w, errors.New("invalid page"))
			return
		}
	}
	if v := q.Get("page_size"); v != "" {
		f.PageSize, err = strconv.Atoi(v)
		if err != nil || f.PageSize < 1 {
			badRequest(w, errors.New("invalid page_size"))
			return
		}
	}
	value, err := a.Changes.List(r.Context(), f)
	respond(w, value, err)
}

func (a *App) updateInventoryChange(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in inventorychanges.UpdateInput
	if err := decodeJSON(r, &in, 64<<10); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Changes.Update(r.Context(), id, user.ID, in)
	if err == nil {
		a.auditRequest(r, "inventory_change.review", "inventory_change", strconv.FormatInt(id, 10), "success", map[string]any{"documentation_requirement": value.DocumentationRequirement, "review_status": value.ReviewStatus, "notes": strings.TrimSpace(value.Notes)})
	}
	respond(w, value, err)
}

func (a *App) backfillInventoryChanges(w http.ResponseWriter, r *http.Request) {
	n, err := a.Changes.BackfillLatest(r.Context())
	if err == nil {
		a.auditRequest(r, "inventory_change.backfill", "inventory_change", "latest", "success", map[string]any{"inserted": n})
	}
	respond(w, map[string]any{"inserted": n}, err)
}

func (a *App) setInventoryChangesBaseline(w http.ResponseWriter, r *http.Request) {
	var in inventorychanges.BaselineInput
	if err := decodeJSON(r, &in, 16<<10); err != nil {
		badRequest(w, err)
		return
	}
	if in.VMID < 0 {
		badRequest(w, errors.New("invalid vm_id"))
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	n, err := a.Changes.SetBaseline(r.Context(), in.VMID, user.ID)
	if err == nil {
		target := "all"
		if in.VMID > 0 {
			target = strconv.FormatInt(in.VMID, 10)
		}
		a.auditRequest(r, "inventory_change.baseline", "inventory_change", target, "success", map[string]any{"vm_id": in.VMID, "vm_count": n})
	}
	respond(w, map[string]any{"vm_count": n}, err)
}
