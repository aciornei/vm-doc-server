# Upgrade VM-DOC Server 0.20.63 → 0.20.64

Actualizare doar de server/UI. Nu există migrare DB nouă și agentul 1.7.12 rămâne neschimbat.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.63 /usr/local/src/vm-doc-server-0.20.64
tar -xzf vm-doc-server-0.20.64-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.64
cd /usr/local/src/vm-doc-server-0.20.64
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server` și fă `Ctrl+F5` în browser.
