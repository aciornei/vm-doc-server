# Upgrade VM-DOC Server 0.20.88 → 0.20.89

## Scop

Corectează dublarea snapshot-urilor în **VM → Istoric inventare** la apăsarea butonului **Colectează** din VM sau Agenți.

Cauza: agentul central trimite inventarul nou prin push după `/v1/inventory/refresh`, iar worker-ul serverului citește apoi același inventar prin pull. 0.20.89 deduplică strict aceeași execuție (`payload_sha256` + `collected_at`) și păstrează un singur snapshot.

Nu există migrare DB și nu este necesar update de agent.

## Build offline

```bash
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După restart, un singur click **Colectează** trebuie să adauge un singur rând în Istoric inventare.
