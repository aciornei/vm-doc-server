# Upgrade VM-DOC Server 0.20.73 → 0.20.74

0.20.74 adaugă **Network Map + Firewall Hygiene**: hartă per VM și per serviciu pe modelul DECLARAT / OBSERVAT / PERMIS, fluxuri FortiGate și analiza policies corelate/necorelate.

Nu există migrare DB nouă. Agentul rămâne **1.7.12**.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.73 /usr/local/src/vm-doc-server-0.20.74
tar -xzf vm-doc-server-0.20.74-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.74
cd /usr/local/src/vm-doc-server-0.20.74
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi restart server și **Ctrl+F5** în browser.

## Verificare recomandată

1. **VM → Rețea → Hartă rețea**: verifică DECLARAT / OBSERVAT / PERMIS și fluxurile FortiGate.
2. **Serviciu → Rețea**: verifică VM-urile serviciului, porturile host, Docker/DB/Web, dependențele inbound/outbound și fluxurile FortiGate.
3. **Securitate → Analiză FortiGate**: verifică Corelate / Necorelate / Prea largi / Necesită verificare.
4. Pe o policy corelată, numărul de VM-uri distincte și source/destination/VIP trebuie să fie coerente cu Firewall central.
5. **Test FortiGate** trebuie să eșueze explicit dacă API-ul răspunde cu `limited_permission=true`; API administratorul trebuie să aibă drepturi read pentru configurația firewall reală.

Nu este necesar un Sync FortiGate doar pentru upgrade. Dacă modifici profilul API FortiGate sau inventarul firewall, rulează Test și apoi Sync normal.
