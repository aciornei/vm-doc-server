package fortigate

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

const maxResponseSize = 32 << 20

type Client struct {
	base  *url.URL
	token string
	http  *http.Client
	vdom  string
}

type envelope struct {
	Status            string          `json:"status"`
	HTTPStatus        int             `json:"http_status"`
	Results           json.RawMessage `json:"results"`
	LimitReached      bool            `json:"limit_reached"`
	NextIdx           int             `json:"next_idx"`
	Size              int             `json:"size"`
	MatchedCount      int             `json:"matched_count"`
	LimitedPermission bool            `json:"limited_permission"`
}

func NewClient(baseURL, token, vdom string, verifyTLS bool, tlsServerName string, timeout time.Duration, allowHTTP bool) (*Client, error) {
	u, err := url.Parse(strings.TrimRight(strings.TrimSpace(baseURL), "/"))
	if err != nil {
		return nil, err
	}
	if u.Scheme != "https" && !(allowHTTP && u.Scheme == "http") {
		return nil, fmt.Errorf("FortiGate URL must use HTTPS")
	}
	if u.Host == "" {
		return nil, fmt.Errorf("invalid FortiGate URL")
	}
	if strings.TrimSpace(token) == "" {
		return nil, fmt.Errorf("FortiGate API token is required")
	}
	if strings.TrimSpace(vdom) == "" {
		vdom = "root"
	}
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: !verifyTLS, ServerName: strings.TrimSpace(tlsServerName)} // #nosec G402 - explicit admin option
	return &Client{base: u, token: token, vdom: vdom, http: &http.Client{Timeout: timeout, Transport: tr}}, nil
}

// getCollection intentionally performs one unbounded CMDB collection request.
// FortiGate's documented firewall CMDB collection endpoints return the complete
// collection for the selected VDOM. start/count pagination is not consistently
// supported for firewall/policy and can silently cap a result set (for example
// at exactly 500 rows). If FortiGate itself reports limit_reached, fail instead
// of accepting a partial inventory.
func (c *Client) getCollection(ctx context.Context, path string) ([]RawObject, envelope, error) {
	u := *c.base
	u.Path = strings.TrimRight(c.base.Path, "/") + path
	q := u.Query()
	q.Set("vdom", c.vdom)
	u.RawQuery = q.Encode()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return nil, envelope{}, err
	}
	req.Header.Set("Authorization", "Bearer "+c.token)
	req.Header.Set("Accept", "application/json")
	res, err := c.http.Do(req)
	if err != nil {
		return nil, envelope{}, err
	}
	defer res.Body.Close()
	b, err := io.ReadAll(io.LimitReader(res.Body, maxResponseSize+1))
	if err != nil {
		return nil, envelope{}, err
	}
	if len(b) > maxResponseSize {
		return nil, envelope{}, fmt.Errorf("FortiGate response too large")
	}
	if res.StatusCode < 200 || res.StatusCode >= 300 {
		return nil, envelope{}, fmt.Errorf("FortiGate API %s: HTTP %d: %s", path, res.StatusCode, strings.TrimSpace(string(b)))
	}
	var env envelope
	if err := json.Unmarshal(b, &env); err != nil {
		return nil, envelope{}, fmt.Errorf("decode FortiGate response: %w", err)
	}
	if env.Status != "" && !strings.EqualFold(env.Status, "success") {
		return nil, env, fmt.Errorf("FortiGate API %s status %s", path, env.Status)
	}
	if env.LimitedPermission {
		return nil, env, fmt.Errorf("FortiGate API %s returned limited_permission=true; the API administrator profile cannot read the real firewall configuration", path)
	}
	var out []RawObject
	if len(env.Results) != 0 && string(env.Results) != "null" {
		if err := json.Unmarshal(env.Results, &out); err != nil {
			return nil, env, fmt.Errorf("decode FortiGate results %s: %w", path, err)
		}
	}
	if env.LimitReached {
		return nil, env, fmt.Errorf("FortiGate API %s reports limit_reached=true (size=%d matched_count=%d next_idx=%d); refusing partial CMDB inventory", path, env.Size, env.MatchedCount, env.NextIdx)
	}
	return out, env, nil
}

func (c *Client) Inventory(ctx context.Context) (Inventory, error) {
	var out Inventory
	var err error
	if out.Addresses, _, err = c.getCollection(ctx, "/api/v2/cmdb/firewall/address"); err != nil {
		return out, err
	}
	out.AddressPages = 1
	if out.Groups, _, err = c.getCollection(ctx, "/api/v2/cmdb/firewall/addrgrp"); err != nil {
		return out, err
	}
	out.GroupPages = 1
	if out.Policies, _, err = c.getCollection(ctx, "/api/v2/cmdb/firewall/policy"); err != nil {
		return out, err
	}
	out.PolicyPages = 1
	if out.VIPs, _, err = c.getCollection(ctx, "/api/v2/cmdb/firewall/vip"); err != nil {
		return out, err
	}
	out.VIPPages = 1
	return out, nil
}

func (c *Client) Test(ctx context.Context) (map[string]int, error) {
	inv, err := c.Inventory(ctx)
	if err != nil {
		return nil, err
	}
	active, disabled := 0, 0
	for _, rawPolicy := range inv.Policies {
		p := ParsePolicy(rawPolicy)
		if p.ID == 0 {
			continue
		}
		if policyEnabled(p) {
			active++
		} else {
			disabled++
		}
	}
	matchableAddresses, ignoredAddresses := 0, 0
	byType := map[string]int{}
	for _, rawAddress := range inv.Addresses {
		a := ParseAddress(rawAddress)
		if a.Name == "" {
			continue
		}
		typ := strings.ToLower(strings.TrimSpace(a.Type))
		if typ == "" {
			typ = "ipmask"
		}
		byType[typ]++
		if addressMatchable(a) {
			matchableAddresses++
		} else {
			ignoredAddresses++
		}
	}
	return map[string]int{
		"addresses":                  len(inv.Addresses),
		"addresses_matchable":        matchableAddresses,
		"addresses_ignored":          ignoredAddresses,
		"addresses_ipmask":           byType["ipmask"],
		"addresses_iprange":          byType["iprange"],
		"addresses_interface_subnet": byType["interface-subnet"],
		"addresses_wildcard":         byType["wildcard"],
		"groups":                     len(inv.Groups),
		"policies":                   active,
		"policies_disabled":          disabled,
		"policies_total":             active + disabled,
		"vips":                       len(inv.VIPs),
		"address_pages":              1,
		"group_pages":                1,
		"policy_pages":               1,
		"vip_pages":                  1,
	}, nil
}
