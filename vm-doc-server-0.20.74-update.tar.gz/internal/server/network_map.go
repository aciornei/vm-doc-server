package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"

	"vm-doc-server/internal/fortigate"
	"vm-doc-server/internal/inventory"
)

type networkMapVM struct {
	ID         int64    `json:"id"`
	Name       string   `json:"name"`
	Hostname   string   `json:"hostname,omitempty"`
	IP         string   `json:"ip,omitempty"`
	PowerState string   `json:"power_state,omitempty"`
	Services   []string `json:"services,omitempty"`
}

type networkMapComponent struct {
	VMID     int64  `json:"vm_id"`
	VMName   string `json:"vm_name,omitempty"`
	Kind     string `json:"kind"`
	Name     string `json:"name"`
	Detail   string `json:"detail,omitempty"`
	Protocol string `json:"protocol,omitempty"`
	Port     int    `json:"port,omitempty"`
	Source   string `json:"source"`
}

type networkMapDeclared struct {
	Kind      string `json:"kind"`
	Direction string `json:"direction,omitempty"`
	Name      string `json:"name"`
	Detail    string `json:"detail,omitempty"`
}

type networkMapFlow struct {
	SourceID       int64    `json:"source_id"`
	SourceName     string   `json:"source_name"`
	VDOM           string   `json:"vdom"`
	PolicyID       int64    `json:"policy_id"`
	PolicyName     string   `json:"policy_name"`
	From           []string `json:"from"`
	To             []string `json:"to"`
	Services       []string `json:"services"`
	Action         string   `json:"action"`
	NAT            bool     `json:"nat"`
	SourceVMs      []string `json:"source_vms,omitempty"`
	DestinationVMs []string `json:"destination_vms,omitempty"`
	VIP            bool     `json:"vip"`
}

type networkMapResponse struct {
	Scope        string                `json:"scope"`
	ScopeID      int64                 `json:"scope_id"`
	Name         string                `json:"name"`
	VMs          []networkMapVM        `json:"vms"`
	Components   []networkMapComponent `json:"components"`
	Declared     []networkMapDeclared  `json:"declared"`
	FortiRules   []fortigate.RuleRow   `json:"fortigate_rules"`
	Flows        []networkMapFlow      `json:"flows"`
	FirewallInfo []networkMapComponent `json:"host_firewall"`
	Summary      map[string]int        `json:"summary"`
	Warnings     []string              `json:"warnings,omitempty"`
}

func (a *App) vmNetworkMap(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.buildVMNetworkMap(r.Context(), id)
	respond(w, value, err)
}

func (a *App) serviceNetworkMap(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.buildServiceNetworkMap(r.Context(), id)
	respond(w, value, err)
}

func (a *App) buildVMNetworkMap(ctx context.Context, vmID int64) (networkMapResponse, error) {
	out := networkMapResponse{Scope: "vm", ScopeID: vmID, VMs: []networkMapVM{}, Components: []networkMapComponent{}, Declared: []networkMapDeclared{}, FortiRules: []fortigate.RuleRow{}, Flows: []networkMapFlow{}, FirewallInfo: []networkMapComponent{}, Summary: map[string]int{}}
	vm, err := a.networkMapVM(ctx, vmID)
	if err != nil {
		return out, err
	}
	out.Name = vm.Name
	out.VMs = append(out.VMs, vm)

	if services, err := a.networkMapVMServices(ctx, vmID); err == nil {
		vm.Services = services
		out.VMs[0].Services = services
		for _, name := range services {
			out.Declared = append(out.Declared, networkMapDeclared{Kind: "service", Name: name, Detail: "Asociere VM → serviciu intern"})
		}
	}
	out.Declared = append(out.Declared, a.networkMapVMDependencies(ctx, vmID)...)
	out.Declared = append(out.Declared, a.networkMapExternalConnections(ctx, "vm", vmID)...)
	out.Components = append(out.Components, a.networkMapVMComponents(ctx, vmID, vm.Name)...)
	out.FirewallInfo = append(out.FirewallInfo, a.networkMapHostFirewall(ctx, vmID, vm.Name)...)
	if a.FortiGate != nil {
		rules, ruleErr := a.FortiGate.ListRules(ctx, "", "", "", "", "", "", "", "", "", 0, vmID, 1, 500)
		if ruleErr != nil {
			out.Warnings = append(out.Warnings, "Regulile FortiGate nu au putut fi încărcate: "+ruleErr.Error())
		} else {
			out.FortiRules = rules.Items
		}
	}
	out.Flows = a.networkMapFortiFlows(ctx, []int64{vmID})
	out.Summary = networkMapSummary(out)
	return out, nil
}

func (a *App) buildServiceNetworkMap(ctx context.Context, serviceID int64) (networkMapResponse, error) {
	out := networkMapResponse{Scope: "service", ScopeID: serviceID, VMs: []networkMapVM{}, Components: []networkMapComponent{}, Declared: []networkMapDeclared{}, FortiRules: []fortigate.RuleRow{}, Flows: []networkMapFlow{}, FirewallInfo: []networkMapComponent{}, Summary: map[string]int{}}
	if err := a.DB.QueryRowContext(ctx, `SELECT name FROM internal_services WHERE id=?`, serviceID).Scan(&out.Name); err != nil {
		return out, err
	}
	ids, err := a.networkMapServiceVMIDs(ctx, serviceID)
	if err != nil {
		return out, err
	}
	for _, vmID := range ids {
		vm, vmErr := a.networkMapVM(ctx, vmID)
		if vmErr != nil {
			continue
		}
		vm.Services, _ = a.networkMapVMServices(ctx, vmID)
		out.VMs = append(out.VMs, vm)
		out.FirewallInfo = append(out.FirewallInfo, a.networkMapHostFirewall(ctx, vmID, vm.Name)...)
		out.Components = append(out.Components, a.networkMapListeningPorts(ctx, vmID, vm.Name)...)
	}
	sort.Slice(out.VMs, func(i, j int) bool { return strings.ToLower(out.VMs[i].Name) < strings.ToLower(out.VMs[j].Name) })

	if containers, e := a.Docker.ListForService(ctx, serviceID); e == nil {
		for _, c := range containers {
			detail := strings.TrimSpace(strings.Join([]string{c.Image, c.ComposeProject, c.ComposeService}, " · "))
			if detail == "··" {
				detail = ""
			}
			out.Components = append(out.Components, networkMapComponent{VMID: c.VMID, VMName: c.VMName, Kind: "docker", Name: c.Name, Detail: strings.Trim(detail, " ·"), Source: "OBSERVAT"})
			for _, p := range c.Ports {
				port := p.HostPort
				if port == 0 {
					port = p.ContainerPort
				}
				out.Components = append(out.Components, networkMapComponent{VMID: c.VMID, VMName: c.VMName, Kind: "port", Name: c.Name, Detail: "Docker", Protocol: p.Protocol, Port: port, Source: "OBSERVAT"})
			}
		}
	}
	if dbs, e := a.Databases.ListForService(ctx, serviceID); e == nil {
		for _, d := range dbs {
			name := d.Product
			if name == "" {
				name = d.Engine
			}
			if d.DatabaseName != "" {
				name += " / " + d.DatabaseName
			}
			out.Components = append(out.Components, networkMapComponent{VMID: d.VMID, VMName: d.VMName, Kind: "database", Name: name, Detail: d.InstanceName, Source: "OBSERVAT"})
			for _, ep := range d.Endpoints {
				out.Components = append(out.Components, networkMapComponent{VMID: d.VMID, VMName: d.VMName, Kind: "port", Name: name, Detail: "DB", Protocol: ep.Protocol, Port: int(ep.Port), Source: "OBSERVAT"})
			}
		}
	}
	if sites, e := a.Web.ListForService(ctx, serviceID); e == nil {
		for _, site := range sites {
			out.Components = append(out.Components, networkMapComponent{VMID: site.VMID, VMName: site.VMName, Kind: "web", Name: firstNonEmpty(site.Name, strings.Join(site.ServerNames, ", "), site.Engine), Detail: site.Engine, Source: "OBSERVAT"})
			for _, b := range site.Bindings {
				out.Components = append(out.Components, networkMapComponent{VMID: site.VMID, VMName: site.VMName, Kind: "port", Name: firstNonEmpty(site.Name, site.Engine), Detail: "Web", Protocol: b.Protocol, Port: int(b.Port), Source: "OBSERVAT"})
			}
		}
	}
	out.Declared = append(out.Declared, a.networkMapServiceDependencies(ctx, serviceID)...)
	out.Declared = append(out.Declared, a.networkMapExternalConnections(ctx, "service", serviceID)...)

	seen := map[int64]bool{}
	if a.FortiGate != nil {
		for _, vm := range out.VMs {
			rules, ruleErr := a.FortiGate.ListRules(ctx, "", "", "", "", "", "", "", "", "", 0, vm.ID, 1, 500)
			if ruleErr != nil {
				continue
			}
			for _, row := range rules.Items {
				if !seen[row.MatchID] {
					seen[row.MatchID] = true
					out.FortiRules = append(out.FortiRules, row)
				}
			}
		}
	}
	out.Components = dedupeComponents(out.Components)
	validIDs := make([]int64, 0, len(out.VMs))
	for _, vm := range out.VMs {
		validIDs = append(validIDs, vm.ID)
	}
	out.Flows = a.networkMapFortiFlows(ctx, validIDs)
	out.Summary = networkMapSummary(out)
	return out, nil
}

func (a *App) networkMapVM(ctx context.Context, vmID int64) (networkMapVM, error) {
	var v networkMapVM
	err := a.DB.QueryRowContext(ctx, `SELECT vm.id,vm.name,COALESCE(NULLIF(vm.guest_hostname,''),NULLIF(i.hostname,''),''),COALESCE(NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,''),''),COALESCE(vm.power_state,'') FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.id=? AND vm.retired=0`, vmID).Scan(&v.ID, &v.Name, &v.Hostname, &v.IP, &v.PowerState)
	return v, err
}

func (a *App) networkMapVMServices(ctx context.Context, vmID int64) ([]string, error) {
	rows, err := a.DB.QueryContext(ctx, `SELECT DISTINCT s.name FROM vm_internal_service_assignments a JOIN internal_services s ON s.id=a.internal_service_id WHERE a.vm_id=? AND s.active=1 ORDER BY s.name`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []string{}
	for rows.Next() {
		var name string
		if rows.Scan(&name) == nil {
			out = append(out, name)
		}
	}
	return out, rows.Err()
}

func (a *App) networkMapServiceVMIDs(ctx context.Context, serviceID int64) ([]int64, error) {
	rows, err := a.DB.QueryContext(ctx, `SELECT DISTINCT vm_id FROM (
        SELECT vm_id FROM vm_internal_service_assignments WHERE internal_service_id=?
        UNION SELECT c.vm_id FROM docker_container_service_assignments x JOIN docker_containers c ON c.id=x.docker_container_id AND c.present=1 WHERE x.internal_service_id=?
        UNION SELECT d.vm_id FROM database_instance_service_assignments x JOIN database_instances d ON d.id=x.database_instance_id AND d.present=1 WHERE x.internal_service_id=?
        UNION SELECT c.vm_id FROM database_catalog_service_assignments x JOIN database_catalogs c ON c.id=x.database_catalog_id AND c.present=1 WHERE x.internal_service_id=?
        UNION SELECT w.vm_id FROM web_site_service_assignments x JOIN web_sites w ON w.id=x.web_site_id AND w.present=1 WHERE x.internal_service_id=?
    ) q ORDER BY vm_id`, serviceID, serviceID, serviceID, serviceID, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []int64{}
	for rows.Next() {
		var id int64
		if rows.Scan(&id) == nil {
			out = append(out, id)
		}
	}
	return out, rows.Err()
}

func (a *App) networkMapVMComponents(ctx context.Context, vmID int64, vmName string) []networkMapComponent {
	out := []networkMapComponent{}
	if view, err := a.Docker.GetVM(ctx, vmID); err == nil {
		for _, c := range view.Containers {
			if !c.Present {
				continue
			}
			out = append(out, networkMapComponent{VMID: vmID, VMName: vmName, Kind: "docker", Name: c.Name, Detail: c.Image, Source: "OBSERVAT"})
			for _, p := range c.Ports {
				port := p.HostPort
				if port == 0 {
					port = p.ContainerPort
				}
				out = append(out, networkMapComponent{VMID: vmID, VMName: vmName, Kind: "port", Name: c.Name, Detail: "Docker", Protocol: p.Protocol, Port: port, Source: "OBSERVAT"})
			}
		}
	}
	if view, err := a.Databases.GetVM(ctx, vmID); err == nil {
		for _, d := range view.Instances {
			if !d.Present {
				continue
			}
			name := firstNonEmpty(d.Product, d.Engine)
			out = append(out, networkMapComponent{VMID: vmID, VMName: vmName, Kind: "database", Name: name, Detail: d.InstanceName, Source: "OBSERVAT"})
			for _, ep := range d.Endpoints {
				out = append(out, networkMapComponent{VMID: vmID, VMName: vmName, Kind: "port", Name: name, Detail: "DB", Protocol: ep.Protocol, Port: int(ep.Port), Source: "OBSERVAT"})
			}
		}
	}
	if view, err := a.Web.GetVM(ctx, vmID); err == nil {
		for _, site := range view.Sites {
			if !site.Present || !site.Enabled {
				continue
			}
			name := firstNonEmpty(site.Name, strings.Join(site.ServerNames, ", "), site.Engine)
			out = append(out, networkMapComponent{VMID: vmID, VMName: vmName, Kind: "web", Name: name, Detail: site.Engine, Source: "OBSERVAT"})
			for _, b := range site.Bindings {
				out = append(out, networkMapComponent{VMID: vmID, VMName: vmName, Kind: "port", Name: name, Detail: "Web", Protocol: b.Protocol, Port: int(b.Port), Source: "OBSERVAT"})
			}
		}
	}
	out = append(out, a.networkMapListeningPorts(ctx, vmID, vmName)...)
	return dedupeComponents(out)
}

func (a *App) networkMapListeningPorts(ctx context.Context, vmID int64, vmName string) []networkMapComponent {
	raw, err := a.networkMapInventoryRaw(ctx, vmID)
	if err != nil || len(raw) == 0 {
		return nil
	}
	view, err := inventory.BuildDocumentView(raw)
	if err != nil {
		return nil
	}
	out := []networkMapComponent{}
	for _, section := range view.Sections {
		if section.Key != "listening_ports" {
			continue
		}
		for _, item := range genericItems(section.Data) {
			port := genericInt(item["port"])
			if port <= 0 {
				continue
			}
			out = append(out, networkMapComponent{VMID: vmID, VMName: vmName, Kind: "port", Name: firstNonEmpty(genericString(item["process_name"]), genericString(item["process"]), "Port ascultat"), Detail: "Agent / host", Protocol: genericString(item["protocol"]), Port: port, Source: "OBSERVAT"})
		}
	}
	return out
}

func (a *App) networkMapHostFirewall(ctx context.Context, vmID int64, vmName string) []networkMapComponent {
	raw, err := a.networkMapInventoryRaw(ctx, vmID)
	if err != nil || len(raw) == 0 {
		return nil
	}
	view, err := inventory.BuildDocumentView(raw)
	if err != nil {
		return nil
	}
	out := []networkMapComponent{}
	for _, section := range view.Sections {
		if section.Key != "firewall" {
			continue
		}
		count := genericObjectCount(section.Data)
		detail := "Firewall host detectat"
		if count > 0 {
			detail = fmt.Sprintf("%d elemente/rules observate", count)
		}
		out = append(out, networkMapComponent{VMID: vmID, VMName: vmName, Kind: "host-firewall", Name: "Firewall intern", Detail: detail, Source: "PERMIS"})
		rules := genericItems(section.Data)
		if len(rules) > 30 {
			rules = rules[:30]
		}
		for _, item := range rules {
			rule := genericString(item["rule"])
			if rule == "" {
				continue
			}
			name := strings.TrimSpace(strings.Join([]string{genericString(item["backend"]), genericString(item["chain"]), genericString(item["action"])}, " · "))
			name = strings.Trim(name, " ·")
			if name == "" {
				name = "Regulă firewall host"
			}
			if len(rule) > 180 {
				rule = rule[:177] + "..."
			}
			out = append(out, networkMapComponent{VMID: vmID, VMName: vmName, Kind: "host-firewall-rule", Name: name, Detail: rule, Source: "PERMIS"})
		}
	}
	return out
}

func (a *App) networkMapInventoryRaw(ctx context.Context, vmID int64) ([]byte, error) {
	var raw []byte
	err := a.DB.QueryRowContext(ctx, `SELECT i.raw_json FROM virtual_machines vm JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.id=?`, vmID).Scan(&raw)
	return raw, err
}

func (a *App) networkMapExternalConnections(ctx context.Context, scope string, id int64) []networkMapDeclared {
	var query string
	if scope == "service" {
		query = `SELECT x.name,c.direction,c.remote_service,c.protocol,COALESCE(c.port,0),c.purpose FROM external_connections c JOIN external_systems x ON x.id=c.external_system_id WHERE c.internal_service_id=? AND c.active=1 ORDER BY x.name`
	} else {
		query = `SELECT x.name,c.direction,c.remote_service,c.protocol,COALESCE(c.port,0),c.purpose FROM external_connections c JOIN external_systems x ON x.id=c.external_system_id WHERE c.vm_id=? AND c.active=1 ORDER BY x.name`
	}
	rows, err := a.DB.QueryContext(ctx, query, id)
	if err != nil {
		return nil
	}
	defer rows.Close()
	out := []networkMapDeclared{}
	for rows.Next() {
		var name, direction, remote, protocol, purpose string
		var port int
		if rows.Scan(&name, &direction, &remote, &protocol, &port, &purpose) != nil {
			continue
		}
		detail := strings.TrimSpace(strings.Join([]string{remote, endpoint(protocol, port), purpose}, " · "))
		out = append(out, networkMapDeclared{Kind: "external", Direction: direction, Name: name, Detail: strings.Trim(detail, " ·")})
	}
	return out
}

func (a *App) networkMapVMDependencies(ctx context.Context, vmID int64) []networkMapDeclared {
	rows, err := a.DB.QueryContext(ctx, `SELECT target.name,COALESCE(n.name,''),COALESCE(d.notes,'') FROM vm_common_service_dependencies d JOIN internal_services target ON target.id=d.target_service_id LEFT JOIN nomenclature_items n ON n.id=d.dependency_type_id WHERE d.vm_id=? AND d.active=1 ORDER BY target.name`, vmID)
	if err != nil {
		return nil
	}
	defer rows.Close()
	out := []networkMapDeclared{}
	for rows.Next() {
		var name, kind, notes string
		if rows.Scan(&name, &kind, &notes) != nil {
			continue
		}
		out = append(out, networkMapDeclared{Kind: "service", Direction: "outbound", Name: name, Detail: strings.Trim(strings.Join([]string{kind, notes}, " · "), " ·")})
	}
	return out
}

func (a *App) networkMapServiceDependencies(ctx context.Context, serviceID int64) []networkMapDeclared {
	rows, err := a.DB.QueryContext(ctx, `
        SELECT target.name,'outbound',COALESCE(n.name,''),COALESCE(d.protocol,''),COALESCE(d.port,0),COALESCE(d.notes,'')
          FROM internal_service_dependencies d
          JOIN internal_services target ON target.id=d.target_service_id
          LEFT JOIN nomenclature_items n ON n.id=d.dependency_type_id
         WHERE d.source_service_id=? AND d.active=1
        UNION ALL
        SELECT source.name,'inbound',COALESCE(n.name,''),COALESCE(d.protocol,''),COALESCE(d.port,0),COALESCE(d.notes,'')
          FROM internal_service_dependencies d
          JOIN internal_services source ON source.id=d.source_service_id
          LEFT JOIN nomenclature_items n ON n.id=d.dependency_type_id
         WHERE d.target_service_id=? AND d.active=1
        ORDER BY 2,1`, serviceID, serviceID)
	if err != nil {
		return nil
	}
	defer rows.Close()
	out := []networkMapDeclared{}
	for rows.Next() {
		var name, direction, kind, protocol, notes string
		var port int
		if rows.Scan(&name, &direction, &kind, &protocol, &port, &notes) != nil {
			continue
		}
		detail := strings.Trim(strings.Join([]string{kind, endpoint(protocol, port), notes}, " · "), " ·")
		out = append(out, networkMapDeclared{Kind: "service", Direction: direction, Name: name, Detail: detail})
	}
	return out
}

func (a *App) networkMapFortiFlows(ctx context.Context, scopeVMIDs []int64) []networkMapFlow {
	if len(scopeVMIDs) == 0 {
		return nil
	}
	marks := make([]string, len(scopeVMIDs))
	args := make([]any, len(scopeVMIDs))
	for i, id := range scopeVMIDs {
		marks[i] = "?"
		args[i] = id
	}
	query := `SELECT p.source_id,s.name,p.vdom,p.policy_id,p.name,p.action,p.nat,p.srcaddr_json,p.dstaddr_json,p.service_json,m.vm_id,vm.name,m.direction
        FROM fortigate_policies p
        JOIN fortigate_sources s ON s.id=p.source_id
        JOIN fortigate_vm_matches m ON m.source_id=p.source_id AND m.vdom=p.vdom AND m.policy_id=p.policy_id
        JOIN virtual_machines vm ON vm.id=m.vm_id
        WHERE LOWER(TRIM(p.status)) NOT IN ('disable','disabled','off','false','0')
          AND EXISTS (SELECT 1 FROM fortigate_vm_matches x WHERE x.source_id=p.source_id AND x.vdom=p.vdom AND x.policy_id=p.policy_id AND x.vm_id IN (` + strings.Join(marks, ",") + `))
        ORDER BY s.name,p.vdom,p.policy_id,vm.name,m.direction`
	rows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil
	}
	defer rows.Close()
	type acc struct {
		flow networkMapFlow
		src  map[string]bool
		dst  map[string]bool
	}
	byKey := map[string]*acc{}
	order := []string{}
	for rows.Next() {
		var sourceID, policyID, vmID int64
		var sourceName, vdom, policyName, action, srcRaw, dstRaw, svcRaw, vmName, direction string
		var nat bool
		if rows.Scan(&sourceID, &sourceName, &vdom, &policyID, &policyName, &action, &nat, &srcRaw, &dstRaw, &svcRaw, &vmID, &vmName, &direction) != nil {
			continue
		}
		key := fmt.Sprintf("%d|%s|%d", sourceID, vdom, policyID)
		a := byKey[key]
		if a == nil {
			a = &acc{flow: networkMapFlow{SourceID: sourceID, SourceName: sourceName, VDOM: vdom, PolicyID: policyID, PolicyName: policyName, Action: action, NAT: nat}, src: map[string]bool{}, dst: map[string]bool{}}
			_ = json.Unmarshal([]byte(srcRaw), &a.flow.From)
			_ = json.Unmarshal([]byte(dstRaw), &a.flow.To)
			_ = json.Unmarshal([]byte(svcRaw), &a.flow.Services)
			byKey[key] = a
			order = append(order, key)
		}
		switch strings.ToLower(direction) {
		case "source":
			a.src[vmName] = true
		case "destination":
			a.dst[vmName] = true
		case "vip":
			a.dst[vmName] = true
			a.flow.VIP = true
		}
	}
	out := make([]networkMapFlow, 0, len(order))
	for _, key := range order {
		a := byKey[key]
		for name := range a.src {
			a.flow.SourceVMs = append(a.flow.SourceVMs, name)
		}
		for name := range a.dst {
			a.flow.DestinationVMs = append(a.flow.DestinationVMs, name)
		}
		sort.Strings(a.flow.SourceVMs)
		sort.Strings(a.flow.DestinationVMs)
		out = append(out, a.flow)
		if len(out) >= 200 {
			break
		}
	}
	return out
}

func networkMapSummary(v networkMapResponse) map[string]int {
	summary := map[string]int{"vms": len(v.VMs), "declared": len(v.Declared), "observed": len(v.Components), "host_firewall": len(v.FirewallInfo), "fortigate": len(v.FortiRules), "flows": len(v.Flows)}
	for _, c := range v.Components {
		switch c.Kind {
		case "port":
			summary["ports"]++
		case "docker":
			summary["docker"]++
		case "database":
			summary["databases"]++
		case "web":
			summary["web"]++
		}
	}
	return summary
}

func dedupeComponents(values []networkMapComponent) []networkMapComponent {
	seen := map[string]bool{}
	out := make([]networkMapComponent, 0, len(values))
	for _, v := range values {
		key := fmt.Sprintf("%d|%s|%s|%s|%d|%s", v.VMID, v.Kind, strings.ToLower(v.Name), strings.ToLower(v.Protocol), v.Port, strings.ToLower(v.Detail))
		if seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, v)
	}
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].VMName != out[j].VMName {
			return out[i].VMName < out[j].VMName
		}
		if out[i].Kind != out[j].Kind {
			return out[i].Kind < out[j].Kind
		}
		if out[i].Port != out[j].Port {
			return out[i].Port < out[j].Port
		}
		return out[i].Name < out[j].Name
	})
	return out
}

func genericItems(value any) []map[string]any {
	switch typed := value.(type) {
	case []any:
		out := []map[string]any{}
		for _, item := range typed {
			if m, ok := item.(map[string]any); ok {
				out = append(out, m)
			}
		}
		return out
	case map[string]any:
		for _, key := range []string{"items", "ports", "listening_ports", "entries", "rules"} {
			if items := genericItems(typed[key]); len(items) > 0 {
				return items
			}
		}
	}
	return nil
}

func genericObjectCount(value any) int {
	switch typed := value.(type) {
	case []any:
		return len(typed)
	case map[string]any:
		total := 0
		for _, child := range typed {
			switch child.(type) {
			case []any, map[string]any:
				total += genericObjectCount(child)
			}
		}
		if total == 0 && len(typed) > 0 {
			return 1
		}
		return total
	default:
		return 0
	}
}

func genericString(value any) string {
	if value == nil {
		return ""
	}
	return strings.TrimSpace(fmt.Sprint(value))
}

func genericInt(value any) int {
	switch v := value.(type) {
	case json.Number:
		n, _ := strconv.Atoi(v.String())
		return n
	case float64:
		return int(v)
	case int:
		return v
	case string:
		n, _ := strconv.Atoi(strings.TrimSpace(v))
		return n
	default:
		return 0
	}
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}

func endpoint(protocol string, port int) string {
	protocol = strings.TrimSpace(protocol)
	if port <= 0 {
		return protocol
	}
	if protocol == "" {
		return strconv.Itoa(port)
	}
	return fmt.Sprintf("%s/%d", protocol, port)
}
