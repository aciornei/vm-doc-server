package server

import (
	"encoding/json"
	"net/http"
	"sort"
	"strconv"
	"strings"
)

type fortigatePolicyAnalysisRow struct {
	SourceID           int64    `json:"source_id"`
	SourceName         string   `json:"source_name"`
	VDOM               string   `json:"vdom"`
	PolicyID           int64    `json:"policy_id"`
	PolicyName         string   `json:"policy_name"`
	Status             string   `json:"status"`
	Action             string   `json:"action"`
	SrcIntf            []string `json:"srcintf"`
	DstIntf            []string `json:"dstintf"`
	SrcAddr            []string `json:"srcaddr"`
	DstAddr            []string `json:"dstaddr"`
	Services           []string `json:"services"`
	NAT                bool     `json:"nat"`
	Comments           string   `json:"comments,omitempty"`
	MatchCount         int      `json:"match_count"`
	VMCount            int      `json:"vm_count"`
	MatchedVMs         []string `json:"matched_vms,omitempty"`
	SourceMatches      int      `json:"source_matches"`
	DestinationMatches int      `json:"destination_matches"`
	VIPMatches         int      `json:"vip_matches"`
	Flags              []string `json:"flags"`
	Classification     string   `json:"classification"`
}

type fortigatePolicyAnalysisPage struct {
	Items             []fortigatePolicyAnalysisRow `json:"items"`
	Page              int                          `json:"page"`
	PageSize          int                          `json:"page_size"`
	Total             int                          `json:"total"`
	Pages             int                          `json:"pages"`
	ActivePolicies    int                          `json:"active_policies"`
	Correlated        int                          `json:"correlated"`
	Uncorrelated      int                          `json:"uncorrelated"`
	Broad             int                          `json:"broad"`
	CandidateReview   int                          `json:"candidate_review"`
	TrafficEvidence   bool                         `json:"traffic_evidence"`
	CleanupCandidates int                          `json:"cleanup_candidates"`
}

func (a *App) fortigatePolicyAnalysis(w http.ResponseWriter, r *http.Request) {
	page, size, err := paginationFromRequest(r, 50, 500)
	if err != nil {
		badRequest(w, err)
		return
	}
	rows, err := a.DB.QueryContext(r.Context(), `SELECT p.source_id,s.name,p.vdom,p.policy_id,p.name,p.status,p.action,p.srcintf_json,p.dstintf_json,p.srcaddr_json,p.dstaddr_json,p.service_json,p.nat,p.comments,
        COUNT(m.id),COUNT(DISTINCT m.vm_id),COALESCE(GROUP_CONCAT(DISTINCT vm.name ORDER BY vm.name SEPARATOR '||'),''),COALESCE(SUM(m.direction='source'),0),COALESCE(SUM(m.direction='destination'),0),COALESCE(SUM(m.direction='vip'),0)
        FROM fortigate_policies p
        JOIN fortigate_sources s ON s.id=p.source_id
        LEFT JOIN fortigate_vm_matches m ON m.source_id=p.source_id AND m.vdom=p.vdom AND m.policy_id=p.policy_id
        LEFT JOIN virtual_machines vm ON vm.id=m.vm_id
        WHERE LOWER(TRIM(p.status)) NOT IN ('disable','disabled','off','false','0')
        GROUP BY p.source_id,s.name,p.vdom,p.policy_id,p.name,p.status,p.action,p.srcintf_json,p.dstintf_json,p.srcaddr_json,p.dstaddr_json,p.service_json,p.nat,p.comments
        ORDER BY s.name,p.vdom,p.policy_id`)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer rows.Close()
	all := []fortigatePolicyAnalysisRow{}
	for rows.Next() {
		var item fortigatePolicyAnalysisRow
		var srcIntf, dstIntf, srcAddr, dstAddr, services, matchedVMs string
		if err := rows.Scan(&item.SourceID, &item.SourceName, &item.VDOM, &item.PolicyID, &item.PolicyName, &item.Status, &item.Action, &srcIntf, &dstIntf, &srcAddr, &dstAddr, &services, &item.NAT, &item.Comments, &item.MatchCount, &item.VMCount, &matchedVMs, &item.SourceMatches, &item.DestinationMatches, &item.VIPMatches); err != nil {
			respond(w, nil, err)
			return
		}
		_ = json.Unmarshal([]byte(srcIntf), &item.SrcIntf)
		_ = json.Unmarshal([]byte(dstIntf), &item.DstIntf)
		_ = json.Unmarshal([]byte(srcAddr), &item.SrcAddr)
		_ = json.Unmarshal([]byte(dstAddr), &item.DstAddr)
		_ = json.Unmarshal([]byte(services), &item.Services)
		if strings.TrimSpace(matchedVMs) != "" {
			item.MatchedVMs = strings.Split(matchedVMs, "||")
		}
		item.Flags = fortigatePolicyFlags(item)
		if item.MatchCount == 0 {
			item.Classification = "uncorrelated"
		} else {
			item.Classification = "correlated"
		}
		all = append(all, item)
	}
	if err := rows.Err(); err != nil {
		respond(w, nil, err)
		return
	}

	out := fortigatePolicyAnalysisPage{Page: page, PageSize: size, ActivePolicies: len(all), TrafficEvidence: false, CleanupCandidates: 0}
	for _, item := range all {
		if item.MatchCount > 0 {
			out.Correlated++
		} else {
			out.Uncorrelated++
		}
		if hasPolicyFlag(item.Flags, "prea largă") {
			out.Broad++
		}
		if item.MatchCount == 0 || len(item.Flags) > 0 {
			out.CandidateReview++
		}
	}

	q := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("q")))
	sourceID := strings.TrimSpace(r.URL.Query().Get("source_id"))
	vdom := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("vdom")))
	class := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("classification")))
	flag := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("flag")))
	filtered := make([]fortigatePolicyAnalysisRow, 0, len(all))
	for _, item := range all {
		if sourceID != "" && sourceID != int64String(item.SourceID) {
			continue
		}
		if vdom != "" && strings.ToLower(item.VDOM) != vdom {
			continue
		}
		if class == "correlated" && item.MatchCount == 0 {
			continue
		}
		if class == "uncorrelated" && item.MatchCount > 0 {
			continue
		}
		if class == "broad" && !hasPolicyFlag(item.Flags, "prea largă") {
			continue
		}
		if class == "review" && !(item.MatchCount == 0 || len(item.Flags) > 0) {
			continue
		}
		if flag != "" && !containsPolicyFlag(item.Flags, flag) {
			continue
		}
		if q != "" {
			hay := strings.ToLower(strings.Join([]string{item.SourceName, item.VDOM, item.PolicyName, int64String(item.PolicyID), strings.Join(item.SrcAddr, " "), strings.Join(item.DstAddr, " "), strings.Join(item.Services, " "), strings.Join(item.SrcIntf, " "), strings.Join(item.DstIntf, " "), item.Comments}, " "))
			if !strings.Contains(hay, q) {
				continue
			}
		}
		filtered = append(filtered, item)
	}
	sort.SliceStable(filtered, func(i, j int) bool {
		ai, aj := analysisPriority(filtered[i]), analysisPriority(filtered[j])
		if ai != aj {
			return ai < aj
		}
		if filtered[i].SourceName != filtered[j].SourceName {
			return filtered[i].SourceName < filtered[j].SourceName
		}
		if filtered[i].VDOM != filtered[j].VDOM {
			return filtered[i].VDOM < filtered[j].VDOM
		}
		return filtered[i].PolicyID < filtered[j].PolicyID
	})
	out.Total = len(filtered)
	if size > 0 {
		out.Pages = (out.Total + size - 1) / size
	}
	start := (page - 1) * size
	if start < out.Total {
		end := start + size
		if end > out.Total {
			end = out.Total
		}
		out.Items = filtered[start:end]
	} else {
		out.Items = []fortigatePolicyAnalysisRow{}
	}
	respond(w, out, nil)
}

func fortigatePolicyFlags(item fortigatePolicyAnalysisRow) []string {
	flags := []string{}
	broad := false
	if stringSliceHasCI(item.SrcAddr, "all") {
		flags = append(flags, "source ALL")
		broad = true
	}
	if stringSliceHasCI(item.DstAddr, "all") {
		flags = append(flags, "destination ALL")
		broad = true
	}
	if stringSliceHasCI(item.Services, "ALL") {
		flags = append(flags, "service ALL")
		broad = true
	}
	if broad {
		flags = append(flags, "prea largă")
	}
	if strings.TrimSpace(item.Comments) == "" {
		flags = append(flags, "fără comentariu")
	}
	if item.MatchCount == 0 {
		flags = append(flags, "fără VM corelat")
	}
	return flags
}

func analysisPriority(item fortigatePolicyAnalysisRow) int {
	if item.MatchCount == 0 && hasPolicyFlag(item.Flags, "prea largă") {
		return 0
	}
	if item.MatchCount == 0 {
		return 1
	}
	if hasPolicyFlag(item.Flags, "prea largă") {
		return 2
	}
	if len(item.Flags) > 0 {
		return 3
	}
	return 4
}

func stringSliceHasCI(values []string, wanted string) bool {
	for _, value := range values {
		if strings.EqualFold(strings.TrimSpace(value), wanted) {
			return true
		}
	}
	return false
}

func hasPolicyFlag(values []string, wanted string) bool {
	for _, value := range values {
		if strings.EqualFold(value, wanted) {
			return true
		}
	}
	return false
}

func containsPolicyFlag(values []string, wanted string) bool {
	for _, value := range values {
		if strings.Contains(strings.ToLower(value), wanted) {
			return true
		}
	}
	return false
}

func int64String(v int64) string {
	return strconv.FormatInt(v, 10)
}
