# Upgrade 0.20.56 → 0.20.57

1. Copiază directorul 0.20.56 în 0.20.57 sau aplică arhiva update peste copia nouă.
2. Nu există migrare DB nouă.
3. Rulează testele și build-ul offline:

```bash
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

4. Repornește serviciul `vm-doc-server` și fă `Ctrl+F5`.

## Schimbări

- `Porturi ascultate` poate fi omisă complet fără să renumeroteze capitolele următoare din fișa VM.
- `Firewall` rămâne `9.7`, inclusiv când lista porturilor ascultate este ascunsă.
- Porturile marcate Principal rămân în secțiunea dedicată.
- Fără update de agent.
