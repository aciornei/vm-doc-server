# Upgrade vm-doc-server 0.20.4 → 0.20.5

Versiunea 0.20.5 rafinează controlul documentației la nivel de resursă și aliniază exportul Markdown cu structura fișei VM Word.

## Noutăți

- `Nu necesită documentare` este disponibil și pentru fiecare container Docker, fiecare bază logică/catalog și fiecare configurație/site Web;
- marcajele sunt persistente și nu sunt suprascrise de resync-ul inventarului;
- resursele marcate rămân vizibile în inventar, dar sunt excluse din fișele VM/serviciu și din completitudinea documentației;
- checkbox-urile sunt aliniate într-o coloană `Documentare`; controalele coarse existente pentru Docker host, instanță DB și server Web rămân disponibile;
- fișa VM simplifică tabelele: `Utilizare` include și `Principal`, componentele software nu mai au coloana `Pachet`, port/proces și persoană/departament sunt concatenate, iar containerele nu mai au coloana `Indicatori`;
- exportul Markdown al anexelor VM reproduce structurat aceleași zone tehnice ca Word: Sistem și hardware, OS, Stocare, Rețea, Servicii active, Porturi, Firewall (politici/zone/reguli), Conturi, SSSD, Integrări, Politici, Cron și NTP;
- testul vCenter pentru căutarea VM este actualizat la 17 argumente după introducerea IP-ului principal preferat.

## Migrare DB

La pornire se aplică automat:

```text
049_resource_documentation_exempt.up.sql
```

Migrarea adaugă `documentation_exempt` în:

- `docker_containers`;
- `database_catalogs`;
- `web_sites`.

Valorile implicite sunt `0`, deci toate resursele existente continuă să fie documentate până când operatorul bifează explicit excluderea.

## Upgrade offline

Folosiți arborele 0.20.4 care deja are `go.mod`, `go.sum` și `vendor/` funcționale. Nu rulați `go mod vendor` pe serverul izolat.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.4 vm-doc-server-0.20.5
tar -xzf vm-doc-server-0.20.5-update.tar.gz -C vm-doc-server-0.20.5
cd vm-doc-server-0.20.5

GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

După instalarea binarului și restartul serviciului, faceți `Ctrl+F5` în browser pentru încărcarea JS/CSS actualizate.

## Verificare funcțională

1. VM → Docker: fiecare container trebuie să aibă checkbox `Nu necesită documentare` aliniat în coloana `Documentare`.
2. VM → Baze de date: fiecare instanță și fiecare bază logică trebuie să poată fi exclusă independent.
3. VM → Web: fiecare server și fiecare site/frontend trebuie să poată fi exclus independent.
4. Generați fișa VM și verificați tabelele simplificate.
5. Generați Markdown pentru un serviciu cu anexele VM lipite; secțiunile tehnice din anexă trebuie să fie tabele Markdown similare celor din Word.

Nu este necesară actualizarea vm-doc-agent 1.7.9.
