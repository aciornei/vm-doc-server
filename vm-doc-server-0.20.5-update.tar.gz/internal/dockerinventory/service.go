package dockerinventory

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

type Service struct{ DB *sql.DB }

type AssignmentInput struct {
	ServiceID           int64  `json:"service_id"`
	EnvironmentID       *int64 `json:"environment_id,omitempty"`
	OperationalStatusID *int64 `json:"operational_status_id,omitempty"`
	SolutionTypeID      *int64 `json:"solution_type_id,omitempty"`
	ComponentName       string `json:"component_name,omitempty"`
	RoleName            string `json:"role_name,omitempty"`
	Notes               string `json:"notes,omitempty"`
}

type agentDocker struct {
	Installed       bool                          `json:"installed"`
	Available       bool                          `json:"available"`
	Executable      string                        `json:"executable"`
	ServiceState    string                        `json:"service_state"`
	Version         string                        `json:"version"`
	APIVersion      string                        `json:"api_version"`
	OS              string                        `json:"os"`
	Architecture    string                        `json:"architecture"`
	StorageDriver   string                        `json:"storage_driver"`
	LoggingDriver   string                        `json:"logging_driver"`
	CgroupDriver    string                        `json:"cgroup_driver"`
	CgroupVersion   string                        `json:"cgroup_version"`
	DockerRootDir   string                        `json:"docker_root_dir"`
	Containers      []agentContainer              `json:"containers"`
	Images          []agentImage                  `json:"images"`
	Networks        []agentNetwork                `json:"networks"`
	Volumes         []agentVolume                 `json:"volumes"`
	ComposeProjects []domain.DockerComposeProject `json:"compose_projects"`
}

type agentContainer struct {
	ID                       string                          `json:"id"`
	Name                     string                          `json:"name"`
	Image                    string                          `json:"image"`
	ImageID                  string                          `json:"image_id"`
	State                    string                          `json:"state"`
	Status                   string                          `json:"status"`
	Health                   string                          `json:"health"`
	CreatedAt                *time.Time                      `json:"created_at"`
	StartedAt                *time.Time                      `json:"started_at"`
	FinishedAt               *time.Time                      `json:"finished_at"`
	RestartPolicy            string                          `json:"restart_policy"`
	RestartMaximumRetryCount int                             `json:"restart_maximum_retry_count"`
	Privileged               bool                            `json:"privileged"`
	ReadonlyRootFS           bool                            `json:"readonly_rootfs"`
	NetworkMode              string                          `json:"network_mode"`
	User                     string                          `json:"user"`
	WorkingDir               string                          `json:"working_dir"`
	MemoryLimitBytes         int64                           `json:"memory_limit_bytes"`
	NanoCPUs                 int64                           `json:"nano_cpus"`
	CPUQuota                 int64                           `json:"cpu_quota"`
	CPUPeriod                int64                           `json:"cpu_period"`
	PidsLimit                int64                           `json:"pids_limit"`
	DockerSocketMounted      bool                            `json:"docker_socket_mounted"`
	CapAdd                   []string                        `json:"cap_add"`
	SecurityOpt              []string                        `json:"security_opt"`
	EnvironmentKeys          []string                        `json:"environment_keys"`
	Labels                   map[string]string               `json:"labels"`
	ComposeProject           string                          `json:"compose_project"`
	ComposeService           string                          `json:"compose_service"`
	ComposeWorkingDir        string                          `json:"compose_working_dir"`
	ComposeConfigFiles       []string                        `json:"compose_config_files"`
	Ports                    []domain.DockerPort             `json:"ports"`
	Mounts                   []domain.DockerMount            `json:"mounts"`
	Networks                 []domain.DockerContainerNetwork `json:"networks"`
}

type agentImage struct {
	ID           string     `json:"id"`
	RepoTags     []string   `json:"repo_tags"`
	RepoDigests  []string   `json:"repo_digests"`
	CreatedAt    *time.Time `json:"created_at"`
	SizeBytes    int64      `json:"size_bytes"`
	Architecture string     `json:"architecture"`
	OS           string     `json:"os"`
}

type agentNetwork struct {
	ID         string                    `json:"id"`
	Name       string                    `json:"name"`
	Driver     string                    `json:"driver"`
	Scope      string                    `json:"scope"`
	Internal   bool                      `json:"internal"`
	Attachable bool                      `json:"attachable"`
	Ingress    bool                      `json:"ingress"`
	IPAM       []domain.DockerIPAMConfig `json:"ipam"`
	Labels     map[string]string         `json:"labels"`
}

type agentVolume struct {
	Name       string            `json:"name"`
	Driver     string            `json:"driver"`
	Mountpoint string            `json:"mountpoint"`
	Scope      string            `json:"scope"`
	Labels     map[string]string `json:"labels"`
}

func (s Service) Sync(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, raw []byte) error {
	if tx == nil || vmID < 1 || inventoryID < 1 {
		return nil
	}
	var root struct {
		Docker     json.RawMessage `json:"docker"`
		Collection struct {
			Collectors map[string]struct {
				Status string `json:"status"`
			} `json:"collectors"`
		} `json:"collection"`
	}
	dec := json.NewDecoder(bytes.NewReader(raw))
	if err := dec.Decode(&root); err != nil {
		return fmt.Errorf("decode Docker inventory envelope: %w", err)
	}
	if dockerStatus, ok := root.Collection.Collectors["docker"]; ok && !dockerCollectorStatusUsable(dockerStatus.Status) {
		// Disabled, failed or timed-out Docker collection must not erase the
		// last known good topology and service mappings. A partial Docker
		// collection is still usable: the agent emits partial for any warning,
		// even when the Docker payload itself contains valid engine/container
		// data (for example one optional inspect/info warning).
		return nil
	}
	if len(bytes.TrimSpace(root.Docker)) == 0 || bytes.Equal(bytes.TrimSpace(root.Docker), []byte("null")) {
		// Old agents do not have a docker section. Do not erase the last known
		// structured Docker inventory merely because an older agent reported.
		return nil
	}
	var payload agentDocker
	if err := json.Unmarshal(root.Docker, &payload); err != nil {
		return fmt.Errorf("decode Docker inventory: %w", err)
	}
	now := time.Now().UTC()
	running := 0
	for _, c := range payload.Containers {
		if strings.EqualFold(strings.TrimSpace(c.State), "running") {
			running++
		}
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO docker_hosts(vm_id,current_inventory_id,installed,available,executable,service_state,engine_version,api_version,engine_os,architecture,storage_driver,logging_driver,cgroup_driver,cgroup_version,docker_root_dir,container_count,running_count,image_count,network_count,volume_count,compose_project_count,observed_at)
		VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
		ON DUPLICATE KEY UPDATE current_inventory_id=VALUES(current_inventory_id),installed=VALUES(installed),available=VALUES(available),executable=VALUES(executable),service_state=VALUES(service_state),engine_version=VALUES(engine_version),api_version=VALUES(api_version),engine_os=VALUES(engine_os),architecture=VALUES(architecture),storage_driver=VALUES(storage_driver),logging_driver=VALUES(logging_driver),cgroup_driver=VALUES(cgroup_driver),cgroup_version=VALUES(cgroup_version),docker_root_dir=VALUES(docker_root_dir),container_count=VALUES(container_count),running_count=VALUES(running_count),image_count=VALUES(image_count),network_count=VALUES(network_count),volume_count=VALUES(volume_count),compose_project_count=VALUES(compose_project_count),observed_at=VALUES(observed_at)`,
		vmID, inventoryID, payload.Installed, payload.Available, payload.Executable, payload.ServiceState, payload.Version, payload.APIVersion, payload.OS, payload.Architecture, payload.StorageDriver, payload.LoggingDriver, payload.CgroupDriver, payload.CgroupVersion, payload.DockerRootDir, len(payload.Containers), running, len(payload.Images), len(payload.Networks), len(payload.Volumes), len(payload.ComposeProjects), now)
	if err != nil {
		return fmt.Errorf("upsert Docker host: %w", err)
	}

	for _, table := range []string{"docker_containers", "docker_images", "docker_networks", "docker_volumes"} {
		if _, err := tx.ExecContext(ctx, `UPDATE `+table+` SET present=0 WHERE vm_id=?`, vmID); err != nil {
			return err
		}
	}
	for _, c := range payload.Containers {
		containerID, err := upsertContainer(ctx, tx, vmID, inventoryID, c, now)
		if err != nil {
			return err
		}
		if err := syncLabelAssignments(ctx, tx, containerID, c); err != nil {
			return err
		}
	}
	for _, image := range payload.Images {
		if err := upsertImage(ctx, tx, vmID, inventoryID, image, now); err != nil {
			return err
		}
	}
	for _, network := range payload.Networks {
		if err := upsertNetwork(ctx, tx, vmID, inventoryID, network, now); err != nil {
			return err
		}
	}
	for _, volume := range payload.Volumes {
		if err := upsertVolume(ctx, tx, vmID, inventoryID, volume, now); err != nil {
			return err
		}
	}
	return nil
}

func dockerCollectorStatusUsable(status string) bool {
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "success", "partial":
		return true
	default:
		return false
	}
}

func containerIdentity(c agentContainer) string {
	project := strings.TrimSpace(c.ComposeProject)
	service := strings.TrimSpace(c.ComposeService)
	if project != "" && service != "" {
		number := strings.TrimSpace(c.Labels["com.docker.compose.container-number"])
		if number != "" {
			return "compose:" + project + ":" + service + ":" + number
		}
		if name := strings.TrimSpace(c.Name); name != "" {
			return "compose:" + project + ":" + service + ":" + name
		}
	}
	if name := strings.TrimSpace(c.Name); name != "" {
		return "name:" + name
	}
	return "id:" + strings.TrimSpace(c.ID)
}

func upsertContainer(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, c agentContainer, now time.Time) (int64, error) {
	identity := containerIdentity(c)
	jsonValue := func(v any) string {
		b, _ := json.Marshal(v)
		return string(b)
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO docker_containers(vm_id,identity_key,engine_container_id,name,image_ref,image_id,state,status,health,created_at_engine,started_at,finished_at,restart_policy,restart_maximum_retry_count,privileged,readonly_rootfs,network_mode,run_as_user,working_dir,memory_limit_bytes,nano_cpus,cpu_quota,cpu_period,pids_limit,docker_socket_mounted,compose_project,compose_service,compose_working_dir,compose_config_files_json,environment_keys_json,labels_json,ports_json,mounts_json,networks_json,cap_add_json,security_opt_json,present,current_inventory_id,last_seen_at)
		VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
		ON DUPLICATE KEY UPDATE engine_container_id=VALUES(engine_container_id),name=VALUES(name),image_ref=VALUES(image_ref),image_id=VALUES(image_id),state=VALUES(state),status=VALUES(status),health=VALUES(health),created_at_engine=VALUES(created_at_engine),started_at=VALUES(started_at),finished_at=VALUES(finished_at),restart_policy=VALUES(restart_policy),restart_maximum_retry_count=VALUES(restart_maximum_retry_count),privileged=VALUES(privileged),readonly_rootfs=VALUES(readonly_rootfs),network_mode=VALUES(network_mode),run_as_user=VALUES(run_as_user),working_dir=VALUES(working_dir),memory_limit_bytes=VALUES(memory_limit_bytes),nano_cpus=VALUES(nano_cpus),cpu_quota=VALUES(cpu_quota),cpu_period=VALUES(cpu_period),pids_limit=VALUES(pids_limit),docker_socket_mounted=VALUES(docker_socket_mounted),compose_project=VALUES(compose_project),compose_service=VALUES(compose_service),compose_working_dir=VALUES(compose_working_dir),compose_config_files_json=VALUES(compose_config_files_json),environment_keys_json=VALUES(environment_keys_json),labels_json=VALUES(labels_json),ports_json=VALUES(ports_json),mounts_json=VALUES(mounts_json),networks_json=VALUES(networks_json),cap_add_json=VALUES(cap_add_json),security_opt_json=VALUES(security_opt_json),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`,
		vmID, identity, c.ID, c.Name, c.Image, c.ImageID, c.State, c.Status, c.Health, c.CreatedAt, c.StartedAt, c.FinishedAt, c.RestartPolicy, c.RestartMaximumRetryCount, c.Privileged, c.ReadonlyRootFS, c.NetworkMode, c.User, c.WorkingDir, c.MemoryLimitBytes, c.NanoCPUs, c.CPUQuota, c.CPUPeriod, c.PidsLimit, c.DockerSocketMounted, c.ComposeProject, c.ComposeService, c.ComposeWorkingDir, jsonValue(c.ComposeConfigFiles), jsonValue(c.EnvironmentKeys), jsonValue(c.Labels), jsonValue(c.Ports), jsonValue(c.Mounts), jsonValue(c.Networks), jsonValue(c.CapAdd), jsonValue(c.SecurityOpt), true, inventoryID, now)
	if err != nil {
		return 0, fmt.Errorf("upsert Docker container %q: %w", c.Name, err)
	}
	var id int64
	if err := tx.QueryRowContext(ctx, `SELECT id FROM docker_containers WHERE vm_id=? AND identity_key=?`, vmID, identity).Scan(&id); err != nil {
		return 0, err
	}
	return id, nil
}

func upsertImage(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, image agentImage, now time.Time) error {
	tags, _ := json.Marshal(image.RepoTags)
	digests, _ := json.Marshal(image.RepoDigests)
	_, err := tx.ExecContext(ctx, `INSERT INTO docker_images(vm_id,engine_image_id,repo_tags_json,repo_digests_json,created_at_engine,size_bytes,architecture,image_os,present,current_inventory_id,last_seen_at) VALUES(?,?,?,?,?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE repo_tags_json=VALUES(repo_tags_json),repo_digests_json=VALUES(repo_digests_json),created_at_engine=VALUES(created_at_engine),size_bytes=VALUES(size_bytes),architecture=VALUES(architecture),image_os=VALUES(image_os),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`, vmID, image.ID, tags, digests, image.CreatedAt, image.SizeBytes, image.Architecture, image.OS, inventoryID, now)
	return err
}

func upsertNetwork(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, network agentNetwork, now time.Time) error {
	ipam, _ := json.Marshal(network.IPAM)
	labels, _ := json.Marshal(network.Labels)
	_, err := tx.ExecContext(ctx, `INSERT INTO docker_networks(vm_id,engine_network_id,name,driver,scope,internal,attachable,ingress,ipam_json,labels_json,present,current_inventory_id,last_seen_at) VALUES(?,?,?,?,?,?,?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),driver=VALUES(driver),scope=VALUES(scope),internal=VALUES(internal),attachable=VALUES(attachable),ingress=VALUES(ingress),ipam_json=VALUES(ipam_json),labels_json=VALUES(labels_json),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`, vmID, network.ID, network.Name, network.Driver, network.Scope, network.Internal, network.Attachable, network.Ingress, ipam, labels, inventoryID, now)
	return err
}

func upsertVolume(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, volume agentVolume, now time.Time) error {
	labels, _ := json.Marshal(volume.Labels)
	_, err := tx.ExecContext(ctx, `INSERT INTO docker_volumes(vm_id,name,driver,mountpoint,scope,labels_json,present,current_inventory_id,last_seen_at) VALUES(?,?,?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE driver=VALUES(driver),mountpoint=VALUES(mountpoint),scope=VALUES(scope),labels_json=VALUES(labels_json),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`, vmID, volume.Name, volume.Driver, volume.Mountpoint, volume.Scope, labels, inventoryID, now)
	return err
}

func syncLabelAssignments(ctx context.Context, tx *sql.Tx, containerID int64, c agentContainer) error {
	if _, err := tx.ExecContext(ctx, `DELETE FROM docker_container_service_assignments WHERE docker_container_id=? AND assignment_source='label'`, containerID); err != nil {
		return err
	}
	labels := c.Labels
	if len(labels) == 0 {
		return nil
	}
	serviceRefs := make([]string, 0)
	if v := strings.TrimSpace(labels["vm-doc.service"]); v != "" {
		serviceRefs = append(serviceRefs, v)
	}
	if v := strings.TrimSpace(labels["vm-doc.services"]); v != "" {
		v = strings.ReplaceAll(v, ";", ",")
		for _, part := range strings.Split(v, ",") {
			if part = strings.TrimSpace(part); part != "" {
				serviceRefs = append(serviceRefs, part)
			}
		}
	}
	seen := map[int64]struct{}{}
	for _, ref := range serviceRefs {
		var serviceID int64
		err := tx.QueryRowContext(ctx, `SELECT id FROM internal_services WHERE LOWER(service_code)=LOWER(?) OR LOWER(name)=LOWER(?) ORDER BY CASE WHEN LOWER(service_code)=LOWER(?) THEN 0 ELSE 1 END,id LIMIT 1`, ref, ref, ref).Scan(&serviceID)
		if errors.Is(err, sql.ErrNoRows) {
			continue
		}
		if err != nil {
			return err
		}
		if _, ok := seen[serviceID]; ok {
			continue
		}
		seen[serviceID] = struct{}{}
		_, err = tx.ExecContext(ctx, `INSERT INTO docker_container_service_assignments(docker_container_id,internal_service_id,assignment_source,component_name,role_name,notes) VALUES(?,?,'label',?,?,?) ON DUPLICATE KEY UPDATE component_name=VALUES(component_name),role_name=VALUES(role_name),notes=VALUES(notes)`, containerID, serviceID, strings.TrimSpace(labels["vm-doc.component"]), strings.TrimSpace(labels["vm-doc.role"]), "Docker label")
		if err != nil {
			return err
		}
	}
	return nil
}

func (s Service) ensureCurrentSnapshot(ctx context.Context, vmID int64) error {
	if s.DB == nil || vmID < 1 {
		return nil
	}
	var inventoryID int64
	var raw []byte
	var normalizedInventoryID sql.NullInt64
	err := s.DB.QueryRowContext(ctx, `SELECT vm.current_inventory_id,i.raw_json,dh.current_inventory_id
		FROM virtual_machines vm
		JOIN inventory_snapshots i ON i.id=vm.current_inventory_id
		LEFT JOIN docker_hosts dh ON dh.vm_id=vm.id
		WHERE vm.id=? AND vm.current_inventory_id IS NOT NULL`, vmID).Scan(&inventoryID, &raw, &normalizedInventoryID)
	if errors.Is(err, sql.ErrNoRows) {
		return nil
	}
	if err != nil {
		return err
	}
	if normalizedInventoryID.Valid && normalizedInventoryID.Int64 == inventoryID {
		return nil
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if err := s.Sync(ctx, tx, vmID, inventoryID, raw); err != nil {
		return err
	}
	return tx.Commit()
}

func (s Service) GetVM(ctx context.Context, vmID int64) (domain.DockerVMView, error) {
	view := domain.DockerVMView{Containers: []domain.DockerContainer{}, Images: []domain.DockerImage{}, Networks: []domain.DockerNetwork{}, Volumes: []domain.DockerVolume{}, ComposeProjects: []domain.DockerComposeProject{}}
	if s.DB == nil {
		return view, nil
	}
	// 0.14.1 self-healing/backfill: 0.14.0 stored the raw inventory snapshot
	// but skipped Docker normalization whenever the collector status was
	// "partial". If the current VM snapshot is newer than the normalized
	// Docker row (or there is no row yet), retry normalization from raw_json.
	// This makes already collected Docker data visible without requiring a new
	// agent collection after upgrading the server.
	if err := s.ensureCurrentSnapshot(ctx, vmID); err != nil {
		return view, fmt.Errorf("synchronize current Docker snapshot: %w", err)
	}
	var host domain.DockerHostSummary
	var observed sql.NullTime
	err := s.DB.QueryRowContext(ctx, `SELECT vm_id,installed,documentation_exempt,available,executable,service_state,engine_version,api_version,engine_os,architecture,storage_driver,logging_driver,cgroup_driver,cgroup_version,docker_root_dir,container_count,running_count,image_count,network_count,volume_count,compose_project_count,observed_at FROM docker_hosts WHERE vm_id=?`, vmID).Scan(&host.VMID, &host.Installed, &host.DocumentationExempt, &host.Available, &host.Executable, &host.ServiceState, &host.Version, &host.APIVersion, &host.OS, &host.Architecture, &host.StorageDriver, &host.LoggingDriver, &host.CgroupDriver, &host.CgroupVersion, &host.DockerRootDir, &host.ContainerCount, &host.RunningCount, &host.ImageCount, &host.NetworkCount, &host.VolumeCount, &host.ComposeProjectCount, &observed)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return view, err
	}
	if err == nil {
		if observed.Valid {
			t := observed.Time
			host.ObservedAt = &t
		}
		view.Host = &host
	}
	containers, err := s.listContainers(ctx, `WHERE c.vm_id=? AND c.present=1`, vmID)
	if err != nil {
		return view, err
	}
	view.Containers = containers
	if err := s.loadImages(ctx, vmID, &view); err != nil {
		return view, err
	}
	if err := s.loadNetworks(ctx, vmID, &view); err != nil {
		return view, err
	}
	if err := s.loadVolumes(ctx, vmID, &view); err != nil {
		return view, err
	}
	view.ComposeProjects = composeProjectsFromContainers(containers)
	return view, nil
}

func (s Service) SetContainerDocumentationExempt(ctx context.Context, vmID, containerID int64, exempt bool) error {
	if s.DB == nil {
		return errors.New("docker inventory service is not configured")
	}
	result, err := s.DB.ExecContext(ctx, `UPDATE docker_containers SET documentation_exempt=? WHERE id=? AND vm_id=?`, exempt, containerID, vmID)
	if err != nil {
		return err
	}
	n, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) SetHostDocumentationExempt(ctx context.Context, vmID int64, exempt bool) error {
	if s.DB == nil {
		return errors.New("docker inventory service is not configured")
	}
	result, err := s.DB.ExecContext(ctx, `UPDATE docker_hosts SET documentation_exempt=? WHERE vm_id=?`, exempt, vmID)
	if err != nil {
		return err
	}
	n, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) ListForService(ctx context.Context, serviceID int64) ([]domain.DockerContainer, error) {
	if s.DB == nil {
		return []domain.DockerContainer{}, nil
	}
	return s.listContainers(ctx, `JOIN docker_container_service_assignments dsa_filter ON dsa_filter.docker_container_id=c.id JOIN docker_hosts dh_filter ON dh_filter.vm_id=c.vm_id WHERE dsa_filter.internal_service_id=? AND c.present=1 AND c.documentation_exempt=0 AND dh_filter.documentation_exempt=0`, serviceID)
}

func (s Service) listContainers(ctx context.Context, suffix string, arg any) ([]domain.DockerContainer, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT DISTINCT c.id,c.vm_id,vm.name,vm.guest_hostname,c.identity_key,c.engine_container_id,c.name,c.image_ref,c.image_id,c.state,c.status,c.health,c.created_at_engine,c.started_at,c.finished_at,c.restart_policy,c.restart_maximum_retry_count,c.privileged,c.readonly_rootfs,c.network_mode,c.run_as_user,c.working_dir,c.memory_limit_bytes,c.nano_cpus,c.cpu_quota,c.cpu_period,c.pids_limit,c.docker_socket_mounted,c.compose_project,c.compose_service,c.compose_working_dir,c.compose_config_files_json,c.environment_keys_json,c.labels_json,c.ports_json,c.mounts_json,c.networks_json,c.cap_add_json,c.security_opt_json,c.present,c.documentation_exempt,c.last_seen_at FROM docker_containers c JOIN virtual_machines vm ON vm.id=c.vm_id `+suffix+` ORDER BY vm.name,c.compose_project,c.name`, arg)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.DockerContainer{}
	for rows.Next() {
		var c domain.DockerContainer
		var created, started, finished sql.NullTime
		var composeFiles, envKeys, labels, ports, mounts, networks, capAdd, securityOpt sql.NullString
		if err := rows.Scan(&c.ID, &c.VMID, &c.VMName, &c.VMHostname, &c.IdentityKey, &c.EngineContainerID, &c.Name, &c.Image, &c.ImageID, &c.State, &c.Status, &c.Health, &created, &started, &finished, &c.RestartPolicy, &c.RestartMaximumRetryCount, &c.Privileged, &c.ReadonlyRootFS, &c.NetworkMode, &c.User, &c.WorkingDir, &c.MemoryLimitBytes, &c.NanoCPUs, &c.CPUQuota, &c.CPUPeriod, &c.PidsLimit, &c.DockerSocketMounted, &c.ComposeProject, &c.ComposeService, &c.ComposeWorkingDir, &composeFiles, &envKeys, &labels, &ports, &mounts, &networks, &capAdd, &securityOpt, &c.Present, &c.DocumentationExempt, &c.LastSeenAt); err != nil {
			return nil, err
		}
		if created.Valid {
			t := created.Time
			c.CreatedAt = &t
		}
		if started.Valid {
			t := started.Time
			c.StartedAt = &t
		}
		if finished.Valid {
			t := finished.Time
			c.FinishedAt = &t
		}
		decodeJSON(composeFiles.String, &c.ComposeConfigFiles)
		decodeJSON(envKeys.String, &c.EnvironmentKeys)
		decodeJSON(labels.String, &c.Labels)
		decodeJSON(ports.String, &c.Ports)
		decodeJSON(mounts.String, &c.Mounts)
		decodeJSON(networks.String, &c.Networks)
		decodeJSON(capAdd.String, &c.CapAdd)
		decodeJSON(securityOpt.String, &c.SecurityOpt)
		assignments, err := s.assignments(ctx, c.ID)
		if err != nil {
			return nil, err
		}
		c.ServiceAssignments = assignments
		out = append(out, c)
	}
	return out, rows.Err()
}

func decodeJSON(raw string, target any) {
	if strings.TrimSpace(raw) != "" {
		_ = json.Unmarshal([]byte(raw), target)
	}
}

func (s Service) assignments(ctx context.Context, containerID int64) ([]domain.DockerServiceAssignment, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT dsa.id,dsa.internal_service_id,svc.name,COALESCE(svc.service_code,''),dsa.assignment_source,dsa.environment_id,COALESCE(env.name,''),dsa.operational_status_id,COALESCE(st.name,''),dsa.solution_type_id,COALESCE(sol.name,''),dsa.component_name,dsa.role_name,dsa.notes FROM docker_container_service_assignments dsa JOIN internal_services svc ON svc.id=dsa.internal_service_id LEFT JOIN nomenclature_items env ON env.id=dsa.environment_id LEFT JOIN nomenclature_items st ON st.id=dsa.operational_status_id LEFT JOIN nomenclature_items sol ON sol.id=dsa.solution_type_id WHERE dsa.docker_container_id=? ORDER BY svc.name,dsa.assignment_source`, containerID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.DockerServiceAssignment{}
	for rows.Next() {
		var a domain.DockerServiceAssignment
		var environmentID, statusID, solutionTypeID sql.NullInt64
		if err := rows.Scan(&a.ID, &a.ServiceID, &a.ServiceName, &a.ServiceCode, &a.Source, &environmentID, &a.Environment, &statusID, &a.OperationalStatus, &solutionTypeID, &a.SolutionType, &a.ComponentName, &a.RoleName, &a.Notes); err != nil {
			return nil, err
		}
		if environmentID.Valid {
			v := environmentID.Int64
			a.EnvironmentID = &v
		}
		if statusID.Valid {
			v := statusID.Int64
			a.OperationalStatusID = &v
		}
		if solutionTypeID.Valid {
			v := solutionTypeID.Int64
			a.SolutionTypeID = &v
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

func (s Service) loadImages(ctx context.Context, vmID int64, view *domain.DockerVMView) error {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,engine_image_id,repo_tags_json,repo_digests_json,created_at_engine,size_bytes,architecture,image_os FROM docker_images WHERE vm_id=? AND present=1 ORDER BY id`, vmID)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var i domain.DockerImage
		var tags, digests sql.NullString
		var created sql.NullTime
		if err := rows.Scan(&i.ID, &i.EngineID, &tags, &digests, &created, &i.SizeBytes, &i.Architecture, &i.OS); err != nil {
			return err
		}
		decodeJSON(tags.String, &i.RepoTags)
		decodeJSON(digests.String, &i.RepoDigests)
		if created.Valid {
			t := created.Time
			i.CreatedAt = &t
		}
		view.Images = append(view.Images, i)
	}
	return rows.Err()
}
func (s Service) loadNetworks(ctx context.Context, vmID int64, view *domain.DockerVMView) error {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,engine_network_id,name,driver,scope,internal,attachable,ingress,ipam_json,labels_json FROM docker_networks WHERE vm_id=? AND present=1 ORDER BY name`, vmID)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var n domain.DockerNetwork
		var ipam, labels sql.NullString
		if err := rows.Scan(&n.ID, &n.EngineID, &n.Name, &n.Driver, &n.Scope, &n.Internal, &n.Attachable, &n.Ingress, &ipam, &labels); err != nil {
			return err
		}
		decodeJSON(ipam.String, &n.IPAM)
		decodeJSON(labels.String, &n.Labels)
		view.Networks = append(view.Networks, n)
	}
	return rows.Err()
}
func (s Service) loadVolumes(ctx context.Context, vmID int64, view *domain.DockerVMView) error {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,name,driver,mountpoint,scope,labels_json FROM docker_volumes WHERE vm_id=? AND present=1 ORDER BY name`, vmID)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var v domain.DockerVolume
		var labels sql.NullString
		if err := rows.Scan(&v.ID, &v.Name, &v.Driver, &v.Mountpoint, &v.Scope, &labels); err != nil {
			return err
		}
		decodeJSON(labels.String, &v.Labels)
		view.Volumes = append(view.Volumes, v)
	}
	return rows.Err()
}

func composeProjectsFromContainers(containers []domain.DockerContainer) []domain.DockerComposeProject {
	projects := map[string]*domain.DockerComposeProject{}
	serviceSets := map[string]map[string]struct{}{}
	fileSets := map[string]map[string]struct{}{}
	for _, c := range containers {
		p := strings.TrimSpace(c.ComposeProject)
		if p == "" {
			continue
		}
		item := projects[p]
		if item == nil {
			item = &domain.DockerComposeProject{Name: p}
			projects[p] = item
			serviceSets[p] = map[string]struct{}{}
			fileSets[p] = map[string]struct{}{}
		}
		item.ContainerCount++
		if item.WorkingDir == "" {
			item.WorkingDir = c.ComposeWorkingDir
		}
		if c.ComposeService != "" {
			serviceSets[p][c.ComposeService] = struct{}{}
		}
		for _, f := range c.ComposeConfigFiles {
			if f != "" {
				fileSets[p][f] = struct{}{}
			}
		}
	}
	out := make([]domain.DockerComposeProject, 0, len(projects))
	for name, item := range projects {
		for v := range serviceSets[name] {
			item.Services = append(item.Services, v)
		}
		for v := range fileSets[name] {
			item.ConfigFiles = append(item.ConfigFiles, v)
		}
		sort.Strings(item.Services)
		sort.Strings(item.ConfigFiles)
		out = append(out, *item)
	}
	sort.Slice(out, func(i, j int) bool { return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name) })
	return out
}

func (s Service) ReplaceManualAssignments(ctx context.Context, vmID, containerID, userID int64, inputs []AssignmentInput) error {
	if s.DB == nil {
		return errors.New("Docker inventory service is not configured")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	var exists int
	if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM docker_containers WHERE id=? AND vm_id=?`, containerID, vmID).Scan(&exists); err != nil {
		return err
	}
	if exists == 0 {
		return sql.ErrNoRows
	}
	if err := validateAssignments(ctx, tx, inputs); err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM docker_container_service_assignments WHERE docker_container_id=? AND assignment_source='manual'`, containerID); err != nil {
		return err
	}
	for _, in := range dedupeInputs(inputs) {
		if _, err := tx.ExecContext(ctx, `INSERT INTO docker_container_service_assignments(docker_container_id,internal_service_id,assignment_source,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by) VALUES(?,?,'manual',?,?,?,?,?,?,?,?)`, containerID, in.ServiceID, nullableInt64(in.EnvironmentID), nullableInt64(in.OperationalStatusID), nullableInt64(in.SolutionTypeID), clean(in.ComponentName, 255), clean(in.RoleName, 255), clean(in.Notes, 1000), nullableUser(userID), nullableUser(userID)); err != nil {
			return err
		}
	}
	return tx.Commit()
}

func (s Service) AssignComposeProject(ctx context.Context, vmID int64, project string, userID int64, inputs []AssignmentInput) (int64, error) {
	project = strings.TrimSpace(project)
	if project == "" {
		return 0, errors.New("compose project is required")
	}
	if s.DB == nil {
		return 0, errors.New("Docker inventory service is not configured")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback()
	if err := validateAssignments(ctx, tx, inputs); err != nil {
		return 0, err
	}
	rows, err := tx.QueryContext(ctx, `SELECT id FROM docker_containers WHERE vm_id=? AND present=1 AND compose_project=? ORDER BY id`, vmID, project)
	if err != nil {
		return 0, err
	}
	ids := []int64{}
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			rows.Close()
			return 0, err
		}
		ids = append(ids, id)
	}
	rows.Close()
	if len(ids) == 0 {
		return 0, sql.ErrNoRows
	}
	var changed int64
	for _, cid := range ids {
		for _, in := range dedupeInputs(inputs) {
			res, err := tx.ExecContext(ctx, `INSERT INTO docker_container_service_assignments(docker_container_id,internal_service_id,assignment_source,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by) VALUES(?,?,'manual',?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE environment_id=VALUES(environment_id),operational_status_id=VALUES(operational_status_id),solution_type_id=VALUES(solution_type_id),component_name=VALUES(component_name),role_name=VALUES(role_name),notes=VALUES(notes),updated_by=VALUES(updated_by)`, cid, in.ServiceID, nullableInt64(in.EnvironmentID), nullableInt64(in.OperationalStatusID), nullableInt64(in.SolutionTypeID), clean(in.ComponentName, 255), clean(in.RoleName, 255), clean(in.Notes, 1000), nullableUser(userID), nullableUser(userID))
			if err != nil {
				return 0, err
			}
			n, _ := res.RowsAffected()
			if n > 0 {
				changed++
			}
		}
	}
	return changed, tx.Commit()
}

func validateAssignments(ctx context.Context, tx *sql.Tx, inputs []AssignmentInput) error {
	for _, in := range dedupeInputs(inputs) {
		if in.ServiceID < 1 {
			return errors.New("service_id must be positive")
		}
		var n int
		if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM internal_services WHERE id=?`, in.ServiceID).Scan(&n); err != nil {
			return err
		}
		if n == 0 {
			return fmt.Errorf("internal service %d does not exist", in.ServiceID)
		}
		if err := validateAssignmentNomenclature(ctx, tx, in.EnvironmentID, "environment"); err != nil {
			return err
		}
		if err := validateAssignmentNomenclature(ctx, tx, in.OperationalStatusID, "operational_status"); err != nil {
			return err
		}
		if err := validateAssignmentNomenclature(ctx, tx, in.SolutionTypeID, "solution_type"); err != nil {
			return err
		}
	}
	return nil
}

func validateAssignmentNomenclature(ctx context.Context, tx *sql.Tx, id *int64, category string) error {
	if id == nil || *id < 1 {
		return nil
	}
	var n int
	if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM nomenclature_items WHERE id=? AND category_code=?`, *id, category).Scan(&n); err != nil {
		return err
	}
	if n == 0 {
		return fmt.Errorf("nomenclature item %d is not in %s", *id, category)
	}
	return nil
}

func nullableInt64(value *int64) any {
	if value != nil && *value > 0 {
		return *value
	}
	return nil
}
func dedupeInputs(inputs []AssignmentInput) []AssignmentInput {
	seen := map[int64]struct{}{}
	out := []AssignmentInput{}
	for _, in := range inputs {
		if in.ServiceID < 1 {
			continue
		}
		if _, ok := seen[in.ServiceID]; ok {
			continue
		}
		seen[in.ServiceID] = struct{}{}
		out = append(out, in)
	}
	return out
}
func nullableUser(id int64) any {
	if id > 0 {
		return id
	}
	return nil
}
func clean(v string, max int) string {
	v = strings.TrimSpace(v)
	if len(v) > max {
		return v[:max]
	}
	return v
}
