package documents

import (
	"sort"
	"strconv"
	"strings"

	"vm-doc-server/internal/inventory"
)

// compactInventoryMarkdown mirrors the structured inventory presentation used by
// compactInventoryXML. The goal is for Outline/Markdown annexes to contain the
// same operational information and table shapes as the Word VM sheet instead of
// a flattened key/value dump.
func compactInventoryMarkdown(out *strings.Builder, view *inventory.DocumentView, headingLevel int) {
	if view == nil {
		return
	}
	sections := make(map[string]any, len(view.Sections))
	for _, section := range view.Sections {
		key := normalizeInventoryKey(section.Key)
		if key != "" {
			sections[key] = section.Data
		}
	}
	add := func(title string, render func()) {
		markdownHeading(out, headingLevel, title)
		render()
	}

	add("Sistem și hardware", func() {
		markdownKeyValueTable(out, mergedCompactMarkdownRows(sections, []string{"identity", "host", "system"}, map[string]bool{"uptimeseconds": true}, 36))
	})
	add("Sistem de operare", func() {
		markdownKeyValueTable(out, mergedCompactMarkdownRows(sections, []string{"os", "operatingsystem"}, nil, 24))
	})
	add("Stocare", func() {
		markdownRawTable(out, []string{"Partiție", "Filesystem", "Capacitate"}, storageMarkdownRows(sections))
	})
	add("Rețea", func() {
		markdownRawTable(out, []string{"IP", "Mask / Gateway", "DNS", "Interfață"}, networkMarkdownRows(sectionValue(sections, "network")))
	})
	add("Servicii active", func() {
		markdownRawTable(out, []string{"Nume", "Descriere"}, servicesMarkdownRows(sectionValue(sections, "services")))
	})
	add("Porturi ascultate", func() {
		markdownRawTable(out, []string{"Nume / proces", "Executabil", "Adresă", "Port", "Protocol"}, portsMarkdownRows(sectionValue(sections, "listeningports")))
	})
	add("Firewall", func() { firewallMarkdown(out, sectionValue(sections, "firewall"), headingLevel+1) })
	add("Conturi importante", func() {
		markdownRawTable(out, []string{"Utilizator", "UID", "Home", "Grupuri / shell"}, accountsMarkdownRows(sectionValue(sections, "accounts")))
	})
	add("Integrare SSSD", func() {
		markdownRawTable(out, []string{"SSSD", "LDAP search base", "Versiune"}, sssdMarkdownRows(sectionValue(sections, "sssd")))
	})
	add("Integrări operaționale", func() {
		markdownRawTable(out, []string{"Integrare", "Activ", "Versiune", "Config OK", "Output host", "Detalii"}, integrationsMarkdownRows(sectionValue(sections, "integrations"), sections))
	})
	if policies := sectionValue(sections, "policies"); policies != nil && len(flattenValue(policies, 12)) > 0 {
		add("Politici", func() { markdownKeyValueTable(out, compactMarkdownRows(policies, nil, 12)) })
	}
	add("Sarcini programate", func() {
		markdownRawTable(out, []string{"Programare", "Comandă", "Utilizator"}, cronMarkdownRows(sectionValue(sections, "cron")))
	})
	add("Sincronizare timp", func() {
		markdownRawTable(out, []string{"Fișier configurație", "Sursă", "Versiune"}, ntpMarkdownRows(sectionValue(sections, "ntp")))
	})
}

func markdownRawTable(out *strings.Builder, headers []string, rows [][]string) {
	if len(rows) == 0 {
		out.WriteString("_Nu există date._\n\n")
		return
	}
	out.WriteString("|")
	for _, h := range headers {
		out.WriteString(" ")
		out.WriteString(markdownTableCell(h))
		out.WriteString(" |")
	}
	out.WriteString("\n|")
	for range headers {
		out.WriteString("---|")
	}
	out.WriteString("\n")
	for _, row := range rows {
		out.WriteString("|")
		for i := range headers {
			value := ""
			if i < len(row) {
				value = row[i]
			}
			out.WriteString(" ")
			out.WriteString(markdownTableCell(value))
			out.WriteString(" |")
		}
		out.WriteString("\n")
	}
	out.WriteString("\n")
}

func compactMarkdownRows(value any, excluded map[string]bool, limit int) []PreviewRow {
	rows := flattenValue(value, limit)
	filtered := make([]PreviewRow, 0, len(rows))
	seen := make(map[string]bool)
	for _, row := range rows {
		key := normalizeInventoryKey(row.Label)
		if excluded != nil && excluded[key] {
			continue
		}
		if strings.Contains(key, "uptimeseconds") {
			continue
		}
		row.Label = compactLabel(row.Label)
		row.Value = humanizeValueForLabel(row.Label, row.Value)
		dedupe := normalizeInventoryKey(row.Label) + "\x00" + strings.TrimSpace(row.Value)
		if seen[dedupe] {
			continue
		}
		seen[dedupe] = true
		filtered = append(filtered, row)
	}
	return filtered
}

func mergedCompactMarkdownRows(sections map[string]any, keys []string, excluded map[string]bool, limit int) []PreviewRow {
	rows := make([]PreviewRow, 0)
	seen := make(map[string]bool)
	for _, key := range keys {
		value := sectionValue(sections, key)
		if value == nil {
			continue
		}
		for _, row := range flattenValue(value, limit) {
			normalized := normalizeInventoryKey(row.Label)
			if excluded != nil && excluded[normalized] {
				continue
			}
			if strings.Contains(normalized, "uptimeseconds") {
				continue
			}
			row.Label = compactLabel(row.Label)
			row.Value = humanizeValueForLabel(row.Label, row.Value)
			dedupe := normalizeInventoryKey(row.Label) + "\x00" + strings.TrimSpace(row.Value)
			if seen[dedupe] {
				continue
			}
			seen[dedupe] = true
			rows = append(rows, row)
			if len(rows) >= limit {
				return rows
			}
		}
	}
	return rows
}

func storageMarkdownRows(sections map[string]any) [][]string {
	values := []any{sectionValue(sections, "storage"), sectionValue(sections, "disks"), sectionValue(sections, "mounts")}
	type row struct{ partition, filesystem, capacity string }
	rows := make([]row, 0)
	seen := make(map[string]bool)
	for _, value := range values {
		walkRecordMaps(value, "", func(record map[string]any, hint string) {
			partition := firstMapText(record, "partition", "mount_point", "mountpoint", "mount", "device", "path", "name", "volume")
			if partition == "" {
				partition = hint
			}
			filesystem := firstMapText(record, "filesystem", "file_system", "fs_type", "fstype", "filesystem_type", "type")
			capacity := ""
			if v, ok := firstMapValue(record, "capacity_bytes", "size_bytes", "total_bytes", "bytes_total", "capacity", "size", "total"); ok {
				capacity = humanCapacity(v)
			}
			if strings.TrimSpace(partition) == "" || (filesystem == "" && capacity == "") {
				return
			}
			key := strings.ToLower(partition + "\x00" + filesystem + "\x00" + capacity)
			if seen[key] {
				return
			}
			seen[key] = true
			rows = append(rows, row{partition, filesystem, capacity})
		})
	}
	sort.SliceStable(rows, func(i, j int) bool { return strings.ToLower(rows[i].partition) < strings.ToLower(rows[j].partition) })
	out := make([][]string, 0, len(rows))
	for _, r := range rows {
		out = append(out, []string{r.partition, r.filesystem, r.capacity})
	}
	return out
}

func networkMarkdownRows(value any) [][]string {
	type row struct{ ip, maskGateway, dns, iface string }
	rows := make([]row, 0)
	seen := make(map[string]bool)
	rootDNS := recursiveTextList(value, "dns", "dns_servers", "nameservers", "name_servers")
	rootGateway := recursiveFirstText(value, "gateway", "default_gateway", "gateway4", "gateway6")
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		iface := firstMapText(record, "interface_name", "interface", "ifname", "device", "name")
		if iface == "" && !genericHint(hint) {
			iface = hint
		}
		gateway := firstMapText(record, "gateway", "default_gateway", "gateway4", "gateway6")
		if gateway == "" {
			gateway = rootGateway
		}
		dns := strings.Join(uniqueStrings(append(textListFromMap(record, "dns", "dns_servers", "nameservers", "name_servers"), rootDNS...)), ", ")
		addresses := addressValues(record)
		if len(addresses) == 0 {
			ip := firstMapText(record, "primary_ip", "ip", "ip_address", "address")
			if ip != "" {
				addresses = append(addresses, networkAddress{IP: ip, Mask: firstMapText(record, "mask", "netmask", "prefix", "prefix_length", "cidr")})
			}
		}
		for _, a := range addresses {
			if a.IP == "" || (strings.Contains(a.IP, ":") && strings.HasPrefix(strings.ToLower(a.IP), "fe80:")) {
				continue
			}
			parts := []string{}
			if a.Mask != "" {
				parts = append(parts, "mask "+a.Mask)
			}
			if gateway != "" {
				parts = append(parts, "gateway "+gateway)
			}
			r := row{a.IP, strings.Join(parts, " · "), dns, iface}
			key := strings.ToLower(r.ip + "\x00" + r.maskGateway + "\x00" + r.iface)
			if seen[key] {
				continue
			}
			seen[key] = true
			rows = append(rows, r)
		}
	})
	if len(rows) == 0 {
		if ip := recursiveFirstText(value, "primary_ip", "ip", "ip_address"); ip != "" {
			rows = append(rows, row{ip, rootGateway, strings.Join(rootDNS, ", "), ""})
		}
	}
	out := make([][]string, 0, len(rows))
	for _, r := range rows {
		out = append(out, []string{r.ip, r.maskGateway, r.dns, r.iface})
	}
	return out
}

func servicesMarkdownRows(value any) [][]string {
	rows := [][]string{}
	seen := map[string]bool{}
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		name := firstMapText(record, "name", "service_name", "unit", "unit_name", "id")
		if name == "" && !genericHint(hint) {
			name = hint
		}
		if name == "" || !recordIsActive(record) || strings.EqualFold(firstMapText(record, "classification"), "system") {
			return
		}
		key := strings.ToLower(name)
		if seen[key] {
			return
		}
		seen[key] = true
		rows = append(rows, []string{name, firstMapText(record, "description", "display_name", "unit_description", "summary")})
	})
	sort.SliceStable(rows, func(i, j int) bool { return strings.ToLower(rows[i][0]) < strings.ToLower(rows[j][0]) })
	return rows
}

func portsMarkdownRows(value any) [][]string {
	type portRow struct {
		name, executable, address, port, protocol string
		score                                     int
	}
	byPort := map[string]portRow{}
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		port := firstMapText(record, "port", "local_port", "listen_port", "service_port")
		if port == "" {
			if local := firstMapText(record, "local_address", "address", "listen"); local != "" {
				port = lastPort(local)
			}
		}
		if port == "" {
			return
		}
		protocol := strings.ToUpper(firstMapText(record, "protocol", "proto", "transport"))
		address := firstMapText(record, "address", "local_address", "listen")
		processes, _ := firstMapValue(record, "processes", "process_info", "owners")
		processRows := [][]string{}
		walkRecordMaps(processes, "", func(proc map[string]any, procHint string) {
			name := firstMapText(proc, "name", "process", "process_name", "service", "program")
			if name == "" && !genericHint(procHint) {
				name = procHint
			}
			exe := firstMapText(proc, "executable", "exec", "exec_path", "binary", "path", "command")
			pid := firstMapText(proc, "pid", "process_id")
			if name == "" && exe == "" && pid == "" {
				return
			}
			if pid != "" && name != "" {
				name += " (PID " + pid + ")"
			}
			processRows = append(processRows, []string{name, exe})
		})
		if len(processRows) == 0 {
			name := firstMapText(record, "name", "process", "process_name", "service", "program")
			if name == "" && !genericHint(hint) {
				name = hint
			}
			processRows = append(processRows, []string{name, firstMapText(record, "executable", "exec", "exec_path", "binary", "path", "command")})
		}
		for _, pr := range processRows {
			c := portRow{pr[0], pr[1], firstNonEmpty(address, "*"), port, protocol, 0}
			if c.name != "" {
				c.score += 2
			}
			if c.executable != "" {
				c.score += 3
			}
			if c.address != "" && c.address != "*" {
				c.score++
			}
			key := strings.ToLower(port + "\x00" + protocol)
			if cur, ok := byPort[key]; !ok || c.score > cur.score {
				byPort[key] = c
			}
		}
	})
	vals := make([]portRow, 0, len(byPort))
	for _, r := range byPort {
		vals = append(vals, r)
	}
	sort.SliceStable(vals, func(i, j int) bool {
		pi, _ := strconv.Atoi(vals[i].port)
		pj, _ := strconv.Atoi(vals[j].port)
		if pi != pj {
			return pi < pj
		}
		return strings.ToLower(vals[i].protocol) < strings.ToLower(vals[j].protocol)
	})
	out := [][]string{}
	for _, r := range vals {
		out = append(out, []string{r.name, r.executable, r.address, r.port, r.protocol})
	}
	return out
}

func firewallMarkdown(out *strings.Builder, value any, subLevel int) {
	object := firstObject(value)
	if object == nil {
		out.WriteString("_Nu există date._\n\n")
		return
	}
	backends := strings.Join(uniqueStrings(textListFromMap(object, "backends", "backend")), ", ")
	configs := strings.Join(uniqueStrings(textListFromMap(object, "config_files", "config_file", "configs")), ", ")
	active := "Nu"
	if boolFromMap(object, "active", "enabled", "running") {
		active = "Da"
	}
	detected := "Nu"
	if boolFromMap(object, "detected", "installed") || backends != "" {
		detected = "Da"
	}
	markdownKeyValueTable(out, []PreviewRow{{Label: "Detectat", Value: detected}, {Label: "Activ", Value: active}, {Label: "Backend-uri", Value: firstNonEmpty(backends, "—")}, {Label: "Fișiere configurație", Value: firstNonEmpty(configs, "—")}})
	if raw, ok := firstMapValue(object, "default_policies", "policies"); ok {
		if policies, ok := raw.(map[string]any); ok && len(policies) > 0 {
			keys := make([]string, 0, len(policies))
			for k := range policies {
				keys = append(keys, k)
			}
			sort.Strings(keys)
			rows := [][]string{}
			for _, k := range keys {
				rows = append(rows, []string{k, compactString(policies[k])})
			}
			markdownHeading(out, subLevel, "Politici implicite")
			markdownRawTable(out, []string{"Context", "Politică"}, rows)
		}
	}
	zoneRows := [][]string{}
	if raw, ok := firstMapValue(object, "zones"); ok {
		walkRecordMaps(raw, "", func(zone map[string]any, hint string) {
			name := firstMapText(zone, "name", "zone")
			if name == "" && !genericHint(hint) {
				name = hint
			}
			if name == "" {
				return
			}
			state := "Nu"
			if boolFromMap(zone, "active", "enabled") {
				state = "Da"
			}
			zoneRows = append(zoneRows, []string{name, state, strings.Join(textListFromMap(zone, "interfaces", "interface"), ", "), strings.Join(textListFromMap(zone, "sources", "source"), ", "), strings.Join(textListFromMap(zone, "services", "service"), ", "), strings.Join(textListFromMap(zone, "ports", "port"), ", "), firstMapText(zone, "target", "policy")})
		})
	}
	if len(zoneRows) > 0 {
		markdownHeading(out, subLevel, "Zone firewalld")
		markdownRawTable(out, []string{"Zonă", "Activă", "Interfețe", "Surse", "Servicii", "Porturi", "Target"}, zoneRows)
	}
	ruleRows := [][]string{}
	for _, rule := range firewallRelevantRules(object) {
		backend := firstMapText(rule, "backend")
		text := firstMapText(rule, "rule", "raw", "expression", "line")
		if backend == "" && text == "" {
			continue
		}
		ruleRows = append(ruleRows, []string{backend, firstMapText(rule, "family"), strings.Trim(strings.Join(nonEmpty(firstMapText(rule, "table"), firstMapText(rule, "chain")), " / "), " /"), firstMapText(rule, "action", "decision", "target"), text})
	}
	if len(ruleRows) > 0 {
		if len(ruleRows) > 200 {
			ruleRows = ruleRows[:200]
		}
		markdownHeading(out, subLevel, "Reguli firewall configurate")
		markdownRawTable(out, []string{"Backend", "Familie", "Tabel / chain", "Acțiune", "Regulă"}, ruleRows)
	}
	if len(zoneRows) == 0 && len(ruleRows) == 0 {
		legacy := [][]string{}
		walkFirewall(value, "", &legacy, map[string]bool{})
		if len(legacy) > 0 {
			markdownHeading(out, subLevel, "Reguli UFW (format legacy)")
			markdownRawTable(out, []string{"Nr.", "Către", "Acțiune", "Din"}, legacy)
		}
	}
}

func accountsMarkdownRows(value any) [][]string {
	rows := [][]string{}
	seen := map[string]bool{}
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		name := firstMapText(record, "username", "user", "name", "account")
		if name == "" && !genericHint(hint) {
			name = hint
		}
		uidText := firstMapText(record, "uid", "user_id")
		uid, _ := strconv.ParseInt(strings.TrimSpace(uidText), 10, 64)
		groups := strings.Join(textListFromMap(record, "groups", "group", "memberships"), ", ")
		admin := boolFromMap(record, "admin", "is_admin", "administrator", "sudo") || containsAdminGroup(groups)
		system := uid < 1000
		if raw, ok := firstMapValue(record, "system_account", "is_system_account"); ok {
			system = boolValue(raw)
		}
		if !strings.EqualFold(name, "root") && system && !admin {
			return
		}
		if name == "" {
			return
		}
		key := strings.ToLower(name)
		if seen[key] {
			return
		}
		seen[key] = true
		rows = append(rows, []string{name, uidText, firstMapText(record, "home", "home_directory", "homedir"), firstNonEmpty(groups, firstMapText(record, "shell", "login_shell"))})
	})
	sort.SliceStable(rows, func(i, j int) bool {
		if strings.EqualFold(rows[i][0], "root") != strings.EqualFold(rows[j][0], "root") {
			return strings.EqualFold(rows[i][0], "root")
		}
		return strings.ToLower(rows[i][0]) < strings.ToLower(rows[j][0])
	})
	return rows
}
func sssdMarkdownRows(value any) [][]string {
	object := firstObject(value)
	active := "Nu"
	if object != nil && recordIsActive(object) {
		active = "Da"
	}
	return [][]string{{active, recursiveFirstText(value, "ldap_search_base", "ldapsearchbase", "search_base", "base_dn"), shortVersion(recursiveFirstText(value, "version", "sssd_version"))}}
}
func integrationsMarkdownRows(value any, sections map[string]any) [][]string {
	type spec struct {
		label   string
		aliases []string
	}
	specs := []spec{{"Auditbeat", []string{"auditbeat"}}, {"Filebeat", []string{"filebeat"}}, {"GLPI Agent", []string{"glpi", "glpi_agent", "glpiagent"}}, {"Node Exporter", []string{"node_exporter", "nodeexporter"}}, {"Syslog", []string{"syslog", "rsyslog"}}}
	rows := [][]string{}
	for _, sp := range specs {
		item := findNamedValue(value, sp.aliases...)
		if item == nil {
			item = findNamedValue(sections, sp.aliases...)
		}
		obj := firstObject(item)
		active := "Nu"
		if obj != nil && recordIsActive(obj) {
			active = "Da"
		}
		rows = append(rows, []string{sp.label, active, shortVersion(recursiveFirstText(item, "version", "agent_version")), yesNoFromValue(recursiveFirstValue(item, "config_ok", "configuration_ok", "config_valid", "configured")), strings.Join(uniqueStrings(recursiveTextList(item, "output_host", "output_hosts", "host", "hosts", "server", "servers", "destination")), ", "), strings.Join(uniqueStrings(nonEmpty(recursiveFirstText(item, "details", "detail", "message", "notes"), recursiveFirstText(item, "config_file", "configuration_file", "conf_file"), recursiveFirstText(item, "error", "last_error"))), " · ")})
	}
	return rows
}
func cronMarkdownRows(value any) [][]string {
	rows := [][]string{}
	seen := map[string]bool{}
	walkRecordMaps(value, "", func(record map[string]any, hint string) {
		schedule := firstMapText(record, "schedule", "expression", "cron", "cron_expression", "timer", "when")
		command := firstMapText(record, "command", "cmd", "exec", "executable", "script")
		user := firstMapText(record, "user", "username", "owner", "run_as")
		if command == "" && !genericHint(hint) {
			command = hint
		}
		if schedule == "" && command == "" {
			return
		}
		key := strings.ToLower(schedule + "\x00" + command + "\x00" + user)
		if seen[key] {
			return
		}
		seen[key] = true
		rows = append(rows, []string{schedule, command, user})
	})
	return rows
}
func ntpMarkdownRows(value any) [][]string {
	return [][]string{{recursiveFirstText(value, "conf_file", "config_file", "configuration_file", "config"), strings.Join(uniqueStrings(recursiveTextList(value, "source", "sources", "server", "servers", "peer", "peers")), ", "), shortVersion(recursiveFirstText(value, "version", "chrony_version", "ntp_version"))}}
}
