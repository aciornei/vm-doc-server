package documents

import (
	"fmt"
	"strconv"
	"strings"

	"vm-doc-server/internal/domain"
)

func renderVMMarkdownAnnex(out *strings.Builder, data GenerationData, level int) {
	markdownHeading(out, level, "Document")
	documentRows := []PreviewRow{{Label: "Număr electronic document", Value: data.DocumentNumber}, {Label: "Data referință", Value: formatTime(data.GeneratedAt)}}
	if data.IncludeGeneratedBy {
		documentRows = append(documentRows, PreviewRow{Label: "Generat de", Value: firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)})
	}
	markdownKeyValueTable(out, documentRows)

	markdownHeading(out, level, "Identificare și resurse")
	markdownKeyValueTable(out, identityPreviewRows(data))
	markdownHeading(out, level, "Încadrare operațională")
	markdownKeyValueTable(out, operationalPreviewRows(data))

	markdownHeading(out, level, "Servicii interne și roluri tehnice")
	if len(data.Operational.ServiceAssignments) == 0 {
		out.WriteString("_Nu există servicii interne asociate._\n\n")
	} else {
		rows := make([][]string, 0, len(data.Operational.ServiceAssignments))
		for _, item := range data.Operational.ServiceAssignments {
			usage := firstNonEmpty(item.UsageType, "—")
			if item.Primary {
				usage += "\nPrincipal"
			}
			rows = append(rows, []string{item.ArchitecturalDomain, item.ITILCategory, item.InternalServiceName, item.LayerName, item.TechnicalRole, item.SolutionType, usage})
		}
		markdownRawTable(out, []string{"Domeniu", "Categorie", "Serviciu intern", "Layer", "Rol tehnic", "Tip soluție", "Utilizare"}, rows)
	}

	markdownHeading(out, level, "Componente software principale")
	if len(data.PrimaryServices) == 0 {
		out.WriteString("_Nu au fost marcate servicii software principale._\n\n")
	} else {
		rows := make([][]string, 0, len(data.PrimaryServices))
		for _, item := range data.PrimaryServices {
			software := firstNonEmpty(item.SoftwareName, strings.TrimSuffix(item.ServiceName, ".service"), item.ServiceName)
			state := strings.TrimSpace(strings.Join(nonEmpty(item.ActiveState, item.EnabledState), " · "))
			if !item.Detected {
				state = "Nedetectat în inventarul curent"
			}
			rows = append(rows, []string{software, item.ServiceName, firstNonEmpty(shortVersion(item.Version), "—"), state})
		}
		markdownRawTable(out, []string{"Software", "Serviciu", "Versiune", "Stare"}, rows)
	}

	markdownHeading(out, level, "Porturi și procese principale")
	if len(data.PrimaryPorts) == 0 {
		out.WriteString("_Nu au fost marcate porturi sau procese principale._\n\n")
	} else {
		rows := make([][]string, 0, len(data.PrimaryPorts))
		for _, item := range data.PrimaryPorts {
			details := []string{firstNonEmpty(item.ProcessName, "—")}
			if len(item.PIDs) > 0 {
				pids := make([]string, 0, len(item.PIDs))
				for _, pid := range item.PIDs {
					pids = append(pids, strconv.Itoa(pid))
				}
				details = append(details, "PID "+strings.Join(pids, ", "))
			}
			if strings.TrimSpace(item.Executable) != "" {
				details = append(details, item.Executable)
			}
			if len(item.Addresses) > 0 {
				details = append(details, "listen "+strings.Join(item.Addresses, ", "))
			}
			if !item.Detected {
				details = append(details, "Nedetectat în inventarul curent")
			}
			rows = append(rows, []string{fmt.Sprintf("%d/%s", item.Port, strings.ToUpper(firstNonEmpty(item.Protocol, "tcp"))), strings.Join(details, "\n")})
		}
		markdownRawTable(out, []string{"Port / protocol", "Proces / detalii"}, rows)
	}

	markdownHeading(out, level, "Dependențe infrastructură comună")
	if len(data.CommonDependencies) == 0 {
		out.WriteString("_Nu sunt declarate dependențe comune sau globale._\n\n")
	} else {
		rows := make([][]string, 0, len(data.CommonDependencies))
		for _, item := range data.CommonDependencies {
			character := "Comun"
			if item.Global {
				character = "Global"
			}
			rows = append(rows, []string{item.TargetServiceName, item.DependencyType, character, firstNonEmpty(item.SourceLabel, item.SourceServiceName, "—"), item.Notes})
		}
		markdownRawTable(out, []string{"Serviciu comun", "Tip dependență", "Caracter", "Proveniență", "Detalii"}, rows)
	}
	if len(data.ExternalConnections) > 0 {
		markdownHeading(out, level+1, "Conexiuni către sisteme externe")
		rows := make([][]string, 0, len(data.ExternalConnections))
		for _, item := range data.ExternalConnections {
			endpoint := firstNonEmpty(item.ExternalHostname, item.ExternalIPAddresses)
			name := item.ExternalSystemName
			if endpoint != "" {
				name += " · " + endpoint
			}
			protocol := strings.ToUpper(strings.TrimSpace(item.Protocol))
			if item.Port != nil {
				protocol = strings.TrimSpace(protocol + "/" + strconv.Itoa(*item.Port))
			}
			security := strings.Join(nonEmpty(map[bool]string{true: "TLS", false: ""}[item.TLSEnabled], item.Authentication), " · ")
			if security == "" {
				security = "—"
			}
			rows = append(rows, []string{name, externalNetworkSummary(item), externalDirectionLabel(item.Direction), strings.Join(nonEmpty(item.RemoteService, protocol), " · "), security, firstNonEmpty(item.Purpose, item.Notes)})
		}
		markdownRawTable(out, []string{"Sistem extern", "Rețea / risc", "Sens", "Serviciu / port", "Securitate", "Scop"}, rows)
	}

	markdownHeading(out, level, "Responsabilități")
	if len(data.Operational.Responsibilities) == 0 {
		out.WriteString("_Nu există responsabilități definite._\n\n")
	} else {
		rows := make([][]string, 0, len(data.Operational.Responsibilities))
		for _, item := range data.Operational.Responsibilities {
			rows = append(rows, []string{responsibilityLabel(item.ResponsibilityType), strings.Join(nonEmpty(item.PersonName, item.PersonDepartment), "\n"), item.PersonEmail, item.PersonPhone, item.Notes})
		}
		markdownRawTable(out, []string{"Rol", "Persoană / departament", "Email", "Telefon", "Detalii"}, rows)
	}

	markdownHeading(out, level, "Backup și restaurare")
	markdownKeyValueTable(out, backupPreviewRows(data))
	markdownHeading(out, level, "Monitorizare")
	markdownKeyValueTable(out, monitoringPreviewRows(data.Monitoring))

	if hasPrimarySoftware(data.Software) {
		markdownHeading(out, level, "Software instalat principal")
		markdownKeyValueTable(out, primarySoftwarePreviewRows(data.Software))
	}
	if hasDockerDocumentData(data.Docker) {
		markdownHeading(out, level, "Docker și containere")
		dockerMarkdown(out, data.Docker)
	}
	if hasDatabaseDocumentData(data.Databases) {
		markdownHeading(out, level, "Baze de date")
		databaseMarkdown(out, data.Databases)
	}
	if hasWebDocumentData(data.Web) {
		markdownHeading(out, level, "Site-uri web și frontends")
		webMarkdown(out, data.Web)
	}

	markdownHeading(out, level, "Inventar agent")
	if data.Inventory == nil {
		out.WriteString("_Nu există inventar curent pentru această VM._\n\n")
	} else {
		markdownKeyValueTable(out, []PreviewRow{{Label: "Snapshot", Value: strconv.FormatInt(data.Inventory.ID, 10)}, {Label: "Hostname", Value: data.Inventory.Hostname}, {Label: "FQDN", Value: data.Inventory.FQDN}, {Label: "OS", Value: strings.TrimSpace(data.Inventory.OSName + " " + data.Inventory.OSVersion)}, {Label: "IP principal", Value: firstNonEmpty(data.Operational.PreferredIP, data.Inventory.PrimaryIP)}, {Label: "Primit la", Value: formatTime(data.Inventory.ReceivedAt)}, {Label: "Colectori OK", Value: fmt.Sprintf("%d din %d", data.Inventory.CollectorOK, data.Inventory.CollectorTotal)}, {Label: "Versiune agent", Value: data.Inventory.AgentVersion}})
	}
	if data.InventoryDocument != nil {
		compactInventoryMarkdown(out, data.InventoryDocument, level+1)
	}
}

func dockerMarkdown(out *strings.Builder, view domain.DockerVMView) {
	if view.Host == nil {
		out.WriteString("_Nu există inventar Docker structurat._\n\n")
		return
	}
	markdownKeyValueTable(out, []PreviewRow{{Label: "Docker Engine", Value: view.Host.Version}, {Label: "Stare serviciu", Value: view.Host.ServiceState}, {Label: "Storage driver", Value: view.Host.StorageDriver}, {Label: "Logging driver", Value: view.Host.LoggingDriver}, {Label: "Docker root", Value: view.Host.DockerRootDir}})
	rows := [][]string{}
	for _, c := range view.Containers {
		if c.DocumentationExempt {
			continue
		}
		compose := strings.Trim(strings.Join(nonEmpty(c.ComposeProject, c.ComposeService), " / "), " /")
		rows = append(rows, []string{c.Name, c.Image, firstNonEmpty(compose, "—"), firstNonEmpty(c.State, c.Status, "—"), dockerPortSummary(c.Ports), dockerAssignmentNames(c.ServiceAssignments)})
	}
	markdownRawTable(out, []string{"Container", "Imagine", "Compose", "Stare", "Porturi", "Servicii"}, rows)
}

func databaseMarkdown(out *strings.Builder, view domain.DatabaseVMView) {
	rows := [][]string{}
	for _, i := range view.Instances {
		if i.DocumentationExempt {
			continue
		}
		rows = append(rows, []string{firstNonEmpty(i.Product, i.Engine), firstNonEmpty(i.InstanceName, "implicit"), firstNonEmpty(shortVersion(i.Version), "—"), firstNonEmpty(i.Status, "—"), databaseEndpointSummary(i.Endpoints), databaseAssignmentNames(i.ServiceAssignments)})
	}
	markdownRawTable(out, []string{"Engine", "Instanță", "Versiune", "Stare", "Endpoint", "Servicii"}, rows)
	catalogRows := [][]string{}
	for _, i := range view.Instances {
		if i.DocumentationExempt {
			continue
		}
		for _, c := range i.Catalogs {
			if c.System || c.DocumentationExempt {
				continue
			}
			catalogRows = append(catalogRows, []string{firstNonEmpty(i.Product, i.Engine), firstNonEmpty(i.InstanceName, "implicit"), c.Name, firstNonEmpty(c.Kind, "database"), databaseAssignmentNames(c.ServiceAssignments)})
		}
	}
	if len(catalogRows) > 0 {
		markdownRawTable(out, []string{"Engine", "Instanță", "Bază", "Tip", "Servicii"}, catalogRows)
	}
}

func webMarkdown(out *strings.Builder, view domain.WebVMView) {
	serverRows := [][]string{}
	for _, s := range view.Servers {
		if s.DocumentationExempt {
			continue
		}
		serverRows = append(serverRows, []string{firstNonEmpty(s.Product, s.Engine), firstNonEmpty(shortVersion(s.Version), "—"), firstNonEmpty(s.Status, "—"), firstNonEmpty(s.ServiceName, "—"), firstNonEmpty(strings.Join(s.ConfigFiles, ", "), "—")})
	}
	if len(serverRows) > 0 {
		markdownRawTable(out, []string{"Produs", "Versiune", "Stare", "Serviciu OS", "Config"}, serverRows)
	}
	siteRows := [][]string{}
	for _, s := range view.Sites {
		if s.DocumentationExempt || webEngineDocumentationExempt(view, s.Engine) {
			continue
		}
		siteRows = append(siteRows, []string{firstNonEmpty(s.Name, "—"), firstNonEmpty(s.Product, s.Engine), firstNonEmpty(strings.Join(s.ServerNames, ", "), "—"), webBindingSummary(s.Bindings), webTargetSummary(s), webAssignmentNames(s.ServiceAssignments)})
	}
	if len(siteRows) > 0 {
		markdownRawTable(out, []string{"Site / frontend", "Engine", "Nume publice", "Bind", "Root / backend / proxy", "Servicii"}, siteRows)
	}
}
