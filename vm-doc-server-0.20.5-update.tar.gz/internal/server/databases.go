package server

import (
	"errors"
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/databaseinventory"
)

type databaseAssignmentsRequest struct {
	Assignments []databaseinventory.AssignmentInput `json:"assignments"`
}

func (a *App) getVMDatabaseInventory(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	view, err := a.Databases.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) replaceDatabaseInstanceServices(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	instanceID, err := strconv.ParseInt(r.PathValue("instance_id"), 10, 64)
	if err != nil || instanceID < 1 {
		badRequest(w, errors.New("invalid instance_id"))
		return
	}
	var input databaseAssignmentsRequest
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Databases.ReplaceInstanceAssignments(r.Context(), vmID, instanceID, user.ID, input.Assignments); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "database.instance.services.replace", "database_instance", strconv.FormatInt(instanceID, 10), "success", map[string]any{"vm_id": vmID, "assignments": input.Assignments})
	view, err := a.Databases.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) replaceDatabaseCatalogServices(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	catalogID, err := strconv.ParseInt(r.PathValue("catalog_id"), 10, 64)
	if err != nil || catalogID < 1 {
		badRequest(w, errors.New("invalid catalog_id"))
		return
	}
	var input databaseAssignmentsRequest
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Databases.ReplaceCatalogAssignments(r.Context(), vmID, catalogID, user.ID, input.Assignments); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "database.catalog.services.replace", "database_catalog", strconv.FormatInt(catalogID, 10), "success", map[string]any{"vm_id": vmID, "assignments": input.Assignments})
	view, err := a.Databases.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) setDatabaseInstanceDocumentationExempt(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	instanceID, err := strconv.ParseInt(r.PathValue("instance_id"), 10, 64)
	if err != nil || instanceID < 1 {
		badRequest(w, errors.New("invalid instance_id"))
		return
	}
	var input struct {
		Exempt bool `json:"exempt"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if err := a.Databases.SetDocumentationExempt(r.Context(), vmID, instanceID, input.Exempt); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "database.instance.documentation_exempt", "database_instance", strconv.FormatInt(instanceID, 10), "success", map[string]any{"vm_id": vmID, "exempt": input.Exempt})
	view, err := a.Databases.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) setDatabaseCatalogDocumentationExempt(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	catalogID, err := strconv.ParseInt(r.PathValue("catalog_id"), 10, 64)
	if err != nil || catalogID < 1 {
		badRequest(w, errors.New("invalid catalog_id"))
		return
	}
	var input struct {
		Exempt bool `json:"exempt"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if err := a.Databases.SetCatalogDocumentationExempt(r.Context(), vmID, catalogID, input.Exempt); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "database.catalog.documentation_exempt", "database_catalog", strconv.FormatInt(catalogID, 10), "success", map[string]any{"vm_id": vmID, "exempt": input.Exempt})
	view, err := a.Databases.GetVM(r.Context(), vmID)
	respond(w, view, err)
}
