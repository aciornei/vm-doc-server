package webinventory

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

type Service struct{ DB *sql.DB }

type AssignmentInput struct {
	ServiceID           int64  `json:"service_id"`
	EnvironmentID       *int64 `json:"environment_id,omitempty"`
	OperationalStatusID *int64 `json:"operational_status_id,omitempty"`
	SolutionTypeID      *int64 `json:"solution_type_id,omitempty"`
	ComponentName       string `json:"component_name,omitempty"`
	RoleName            string `json:"role_name,omitempty"`
	Notes               string `json:"notes,omitempty"`
}

type agentWebInfo struct {
	Servers []agentWebServer `json:"servers"`
	Sites   []agentWebSite   `json:"sites"`
}

type agentWebServer struct {
	Engine           string   `json:"engine"`
	Product          string   `json:"product"`
	Installed        bool     `json:"installed"`
	Version          string   `json:"version"`
	Executable       string   `json:"executable"`
	ServiceName      string   `json:"service_name"`
	Status           string   `json:"status"`
	ConfigFiles      []string `json:"config_files"`
	DetectionSources []string `json:"detection_sources"`
}

type agentWebBinding struct {
	Address  string `json:"address"`
	Port     uint16 `json:"port"`
	Protocol string `json:"protocol"`
	TLS      bool   `json:"tls"`
	Wildcard bool   `json:"wildcard"`
}

type agentWebSite struct {
	Engine           string            `json:"engine"`
	Product          string            `json:"product"`
	SiteType         string            `json:"site_type"`
	Name             string            `json:"name"`
	ServerNames      []string          `json:"server_names"`
	Bindings         []agentWebBinding `json:"bindings"`
	DocumentRoot     string            `json:"document_root"`
	ProxyTargets     []string          `json:"proxy_targets"`
	Backends         []string          `json:"backends"`
	Mode             string            `json:"mode"`
	ConfigFile       string            `json:"config_file"`
	Enabled          bool              `json:"enabled"`
	Default          bool              `json:"default"`
	DetectionSources []string          `json:"detection_sources"`
}

func (s Service) Sync(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, raw []byte) error {
	if tx == nil || vmID < 1 || inventoryID < 1 {
		return nil
	}
	var root struct {
		Web        json.RawMessage `json:"web"`
		Collection struct {
			Collectors map[string]struct {
				Status string `json:"status"`
			} `json:"collectors"`
		} `json:"collection"`
	}
	if err := json.NewDecoder(bytes.NewReader(raw)).Decode(&root); err != nil {
		return fmt.Errorf("decode web inventory envelope: %w", err)
	}
	if status, ok := root.Collection.Collectors["web"]; ok && !collectorStatusUsable(status.Status) {
		return nil
	}
	payloadRaw := bytes.TrimSpace(root.Web)
	if len(payloadRaw) == 0 || bytes.Equal(payloadRaw, []byte("null")) {
		return nil
	}
	var payload agentWebInfo
	if err := json.Unmarshal(payloadRaw, &payload); err != nil {
		return fmt.Errorf("decode web inventory: %w", err)
	}
	now := time.Now().UTC()
	if _, err := tx.ExecContext(ctx, `INSERT INTO web_hosts(vm_id,current_inventory_id,server_count,site_count,observed_at) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE current_inventory_id=VALUES(current_inventory_id),server_count=VALUES(server_count),site_count=VALUES(site_count),observed_at=VALUES(observed_at)`, vmID, inventoryID, len(payload.Servers), len(payload.Sites), now); err != nil {
		return fmt.Errorf("upsert web host: %w", err)
	}
	if _, err := tx.ExecContext(ctx, `UPDATE web_servers SET present=0 WHERE vm_id=?`, vmID); err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE web_sites SET present=0 WHERE vm_id=?`, vmID); err != nil {
		return err
	}
	for _, v := range payload.Servers {
		if err := upsertServer(ctx, tx, vmID, inventoryID, v, now); err != nil {
			return err
		}
	}
	for _, v := range payload.Sites {
		if err := upsertSite(ctx, tx, vmID, inventoryID, v, now); err != nil {
			return err
		}
	}
	return nil
}

func collectorStatusUsable(status string) bool {
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "success", "partial":
		return true
	default:
		return false
	}
}

func upsertServer(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, v agentWebServer, now time.Time) error {
	configs, _ := json.Marshal(v.ConfigFiles)
	sources, _ := json.Marshal(v.DetectionSources)
	_, err := tx.ExecContext(ctx, `INSERT INTO web_servers(vm_id,engine,product,installed,version,executable,service_name,status,config_files_json,detection_sources_json,present,current_inventory_id,last_seen_at) VALUES(?,?,?,?,?,?,?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE product=VALUES(product),installed=VALUES(installed),version=VALUES(version),executable=VALUES(executable),service_name=VALUES(service_name),status=VALUES(status),config_files_json=VALUES(config_files_json),detection_sources_json=VALUES(detection_sources_json),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`, vmID, clean(v.Engine, 64), clean(v.Product, 255), v.Installed, clean(v.Version, 512), clean(v.Executable, 2048), clean(v.ServiceName, 255), clean(v.Status, 64), configs, sources, inventoryID, now)
	return err
}

func siteIdentity(v agentWebSite) string {
	names := append([]string{}, v.ServerNames...)
	sort.Strings(names)
	binds := make([]string, 0, len(v.Bindings))
	for _, b := range v.Bindings {
		binds = append(binds, fmt.Sprintf("%s:%d:%t", strings.ToLower(b.Address), b.Port, b.TLS))
	}
	sort.Strings(binds)
	value := strings.ToLower(strings.Join([]string{v.Engine, v.SiteType, v.Name, strings.Join(names, ","), strings.Join(binds, ","), v.ConfigFile}, "|"))
	if len(value) > 768 {
		value = value[:768]
	}
	return value
}

func upsertSite(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, v agentWebSite, now time.Time) error {
	names, _ := json.Marshal(v.ServerNames)
	bindings, _ := json.Marshal(v.Bindings)
	targets, _ := json.Marshal(v.ProxyTargets)
	backends, _ := json.Marshal(v.Backends)
	sources, _ := json.Marshal(v.DetectionSources)
	_, err := tx.ExecContext(ctx, `INSERT INTO web_sites(vm_id,identity_key,engine,product,site_type,name,server_names_json,bindings_json,document_root,proxy_targets_json,backends_json,mode,config_file,enabled,is_default,detection_sources_json,present,current_inventory_id,last_seen_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE engine=VALUES(engine),product=VALUES(product),site_type=VALUES(site_type),name=VALUES(name),server_names_json=VALUES(server_names_json),bindings_json=VALUES(bindings_json),document_root=VALUES(document_root),proxy_targets_json=VALUES(proxy_targets_json),backends_json=VALUES(backends_json),mode=VALUES(mode),config_file=VALUES(config_file),enabled=VALUES(enabled),is_default=VALUES(is_default),detection_sources_json=VALUES(detection_sources_json),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`, vmID, siteIdentity(v), clean(v.Engine, 64), clean(v.Product, 255), clean(v.SiteType, 64), clean(v.Name, 512), names, bindings, clean(v.DocumentRoot, 2048), targets, backends, clean(v.Mode, 64), clean(v.ConfigFile, 2048), v.Enabled, v.Default, sources, inventoryID, now)
	return err
}

func (s Service) ensureCurrentSnapshot(ctx context.Context, vmID int64) error {
	if s.DB == nil || vmID < 1 {
		return nil
	}
	var inventoryID int64
	var raw []byte
	var normalized sql.NullInt64
	err := s.DB.QueryRowContext(ctx, `SELECT vm.current_inventory_id,i.raw_json,wh.current_inventory_id FROM virtual_machines vm JOIN inventory_snapshots i ON i.id=vm.current_inventory_id LEFT JOIN web_hosts wh ON wh.vm_id=vm.id WHERE vm.id=? AND vm.current_inventory_id IS NOT NULL`, vmID).Scan(&inventoryID, &raw, &normalized)
	if errors.Is(err, sql.ErrNoRows) {
		return nil
	}
	if err != nil {
		return err
	}
	if normalized.Valid && normalized.Int64 == inventoryID {
		return nil
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if err := s.Sync(ctx, tx, vmID, inventoryID, raw); err != nil {
		return err
	}
	return tx.Commit()
}

func (s Service) GetVM(ctx context.Context, vmID int64) (domain.WebVMView, error) {
	view := domain.WebVMView{Servers: []domain.WebServer{}, Sites: []domain.WebSite{}}
	if s.DB == nil {
		return view, nil
	}
	if err := s.ensureCurrentSnapshot(ctx, vmID); err != nil {
		return view, fmt.Errorf("synchronize current web snapshot: %w", err)
	}
	var host domain.WebHostSummary
	var inv sql.NullInt64
	var observed sql.NullTime
	err := s.DB.QueryRowContext(ctx, `SELECT vm_id,current_inventory_id,server_count,site_count,observed_at FROM web_hosts WHERE vm_id=?`, vmID).Scan(&host.VMID, &inv, &host.ServerCount, &host.SiteCount, &observed)
	if errors.Is(err, sql.ErrNoRows) {
		return view, nil
	}
	if err != nil {
		return view, err
	}
	if inv.Valid {
		x := inv.Int64
		host.CurrentInventoryID = &x
	}
	if observed.Valid {
		x := observed.Time
		host.ObservedAt = &x
	}
	view.Host = &host
	servers, err := s.loadServers(ctx, vmID)
	if err != nil {
		return view, err
	}
	view.Servers = servers
	sites, err := s.loadSites(ctx, vmID)
	if err != nil {
		return view, err
	}
	view.Sites = sites
	return view, nil
}

func (s Service) loadServers(ctx context.Context, vmID int64) ([]domain.WebServer, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,vm_id,engine,product,installed,documentation_exempt,version,executable,service_name,status,config_files_json,detection_sources_json FROM web_servers WHERE vm_id=? AND present=1 ORDER BY product,engine`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.WebServer{}
	for rows.Next() {
		var v domain.WebServer
		var configs, sources sql.NullString
		if err := rows.Scan(&v.ID, &v.VMID, &v.Engine, &v.Product, &v.Installed, &v.DocumentationExempt, &v.Version, &v.Executable, &v.ServiceName, &v.Status, &configs, &sources); err != nil {
			return nil, err
		}
		decodeJSON(configs.String, &v.ConfigFiles)
		decodeJSON(sources.String, &v.DetectionSources)
		out = append(out, v)
	}
	return out, rows.Err()
}

func (s Service) SetServerDocumentationExempt(ctx context.Context, vmID, serverID int64, exempt bool) error {
	if s.DB == nil {
		return errors.New("web inventory service is not configured")
	}
	result, err := s.DB.ExecContext(ctx, `UPDATE web_servers SET documentation_exempt=? WHERE id=? AND vm_id=?`, exempt, serverID, vmID)
	if err != nil {
		return err
	}
	n, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) SetSiteDocumentationExempt(ctx context.Context, vmID, siteID int64, exempt bool) error {
	if s.DB == nil {
		return errors.New("web inventory service is not configured")
	}
	result, err := s.DB.ExecContext(ctx, `UPDATE web_sites SET documentation_exempt=? WHERE id=? AND vm_id=?`, exempt, siteID, vmID)
	if err != nil {
		return err
	}
	n, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) loadSites(ctx context.Context, vmID int64) ([]domain.WebSite, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT ws.id,ws.vm_id,vm.name,COALESCE(vm.guest_hostname,''),ws.identity_key,ws.engine,ws.product,ws.site_type,ws.name,ws.server_names_json,ws.bindings_json,ws.document_root,ws.proxy_targets_json,ws.backends_json,ws.mode,ws.config_file,ws.enabled,ws.is_default,ws.detection_sources_json,ws.present,ws.documentation_exempt FROM web_sites ws JOIN virtual_machines vm ON vm.id=ws.vm_id WHERE ws.vm_id=? AND ws.present=1 ORDER BY ws.engine,ws.name,ws.id`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.WebSite{}
	for rows.Next() {
		var v domain.WebSite
		var names, bindings, targets, backends, sources sql.NullString
		if err := rows.Scan(&v.ID, &v.VMID, &v.VMName, &v.VMHostname, &v.IdentityKey, &v.Engine, &v.Product, &v.SiteType, &v.Name, &names, &bindings, &v.DocumentRoot, &targets, &backends, &v.Mode, &v.ConfigFile, &v.Enabled, &v.Default, &sources, &v.Present, &v.DocumentationExempt); err != nil {
			return nil, err
		}
		decodeJSON(names.String, &v.ServerNames)
		decodeJSON(bindings.String, &v.Bindings)
		decodeJSON(targets.String, &v.ProxyTargets)
		decodeJSON(backends.String, &v.Backends)
		decodeJSON(sources.String, &v.DetectionSources)
		a, err := s.siteAssignments(ctx, v.ID)
		if err != nil {
			return nil, err
		}
		v.ServiceAssignments = a
		out = append(out, v)
	}
	return out, rows.Err()
}

func (s Service) siteAssignments(ctx context.Context, siteID int64) ([]domain.WebServiceAssignment, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT a.id,a.internal_service_id,svc.name,COALESCE(svc.service_code,''),a.environment_id,COALESCE(env.name,''),a.operational_status_id,COALESCE(st.name,''),a.solution_type_id,COALESCE(sol.name,''),a.component_name,a.role_name,a.notes FROM web_site_service_assignments a JOIN internal_services svc ON svc.id=a.internal_service_id LEFT JOIN nomenclature_items env ON env.id=a.environment_id LEFT JOIN nomenclature_items st ON st.id=a.operational_status_id LEFT JOIN nomenclature_items sol ON sol.id=a.solution_type_id WHERE a.web_site_id=? ORDER BY svc.name`, siteID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.WebServiceAssignment{}
	for rows.Next() {
		var a domain.WebServiceAssignment
		var environmentID, statusID, solutionTypeID sql.NullInt64
		if err := rows.Scan(&a.ID, &a.ServiceID, &a.ServiceName, &a.ServiceCode, &environmentID, &a.Environment, &statusID, &a.OperationalStatus, &solutionTypeID, &a.SolutionType, &a.ComponentName, &a.RoleName, &a.Notes); err != nil {
			return nil, err
		}
		if environmentID.Valid {
			v := environmentID.Int64
			a.EnvironmentID = &v
		}
		if statusID.Valid {
			v := statusID.Int64
			a.OperationalStatusID = &v
		}
		if solutionTypeID.Valid {
			v := solutionTypeID.Int64
			a.SolutionTypeID = &v
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

func (s Service) ReplaceSiteAssignments(ctx context.Context, vmID, siteID, userID int64, inputs []AssignmentInput) error {
	if s.DB == nil {
		return errors.New("web inventory service is not configured")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	var exists int
	if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM web_sites WHERE id=? AND vm_id=?`, siteID, vmID).Scan(&exists); err != nil {
		return err
	}
	if exists == 0 {
		return sql.ErrNoRows
	}
	if err := validateAssignments(ctx, tx, inputs); err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM web_site_service_assignments WHERE web_site_id=?`, siteID); err != nil {
		return err
	}
	for _, in := range dedupeInputs(inputs) {
		if _, err := tx.ExecContext(ctx, `INSERT INTO web_site_service_assignments(web_site_id,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?)`, siteID, in.ServiceID, nullableInt64(in.EnvironmentID), nullableInt64(in.OperationalStatusID), nullableInt64(in.SolutionTypeID), clean(in.ComponentName, 255), clean(in.RoleName, 255), clean(in.Notes, 1000), nullableUser(userID), nullableUser(userID)); err != nil {
			return err
		}
	}
	return tx.Commit()
}

func (s Service) ListForService(ctx context.Context, serviceID int64) ([]domain.WebSite, error) {
	if s.DB == nil {
		return []domain.WebSite{}, nil
	}
	rows, err := s.DB.QueryContext(ctx, `SELECT ws.id,ws.vm_id,vm.name,COALESCE(vm.guest_hostname,''),ws.identity_key,ws.engine,ws.product,ws.site_type,ws.name,ws.server_names_json,ws.bindings_json,ws.document_root,ws.proxy_targets_json,ws.backends_json,ws.mode,ws.config_file,ws.enabled,ws.is_default,ws.detection_sources_json,ws.present FROM web_site_service_assignments a JOIN web_sites ws ON ws.id=a.web_site_id JOIN virtual_machines vm ON vm.id=ws.vm_id LEFT JOIN web_servers wsv ON wsv.vm_id=ws.vm_id AND wsv.engine=ws.engine AND wsv.present=1 WHERE a.internal_service_id=? AND ws.present=1 AND ws.documentation_exempt=0 AND COALESCE(wsv.documentation_exempt,0)=0 ORDER BY vm.name,ws.engine,ws.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.WebSite{}
	for rows.Next() {
		var v domain.WebSite
		var names, bindings, targets, backends, sources sql.NullString
		if err := rows.Scan(&v.ID, &v.VMID, &v.VMName, &v.VMHostname, &v.IdentityKey, &v.Engine, &v.Product, &v.SiteType, &v.Name, &names, &bindings, &v.DocumentRoot, &targets, &backends, &v.Mode, &v.ConfigFile, &v.Enabled, &v.Default, &sources, &v.Present, &v.DocumentationExempt); err != nil {
			return nil, err
		}
		decodeJSON(names.String, &v.ServerNames)
		decodeJSON(bindings.String, &v.Bindings)
		decodeJSON(targets.String, &v.ProxyTargets)
		decodeJSON(backends.String, &v.Backends)
		decodeJSON(sources.String, &v.DetectionSources)
		a, err := s.siteAssignments(ctx, v.ID)
		if err != nil {
			return nil, err
		}
		v.ServiceAssignments = filterAssignments(a, serviceID)
		out = append(out, v)
	}
	return out, rows.Err()
}

func filterAssignments(values []domain.WebServiceAssignment, serviceID int64) []domain.WebServiceAssignment {
	out := []domain.WebServiceAssignment{}
	for _, v := range values {
		if v.ServiceID == serviceID {
			out = append(out, v)
		}
	}
	return out
}
func validateAssignments(ctx context.Context, tx *sql.Tx, inputs []AssignmentInput) error {
	for _, in := range dedupeInputs(inputs) {
		if in.ServiceID < 1 {
			return errors.New("service_id must be positive")
		}
		var n int
		if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM internal_services WHERE id=?`, in.ServiceID).Scan(&n); err != nil {
			return err
		}
		if n == 0 {
			return fmt.Errorf("internal service %d does not exist", in.ServiceID)
		}
		if err := validateAssignmentNomenclature(ctx, tx, in.EnvironmentID, "environment"); err != nil {
			return err
		}
		if err := validateAssignmentNomenclature(ctx, tx, in.OperationalStatusID, "operational_status"); err != nil {
			return err
		}
		if err := validateAssignmentNomenclature(ctx, tx, in.SolutionTypeID, "solution_type"); err != nil {
			return err
		}
	}
	return nil
}

func validateAssignmentNomenclature(ctx context.Context, tx *sql.Tx, id *int64, category string) error {
	if id == nil || *id < 1 {
		return nil
	}
	var n int
	if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM nomenclature_items WHERE id=? AND category_code=?`, *id, category).Scan(&n); err != nil {
		return err
	}
	if n == 0 {
		return fmt.Errorf("nomenclature item %d is not in %s", *id, category)
	}
	return nil
}

func nullableInt64(value *int64) any {
	if value != nil && *value > 0 {
		return *value
	}
	return nil
}
func dedupeInputs(inputs []AssignmentInput) []AssignmentInput {
	seen := map[int64]struct{}{}
	out := []AssignmentInput{}
	for _, in := range inputs {
		if in.ServiceID < 1 {
			continue
		}
		if _, ok := seen[in.ServiceID]; ok {
			continue
		}
		seen[in.ServiceID] = struct{}{}
		out = append(out, in)
	}
	return out
}
func nullableUser(id int64) any {
	if id > 0 {
		return id
	}
	return nil
}
func clean(v string, max int) string {
	v = strings.TrimSpace(v)
	if len(v) > max {
		return v[:max]
	}
	return v
}
func decodeJSON(raw string, target any) {
	if strings.TrimSpace(raw) != "" {
		_ = json.Unmarshal([]byte(raw), target)
	}
}
