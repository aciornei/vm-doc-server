-- 0.20.5: excludere din documentație la nivelul resursei efective.
ALTER TABLE docker_containers
  ADD COLUMN documentation_exempt TINYINT(1) NOT NULL DEFAULT 0 AFTER present;

ALTER TABLE database_catalogs
  ADD COLUMN documentation_exempt TINYINT(1) NOT NULL DEFAULT 0 AFTER present;

ALTER TABLE web_sites
  ADD COLUMN documentation_exempt TINYINT(1) NOT NULL DEFAULT 0 AFTER present;
