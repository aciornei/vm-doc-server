# Upgrade VM-DOC Server 0.21.27 → 0.21.28

UI: Baze de date pe model Docker. **Fără migrare SQL nouă**. Agent 1.7.18 este neschimbat.

1. Faceți copie a surselor 0.21.27, inclusiv `vendor/` offline. Nu extrageți noul update peste fișierele binare care rulează.
2. Extrageți `vm-doc-server-0.21.28-update.tar.gz` în copia surselor (arhiva conține căi relative la rădăcina proiectului).
3. Rulați `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și `GOPROXY=off GOFLAGS=-mod=vendor make build`.
4. După succes, înlocuiți binarul în procedura de deployment existentă, reporniți serviciul și dați Ctrl+F5.
5. În VM → Baze de date verificați panoul Filtre și că rămân selectate după revenirea în tab; testați ambele tabele. Pe o VM fără joburi PostgreSQL, panoul, cardul KPI și coloana Joburi DB trebuie să lipsească; pe o VM cu joburi trebuie să fie prezente.
6. Pentru rollback, reinstalați binarul anterior 0.21.27. Nu există schema DB de modificat sau migrări noi de revenit.

**Testare locală:** Chromium pe date simulate și pachetele Go disponibile au trecut. Compilarea completă cu dependențele din `vendor/` și integrarea în staging/PROD nu au fost confirmate aici.
