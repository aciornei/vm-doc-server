package server

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/auth"
)

type securityReview struct {
	ResourceType   string     `json:"resource_type"`
	ResourceKey    string     `json:"resource_key"`
	IntervalMonths int        `json:"interval_months"`
	Justified      bool       `json:"justified"`
	Notes          string     `json:"notes,omitempty"`
	ReviewedAt     *time.Time `json:"reviewed_at,omitempty"`
	NextReviewAt   *time.Time `json:"next_review_at,omitempty"`
	ReviewedBy     string     `json:"reviewed_by,omitempty"`
	Due            bool       `json:"due"`
}

type securityAccount struct {
	VMID              int64          `json:"vm_id"`
	VMName            string         `json:"vm_name"`
	Username          string         `json:"username"`
	UID               uint64         `json:"uid"`
	GID               uint64         `json:"gid"`
	Shell             string         `json:"shell,omitempty"`
	Groups            []string       `json:"groups,omitempty"`
	LoginCapable      bool           `json:"login_capable"`
	Privileged        bool           `json:"privileged"`
	SystemAccount     bool           `json:"system_account"`
	PasswordStatus    string         `json:"password_status"`
	PasswordLocked    bool           `json:"password_locked"`
	PasswordLastSet   *time.Time     `json:"password_last_set,omitempty"`
	PasswordExpiresAt *time.Time     `json:"password_expires_at,omitempty"`
	AccountExpiresAt  *time.Time     `json:"account_expires_at,omitempty"`
	Review            securityReview `json:"review"`
}

type securityDBPrincipal struct {
	Name        string   `json:"name"`
	Host        string   `json:"host,omitempty"`
	Login       bool     `json:"login"`
	Superuser   bool     `json:"superuser,omitempty"`
	CreateDB    bool     `json:"create_db,omitempty"`
	CreateRole  bool     `json:"create_role,omitempty"`
	Replication bool     `json:"replication,omitempty"`
	Roles       []string `json:"roles,omitempty"`
}

type securityHBARule struct {
	Type        string   `json:"type"`
	Databases   []string `json:"databases,omitempty"`
	Users       []string `json:"users,omitempty"`
	Address     string   `json:"address,omitempty"`
	Method      string   `json:"method,omitempty"`
	Options     []string `json:"options,omitempty"`
	SourceFile  string   `json:"source_file,omitempty"`
	Line        int      `json:"line,omitempty"`
	Warning     bool     `json:"warning"`
	WarningText string   `json:"warning_text,omitempty"`
}

type securityDatabase struct {
	ID           int64                 `json:"id"`
	VMID         int64                 `json:"vm_id"`
	VMName       string                `json:"vm_name"`
	Engine       string                `json:"engine"`
	Product      string                `json:"product"`
	InstanceName string                `json:"instance_name"`
	Version      string                `json:"version,omitempty"`
	Status       string                `json:"status,omitempty"`
	Reason       string                `json:"reason,omitempty"`
	Principals   []securityDBPrincipal `json:"principals"`
	HBARules     []securityHBARule     `json:"hba_rules"`
	Review       securityReview        `json:"review"`
}

type securityWebRule struct {
	Action     string `json:"action"`
	Source     string `json:"source"`
	Scope      string `json:"scope,omitempty"`
	Directive  string `json:"directive,omitempty"`
	SourceFile string `json:"source_file,omitempty"`
	Warning    bool   `json:"warning"`
}

type securityWebSite struct {
	ID          int64             `json:"id"`
	VMID        int64             `json:"vm_id"`
	VMName      string            `json:"vm_name"`
	Engine      string            `json:"engine"`
	Name        string            `json:"name"`
	ServerNames []string          `json:"server_names,omitempty"`
	ConfigFile  string            `json:"config_file,omitempty"`
	Rules       []securityWebRule `json:"rules"`
	Review      securityReview    `json:"review"`
}

type securitySummary struct {
	Accounts             int `json:"accounts"`
	AccountsRelevant     int `json:"accounts_relevant"`
	AccountsSystem       int `json:"accounts_system"`
	AccountsSystemHidden int `json:"accounts_system_hidden"`
	AccountsPrivileged   int `json:"accounts_privileged"`
	AccountsPasswordSet  int `json:"accounts_password_set"`
	AccountsDue          int `json:"accounts_due"`
	AccountsDueAll       int `json:"accounts_due_all"`
	DatabaseInstances    int `json:"database_instances"`
	DatabasePrincipals   int `json:"database_principals"`
	DatabasePrivileged   int `json:"database_privileged"`
	HBAWarnings          int `json:"hba_warnings"`
	DatabaseDue          int `json:"database_due"`
	WebSites             int `json:"web_sites"`
	WebRules             int `json:"web_rules"`
	WebAllowAll          int `json:"web_allow_all"`
	WebDue               int `json:"web_due"`
	TotalDue             int `json:"total_due"`
}

type securityResponse struct {
	GeneratedAt time.Time          `json:"generated_at"`
	Summary     securitySummary    `json:"summary"`
	Accounts    []securityAccount  `json:"accounts"`
	Databases   []securityDatabase `json:"databases"`
	WebSites    []securityWebSite  `json:"web_sites"`
}

func securityReviewMapKey(vmID int64, typ, key string) string {
	return fmt.Sprintf("%d|%s|%s", vmID, strings.ToLower(strings.TrimSpace(typ)), strings.TrimSpace(key))
}

func (a *App) loadSecurityReviews(ctx context.Context) (map[string]securityReview, error) {
	out := map[string]securityReview{}
	rows, err := a.DB.QueryContext(ctx, `SELECT r.vm_id,r.resource_type,r.resource_key,r.interval_months,r.justified,r.notes,r.reviewed_at,r.next_review_at,COALESCE(u.display_name,u.username,'') FROM security_reviews r LEFT JOIN users u ON u.id=r.reviewed_by`)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	now := time.Now().UTC()
	for rows.Next() {
		var vmID int64
		var v securityReview
		var reviewedAt, nextAt time.Time
		if err := rows.Scan(&vmID, &v.ResourceType, &v.ResourceKey, &v.IntervalMonths, &v.Justified, &v.Notes, &reviewedAt, &nextAt, &v.ReviewedBy); err != nil {
			return nil, err
		}
		v.ReviewedAt = &reviewedAt
		v.NextReviewAt = &nextAt
		v.Due = !nextAt.After(now)
		out[securityReviewMapKey(vmID, v.ResourceType, v.ResourceKey)] = v
	}
	return out, rows.Err()
}

func defaultSecurityReview(vmID int64, typ, key string, interval int) securityReview {
	return securityReview{ResourceType: typ, ResourceKey: key, IntervalMonths: interval, Due: true}
}

func reviewFor(m map[string]securityReview, vmID int64, typ, key string, interval int) securityReview {
	if v, ok := m[securityReviewMapKey(vmID, typ, key)]; ok {
		return v
	}
	return defaultSecurityReview(vmID, typ, key, interval)
}

func (a *App) securityOverview(w http.ResponseWriter, r *http.Request) {
	var vmID int64
	if raw := strings.TrimSpace(r.URL.Query().Get("vm_id")); raw != "" {
		parsed, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || parsed < 1 {
			badRequest(w, errors.New("vm_id invalid"))
			return
		}
		vmID = parsed
	}
	reviews, err := a.loadSecurityReviews(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	result := securityResponse{GeneratedAt: time.Now().UTC(), Accounts: []securityAccount{}, Databases: []securityDatabase{}, WebSites: []securityWebSite{}}
	if err := a.loadSecurityAccounts(r.Context(), reviews, &result, vmID); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.loadSecurityDatabases(r.Context(), reviews, &result, vmID); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.loadSecurityWeb(r.Context(), reviews, &result, vmID); err != nil {
		respond(w, nil, err)
		return
	}
	result.Summary.TotalDue = result.Summary.AccountsDue + result.Summary.DatabaseDue + result.Summary.WebDue
	respond(w, result, nil)
}

func securityAccountPasswordRelevant(row securityAccount) bool {
	if row.PasswordLocked {
		return false
	}
	status := strings.ToLower(strings.TrimSpace(row.PasswordStatus))
	return status == "password_set" || status == "password_set_or_external" || status == "empty"
}

// securityAccountRelevant suppresses low-value daemon/system accounts by default,
// while keeping root and any system account that can log in, is privileged or has
// a password state that deserves review. The complete inventory remains available
// through the UI filter.
func securityAccountRelevant(row securityAccount) bool {
	if strings.EqualFold(strings.TrimSpace(row.Username), "root") {
		return true
	}
	if !row.SystemAccount {
		return true
	}
	return row.LoginCapable || row.Privileged || securityAccountPasswordRelevant(row)
}

func (a *App) loadSecurityAccounts(ctx context.Context, reviews map[string]securityReview, result *securityResponse, onlyVMID int64) error {
	query := `SELECT vm.id,vm.name,COALESCE(i.raw_json,'') FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0`
	args := []any{}
	if onlyVMID > 0 {
		query += ` AND vm.id=?`
		args = append(args, onlyVMID)
	}
	query += ` ORDER BY vm.name,vm.id`
	rows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var vmID int64
		var vmName string
		var raw []byte
		if err := rows.Scan(&vmID, &vmName, &raw); err != nil {
			return err
		}
		var envelope struct {
			Accounts struct {
				LocalUsers []struct {
					Username          string     `json:"username"`
					UID               uint64     `json:"uid"`
					GID               uint64     `json:"gid"`
					Shell             string     `json:"shell"`
					Groups            []string   `json:"groups"`
					LoginCapable      bool       `json:"login_capable"`
					Privileged        bool       `json:"privileged"`
					SystemAccount     bool       `json:"system_account"`
					PasswordStatus    string     `json:"password_status"`
					PasswordLocked    bool       `json:"password_locked"`
					PasswordLastSet   *time.Time `json:"password_last_set"`
					PasswordExpiresAt *time.Time `json:"password_expires_at"`
					AccountExpiresAt  *time.Time `json:"account_expires_at"`
				} `json:"local_users"`
			} `json:"accounts"`
		}
		if len(raw) == 0 || json.Unmarshal(raw, &envelope) != nil {
			continue
		}
		for _, u := range envelope.Accounts.LocalUsers {
			privileged := u.Privileged || u.UID == 0
			for _, group := range u.Groups {
				if strings.EqualFold(group, "sudo") || strings.EqualFold(group, "wheel") || strings.EqualFold(group, "admin") || strings.EqualFold(group, "root") {
					privileged = true
				}
			}
			loginCapable := u.LoginCapable
			if !loginCapable {
				shell := strings.ToLower(strings.TrimSpace(u.Shell))
				loginCapable = shell != "" && !strings.Contains(shell, "nologin") && !strings.HasSuffix(shell, "/false") && shell != "false"
			}
			interval := 12
			if privileged {
				interval = 6
			}
			row := securityAccount{VMID: vmID, VMName: vmName, Username: u.Username, UID: u.UID, GID: u.GID, Shell: u.Shell, Groups: u.Groups, LoginCapable: loginCapable, Privileged: privileged, SystemAccount: u.SystemAccount, PasswordStatus: u.PasswordStatus, PasswordLocked: u.PasswordLocked, PasswordLastSet: u.PasswordLastSet, PasswordExpiresAt: u.PasswordExpiresAt, AccountExpiresAt: u.AccountExpiresAt, Review: reviewFor(reviews, vmID, "vm_account", u.Username, interval)}
			result.Accounts = append(result.Accounts, row)
			result.Summary.Accounts++
			if row.SystemAccount && !strings.EqualFold(strings.TrimSpace(row.Username), "root") {
				result.Summary.AccountsSystem++
			}
			if securityAccountRelevant(row) {
				result.Summary.AccountsRelevant++
			} else {
				result.Summary.AccountsSystemHidden++
			}
			if row.Privileged {
				result.Summary.AccountsPrivileged++
			}
			if row.PasswordStatus == "password_set" || row.PasswordStatus == "password_set_or_external" {
				result.Summary.AccountsPasswordSet++
			}
			if row.Review.Due {
				result.Summary.AccountsDueAll++
				if securityAccountRelevant(row) {
					result.Summary.AccountsDue++
				}
			}
		}
	}
	return rows.Err()
}

func hbaWarning(rule securityHBARule) (bool, string) {
	reasons := []string{}
	addr := strings.ToLower(strings.TrimSpace(rule.Address))
	method := strings.ToLower(strings.TrimSpace(rule.Method))
	if addr == "0.0.0.0/0" || addr == "::/0" || addr == "all" {
		reasons = append(reasons, "sursă foarte largă")
	}
	if method == "trust" {
		reasons = append(reasons, "trust")
	}
	if method == "md5" {
		reasons = append(reasons, "md5")
	}
	if containsSecurityFold(rule.Databases, "all") && containsSecurityFold(rule.Users, "all") {
		reasons = append(reasons, "all/all")
	}
	return len(reasons) > 0, strings.Join(reasons, ", ")
}
func containsSecurityFold(v []string, target string) bool {
	for _, x := range v {
		if strings.EqualFold(strings.TrimSpace(x), target) {
			return true
		}
	}
	return false
}

func (a *App) loadSecurityDatabases(ctx context.Context, reviews map[string]securityReview, result *securityResponse, onlyVMID int64) error {
	query := `SELECT di.id,di.vm_id,vm.name,di.engine,di.product,di.instance_name,di.version,COALESCE(di.access_json,'{}') FROM database_instances di JOIN virtual_machines vm ON vm.id=di.vm_id WHERE di.present=1 AND vm.retired=0`
	args := []any{}
	if onlyVMID > 0 {
		query += ` AND di.vm_id=?`
		args = append(args, onlyVMID)
	}
	query += ` ORDER BY vm.name,di.engine,di.instance_name,di.id`
	rows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var row securityDatabase
		var raw []byte
		if err := rows.Scan(&row.ID, &row.VMID, &row.VMName, &row.Engine, &row.Product, &row.InstanceName, &row.Version, &raw); err != nil {
			return err
		}
		var access struct {
			Principals []securityDBPrincipal `json:"principals"`
			HBARules   []securityHBARule     `json:"hba_rules"`
			Status     string                `json:"status"`
			Reason     string                `json:"reason"`
		}
		_ = json.Unmarshal(raw, &access)
		row.Principals = access.Principals
		row.HBARules = access.HBARules
		row.Status = access.Status
		row.Reason = access.Reason
		for i := range row.HBARules {
			row.HBARules[i].Warning, row.HBARules[i].WarningText = hbaWarning(row.HBARules[i])
			if row.HBARules[i].Warning {
				result.Summary.HBAWarnings++
			}
		}
		row.Review = reviewFor(reviews, row.VMID, "database", strconv.FormatInt(row.ID, 10), 6)
		result.Summary.DatabaseInstances++
		result.Summary.DatabasePrincipals += len(row.Principals)
		if row.Review.Due {
			result.Summary.DatabaseDue++
		}
		for _, p := range row.Principals {
			if p.Superuser || p.CreateRole {
				result.Summary.DatabasePrivileged++
			}
		}
		result.Databases = append(result.Databases, row)
	}
	return rows.Err()
}

func webAllowAll(rule securityWebRule) bool {
	if !strings.EqualFold(strings.TrimSpace(rule.Action), "allow") {
		return false
	}
	s := strings.ToLower(strings.TrimSpace(rule.Source))
	return s == "all" || s == "0.0.0.0/0" || s == "::/0"
}

func (a *App) loadSecurityWeb(ctx context.Context, reviews map[string]securityReview, result *securityResponse, onlyVMID int64) error {
	query := `SELECT ws.id,ws.vm_id,vm.name,ws.engine,ws.name,ws.server_names_json,ws.config_file,COALESCE(ws.access_control_json,'[]') FROM web_sites ws JOIN virtual_machines vm ON vm.id=ws.vm_id WHERE ws.present=1 AND vm.retired=0`
	args := []any{}
	if onlyVMID > 0 {
		query += ` AND ws.vm_id=?`
		args = append(args, onlyVMID)
	}
	query += ` ORDER BY vm.name,ws.engine,ws.name,ws.id`
	rows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var row securityWebSite
		var namesRaw, accessRaw []byte
		if err := rows.Scan(&row.ID, &row.VMID, &row.VMName, &row.Engine, &row.Name, &namesRaw, &row.ConfigFile, &accessRaw); err != nil {
			return err
		}
		_ = json.Unmarshal(namesRaw, &row.ServerNames)
		_ = json.Unmarshal(accessRaw, &row.Rules)
		for i := range row.Rules {
			row.Rules[i].Warning = webAllowAll(row.Rules[i])
			if row.Rules[i].Warning {
				result.Summary.WebAllowAll++
			}
		}
		row.Review = reviewFor(reviews, row.VMID, "web", strconv.FormatInt(row.ID, 10), 12)
		result.Summary.WebSites++
		result.Summary.WebRules += len(row.Rules)
		if row.Review.Due {
			result.Summary.WebDue++
		}
		result.WebSites = append(result.WebSites, row)
	}
	return rows.Err()
}

type securityReviewInput struct {
	VMID           int64  `json:"vm_id"`
	ResourceType   string `json:"resource_type"`
	ResourceKey    string `json:"resource_key"`
	IntervalMonths int    `json:"interval_months"`
	Justified      bool   `json:"justified"`
	Notes          string `json:"notes"`
}

func (a *App) updateSecurityReview(w http.ResponseWriter, r *http.Request) {
	var in securityReviewInput
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	in.ResourceType = strings.ToLower(strings.TrimSpace(in.ResourceType))
	in.ResourceKey = strings.TrimSpace(in.ResourceKey)
	in.Notes = strings.TrimSpace(in.Notes)
	if in.VMID < 1 || in.ResourceKey == "" {
		badRequest(w, errors.New("vm_id și resource_key sunt obligatorii"))
		return
	}
	if in.ResourceType != "vm_account" && in.ResourceType != "database" && in.ResourceType != "web" {
		badRequest(w, errors.New("resource_type invalid"))
		return
	}
	if in.IntervalMonths != 6 && in.IntervalMonths != 12 {
		badRequest(w, errors.New("interval_months trebuie să fie 6 sau 12"))
		return
	}
	if len(in.Notes) > 2000 {
		in.Notes = in.Notes[:2000]
	}
	u, _ := auth.UserFromContext(r.Context())
	now := time.Now().UTC()
	next := now.AddDate(0, in.IntervalMonths, 0)
	_, err := a.DB.ExecContext(r.Context(), `INSERT INTO security_reviews(vm_id,resource_type,resource_key,interval_months,justified,notes,reviewed_at,next_review_at,reviewed_by) VALUES(?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE interval_months=VALUES(interval_months),justified=VALUES(justified),notes=VALUES(notes),reviewed_at=VALUES(reviewed_at),next_review_at=VALUES(next_review_at),reviewed_by=VALUES(reviewed_by)`, in.VMID, in.ResourceType, in.ResourceKey, in.IntervalMonths, in.Justified, in.Notes, now, next, u.ID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "security.access.review", "security_review", fmt.Sprintf("%d:%s:%s", in.VMID, in.ResourceType, in.ResourceKey), "success", map[string]any{"vm_id": in.VMID, "resource_type": in.ResourceType, "resource_key": in.ResourceKey, "interval_months": in.IntervalMonths, "justified": in.Justified})
	reviews, err := a.loadSecurityReviews(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	v := reviewFor(reviews, in.VMID, in.ResourceType, in.ResourceKey, in.IntervalMonths)
	respond(w, v, nil)
}
