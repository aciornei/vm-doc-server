package server

import "testing"

func TestSecurityAccountRelevant(t *testing.T) {
	cases := []struct {
		name string
		row  securityAccount
		want bool
	}{
		{name: "root always visible", row: securityAccount{Username: "root", SystemAccount: true, PasswordLocked: true}, want: true},
		{name: "normal user", row: securityAccount{Username: "andrei", UID: 1000}, want: true},
		{name: "quiet daemon hidden", row: securityAccount{Username: "www-data", UID: 33, SystemAccount: true, Shell: "/usr/sbin/nologin", PasswordLocked: true, PasswordStatus: "locked"}, want: false},
		{name: "service account with shell visible", row: securityAccount{Username: "postgres", UID: 111, SystemAccount: true, Shell: "/bin/bash", LoginCapable: true, PasswordLocked: true}, want: true},
		{name: "system account with active password visible", row: securityAccount{Username: "backup", UID: 110, SystemAccount: true, Shell: "/usr/sbin/nologin", PasswordStatus: "password_set"}, want: true},
		{name: "system account with empty password visible", row: securityAccount{Username: "legacy", UID: 90, SystemAccount: true, Shell: "/bin/false", PasswordStatus: "empty"}, want: true},
		{name: "privileged system account visible", row: securityAccount{Username: "ops", UID: 99, SystemAccount: true, Privileged: true, PasswordLocked: true}, want: true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := securityAccountRelevant(tc.row); got != tc.want {
				t.Fatalf("securityAccountRelevant(%+v)=%v want %v", tc.row, got, tc.want)
			}
		})
	}
}

func TestSecurityWarnings(t *testing.T) {
	if ok, _ := hbaWarning(securityHBARule{Type: "host", Databases: []string{"all"}, Users: []string{"all"}, Address: "0.0.0.0/0", Method: "trust"}); !ok {
		t.Fatal("expected broad trust HBA rule to be a warning")
	}
	if !webAllowAll(securityWebRule{Action: "allow", Source: "0.0.0.0/0"}) {
		t.Fatal("expected allow 0.0.0.0/0 to be detected")
	}
	if webAllowAll(securityWebRule{Action: "deny", Source: "all"}) {
		t.Fatal("deny all must not be classified as allow all")
	}
}
