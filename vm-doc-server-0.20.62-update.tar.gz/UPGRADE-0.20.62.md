# Upgrade VM-DOC Server 0.20.61 → 0.20.62

Versiunea 0.20.62 este un upgrade de server/UI. Nu adaugă migrare DB și nu necesită upgrade peste vm-doc-agent 1.7.11.

## Modificări

- filtre și paginare în cele trei inventare Security;
- conturile system cu risc redus sunt ascunse implicit, dar pot fi afișate din filtrul Tip cont;
- zonă Securitate în fișa fiecărui VM;
- `GET /api/v1/security?vm_id=<id>` pentru vederea per-VM.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.61 /usr/local/src/vm-doc-server-0.20.62
tar -xzf vm-doc-server-0.20.62-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.62
cd /usr/local/src/vm-doc-server-0.20.62
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server`, apoi fă `Ctrl+F5` în browser.
