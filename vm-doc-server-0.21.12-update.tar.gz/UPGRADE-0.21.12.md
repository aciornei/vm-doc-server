# VM-DOC Server 0.21.11 → 0.21.12

Hotfix strict pentru eroarea Go `no new variables on left side of :=` din `internal/server/hardening.go`.
Nu există migrare SQL nouă, actualizare de agent sau modificări API/Swagger.

## Upgrade offline

Păstrează sursele 0.21.11 și directorul `vendor/` de pe serverul de compilare. **Aplică numai una** dintre metodele update sau patch.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.11 vm-doc-server-0.21.12
cd vm-doc-server-0.21.12
# Metoda 1: arhivă update
tar -xzf /cale/vm-doc-server-0.21.12-update.tar.gz -C .
# Metoda 2 (alternativă):
# patch -p1 --dry-run < /cale/vm-doc-server-0.21.11-to-0.21.12.patch
# patch -p1 < /cale/vm-doc-server-0.21.11-to-0.21.12.patch

# Este important să nu existe alte surse versionate imbricate în acest director.
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./internal/... ./cmd/...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Dacă ambele comenzi trec, continuă instalarea prin procedura standard. Verifică apoi `/version` = `0.21.12` și pagina Hardening.

## Verificare expresie corectată

```bash
grep -n 'UPDATE hardening_profiles' internal/server/hardening.go
```

Trebuie să înceapă cu `_, err = a.DB.ExecContext(...)`, NU `_, err :=`.

## Rollback

Dacă testul/buildul eșuează, **nu înlocui binarul instalat**. Nu executa migrarea down 075; migrarea hardening existentă rămâne neschimbată.

**Limitare:** versiunea a fost împachetată și verificată structural, dar compilarea integrală nu a fost posibilă în mediul de generare fără directorul `vendor/`.
