# Upgrade VM-DOC Server 0.20.94 → 0.20.95

Hotfix Security pentru familiile Linux.

1. Oprește `vm-doc-server`.
2. Aplică update-ul peste 0.20.94.
3. Recompilează/repornește serverul conform procedurii curente.
4. Fă `Ctrl+F5` în browser.
5. Pentru SLES9, rulează o colectare nouă sau reîncarcă pagina dacă snapshot-ul curent conține deja `accounts.password_policy`.

Nu există migrare DB și nu este necesar un agent nou peste SLES9 legacy 1.0.1.
