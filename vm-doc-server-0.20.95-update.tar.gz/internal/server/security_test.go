package server

import "testing"

func TestSecurityAccountRelevant(t *testing.T) {
	cases := []struct {
		name string
		row  securityAccount
		want bool
	}{
		{name: "root always visible", row: securityAccount{Username: "root", SystemAccount: true, PasswordLocked: true}, want: true},
		{name: "normal user", row: securityAccount{Username: "andrei", UID: 1000}, want: true},
		{name: "quiet daemon hidden", row: securityAccount{Username: "www-data", UID: 33, SystemAccount: true, Shell: "/usr/sbin/nologin", PasswordLocked: true, PasswordStatus: "locked"}, want: false},
		{name: "service account with shell visible", row: securityAccount{Username: "postgres", UID: 111, SystemAccount: true, Shell: "/bin/bash", LoginCapable: true, PasswordLocked: true}, want: true},
		{name: "system account with active password visible", row: securityAccount{Username: "backup", UID: 110, SystemAccount: true, Shell: "/usr/sbin/nologin", PasswordStatus: "password_set"}, want: true},
		{name: "system account with empty password visible", row: securityAccount{Username: "legacy", UID: 90, SystemAccount: true, Shell: "/bin/false", PasswordStatus: "empty"}, want: true},
		{name: "privileged system account visible", row: securityAccount{Username: "ops", UID: 99, SystemAccount: true, Privileged: true, PasswordLocked: true}, want: true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := securityAccountRelevant(tc.row); got != tc.want {
				t.Fatalf("securityAccountRelevant(%+v)=%v want %v", tc.row, got, tc.want)
			}
		})
	}
}

func TestSecurityWarnings(t *testing.T) {
	if ok, _ := hbaWarning(securityHBARule{Type: "host", Databases: []string{"all"}, Users: []string{"all"}, Address: "0.0.0.0/0", Method: "trust"}); !ok {
		t.Fatal("expected broad trust HBA rule to be a warning")
	}
	if !webAllowAll(securityWebRule{Action: "allow", Source: "0.0.0.0/0"}) {
		t.Fatal("expected allow 0.0.0.0/0 to be detected")
	}
	if webAllowAll(securityWebRule{Action: "deny", Source: "all"}) {
		t.Fatal("deny all must not be classified as allow all")
	}
}

func TestSecurityInteractiveShell(t *testing.T) {
	cases := map[string]bool{
		"/bin/bash":         true,
		"/bin/sh":           true,
		"/usr/bin/zsh":      true,
		"/usr/sbin/nologin": false,
		"/sbin/nologin":     false,
		"/bin/false":        false,
		"/bin/sync":         false,
		"/sbin/shutdown":    false,
		"/sbin/halt":        false,
		"":                  false,
	}
	for shell, want := range cases {
		if got := securityInteractiveShell(shell); got != want {
			t.Fatalf("securityInteractiveShell(%q)=%v want %v", shell, got, want)
		}
	}
}

func TestSecurityLinuxLikeFamilies(t *testing.T) {
	for _, family := range []string{"linux", "debian", "redhat", "suse", "sles", "ubuntu", "rhel", "centos", "rocky", "almalinux", "oraclelinux", "opensuse", "GNU/Linux", "unix"} {
		if !securityLinuxLike(family) {
			t.Fatalf("securityLinuxLike(%q)=false; expected Linux-like family", family)
		}
	}
	for _, family := range []string{"windows", "darwin", ""} {
		if securityLinuxLike(family) {
			t.Fatalf("securityLinuxLike(%q)=true; expected non-Linux family", family)
		}
	}
}

func TestSecuritySystemAccountLinuxUIDThreshold(t *testing.T) {
	if !securitySystemAccount("linux", "sync", 4, false) {
		t.Fatal("Linux UID < 1000 must be treated as system account even if old inventory did not mark it")
	}
	if securitySystemAccount("linux", "app", 1000, false) {
		t.Fatal("Linux UID 1000 must not be forced to system account")
	}
	if securitySystemAccount("windows", "LocalAdmin", 0, false) {
		t.Fatal("Windows accounts must not use the Linux UID threshold")
	}
	if !securitySystemAccount("linux", "root", 0, false) {
		t.Fatal("root must always be recognized as system/root account")
	}
}

func TestSecurityPasswordPolicyPresent(t *testing.T) {
	if securityPasswordPolicyPresent(securityPasswordPolicy{}) {
		t.Fatal("empty policy must not be exposed")
	}
	if !securityPasswordPolicyPresent(securityPasswordPolicy{EnforcementStatus: "partial"}) {
		t.Fatal("policy with enforcement status must be exposed")
	}
	if !securityPasswordPolicyPresent(securityPasswordPolicy{Checks: []securityPasswordPolicyCheck{{Code: "complexity", Status: "enforced"}}}) {
		t.Fatal("policy with checks must be exposed")
	}
}

func int64p(v int64) *int64 { return &v }

func TestDeriveLegacyLinuxPasswordPolicySLES9(t *testing.T) {
	raw := legacySecurityPasswordPolicy{
		Sources: []string{"/etc/login.defs", "/etc/pam.d/common-password-pc"},
		LoginDefs: map[string]string{
			"PASS_MIN_LEN": "8", "PASS_MIN_DAYS": "1", "PASS_MAX_DAYS": "90", "PASS_WARN_AGE": "7",
		},
		PAMModules: []legacySecurityPAMModule{{
			File: "/etc/pam.d/common-password-pc", Module: "pam_pwcheck.so", Options: map[string]string{"minlen": "8", "remember": "5"},
		}},
		ComplexityConfigured: true,
	}
	users := []legacySecurityPolicyUser{{
		Username: "operator", UID: 1000, Shell: "/bin/bash", PasswordStatus: "password_set",
		MinPasswordAgeDays: int64p(1), MaxPasswordAgeDays: int64p(90), WarningDays: int64p(7),
	}}
	got := deriveLegacyLinuxPasswordPolicy(raw, users)
	if got.EnforcementStatus != "enforced" {
		t.Fatalf("status=%q checks=%#v", got.EnforcementStatus, got.Checks)
	}
	wanted := map[string]bool{"complexity": false, "minimum_length": false, "min_age": false, "max_age": false, "warning_age": false}
	for _, check := range got.Checks {
		if _, ok := wanted[check.Code]; ok && check.Status == "enforced" {
			wanted[check.Code] = true
		}
	}
	for code, ok := range wanted {
		if !ok {
			t.Fatalf("expected enforced check %s in %#v", code, got.Checks)
		}
	}
}

func TestDeriveLegacyLinuxPasswordPolicyDetectsAgingMismatch(t *testing.T) {
	raw := legacySecurityPasswordPolicy{
		Sources:   []string{"/etc/login.defs"},
		LoginDefs: map[string]string{"PASS_MAX_DAYS": "90", "PASS_MIN_DAYS": "1", "PASS_WARN_AGE": "7"},
	}
	users := []legacySecurityPolicyUser{{
		Username: "operator", UID: 1000, Shell: "/bin/bash", PasswordStatus: "password_set",
		MinPasswordAgeDays: int64p(0), MaxPasswordAgeDays: int64p(99999), WarningDays: int64p(7),
	}}
	got := deriveLegacyLinuxPasswordPolicy(raw, users)
	if got.EnforcementStatus != "partial" {
		t.Fatalf("status=%q checks=%#v", got.EnforcementStatus, got.Checks)
	}
}
