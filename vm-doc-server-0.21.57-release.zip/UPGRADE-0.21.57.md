# Upgrade VM-DOC Server 0.21.56 → 0.21.57

1. Confirmă versiunea 0.21.56 în surse și fă backup verificabil pentru MariaDB, configurație, surse și binarul curent. Nu rula curățarea înainte de backup.
2. Aplică **un singur mecanism**: `vm-doc-server-0.21.57-update.tar.gz` peste sursele 0.21.56 **sau** patch-ul 0.21.56→0.21.57. Nu aplica ambele. Refolosește `vendor/` de pe sistemul offline.
3. `GOPROXY=off GOSUMDB=off go test ./internal/inventorychanges`, apoi `GOPROXY=off GOSUMDB=off go test ./...` și `make build` pe serverul cu `vendor/`. Nu instala noul binar fără build și test staging.
4. Validează Docker: MAC diferit cu IP/gateway/network_id/imagine identice → 0 modificări. IP, gateway, network_id și imagine diferite → modificare. Inventarul brut trebuie să păstreze MAC-ul real.
5. Rulează `scripts/diagnose-nftables-docker-02157.sql` și compară timestampurile cu momentul instalării 0.21.56. Verifică `backend`, `chain` și `regula` pentru rândurile care persistă. Prezența unui eveniment vechi nu implică faptul că noul detector nu funcționează.
6. Curățare opțională: **oprește serverul**, rulează PREVIEW în staging, inspectează toate categoriile cumulative, apoi după aprobare rulează CLEANUP într-o fereastră de mentenanță. Selectează explicit baza MariaDB corectă. Scriptul păstrează review-urile, deciziile și notele manuale. Pentru rollback al DELETE este necesar backup.
7. Repornește, urmărește 2–3 zile distribuția schimbărilor `firewall`, `docker`, `ports` și asigură-te că evenimentele importante continuă să apară.

**Rollback cod:** restore binar/surse 0.21.56; fără rollback de schemă. **Rollback date:** exclusiv backup înainte de CLEANUP.

Agent 1.7.18/legacy neschimbat; fără migrare sau modificare de schema SQL. Test MariaDB reală și build complet cu vendor/ sunt de efectuat local.
