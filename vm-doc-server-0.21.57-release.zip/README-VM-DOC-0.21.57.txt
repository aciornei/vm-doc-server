VM-DOC Server 0.21.57 — pachet offline

Baza: 0.21.56. Folosește fie patch, fie update peste 0.21.56; nu ambele.
Sursele complete din source.zip nu includ vendor/ sau binar gata compilat.
Vezi UPGRADE-0.21.57.md pentru pași și rollback.
SQL PREVIEW și DIAGNOSE sunt doar citire; CLEANUP este distructiv și opțional.
Nu executa CLEANUP înainte de backup/restaurare testată și staging.
