-- Diagnostic READ ONLY pentru a stabili de ce exista inca evenimente nftables br-.
-- Nu modifica nimic si nu presupune o data de instalare a release-ului.
SELECT DATABASE() AS baza_curenta;
SELECT DATE(occurred_at) AS zi, change_type, COUNT(*) AS total
FROM inventory_changes
WHERE category='firewall' AND object_type='rule'
  AND object_key LIKE 'nftables|%br-%'
  AND occurred_at >= NOW() - INTERVAL 14 DAY
GROUP BY DATE(occurred_at), change_type ORDER BY zi DESC, change_type;

SELECT id, vm_id, occurred_at, change_type,
       SUBSTRING_INDEX(object_key,'|',1) AS backend,
       SUBSTRING_INDEX(SUBSTRING_INDEX(object_key,'|',4),'|',-1) AS lant,
       JSON_UNQUOTE(JSON_EXTRACT(COALESCE(new_json,old_json),'$.rule')) AS regula,
       review_status, documentation_requirement
FROM inventory_changes
WHERE category='firewall' AND object_type='rule'
  AND object_key LIKE 'nftables|%br-%'
  AND occurred_at >= NOW() - INTERVAL 14 DAY
ORDER BY occurred_at DESC, id DESC LIMIT 40;

-- Pentru a verifica exact regula izolarii Docker, inclusiv reguli vechi:
SELECT COUNT(*) AS total_guard_docker_neprocesate
FROM inventory_changes c
WHERE c.category='firewall' AND c.object_type='rule'
 AND c.object_key LIKE 'nftables|%br-%'
 AND c.review_status='new' AND c.documentation_requirement='unset'
 AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'')=''
 AND LOWER(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')),''))
 REGEXP 'ip daddr 172[.](1[6-9]|2[0-9]|3[01])[.][0-9]{1,3}[.][0-9]{1,3}';
