-- VM-DOC 0.21.50 · analiza/curatare zgomot inventory_changes
-- Ruleaza EXCLUSIV pe MariaDB-ul VM-DOC; operatorul trebuie sa selecteze baza corecta.
-- Protejeaza review-urile, deciziile de documentare si orice observatie manuala.
-- Criterii identice in PREVIEW si DELETE (sunt generate din aceeasi lista).
-- OPRITI vm-doc-server in timpul curatarii si faceti backup inainte.
-- NU afecteaza inventory_snapshots sau inventarul brut al agentului.
-- Ruleaza numai DUPA preview si backup. Operatia DELETE este ireversibila fara backup.
-- MariaDB / mysql CLI: mariadb -u ... -p NUME_BAZA < scripts/cleanup-inventory-changes.sql
-- O singura tranzactie: ori toate stergerile sunt confirmate, ori pot fi rollback.
START TRANSACTION;

-- porturi_dinamice
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'ports' AND c.object_type = 'listening_port' AND c.change_type IN ('added','removed')
AND c.object_label REGEXP '^Port [A-Za-z]+/[0-9]+$'
AND CAST(SUBSTRING_INDEX(c.object_label,'/',-1) AS UNSIGNED) BETWEEN 49152 AND 65535
AND NOT EXISTS (
 SELECT 1 FROM vm_primary_agent_ports pp WHERE pp.vm_id = c.vm_id
 AND LOWER(pp.protocol) = LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_label,' ', -1),'/',1))
 AND pp.port = CAST(SUBSTRING_INDEX(c.object_label,'/',-1) AS UNSIGNED)
));
SELECT 'porturi_dinamice' AS motiv, ROW_COUNT() AS sterse;

-- firewall_generat
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'firewall' AND c.object_type = 'rule' AND c.change_type IN ('added','removed')
AND (c.object_key LIKE 'firewall|rule|nftables|%' OR c.object_key LIKE 'firewall|rule|iptables|%' OR c.object_key LIKE 'firewall|rule|ip6tables|%')
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',6),'|',-1)) REGEXP '^(ufw-(before|after|track|logging|skip|reject|not-local)(-|$)|docker(-|$)|cni-|kube-|libvirt)'
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',6),'|',-1)) NOT LIKE 'docker-user%');
SELECT 'firewall_generat' AS motiv, ROW_COUNT() AS sterse;

-- servicii_efemere
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'services' AND c.object_type = 'service'
AND SUBSTRING_INDEX(c.object_key,'|',-1) REGEXP '^(user|user-runtime-dir|lxd-installer)@[0-9]+[.]service$');
SELECT 'servicii_efemere' AS motiv, ROW_COUNT() AS sterse;

-- stare_runtime_servicii
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='services' AND c.object_type='service' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND BINARY JSON_REMOVE(c.old_json,'$.active_state','$.sub_state') =
    BINARY JSON_REMOVE(c.new_json,'$.active_state','$.sub_state'));
SELECT 'stare_runtime_servicii' AS motiv, ROW_COUNT() AS sterse;

-- stare_runtime_ntp
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='time' AND c.object_type='ntp' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND BINARY JSON_REMOVE(c.old_json,'$.service_active','$.synchronized','$.current_source') =
    BINARY JSON_REMOVE(c.new_json,'$.service_active','$.synchronized','$.current_source'));
SELECT 'stare_runtime_ntp' AS motiv, ROW_COUNT() AS sterse;

-- probe_runtime_integrari
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='integrations' AND c.object_type='integration' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND BINARY JSON_REMOVE(c.old_json,'$.service_active','$.config_valid','$.config_check_output','$.output_test_ok','$.output_test_output') =
    BINARY JSON_REMOVE(c.new_json,'$.service_active','$.config_valid','$.config_check_output','$.output_test_ok','$.output_test_output'));
SELECT 'probe_runtime_integrari' AS motiv, ROW_COUNT() AS sterse;

COMMIT;
SELECT COUNT(*) AS evenimente_ramase FROM inventory_changes;
-- Nu OPTIMIZE TABLE automat; poate bloca tabela si se decide separat in mentenanta.
