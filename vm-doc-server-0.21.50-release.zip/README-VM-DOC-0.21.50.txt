VM-DOC Server 0.21.50 — Release offline
Data: 2026-10-20. Upgrade: 0.21.49 → 0.21.50.

CONȚINUT:
- vm-doc-server-0.21.50-source.zip: sursele complete (fără vendor/, la fel ca 0.21.49).
- vm-doc-server-0.21.50-update.tar.gz: numai fișiere noi/modificate, relativ la rădăcina surselor.
- vm-doc-server-0.21.49-to-0.21.50.patch: patch git verificat pe sursele 0.21.49.
- CONTEXT, CHANGELOG, VM-DOC-TODO, UPGRADE, RELEASE-NOTES, VERIFICATION.
- PREVIEW/CLEANUP SQL: curățare explicită după backup, fără ștergere automată în migrație.
- SHA256SUMS-IN-RELEASE.txt: SHA256 al membrilor pachetului.

INSTALL: citește UPGRADE-0.21.50.md înainte de executarea comenzilor.
ATENȚIE: curățarea istoricului elimină înregistrări; verifică preview-ul și backupul.
REȚINE: porturile persistente >=49152 necesită marcaj Principal pentru urmărirea în istoric.
LIMITARE: build Go complet cere dependențe din vendor/ existent; MariaDB reală necesită validare locală.
