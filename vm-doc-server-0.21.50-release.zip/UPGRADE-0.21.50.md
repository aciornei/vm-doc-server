# VM-DOC 0.21.49 → 0.21.50

**Server only; Agent 1.7.18 unchanged. No automatic schema migration.** Cleanup is opt-in and irreversible without backup.

1. **Back up** sources, current server binary, configs, and MariaDB. Copy the MySQL dump OUTSIDE the source tree. Verify the selected DB with `SELECT DATABASE()` and retain the backup securely.
2. Apply **one** update method to an **unmodified 0.21.49** source tree containing the real `vendor/` required for offline build:

   ```sh
   tar -xzf /cale/vm-doc-server-0.21.50-update.tar.gz
   # OR, from the source root:
   git apply /cale/vm-doc-server-0.21.49-to-0.21.50.patch
   ```

3. `cat VERSION` must return `0.21.50`. Run `bash scripts/cleanup-source-tree.sh --check` and `GOPROXY=off GOSUMDB=off go test ./...` followed by `GOPROXY=off GOSUMDB=off make build`. On an offline host, retain the preexisting `vendor/`. This release ZIP does **not** embed `vendor/` or a ready-to-run Linux binary.
4. Before applying to PROD, verify functional regression in staging: dynamic and Principal ports, firewall UFW user/DOCKER-USER/direct rules, service version and enabled-state changes, NTP and integration configuration. Then install the rebuilt binaries and restart systemd as usual.
5. **Cleanup existing changes (explicit, only after backup):** Stop the server service to prevent concurrent inserts. For example (replace `NUME_BAZA` and the mysql client login arguments according to your environment):

   ```sh
   systemctl stop vm-doc-server
   mysqldump --single-transaction -u UTILIZATOR -p NUME_BAZA > vm-doc-before-0.21.50.sql
   mariadb -u UTILIZATOR -p NUME_BAZA < scripts/preview-inventory-changes-cleanup.sql
   mariadb -u UTILIZATOR -p NUME_BAZA < scripts/cleanup-inventory-changes.sql
   mariadb -u UTILIZATOR -p NUME_BAZA < scripts/preview-inventory-changes-cleanup.sql
   systemctl start vm-doc-server
   ```

   The `cleanup` script uses an explicit transaction, reports removed rows per reason and preserves changes already reviewed, marked as documentation-required, or annotated. It does not delete inventory snapshots or firewall configurations. **Do not run `cleanup` on the wrong database.** For a large production table, run during a maintenance window due to temporary locks/undo usage. `OPTIMIZE TABLE` is not included.
6. Check change counts in 24–72 hours, and iterate the filters only with real samples.

**Rollback:** server/source 0.21.49 can be restored; SQL cleanup cannot be undone without restoring the MariaDB backup. No DDL migration needs rollback. Old filtered events remain absent after rollback until new collections regenerate them.

**Validation limits:** Unit tests and release parity checks may run locally; a live MariaDB test and full offline Go build on a host with `vendor/` are still required.
