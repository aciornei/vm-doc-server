# Upgrade VM-DOC Server 0.20.90 → 0.20.91

## Modificări

0.20.91 extinde **Securitate / Conturi VM** cu politica de parolă efectivă colectată de vm-doc-agent 1.7.15 și curăță implicit lista conturilor system Linux.

- nu există migrare DB;
- recomandat `vm-doc-agent 1.7.15` (schema 2.12) pentru politica de parole;
- agenții mai vechi rămân compatibili, dar cardul Politică parole va apărea ca necolectat;
- conturile system nu sunt șterse din inventar, doar ascunse implicit în UI.

## Upgrade

Oprește serviciul, aplică update-ul peste 0.20.90, reconstruiește binarul conform procedurii tale offline și repornește serviciul.

După restart, fă `Ctrl+F5` în browser. Pentru datele de policy, rulează **Colectează** pe VM-urile cu agent 1.7.15.

## Verificare

1. Deschide **Securitate → Conturi VM** și verifică blocul **Politici parole**.
2. Deschide o VM → **Securitate → Conturi** și verifică cardul **Politică parole**.
3. `sync`, `nobody`, `syslog` și alte conturi system fără login/privilegii nu trebuie să apară implicit.
4. Bifează **Afișează conturile system** pentru a vedea inventarul complet.
