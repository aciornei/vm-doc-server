# Upgrade vm-doc-server 0.20.42 -> 0.20.43

Versiunea 0.20.43 actualizează raportul **Suport sisteme de operare**. Nu adaugă migrare DB și nu necesită update de `vm-doc-agent`.

## Schimbări

- coloană nouă `Servicii` în tabel și export Excel;
- filtrul `VM pornit/oprit` este implicit `Pornit`;
- `Reset filtre` revine la `Pornit`;
- cardurile reflectă rezultatul căutării și filtrelor generale;
- spațiere îmbunătățită între filtre, carduri, grafice și tabel;
- rândul de acțiuni / Export Excel are padding pe toată lățimea.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.42 \
      /usr/local/src/vm-doc-server-0.20.43

tar -xzf vm-doc-server-0.20.43-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.43

cd /usr/local/src/vm-doc-server-0.20.43
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După restart folosește `Ctrl+F5` pentru a încărca `app.js?v=0.20.43`.
