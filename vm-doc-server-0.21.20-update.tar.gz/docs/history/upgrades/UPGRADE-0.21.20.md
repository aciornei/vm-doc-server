# Upgrade VM-DOC Server 0.21.19 → 0.21.20

- UI only; no SQL migrations and no agent update (1.7.18).
- Inventory VM and VM detail now use `ui-kpi-seven` with identical compact KPI card dimensions; on a normal 1440px viewport, seven cards render on one row.
- Filter expansion chevron centered in the filter bar; reset aligned right. On narrow mobile screens the active filters span the first row, while the chevron remains horizontally centered on the second.

## Offline update

```sh
cd /usr/local/src
cp -a vm-doc-server-0.21.19 vm-doc-server-0.21.20
cd vm-doc-server-0.21.20
tar -xzf /cale/vm-doc-server-0.21.20-update.tar.gz -C .
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Only deploy after tests and build succeed. Replace executable and restart service; refresh browser cache (Ctrl+F5). Manual verification in inventory and VM detail at 1440, 1024 and mobile resolutions is advised. No changes to server configuration, DB, API, or agent.
