package inventorychanges

import (
	"context"
	"database/sql"
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

// Default change-history policy: retain all raw snapshots. Only suppress
// unstable observations in change events. A selected Principal port is exempt.
const ephemeralPortStart = 49152
const ephemeralPortEnd = 65535

var ephemeralServiceRE = regexp.MustCompile(`(?i)^(?:user|user-runtime-dir|lxd-installer)@[0-9]+\.service$`)

func isEphemeralService(name string) bool {
	return ephemeralServiceRE.MatchString(strings.TrimSpace(name))
}

// This is an intentionally narrow list of AUTOMATIC rules/chains. In particular
// ufw-user-*, DOCKER-USER and ordinary INPUT/OUTPUT/FORWARD rules are retained.
var generatedChainRE = regexp.MustCompile(`(?i)^(?:ufw-(?:before|after|track|logging|skip|reject|not-local)(?:-|$)|docker(?:-|$)|cni-|kube-|libvirt)`)

func isGeneratedFirewallRule(rule map[string]any) bool {
	backend := strings.ToLower(first(rule, "backend"))
	if backend != "nftables" && backend != "iptables" && backend != "ip6tables" {
		return false
	}
	chain := first(rule, "chain")
	if strings.EqualFold(chain, "DOCKER-USER") || strings.HasPrefix(strings.ToLower(chain), "docker-user-") {
		return false
	}
	return generatedChainRE.MatchString(chain)
}

type portSelection struct {
	protocol string
	port     int
}

func loadPrimaryPortSelections(ctx context.Context, tx *sql.Tx, vmID int64) (map[portSelection]bool, error) {
	rows, err := tx.QueryContext(ctx, `SELECT protocol,port FROM vm_primary_agent_ports WHERE vm_id=?`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	selected := make(map[portSelection]bool)
	for rows.Next() {
		var protocol string
		var port int
		if err := rows.Scan(&protocol, &port); err != nil {
			return nil, err
		}
		selected[portSelection{strings.ToLower(strings.TrimSpace(protocol)), port}] = true
	}
	return selected, rows.Err()
}

func suppressDynamicPortChange(oldObj, newObj trackedObject, hadOld, hasNew bool, selected map[portSelection]bool) bool {
	o := newObj
	if !hasNew {
		o = oldObj
	}
	if o.Category != "ports" || o.Type != "listening_port" {
		return false
	}
	v, ok := o.Value.(map[string]any)
	if !ok {
		return false
	}
	pText := numberText(v["port"])
	port, err := strconv.Atoi(pText)
	if err != nil || port < ephemeralPortStart || port > ephemeralPortEnd {
		return false
	}
	proto := strings.ToLower(strings.TrimSpace(fmt.Sprint(v["protocol"])))
	return !selected[portSelection{proto, port}]
}
