package inventorychanges

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestNoiseServices(t *testing.T) {
	raw := []byte(`{"services":[{"name":"wlidsvc","active_state":"active","sub_state":"running","enabled_state":"enabled","version":"1.0"},{"name":"user@1000.service","enabled_state":"enabled"},{"name":"lxd-installer@68.service"}]}`)
	objs, err := extractTracked(raw)
	if err != nil {
		t.Fatal(err)
	}
	v, ok := objs["services|service|wlidsvc"]
	if !ok {
		t.Fatal("service lost")
	}
	val := v.Value.(map[string]any)
	if _, ok := val["active_state"]; ok {
		t.Fatal("volatile active_state preserved")
	}
	if _, ok := val["sub_state"]; ok {
		t.Fatal("volatile sub_state preserved")
	}
	if val["enabled_state"] != "enabled" || val["version"] != "1.0" {
		t.Fatal("meaningful service fields lost")
	}
	for key := range objs {
		if strings.Contains(key, "user@1000") || strings.Contains(key, "lxd-installer@") {
			t.Fatal("ephemeral service tracked", key)
		}
	}
}

func TestPortSelectionAndDynamicRange(t *testing.T) {
	makePort := func(port int) trackedObject {
		return trackedObject{Category: "ports", Type: "listening_port", Value: map[string]any{"protocol": "tcp", "port": json.Number(strings.TrimSpace(func() string {
			switch port {
			case 443:
				return "443"
			case 55000:
				return "55000"
			}
			return ""
		}()))}}
	}
	high := makePort(55000)
	low := makePort(443)
	if !suppressDynamicPortChange(high, trackedObject{}, true, false, nil) {
		t.Fatal("dynamic high port not ignored")
	}
	if suppressDynamicPortChange(low, trackedObject{}, true, false, nil) {
		t.Fatal("well known port ignored")
	}
	marked := map[portSelection]bool{{protocol: "tcp", port: 55000}: true}
	if suppressDynamicPortChange(trackedObject{}, high, false, true, marked) {
		t.Fatal("Principal port ignored")
	}
}

func TestGeneratedRulesConservative(t *testing.T) {
	tests := []struct {
		chain    string
		expected bool
	}{{"DOCKER", true}, {"DOCKER-FORWARD", true}, {"ufw-before-input", true}, {"cni-forward", true}, {"ufw-user-input", false}, {"DOCKER-USER", false}, {"INPUT", false}, {"OUTPUT", false}, {"custom", false}}
	for _, tc := range tests {
		actual := isGeneratedFirewallRule(map[string]any{"backend": "nftables", "chain": tc.chain})
		if actual != tc.expected {
			t.Fatalf("chain %s: want %v got %v", tc.chain, tc.expected, actual)
		}
	}
	if isGeneratedFirewallRule(map[string]any{"backend": "windows_firewall", "chain": "DOCKER"}) {
		t.Fatal("windows rule incorrectly excluded")
	}
}

func TestRuntimeChangesNoLongerTracked(t *testing.T) {
	a := []byte(`{"services":[{"name":"foo.service","active_state":"active","sub_state":"running","enabled_state":"enabled","version":"1"}],"ntp":{"synchronized":true,"current_source":"a","service_active":"active","service_enabled":"enabled"},"integrations":{"auditbeat":{"installed":true,"service_active":"running","output_test_ok":true,"output_test_output":"ok","package_version":"1"}}}`)
	b := []byte(`{"services":[{"name":"foo.service","active_state":"inactive","sub_state":"dead","enabled_state":"enabled","version":"1"}],"ntp":{"synchronized":false,"current_source":"b","service_active":"inactive","service_enabled":"enabled"},"integrations":{"auditbeat":{"installed":true,"service_active":"stopped","output_test_ok":false,"output_test_output":"error","package_version":"1"}}}`)
	aa, err := extractTracked(a)
	if err != nil {
		t.Fatal(err)
	}
	bb, err := extractTracked(b)
	if err != nil {
		t.Fatal(err)
	}
	for key, val := range aa {
		if !canonicalEqual(val.Value, bb[key].Value) {
			t.Fatal("runtime noise still tracked", key)
		}
	}
	bb["services|service|foo.service"] = trackedObject{Value: map[string]any{"version": "2"}}
	if canonicalEqual(aa["services|service|foo.service"].Value, bb["services|service|foo.service"].Value) {
		t.Fatal("version change not detected")
	}
}
