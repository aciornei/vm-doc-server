package fortigate

import (
	"fmt"
	"net"
	"strings"
)

type Resolver struct {
	Addresses map[string]Address
	Groups    map[string]Group
}

func (r Resolver) Match(ref, ipText string) (bool, string) {
	return r.match(ref, net.ParseIP(ipText), map[string]bool{}, 0)
}
func (r Resolver) match(ref string, ip net.IP, seen map[string]bool, depth int) (bool, string) {
	ref = strings.TrimSpace(ref)
	if ref == "" || ip == nil || depth > 16 {
		return false, ""
	}
	if strings.EqualFold(ref, "all") {
		// "all" is not enough to prove that a VM belongs to the policy source/destination interface.
		// Keep matching conservative and only correlate concrete IP objects/subnets/ranges/groups.
		return false, ""
	}
	key := strings.ToLower(ref)
	if seen[key] {
		return false, ""
	}
	seen[key] = true
	defer delete(seen, key)
	if a, ok := r.Addresses[key]; ok {
		if ok, desc := addressContains(a, ip); ok {
			return true, fmt.Sprintf("%s (%s)", a.Name, desc)
		}
	}
	if g, ok := r.Groups[key]; ok {
		for _, m := range g.Members {
			if yes, why := r.match(m, ip, seen, depth+1); yes {
				return true, fmt.Sprintf("%s → %s", g.Name, why)
			}
		}
	}
	return false, ""
}
func addressContains(a Address, ip net.IP) (bool, string) {
	// FortiGate address objects carry several different address types. Some
	// non-IP types may still expose a default/substitute subnet in the CMDB
	// payload. Treating that field as an IPv4 network creates false VM matches
	// (and can explode the match table). Only the two static IPv4 types below
	// are safe to use without additional FortiGate/runtime context.
	typ := strings.ToLower(strings.TrimSpace(a.Type))
	switch typ {
	case "", "ipmask":
		if a.Subnet == "" {
			return false, ""
		}
		n, desc := parseFortiSubnet(a.Subnet)
		if n == nil {
			return false, ""
		}
		ones, bits := n.Mask.Size()
		// A custom 0.0.0.0/0 object is semantically the same as FortiGate's
		// built-in "all" and must never be positive evidence that a policy is
		// specific to one VM.
		if bits != 32 || ones <= 0 {
			return false, ""
		}
		if n.Contains(ip) {
			return true, desc
		}
	case "iprange":
		if a.StartIP == "" || a.EndIP == "" {
			return false, ""
		}
		s, e := net.ParseIP(a.StartIP), net.ParseIP(a.EndIP)
		if s != nil && e != nil && compareIP(ip, s) >= 0 && compareIP(ip, e) <= 0 {
			return true, a.StartIP + "-" + a.EndIP
		}
	default:
		// fqdn, wildcard-fqdn, geography, dynamic, interface-subnet,
		// wildcard, mac, route-tag etc. are intentionally not resolved here.
		// They require DNS/interface/runtime semantics that cannot be proven from
		// a VM inventory IP alone.
		return false, ""
	}
	return false, ""
}

func addressMatchable(a Address) bool {
	typ := strings.ToLower(strings.TrimSpace(a.Type))
	switch typ {
	case "", "ipmask":
		n, _ := parseFortiSubnet(a.Subnet)
		if n == nil {
			return false
		}
		ones, bits := n.Mask.Size()
		return bits == 32 && ones > 0
	case "iprange":
		s, e := net.ParseIP(a.StartIP), net.ParseIP(a.EndIP)
		return s != nil && e != nil && compareIP(s, e) <= 0
	default:
		return false
	}
}
func parseFortiSubnet(v string) (*net.IPNet, string) {
	parts := strings.Fields(strings.TrimSpace(v))
	if len(parts) == 1 {
		_, n, e := net.ParseCIDR(parts[0])
		if e == nil {
			return n, n.String()
		}
		return nil, ""
	}
	if len(parts) >= 2 {
		ip := net.ParseIP(parts[0]).To4()
		maskIP := net.ParseIP(parts[1]).To4()
		if ip == nil || maskIP == nil {
			return nil, ""
		}
		mask := net.IPMask(maskIP)
		ones, bits := mask.Size()
		if bits != 32 || ones < 0 {
			return nil, ""
		}
		n := &net.IPNet{IP: ip.Mask(mask), Mask: mask}
		return n, n.String()
	}
	return nil, ""
}
func compareIP(a, b net.IP) int {
	aa := a.To16()
	bb := b.To16()
	if aa == nil || bb == nil {
		return 0
	}
	for i := 0; i < len(aa); i++ {
		if aa[i] < bb[i] {
			return -1
		}
		if aa[i] > bb[i] {
			return 1
		}
	}
	return 0
}
func vipContains(v VIP, ip string) (bool, string) {
	parsed := net.ParseIP(ip)
	if parsed == nil {
		return false, ""
	}
	for _, entry := range v.MappedIPs {
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		if strings.Contains(entry, "-") {
			p := strings.SplitN(entry, "-", 2)
			s, e := net.ParseIP(strings.TrimSpace(p[0])), net.ParseIP(strings.TrimSpace(p[1]))
			if s != nil && e != nil && compareIP(parsed, s) >= 0 && compareIP(parsed, e) <= 0 {
				return true, entry
			}
		} else if x := net.ParseIP(entry); x != nil && x.Equal(parsed) {
			return true, entry
		} else if _, n, err := net.ParseCIDR(entry); err == nil && n.Contains(parsed) {
			return true, entry
		}
	}
	return false, ""
}
