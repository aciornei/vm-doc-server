package fortigate

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

const maxResponseSize = 32 << 20

type Client struct {
	base  *url.URL
	token string
	http  *http.Client
	vdom  string
}

type envelope struct {
	Status     string          `json:"status"`
	HTTPStatus int             `json:"http_status"`
	Results    json.RawMessage `json:"results"`
}

func NewClient(baseURL, token, vdom string, verifyTLS bool, tlsServerName string, timeout time.Duration, allowHTTP bool) (*Client, error) {
	u, err := url.Parse(strings.TrimRight(strings.TrimSpace(baseURL), "/"))
	if err != nil {
		return nil, err
	}
	if u.Scheme != "https" && !(allowHTTP && u.Scheme == "http") {
		return nil, fmt.Errorf("FortiGate URL must use HTTPS")
	}
	if u.Host == "" {
		return nil, fmt.Errorf("invalid FortiGate URL")
	}
	if strings.TrimSpace(token) == "" {
		return nil, fmt.Errorf("FortiGate API token is required")
	}
	if strings.TrimSpace(vdom) == "" {
		vdom = "root"
	}
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: !verifyTLS, ServerName: strings.TrimSpace(tlsServerName)} // #nosec G402 - explicit admin option
	return &Client{base: u, token: token, vdom: vdom, http: &http.Client{Timeout: timeout, Transport: tr}}, nil
}

func (c *Client) get(ctx context.Context, path string, out any) error {
	u := *c.base
	u.Path = strings.TrimRight(c.base.Path, "/") + path
	q := u.Query()
	q.Set("vdom", c.vdom)
	u.RawQuery = q.Encode()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+c.token)
	req.Header.Set("Accept", "application/json")
	res, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	b, err := io.ReadAll(io.LimitReader(res.Body, maxResponseSize+1))
	if err != nil {
		return err
	}
	if len(b) > maxResponseSize {
		return fmt.Errorf("FortiGate response too large")
	}
	if res.StatusCode < 200 || res.StatusCode >= 300 {
		return fmt.Errorf("FortiGate API %s: HTTP %d: %s", path, res.StatusCode, strings.TrimSpace(string(b)))
	}
	var env envelope
	if err := json.Unmarshal(b, &env); err != nil {
		return fmt.Errorf("decode FortiGate response: %w", err)
	}
	if env.Status != "" && !strings.EqualFold(env.Status, "success") {
		return fmt.Errorf("FortiGate API %s status %s", path, env.Status)
	}
	if len(env.Results) == 0 || string(env.Results) == "null" {
		return nil
	}
	if err := json.Unmarshal(env.Results, out); err != nil {
		return fmt.Errorf("decode FortiGate results %s: %w", path, err)
	}
	return nil
}

func (c *Client) Inventory(ctx context.Context) (Inventory, error) {
	var out Inventory
	if err := c.get(ctx, "/api/v2/cmdb/firewall/address", &out.Addresses); err != nil {
		return out, err
	}
	if err := c.get(ctx, "/api/v2/cmdb/firewall/addrgrp", &out.Groups); err != nil {
		return out, err
	}
	if err := c.get(ctx, "/api/v2/cmdb/firewall/policy", &out.Policies); err != nil {
		return out, err
	}
	if err := c.get(ctx, "/api/v2/cmdb/firewall/vip", &out.VIPs); err != nil {
		return out, err
	}
	return out, nil
}

func (c *Client) Test(ctx context.Context) (map[string]int, error) {
	inv, err := c.Inventory(ctx)
	if err != nil {
		return nil, err
	}
	active, disabled := 0, 0
	for _, rawPolicy := range inv.Policies {
		p := ParsePolicy(rawPolicy)
		if p.ID == 0 {
			continue
		}
		if policyEnabled(p) {
			active++
		} else {
			disabled++
		}
	}
	matchableAddresses, ignoredAddresses := 0, 0
	for _, rawAddress := range inv.Addresses {
		a := ParseAddress(rawAddress)
		if a.Name == "" {
			continue
		}
		if addressMatchable(a) {
			matchableAddresses++
		} else {
			ignoredAddresses++
		}
	}
	return map[string]int{
		"addresses":           len(inv.Addresses),
		"addresses_matchable": matchableAddresses,
		"addresses_ignored":   ignoredAddresses,
		"groups":              len(inv.Groups),
		"policies":            active,
		"policies_disabled":   disabled,
		"vips":                len(inv.VIPs),
	}, nil
}
