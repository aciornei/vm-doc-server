package fortigate

import "testing"

func TestResolverSubnetAndNestedGroup(t *testing.T) {
	r := Resolver{Addresses: map[string]Address{
		"net-app": {Name: "NET-APP", Type: "ipmask", Subnet: "10.20.10.0 255.255.255.0"},
	}, Groups: map[string]Group{
		"grp-prod": {Name: "GRP-PROD", Members: []string{"NET-APP"}},
	}}
	ok, why := r.Match("GRP-PROD", "10.20.10.25")
	if !ok || why != "GRP-PROD → NET-APP (10.20.10.0/24)" {
		t.Fatalf("unexpected match: %v %q", ok, why)
	}
	if ok, _ := r.Match("GRP-PROD", "10.20.11.25"); ok {
		t.Fatal("unexpected subnet match")
	}
}

func TestResolverIPRange(t *testing.T) {
	r := Resolver{Addresses: map[string]Address{"range": {Name: "RANGE", Type: "iprange", StartIP: "10.1.1.10", EndIP: "10.1.1.20"}}, Groups: map[string]Group{}}
	if ok, _ := r.Match("RANGE", "10.1.1.15"); !ok {
		t.Fatal("range should match")
	}
	if ok, _ := r.Match("RANGE", "10.1.1.21"); ok {
		t.Fatal("range should not match")
	}
}

func TestResolverDoesNotClaimAllWithoutInterfaceEvidence(t *testing.T) {
	r := Resolver{Addresses: map[string]Address{}, Groups: map[string]Group{}}
	if ok, _ := r.Match("all", "10.1.1.15"); ok {
		t.Fatal("all must not be used as a positive VM correlation")
	}
}

func TestVIPRange(t *testing.T) {
	v := VIP{Name: "vip-app", MappedIPs: []string{"10.20.10.20-10.20.10.30"}}
	if ok, _ := vipContains(v, "10.20.10.25"); !ok {
		t.Fatal("VIP range should match")
	}
}

func TestResolverIgnoresCatchAllIPMask(t *testing.T) {
	r := Resolver{Addresses: map[string]Address{
		"custom-all": {Name: "CUSTOM-ALL", Type: "ipmask", Subnet: "0.0.0.0 0.0.0.0"},
	}, Groups: map[string]Group{}}
	if ok, _ := r.Match("CUSTOM-ALL", "10.20.10.25"); ok {
		t.Fatal("custom /0 address must not be positive VM evidence")
	}
}

func TestResolverIgnoresNonStaticAddressTypesEvenWithSubnetField(t *testing.T) {
	for _, typ := range []string{"geography", "dynamic", "interface-subnet", "wildcard", "mac", "route-tag"} {
		r := Resolver{Addresses: map[string]Address{
			"obj": {Name: "OBJ", Type: typ, Subnet: "0.0.0.0 0.0.0.0", StartIP: "0.0.0.0", EndIP: "255.255.255.255"},
		}, Groups: map[string]Group{}}
		if ok, _ := r.Match("OBJ", "10.20.10.25"); ok {
			t.Fatalf("address type %s must not be interpreted as static IPv4", typ)
		}
	}
}

func TestResolverKeepsSpecificIPMaskMatching(t *testing.T) {
	r := Resolver{Addresses: map[string]Address{
		"net-app": {Name: "NET-APP", Type: "ipmask", Subnet: "10.20.10.0 255.255.255.0"},
	}, Groups: map[string]Group{}}
	if ok, why := r.Match("NET-APP", "10.20.10.25"); !ok || why != "NET-APP (10.20.10.0/24)" {
		t.Fatalf("specific subnet should still match: %v %q", ok, why)
	}
}

func TestAddressMatchableClassification(t *testing.T) {
	cases := []struct {
		name string
		a    Address
		want bool
	}{
		{"ipmask", Address{Name: "N", Type: "ipmask", Subnet: "10.0.0.0 255.255.255.0"}, true},
		{"range", Address{Name: "R", Type: "iprange", StartIP: "10.0.0.1", EndIP: "10.0.0.10"}, true},
		{"catch-all", Address{Name: "A", Type: "ipmask", Subnet: "0.0.0.0 0.0.0.0"}, false},
		{"dynamic", Address{Name: "D", Type: "dynamic", Subnet: "10.0.0.0 255.0.0.0"}, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := addressMatchable(tc.a); got != tc.want {
				t.Fatalf("addressMatchable()=%v want %v", got, tc.want)
			}
		})
	}
}
