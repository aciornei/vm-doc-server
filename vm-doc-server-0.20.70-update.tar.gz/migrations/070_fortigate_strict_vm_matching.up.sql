-- 0.20.70: rebuild FortiGate VM correlations with strict static IPv4 semantics.
-- Existing rows were produced by the older permissive matcher and are not safe
-- to keep. DELETE is intentionally retry-safe if startup is interrupted.

DELETE FROM fortigate_vm_matches;

CREATE INDEX IF NOT EXISTS idx_fortigate_vm_matches_page
  ON fortigate_vm_matches (vm_id,policy_id,direction,vm_ip);

CREATE INDEX IF NOT EXISTS idx_fortigate_vm_matches_source_page
  ON fortigate_vm_matches (source_id,vm_id,policy_id,direction,vm_ip);
