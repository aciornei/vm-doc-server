# Upgrade VM-DOC Server 0.20.69 → 0.20.70

0.20.70 corectează corelarea FortiGate ↔ VM și reduce impactul Firewall central asupra bazei de date.

## Important

La primul startup se aplică migrarea `070_fortigate_strict_vm_matching.up.sql`.
Ea **șterge doar tabela de corelări `fortigate_vm_matches`**, nu inventarul FortiGate, VM-urile, address objects, groups, policies sau VIP-urile. Corelările existente trebuie eliminate deoarece au fost calculate cu matcher-ul vechi.

După pornire rulează **Securitate → Firewall central → Sync** pentru fiecare sursă FortiGate (sau `Sync toate`).

Pe o bază cu aproximativ 800.000 de match-uri, primul startup poate dura puțin cât se execută curățarea, dar indexurile noi se creează după golirea tabelei.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.69 /usr/local/src/vm-doc-server-0.20.70
tar -xzf vm-doc-server-0.20.70-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.70
cd /usr/local/src/vm-doc-server-0.20.70
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server`, apoi rulează un Sync FortiGate manual.

În **Test** vei vedea acum separat:
- policies active;
- policies disabled ignorate;
- adrese IP corelabile;
- adrese ignorate;
- VIP-uri.

În tabelul Firewall central, coloana **Corelat prin** rămâne explicația exactă a match-ului. Un VM trebuie să poată fi urmărit până la un obiect `ipmask`, `iprange` sau VIP valid; un tip dinamic/FQDN/geography ori un `/0` nu mai este suficient.

Agentul nu trebuie actualizat: `vm-doc-agent 1.7.12` rămâne recomandat.
