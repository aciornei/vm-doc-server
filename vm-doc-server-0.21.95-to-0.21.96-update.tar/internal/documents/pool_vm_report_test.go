package documents

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"io"
	"strings"
	"testing"
	"time"
)

func TestPoolVMReportThreeColumnsAndEscapedNotes(t *testing.T) {
	data, err := BuildPoolVMReportDOCX([]PoolVMReportEntry{{Pool: "VCSA / A&B", VM: "VM <prod>", Observation: "Note & data\nA doua linie"}, {Pool: "Fără pool identificat (VCSA)", VM: "", Observation: ""}}, []string{"Toate pool-urile"}, time.Date(2026, 11, 16, 8, 0, 0, 0, time.UTC))
	if err != nil {
		t.Fatal(err)
	}
	z, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		t.Fatal(err)
	}
	var found bool
	for _, f := range z.File {
		if f.Name != "word/document.xml" {
			continue
		}
		found = true
		rd, _ := f.Open()
		content, _ := io.ReadAll(rd)
		rd.Close()
		if err := xml.Unmarshal(content, new(any)); err != nil {
			t.Fatalf("invalid document.xml: %v", err)
		}
		s := string(content)
		for _, value := range []string{"Nume Pool", "Denumire VM", "Obs.", "A&amp;B", "VM &lt;prod&gt;", "Note &amp; data", "<w:tblHeader"} {
			if !strings.Contains(s, value) {
				t.Errorf("missing %q", value)
			}
		}
		if strings.Count(s, "<w:tr>") != 3 {
			t.Errorf("expected header and 2 rows")
		}
	}
	if !found {
		t.Fatal("missing Word body")
	}
}

func TestPoolVMReportMergesPoolCellsVerticallyWithoutMixingSources(t *testing.T) {
	entries := []PoolVMReportEntry{
		{GroupKey: "1:pool-1", Pool: "Resources / PROD", VM: "prod-1", Observation: "notă 1"},
		{GroupKey: "1:pool-1", Pool: "Resources / PROD", VM: "prod-2", Observation: "notă 2"},
		{GroupKey: "1:pool-1", Pool: "Resources / PROD", VM: "prod-3"},
		{GroupKey: "2:pool-1", Pool: "Resources / PROD", VM: "alta VCSA"},
		{GroupKey: "2:pool-2", Pool: "Resources / TEST", VM: "vm-test"},
	}
	data, err := BuildPoolVMReportDOCX(entries, nil, time.Date(2026, 11, 16, 9, 0, 0, 0, time.UTC))
	if err != nil {
		t.Fatal(err)
	}
	z, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		t.Fatal(err)
	}
	for _, f := range z.File {
		if f.Name != "word/document.xml" {
			continue
		}
		r, err := f.Open()
		if err != nil {
			t.Fatal(err)
		}
		body, err := io.ReadAll(r)
		_ = r.Close()
		if err != nil {
			t.Fatal(err)
		}
		var decoded any
		if err := xml.Unmarshal(body, &decoded); err != nil {
			t.Fatal(err)
		}
		text := string(body)
		if got := strings.Count(text, `<w:vMerge w:val="restart"/>`); got != 1 {
			t.Errorf("expected one merged group, got %d", got)
		}
		if got := strings.Count(text, `<w:vMerge w:val="continue"/>`); got != 2 {
			t.Errorf("expected two continuation cells, got %d", got)
		}
		if got := strings.Count(text, `Resources / PROD</w:t>`); got != 2 {
			t.Errorf("same name in two sources must be shown twice, got %d", got)
		}
		if !strings.Contains(text, `<w:vMerge w:val="restart"/><w:vAlign w:val="center"/>`) {
			t.Error("pool merged cells must be vertically centered")
		}
		if got := strings.Count(text, `<w:tr>`); got != 6 {
			t.Errorf("expected one header plus five VM rows, got %d", got)
		}
		for _, v := range []string{"prod-1", "prod-2", "prod-3", "alta VCSA", "vm-test", "notă 1", "notă 2"} {
			if !strings.Contains(text, v) {
				t.Errorf("missing row information %s", v)
			}
		}
		return
	}
	t.Fatal("missing main document")
}
