package documents

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"fmt"
	"io"
	"strings"
	"time"
)

// PoolVMReportEntry is deliberately limited to the three requested report
// columns. No Vault URL, credentials, identifiers, or inventory JSON are used.
type PoolVMReportEntry struct {
	// GroupKey distinguishes identically named pools from different VCSA sources.
	// It is used only for table merging and is never printed in the document.
	GroupKey    string
	Pool        string
	VM          string
	Observation string
}

func safePoolReportText(value string) string {
	value = strings.Map(func(r rune) rune {
		if r == '\t' || r == '\n' || r == '\r' || r >= 0x20 && r <= 0xD7FF || r >= 0xE000 && r <= 0xFFFD || r >= 0x10000 && r <= 0x10FFFF {
			return r
		}
		return -1
	}, value)
	var out bytes.Buffer
	_ = xml.EscapeText(&out, []byte(value))
	return out.String()
}

func poolReportParagraph(value string, bold bool) string {
	style := ""
	if bold {
		style = `<w:rPr><w:b/><w:sz w:val="20"/></w:rPr>`
	}
	parts := strings.Split(strings.ReplaceAll(value, "\r\n", "\n"), "\n")
	var b strings.Builder
	b.WriteString(`<w:p><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr>`)
	for i, part := range parts {
		if i > 0 {
			b.WriteString(`<w:r><w:br/></w:r>`)
		}
		b.WriteString(`<w:r>` + style + `<w:t xml:space="preserve">` + safePoolReportText(part) + `</w:t></w:r>`)
	}
	b.WriteString(`</w:p>`)
	return b.String()
}

// mergeState is "restart" on the first VM row of a multi-row pool,
// "continue" on subsequent rows, or empty for a single-row pool.
func poolReportCell(value string, width int, header, poolColumn bool, mergeState string) string {
	var b strings.Builder
	b.WriteString(fmt.Sprintf(`<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>`, width))
	if mergeState != "" {
		b.WriteString(`<w:vMerge w:val="` + mergeState + `"/>`)
	}
	if poolColumn || header {
		b.WriteString(`<w:vAlign w:val="center"/>`)
	} else {
		b.WriteString(`<w:vAlign w:val="top"/>`)
	}
	if header {
		b.WriteString(`<w:shd w:fill="E8EFF8"/>`)
	}
	b.WriteString(`</w:tcPr>`)
	if mergeState == "continue" {
		b.WriteString(`<w:p/>`)
	} else {
		b.WriteString(poolReportParagraph(value, header))
	}
	b.WriteString(`</w:tc>`)
	return b.String()
}

func poolReportRow(pool, vm, observation string, header bool, mergeState string) string {
	var b strings.Builder
	b.WriteString(`<w:tr><w:trPr><w:cantSplit/>`)
	if header {
		b.WriteString(`<w:tblHeader w:val="true"/>`)
	}
	b.WriteString(`</w:trPr>`)
	b.WriteString(poolReportCell(pool, 3900, header, true, mergeState))
	b.WriteString(poolReportCell(vm, 4200, header, false, ""))
	b.WriteString(poolReportCell(observation, 5600, header, false, ""))
	b.WriteString(`</w:tr>`)
	return b.String()
}

func poolReportGroupKey(item PoolVMReportEntry) string {
	if item.GroupKey != "" {
		return item.GroupKey
	}
	return item.Pool
}

func poolReportDocumentXML(items []PoolVMReportEntry, filters []string, when time.Time) string {
	var b strings.Builder
	b.WriteString(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>`)
	b.WriteString(`<w:p><w:pPr><w:pStyle w:val="Title"/><w:spacing w:after="180"/></w:pPr><w:r><w:t>VM-uri pe resource pool-uri</w:t></w:r></w:p>`)
	b.WriteString(poolReportParagraph(fmt.Sprintf("Generat: %s UTC  ·  Rânduri: %d", when.UTC().Format("02.01.2006 15:04"), len(items)), false))
	b.WriteString(poolReportParagraph("Sursă: ultimul inventar sincronizat din VCSA (inclusiv pool-uri excluse și VM-uri neimportate).", false))
	if len(filters) > 0 {
		b.WriteString(poolReportParagraph("Filtre: "+strings.Join(filters, " · "), false))
	} else {
		b.WriteString(poolReportParagraph("Filtre: toate pool-urile prezente în VCSA", false))
	}
	b.WriteString(`<w:p><w:pPr><w:spacing w:after="140"/></w:pPr></w:p>`)
	b.WriteString(`<w:tbl><w:tblPr><w:tblW w:w="13700" w:type="dxa"/><w:tblLayout w:type="fixed"/>`)
	b.WriteString(`<w:tblBorders><w:top w:val="single" w:sz="4" w:color="B6C4D8"/><w:left w:val="single" w:sz="4" w:color="B6C4D8"/><w:bottom w:val="single" w:sz="4" w:color="B6C4D8"/><w:right w:val="single" w:sz="4" w:color="B6C4D8"/><w:insideH w:val="single" w:sz="4" w:color="D8E1EA"/><w:insideV w:val="single" w:sz="4" w:color="D8E1EA"/></w:tblBorders>`)
	b.WriteString(`<w:tblCellMar><w:top w:w="80" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/><w:left w:w="120" w:type="dxa"/><w:right w:w="120" w:type="dxa"/></w:tblCellMar></w:tblPr>`)
	b.WriteString(`<w:tblGrid><w:gridCol w:w="3900"/><w:gridCol w:w="4200"/><w:gridCol w:w="5600"/></w:tblGrid>`)
	b.WriteString(poolReportRow("Nume Pool", "Denumire VM", "Obs.", true, ""))
	for i, item := range items {
		mergeState := ""
		key := poolReportGroupKey(item)
		if i > 0 && poolReportGroupKey(items[i-1]) == key {
			mergeState = "continue"
		} else if i+1 < len(items) && poolReportGroupKey(items[i+1]) == key {
			mergeState = "restart"
		}
		vmName := item.VM
		if vmName == "" {
			vmName = "—"
		}
		b.WriteString(poolReportRow(item.Pool, vmName, item.Observation, false, mergeState))
	}
	b.WriteString(`</w:tbl>`)
	b.WriteString(`<w:p/>`)
	b.WriteString(`<w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="850" w:right="850" w:bottom="850" w:left="850" w:header="400" w:footer="400" w:gutter="0"/></w:sectPr>`)
	b.WriteString(`</w:body></w:document>`)
	return b.String()
}

// BuildPoolVMReportDOCX produces an editable DOCX report. The default VM-DOC
// package supplies standard styles and packaging; only the main document body
// is replaced with the dedicated, three-column report.
func BuildPoolVMReportDOCX(items []PoolVMReportEntry, filters []string, when time.Time) ([]byte, error) {
	if len(items) > 25000 {
		return nil, fmt.Errorf("pool report exceeds 25000 rows")
	}
	defaultDOCX, err := DefaultTemplate()
	if err != nil {
		return nil, err
	}
	reader, err := zip.NewReader(bytes.NewReader(defaultDOCX), int64(len(defaultDOCX)))
	if err != nil {
		return nil, err
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	for _, file := range reader.File {
		entry, err := writer.Create(file.Name)
		if err != nil {
			return nil, err
		}
		if file.Name == "word/document.xml" {
			_, err = io.WriteString(entry, poolReportDocumentXML(items, filters, when))
		} else {
			input, openErr := file.Open()
			if openErr != nil {
				return nil, openErr
			}
			if file.Name == "docProps/core.xml" {
				content, readErr := io.ReadAll(input)
				_ = input.Close()
				if readErr != nil {
					return nil, readErr
				}
				meta := strings.ReplaceAll(string(content), "Fișă tehnică VM", "VM-uri pe resource pool-uri")
				stamp := when.UTC().Format("2006-01-02T15:04:05Z")
				meta = strings.ReplaceAll(meta, "2026-01-01T00:00:00Z", stamp)
				_, err = io.WriteString(entry, meta)
			} else {
				_, err = io.Copy(entry, input)
				_ = input.Close()
			}
		}
		if err != nil {
			return nil, err
		}
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return output.Bytes(), nil
}
