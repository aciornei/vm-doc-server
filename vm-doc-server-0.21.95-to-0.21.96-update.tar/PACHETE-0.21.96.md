# VM-DOC Server 0.21.96 — pachete

- `VM-DOC-0.21.96-RELEASE.zip`: pachet complet de livrare (surse, incremental, patch, documentație, verificări și SHA256).
- `vm-doc-server-0.21.96-source.zip`: toate sursele Go, JS, CSS și documentația aferentă versiunii.
- `vm-doc-server-0.21.95-to-0.21.96-update.tar.gz`: doar fișierele schimbate; extrage în rădăcina surselor 0.21.95.
- `vm-doc-server-0.21.95-to-0.21.96.patch`: diff text aplicabil cu `patch -p1` peste sursele 0.21.95.
- `UPGRADE-0.21.96.md`, `RELEASE-NOTES-0.21.96.md`, `CHANGELOG-0.21.96.md`, `CONTEXT-0.21.96.md`, `VM-DOC-TODO-0.21.96.md`.
- `QA-pool-report-0.21.96.docx`: Word exemplu cu date fictive și pool-uri unificate.

Agent: 1.7.18 (nemodificat). Fără migrare SQL nouă. Build complet pe serverul offline necesar.
