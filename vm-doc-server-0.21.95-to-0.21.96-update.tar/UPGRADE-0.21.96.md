# Actualizare VM-DOC Server 0.21.95 → 0.21.96

1. Efectuează backup pentru configurație, binarul actual și MariaDB înainte de actualizare (fără migrare SQL nouă).
2. Din directorul **surselor** 0.21.95, care conține `Makefile` și `VERSION`, extrage arhiva `vm-doc-server-0.21.95-to-0.21.96-update.tar.gz`:

   ```bash
   tar -xzf /cale/vm-doc-server-0.21.95-to-0.21.96-update.tar.gz
   cat VERSION   # trebuie sa fie 0.21.96
   ```

   Alternativ: sursele complete 0.21.96, fără suprascrierea directorului local `vendor/` sau a configurației.
3. Testează și compilează în mediul offline cu `vendor/` instalat:

   ```bash
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
   ```

4. Identifică binarul activ cu `systemctl cat vm-doc-server | grep ExecStart`. Oprește serviciul, salvează executabilul vechi, instalează noul `bin/vm-doc-server` în calea exactă a lui `ExecStart`, repornește și verifică `/version` = `0.21.96`. Aplică `Ctrl+F5` în browser.
5. Deschide **Rapoarte → VM-uri pe resource pool-uri**: verifică gruparea primei coloane într-un pool cu două sau mai multe VM-uri, apoi **Export Word**. În Word, numele pool-ului trebuie să fie într-o singură celulă unită vertical, iar VM-urile și observațiile pe rânduri distincte.
6. Testează un pool cu multe VM-uri pe mai multe pagini, două pool-uri cu același nume în surse diferite, pool-uri goale, filtre și paginare.

## Rollback

Înlocuiește doar executabilul cu copia 0.21.95 și repornește; nu există migrare de revenit. Nu este necesar upgrade agent.

## Limitări

Pachetul conține surse, nu `vendor/` sau binar compilat pentru mediul de producție. Build complet și test MariaDB/VCSA + browser se efectuează pe server/staging.
