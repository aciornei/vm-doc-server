# VM-DOC Server 0.21.96 — Nume Pool unificat vertical în raport

Data: 2026-11-16. Actualizare incrementală peste 0.21.95. Agent VM-DOC 1.7.18, nemodificat.

## Modificare

- În **Rapoarte → VM-uri pe resource pool-uri**, celula **Nume Pool** este unită pe rândurile VM-urilor din același pool, cu numele **centrat pe verticală** și aliniat la stânga pe orizontală.
- Interfața HTML folosește `rowspan`; în cazul paginării, gruparea este reluată la începutul paginii următoare.
- Exportul Word DOCX folosește celule unite OOXML `w:vMerge` (`restart` / `continue`), cu `w:vAlign=center`. Rândurile VM nu se despart între pagini; antetul tabelului se repetă.
- Identitatea grupului este `vcenter_source_id + pool_moid`, nu numai denumirea; pool-urile omonime din surse diferite sau același vCenter nu sunt unite accidental. Ordinea serverului a fost întărită pentru grupuri contigue.
- Câte o celulă distinctă pentru **Denumire VM** și **Obs.**; filtrele, exportul pe întreg setul filtrat și listele de VM-uri neimportate/pool-uri goale rămân neschimbate.
- Sortarea generică din browser este dezactivată numai pentru tabelul cu `rowspan`, pentru a nu sparge gruparea.

## Compatibilitate și validare

- Fără migrare SQL, modificări în vCenter/sincronizare, modificări ale agentului, API-urilor, permisiunilor, Outline sau Vault.
- Teste Go DOCX pentru îmbinare, etichetă centrată și pool-uri omonime; `node --check` și test HTML pentru `rowspan`/paginare: OK.
- Exemplu Word 36 VM-uri randat și verificat pe trei pagini: OK.
- Testul complet Go cu `vendor/`, MariaDB/VCSA reale și browser autentificat rămân de confirmat în staging.
