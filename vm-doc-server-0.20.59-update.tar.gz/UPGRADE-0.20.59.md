# Upgrade 0.20.58 → 0.20.59

## Ce se schimbă

0.20.59 extinde raportul **Rapoarte → Componente software** cu publicare în Outline.

În **Documente → Configurare Outline** apare destinația **Componente suport**, unde se configurează linkul unei pagini părinte existente din Outline. VM-DOC nu rescrie pagina părinte; creează sau actualizează sub ea câte o pagină copil pentru fiecare componentă software detectată, de exemplu PostgreSQL, MongoDB, Java, Nginx sau Redis.

În raport:

- fără componentă selectată, butonul publică toate componentele pe rând;
- cu o componentă selectată, publică numai pagina acelei componente;
- filtrele vizuale de căutare, versiune, categorie și mediu nu reduc conținutul paginii publicate, astfel încât pagina unei componente rămâne completă;
- VM-urile folosesc linkul către fișa lor Outline dacă aceasta există;
- serviciile/proiectele folosesc Link documentație Outline;
- **Power** și **Mediu** sunt coloane separate, iar Power este afișat ca ON/OFF.

## Migrare DB

La pornire se aplică automat:

```text
066_outline_software_component_documents.up.sql
```

Migrarea:

- adaugă destinația generică `support_components` / **Componente suport** în `outline_publication_targets`;
- creează tabelul `outline_software_component_documents`, care păstrează maparea componentă → pagină Outline și previne dublarea paginilor la republicare.

Nu sunt modificate selecțiile existente, fișele VM sau paginile serviciilor.

## Agent

Nu este necesar update de `vm-doc-agent`.

## Instalare offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.58 \
      /usr/local/src/vm-doc-server-0.20.59

tar -xzf vm-doc-server-0.20.59-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.59

cd /usr/local/src/vm-doc-server-0.20.59
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Înlocuiește binarul și repornește `vm-doc-server`. Migrarea 066 este aplicată la startup. Apoi fă `Ctrl+F5` în browser.

## Configurare și verificare recomandată

1. Intră în **Documente → Configurare Outline**.
2. La **Componente suport**, introdu linkul paginii părinte din Outline și salvează.
3. Deschide **Rapoarte → Componente software**.
4. Fără componentă selectată, apasă **Publică toate în Outline** și urmărește progresul; sub pagina părinte trebuie să apară câte o pagină pentru fiecare componentă.
5. Selectează **PostgreSQL** și republică: trebuie actualizată numai pagina PostgreSQL.
6. Verifică în pagina PostgreSQL că VM-urile publicate deja au link către fișa lor Outline și că serviciile/proiectele cu Link documentație sunt clicabile.
7. Verifică existența coloanelor separate **Power** și **Mediu**, cu valorile ON/OFF pentru Power.
8. Schimbă un filtru de mediu sau versiune și republică PostgreSQL: pagina Outline trebuie să rămână inventarul complet PostgreSQL, nu doar filtrul vizual.
