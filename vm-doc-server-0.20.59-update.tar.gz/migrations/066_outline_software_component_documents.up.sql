-- 0.20.59: părinte Outline pentru componente software și maparea paginilor copil create automat.

INSERT INTO outline_publication_targets(target_code,target_name,active)
VALUES ('support_components','Componente suport',1)
ON DUPLICATE KEY UPDATE target_name=VALUES(target_name);

CREATE TABLE IF NOT EXISTS outline_software_component_documents (
  component_key VARCHAR(64) NOT NULL,
  component_name VARCHAR(255) NOT NULL,
  document_id VARCHAR(64) NOT NULL DEFAULT '',
  document_url VARCHAR(1024) NOT NULL DEFAULT '',
  parent_document_id VARCHAR(64) NOT NULL DEFAULT '',
  content_hash CHAR(64) NOT NULL DEFAULT '',
  last_synced_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (component_key),
  KEY idx_outline_software_component_document_id (document_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
