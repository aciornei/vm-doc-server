package server

import "testing"

func TestIdentifySoftwareComponent(t *testing.T) {
	tests := []struct {
		value string
		key   string
		ok    bool
	}{
		{"postgresql-14.service", "postgresql", true},
		{"bitnami/mongodb:7.0", "mongodb", true},
		{"mongo:7.0", "mongodb", true},
		{"kubelet.service", "kubernetes", true},
		{"redis-server", "redis", true},
		{"node_exporter.service", "nodeexporter", true},
		{"prometheus.service", "prometheus", true},
		{"java-1.8.0-openjdk", "java", true},
		{"php8.2-fpm", "php", true},
		{"Microsoft SQL Server 2022", "sqlserver", true},
		{"postgres_exporter", "", false},
		{"postgresql-client-14", "", false},
		{"unrelated-package", "", false},
	}
	for _, test := range tests {
		def, ok := identifySoftwareComponent(test.value)
		if ok != test.ok {
			t.Fatalf("identifySoftwareComponent(%q) ok=%v, want %v (def=%+v)", test.value, ok, test.ok, def)
		}
		if ok && def.Key != test.key {
			t.Fatalf("identifySoftwareComponent(%q) key=%q, want %q", test.value, def.Key, test.key)
		}
	}
}

func TestVersionFromContainerImage(t *testing.T) {
	tests := map[string]string{
		"postgres:14.11":                         "14.11",
		"registry.local:5000/mongo:7.0":          "7.0",
		"quay.io/keycloak/keycloak:26.5.7":       "26.5.7",
		"redis@sha256:0123456789abcdef":          "",
		"registry.local:5000/postgres":           "",
		"registry.local:5000/postgres:latest":    "",
		"registry.local:5000/postgres:16-alpine": "16-alpine",
	}
	for image, want := range tests {
		if got := versionFromContainerImage(image); got != want {
			t.Errorf("versionFromContainerImage(%q)=%q, want %q", image, got, want)
		}
	}
}

func TestFilterSoftwareComponentRowsVersionPrefix(t *testing.T) {
	rows := []softwareComponentReportRow{{ComponentKey: "postgresql", ComponentName: "PostgreSQL", Category: "Baze de date", Versions: []string{"8.4.22", "14.11"}, Version: "8.4.22, 14.11", Environment: "PROD", VMID: 1, VMName: "db01"}}
	if got := filterSoftwareComponentRows(rows, "", "postgresql", "", "8", ""); len(got) != 1 {
		t.Fatalf("expected PostgreSQL 8 prefix to match, got %d rows", len(got))
	}
	if got := filterSoftwareComponentRows(rows, "", "postgresql", "", "15", ""); len(got) != 0 {
		t.Fatalf("expected PostgreSQL 15 not to match, got %d rows", len(got))
	}
}

func TestGroupSoftwareComponentRowsForOutline(t *testing.T) {
	rows := []softwareComponentReportRow{
		{ComponentKey: "postgresql", ComponentName: "PostgreSQL", Category: "Baze de date", VMID: 2, VMName: "db02", Environment: "TEST"},
		{ComponentKey: "mongodb", ComponentName: "MongoDB", Category: "Baze de date", VMID: 3, VMName: "mongo01", Environment: "PROD"},
		{ComponentKey: "postgresql", ComponentName: "PostgreSQL", Category: "Baze de date", VMID: 1, VMName: "db01", Environment: "PROD"},
	}
	all := groupSoftwareComponentRowsForOutline(rows, "")
	if len(all) != 2 {
		t.Fatalf("expected 2 component groups, got %d", len(all))
	}
	selected := groupSoftwareComponentRowsForOutline(rows, "postgresql")
	if len(selected) != 1 || selected[0].Key != "postgresql" || len(selected[0].Rows) != 2 {
		t.Fatalf("unexpected PostgreSQL selection: %+v", selected)
	}
	if selected[0].Rows[0].VMName != "db01" {
		t.Fatalf("expected PROD/db01 first, got %q", selected[0].Rows[0].VMName)
	}
}

func TestSoftwareComponentServiceLinksMarkdown(t *testing.T) {
	got := softwareComponentServiceLinksMarkdown([]softwareComponentServiceLink{{Name: "Portal", URL: "https://outline.example/doc/portal"}, {Name: "Worker"}}, "")
	if got != "[Portal](https://outline.example/doc/portal)<br>Worker" {
		t.Fatalf("unexpected service links markdown: %q", got)
	}
}
