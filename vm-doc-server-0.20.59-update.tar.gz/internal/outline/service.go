package outline

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/cryptox"
)

const secretAADPrefix = "vm-doc-outline-api-key:"

type Service struct {
	DB     *sql.DB
	Box    *cryptox.Box
	Logger *slog.Logger
}

type Settings struct {
	Enabled                        bool      `json:"enabled"`
	BaseURL                        string    `json:"base_url"`
	CollectionID                   string    `json:"collection_id,omitempty"`
	VirtualizationParentDocumentID string    `json:"virtualization_parent_document_id"`
	VerifyTLS                      bool      `json:"verify_tls"`
	AllowHTTP                      bool      `json:"allow_http"`
	RequestTimeoutSeconds          int       `json:"request_timeout_seconds"`
	APIKeyConfigured               bool      `json:"api_key_configured"`
	UpdatedAt                      time.Time `json:"updated_at"`
}

type PublicationTarget struct {
	Code              string     `json:"code"`
	Name              string     `json:"name"`
	DocumentReference string     `json:"document_reference"`
	DocumentID        string     `json:"document_id,omitempty"`
	DocumentURL       string     `json:"document_url,omitempty"`
	Active            bool       `json:"active"`
	LastPublishedAt   *time.Time `json:"last_published_at,omitempty"`
	UpdatedAt         time.Time  `json:"updated_at"`
	contentHash       string
}

type PublicationTargetInput struct {
	Name              string `json:"name"`
	DocumentReference string `json:"document_reference"`
	Active            *bool  `json:"active,omitempty"`
}

type SettingsInput struct {
	Enabled                        *bool  `json:"enabled,omitempty"`
	BaseURL                        string `json:"base_url"`
	CollectionID                   string `json:"collection_id,omitempty"`
	VirtualizationParentDocumentID string `json:"virtualization_parent_document_id"`
	APIKey                         string `json:"api_key,omitempty"`
	VerifyTLS                      *bool  `json:"verify_tls,omitempty"`
	AllowHTTP                      *bool  `json:"allow_http,omitempty"`
	RequestTimeoutSeconds          int    `json:"request_timeout_seconds,omitempty"`
}

type settingsRecord struct {
	Settings
	SecretRef string
	Cipher    sql.NullString
}

type TestResult struct {
	OK                  bool   `json:"ok"`
	CollectionID        string `json:"collection_id,omitempty"`
	CollectionName      string `json:"collection_name,omitempty"`
	ParentDocumentID    string `json:"parent_document_id,omitempty"`
	ParentDocumentTitle string `json:"parent_document_title,omitempty"`
	BaseURL             string `json:"base_url"`
}

type PublishResult struct {
	ObjectType string `json:"object_type"`
	TargetCode string `json:"target_code,omitempty"`
	ObjectID   int64  `json:"object_id"`
	ServiceID  int64  `json:"service_id,omitempty"`
	DocumentID string `json:"document_id"`
	URL        string `json:"url"`
	Created    bool   `json:"created"`
	Changed    bool   `json:"changed"`
	Title      string `json:"title"`
}

type apiDocument struct {
	ID    string `json:"id"`
	URL   string `json:"url"`
	Title string `json:"title"`
}

type ResolvedDocument struct {
	ID    string `json:"id"`
	URL   string `json:"url"`
	Title string `json:"title"`
}

type apiCollection struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}

type apiEnvelope[T any] struct {
	Data T `json:"data"`
}

type apiErrorEnvelope struct {
	Error   string `json:"error"`
	Message string `json:"message"`
	Status  int    `json:"status"`
	OK      bool   `json:"ok"`
}

type remoteError struct {
	StatusCode int
	Message    string
}

func (e *remoteError) Error() string { return e.Message }

func NewService(db *sql.DB, box *cryptox.Box, logger *slog.Logger) *Service {
	if logger == nil {
		logger = slog.Default()
	}
	return &Service{DB: db, Box: box, Logger: logger}
}

func (s *Service) GetSettings(ctx context.Context) (Settings, error) {
	record, err := s.getRecord(ctx)
	return record.Settings, err
}

func (s *Service) getRecord(ctx context.Context) (settingsRecord, error) {
	var r settingsRecord
	var enabled, verifyTLS, allowHTTP bool
	var updatedAt time.Time
	err := s.DB.QueryRowContext(ctx, `SELECT s.enabled,s.base_url,s.collection_id,s.api_key_secret_ref,s.api_key_ciphertext,s.verify_tls,s.allow_http,s.request_timeout_seconds,s.updated_at,
		COALESCE((SELECT t.parent_document_id FROM outline_targets t WHERE t.target_code='virtualization' AND t.active=1),'')
		FROM outline_settings s WHERE s.id=1`).Scan(
		&enabled, &r.BaseURL, &r.CollectionID, &r.SecretRef, &r.Cipher, &verifyTLS, &allowHTTP, &r.RequestTimeoutSeconds, &updatedAt, &r.VirtualizationParentDocumentID,
	)
	if err != nil {
		return r, err
	}
	r.Enabled = enabled
	r.VerifyTLS = verifyTLS
	r.AllowHTTP = allowHTTP
	r.APIKeyConfigured = r.Cipher.Valid && strings.TrimSpace(r.Cipher.String) != "" && strings.TrimSpace(r.SecretRef) != ""
	r.UpdatedAt = updatedAt
	return r, nil
}

func (s *Service) UpdateSettings(ctx context.Context, userID int64, in SettingsInput) (Settings, error) {
	current, err := s.getRecord(ctx)
	if err != nil {
		return Settings{}, err
	}
	if in.Enabled == nil {
		v := current.Enabled
		in.Enabled = &v
	}
	if in.VerifyTLS == nil {
		v := current.VerifyTLS
		in.VerifyTLS = &v
	}
	if in.AllowHTTP == nil {
		v := current.AllowHTTP
		in.AllowHTTP = &v
	}
	if in.RequestTimeoutSeconds == 0 {
		in.RequestTimeoutSeconds = current.RequestTimeoutSeconds
		if in.RequestTimeoutSeconds == 0 {
			in.RequestTimeoutSeconds = 30
		}
	}
	if strings.TrimSpace(in.BaseURL) == "" {
		in.BaseURL = current.BaseURL
	}
	if strings.TrimSpace(in.CollectionID) == "" {
		in.CollectionID = current.CollectionID
	}
	if in.CollectionID == "-" {
		in.CollectionID = ""
	}
	if in.VirtualizationParentDocumentID == "" && current.VirtualizationParentDocumentID != "" {
		in.VirtualizationParentDocumentID = current.VirtualizationParentDocumentID
	}
	if in.VirtualizationParentDocumentID == "-" {
		in.VirtualizationParentDocumentID = ""
	}
	if err := normalizeSettings(&in); err != nil {
		return Settings{}, err
	}

	secretRef := current.SecretRef
	ciphertext := ""
	plainKey := strings.TrimSpace(in.APIKey)
	if current.Cipher.Valid {
		ciphertext = current.Cipher.String
	}
	if plainKey != "" {
		if secretRef == "" {
			secretRef, err = cryptox.RandomToken(24)
			if err != nil {
				return Settings{}, err
			}
		}
		ciphertext, err = s.Box.Encrypt([]byte(plainKey), secretAADPrefix+secretRef)
		if err != nil {
			return Settings{}, err
		}
	}
	if *in.Enabled && strings.TrimSpace(ciphertext) == "" {
		return Settings{}, errors.New("Outline API key is required when integration is enabled")
	}
	if *in.Enabled && plainKey == "" {
		plain, decryptErr := s.Box.Decrypt(ciphertext, secretAADPrefix+secretRef)
		if decryptErr != nil {
			return Settings{}, fmt.Errorf("decrypt Outline API key: %w", decryptErr)
		}
		plainKey = strings.TrimSpace(string(plain))
	}
	if *in.Enabled && in.VirtualizationParentDocumentID != "" && !looksLikeUUID(in.VirtualizationParentDocumentID) {
		probe := settingsRecord{Settings: Settings{
			Enabled: true, BaseURL: strings.TrimRight(in.BaseURL, "/"), CollectionID: in.CollectionID,
			VirtualizationParentDocumentID: in.VirtualizationParentDocumentID, VerifyTLS: *in.VerifyTLS, AllowHTTP: *in.AllowHTTP,
			RequestTimeoutSeconds: in.RequestTimeoutSeconds,
		}}
		resolved, resolveErr := s.resolveDocumentWithRuntime(ctx, probe, plainKey, in.VirtualizationParentDocumentID)
		if resolveErr != nil {
			return Settings{}, fmt.Errorf("resolve Outline Virtualizare document: %w", resolveErr)
		}
		in.VirtualizationParentDocumentID = resolved.ID
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return Settings{}, err
	}
	defer tx.Rollback()
	if _, err = tx.ExecContext(ctx, `UPDATE outline_settings SET enabled=?,base_url=?,collection_id=?,api_key_secret_ref=?,api_key_ciphertext=?,verify_tls=?,allow_http=?,request_timeout_seconds=?,updated_by=? WHERE id=1`,
		*in.Enabled, strings.TrimRight(in.BaseURL, "/"), in.CollectionID, secretRef, nullableCipher(ciphertext), *in.VerifyTLS, *in.AllowHTTP, in.RequestTimeoutSeconds, userID,
	); err != nil {
		return Settings{}, err
	}
	if _, err = tx.ExecContext(ctx, `INSERT INTO outline_targets(target_code,target_name,parent_document_id,active,created_by,updated_by)
		VALUES('virtualization','Virtualizare',?,1,?,?)
		ON DUPLICATE KEY UPDATE target_name='Virtualizare',parent_document_id=VALUES(parent_document_id),active=1,updated_by=VALUES(updated_by)`, in.VirtualizationParentDocumentID, userID, userID); err != nil {
		return Settings{}, err
	}
	if err = tx.Commit(); err != nil {
		return Settings{}, err
	}
	return s.GetSettings(ctx)
}

func (s *Service) ListPublicationTargets(ctx context.Context) ([]PublicationTarget, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT target_code,target_name,document_reference,document_id,document_url,active,last_published_at,updated_at,content_hash
		FROM outline_publication_targets ORDER BY target_name,target_code`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]PublicationTarget, 0)
	for rows.Next() {
		var item PublicationTarget
		var published sql.NullTime
		if err := rows.Scan(&item.Code, &item.Name, &item.DocumentReference, &item.DocumentID, &item.DocumentURL, &item.Active, &published, &item.UpdatedAt, &item.contentHash); err != nil {
			return nil, err
		}
		if published.Valid {
			value := published.Time
			item.LastPublishedAt = &value
		}
		out = append(out, item)
	}
	return out, rows.Err()
}

func (s *Service) GetPublicationTarget(ctx context.Context, code string) (PublicationTarget, error) {
	code = strings.ToLower(strings.TrimSpace(code))
	var item PublicationTarget
	var published sql.NullTime
	err := s.DB.QueryRowContext(ctx, `SELECT target_code,target_name,document_reference,document_id,document_url,active,last_published_at,updated_at,content_hash
		FROM outline_publication_targets WHERE target_code=?`, code).Scan(&item.Code, &item.Name, &item.DocumentReference, &item.DocumentID, &item.DocumentURL, &item.Active, &published, &item.UpdatedAt, &item.contentHash)
	if published.Valid {
		value := published.Time
		item.LastPublishedAt = &value
	}
	return item, err
}

func (s *Service) UpdatePublicationTarget(ctx context.Context, userID int64, code string, in PublicationTargetInput) (PublicationTarget, error) {
	code = strings.ToLower(strings.TrimSpace(code))
	if !validTargetCode(code) {
		return PublicationTarget{}, errors.New("invalid Outline publication target code")
	}
	name := strings.TrimSpace(in.Name)
	if name == "" {
		name = code
	}
	reference := strings.TrimSpace(in.DocumentReference)
	active := true
	if in.Active != nil {
		active = *in.Active
	}
	documentID, documentURL := "", ""
	if reference != "" {
		resolved, err := s.ResolveDocument(ctx, reference)
		if err != nil {
			return PublicationTarget{}, fmt.Errorf("resolve Outline publication target: %w", err)
		}
		documentID = resolved.ID
		documentURL = resolved.URL
	}
	_, err := s.DB.ExecContext(ctx, `INSERT INTO outline_publication_targets(target_code,target_name,document_reference,document_id,document_url,active,created_by,updated_by)
		VALUES(?,?,?,?,?,?,?,?)
		ON DUPLICATE KEY UPDATE target_name=VALUES(target_name),document_reference=VALUES(document_reference),document_id=VALUES(document_id),document_url=VALUES(document_url),active=VALUES(active),updated_by=VALUES(updated_by)`,
		code, name, reference, documentID, documentURL, active, userID, userID)
	if err != nil {
		return PublicationTarget{}, err
	}
	return s.GetPublicationTarget(ctx, code)
}

func (s *Service) PublishTargetDocument(ctx context.Context, code string, markdown []byte) (PublishResult, error) {
	record, key, err := s.runtime(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	target, err := s.GetPublicationTarget(ctx, code)
	if err != nil {
		return PublishResult{}, err
	}
	if !target.Active {
		return PublishResult{}, errors.New("Outline publication target is disabled")
	}
	if strings.TrimSpace(target.DocumentReference) == "" {
		return PublishResult{}, errors.New("Outline publication target document is not configured")
	}
	resolved, err := s.resolveDocumentWithRuntime(ctx, record, key, target.DocumentReference)
	if err != nil {
		return PublishResult{}, fmt.Errorf("resolve Outline publication target: %w", err)
	}
	hash := documentHash(resolved.Title, markdown)
	changed := target.DocumentID != resolved.ID || target.ContentHashForCompare() != hash
	if changed {
		var env apiEnvelope[apiDocument]
		if err := s.call(ctx, record, key, "documents.update", map[string]any{"id": resolved.ID, "text": string(markdown)}, &env); err != nil {
			return PublishResult{}, err
		}
		if env.Data.ID != "" {
			resolved.ID = env.Data.ID
		}
		if env.Data.URL != "" {
			resolved.URL = absoluteDocumentURL(record.BaseURL, env.Data.URL)
		}
		if env.Data.Title != "" {
			resolved.Title = env.Data.Title
		}
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE outline_publication_targets SET document_id=?,document_url=?,content_hash=?,last_published_at=NOW(6) WHERE target_code=?`, resolved.ID, resolved.URL, hash, target.Code)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "publication_target", TargetCode: target.Code, DocumentID: resolved.ID, URL: absoluteDocumentURL(record.BaseURL, resolved.URL), Changed: changed, Title: resolved.Title}, nil
}

// UpsertSoftwareComponentDocument creează sau actualizează o pagină copil pentru
// o componentă software sub destinația Outline configurată. Păstrăm maparea local
// ca publicările repetate să actualizeze aceeași pagină, fără duplicate.
func (s *Service) UpsertSoftwareComponentDocument(ctx context.Context, targetCode, componentKey, title string, markdown []byte) (PublishResult, error) {
	record, key, err := s.runtime(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	targetCode = strings.ToLower(strings.TrimSpace(targetCode))
	componentKey = strings.ToLower(strings.TrimSpace(componentKey))
	if !validTargetCode(targetCode) || !validTargetCode(componentKey) {
		return PublishResult{}, errors.New("invalid Outline software component target/key")
	}
	target, err := s.GetPublicationTarget(ctx, targetCode)
	if err != nil {
		return PublishResult{}, err
	}
	if !target.Active {
		return PublishResult{}, errors.New("Outline publication target is disabled")
	}
	if strings.TrimSpace(target.DocumentReference) == "" {
		return PublishResult{}, errors.New("Outline publication target parent document is not configured")
	}
	parent, err := s.resolveDocumentWithRuntime(ctx, record, key, target.DocumentReference)
	if err != nil {
		return PublishResult{}, fmt.Errorf("resolve Outline software components parent: %w", err)
	}
	parentDocumentID := strings.TrimSpace(parent.ID)
	if parentDocumentID == "" {
		return PublishResult{}, errors.New("Outline software components parent document id is empty")
	}

	title = cleanTitle(title)
	hash := documentHash(title, markdown)
	var documentID, documentURL, storedParentDocumentID, currentHash string
	err = s.DB.QueryRowContext(ctx, `SELECT document_id,document_url,parent_document_id,content_hash FROM outline_software_component_documents WHERE component_key=?`, componentKey).Scan(&documentID, &documentURL, &storedParentDocumentID, &currentHash)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return PublishResult{}, err
	}
	created := false
	changed := currentHash != hash
	var doc apiDocument
	if documentID != "" {
		if strings.TrimSpace(storedParentDocumentID) != parentDocumentID {
			if err := s.call(ctx, record, key, "documents.move", map[string]any{"id": documentID, "parentDocumentId": parentDocumentID}, nil); err != nil {
				if !isNotFound(err) {
					return PublishResult{}, err
				}
				documentID = ""
			} else {
				changed = true
			}
		}
		if documentID != "" && currentHash == hash {
			var info apiEnvelope[apiDocument]
			if infoErr := s.call(ctx, record, key, "documents.info", map[string]any{"id": documentID}, &info); infoErr != nil {
				if !isNotFound(infoErr) {
					return PublishResult{}, infoErr
				}
				documentID = ""
				documentURL = ""
				changed = true
			} else {
				if info.Data.URL != "" {
					documentURL = info.Data.URL
				}
				_, err = s.DB.ExecContext(ctx, `UPDATE outline_software_component_documents SET component_name=?,document_url=?,parent_document_id=?,last_synced_at=NOW(6) WHERE component_key=?`, title, documentURL, parentDocumentID, componentKey)
				if err != nil {
					return PublishResult{}, err
				}
				return PublishResult{ObjectType: "software_component", TargetCode: targetCode, DocumentID: documentID, URL: absoluteDocumentURL(record.BaseURL, documentURL), Created: false, Changed: changed, Title: title}, nil
			}
		}
		if documentID != "" {
			var env apiEnvelope[apiDocument]
			err = s.call(ctx, record, key, "documents.update", map[string]any{"id": documentID, "title": title, "text": string(markdown)}, &env)
			if err == nil {
				doc = env.Data
			} else if !isNotFound(err) {
				return PublishResult{}, err
			} else {
				documentID = ""
			}
		}
	}
	if documentID == "" {
		var env apiEnvelope[apiDocument]
		if err := s.call(ctx, record, key, "documents.create", map[string]any{"title": title, "text": string(markdown), "parentDocumentId": parentDocumentID, "publish": true}, &env); err != nil {
			return PublishResult{}, err
		}
		doc = env.Data
		created = true
		changed = true
	}
	if doc.ID == "" {
		doc.ID = documentID
	}
	if doc.URL == "" {
		doc.URL = documentURL
	}
	_, err = s.DB.ExecContext(ctx, `INSERT INTO outline_software_component_documents(component_key,component_name,document_id,document_url,parent_document_id,content_hash,last_synced_at) VALUES(?,?,?,?,?,?,NOW(6)) ON DUPLICATE KEY UPDATE component_name=VALUES(component_name),document_id=VALUES(document_id),document_url=VALUES(document_url),parent_document_id=VALUES(parent_document_id),content_hash=VALUES(content_hash),last_synced_at=NOW(6)`, componentKey, title, doc.ID, doc.URL, parentDocumentID, hash)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "software_component", TargetCode: targetCode, DocumentID: doc.ID, URL: absoluteDocumentURL(record.BaseURL, doc.URL), Created: created, Changed: changed, Title: title}, nil
}

func (t PublicationTarget) ContentHashForCompare() string { return t.contentHash }

func validTargetCode(value string) bool {
	if value == "" || len(value) > 64 {
		return false
	}
	for _, r := range value {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '_' || r == '-' {
			continue
		}
		return false
	}
	return true
}

func nullableCipher(value string) any {
	if strings.TrimSpace(value) == "" {
		return nil
	}
	return value
}

func normalizeSettings(in *SettingsInput) error {
	in.BaseURL = strings.TrimRight(strings.TrimSpace(in.BaseURL), "/")
	in.CollectionID = strings.TrimSpace(in.CollectionID)
	in.VirtualizationParentDocumentID = strings.TrimSpace(in.VirtualizationParentDocumentID)
	if *in.Enabled || in.BaseURL != "" {
		u, err := url.Parse(in.BaseURL)
		if err != nil || u.Host == "" || (u.Scheme != "https" && u.Scheme != "http") {
			return errors.New("Outline base_url must be an absolute http/https URL")
		}
		if u.Scheme == "http" && !*in.AllowHTTP {
			return errors.New("Outline HTTP URL requires allow_http=true")
		}
	}
	if *in.Enabled && in.VirtualizationParentDocumentID == "" {
		return errors.New("Outline virtualization_parent_document_id is required")
	}
	if in.RequestTimeoutSeconds < 5 || in.RequestTimeoutSeconds > 300 {
		return errors.New("Outline request_timeout_seconds must be between 5 and 300")
	}
	return nil
}

func (s *Service) Test(ctx context.Context) (TestResult, error) {
	record, key, err := s.runtime(ctx)
	if err != nil {
		return TestResult{}, err
	}
	var doc apiEnvelope[apiDocument]
	if err := s.call(ctx, record, key, "documents.info", map[string]any{"id": record.VirtualizationParentDocumentID}, &doc); err != nil {
		return TestResult{}, err
	}
	result := TestResult{OK: true, ParentDocumentID: doc.Data.ID, ParentDocumentTitle: doc.Data.Title, BaseURL: record.BaseURL}
	if record.CollectionID != "" {
		var collection apiEnvelope[apiCollection]
		if err := s.call(ctx, record, key, "collections.info", map[string]any{"id": record.CollectionID}, &collection); err == nil {
			result.CollectionID = collection.Data.ID
			result.CollectionName = collection.Data.Name
		}
	}
	return result, nil
}

func (s *Service) runtime(ctx context.Context) (settingsRecord, string, error) {
	record, err := s.getRecord(ctx)
	if err != nil {
		return record, "", err
	}
	if !record.Enabled {
		return record, "", errors.New("Outline integration is disabled")
	}
	if !record.APIKeyConfigured {
		return record, "", errors.New("Outline API key is not configured")
	}
	plain, err := s.Box.Decrypt(record.Cipher.String, secretAADPrefix+record.SecretRef)
	if err != nil {
		return record, "", fmt.Errorf("decrypt Outline API key: %w", err)
	}
	return record, strings.TrimSpace(string(plain)), nil
}

func (s *Service) UpdateLinkedServiceDocument(ctx context.Context, serviceID int64, documentationURL string, markdown []byte) (PublishResult, error) {
	record, key, err := s.runtime(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	documentationURL = strings.TrimSpace(documentationURL)
	if documentationURL == "" {
		return PublishResult{}, errors.New("service Link documentație is not configured")
	}
	if !sameOutlineOrigin(record.BaseURL, documentationURL) {
		return PublishResult{}, errors.New("service Link documentație must point to the configured Outline instance")
	}
	resolved, err := s.resolveDocumentWithRuntime(ctx, record, key, documentationURL)
	if err != nil {
		return PublishResult{}, fmt.Errorf("resolve service Outline document: %w", err)
	}
	hash := documentHash(resolved.Title, markdown)
	var storedID, storedHash string
	err = s.DB.QueryRowContext(ctx, `SELECT document_id,content_hash FROM outline_service_documents WHERE internal_service_id=?`, serviceID).Scan(&storedID, &storedHash)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return PublishResult{}, err
	}
	changed := storedID != resolved.ID || storedHash != hash
	if changed {
		var env apiEnvelope[apiDocument]
		if err := s.call(ctx, record, key, "documents.update", map[string]any{"id": resolved.ID, "text": string(markdown)}, &env); err != nil {
			return PublishResult{}, err
		}
		if env.Data.ID != "" {
			resolved.ID = env.Data.ID
		}
		if env.Data.URL != "" {
			resolved.URL = env.Data.URL
		}
		if env.Data.Title != "" {
			resolved.Title = env.Data.Title
		}
	}
	_, err = s.DB.ExecContext(ctx, `INSERT INTO outline_service_documents(internal_service_id,document_id,document_url,content_hash,last_synced_at) VALUES(?,?,?,?,NOW(6)) ON DUPLICATE KEY UPDATE document_id=VALUES(document_id),document_url=VALUES(document_url),content_hash=VALUES(content_hash),last_synced_at=NOW(6)`, serviceID, resolved.ID, resolved.URL, hash)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "service", ObjectID: serviceID, ServiceID: serviceID, DocumentID: resolved.ID, URL: absoluteDocumentURL(record.BaseURL, resolved.URL), Created: false, Changed: changed, Title: resolved.Title}, nil
}

// UpsertServiceDocument remains for source compatibility; service pages are never created by VM-DOC anymore.
func (s *Service) UpsertServiceDocument(ctx context.Context, serviceID int64, title string, markdown []byte) (PublishResult, error) {
	var documentationURL string
	if err := s.DB.QueryRowContext(ctx, `SELECT documentation_url FROM internal_services WHERE id=?`, serviceID).Scan(&documentationURL); err != nil {
		return PublishResult{}, err
	}
	return s.UpdateLinkedServiceDocument(ctx, serviceID, documentationURL, markdown)
}

func (s *Service) UpsertVMDocument(ctx context.Context, vmID int64, title string, markdown []byte) (PublishResult, error) {
	record, key, err := s.runtime(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	parentDocumentID := strings.TrimSpace(record.VirtualizationParentDocumentID)
	if parentDocumentID == "" {
		return PublishResult{}, errors.New("Outline Virtualizare parent document is not configured")
	}
	title = cleanTitle(title)
	hash := documentHash(title, markdown)
	var documentID, documentURL, storedParentDocumentID, currentHash string
	err = s.DB.QueryRowContext(ctx, `SELECT document_id,document_url,parent_document_id,content_hash FROM outline_vm_documents_global WHERE vm_id=? AND target_code='virtualization'`, vmID).Scan(&documentID, &documentURL, &storedParentDocumentID, &currentHash)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return PublishResult{}, err
	}
	created := false
	changed := currentHash != hash
	var doc apiDocument
	if documentID != "" {
		if strings.TrimSpace(storedParentDocumentID) != parentDocumentID {
			if err := s.call(ctx, record, key, "documents.move", map[string]any{"id": documentID, "parentDocumentId": parentDocumentID}, nil); err != nil {
				if !isNotFound(err) {
					return PublishResult{}, err
				}
				documentID = ""
			} else {
				changed = true
			}
		}
		if documentID != "" && currentHash == hash {
			var info apiEnvelope[apiDocument]
			if infoErr := s.call(ctx, record, key, "documents.info", map[string]any{"id": documentID}, &info); infoErr != nil {
				if !isNotFound(infoErr) {
					return PublishResult{}, infoErr
				}
				documentID = ""
				documentURL = ""
				changed = true
			} else {
				if info.Data.URL != "" {
					documentURL = info.Data.URL
				}
				_, err = s.DB.ExecContext(ctx, `UPDATE outline_vm_documents_global SET document_url=?,parent_document_id=?,last_synced_at=NOW(6) WHERE vm_id=? AND target_code='virtualization'`, documentURL, parentDocumentID, vmID)
				if err != nil {
					return PublishResult{}, err
				}
				return PublishResult{ObjectType: "vm", ObjectID: vmID, DocumentID: documentID, URL: absoluteDocumentURL(record.BaseURL, documentURL), Created: false, Changed: changed, Title: title}, nil
			}
		}
		if documentID != "" {
			var env apiEnvelope[apiDocument]
			err = s.call(ctx, record, key, "documents.update", map[string]any{"id": documentID, "title": title, "text": string(markdown)}, &env)
			if err == nil {
				doc = env.Data
			} else if !isNotFound(err) {
				return PublishResult{}, err
			} else {
				documentID = ""
			}
		}
	}
	if documentID == "" {
		var env apiEnvelope[apiDocument]
		if err := s.call(ctx, record, key, "documents.create", map[string]any{"title": title, "text": string(markdown), "parentDocumentId": parentDocumentID, "publish": true}, &env); err != nil {
			return PublishResult{}, err
		}
		doc = env.Data
		created = true
		changed = true
	}
	if doc.ID == "" {
		doc.ID = documentID
	}
	if doc.URL == "" {
		doc.URL = documentURL
	}
	_, err = s.DB.ExecContext(ctx, `INSERT INTO outline_vm_documents_global(vm_id,target_code,document_id,document_url,parent_document_id,content_hash,last_synced_at) VALUES(?,'virtualization',?,?,?,?,NOW(6)) ON DUPLICATE KEY UPDATE document_id=VALUES(document_id),document_url=VALUES(document_url),parent_document_id=VALUES(parent_document_id),content_hash=VALUES(content_hash),last_synced_at=NOW(6)`, vmID, doc.ID, doc.URL, parentDocumentID, hash)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "vm", ObjectID: vmID, DocumentID: doc.ID, URL: absoluteDocumentURL(record.BaseURL, doc.URL), Created: created, Changed: changed, Title: title}, nil
}

func (s *Service) ServiceDocumentID(ctx context.Context, serviceID int64) (string, error) {
	var id string
	err := s.DB.QueryRowContext(ctx, `SELECT document_id FROM outline_service_documents WHERE internal_service_id=?`, serviceID).Scan(&id)
	return id, err
}

func (s *Service) ServiceMapping(ctx context.Context, serviceID int64) (PublishResult, error) {
	var id, path string
	err := s.DB.QueryRowContext(ctx, `SELECT document_id,document_url FROM outline_service_documents WHERE internal_service_id=?`, serviceID).Scan(&id, &path)
	if err != nil {
		return PublishResult{}, err
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "service", ObjectID: serviceID, ServiceID: serviceID, DocumentID: id, URL: absoluteDocumentURL(settings.BaseURL, path)}, nil
}

func (s *Service) VMMapping(ctx context.Context, vmID int64) (PublishResult, error) {
	var id, path string
	err := s.DB.QueryRowContext(ctx, `SELECT document_id,document_url FROM outline_vm_documents_global WHERE vm_id=? AND target_code='virtualization'`, vmID).Scan(&id, &path)
	if err != nil {
		return PublishResult{}, err
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "vm", ObjectID: vmID, DocumentID: id, URL: absoluteDocumentURL(settings.BaseURL, path)}, nil
}

func (s *Service) ResolveDocument(ctx context.Context, reference string) (ResolvedDocument, error) {
	record, key, err := s.runtime(ctx)
	if err != nil {
		return ResolvedDocument{}, err
	}
	return s.resolveDocumentWithRuntime(ctx, record, key, reference)
}

func (s *Service) resolveDocumentWithRuntime(ctx context.Context, record settingsRecord, key, reference string) (ResolvedDocument, error) {
	candidates, err := documentReferenceCandidates(record.BaseURL, reference)
	if err != nil {
		return ResolvedDocument{}, err
	}
	var last error
	for _, candidate := range candidates {
		var env apiEnvelope[apiDocument]
		if err := s.call(ctx, record, key, "documents.info", map[string]any{"id": candidate}, &env); err != nil {
			last = err
			if isNotFound(err) {
				continue
			}
			return ResolvedDocument{}, err
		}
		if strings.TrimSpace(env.Data.ID) == "" {
			last = errors.New("Outline documents.info returned an empty document id")
			continue
		}
		return ResolvedDocument{ID: env.Data.ID, URL: absoluteDocumentURL(record.BaseURL, env.Data.URL), Title: env.Data.Title}, nil
	}
	if last == nil {
		last = errors.New("Outline document reference is empty")
	}
	return ResolvedDocument{}, last
}

func (s *Service) VMURLs(ctx context.Context, vmIDs []int64) (map[int64]string, error) {
	result := map[int64]string{}
	if len(vmIDs) == 0 {
		return result, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return nil, err
	}
	query, args := inQuery(`SELECT m.vm_id,m.document_url FROM outline_vm_documents_global m JOIN virtual_machines vm ON vm.id=m.vm_id WHERE m.target_code='virtualization' AND vm.outline_documentation_disabled=0 AND m.vm_id IN (%s)`, vmIDs)
	rows, err := s.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		var path string
		if err := rows.Scan(&id, &path); err != nil {
			return nil, err
		}
		if value := absoluteDocumentURL(settings.BaseURL, path); value != "" {
			result[id] = value
		}
	}
	return result, rows.Err()
}

func (s *Service) ServiceOutlineURLs(ctx context.Context, serviceIDs []int64) (map[int64]string, error) {
	result := map[int64]string{}
	if len(serviceIDs) == 0 {
		return result, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return nil, err
	}
	query, args := inQuery(`SELECT id,documentation_url FROM internal_services WHERE retired=0 AND outline_documentation_disabled=0 AND id IN (%s)`, serviceIDs)
	rows, err := s.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		var value string
		if err := rows.Scan(&id, &value); err != nil {
			return nil, err
		}
		if sameOutlineOrigin(settings.BaseURL, value) {
			result[id] = strings.TrimSpace(value)
		}
	}
	return result, rows.Err()
}

func RemoteErrorDetails(err error) (int, string, bool) {
	var remote *remoteError
	if !errors.As(err, &remote) {
		return 0, "", false
	}
	return remote.StatusCode, remote.Message, true
}

func documentReferenceCandidates(baseURL, reference string) ([]string, error) {
	reference = strings.TrimSpace(reference)
	if reference == "" {
		return nil, errors.New("Outline document reference is required")
	}
	values := []string{}
	add := func(value string) {
		value = strings.Trim(strings.TrimSpace(value), "/")
		if value == "" {
			return
		}
		for _, existing := range values {
			if existing == value {
				return
			}
		}
		values = append(values, value)
	}
	if parsed, err := url.Parse(reference); err == nil && parsed.IsAbs() {
		if !sameOutlineOrigin(baseURL, reference) {
			return nil, errors.New("Outline document URL belongs to another Outline instance")
		}
		segment := strings.Trim(pathLast(parsed.Path), "/")
		add(segment)
		if idx := strings.LastIndex(segment, "-"); idx >= 0 && idx+1 < len(segment) {
			add(segment[idx+1:])
		}
	} else {
		add(reference)
		segment := pathLast(reference)
		add(segment)
		if idx := strings.LastIndex(segment, "-"); idx >= 0 && idx+1 < len(segment) {
			add(segment[idx+1:])
		}
	}
	if len(values) == 0 {
		return nil, errors.New("Outline document reference is required")
	}
	return values, nil
}

func sameOutlineOrigin(baseURL, candidate string) bool {
	baseURL = strings.TrimSpace(baseURL)
	candidate = strings.TrimSpace(candidate)
	if baseURL == "" || candidate == "" {
		return false
	}
	base, err1 := url.Parse(baseURL)
	value, err2 := url.Parse(candidate)
	if err1 != nil || err2 != nil || !base.IsAbs() || !value.IsAbs() {
		return false
	}
	return strings.EqualFold(base.Scheme, value.Scheme) && strings.EqualFold(base.Host, value.Host)
}

func looksLikeUUID(value string) bool {
	value = strings.TrimSpace(value)
	if len(value) != 36 {
		return false
	}
	for index, r := range value {
		if index == 8 || index == 13 || index == 18 || index == 23 {
			if r != '-' {
				return false
			}
			continue
		}
		if !((r >= '0' && r <= '9') || (r >= 'a' && r <= 'f') || (r >= 'A' && r <= 'F')) {
			return false
		}
	}
	return true
}

func pathLast(value string) string {
	value = strings.TrimRight(value, "/")
	if idx := strings.LastIndex(value, "/"); idx >= 0 {
		return value[idx+1:]
	}
	return value
}

func inQuery(format string, ids []int64) (string, []any) {
	placeholders := make([]string, 0, len(ids))
	args := make([]any, 0, len(ids))
	seen := map[int64]bool{}
	for _, id := range ids {
		if id <= 0 || seen[id] {
			continue
		}
		seen[id] = true
		placeholders = append(placeholders, "?")
		args = append(args, id)
	}
	if len(placeholders) == 0 {
		return fmt.Sprintf(format, "NULL"), args
	}
	return fmt.Sprintf(format, strings.Join(placeholders, ",")), args
}

func (s *Service) call(ctx context.Context, settings settingsRecord, apiKey, method string, payload any, out any) error {
	body, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	endpoint := strings.TrimRight(settings.BaseURL, "/") + "/api/" + method
	transport := &http.Transport{TLSClientConfig: &tls.Config{MinVersion: tls.VersionTLS12, InsecureSkipVerify: !settings.VerifyTLS}} // #nosec G402 - explicit administrator-controlled compatibility option.
	client := &http.Client{Timeout: time.Duration(settings.RequestTimeoutSeconds) * time.Second, Transport: transport}
	var last error
	for attempt := 0; attempt < 3; attempt++ {
		req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(body))
		if err != nil {
			return err
		}
		req.Header.Set("Authorization", "Bearer "+apiKey)
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("Accept", "application/json")
		resp, err := client.Do(req)
		if err != nil {
			return fmt.Errorf("Outline %s: %w", method, err)
		}
		data, readErr := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
		resp.Body.Close()
		if readErr != nil {
			return fmt.Errorf("Outline %s response: %w", method, readErr)
		}
		if resp.StatusCode >= 200 && resp.StatusCode < 300 {
			if out == nil || len(data) == 0 {
				return nil
			}
			if err := json.Unmarshal(data, out); err != nil {
				return fmt.Errorf("Outline %s invalid response: %w", method, err)
			}
			return nil
		}
		var apiErr apiErrorEnvelope
		_ = json.Unmarshal(data, &apiErr)
		message := strings.TrimSpace(firstNonEmpty(apiErr.Message, apiErr.Error, string(data)))
		if message == "" {
			message = http.StatusText(resp.StatusCode)
		}
		last = &remoteError{StatusCode: resp.StatusCode, Message: "Outline " + method + ": " + message}
		if resp.StatusCode != http.StatusTooManyRequests || attempt == 2 {
			return last
		}
		wait := time.Second * time.Duration(attempt+1)
		if raw := resp.Header.Get("Retry-After"); raw != "" {
			if sec, convErr := strconv.Atoi(raw); convErr == nil && sec > 0 && sec <= 30 {
				wait = time.Duration(sec) * time.Second
			}
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(wait):
		}
	}
	return last
}

func isNotFound(err error) bool {
	var remote *remoteError
	return errors.As(err, &remote) && remote.StatusCode == http.StatusNotFound
}

func documentHash(title string, markdown []byte) string {
	sum := sha256.Sum256(append([]byte(title+"\n"), markdown...))
	return hex.EncodeToString(sum[:])
}

func cleanTitle(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "VM-DOC"
	}
	runes := []rune(value)
	if len(runes) > 100 {
		value = string(runes[:100])
	}
	return value
}

func absoluteDocumentURL(baseURL, path string) string {
	path = strings.TrimSpace(path)
	if path == "" {
		return ""
	}
	if u, err := url.Parse(path); err == nil && u.IsAbs() {
		return path
	}
	return strings.TrimRight(baseURL, "/") + "/" + strings.TrimLeft(path, "/")
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}
