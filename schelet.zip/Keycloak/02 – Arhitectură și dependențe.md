# 02 – Arhitectură și dependențe

> Arhitectură logică, diagramă și dependențe. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Rezumat arhitectural
[Descrie fluxul browser → reverse proxy → Keycloak → AD/LDAP și componenta DB.]

## Diagrama
[Inserează diagramă sau link către diagramă.]

## Componente și dependențe
- **Instanțe și medii:** [Link către VM-DOC]
- **Identity source:** [AD / LDAP și descriere integrare]
- **Bază de date:** [Referință serviciu / link]
- **Reverse proxy / TLS:** [Referință serviciu / link]
- **DNS / certificate:** [Linkuri relevante]
- **Dependențe și impact:** [Link GLPI / VM-DOC – sursa de adevăr]

## Fluxuri critice
[SSO OIDC / SAML / Kerberos, la nivel conceptual.]
