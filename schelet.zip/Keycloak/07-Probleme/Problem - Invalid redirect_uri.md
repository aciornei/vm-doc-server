# Problemă cunoscută – Invalid redirect_uri

## Simptome
[Mesaj complet, impact și aplicații afectate]
## Cauză
[Explicație verificată]
## Diagnostic
1. [Compară redirect_uri primit cu configurația permisă]
2. [Verifică URL și reverse proxy]
## Remediere / workaround
[Pași validați sau trimitere la runbook]
## Referințe
[Tichete, change-uri, versiuni]
## Ultima validare
[AAAA-LL-ZZ]
