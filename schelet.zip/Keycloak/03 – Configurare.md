# 03 – Configurare

> Configurația curentă a serviciului; detaliile în subpagini. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Scopul secțiunii
Conține configurația **curentă**, validată, fără secrete. Procedurile de schimbare sunt în 05 – Proceduri.

## Configurație de ansamblu
- **Versiune Keycloak:** [Versiunea în producție]
- **Realm(uri):** [Nume]
- **Metode de autentificare:** [OIDC / SAML / Kerberos / LDAP]
- **Loc configurație:** [URL repo / referință / document tehnic]

## Subdocumente
- Configurare realm AD
- Integrare AD / Kerberos
- Integrare Grafana OIDC
- Mapperi și client scopes

## Reguli
Documentează aici ce este activ. Nu include parole, client secrets sau chei private.
