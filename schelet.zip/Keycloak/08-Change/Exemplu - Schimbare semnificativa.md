# Change – [Identificator și titlu]

- **Dată:** [AAAA-LL-ZZ]
- **Referință Huly:** [URL]
- **Versiune afectată:** [x.y]
- **Aprobare:** [referință]

## Motiv
[De ce a fost necesară schimbarea]
## Ce s-a modificat
[Rezumat tehnic]
## Impact / risc
[Ce servicii pot fi afectate; relațiile oficiale sunt în CMDB]
## Validare și rollback
[Rezultate și link la procedură]
