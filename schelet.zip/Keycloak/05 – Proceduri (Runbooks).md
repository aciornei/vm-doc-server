# 05 – Proceduri (Runbooks)

> Proceduri pas cu pas, cu verificare și rollback. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Scop
Proceduri operaționale care pot fi executate repetabil de către un administrator autorizat.

## Catalog proceduri
- Adăugare client OIDC
- Upgrade Keycloak
- Înlocuire certificat
- Restaurare serviciu

## Cerințe pentru fiecare runbook
1. Scop și situații de utilizare
2. Precondiții și aprobări
3. Riscuri și impact
4. Pași numerotați
5. Verificări de succes
6. Rollback
7. Referințe la change și responsabil
