# 09 – Securitate și continuitate

> Control acces, audit, backup și DR. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Controlul accesului
- **Administratori autorizați:** [Roluri/echipe]
- **Autentificare administrare:** [Politică MFA/SSO]
- **Audit și loguri:** [Link]
- **Politici aplicate:** [Link la standarde comune]

## Secrete și certificate
- **Locația secretelor:** [Referințe Vault; fără valori]
- **Gestionarea certificatelor:** [Procedură / responsabil]

## Continuitate
- **Backup:** [Politică + link sistem]
- **RTO / RPO:** [Valori aprobate]
- **Scenarii DR:** [Descriere]
- **Ultimul test restaurare:** [Dată + rezultat + link]
