# Runbook – Adăugare client OIDC

- **Responsabil:** [de completat]
- **Ultima validare:** [AAAA-LL-ZZ]
- **Impact:** [de completat]

## 1. Scop
[Ce se obține]
## 2. Precondiții
- [ ] Aprobare change / solicitare
- [ ] Redirect URI și domeniul confirmate
- [ ] Responsabil aplicație identificat
## 3. Pași
1. [Pasul 1]
2. [Pasul 2]
3. [Pasul 3]
## 4. Verificare
- [ ] Login testat
- [ ] Claims și roluri verificate
- [ ] Logout testat
## 5. Rollback
[Pași de revenire]
## 6. Referințe
[Tichet, configurație, aplicație]
