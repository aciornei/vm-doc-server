# Runbook – Upgrade Keycloak

## Scop și versiuni
- **De la:** [versiune]
- **La:** [versiune]
## Precondiții și aprobare
- [ ] Backup verificat
- [ ] Compatibilitate DB / provider verificată
- [ ] Fereastră de mentenanță aprobată
## Pași
1. [Backup / snapshot în condițiile politicii]
2. [Upgrade conform planului validat]
3. [Pornire și validări]
## Teste funcționale
- [ ] OIDC
- [ ] SAML, unde se folosește
- [ ] Kerberos / LDAP
## Rollback
[Procedură validată]
## Referință change
[URL Huly]
