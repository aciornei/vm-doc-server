# 01 – Fișa serviciului

> Scop, responsabil, criticitate, utilizatori și SLA. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Identificare
- **Cod serviciu:** SVC-IAM-001 (de confirmat)
- **Denumire:** Keycloak – Identity & SSO
- **Descriere și scop:** [Ce furnizează serviciul și cui]
- **Mediu:** [PROD / TEST / DEV]
- **Stare:** [Activ / În mentenanță / Retras]
- **Responsabil tehnic:** [Nume/echipă]
- **Proprietar serviciu:** [Nume/echipă]
- **Criticitate:** [Ridicată / Medie / Scăzută]
- **Program suport / SLA / RTO / RPO:** [De completat sau link către politica oficială]

## Utilizatori și consumatori
- **Categorii utilizatori:** [Angajați, administratori, aplicații]
- **Servicii consumatoare:** [Link spre registrul de relații GLPI / VM-DOC; nu duplicăm lista]

## Linkuri operaționale
- **GLPI / CMDB:** [URL]
- **VM-DOC (serviciu):** [URL]
- **Monitorizare:** [URL]
- **Backup / Veeam:** [URL]
- **Vault:** [Referință, fără parole]
- **Huly / proiect:** [URL]

## Responsabilitatea reviziei
- **Ultima verificare:** [AAAA-LL-ZZ]
- **Verificat de:** [Persoană]
- **Următoarea revizie:** [AAAA-LL-ZZ]
