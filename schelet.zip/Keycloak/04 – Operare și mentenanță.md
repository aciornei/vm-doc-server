# 04 – Operare și mentenanță

> Rutine, monitorizare și verificări. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Verificări operaționale
| Verificare | Frecvență | Instrument / link | Rezultat așteptat |
|---|---|---|---|
| Disponibilitate endpoint | [Zilnic] | [Grafana/Blackbox] | [OK] |
| Erori autentificare | [Zilnic] | [Loguri/Graylog] | [Fără creșteri anormale] |
| Certificate | [Săptămânal] | [Monitorizare] | [Fără expirări apropiate] |
| Backup | [Zilnic] | [Veeam] | [Job reușit] |

## Operare normală
- **Pornire / oprire:** [Referință runbook]
- **Locația logurilor:** [Referință sau URL]
- **Monitorizare:** [URL]
- **Mentenanță planificată:** [Interval / responsabil]
- **Escaladare:** [Persoane / echipe, fără date sensibile]
