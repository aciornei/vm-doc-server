# Keycloak – Identity & SSO

> Serviciu comun de autentificare. **Acesta este indexul serviciului**, nu registrul său de configurații.

**Responsabil:** [Echipă] · **Mediu:** [PROD] · **Stare:** [Activ] · **Ultima revizie:** [AAAA-LL-ZZ]

## Acces rapid
- **Fișa serviciului:** 01 – Fișa serviciului
- **Arhitectură:** 02 – Arhitectură și dependențe
- **Configurație curentă:** 03 – Configurare
- **Rutine și alerte:** 04 – Operare și mentenanță
- **Proceduri pas cu pas:** 05 – Proceduri (Runbooks)
- **Ghiduri:** 06 – Utilizare și administrare
- **Erori și soluții:** 07 – Incidente și probleme cunoscute
- **Schimbări:** 08 – Change & Release
- **Controale și DR:** 09 – Securitate și continuitate
- **Documentație veche:** 10 – Istoric și arhivă

## Surse de adevăr (completează linkurile)
| Informație | Unde se întreține | Link |
|---|---|---|
| VM-uri și componente | VM-DOC | [URL] |
| Inventar / relații servicii | GLPI / VM-DOC | [URL] |
| Issue / change | Huly | [URL] |
| Parole și tokenuri | Vault | [Referință] |
| Backup | Veeam | [URL] |
| Monitorizare | Grafana / Prometheus | [URL] |

## Reguli de documentare
- Nu copia secrete, parole, tokenuri sau chei private.
- Configurarea curentă este în secțiunea 03; procedurile de modificare sunt în 05.
- Problemele comune sunt rezumate în 07; tichetele rămân în sistemul de issue tracking.
- Fiecare document important are responsabil și dată de revizie.
