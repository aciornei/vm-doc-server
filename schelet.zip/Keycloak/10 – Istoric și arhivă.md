# 10 – Istoric și arhivă

> Documente înlocuite, cu marcajul de neutilizare. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Reguli arhivare
Documentele păstrate aici au valoare istorică, dar **nu sunt instrucțiuni valabile pentru producție**.

## Evidență
| Document | Perioada de valabilitate | Înlocuit de | Motivul arhivării |
|---|---|---|---|
| [Titlu] | [Perioadă] | [Link] | [Motiv] |

> Atenție: nu restaura configurații sau executa comenzi din arhivă fără validare.
