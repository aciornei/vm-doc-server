# 08 – Change & Release

> Istoricul schimbărilor semnificative și versiunile. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Stare curentă
- **Versiune în PROD:** [x.y.z]
- **Data ultimei schimbări:** [AAAA-LL-ZZ]
- **Sursa oficială a change-urilor:** [Huly / alt sistem]

## Schimbări semnificative
| Data | Change | Rezumat | Impact | Link tichet |
|---|---|---|---|---|
| [AAAA-LL-ZZ] | [CHG-...] | [Ce s-a schimbat] | [Impact] | [URL] |

## Reguli
Nu duplica întregul tichet. Păstrează aici doar decizia tehnică, impactul, pașii de validare și legătura către change.
