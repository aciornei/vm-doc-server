# 07 – Incidente și probleme cunoscute

> Simptome, cauze, diagnostic și soluții reutilizabile. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Cum folosim această secțiune
Aici păstrăm **articole reutilizabile**, nu câte o copie a fiecărui incident. Tichetele rămân în sistemul operațional.

## Index probleme
- Invalid parameter: redirect_uri
- Eroare Kerberos / SPNEGO
- Eroare de sincronizare utilizator

## Diagnostic rapid
- **Stare serviciu:** [Link]
- **Loguri:** [Link]
- **Validare certificat:** [Pași / link]
- **Escaladare:** [Echipă]
