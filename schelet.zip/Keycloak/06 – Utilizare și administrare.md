# 06 – Utilizare și administrare

> Instrucțiuni și operații administrative. **Responsabil:** [de completat] · **Ultima revizie:** [AAAA-LL-ZZ]

## Pentru administratori
- [Cum se accesează consola de administrare]
- [Cum se investighează o autentificare nereușită]
- [Cum se verifică un client / utilizator / grup]

## Pentru utilizatori
- [Autentificare în aplicații]
- [Resetare parolă – trimitere către procedura AD, dacă este cazul]
- [Probleme frecvente și canal de suport]

## Acces și roluri
[Descrie rolurile autorizate, fără date de acces.]
