# Integrare Grafana OIDC

## Delimitarea responsabilităților
**Aici:** configurarea clientului din Keycloak. **În Grafana:** `grafana.ini`, roluri și organizații.

## Configurare Keycloak
- Realm: [de completat]
- Client ID: [de completat]
- Redirect URI: [de completat]
- Scopes / claims / mapperi: [de completat]
- Logout: [de completat]
- Secret: [doar referință Vault]

## Linkuri
- Document Grafana → Configurare → Autentificare: [URL]
- GLPI / VM-DOC relație: [URL]
