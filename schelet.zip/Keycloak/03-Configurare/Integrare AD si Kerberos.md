# Integrare AD și Kerberos

## Flux de autentificare
[Diagramă / descriere SPNEGO]
## Configurație curentă
- Domeniu/realm: [de completat]
- SPN: [referință, fără parole/keytab]
- Federation mapperi: [de completat]
## Verificare
[Cum se verifică fără modificări]
## Trimiteri
[Procedură de schimbare / problemă cunoscută]
