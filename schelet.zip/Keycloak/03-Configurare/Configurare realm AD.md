# Configurare realm AD

## Scop
[Descriere]
## Setări active
| Parametru | Valoare sau referință |
|---|---|
| Realm | AD |
| Federation | [Referință LDAP/AD] |
| Flux autentificare | [Descriere] |
## Verificări
[Pași siguri de citire / validare]
## Linkuri
[Referințe]
