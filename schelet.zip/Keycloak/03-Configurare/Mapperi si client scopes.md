# Mapperi și client scopes

## Scope-uri reutilizate
| Scope | Claim transmis | Consumatori / referință |
|---|---|---|
| [Nume] | [Claim] | [Link] |

## Reguli de modificare
[Validări necesare și link la procedura de change]
