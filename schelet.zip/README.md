# Schelet Outline – Keycloak

Acesta este un pachet de **Markdown** pentru construirea structurii unui serviciu în Outline.

- `Keycloak/00 – Keycloak – Identity & SSO.md` este pagina principală (index).
- Cele 10 fișiere `01 – ...md` până la `10 – ...md` sunt paginile-părinte.
- Folderele `03-Configurare`, `05-Proceduri`, `07-Probleme`, `08-Change` conțin **exemple de subpagini**, care trebuie mutate ca subdocumente ale secțiunii potrivite.
- Înlocuiește `[de completat]` și `[URL]` cu informațiile reale.
- Nicio parolă/token nu trebuie introdusă în wiki.

## Import
Documentația oficială Outline permite importul de fișiere Markdown în colecții și import de documente sub pagini. În funcție de versiunea instanței, importul unei arhive cu foldere **nu este garantat** să reconstruiască automat exact arborele dorit. Verifică rezultatul într-o colecție de test și mută documentele ca subpagini dacă este necesar.

Pentru un singur document de pornire folosește `Schelet_Outline_Keycloak_un_singur_MD.md`.
