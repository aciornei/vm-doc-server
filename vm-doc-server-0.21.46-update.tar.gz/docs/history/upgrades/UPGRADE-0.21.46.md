# VM-DOC Server 0.21.45 → 0.21.46

Acest upgrade este exclusiv **frontend / metadate**. Fără migrare SQL, schimbare API, backend Go sau agent (1.7.18 rămâne compatibil).

1. Salvează binarul și întregul arbore al surselor 0.21.45, inclusiv configurații și `vendor/`.
2. Intră în directorul surselor 0.21.45 și folosește **o singură metodă**:

   ```bash
   tar -xzf /cale/vm-doc-server-0.21.46-update.tar.gz
   # SAU, pentru arbore nemodificat de la 0.21.45:
   git apply /cale/vm-doc-server-0.21.45-to-0.21.46.patch
   ```

3. Verifică `cat VERSION` = `0.21.46` și `bash scripts/cleanup-source-tree.sh --check`.
4. Pentru mediul offline cu dependențe disponibile:

   ```bash
   GOPROXY=off GOSUMDB=off go test ./...
   GOPROXY=off GOSUMDB=off make build
   ```

5. În staging verifică Harta rețea la 1595 / 1366 / 1024 / 390 px, un VM cu multe porturi, un serviciu cu mai multe VM-uri și fluxuri FortiGate cu multe adrese/servicii; export SVG și săgețile din panouri.
6. După validare, instalează noul binar, repornește serviciul și reîncarcă pagina cu hard refresh (asset-uri versiunea 0.21.46).

**Rollback:** restaurează sursele și binarul 0.21.45, recompilează din sursele originale după caz și repornește serviciul. Nu există rollback SQL.

**Limite de validare:** Chromium numai cu date simulate; build Go complet cu vendor și integrare MariaDB nu au fost executate aici.
