# Upgrade vm-doc-server 0.13.4 -> 0.13.5

Versiunea 0.13.5 este un update exclusiv de interfață pentru un layout fluid și responsive.

## Ce se schimbă

- conținutul nu mai este limitat la 1600 px și folosește toată lățimea disponibilă;
- padding-ul și spațierea se adaptează automat la dimensiunea viewport-ului;
- panourile, tabelele, filtrele și toolbar-urile rămân în viewport la redimensionare;
- dialogurile sunt limitate la înălțimea/lățimea ecranului;
- comportamentul pentru tabletă și mobil este îmbunătățit.

## Baza de date

Nu există migrare MariaDB nouă.

## Upgrade cu pachetul update

Din rădăcina instalării 0.13.4:

```bash
sudo systemctl stop vm-doc-server vm-doc-collector
sudo tar -xzf vm-doc-server-0.13.5-update.tar.gz -C /opt/vm-doc-server
cd /opt/vm-doc-server
go build -o bin/vm-doc-server ./cmd/vm-doc-server
go build -o bin/vm-doc-collector ./cmd/vm-doc-collector
sudo systemctl start vm-doc-server vm-doc-collector
```

Adaptați `/opt/vm-doc-server` la calea instalării locale.

## După upgrade

CSS-ul este referențiat cu versiunea 0.13.5 pentru cache-busting. Un `Ctrl+F5` rămâne util doar dacă browserul/proxy-ul păstrează agresiv cache-ul.

Verificați în special paginile Dashboard, VM-uri, Agenți, Servicii, Nomenclatoare și Audit la rezoluția uzuală și pe monitorul mare.
