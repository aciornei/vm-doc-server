# Upgrade offline VM-DOC Server 0.21.65 → 0.21.66

1. Păstrează backup la binarul serverului, surse și configurații. Pentru acest hotfix nu există modificare de schemă DB.
2. Oprește serviciul server înainte de înlocuire.
3. În rădăcina surselor 0.21.65 extrage **doar** `vm-doc-server-0.21.66-update.tar.gz`; alternativ aplică patch-ul `.patch` (nu ambele). Release-ul include și arhiva completă a surselor.
4. Rulează `node --check web/static/js/app.js` și `node scripts/test-vm-resource-context.cjs`.
5. Construiește offline binarul cu procedura ta standard, folosind modulele aprobate din `vendor/`, apoi instalează, repornește și verifică versiunea `0.21.66`.
6. Deschide interfața cu refresh Ctrl+F5; în Network verifică `app.js?v=0.21.66`. Deschide VM #264 → Docker, Baze de date, Web; verifică listarea, click Configurare, salvarea documentației și schimbarea între VM-uri, fără erori în F12 Console.
7. Dacă apare altă eroare, trimite textul complet din Console (fișier + linie). Eroarea inițială de `vmResourceContexts` este remediată la nivel sursă, dar alte erori pot fi vizibile doar în browser real.

Rollback: readu sursele + binarul versiunii 0.21.65; nu necesită rollback MariaDB. Nu este necesară modificarea agentului 1.7.18.
