# VM-DOC Server 0.21.66 — Hotfix Docker / Baze de date / Web

## Defect confirmat
Chrome Developer Tools pe instalarea 0.21.65: `ReferenceError: vmResourceContexts is not defined`, în `registerResourceEditor` (app.js linia 4742), apelat din `vmDetail` pentru VM #264 / Docker. Exact aceeași funcție înregistrează contextul pe Baze de date și Web.

## Corecție
Se declară `const vmResourceContexts=new Map()` în modulul aplicației, înainte de orice folosire de către `registerResourceEditor` și `resolveResourceContext`. Cheile includ VM ID și secțiunea, ca să nu se amestece datele între VM-uri.

Se actualizează `/static/js/app.js?v=0.21.66` și marcajele de diagnostic. Nou: `node scripts/test-vm-resource-context.cjs` verifică înregistrare și citire pentru 3 secțiuni, plus izolare pe VM.

Nu afectează sincronizări, date, inventare, filtre Power/Mediu, API, migrare DB sau agent (1.7.18).

## Limitele verificării
JavaScript syntax și test Node trecute, Go teste independente trecute. Nu există aici dependențe vendor pentru build complet și nici browser conectat la serverul real; e necesară verificare în staging și pe VM-ul raportat.
