'use strict';
// Regression test for the 0.21.65 error reported at app.js:4742.
// Runs the *actual* registerResourceEditor / resolveResourceContext definitions
// with a simulated VM route. Requires only the Node.js standard library.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../web/static/js/app.js'), 'utf8');
assert.match(source, /\bconst vmResourceContexts\s*=\s*new Map\(\)\s*;/, 'Resource context Map must be initialized');
const begin = source.indexOf('function registerResourceEditor(');
const finish = source.indexOf('function resourceSectionForKind(', begin);
assert.ok(begin > 0 && finish > begin, 'Resource context functions must exist');
const context = vm.createContext({location: {hash: '#vms/264/docker'}});
vm.runInContext(`const vmResourceContexts = new Map();\n${source.slice(begin, finish)}`, context);

const data = [
  ['docker', {containers: [{id: 1}]}],
  ['databases', {instances: [{id: 2}]}],
  ['web', {sites: [{id: 3}]}],
];
for (const [section, view] of data) {
  const services = [{id: 42}], categories = [{code: 'environment'}];
  vm.runInContext(`registerResourceEditor(264, '${section}', ${JSON.stringify(view)}, ${JSON.stringify(services)}, ${JSON.stringify(categories)})`, context);
  context.location.hash = `#vms/264/${section}`;
  const found = vm.runInContext(`resolveResourceContext('${section}')`, context);
  assert.equal(found.vmID, 264);
  assert.equal(found.section, section);
  assert.equal(JSON.stringify(found.view), JSON.stringify(view));
  assert.equal(found.services[0].id, 42);
  assert.equal(found.categories[0].code, 'environment');
}
context.location.hash = '#vms/265/docker';
assert.equal(vm.runInContext(`resolveResourceContext('docker')`, context), undefined, 'Contexts must remain scoped by VM ID');
context.location.hash = '#vms/264/docker';
assert.equal(vm.runInContext(`resolveResourceContext('databases')`, context).section, 'databases', 'Contexts must remain scoped by section');

for (const section of ['docker','databases','web']) {
  assert.match(source, new RegExp(`selectedSection==='${section}'[^\\n]*registerResourceEditor\\(id,'${section}'`), `VM detail must register ${section} context`);
}
console.log('PASS: Docker / Databases / Web context initialization, registration, lookup and VM isolation');
