# Upgrade vm-doc-server 0.20.31 -> 0.20.32

Versiunea 0.20.32 este un update exclusiv server/UI. Nu adaugă migrare DB și nu necesită update de vm-doc-agent.

## Schimbări

- Documente este împărțit în `Export / Publică` și `Șabloane`.
- Titlul paginii VM în Outline este exact numele VM-ului din vCenter.
- VM-urile publicate în Outline trimit serviciile către `Link documentație` Outline, dacă acesta este configurat.
- Serviciile publicate în Outline trimit VM-urile către paginile lor Outline din `Virtualizare`, dacă acestea au fost deja publicate.
- Serviciile sunt actualizate numai în pagina indicată de `Link documentație`; VM-DOC nu creează și nu mută pagini de serviciu.
- `Virtualizare · Document / URL` poate primi UUID, slug sau URL Outline; valorile non-UUID sunt rezolvate automat la salvare.
- Testul Outline raportează explicit integrarea dezactivată și erorile API reale.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.31 \
      /usr/local/src/vm-doc-server-0.20.32

tar -xzf vm-doc-server-0.20.32-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.32

cd /usr/local/src/vm-doc-server-0.20.32

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Păstrează directorul `vendor/` din instalarea curentă pentru build offline.
