# VM-DOC Server 0.21.97 — pachete

Bază de upgrade: **0.21.96**. Include funcția Resources→nume cluster doar în raport; migrare aditivă MariaDB 086; agent 1.7.18 nemodificat.

- `VM-DOC-0.21.97-RELEASE.zip` — pachet complet cu surse, incremental și documentație.
- `VM-DOC-UPDATE-096-097.zip` — fișierele modificării incrementale, direct extrase peste sursele 0.21.96.
- `vm-doc-server-0.21.96-to-0.21.97-update.tar.gz` — același incremental, în TAR.GZ.
- `vm-doc-server-0.21.97-source.zip` — sursele complete 0.21.97.
- `vm-doc-server-0.21.96-to-0.21.97.patch` — patch text pentru audit.
- `UPGRADE-0.21.97.md` — instrucțiuni, test, rollback.
- `RELEASE-NOTES-0.21.97.md` — comportament și limite.
- `SHA256SUMS-0.21.97.txt` — verificare integritate.

Nu include binar compilat sau `vendor/`. Rulează test/build complet pe serverul offline înainte de deploy.
