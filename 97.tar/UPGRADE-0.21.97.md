# Upgrade VM-DOC 0.21.96 → 0.21.97

> **Atenție:** acest release introduce migrarea SQL `086`. Recomandăm backup MariaDB, binar și configurație, plus test pe staging.

1. Verifică în directorul surselor active: `cat VERSION` = `0.21.96`; folosește update-ul incremental numai peste această bază.
2. Oprește VM-DOC în fereastra de mentenanță, efectuează backup MariaDB și copiază binarul/configurația curentă.
3. Aplică pachetul incremental din directorul surselor, nu în directorul binarului:

   ```bash
   tar -xzf /cale/vm-doc-server-0.21.96-to-0.21.97-update.tar.gz
   cat VERSION        # 0.21.97
   ```

4. Pe serverul care are `vendor/`, testează și recompilează:

   ```bash
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
   ```

5. Consultă `systemctl cat vm-doc-server` pentru calea exactă a executabilului `ExecStart`. Înlocuiește **doar binarul** cu `bin/vm-doc-server` nou, apoi pornește serviciul. Migrarea `086` rulează automat la pornire; **nu o executa manual**.
6. Verifică `systemctl status vm-doc-server` și endpointul `/version` = `0.21.97`, apoi `Ctrl+F5` în browser.
7. Intră în **Surse & sincronizări → vCenter → Resource pool-uri**, rulează **Descoperă / actualizează**, apoi deschide **Rapoarte → VM-uri pe resource pool-uri** și exportă Word. `Resources` trebuie să devină `cluster-app` numai pentru pool-ul rădăcină confirmat de VCSA.

## Diagnostice (read-only)

Dacă numele rămâne `Resources` după un sync reușit:

```sql
SELECT s.name AS vcsa, p.moid, p.name, p.parent_moid, p.cluster_name, p.present_in_vcenter
FROM vcenter_resource_pools p
JOIN vcenter_sources s ON s.id = p.vcenter_source_id
WHERE p.name = 'Resources'
ORDER BY s.name, p.moid;
```

Verifică permisiunea `System.Read` pe clustere pentru contul VCSA. Lipsa informației de cluster nu trebuie să blocheze importul; aplicația nu ghicește numele.

## Rollback

Revenirea la binarul 0.21.96 este posibilă; coloana aditivă `cluster_name` rămâne neutilizată de acesta. Nu rula automat fișierul `.down.sql` în producție. Dacă trebuie restaurată schema veche, folosește planul DBA/backup. Agentul rămâne 1.7.18.
