package server

import (
	"net/http/httptest"
	"testing"
)

func TestPoolReportExcludesNoVMOnVMFilters(t *testing.T) {
	rows := []poolVMReportRow{
		{SourceID: 1, PoolMoID: "pool-1", PoolName: "Resources / PROD", Included: true, VMName: "VM-A", VMExists: true, Imported: true, PoweredOn: true, Observation: "Nota A"},
		{SourceID: 1, PoolMoID: "pool-2", PoolName: "Resources / TEST", Included: false, VMName: "VM-B", VMExists: true, PoweredOn: false, Imported: false},
		{SourceID: 1, PoolMoID: "pool-3", PoolName: "Resources / Empty", Included: true},
	}
	if n := len(filterPoolVMReport(rows, poolVMReportFilters{})); n != 3 {
		t.Fatalf("default must include all pools, got %d", n)
	}
	for _, tt := range []struct {
		f    poolVMReportFilters
		want string
	}{
		{poolVMReportFilters{Power: "on"}, "VM-A"},
		{poolVMReportFilters{Policy: "excluded"}, "VM-B"},
		{poolVMReportFilters{Import: "not_imported"}, "VM-B"},
		{poolVMReportFilters{Notes: "yes"}, "VM-A"},
		{poolVMReportFilters{Membership: "empty"}, ""},
		{poolVMReportFilters{Pool: "1:pool-2"}, "VM-B"},
	} {
		got := filterPoolVMReport(rows, tt.f)
		if len(got) != 1 || got[0].VMName != tt.want {
			t.Errorf("filters %#v => %#v", tt.f, got)
		}
	}
}
func TestPoolReportRejectsInvalidFilters(t *testing.T) {
	for _, url := range []string{"/api/v1/reports/pool-vms?policy=ignore", "/api/v1/reports/pool-vms?page=0", "/api/v1/reports/pool-vms?source=bad", "/api/v1/reports/pool-vms?pool=x:y", "/api/v1/reports/pool-vms?page_size=1000"} {
		req := httptest.NewRequest("GET", url, nil)
		if _, err := readPoolVMReportFilters(req); err == nil {
			t.Errorf("accepted invalid filter %s", url)
		}
	}
}

func TestPoolReportSortKeepsHomonymousPoolVMsContiguous(t *testing.T) {
	rows := []poolVMReportRow{
		{SourceID: 1, SourceName: "VCSA", PoolMoID: "pool-2", PoolName: "Resources / App", VMName: "a"},
		{SourceID: 1, SourceName: "VCSA", PoolMoID: "pool-1", PoolName: "Resources / App", VMName: "b"},
		{SourceID: 1, SourceName: "VCSA", PoolMoID: "pool-2", PoolName: "Resources / App", VMName: "c"},
		{SourceID: 1, SourceName: "VCSA", PoolMoID: "pool-1", PoolName: "Resources / App", VMName: "d"},
	}
	sortPoolVMReportRows(rows)
	for _, n := range []int{0, 1} {
		if rows[n].PoolMoID != "pool-1" || rows[n+2].PoolMoID != "pool-2" {
			t.Fatalf("same-named pools must not interleave: %#v", rows)
		}
	}
}

func TestDisplayPoolReportRootClusterName(t *testing.T) {
	tests := []struct{ pool, cluster, parent, want string }{
		{"Resources", "cluster-app", "", "cluster-app"},
		{"Resources", "cluster-db", "", "cluster-db"},
		{"Resources", "", "", "Resources"},
		{"Resources", "cluster-app", "resgroup-1", "Resources"},
		{"Aplicatii-PROD", "cluster-app", "resgroup-1", "Aplicatii-PROD"},
		{"PROD", "cluster-app", "", "PROD"},
	}
	for _, tt := range tests {
		got := displayPoolReportRootLabel(tt.pool, tt.cluster, tt.parent)
		if got != tt.want {
			t.Errorf("pool=%s, cluster=%s, parent=%s: got %q, want %q", tt.pool, tt.cluster, tt.parent, got, tt.want)
		}
	}
}
