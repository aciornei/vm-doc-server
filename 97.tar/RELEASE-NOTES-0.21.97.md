# VM-DOC Server 0.21.97 — Resources → numele clusterului în raport

Data: 2026-11-16. Actualizare incrementală peste **0.21.96**. Agent recomandat: **1.7.18**, neschimbat.

## Funcționalitate

- În **Rapoarte → VM-uri pe resource pool-uri**, pool-ul rădăcină `Resources` este afișat sub **numele real al clusterului VCSA**, de exemplu `cluster-app`, când asocierea este disponibilă.
- Sursa exactă: `GET /api/vcenter/cluster` și `GET /api/vcenter/cluster/{cluster}`; răspunsul de detaliu conține `resource_pool` (MoRef-ul rădăcinii). Nu se folosește înlocuire globală după textul „Resources”.
- Alte pool-uri, inclusiv pool-uri dedicate sau un `Resources` de host standalone, își păstrează numele. Categoria VM-DOC **Fără pool identificat (VCSA)** rămâne distinctă.
- Dacă endpointurile de cluster nu sunt accesibile (`403`, timeout), sincronizarea continuă; numele vechi rămâne vizibil și o mapare confirmată anterior este păstrată în baza de date.
- Identitatea de grupare este în continuare `vcenter_source_id + pool_moid` în UI și Word, iar prima coloană rămâne îmbinată/centrată vertical.
- Filtrele, exportul Word, includerea VM-urilor din pool-uri excluse și politica de import VCSA rămân neschimbate. Nu există modificări de agent, permisiuni VM-DOC, Vault sau Outline.

## Implementare

- `internal/vcenter/pools_client.go`: citire opțională, limitată în timp, a numelui clusterului și asocierea exactă la MoRef-ul pool-ului rădăcină.
- `internal/vcenter/pools.go`: persistența noului `cluster_name` fără modificarea lui `name` sau `parent_moid`; valoarea cunoscută se păstrează dacă lookup-ul opțional nu reușește.
- `internal/server/pool_vm_reports.go`: folosește eticheta clusterului numai pentru un `Resources` rădăcină; gruparea pool/VM și exportul Word folosesc aceeași etichetă.
- Migrarea aditivă `086_vcenter_root_pool_cluster.up.sql`: adaugă `vcenter_resource_pools.cluster_name VARCHAR(255) NOT NULL DEFAULT ''`; `ADD COLUMN IF NOT EXISTS` permite reluarea în MariaDB.
- Metadate și documentație: `VERSION`, OpenAPI, releases.json, cache-buster static, CHANGELOG, CONTEXT și TODO.

## Validare

- Teste VCSA Go izolate cu `httptest`: 2 clustere + 1 host standalone, pool dedicat, `403` la cluster API, comportament de import neschimbat — trecute.
- Test Go izolat pentru etichetele raportului: root mapat, root fără mapare, pool dedicat, root sub alt pool — trecut.
- Integritate arhive și patch peste 0.21.96, sintaxă JavaScript/JSON și persistență SQL verificată static.
- **Nevalidate în acest mediu:** build complet Go cu `vendor/`, execuție migrare pe MariaDB reală, integrare cu VCSA real și test browser autentificat. Acestea sunt obligatorii în staging înainte de PROD.

După upgrade, rulează **Surse & sincronizări → vCenter → Descoperă / actualizează** sau un sync VCSA reușit. Fără această colectare, numele clusterului nu este încă salvat și raportul poate afișa temporar `Resources`.
