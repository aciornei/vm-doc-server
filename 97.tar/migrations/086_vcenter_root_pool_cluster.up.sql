-- Root Resources pool -> vCenter cluster label, used only by the Pool / VM report.
-- No changes to pool name, MoRef, selection, VM assignment, or audit state.
ALTER TABLE vcenter_resource_pools
  ADD COLUMN IF NOT EXISTS cluster_name VARCHAR(255) NOT NULL DEFAULT '' AFTER name;
