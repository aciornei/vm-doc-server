ALTER TABLE vcenter_resource_pools DROP COLUMN IF EXISTS cluster_name;
