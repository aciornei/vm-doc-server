package server

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/auth"
)

type securityReview struct {
	ResourceType   string     `json:"resource_type"`
	ResourceKey    string     `json:"resource_key"`
	IntervalMonths int        `json:"interval_months"`
	Justified      bool       `json:"justified"`
	Notes          string     `json:"notes,omitempty"`
	ReviewedAt     *time.Time `json:"reviewed_at,omitempty"`
	NextReviewAt   *time.Time `json:"next_review_at,omitempty"`
	ReviewedBy     string     `json:"reviewed_by,omitempty"`
	Due            bool       `json:"due"`
}

type securityAccount struct {
	VMID               int64          `json:"vm_id"`
	VMName             string         `json:"vm_name"`
	OSFamily           string         `json:"os_family,omitempty"`
	Username           string         `json:"username"`
	UID                uint64         `json:"uid"`
	GID                uint64         `json:"gid"`
	Shell              string         `json:"shell,omitempty"`
	Groups             []string       `json:"groups,omitempty"`
	LoginCapable       bool           `json:"login_capable"`
	Privileged         bool           `json:"privileged"`
	SystemAccount      bool           `json:"system_account"`
	PasswordStatus     string         `json:"password_status"`
	PasswordLocked     bool           `json:"password_locked"`
	PasswordLastSet    *time.Time     `json:"password_last_set,omitempty"`
	PasswordExpiresAt  *time.Time     `json:"password_expires_at,omitempty"`
	MaxPasswordAgeDays *int64         `json:"max_password_age_days,omitempty"`
	MinPasswordAgeDays *int64         `json:"min_password_age_days,omitempty"`
	WarningDays        *int64         `json:"warning_days,omitempty"`
	AccountExpiresAt   *time.Time     `json:"account_expires_at,omitempty"`
	Review             securityReview `json:"review"`
}

type securityPasswordPolicyCheck struct {
	Code   string `json:"code"`
	Status string `json:"status"`
	Value  string `json:"value,omitempty"`
	Source string `json:"source,omitempty"`
	Detail string `json:"detail,omitempty"`
}

type legacySecurityPAMModule struct {
	File    string            `json:"file"`
	Module  string            `json:"module"`
	Options map[string]string `json:"options"`
}

type legacySecurityPasswordPolicy struct {
	Sources              []string                      `json:"sources"`
	LoginDefs            map[string]string             `json:"login_defs"`
	PAMModules           []legacySecurityPAMModule     `json:"pam_modules"`
	Pwquality            map[string]string             `json:"pwquality"`
	PasswordHistory      map[string]string             `json:"password_history"`
	Effective            map[string]string             `json:"effective"`
	ComplexityConfigured bool                          `json:"complexity_configured"`
	EnforcementStatus    string                        `json:"enforcement_status"`
	Checks               []securityPasswordPolicyCheck `json:"checks"`
}

type legacySecurityPolicyUser struct {
	Username           string `json:"username"`
	UID                uint64 `json:"uid"`
	Shell              string `json:"shell"`
	SystemAccount      bool   `json:"system_account"`
	LoginCapable       bool   `json:"login_capable"`
	PasswordStatus     string `json:"password_status"`
	PasswordLocked     bool   `json:"password_locked"`
	MinPasswordAgeDays *int64 `json:"min_password_age_days"`
	MaxPasswordAgeDays *int64 `json:"max_password_age_days"`
	WarningDays        *int64 `json:"warning_days"`
}

type securityPasswordPolicy struct {
	VMID                 int64                         `json:"vm_id"`
	VMName               string                        `json:"vm_name"`
	OSFamily             string                        `json:"os_family,omitempty"`
	Sources              []string                      `json:"sources,omitempty"`
	Effective            map[string]string             `json:"effective,omitempty"`
	ComplexityConfigured bool                          `json:"complexity_configured"`
	EnforcementStatus    string                        `json:"enforcement_status,omitempty"`
	Checks               []securityPasswordPolicyCheck `json:"checks,omitempty"`
}

type securityDBPrincipal struct {
	Name        string         `json:"name"`
	Host        string         `json:"host,omitempty"`
	Database    string         `json:"database,omitempty"`
	Login       bool           `json:"login"`
	Superuser   bool           `json:"superuser,omitempty"`
	CreateDB    bool           `json:"create_db,omitempty"`
	CreateRole  bool           `json:"create_role,omitempty"`
	Replication bool           `json:"replication,omitempty"`
	Roles       []string       `json:"roles,omitempty"`
	Review      securityReview `json:"review"`
}

// securityDBPrincipalReviewKey identifies the account within a specific DB
// instance. Never key solely on username: MySQL user@host and distinct
// PostgreSQL instances can have independent access reviews.
func securityDatabaseBuiltInNoLogin(engine string, principal securityDBPrincipal) bool {
	return strings.EqualFold(strings.TrimSpace(engine), "postgresql") &&
		!principal.Login && strings.HasPrefix(strings.ToLower(strings.TrimSpace(principal.Name)), "pg_")
}

func securityDBPrincipalReviewKey(instanceID int64, principal securityDBPrincipal) string {
	identity := principal.Name + "\x00" + principal.Host + "\x00" + principal.Database
	sum := sha256.Sum256([]byte(identity))
	return "dbp:" + strconv.FormatInt(instanceID, 10) + ":" + hex.EncodeToString(sum[:])
}

// Reviews for Grants operate per grantee (principal + host) inside one DB
// instance, even when that grantee owns thousands of individual privileges.
func securityDBGrantReviewKey(instanceID int64, principal, host string) string {
	identity := principal + "\x00" + host
	sum := sha256.Sum256([]byte(identity))
	return "dbg:" + strconv.FormatInt(instanceID, 10) + ":" + hex.EncodeToString(sum[:])
}

func securityDBHBAReviewKey(instanceID int64, rule securityHBARule) string {
	// Include the source path and line: two independent pg_hba records must not
	// share a review simply because their access pattern looks the same.
	payload, _ := json.Marshal([]any{rule.SourceFile, rule.Line, rule.Type, rule.Databases, rule.Users, rule.Address, rule.Method, rule.Options})
	sum := sha256.Sum256(payload)
	return "dbh:" + strconv.FormatInt(instanceID, 10) + ":" + hex.EncodeToString(sum[:])
}

type securityDBGrantReview struct {
	Principal string         `json:"principal"`
	Host      string         `json:"host,omitempty"`
	Count     int            `json:"count"`
	Review    securityReview `json:"review"`
}

type securityDBPrivilege struct {
	Principal  string `json:"principal"`
	Host       string `json:"host,omitempty"`
	Scope      string `json:"scope"`
	Database   string `json:"database,omitempty"`
	Schema     string `json:"schema,omitempty"`
	ObjectType string `json:"object_type,omitempty"`
	ObjectName string `json:"object_name,omitempty"`
	Privilege  string `json:"privilege"`
	State      string `json:"state,omitempty"`
	Grantable  bool   `json:"grantable,omitempty"`
	Source     string `json:"source,omitempty"`
}

type securityHBARule struct {
	Type        string         `json:"type"`
	Databases   []string       `json:"databases,omitempty"`
	Users       []string       `json:"users,omitempty"`
	Address     string         `json:"address,omitempty"`
	Method      string         `json:"method,omitempty"`
	Options     []string       `json:"options,omitempty"`
	SourceFile  string         `json:"source_file,omitempty"`
	Line        int            `json:"line,omitempty"`
	Warning     bool           `json:"warning"`
	WarningText string         `json:"warning_text,omitempty"`
	Review      securityReview `json:"review"`
}

type securityDatabase struct {
	ID           int64                   `json:"id"`
	VMID         int64                   `json:"vm_id"`
	VMName       string                  `json:"vm_name"`
	Engine       string                  `json:"engine"`
	Product      string                  `json:"product"`
	InstanceName string                  `json:"instance_name"`
	Version      string                  `json:"version,omitempty"`
	Status       string                  `json:"status,omitempty"`
	Reason       string                  `json:"reason,omitempty"`
	Principals   []securityDBPrincipal   `json:"principals"`
	Privileges   []securityDBPrivilege   `json:"privileges"`
	GrantReviews []securityDBGrantReview `json:"grant_reviews"`
	HBARules     []securityHBARule       `json:"hba_rules"`
	Review       securityReview          `json:"review"`
}

type securityWebRule struct {
	Action     string `json:"action"`
	Source     string `json:"source"`
	Scope      string `json:"scope,omitempty"`
	Directive  string `json:"directive,omitempty"`
	SourceFile string `json:"source_file,omitempty"`
	Warning    bool   `json:"warning"`
}

type securityWebSite struct {
	ID          int64             `json:"id"`
	VMID        int64             `json:"vm_id"`
	VMName      string            `json:"vm_name"`
	Engine      string            `json:"engine"`
	Name        string            `json:"name"`
	ServerNames []string          `json:"server_names,omitempty"`
	ConfigFile  string            `json:"config_file,omitempty"`
	Rules       []securityWebRule `json:"rules"`
	Review      securityReview    `json:"review"`
}

type securitySummary struct {
	Accounts             int `json:"accounts"`
	AccountsRelevant     int `json:"accounts_relevant"`
	AccountsSystem       int `json:"accounts_system"`
	AccountsSystemHidden int `json:"accounts_system_hidden"`
	AccountsPrivileged   int `json:"accounts_privileged"`
	AccountsPasswordSet  int `json:"accounts_password_set"`
	AccountsDue          int `json:"accounts_due"`
	AccountsDueAll       int `json:"accounts_due_all"`
	PasswordPolicies     int `json:"password_policies"`
	PasswordEnforced     int `json:"password_enforced"`
	PasswordPartial      int `json:"password_partial"`
	PasswordNotEnforced  int `json:"password_not_enforced"`
	PasswordUnknown      int `json:"password_unknown"`
	DatabaseInstances    int `json:"database_instances"`
	DatabasePrincipals   int `json:"database_principals"`
	DatabasePrivileges   int `json:"database_privileges"`
	DatabasePrivileged   int `json:"database_privileged"`
	HBAWarnings          int `json:"hba_warnings"`
	DatabaseDue          int `json:"database_due"`
	DatabaseGrantsDue    int `json:"database_grants_due"`
	DatabaseHBADue       int `json:"database_hba_due"`
	WebSites             int `json:"web_sites"`
	WebRules             int `json:"web_rules"`
	WebAllowAll          int `json:"web_allow_all"`
	WebDue               int `json:"web_due"`
	TotalDue             int `json:"total_due"`
}

type securityResponse struct {
	GeneratedAt      time.Time                `json:"generated_at"`
	Summary          securitySummary          `json:"summary"`
	Accounts         []securityAccount        `json:"accounts"`
	PasswordPolicies []securityPasswordPolicy `json:"password_policies"`
	Databases        []securityDatabase       `json:"databases"`
	WebSites         []securityWebSite        `json:"web_sites"`
}

func securityReviewMapKey(vmID int64, typ, key string) string {
	return fmt.Sprintf("%d|%s|%s", vmID, strings.ToLower(strings.TrimSpace(typ)), strings.TrimSpace(key))
}

func (a *App) loadSecurityReviews(ctx context.Context) (map[string]securityReview, error) {
	out := map[string]securityReview{}
	rows, err := a.DB.QueryContext(ctx, `SELECT r.vm_id,r.resource_type,r.resource_key,r.interval_months,r.justified,r.notes,r.reviewed_at,r.next_review_at,COALESCE(u.display_name,u.username,'') FROM security_reviews r LEFT JOIN users u ON u.id=r.reviewed_by`)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	now := time.Now().UTC()
	for rows.Next() {
		var vmID int64
		var v securityReview
		var reviewedAt, nextAt time.Time
		if err := rows.Scan(&vmID, &v.ResourceType, &v.ResourceKey, &v.IntervalMonths, &v.Justified, &v.Notes, &reviewedAt, &nextAt, &v.ReviewedBy); err != nil {
			return nil, err
		}
		v.ReviewedAt = &reviewedAt
		v.NextReviewAt = &nextAt
		v.Due = !nextAt.After(now)
		out[securityReviewMapKey(vmID, v.ResourceType, v.ResourceKey)] = v
	}
	return out, rows.Err()
}

func defaultSecurityReview(vmID int64, typ, key string, interval int) securityReview {
	return securityReview{ResourceType: typ, ResourceKey: key, IntervalMonths: interval, Due: true}
}

func reviewFor(m map[string]securityReview, vmID int64, typ, key string, interval int) securityReview {
	if v, ok := m[securityReviewMapKey(vmID, typ, key)]; ok {
		return v
	}
	return defaultSecurityReview(vmID, typ, key, interval)
}

func (a *App) securityOverview(w http.ResponseWriter, r *http.Request) {
	var vmID int64
	if raw := strings.TrimSpace(r.URL.Query().Get("vm_id")); raw != "" {
		parsed, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || parsed < 1 {
			badRequest(w, errors.New("vm_id invalid"))
			return
		}
		vmID = parsed
	}
	reviews, err := a.loadSecurityReviews(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	result := securityResponse{GeneratedAt: time.Now().UTC(), Accounts: []securityAccount{}, PasswordPolicies: []securityPasswordPolicy{}, Databases: []securityDatabase{}, WebSites: []securityWebSite{}}
	if err := a.loadSecurityAccounts(r.Context(), reviews, &result, vmID); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.loadSecurityDatabases(r.Context(), reviews, &result, vmID); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.loadSecurityWeb(r.Context(), reviews, &result, vmID); err != nil {
		respond(w, nil, err)
		return
	}
	result.Summary.TotalDue = result.Summary.AccountsDue + result.Summary.DatabaseDue + result.Summary.WebDue
	// Optional light projection for the global Security workspace. Existing
	// /api/v1/security and ?vm_id=... contracts stay unchanged unless requested.
	// Summary counters are computed from complete inventories before projection.
	if vmID == 0 {
		projectSecurityResponse(&result, strings.TrimSpace(r.URL.Query().Get("section")))
	}
	respond(w, result, nil)
}

// projectSecurityResponse limits JSON transferred to Chrome. The unfiltered
// endpoint remains backwards-compatible with reports/clients using all data.
// No security reviews or stored inventories are changed by this projection.
func projectSecurityResponse(result *securityResponse, section string) {
	switch section {
	case "accounts":
		result.Databases = []securityDatabase{}
		result.WebSites = []securityWebSite{}
	case "databases":
		result.Accounts = []securityAccount{}
		result.PasswordPolicies = []securityPasswordPolicy{}
		result.WebSites = []securityWebSite{}
	case "web":
		result.Accounts = []securityAccount{}
		result.PasswordPolicies = []securityPasswordPolicy{}
		result.Databases = []securityDatabase{}
	case "overview":
		accounts := make([]securityAccount, 0, 15)
		for _, x := range result.Accounts {
			if securityAccountRelevant(x) && x.Review.Due && len(accounts) < 15 {
				accounts = append(accounts, x)
			}
		}
		dbs := make([]securityDatabase, 0, 10)
		for _, x := range result.Databases {
			if !x.Review.Due || len(dbs) >= 10 {
				continue
			}
			// The overview only uses DB metadata, review and existence of HBA warnings.
			slim := securityDatabase{ID: x.ID, VMID: x.VMID, VMName: x.VMName, Engine: x.Engine, Product: x.Product, InstanceName: x.InstanceName, Review: x.Review}
			for _, h := range x.HBARules {
				if h.Warning {
					slim.HBARules = []securityHBARule{{Warning: true}}
					break
				}
			}
			dbs = append(dbs, slim)
		}
		web := make([]securityWebSite, 0, 10)
		for _, x := range result.WebSites {
			if !x.Review.Due || len(web) >= 10 {
				continue
			}
			slim := securityWebSite{ID: x.ID, VMID: x.VMID, VMName: x.VMName, Name: x.Name, Review: x.Review}
			for _, rule := range x.Rules {
				if rule.Warning {
					slim.Rules = []securityWebRule{{Warning: true}}
					break
				}
			}
			web = append(web, slim)
		}
		result.Accounts = accounts
		result.PasswordPolicies = []securityPasswordPolicy{}
		result.Databases = dbs
		result.WebSites = web
	}
}

func securityLinuxLike(osFamily string) bool {
	v := strings.ToLower(strings.TrimSpace(osFamily))
	switch v {
	case "linux", "debian", "redhat", "suse", "sles", "ubuntu", "rhel", "centos", "rocky", "almalinux", "oraclelinux", "opensuse":
		return true
	}
	return strings.Contains(v, "linux") || strings.Contains(v, "unix")
}

func securityInteractiveShell(shell string) bool {
	v := strings.ToLower(strings.TrimSpace(shell))
	if v == "" {
		return false
	}
	base := v
	if idx := strings.LastIndex(base, "/"); idx >= 0 {
		base = base[idx+1:]
	}
	switch base {
	case "nologin", "false", "sync", "shutdown", "halt":
		return false
	}
	return !strings.Contains(v, "nologin")
}

func securitySystemAccount(osFamily, username string, uid uint64, reported bool) bool {
	if strings.EqualFold(strings.TrimSpace(username), "root") {
		return true
	}
	if reported {
		return true
	}
	return securityLinuxLike(osFamily) && uid < 1000
}

func legacyPasswordPolicyValue(policy legacySecurityPasswordPolicy, key string) string {
	if v := strings.TrimSpace(policy.Pwquality[key]); v != "" {
		return v
	}
	return strings.TrimSpace(policy.LoginDefs[key])
}

func legacyPasswordPolicyCheck(code, status, value, source, detail string) securityPasswordPolicyCheck {
	return securityPasswordPolicyCheck{Code: code, Status: status, Value: value, Source: source, Detail: detail}
}

func deriveLegacyLinuxPasswordPolicy(raw legacySecurityPasswordPolicy, users []legacySecurityPolicyUser) securityPasswordPolicy {
	policy := securityPasswordPolicy{
		Sources: raw.Sources, Effective: raw.Effective, ComplexityConfigured: raw.ComplexityConfigured,
		EnforcementStatus: raw.EnforcementStatus, Checks: raw.Checks,
	}
	if strings.TrimSpace(policy.EnforcementStatus) != "" || len(policy.Checks) > 0 {
		return policy
	}
	if len(raw.Sources) == 0 && len(raw.LoginDefs) == 0 && len(raw.PAMModules) == 0 && len(raw.Pwquality) == 0 {
		return policy
	}
	if policy.Effective == nil {
		policy.Effective = map[string]string{}
	}
	for _, key := range []string{"PASS_MIN_LEN", "PASS_MIN_DAYS", "PASS_MAX_DAYS", "PASS_WARN_AGE", "ENCRYPT_METHOD"} {
		if v := strings.TrimSpace(raw.LoginDefs[key]); v != "" {
			policy.Effective[key] = v
		}
	}

	complexitySource, complexityModule, minLen := "", "", ""
	historySource, historyValue := "", ""
	for _, module := range raw.PAMModules {
		name := strings.ToLower(strings.TrimSpace(module.Module))
		switch name {
		case "pam_pwquality.so", "pam_cracklib.so", "pam_pwcheck.so":
			if complexityModule == "" {
				complexityModule, complexitySource = name, module.File
			}
			if minLen == "" {
				minLen = strings.TrimSpace(module.Options["minlen"])
			}
		}
		if name == "pam_pwhistory.so" {
			historySource = module.File
		}
		if remember := strings.TrimSpace(module.Options["remember"]); remember != "" && remember != "0" {
			if historySource == "" {
				historySource = module.File
			}
			historyValue = remember
		}
	}
	if minLen == "" {
		minLen = strings.TrimSpace(raw.Pwquality["minlen"])
	}
	if minLen == "" {
		minLen = strings.TrimSpace(raw.LoginDefs["PASS_MIN_LEN"])
	}

	if complexityModule != "" {
		value := complexityModule
		if minLen != "" {
			value += " minlen=" + minLen
		}
		policy.Checks = append(policy.Checks, legacyPasswordPolicyCheck("complexity", "enforced", value, complexitySource, "modul PAM de complexitate este prezent în stiva password (evaluare server pentru agent legacy)"))
	} else if raw.ComplexityConfigured || minLen != "" {
		policy.Checks = append(policy.Checks, legacyPasswordPolicyCheck("complexity", "configured", minLen, firstLegacyPolicySource(raw.Sources), "există configurare de complexitate, dar agentul legacy nu raportează un modul PAM activ care să o impună"))
	} else {
		policy.Checks = append(policy.Checks, legacyPasswordPolicyCheck("complexity", "not_configured", "", "", "nu a fost detectată o politică de complexitate"))
	}
	if minLen != "" {
		status, source := "configured", "/etc/login.defs"
		if complexityModule != "" {
			status, source = "enforced", complexitySource
		}
		policy.Checks = append(policy.Checks, legacyPasswordPolicyCheck("minimum_length", status, minLen, source, "lungime minimă derivată din configurația raportată de agentul legacy"))
	} else {
		policy.Checks = append(policy.Checks, legacyPasswordPolicyCheck("minimum_length", "not_configured", "", "", "nu a fost detectată o lungime minimă"))
	}
	if historySource != "" {
		value := historyValue
		if value != "" {
			value = "remember=" + value
		}
		policy.Checks = append(policy.Checks, legacyPasswordPolicyCheck("history", "enforced", value, historySource, "istoricul parolelor este impus prin PAM (evaluare server pentru agent legacy)"))
	} else {
		policy.Checks = append(policy.Checks, legacyPasswordPolicyCheck("history", "not_configured", "", "", "nu a fost detectată impunerea istoricului parolelor"))
	}

	policy.Checks = append(policy.Checks, deriveLegacyAgingCheck("min_age", "PASS_MIN_DAYS", raw.LoginDefs["PASS_MIN_DAYS"], users, func(actual, expected int64) bool { return actual >= expected }, func(u legacySecurityPolicyUser) *int64 { return u.MinPasswordAgeDays }))
	policy.Checks = append(policy.Checks, deriveLegacyAgingCheck("max_age", "PASS_MAX_DAYS", raw.LoginDefs["PASS_MAX_DAYS"], users, func(actual, expected int64) bool { return actual >= 0 && actual <= expected }, func(u legacySecurityPolicyUser) *int64 { return u.MaxPasswordAgeDays }))
	policy.Checks = append(policy.Checks, deriveLegacyAgingCheck("warning_age", "PASS_WARN_AGE", raw.LoginDefs["PASS_WARN_AGE"], users, func(actual, expected int64) bool { return actual >= expected }, func(u legacySecurityPolicyUser) *int64 { return u.WarningDays }))
	policy.EnforcementStatus = legacyPasswordPolicyOverallStatus(policy.Checks)
	return policy
}

func firstLegacyPolicySource(sources []string) string {
	if len(sources) > 0 {
		return sources[0]
	}
	return ""
}

func deriveLegacyAgingCheck(code, setting, raw string, users []legacySecurityPolicyUser, compliant func(int64, int64) bool, actualValue func(legacySecurityPolicyUser) *int64) securityPasswordPolicyCheck {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return legacyPasswordPolicyCheck(code, "not_configured", "", "/etc/login.defs", setting+" nu este configurat")
	}
	expected, err := strconv.ParseInt(raw, 10, 64)
	if err != nil {
		return legacyPasswordPolicyCheck(code, "unknown", raw, "/etc/login.defs", setting+" nu poate fi interpretat numeric")
	}
	checked, okCount := 0, 0
	nonCompliant := []string{}
	for _, u := range users {
		login := u.LoginCapable || securityInteractiveShell(u.Shell)
		system := securitySystemAccount("linux", u.Username, u.UID, u.SystemAccount)
		status := strings.ToLower(strings.TrimSpace(u.PasswordStatus))
		if !login || system || u.PasswordLocked || status == "empty" || status == "unknown" {
			continue
		}
		checked++
		actual := actualValue(u)
		if actual != nil && compliant(*actual, expected) {
			okCount++
		} else if len(nonCompliant) < 20 {
			nonCompliant = append(nonCompliant, u.Username)
		}
	}
	if checked == 0 {
		return legacyPasswordPolicyCheck(code, "configured", raw, "/etc/login.defs", setting+" este configurat; nu există conturi locale login-capable eligibile pentru verificare")
	}
	status := "enforced"
	if okCount != checked {
		status = "partial"
	}
	detail := fmt.Sprintf("%d/%d conturi locale login-capable respectă %s", okCount, checked, setting)
	if len(nonCompliant) > 0 {
		detail += "; neconforme: " + strings.Join(nonCompliant, ", ")
	}
	return legacyPasswordPolicyCheck(code, status, raw, "/etc/login.defs", detail+" (evaluare server pentru agent legacy)")
}

func legacyPasswordPolicyOverallStatus(checks []securityPasswordPolicyCheck) string {
	enforced, configured, notEnforced, partial, unknown := 0, 0, 0, 0, 0
	for _, check := range checks {
		switch strings.ToLower(strings.TrimSpace(check.Status)) {
		case "enforced":
			enforced++
		case "configured":
			configured++
		case "not_enforced", "not_configured":
			notEnforced++
		case "partial":
			partial++
		case "unknown":
			unknown++
		}
	}
	if partial > 0 || (notEnforced > 0 && (enforced > 0 || configured > 0)) || (configured > 0 && enforced > 0) {
		return "partial"
	}
	if notEnforced > 0 {
		return "not_enforced"
	}
	if configured > 0 {
		return "configured"
	}
	if enforced > 0 {
		return "enforced"
	}
	if unknown > 0 {
		return "unknown"
	}
	return "not_configured"
}

func securityPasswordPolicyPresent(policy securityPasswordPolicy) bool {
	return strings.TrimSpace(policy.EnforcementStatus) != "" || len(policy.Checks) > 0 || len(policy.Effective) > 0 || len(policy.Sources) > 0
}

func securityAccountPasswordRelevant(row securityAccount) bool {
	if row.PasswordLocked {
		return false
	}
	status := strings.ToLower(strings.TrimSpace(row.PasswordStatus))
	return status == "password_set" || status == "password_set_or_external" || status == "empty"
}

// securityAccountRelevant suppresses low-value daemon/system accounts by default,
// while keeping root and any system account that can log in, is privileged or has
// a password state that deserves review. The complete inventory remains available
// through the UI filter.
func securityAccountRelevant(row securityAccount) bool {
	if strings.EqualFold(strings.TrimSpace(row.Username), "root") {
		return true
	}
	if !row.SystemAccount {
		return true
	}
	return row.LoginCapable || row.Privileged || securityAccountPasswordRelevant(row)
}

func (a *App) loadSecurityAccounts(ctx context.Context, reviews map[string]securityReview, result *securityResponse, onlyVMID int64) error {
	query := `SELECT vm.id,vm.name,COALESCE(i.raw_json,'') FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0`
	args := []any{}
	if onlyVMID > 0 {
		query += ` AND vm.id=?`
		args = append(args, onlyVMID)
	}
	query += ` ORDER BY vm.name,vm.id`
	rows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var vmID int64
		var vmName string
		var raw []byte
		if err := rows.Scan(&vmID, &vmName, &raw); err != nil {
			return err
		}
		var envelope struct {
			OS struct {
				Family string `json:"family"`
			} `json:"os"`
			Accounts struct {
				PasswordPolicy legacySecurityPasswordPolicy `json:"password_policy"`
				LocalUsers     []struct {
					Username           string     `json:"username"`
					UID                uint64     `json:"uid"`
					GID                uint64     `json:"gid"`
					Shell              string     `json:"shell"`
					Groups             []string   `json:"groups"`
					LoginCapable       bool       `json:"login_capable"`
					Privileged         bool       `json:"privileged"`
					SystemAccount      bool       `json:"system_account"`
					PasswordStatus     string     `json:"password_status"`
					PasswordLocked     bool       `json:"password_locked"`
					PasswordLastSet    *time.Time `json:"password_last_set"`
					PasswordExpiresAt  *time.Time `json:"password_expires_at"`
					MinPasswordAgeDays *int64     `json:"min_password_age_days"`
					MaxPasswordAgeDays *int64     `json:"max_password_age_days"`
					WarningDays        *int64     `json:"warning_days"`
					AccountExpiresAt   *time.Time `json:"account_expires_at"`
				} `json:"local_users"`
			} `json:"accounts"`
		}
		if len(raw) == 0 || json.Unmarshal(raw, &envelope) != nil {
			continue
		}
		legacyUsers := make([]legacySecurityPolicyUser, 0, len(envelope.Accounts.LocalUsers))
		for _, u := range envelope.Accounts.LocalUsers {
			legacyUsers = append(legacyUsers, legacySecurityPolicyUser{
				Username: u.Username, UID: u.UID, Shell: u.Shell, SystemAccount: u.SystemAccount, LoginCapable: u.LoginCapable,
				PasswordStatus: u.PasswordStatus, PasswordLocked: u.PasswordLocked, MinPasswordAgeDays: u.MinPasswordAgeDays,
				MaxPasswordAgeDays: u.MaxPasswordAgeDays, WarningDays: u.WarningDays,
			})
		}
		policy := securityPasswordPolicy{
			Sources: envelope.Accounts.PasswordPolicy.Sources, Effective: envelope.Accounts.PasswordPolicy.Effective,
			ComplexityConfigured: envelope.Accounts.PasswordPolicy.ComplexityConfigured,
			EnforcementStatus:    envelope.Accounts.PasswordPolicy.EnforcementStatus, Checks: envelope.Accounts.PasswordPolicy.Checks,
		}
		if securityLinuxLike(envelope.OS.Family) && strings.TrimSpace(policy.EnforcementStatus) == "" && len(policy.Checks) == 0 {
			policy = deriveLegacyLinuxPasswordPolicy(envelope.Accounts.PasswordPolicy, legacyUsers)
		}
		policy.VMID = vmID
		policy.VMName = vmName
		policy.OSFamily = envelope.OS.Family
		if securityPasswordPolicyPresent(policy) {
			result.PasswordPolicies = append(result.PasswordPolicies, policy)
			result.Summary.PasswordPolicies++
			switch strings.ToLower(strings.TrimSpace(policy.EnforcementStatus)) {
			case "enforced":
				result.Summary.PasswordEnforced++
			case "partial":
				result.Summary.PasswordPartial++
			case "not_enforced", "not_configured":
				result.Summary.PasswordNotEnforced++
			default:
				result.Summary.PasswordUnknown++
			}
		}
		for _, u := range envelope.Accounts.LocalUsers {
			privileged := u.Privileged || (securityLinuxLike(envelope.OS.Family) && u.UID == 0)
			for _, group := range u.Groups {
				if strings.EqualFold(group, "sudo") || strings.EqualFold(group, "wheel") || strings.EqualFold(group, "admin") || strings.EqualFold(group, "root") {
					privileged = true
				}
			}
			loginCapable := u.LoginCapable
			if securityLinuxLike(envelope.OS.Family) {
				loginCapable = securityInteractiveShell(u.Shell)
			}
			systemAccount := securitySystemAccount(envelope.OS.Family, u.Username, u.UID, u.SystemAccount)
			interval := 12
			if privileged {
				interval = 6
			}
			row := securityAccount{VMID: vmID, VMName: vmName, OSFamily: envelope.OS.Family, Username: u.Username, UID: u.UID, GID: u.GID, Shell: u.Shell, Groups: u.Groups, LoginCapable: loginCapable, Privileged: privileged, SystemAccount: systemAccount, PasswordStatus: u.PasswordStatus, PasswordLocked: u.PasswordLocked, PasswordLastSet: u.PasswordLastSet, PasswordExpiresAt: u.PasswordExpiresAt, MinPasswordAgeDays: u.MinPasswordAgeDays, MaxPasswordAgeDays: u.MaxPasswordAgeDays, WarningDays: u.WarningDays, AccountExpiresAt: u.AccountExpiresAt, Review: reviewFor(reviews, vmID, "vm_account", u.Username, interval)}
			result.Accounts = append(result.Accounts, row)
			result.Summary.Accounts++
			if row.SystemAccount && !strings.EqualFold(strings.TrimSpace(row.Username), "root") {
				result.Summary.AccountsSystem++
			}
			if securityAccountRelevant(row) {
				result.Summary.AccountsRelevant++
			} else {
				result.Summary.AccountsSystemHidden++
			}
			if row.Privileged {
				result.Summary.AccountsPrivileged++
			}
			if row.PasswordStatus == "password_set" || row.PasswordStatus == "password_set_or_external" {
				result.Summary.AccountsPasswordSet++
			}
			if row.Review.Due {
				result.Summary.AccountsDueAll++
				if securityAccountRelevant(row) {
					result.Summary.AccountsDue++
				}
			}
		}
	}
	return rows.Err()
}

func hbaWarning(rule securityHBARule) (bool, string) {
	reasons := []string{}
	addr := strings.ToLower(strings.TrimSpace(rule.Address))
	method := strings.ToLower(strings.TrimSpace(rule.Method))
	if addr == "0.0.0.0/0" || addr == "::/0" || addr == "all" {
		reasons = append(reasons, "sursă foarte largă")
	}
	if method == "trust" {
		reasons = append(reasons, "trust")
	}
	if method == "md5" {
		reasons = append(reasons, "md5")
	}
	if containsSecurityFold(rule.Databases, "all") && containsSecurityFold(rule.Users, "all") {
		reasons = append(reasons, "all/all")
	}
	return len(reasons) > 0, strings.Join(reasons, ", ")
}
func containsSecurityFold(v []string, target string) bool {
	for _, x := range v {
		if strings.EqualFold(strings.TrimSpace(x), target) {
			return true
		}
	}
	return false
}

func (a *App) loadSecurityDatabases(ctx context.Context, reviews map[string]securityReview, result *securityResponse, onlyVMID int64) error {
	query := `SELECT di.id,di.vm_id,vm.name,di.engine,di.product,di.instance_name,di.version,COALESCE(di.access_json,'{}') FROM (SELECT i0.* FROM database_instances i0 WHERE NOT EXISTS(SELECT 1 FROM database_engine_exclusions ex WHERE ex.ignored=1 AND ex.engine_key=(CASE WHEN REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') IN ('db2','ibmdb2','db2luw','ibmdb2luw') THEN 'db2' ELSE REPLACE(REPLACE(REPLACE(LOWER(TRIM(i0.engine)),' ',''),'_',''),'-','') END))) di JOIN virtual_machines vm ON vm.id=di.vm_id WHERE di.present=1 AND vm.retired=0`
	args := []any{}
	if onlyVMID > 0 {
		query += ` AND di.vm_id=?`
		args = append(args, onlyVMID)
	}
	query += ` ORDER BY vm.name,di.engine,di.instance_name,di.id`
	rows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var row securityDatabase
		var raw []byte
		if err := rows.Scan(&row.ID, &row.VMID, &row.VMName, &row.Engine, &row.Product, &row.InstanceName, &row.Version, &raw); err != nil {
			return err
		}
		var access struct {
			Principals []securityDBPrincipal `json:"principals"`
			Privileges []securityDBPrivilege `json:"privileges"`
			HBARules   []securityHBARule     `json:"hba_rules"`
			Status     string                `json:"status"`
			Reason     string                `json:"reason"`
		}
		_ = json.Unmarshal(raw, &access)
		// System PostgreSQL roles named pg_* with NOLOGIN are internal
		// predefined roles, not application identities requiring review.
		// Keep them in access_json/raw inventories; omit only from security
		// presentation, due counters and review calendar.
		for _, principal := range access.Principals {
			if securityDatabaseBuiltInNoLogin(row.Engine, principal) {
				continue
			}
			row.Principals = append(row.Principals, principal)
		}
		row.Privileges = access.Privileges
		grantIndex := make(map[string]int)
		for _, grant := range row.Privileges {
			identity := grant.Principal + "\x00" + grant.Host
			if idx, found := grantIndex[identity]; found {
				row.GrantReviews[idx].Count++
			} else {
				key := securityDBGrantReviewKey(row.ID, grant.Principal, grant.Host)
				grantIndex[identity] = len(row.GrantReviews)
				row.GrantReviews = append(row.GrantReviews, securityDBGrantReview{
					Principal: grant.Principal, Host: grant.Host, Count: 1,
					Review: reviewFor(reviews, row.VMID, "database_grants", key, 6),
				})
			}
		}
		row.HBARules = access.HBARules
		row.Status = access.Status
		row.Reason = access.Reason
		for i := range row.HBARules {
			row.HBARules[i].Warning, row.HBARules[i].WarningText = hbaWarning(row.HBARules[i])
			row.HBARules[i].Review = reviewFor(reviews, row.VMID, "database_hba", securityDBHBAReviewKey(row.ID, row.HBARules[i]), 6)
			if row.HBARules[i].Warning {
				result.Summary.HBAWarnings++
			}
		}
		row.Review = reviewFor(reviews, row.VMID, "database", strconv.FormatInt(row.ID, 10), 6)
		result.Summary.DatabaseInstances++
		result.Summary.DatabasePrincipals += len(row.Principals)
		result.Summary.DatabasePrivileges += len(row.Privileges)
		// New reviews apply per database principal. Legacy instance-level
		// reviews remain in security_reviews and are exposed as historical
		// metadata, but cannot mark all current principals as reviewed.
		if len(row.Principals) == 0 && row.Review.Due {
			result.Summary.DatabaseDue++
		}
		for idx := range row.Principals {
			p := &row.Principals[idx]
			p.Review = reviewFor(reviews, row.VMID, "database_principal", securityDBPrincipalReviewKey(row.ID, *p), 6)
			if p.Review.Due {
				result.Summary.DatabaseDue++
			}
			privileged := p.Superuser || p.CreateRole || p.CreateDB || p.Replication
			for _, role := range p.Roles {
				switch strings.ToLower(strings.TrimSpace(role)) {
				case "sysadmin", "securityadmin", "serveradmin", "db_owner", "db_securityadmin":
					privileged = true
				}
			}
			if privileged {
				result.Summary.DatabasePrivileged++
			}
		}
		for _, group := range row.GrantReviews {
			if group.Review.Due {
				result.Summary.DatabaseGrantsDue++
				result.Summary.DatabaseDue++
			}
		}
		if strings.EqualFold(row.Engine, "postgresql") {
			for _, rule := range row.HBARules {
				if rule.Review.Due {
					result.Summary.DatabaseHBADue++
					result.Summary.DatabaseDue++
				}
			}
		}
		result.Databases = append(result.Databases, row)
	}
	return rows.Err()
}

func webAllowAll(rule securityWebRule) bool {
	if !strings.EqualFold(strings.TrimSpace(rule.Action), "allow") {
		return false
	}
	s := strings.ToLower(strings.TrimSpace(rule.Source))
	return s == "all" || s == "0.0.0.0/0" || s == "::/0"
}

func (a *App) loadSecurityWeb(ctx context.Context, reviews map[string]securityReview, result *securityResponse, onlyVMID int64) error {
	query := `SELECT ws.id,ws.vm_id,vm.name,ws.engine,ws.name,ws.server_names_json,ws.config_file,COALESCE(ws.access_control_json,'[]') FROM web_sites ws JOIN virtual_machines vm ON vm.id=ws.vm_id WHERE ws.present=1 AND vm.retired=0`
	args := []any{}
	if onlyVMID > 0 {
		query += ` AND ws.vm_id=?`
		args = append(args, onlyVMID)
	}
	query += ` ORDER BY vm.name,ws.engine,ws.name,ws.id`
	rows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var row securityWebSite
		var namesRaw, accessRaw []byte
		if err := rows.Scan(&row.ID, &row.VMID, &row.VMName, &row.Engine, &row.Name, &namesRaw, &row.ConfigFile, &accessRaw); err != nil {
			return err
		}
		_ = json.Unmarshal(namesRaw, &row.ServerNames)
		_ = json.Unmarshal(accessRaw, &row.Rules)
		for i := range row.Rules {
			row.Rules[i].Warning = webAllowAll(row.Rules[i])
			if row.Rules[i].Warning {
				result.Summary.WebAllowAll++
			}
		}
		row.Review = reviewFor(reviews, row.VMID, "web", strconv.FormatInt(row.ID, 10), 12)
		result.Summary.WebSites++
		result.Summary.WebRules += len(row.Rules)
		if row.Review.Due {
			result.Summary.WebDue++
		}
		result.WebSites = append(result.WebSites, row)
	}
	return rows.Err()
}

type securityReviewInput struct {
	VMID           int64  `json:"vm_id"`
	ResourceType   string `json:"resource_type"`
	ResourceKey    string `json:"resource_key"`
	IntervalMonths int    `json:"interval_months"`
	Justified      bool   `json:"justified"`
	Notes          string `json:"notes"`
}

func (a *App) updateSecurityReview(w http.ResponseWriter, r *http.Request) {
	var in securityReviewInput
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	in.ResourceType = strings.ToLower(strings.TrimSpace(in.ResourceType))
	in.ResourceKey = strings.TrimSpace(in.ResourceKey)
	in.Notes = strings.TrimSpace(in.Notes)
	if in.VMID < 1 || in.ResourceKey == "" {
		badRequest(w, errors.New("vm_id și resource_key sunt obligatorii"))
		return
	}
	if in.ResourceType != "vm_account" && in.ResourceType != "database" && in.ResourceType != "database_principal" && in.ResourceType != "web" && in.ResourceType != "firewall" && in.ResourceType != "database_grants" && in.ResourceType != "database_hba" {
		badRequest(w, errors.New("resource_type invalid"))
		return
	}
	if in.ResourceType == "database_principal" {
		parts := strings.Split(in.ResourceKey, ":")
		if len(parts) != 3 || parts[0] != "dbp" || len(parts[2]) != 64 {
			badRequest(w, errors.New("resource_key pentru principal DB invalid"))
			return
		}
		if _, err := strconv.ParseInt(parts[1], 10, 64); err != nil {
			badRequest(w, errors.New("instanță DB invalidă"))
			return
		}
		if _, err := hex.DecodeString(parts[2]); err != nil {
			badRequest(w, errors.New("hash principal DB invalid"))
			return
		}
	}
	if in.ResourceType == "database_principal" {
		// The key must refer to a currently discovered principal on this VM.
		// A caller must not fabricate arbitrary principal review records.
		parts := strings.Split(in.ResourceKey, ":")
		instanceID, _ := strconv.ParseInt(parts[1], 10, 64)
		var accessJSON []byte
		err := a.DB.QueryRowContext(r.Context(), `SELECT access_json FROM database_instances WHERE id=? AND vm_id=? AND present=1`, instanceID, in.VMID).Scan(&accessJSON)
		if err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				badRequest(w, errors.New("instanța DB nu aparține VM-ului sau nu este prezentă"))
			} else {
				respond(w, nil, err)
			}
			return
		}
		var snapshot struct {
			Principals []securityDBPrincipal `json:"principals"`
		}
		if err := json.Unmarshal(accessJSON, &snapshot); err != nil {
			respond(w, nil, err)
			return
		}
		matched := false
		for _, p := range snapshot.Principals {
			if securityDBPrincipalReviewKey(instanceID, p) == in.ResourceKey {
				matched = true
				break
			}
		}
		if !matched {
			badRequest(w, errors.New("principalul DB nu există în inventarul curent al instanței"))
			return
		}
	}
	if in.ResourceType == "database_grants" || in.ResourceType == "database_hba" {
		parts := strings.Split(in.ResourceKey, ":")
		prefix := "dbg"
		if in.ResourceType == "database_hba" {
			prefix = "dbh"
		}
		if len(parts) != 3 || parts[0] != prefix || len(parts[2]) != 64 {
			badRequest(w, errors.New("cheie review DB invalidă"))
			return
		}
		id, parseErr := strconv.ParseInt(parts[1], 10, 64)
		if parseErr != nil || id < 1 {
			badRequest(w, errors.New("instanță DB invalidă"))
			return
		}
		if _, parseErr = hex.DecodeString(parts[2]); parseErr != nil {
			badRequest(w, errors.New("hash review DB invalid"))
			return
		}
		var raw []byte
		if err := a.DB.QueryRowContext(r.Context(), `SELECT access_json FROM database_instances WHERE id=? AND vm_id=? AND present=1`, id, in.VMID).Scan(&raw); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				badRequest(w, errors.New("instanța DB nu aparține VM-ului"))
			} else {
				respond(w, nil, err)
			}
			return
		}
		var access struct {
			Privileges []securityDBPrivilege `json:"privileges"`
			HBARules   []securityHBARule     `json:"hba_rules"`
		}
		if err := json.Unmarshal(raw, &access); err != nil {
			respond(w, nil, err)
			return
		}
		found := false
		if in.ResourceType == "database_grants" {
			for _, grant := range access.Privileges {
				if securityDBGrantReviewKey(id, grant.Principal, grant.Host) == in.ResourceKey {
					found = true
					break
				}
			}
		} else {
			for _, rule := range access.HBARules {
				if securityDBHBAReviewKey(id, rule) == in.ResourceKey {
					found = true
					break
				}
			}
		}
		if !found {
			badRequest(w, errors.New("obiectul nu mai există în inventarul curent"))
			return
		}
	}
	if in.IntervalMonths != 6 && in.IntervalMonths != 12 {
		badRequest(w, errors.New("interval_months trebuie să fie 6 sau 12"))
		return
	}
	if len(in.Notes) > 2000 {
		in.Notes = in.Notes[:2000]
	}
	u, _ := auth.UserFromContext(r.Context())
	now := time.Now().UTC()
	next := now.AddDate(0, in.IntervalMonths, 0)
	_, err := a.DB.ExecContext(r.Context(), `INSERT INTO security_reviews(vm_id,resource_type,resource_key,interval_months,justified,notes,reviewed_at,next_review_at,reviewed_by) VALUES(?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE interval_months=VALUES(interval_months),justified=VALUES(justified),notes=VALUES(notes),reviewed_at=VALUES(reviewed_at),next_review_at=VALUES(next_review_at),reviewed_by=VALUES(reviewed_by)`, in.VMID, in.ResourceType, in.ResourceKey, in.IntervalMonths, in.Justified, in.Notes, now, next, u.ID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "security.access.review", "security_review", fmt.Sprintf("%d:%s:%s", in.VMID, in.ResourceType, in.ResourceKey), "success", map[string]any{"vm_id": in.VMID, "resource_type": in.ResourceType, "resource_key": in.ResourceKey, "interval_months": in.IntervalMonths, "justified": in.Justified})
	reviews, err := a.loadSecurityReviews(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	v := reviewFor(reviews, in.VMID, in.ResourceType, in.ResourceKey, in.IntervalMonths)
	respond(w, v, nil)
}
