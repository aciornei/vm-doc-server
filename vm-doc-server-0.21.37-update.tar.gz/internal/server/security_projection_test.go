package server

import "testing"

func TestSecurityProjectionOverviewKeepsSummaryAndOnlySlimRelevantItems(t *testing.T) {
	result := securityResponse{
		Summary: securitySummary{DatabasePrivileges: 20000, DatabaseInstances: 1, Accounts: 2},
		Accounts: []securityAccount{
			{VMID: 1, Username: "admin", Review: securityReview{Due: true}},
			{VMID: 1, Username: "other", Review: securityReview{Due: false}},
		},
		Databases: []securityDatabase{{ID: 7, VMID: 1, VMName: "vm", Engine: "postgresql", Product: "PostgreSQL", Review: securityReview{Due: true}, Privileges: make([]securityDBPrivilege, 20000), HBARules: []securityHBARule{{Warning: true}}}},
		WebSites:  []securityWebSite{{ID: 9, VMID: 1, Name: "site", Review: securityReview{Due: true}, Rules: []securityWebRule{{Warning: true}}}},
	}
	projectSecurityResponse(&result, "overview")
	if result.Summary.DatabasePrivileges != 20000 || len(result.Databases) != 1 || len(result.Databases[0].Privileges) != 0 || len(result.Databases[0].HBARules) != 1 || len(result.WebSites) != 1 || len(result.WebSites[0].Rules) != 1 || len(result.PasswordPolicies) != 0 {
		t.Fatalf("invalid overview projection: %#v", result)
	}
}

func TestSecurityProjectionSectionsAndLegacy(t *testing.T) {
	makeValue := func() securityResponse {
		return securityResponse{Accounts: []securityAccount{{}}, Databases: []securityDatabase{{}}, WebSites: []securityWebSite{{}}}
	}
	for _, test := range []struct {
		section                  string
		accounts, databases, web int
	}{
		{"accounts", 1, 0, 0}, {"databases", 0, 1, 0}, {"web", 0, 0, 1}, {"", 1, 1, 1}, {"unknown", 1, 1, 1},
	} {
		v := makeValue()
		projectSecurityResponse(&v, test.section)
		if len(v.Accounts) != test.accounts || len(v.Databases) != test.databases || len(v.WebSites) != test.web {
			t.Errorf("section %q not projected", test.section)
		}
	}
}
