# Indexul release-urilor istorice VM-DOC Server

Actualizat pentru 0.21.37; intrările istorice 0.21.20–0.21.24 nu au perechi complete în acest index. **119** fișiere UPGRADE și **119** fișiere RELEASE-NOTES în arhiva istorică.

| Versiune | Upgrade | Release notes |
|---|---|---|
| `0.21.37` | [UPGRADE-0.21.37.md](upgrades/UPGRADE-0.21.37.md) | [RELEASE-NOTES-0.21.37.txt](release-notes/RELEASE-NOTES-0.21.37.txt) |
| `0.21.36` | [UPGRADE-0.21.36.md](upgrades/UPGRADE-0.21.36.md) | [RELEASE-NOTES-0.21.36.txt](release-notes/RELEASE-NOTES-0.21.36.txt) |
| `0.21.35` | [UPGRADE-0.21.35.md](upgrades/UPGRADE-0.21.35.md) | [RELEASE-NOTES-0.21.35.txt](release-notes/RELEASE-NOTES-0.21.35.txt) |
| `0.21.32` | [UPGRADE-0.21.32.md](upgrades/UPGRADE-0.21.32.md) | [RELEASE-NOTES-0.21.32.txt](release-notes/RELEASE-NOTES-0.21.32.txt) |
| `0.21.29` | [UPGRADE-0.21.29.md](upgrades/UPGRADE-0.21.29.md) | [RELEASE-NOTES-0.21.29.txt](release-notes/RELEASE-NOTES-0.21.29.txt) |
| `0.21.28` | [UPGRADE-0.21.28.md](upgrades/UPGRADE-0.21.28.md) | [RELEASE-NOTES-0.21.28.txt](release-notes/RELEASE-NOTES-0.21.28.txt) |
| `0.21.27` | [UPGRADE-0.21.27.md](upgrades/UPGRADE-0.21.27.md) | [RELEASE-NOTES-0.21.27.txt](release-notes/RELEASE-NOTES-0.21.27.txt) |
| `0.21.26` | [UPGRADE-0.21.26.md](upgrades/UPGRADE-0.21.26.md) | [RELEASE-NOTES-0.21.26.txt](release-notes/RELEASE-NOTES-0.21.26.txt) |
| `0.21.25` | [UPGRADE-0.21.25.md](upgrades/UPGRADE-0.21.25.md) | [RELEASE-NOTES-0.21.25.txt](release-notes/RELEASE-NOTES-0.21.25.txt) |
| `0.21.19` | [UPGRADE-0.21.19.md](upgrades/UPGRADE-0.21.19.md) | [RELEASE-NOTES-0.21.19.txt](release-notes/RELEASE-NOTES-0.21.19.txt) |
| `0.21.18` | [UPGRADE-0.21.18.md](upgrades/UPGRADE-0.21.18.md) | [RELEASE-NOTES-0.21.18.txt](release-notes/RELEASE-NOTES-0.21.18.txt) |
| `0.21.17` | [UPGRADE-0.21.17.md](upgrades/UPGRADE-0.21.17.md) | [RELEASE-NOTES-0.21.17.txt](release-notes/RELEASE-NOTES-0.21.17.txt) |
| `0.21.16` | [UPGRADE-0.21.16.md](upgrades/UPGRADE-0.21.16.md) | [RELEASE-NOTES-0.21.16.txt](release-notes/RELEASE-NOTES-0.21.16.txt) |
| `0.21.15` | [UPGRADE-0.21.15.md](upgrades/UPGRADE-0.21.15.md) | [RELEASE-NOTES-0.21.15.txt](release-notes/RELEASE-NOTES-0.21.15.txt) |
| `0.21.14` | [UPGRADE-0.21.14.md](upgrades/UPGRADE-0.21.14.md) | [RELEASE-NOTES-0.21.14.txt](release-notes/RELEASE-NOTES-0.21.14.txt) |
| `0.21.13` | [UPGRADE-0.21.13.md](upgrades/UPGRADE-0.21.13.md) | [RELEASE-NOTES-0.21.13.txt](release-notes/RELEASE-NOTES-0.21.13.txt) |
| `0.21.12` | [UPGRADE-0.21.12.md](upgrades/UPGRADE-0.21.12.md) | [RELEASE-NOTES-0.21.12.txt](release-notes/RELEASE-NOTES-0.21.12.txt) |
| `0.21.11` | [UPGRADE-0.21.11.md](upgrades/UPGRADE-0.21.11.md) | [RELEASE-NOTES-0.21.11.txt](release-notes/RELEASE-NOTES-0.21.11.txt) |
| `0.21.10` | [UPGRADE-0.21.10.md](upgrades/UPGRADE-0.21.10.md) | [RELEASE-NOTES-0.21.10.txt](release-notes/RELEASE-NOTES-0.21.10.txt) |
| `0.21.9` | [UPGRADE-0.21.9.md](upgrades/UPGRADE-0.21.9.md) | [RELEASE-NOTES-0.21.9.txt](release-notes/RELEASE-NOTES-0.21.9.txt) |
| `0.21.8` | [UPGRADE-0.21.8.md](upgrades/UPGRADE-0.21.8.md) | [RELEASE-NOTES-0.21.8.txt](release-notes/RELEASE-NOTES-0.21.8.txt) |
| `0.21.7` | [UPGRADE-0.21.7.md](upgrades/UPGRADE-0.21.7.md) | [RELEASE-NOTES-0.21.7.txt](release-notes/RELEASE-NOTES-0.21.7.txt) |
| `0.21.6` | [UPGRADE-0.21.6.md](upgrades/UPGRADE-0.21.6.md) | [RELEASE-NOTES-0.21.6.txt](release-notes/RELEASE-NOTES-0.21.6.txt) |
| `0.21.5` | [UPGRADE-0.21.5.md](upgrades/UPGRADE-0.21.5.md) | [RELEASE-NOTES-0.21.5.txt](release-notes/RELEASE-NOTES-0.21.5.txt) |
| `0.21.4` | [UPGRADE-0.21.4.md](upgrades/UPGRADE-0.21.4.md) | [RELEASE-NOTES-0.21.4.txt](release-notes/RELEASE-NOTES-0.21.4.txt) |
| `0.21.3` | [UPGRADE-0.21.3.md](upgrades/UPGRADE-0.21.3.md) | [RELEASE-NOTES-0.21.3.txt](release-notes/RELEASE-NOTES-0.21.3.txt) |
| `0.21.2` | [UPGRADE-0.21.2.md](upgrades/UPGRADE-0.21.2.md) | [RELEASE-NOTES-0.21.2.txt](release-notes/RELEASE-NOTES-0.21.2.txt) |
| `0.21.1` | [UPGRADE-0.21.1.md](upgrades/UPGRADE-0.21.1.md) | [RELEASE-NOTES-0.21.1.txt](release-notes/RELEASE-NOTES-0.21.1.txt) |
| `0.21.0` | [UPGRADE-0.21.0.md](upgrades/UPGRADE-0.21.0.md) | [RELEASE-NOTES-0.21.0.txt](release-notes/RELEASE-NOTES-0.21.0.txt) |
| `0.20.99` | [UPGRADE-0.20.99.md](upgrades/UPGRADE-0.20.99.md) | [RELEASE-NOTES-0.20.99.txt](release-notes/RELEASE-NOTES-0.20.99.txt) |
| `0.20.98` | [UPGRADE-0.20.98.md](upgrades/UPGRADE-0.20.98.md) | [RELEASE-NOTES-0.20.98.txt](release-notes/RELEASE-NOTES-0.20.98.txt) |
| `0.20.97` | [UPGRADE-0.20.97.md](upgrades/UPGRADE-0.20.97.md) | [RELEASE-NOTES-0.20.97.txt](release-notes/RELEASE-NOTES-0.20.97.txt) |
| `0.20.96` | [UPGRADE-0.20.96.md](upgrades/UPGRADE-0.20.96.md) | [RELEASE-NOTES-0.20.96.txt](release-notes/RELEASE-NOTES-0.20.96.txt) |
| `0.20.95` | [UPGRADE-0.20.95.md](upgrades/UPGRADE-0.20.95.md) | [RELEASE-NOTES-0.20.95.txt](release-notes/RELEASE-NOTES-0.20.95.txt) |
| `0.20.94` | [UPGRADE-0.20.94.md](upgrades/UPGRADE-0.20.94.md) | [RELEASE-NOTES-0.20.94.txt](release-notes/RELEASE-NOTES-0.20.94.txt) |
| `0.20.93` | [UPGRADE-0.20.93.md](upgrades/UPGRADE-0.20.93.md) | [RELEASE-NOTES-0.20.93.txt](release-notes/RELEASE-NOTES-0.20.93.txt) |
| `0.20.92` | [UPGRADE-0.20.92.md](upgrades/UPGRADE-0.20.92.md) | [RELEASE-NOTES-0.20.92.txt](release-notes/RELEASE-NOTES-0.20.92.txt) |
| `0.20.91` | [UPGRADE-0.20.91.md](upgrades/UPGRADE-0.20.91.md) | [RELEASE-NOTES-0.20.91.txt](release-notes/RELEASE-NOTES-0.20.91.txt) |
| `0.20.90` | [UPGRADE-0.20.90.md](upgrades/UPGRADE-0.20.90.md) | [RELEASE-NOTES-0.20.90.txt](release-notes/RELEASE-NOTES-0.20.90.txt) |
| `0.20.89` | [UPGRADE-0.20.89.md](upgrades/UPGRADE-0.20.89.md) | [RELEASE-NOTES-0.20.89.txt](release-notes/RELEASE-NOTES-0.20.89.txt) |
| `0.20.88` | [UPGRADE-0.20.88.md](upgrades/UPGRADE-0.20.88.md) | [RELEASE-NOTES-0.20.88.txt](release-notes/RELEASE-NOTES-0.20.88.txt) |
| `0.20.87` | [UPGRADE-0.20.87.md](upgrades/UPGRADE-0.20.87.md) | [RELEASE-NOTES-0.20.87.txt](release-notes/RELEASE-NOTES-0.20.87.txt) |
| `0.20.86` | [UPGRADE-0.20.86.md](upgrades/UPGRADE-0.20.86.md) | [RELEASE-NOTES-0.20.86.txt](release-notes/RELEASE-NOTES-0.20.86.txt) |
| `0.20.85` | [UPGRADE-0.20.85.md](upgrades/UPGRADE-0.20.85.md) | [RELEASE-NOTES-0.20.85.txt](release-notes/RELEASE-NOTES-0.20.85.txt) |
| `0.20.84` | [UPGRADE-0.20.84.md](upgrades/UPGRADE-0.20.84.md) | [RELEASE-NOTES-0.20.84.txt](release-notes/RELEASE-NOTES-0.20.84.txt) |
| `0.20.83` | [UPGRADE-0.20.83.md](upgrades/UPGRADE-0.20.83.md) | [RELEASE-NOTES-0.20.83.txt](release-notes/RELEASE-NOTES-0.20.83.txt) |
| `0.20.82` | [UPGRADE-0.20.82.md](upgrades/UPGRADE-0.20.82.md) | [RELEASE-NOTES-0.20.82.txt](release-notes/RELEASE-NOTES-0.20.82.txt) |
| `0.20.81` | [UPGRADE-0.20.81.md](upgrades/UPGRADE-0.20.81.md) | [RELEASE-NOTES-0.20.81.txt](release-notes/RELEASE-NOTES-0.20.81.txt) |
| `0.20.80` | [UPGRADE-0.20.80.md](upgrades/UPGRADE-0.20.80.md) | [RELEASE-NOTES-0.20.80.txt](release-notes/RELEASE-NOTES-0.20.80.txt) |
| `0.20.79` | [UPGRADE-0.20.79.md](upgrades/UPGRADE-0.20.79.md) | [RELEASE-NOTES-0.20.79.txt](release-notes/RELEASE-NOTES-0.20.79.txt) |
| `0.20.78` | [UPGRADE-0.20.78.md](upgrades/UPGRADE-0.20.78.md) | [RELEASE-NOTES-0.20.78.txt](release-notes/RELEASE-NOTES-0.20.78.txt) |
| `0.20.77` | [UPGRADE-0.20.77.md](upgrades/UPGRADE-0.20.77.md) | [RELEASE-NOTES-0.20.77.txt](release-notes/RELEASE-NOTES-0.20.77.txt) |
| `0.20.76` | [UPGRADE-0.20.76.md](upgrades/UPGRADE-0.20.76.md) | [RELEASE-NOTES-0.20.76.txt](release-notes/RELEASE-NOTES-0.20.76.txt) |
| `0.20.75` | [UPGRADE-0.20.75.md](upgrades/UPGRADE-0.20.75.md) | [RELEASE-NOTES-0.20.75.txt](release-notes/RELEASE-NOTES-0.20.75.txt) |
| `0.20.74` | [UPGRADE-0.20.74.md](upgrades/UPGRADE-0.20.74.md) | [RELEASE-NOTES-0.20.74.txt](release-notes/RELEASE-NOTES-0.20.74.txt) |
| `0.20.73` | [UPGRADE-0.20.73.md](upgrades/UPGRADE-0.20.73.md) | [RELEASE-NOTES-0.20.73.txt](release-notes/RELEASE-NOTES-0.20.73.txt) |
| `0.20.72` | [UPGRADE-0.20.72.md](upgrades/UPGRADE-0.20.72.md) | [RELEASE-NOTES-0.20.72.txt](release-notes/RELEASE-NOTES-0.20.72.txt) |
| `0.20.71` | [UPGRADE-0.20.71.md](upgrades/UPGRADE-0.20.71.md) | [RELEASE-NOTES-0.20.71.txt](release-notes/RELEASE-NOTES-0.20.71.txt) |
| `0.20.70` | [UPGRADE-0.20.70.md](upgrades/UPGRADE-0.20.70.md) | [RELEASE-NOTES-0.20.70.txt](release-notes/RELEASE-NOTES-0.20.70.txt) |
| `0.20.69` | [UPGRADE-0.20.69.md](upgrades/UPGRADE-0.20.69.md) | [RELEASE-NOTES-0.20.69.txt](release-notes/RELEASE-NOTES-0.20.69.txt) |
| `0.20.68` | [UPGRADE-0.20.68.md](upgrades/UPGRADE-0.20.68.md) | [RELEASE-NOTES-0.20.68.txt](release-notes/RELEASE-NOTES-0.20.68.txt) |
| `0.20.67` | [UPGRADE-0.20.67.md](upgrades/UPGRADE-0.20.67.md) | [RELEASE-NOTES-0.20.67.txt](release-notes/RELEASE-NOTES-0.20.67.txt) |
| `0.20.66` | [UPGRADE-0.20.66.md](upgrades/UPGRADE-0.20.66.md) | [RELEASE-NOTES-0.20.66.txt](release-notes/RELEASE-NOTES-0.20.66.txt) |
| `0.20.65` | [UPGRADE-0.20.65.md](upgrades/UPGRADE-0.20.65.md) | [RELEASE-NOTES-0.20.65.txt](release-notes/RELEASE-NOTES-0.20.65.txt) |
| `0.20.64` | [UPGRADE-0.20.64.md](upgrades/UPGRADE-0.20.64.md) | [RELEASE-NOTES-0.20.64.txt](release-notes/RELEASE-NOTES-0.20.64.txt) |
| `0.20.63` | [UPGRADE-0.20.63.md](upgrades/UPGRADE-0.20.63.md) | [RELEASE-NOTES-0.20.63.txt](release-notes/RELEASE-NOTES-0.20.63.txt) |
| `0.20.62` | [UPGRADE-0.20.62.md](upgrades/UPGRADE-0.20.62.md) | [RELEASE-NOTES-0.20.62.txt](release-notes/RELEASE-NOTES-0.20.62.txt) |
| `0.20.61` | [UPGRADE-0.20.61.md](upgrades/UPGRADE-0.20.61.md) | [RELEASE-NOTES-0.20.61.txt](release-notes/RELEASE-NOTES-0.20.61.txt) |
| `0.20.60` | [UPGRADE-0.20.60.md](upgrades/UPGRADE-0.20.60.md) | [RELEASE-NOTES-0.20.60.txt](release-notes/RELEASE-NOTES-0.20.60.txt) |
| `0.20.59` | [UPGRADE-0.20.59.md](upgrades/UPGRADE-0.20.59.md) | [RELEASE-NOTES-0.20.59.txt](release-notes/RELEASE-NOTES-0.20.59.txt) |
| `0.20.58` | [UPGRADE-0.20.58.md](upgrades/UPGRADE-0.20.58.md) | [RELEASE-NOTES-0.20.58.txt](release-notes/RELEASE-NOTES-0.20.58.txt) |
| `0.20.57` | [UPGRADE-0.20.57.md](upgrades/UPGRADE-0.20.57.md) | [RELEASE-NOTES-0.20.57.txt](release-notes/RELEASE-NOTES-0.20.57.txt) |
| `0.20.56` | [UPGRADE-0.20.56.md](upgrades/UPGRADE-0.20.56.md) | [RELEASE-NOTES-0.20.56.txt](release-notes/RELEASE-NOTES-0.20.56.txt) |
| `0.20.55` | [UPGRADE-0.20.55.md](upgrades/UPGRADE-0.20.55.md) | [RELEASE-NOTES-0.20.55.txt](release-notes/RELEASE-NOTES-0.20.55.txt) |
| `0.20.54` | [UPGRADE-0.20.54.md](upgrades/UPGRADE-0.20.54.md) | [RELEASE-NOTES-0.20.54.txt](release-notes/RELEASE-NOTES-0.20.54.txt) |
| `0.20.53` | [UPGRADE-0.20.53.md](upgrades/UPGRADE-0.20.53.md) | [RELEASE-NOTES-0.20.53.txt](release-notes/RELEASE-NOTES-0.20.53.txt) |
| `0.20.52` | [UPGRADE-0.20.52.md](upgrades/UPGRADE-0.20.52.md) | [RELEASE-NOTES-0.20.52.txt](release-notes/RELEASE-NOTES-0.20.52.txt) |
| `0.20.51` | [UPGRADE-0.20.51.md](upgrades/UPGRADE-0.20.51.md) | [RELEASE-NOTES-0.20.51.txt](release-notes/RELEASE-NOTES-0.20.51.txt) |
| `0.20.50` | [UPGRADE-0.20.50.md](upgrades/UPGRADE-0.20.50.md) | [RELEASE-NOTES-0.20.50.txt](release-notes/RELEASE-NOTES-0.20.50.txt) |
| `0.20.49` | [UPGRADE-0.20.49.md](upgrades/UPGRADE-0.20.49.md) | [RELEASE-NOTES-0.20.49.txt](release-notes/RELEASE-NOTES-0.20.49.txt) |
| `0.20.48` | [UPGRADE-0.20.48.md](upgrades/UPGRADE-0.20.48.md) | [RELEASE-NOTES-0.20.48.txt](release-notes/RELEASE-NOTES-0.20.48.txt) |
| `0.20.47` | [UPGRADE-0.20.47.md](upgrades/UPGRADE-0.20.47.md) | [RELEASE-NOTES-0.20.47.txt](release-notes/RELEASE-NOTES-0.20.47.txt) |
| `0.20.46` | [UPGRADE-0.20.46.md](upgrades/UPGRADE-0.20.46.md) | [RELEASE-NOTES-0.20.46.txt](release-notes/RELEASE-NOTES-0.20.46.txt) |
| `0.20.45` | [UPGRADE-0.20.45.md](upgrades/UPGRADE-0.20.45.md) | [RELEASE-NOTES-0.20.45.txt](release-notes/RELEASE-NOTES-0.20.45.txt) |
| `0.20.44` | [UPGRADE-0.20.44.md](upgrades/UPGRADE-0.20.44.md) | — |
| `0.20.43` | [UPGRADE-0.20.43.md](upgrades/UPGRADE-0.20.43.md) | [RELEASE-NOTES-0.20.43.txt](release-notes/RELEASE-NOTES-0.20.43.txt) |
| `0.20.42` | [UPGRADE-0.20.42.md](upgrades/UPGRADE-0.20.42.md) | [RELEASE-NOTES-0.20.42.txt](release-notes/RELEASE-NOTES-0.20.42.txt) |
| `0.20.41` | [UPGRADE-0.20.41.md](upgrades/UPGRADE-0.20.41.md) | [RELEASE-NOTES-0.20.41.txt](release-notes/RELEASE-NOTES-0.20.41.txt) |
| `0.20.40` | [UPGRADE-0.20.40.md](upgrades/UPGRADE-0.20.40.md) | [RELEASE-NOTES-0.20.40.txt](release-notes/RELEASE-NOTES-0.20.40.txt) |
| `0.20.39` | [UPGRADE-0.20.39.md](upgrades/UPGRADE-0.20.39.md) | [RELEASE-NOTES-0.20.39.txt](release-notes/RELEASE-NOTES-0.20.39.txt) |
| `0.20.38` | [UPGRADE-0.20.38.md](upgrades/UPGRADE-0.20.38.md) | [RELEASE-NOTES-0.20.38.txt](release-notes/RELEASE-NOTES-0.20.38.txt) |
| `0.20.37` | [UPGRADE-0.20.37.md](upgrades/UPGRADE-0.20.37.md) | [RELEASE-NOTES-0.20.37.txt](release-notes/RELEASE-NOTES-0.20.37.txt) |
| `0.20.36` | [UPGRADE-0.20.36.md](upgrades/UPGRADE-0.20.36.md) | [RELEASE-NOTES-0.20.36.txt](release-notes/RELEASE-NOTES-0.20.36.txt) |
| `0.20.35` | [UPGRADE-0.20.35.md](upgrades/UPGRADE-0.20.35.md) | [RELEASE-NOTES-0.20.35.txt](release-notes/RELEASE-NOTES-0.20.35.txt) |
| `0.20.34` | [UPGRADE-0.20.34.md](upgrades/UPGRADE-0.20.34.md) | [RELEASE-NOTES-0.20.34.txt](release-notes/RELEASE-NOTES-0.20.34.txt) |
| `0.20.33` | [UPGRADE-0.20.33.md](upgrades/UPGRADE-0.20.33.md) | [RELEASE-NOTES-0.20.33.txt](release-notes/RELEASE-NOTES-0.20.33.txt) |
| `0.20.32` | [UPGRADE-0.20.32.md](upgrades/UPGRADE-0.20.32.md) | [RELEASE-NOTES-0.20.32.txt](release-notes/RELEASE-NOTES-0.20.32.txt) |
| `0.20.31` | [UPGRADE-0.20.31.md](upgrades/UPGRADE-0.20.31.md) | [RELEASE-NOTES-0.20.31.txt](release-notes/RELEASE-NOTES-0.20.31.txt) |
| `0.20.30` | [UPGRADE-0.20.30.md](upgrades/UPGRADE-0.20.30.md) | [RELEASE-NOTES-0.20.30.txt](release-notes/RELEASE-NOTES-0.20.30.txt) |
| `0.20.29` | [UPGRADE-0.20.29.md](upgrades/UPGRADE-0.20.29.md) | [RELEASE-NOTES-0.20.29.txt](release-notes/RELEASE-NOTES-0.20.29.txt) |
| `0.20.28` | [UPGRADE-0.20.28.md](upgrades/UPGRADE-0.20.28.md) | [RELEASE-NOTES-0.20.28.txt](release-notes/RELEASE-NOTES-0.20.28.txt) |
| `0.20.27` | [UPGRADE-0.20.27.md](upgrades/UPGRADE-0.20.27.md) | [RELEASE-NOTES-0.20.27.txt](release-notes/RELEASE-NOTES-0.20.27.txt) |
| `0.20.26` | [UPGRADE-0.20.26.md](upgrades/UPGRADE-0.20.26.md) | [RELEASE-NOTES-0.20.26.txt](release-notes/RELEASE-NOTES-0.20.26.txt) |
| `0.20.25` | [UPGRADE-0.20.25.md](upgrades/UPGRADE-0.20.25.md) | [RELEASE-NOTES-0.20.25.txt](release-notes/RELEASE-NOTES-0.20.25.txt) |
| `0.20.24` | [UPGRADE-0.20.24.md](upgrades/UPGRADE-0.20.24.md) | [RELEASE-NOTES-0.20.24.txt](release-notes/RELEASE-NOTES-0.20.24.txt) |
| `0.20.23` | [UPGRADE-0.20.23.md](upgrades/UPGRADE-0.20.23.md) | [RELEASE-NOTES-0.20.23.txt](release-notes/RELEASE-NOTES-0.20.23.txt) |
| `0.20.22` | [UPGRADE-0.20.22.md](upgrades/UPGRADE-0.20.22.md) | [RELEASE-NOTES-0.20.22.txt](release-notes/RELEASE-NOTES-0.20.22.txt) |
| `0.20.21` | [UPGRADE-0.20.21.md](upgrades/UPGRADE-0.20.21.md) | [RELEASE-NOTES-0.20.21.txt](release-notes/RELEASE-NOTES-0.20.21.txt) |
| `0.20.20` | [UPGRADE-0.20.20.md](upgrades/UPGRADE-0.20.20.md) | [RELEASE-NOTES-0.20.20.txt](release-notes/RELEASE-NOTES-0.20.20.txt) |
| `0.20.19` | [UPGRADE-0.20.19.md](upgrades/UPGRADE-0.20.19.md) | [RELEASE-NOTES-0.20.19.txt](release-notes/RELEASE-NOTES-0.20.19.txt) |
| `0.20.18` | [UPGRADE-0.20.18.md](upgrades/UPGRADE-0.20.18.md) | [RELEASE-NOTES-0.20.18.txt](release-notes/RELEASE-NOTES-0.20.18.txt) |
| `0.20.17` | [UPGRADE-0.20.17.md](upgrades/UPGRADE-0.20.17.md) | [RELEASE-NOTES-0.20.17.txt](release-notes/RELEASE-NOTES-0.20.17.txt) |
| `0.20.16` | [UPGRADE-0.20.16.md](upgrades/UPGRADE-0.20.16.md) | [RELEASE-NOTES-0.20.16.txt](release-notes/RELEASE-NOTES-0.20.16.txt) |
| `0.20.15` | [UPGRADE-0.20.15.md](upgrades/UPGRADE-0.20.15.md) | [RELEASE-NOTES-0.20.15.txt](release-notes/RELEASE-NOTES-0.20.15.txt) |
| `0.20.14` | [UPGRADE-0.20.14.md](upgrades/UPGRADE-0.20.14.md) | [RELEASE-NOTES-0.20.14.txt](release-notes/RELEASE-NOTES-0.20.14.txt) |
| `0.20.13` | [UPGRADE-0.20.13.md](upgrades/UPGRADE-0.20.13.md) | [RELEASE-NOTES-0.20.13.txt](release-notes/RELEASE-NOTES-0.20.13.txt) |
| `0.20.12` | [UPGRADE-0.20.12.md](upgrades/UPGRADE-0.20.12.md) | [RELEASE-NOTES-0.20.12.txt](release-notes/RELEASE-NOTES-0.20.12.txt) |
| `0.20.11` | [UPGRADE-0.20.11.md](upgrades/UPGRADE-0.20.11.md) | [RELEASE-NOTES-0.20.11.txt](release-notes/RELEASE-NOTES-0.20.11.txt) |
| `0.20.10` | [UPGRADE-0.20.10.md](upgrades/UPGRADE-0.20.10.md) | [RELEASE-NOTES-0.20.10.txt](release-notes/RELEASE-NOTES-0.20.10.txt) |
| `0.20.9` | [UPGRADE-0.20.9.md](upgrades/UPGRADE-0.20.9.md) | [RELEASE-NOTES-0.20.9.txt](release-notes/RELEASE-NOTES-0.20.9.txt) |
| `0.20.8` | [UPGRADE-0.20.8.md](upgrades/UPGRADE-0.20.8.md) | [RELEASE-NOTES-0.20.8.txt](release-notes/RELEASE-NOTES-0.20.8.txt) |
| `0.20.7` | [UPGRADE-0.20.7.md](upgrades/UPGRADE-0.20.7.md) | [RELEASE-NOTES-0.20.7.txt](release-notes/RELEASE-NOTES-0.20.7.txt) |
| `0.20.6` | [UPGRADE-0.20.6.md](upgrades/UPGRADE-0.20.6.md) | [RELEASE-NOTES-0.20.6.txt](release-notes/RELEASE-NOTES-0.20.6.txt) |
| `0.20.5` | [UPGRADE-0.20.5.md](upgrades/UPGRADE-0.20.5.md) | [RELEASE-NOTES-0.20.5.txt](release-notes/RELEASE-NOTES-0.20.5.txt) |
| `0.20.4` | — | [RELEASE-NOTES-0.20.4.txt](release-notes/RELEASE-NOTES-0.20.4.txt) |

## Alte documente de validare
- [VERIFICATION-0.21.0.md](verification/VERIFICATION-0.21.0.md)
- [VERIFICATION-0.21.1.md](verification/VERIFICATION-0.21.1.md)
- [VERIFICATION-0.21.2.md](verification/VERIFICATION-0.21.2.md)

- 0.21.33: [Upgrade](upgrades/UPGRADE-0.21.33.md) · [Release notes](release-notes/RELEASE-NOTES-0.21.33.txt)

- 0.21.34: [Upgrade](upgrades/UPGRADE-0.21.34.md) · [Release notes](release-notes/RELEASE-NOTES-0.21.34.txt)

- 0.21.35: [Upgrade](upgrades/UPGRADE-0.21.35.md) · [Release notes](release-notes/RELEASE-NOTES-0.21.35.txt)
