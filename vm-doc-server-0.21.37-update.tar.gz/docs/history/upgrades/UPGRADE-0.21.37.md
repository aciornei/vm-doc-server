# VM-DOC Server 0.21.37 — Optimizare memorie browser

Bază: 0.21.36. Agent: 1.7.18. Fără migrare SQL.

## Modificări

- Security Dashboard/Conturi/Web nu mai descarcă toate granturile PostgreSQL; noul parametru opțional `section` limitează JSON-ul. `GET /api/v1/security` fără `section` și `?vm_id=` rămân compatibile.
- DB Grants: panoul se construiește doar la selectarea lui; la restrângerea utilizatorului sau grupului se eliberează nodurile DOM.
- Eliberare referințe vechi în cache-ul DB și Security; cache-ul de citire VM este limitat la 16 intrări cu TTL verificat la fiecare cerere.
- Search DB incremental, fără alocarea unui șir gigant pentru toate granturile.

## Upgrade offline

1. Fă backup la binarul/sursele 0.21.36 și la baza MariaDB înainte de rollout.
2. Aplică `vm-doc-server-0.21.37-update.tar.gz` peste COPIA surselor 0.21.36, fără a suprascrie vendor/, configurări sau secrete.
3. Verifică `cat VERSION` = `0.21.37`, apoi `bash scripts/cleanup-source-tree.sh --check`.
4. Execută pe mașina cu vendor/: `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build`.
5. Testează în staging Dashboard, Conturi, DB, Web, review individual/colectiv, granturi 20k+, Export Excel și 3 rezoluții. Profilare Chrome per tab înainte și după.

## Rollback

Restaurează binarul și sursele 0.21.36. Fără migrare SQL, datele de inventar și reviziile sunt neschimbate.

## Teste și limite

- JavaScript syntax OK; Chromium cu mock 20.000 grants / 40 users la 1595/1024/390 px OK; teste Go independente OK.
- `go test ./internal/server` și compilarea completă nu sunt testabile aici din cauza dependențelor Go indisponibile offline; MariaDB și profilarea browserului real sunt obligatorii înainte de PROD.
- Aceasta este o corecție țintită, nu garanția eliminării oricărei cauze externe a consumului Chrome (extensii, Bitdefender, alte taburi).
