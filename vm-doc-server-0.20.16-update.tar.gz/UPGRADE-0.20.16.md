# Upgrade vm-doc-server 0.20.15 → 0.20.16

## Ce se schimbă

0.20.16 leagă documentarea resurselor Docker / Baze de date / Web de asocierea arhitecturală a VM-ului cu serviciile interne.

Dacă alegi un proiect/serviciu pe un container Docker, o instanță/catalog de bază de date sau un site Web, acel serviciu devine criteriu de completare pentru VM. Pentru a satisface criteriul, aceeași VM trebuie să aibă o asociere în **Configurare servicii → Servicii interne și roluri tehnice** cu:

- domeniu arhitectural;
- categorie de serviciu;
- serviciul intern respectiv;
- layer;
- rol tehnic;
- tip soluție.

Serviciile sunt deduplicate: dacă același proiect este folosit de mai multe resurse tehnice, el contează o singură dată în procent.

## Migrare DB

Nu există migrare nouă în 0.20.16.

## Instalare

Peste arborele 0.20.15:

```bash
tar -xzf vm-doc-server-0.20.16-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.16
cd /usr/local/src/vm-doc-server-0.20.16
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

## Verificare funcțională

1. Alege un serviciu/proiect la un container Docker, o bază sau un site Web.
2. În Rezumat, procentul trebuie să adauge criteriul `Configurare serviciu: <nume>` și să îl arate necompletat.
3. Intră în fila Servicii: proiectul lipsă trebuie afișat în avertismentul de deasupra asocierilor.
4. Adaugă aceeași asociere VM–serviciu și completează domeniu, categorie, layer, rol tehnic și tip soluție.
5. Salvează: criteriul trebuie să devină îndeplinit și procentul să crească.
6. Dacă același proiect este folosit de mai multe resurse, trebuie să existe un singur criteriu pentru el.

Nu este necesar update de agent.
