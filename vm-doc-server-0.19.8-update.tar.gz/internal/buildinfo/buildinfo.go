package buildinfo

var (
	Version = "0.19.8-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
