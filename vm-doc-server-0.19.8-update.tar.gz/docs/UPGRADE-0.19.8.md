# Upgrade vm-doc-server 0.19.7 → 0.19.8

0.19.8 este un release de UI/UX pentru pagina Servicii. Nu modifică schema bazei de date și nu necesită upgrade de agent sau collector.

## Noutăți

- Editarea unui serviciu se face direct în fișa serviciului.
- `Detalii` are subtabs `General`, `Descriere`, `Scop și domeniu`, `Obiective`.
- Butonul `Editează` din catalog deschide fișa serviciului în `Detalii → General`; nu mai deschide dialogul vechi.
- Dialogul vechi rămâne doar pentru crearea unui serviciu nou.
- Filtrele catalogului Servicii folosesc același layout responsive ca Inventar VM și nu mai suprapun listbox-urile peste butoane.
- Căutarea păstrează focusul în timp ce filtrează.

## Instalare

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.7 vm-doc-server-0.19.8
tar -xzf /home/andrei.ciornei/vm-doc-server-0.19.8-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.8
cd /usr/local/src/vm-doc-server-0.19.8
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

Collectorul nu trebuie reinstalat. După upgrade folosiți `Ctrl+F5` pentru a încărca JavaScript/CSS 0.19.8.

## Verificări rapide

1. `/version` trebuie să raporteze `0.19.8`.
2. În Servicii, butonul `Editează` trebuie să deschidă fișa serviciului.
3. `Detalii` trebuie să aibă cele 4 subtabs noi.
4. Salvarea din fiecare subtab trebuie să păstreze celelalte câmpuri ale serviciului.
5. Filtrele din catalog nu trebuie să se suprapună, inclusiv la lățimi intermediare ale ferestrei.
