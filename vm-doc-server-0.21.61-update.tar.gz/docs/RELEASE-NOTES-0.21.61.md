# VM-DOC Server 0.21.61 — Normalizare versiuni Elastic Beats

Data: 2026-10-20. Bază: 0.21.60. Doar server, fără agent nou (1.7.18), migrare automată sau schimbare API.

## Comportament

- Pentru servicii identificabile explicit ca `auditbeat`, `filebeat`, `metricbeat`, `packetbeat`, `heartbeat` sau `winlogbeat`, versiunea simplă `9.4.1` este echivalentă cu `auditbeat version 9.4.1 (amd64), libbeat 9.4.1 ... built <timestamp>`.
- Normalizarea se aplică **doar în detectorul `inventory_changes`**, nu în inventarul brut sau în UI-ul de inventar; comparația pentru integrarea Auditbeat/Filebeat folosește aceeași regulă.
- Sunt necesare numele produsului corespunzător și o versiune `libbeat` identică; ieșirile neobișnuite/ambigue rămân neschimbate. `package_version` este păstrat integral, pentru a nu pierde actualizări reale de pachet.
- Schimbările reale `9.4.1 → 9.4.2` continuă să producă evenimente; modificările de `enabled_state` sunt păstrate.
- Scripturile SQL `preview-beat-version-noise-02161.sql` / `cleanup-beat-version-noise-02161.sql` curăță numai evenimentele istorice `modified` de tip `services/service` la care singura diferență este `version`, iar varianta lungă are forma clar recunoscută Beats. Protejează review-urile, deciziile și observațiile manuale.

## Limitări

- Nu este un normalizator universal pentru orice binar; excluderea altor produse fără pattern explicit poate ascunde schimbări legitime. Nu șterge alte categorii din `inventory_changes`.
- Cleanup SQL: verificare PREVIEW, backup restaurabil și test MariaDB staging, apoi stop colectări/VM-DOC și execuție manuală CLEANUP. Nu se execută la startup. SQL-ul nu este testat pe MariaDB reală în mediul de construire.
- Build complet/teste end-to-end necesită `vendor/` și MariaDB staging. Nu confundați un pachet livrat cu un build de producție validat.
