# Upgrade VM-DOC Server 0.21.60 → 0.21.61

1. Faceți backup verificat pentru DB MariaDB, binarul, configurațiile și sursele 0.21.60.
2. Aplicați **ori** update TAR, **ori** patch; alternativ folosiți sursele complete. Nu suprapuneți patch și TAR. Păstrați `vendor/` din serverul offline.
3. În staging rulați `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./internal/inventorychanges ./openapi ./web` și apoi `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...` și `make build` cu vendor complet.
4. Verificați că `auditbeat.service` versiunea `9.4.1` / `auditbeat version 9.4.1 (amd64), libbeat 9.4.1 ...` nu generează modificări la două colectări consecutive; schimbarea efectivă la 9.4.2 trebuie să apară.
5. **Opțional, numai pentru istoric**: pe MariaDB staging rulați `scripts/preview-beat-version-noise-02161.sql` și inspectați candidatele; după backup nou restaurabil și oprirea VM-DOC executați `scripts/cleanup-beat-version-noise-02161.sql`.
6. Reporniți și monitorizați evenimentele noi. Nu ștergeți alte schimbări din inventarul brut.

Rollback: restaurați binarul/sursele 0.21.60; pentru ștergeri SQL deja comise, numai restore DB din backup. Fără schimbare de schemă sau agent; API identic.
