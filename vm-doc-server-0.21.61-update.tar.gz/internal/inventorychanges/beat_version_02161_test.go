package inventorychanges

import "testing"

func TestElasticBeatBannerIsSameVersion(t *testing.T) {
	for _, name := range []string{"auditbeat", "filebeat", "metricbeat", "packetbeat", "heartbeat", "winlogbeat"} {
		banner := name + " version 9.4.1 (amd64), libbeat 9.4.1 [471eefbca30a79d543af5106d039bf610a5c3281] built 2026-05-08 00:15:55 +0000 UTC (FIPS-distribution: false)"
		a := []byte(`{"services":[{"name":"` + name + `.service","manager":"systemd","version":"9.4.1","enabled_state":"enabled"}]}`)
		b := []byte(`{"services":[{"name":"` + name + `.service","manager":"systemd","version":"` + banner + `","enabled_state":"enabled"}]}`)
		assertTrackedEqual(t, a, b, "services|service|"+name+".service")
		obj, err := extractTracked(b)
		if err != nil {
			t.Fatal(err)
		}
		got := obj["services|service|"+name+".service"].Value.(map[string]any)["version"]
		if got != "9.4.1" {
			t.Fatalf("%s normalized to %#v", name, got)
		}
		updated := []byte(`{"services":[{"name":"` + name + `.service","manager":"systemd","version":"9.4.2","enabled_state":"enabled"}]}`)
		x, _ := extractTracked(a)
		y, _ := extractTracked(updated)
		if trackedObjectsEqual(x["services|service|"+name+".service"], y["services|service|"+name+".service"]) {
			t.Fatalf("real %s upgrade ignored", name)
		}
	}
}

func TestBeatNormalizationRequiresKnownMatchingProductAndLibbeat(t *testing.T) {
	banner := "auditbeat version 9.4.1 (amd64), libbeat 9.4.1 built 2026-05-08"
	if got := normalizeBeatVersion("custom.service", banner); got != banner {
		t.Fatalf("normalized other service: %s", got)
	}
	if got := normalizeBeatVersion("filebeat.service", banner); got != banner {
		t.Fatalf("normalized mismatching Beat name: %s", got)
	}
	mismatched := "auditbeat version 9.4.1 (amd64), libbeat 9.4.2 built 2026-05-08"
	if got := normalizeBeatVersion("auditbeat.service", mismatched); got != mismatched {
		t.Fatalf("masked differing libbeat: %s", got)
	}
	if got := normalizeBeatVersion("auditbeat.service", "auditbeat version 9.4.1-broken"); got != "auditbeat version 9.4.1-broken" {
		t.Fatalf("masked unusual version: %s", got)
	}
	fields := trackedServiceFields(map[string]any{"name": "auditbeat.service", "version": banner, "package_version": "9.4.1-1"})
	if fields["version"] != "9.4.1" || fields["package_version"] != "9.4.1-1" {
		t.Fatalf("bad fields: %#v", fields)
	}
}

func TestBeatIntegrationUsesSameNormalizedVersion(t *testing.T) {
	a := []byte(`{"integrations":{"auditbeat":{"version":"9.4.1","installed":true},"filebeat":{"version":"9.4.1","installed":true}}}`)
	b := []byte(`{"integrations":{"auditbeat":{"version":"auditbeat version 9.4.1 (amd64), libbeat 9.4.1 built today","installed":true},"filebeat":{"version":"filebeat version 9.4.1 (amd64), libbeat 9.4.1 built today","installed":true}}}`)
	assertTrackedEqual(t, a, b, "integrations|integration|auditbeat")
	assertTrackedEqual(t, a, b, "integrations|integration|filebeat")
}
