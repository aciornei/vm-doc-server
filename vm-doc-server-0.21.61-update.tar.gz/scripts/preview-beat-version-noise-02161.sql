-- VM-DOC 0.21.61: PREVIEW specific Elastic Beats version-format noise.
-- MariaDB 10.6+; execute the entire script in ONE SQL connection/session.
-- No statements modify the permanent database. Never skip staging verification.
DROP TEMPORARY TABLE IF EXISTS tmp_vm_doc_beat_version_noise_02161;
CREATE TEMPORARY TABLE tmp_vm_doc_beat_version_noise_02161
(id BIGINT NOT NULL PRIMARY KEY, category VARCHAR(32) NOT NULL) ENGINE=InnoDB;

-- Only modified Beat service/integration events, with matching JSON except version.
-- The verbose banner must be a product-matched version + libbeat banner;
-- both semantic version numbers must agree with each other.
INSERT IGNORE INTO tmp_vm_doc_beat_version_noise_02161 (id,category)
SELECT candidate.id, candidate.category
FROM (
 SELECT checked.id, checked.category, checked.old_v, checked.new_v,
  CASE
   WHEN checked.old_v REGEXP '^[0-9]+([.][0-9]+){1,5}$' THEN checked.old_v
   WHEN checked.old_v REGEXP '^[a-z]+ version [0-9]+([.][0-9]+){1,5} [(][^)]{1,100}[)], libbeat [0-9]+([.][0-9]+){1,5}([[:space:]].*)?$'
    AND LOWER(SUBSTRING_INDEX(checked.old_v,' ',1))=LOWER(checked.product_name)
    AND SUBSTRING_INDEX(SUBSTRING_INDEX(checked.old_v,' ',3),' ',-1)
       =SUBSTRING_INDEX(SUBSTRING_INDEX(checked.old_v,', libbeat ',-1),' ',1)
   THEN SUBSTRING_INDEX(SUBSTRING_INDEX(checked.old_v,' ',3),' ',-1)
   ELSE NULL END AS semantic_old,
  CASE
   WHEN checked.new_v REGEXP '^[0-9]+([.][0-9]+){1,5}$' THEN checked.new_v
   WHEN checked.new_v REGEXP '^[a-z]+ version [0-9]+([.][0-9]+){1,5} [(][^)]{1,100}[)], libbeat [0-9]+([.][0-9]+){1,5}([[:space:]].*)?$'
    AND LOWER(SUBSTRING_INDEX(checked.new_v,' ',1))=LOWER(checked.product_name)
    AND SUBSTRING_INDEX(SUBSTRING_INDEX(checked.new_v,' ',3),' ',-1)
       =SUBSTRING_INDEX(SUBSTRING_INDEX(checked.new_v,', libbeat ',-1),' ',1)
   THEN SUBSTRING_INDEX(SUBSTRING_INDEX(checked.new_v,' ',3),' ',-1)
   ELSE NULL END AS semantic_new
 FROM (
  SELECT c.id, c.category,
   CASE WHEN c.category='services'
     THEN SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',-1),'.',1)
     ELSE SUBSTRING_INDEX(c.object_key,'|',-1) END AS product_name,
   TRIM(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version'))) AS old_v,
   TRIM(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version'))) AS new_v
  FROM inventory_changes c
  WHERE c.review_status='new' AND c.documentation_requirement='unset'
    AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'')=''
    AND c.change_type='modified'
    AND ((c.category='services' AND c.object_type='service'
          AND c.object_key REGEXP '^services[|]service[|](auditbeat|filebeat|metricbeat|packetbeat|heartbeat|winlogbeat)[.]service$')
      OR (c.category='integrations' AND c.object_type='integration'
          AND c.object_key REGEXP '^integrations[|]integration[|](auditbeat|filebeat)$'))
    AND JSON_VALID(c.old_json)=1 AND JSON_VALID(c.new_json)=1
    AND BINARY JSON_REMOVE(c.old_json,'$.version') = BINARY JSON_REMOVE(c.new_json,'$.version')
 ) AS checked
) AS candidate
WHERE candidate.semantic_old IS NOT NULL
  AND candidate.semantic_new IS NOT NULL
  AND BINARY candidate.semantic_old = BINARY candidate.semantic_new
  AND BINARY candidate.old_v <> BINARY candidate.new_v
  AND (candidate.old_v LIKE '%libbeat%' OR candidate.new_v LIKE '%libbeat%');

SELECT DATABASE() AS current_database;
SELECT category,COUNT(*) AS candidates FROM tmp_vm_doc_beat_version_noise_02161 GROUP BY category;
SELECT COUNT(*) AS total_candidates FROM tmp_vm_doc_beat_version_noise_02161;
SELECT c.vm_id,c.id,c.category,c.object_label,c.occurred_at,
       JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')) AS previous_version,
       JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')) AS new_version
FROM inventory_changes c JOIN tmp_vm_doc_beat_version_noise_02161 t ON c.id=t.id
ORDER BY c.occurred_at DESC LIMIT 50;
DROP TEMPORARY TABLE tmp_vm_doc_beat_version_noise_02161;
