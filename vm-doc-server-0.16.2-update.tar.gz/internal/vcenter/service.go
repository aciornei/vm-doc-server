package vcenter

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/url"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/domain"
)

type Service struct {
	DB       *sql.DB
	Box      *cryptox.Box
	Config   config.VCenterConfig
	Logger   *slog.Logger
	Location *time.Location
	ctx      context.Context
	wg       sync.WaitGroup
}

type SourceInput struct {
	Name             string `json:"name"`
	BaseURL          string `json:"base_url"`
	Username         string `json:"username"`
	Password         string `json:"password,omitempty"`
	Enabled          *bool  `json:"enabled,omitempty"`
	VerifyTLS        *bool  `json:"verify_tls,omitempty"`
	TLSServerName    string `json:"tls_server_name,omitempty"`
	DailySyncEnabled *bool  `json:"daily_sync_enabled,omitempty"`
	DailySyncTime    string `json:"daily_sync_time,omitempty"`
}

type SourceRecord struct {
	domain.VCenterSource
	PasswordCiphertext string
}

type VMUpdate struct {
	Retired     *bool  `json:"retired,omitempty"`
	RetiredNote string `json:"retired_note,omitempty"`
	AgentID     *int64 `json:"agent_id,omitempty"`
	ClearAgent  bool   `json:"clear_agent,omitempty"`
}

type VMDetail struct {
	VM        domain.VirtualMachine `json:"vm"`
	Agent     *domain.Agent         `json:"agent,omitempty"`
	Inventory *domain.Inventory     `json:"inventory,omitempty"`
}

var clockPattern = regexp.MustCompile(`^(?:[01]\d|2[0-3]):[0-5]\d$`)

func NewService(ctx context.Context, db *sql.DB, box *cryptox.Box, cfg config.Config, logger *slog.Logger) *Service {
	location, err := time.LoadLocation(cfg.App.Timezone)
	if err != nil {
		location = time.UTC
	}
	if logger == nil {
		logger = slog.Default()
	}
	return &Service{DB: db, Box: box, Config: cfg.VCenter, Logger: logger, Location: location, ctx: ctx}
}

func (s *Service) Wait() { s.wg.Wait() }

func (s *Service) ListSources(ctx context.Context) ([]domain.VCenterSource, error) {
	rows, err := s.DB.QueryContext(ctx, sourceSelect+` ORDER BY s.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.VCenterSource, 0)
	for rows.Next() {
		record, err := scanSource(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, record.VCenterSource)
	}
	return out, rows.Err()
}

func (s *Service) GetSource(ctx context.Context, id int64) (domain.VCenterSource, error) {
	record, err := s.GetSourceRecord(ctx, id)
	return record.VCenterSource, err
}

func (s *Service) GetSourceRecord(ctx context.Context, id int64) (SourceRecord, error) {
	return scanSource(s.DB.QueryRowContext(ctx, sourceSelect+` WHERE s.id=?`, id))
}

func (s *Service) CreateSource(ctx context.Context, in SourceInput, userID int64) (domain.VCenterSource, error) {
	if err := s.normalizeSource(&in, true); err != nil {
		return domain.VCenterSource{}, err
	}
	secretRef, err := cryptox.RandomToken(24)
	if err != nil {
		return domain.VCenterSource{}, err
	}
	ciphertext, err := s.Box.Encrypt([]byte(in.Password), "vm-doc-vcenter-password:"+secretRef)
	if err != nil {
		return domain.VCenterSource{}, err
	}
	enabled, verify, daily := true, true, true
	if in.Enabled != nil {
		enabled = *in.Enabled
	}
	if in.VerifyTLS != nil {
		verify = *in.VerifyTLS
	}
	if in.DailySyncEnabled != nil {
		daily = *in.DailySyncEnabled
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO vcenter_sources(secret_ref,name,base_url,username,password_ciphertext,enabled,verify_tls,tls_server_name,daily_sync_enabled,daily_sync_time,last_error,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?, '',?,?)`, secretRef, in.Name, strings.TrimRight(in.BaseURL, "/"), in.Username, ciphertext, enabled, verify, in.TLSServerName, daily, in.DailySyncTime, userID, userID)
	if err != nil {
		return domain.VCenterSource{}, err
	}
	id, _ := res.LastInsertId()
	return s.GetSource(ctx, id)
}

func (s *Service) UpdateSource(ctx context.Context, id int64, in SourceInput, userID int64) (domain.VCenterSource, error) {
	current, err := s.GetSourceRecord(ctx, id)
	if err != nil {
		return domain.VCenterSource{}, err
	}
	if strings.TrimSpace(in.Name) == "" {
		in.Name = current.Name
	}
	if strings.TrimSpace(in.BaseURL) == "" {
		in.BaseURL = current.BaseURL
	}
	if strings.TrimSpace(in.Username) == "" {
		in.Username = current.Username
	}
	if in.Enabled == nil {
		v := current.Enabled
		in.Enabled = &v
	}
	if in.VerifyTLS == nil {
		v := current.VerifyTLS
		in.VerifyTLS = &v
	}
	if in.DailySyncEnabled == nil {
		v := current.DailySyncEnabled
		in.DailySyncEnabled = &v
	}
	if strings.TrimSpace(in.DailySyncTime) == "" {
		in.DailySyncTime = current.DailySyncTime
	}
	if in.TLSServerName == "" {
		in.TLSServerName = current.TLSServerName
	}
	if err := s.normalizeSource(&in, false); err != nil {
		return domain.VCenterSource{}, err
	}
	ciphertext := current.PasswordCiphertext
	if in.Password != "" {
		ciphertext, err = s.Box.Encrypt([]byte(in.Password), "vm-doc-vcenter-password:"+current.SecretRef)
		if err != nil {
			return domain.VCenterSource{}, err
		}
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE vcenter_sources SET name=?,base_url=?,username=?,password_ciphertext=?,enabled=?,verify_tls=?,tls_server_name=?,daily_sync_enabled=?,daily_sync_time=?,updated_by=? WHERE id=?`, in.Name, strings.TrimRight(in.BaseURL, "/"), in.Username, ciphertext, *in.Enabled, *in.VerifyTLS, in.TLSServerName, *in.DailySyncEnabled, in.DailySyncTime, userID, id)
	if err != nil {
		return domain.VCenterSource{}, err
	}
	return s.GetSource(ctx, id)
}

func (s *Service) DeleteSource(ctx context.Context, id int64) error {
	res, err := s.DB.ExecContext(ctx, `DELETE FROM vcenter_sources WHERE id=?`, id)
	if err != nil {
		return err
	}
	rows, _ := res.RowsAffected()
	if rows == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s *Service) TestSource(ctx context.Context, id int64) (map[string]any, error) {
	record, err := s.GetSourceRecord(ctx, id)
	if err != nil {
		return nil, err
	}
	password, err := s.decryptPassword(record)
	if err != nil {
		return nil, err
	}
	client, err := NewClient(record.VCenterSource, password, s.Config.RequestTimeout.Value(), s.Config.DetailWorkers)
	if err != nil {
		return nil, err
	}
	count, err := client.Test(ctx)
	if err != nil {
		return nil, err
	}
	return map[string]any{"status": "ok", "vm_count": count}, nil
}

func (s *Service) StartSync(ctx context.Context, sourceID int64, source string, requestedBy *int64) (domain.VCenterSyncRun, error) {
	if source != "manual" && source != "scheduler" {
		return domain.VCenterSyncRun{}, errors.New("invalid sync source")
	}
	if _, err := s.GetSource(ctx, sourceID); err != nil {
		return domain.VCenterSyncRun{}, err
	}
	var running int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM vcenter_sync_runs WHERE vcenter_source_id=? AND status IN ('queued','running')`, sourceID).Scan(&running); err != nil {
		return domain.VCenterSyncRun{}, err
	}
	if running > 0 {
		return domain.VCenterSyncRun{}, errors.New("a vCenter synchronization is already running")
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO vcenter_sync_runs(vcenter_source_id,source,status,requested_by_user_id,error_message) VALUES(?,?,'queued',?,'')`, sourceID, source, requestedBy)
	if err != nil {
		return domain.VCenterSyncRun{}, err
	}
	id, _ := res.LastInsertId()
	run, err := s.GetRun(ctx, id)
	if err != nil {
		return run, err
	}
	s.wg.Add(1)
	go func() {
		defer s.wg.Done()
		s.executeSync(s.ctx, id, sourceID)
	}()
	return run, nil
}

func (s *Service) StartAll(ctx context.Context, requestedBy *int64) ([]domain.VCenterSyncRun, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id FROM vcenter_sources WHERE enabled=1 ORDER BY name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	runs := make([]domain.VCenterSyncRun, 0)
	for _, id := range ids {
		run, err := s.StartSync(ctx, id, "manual", requestedBy)
		if err != nil {
			if strings.Contains(err.Error(), "already running") {
				continue
			}
			return runs, err
		}
		runs = append(runs, run)
	}
	return runs, nil
}

type SyncRunPage struct {
	Items    []domain.VCenterSyncRun `json:"items"`
	Page     int                     `json:"page"`
	PageSize int                     `json:"page_size"`
	Total    int                     `json:"total"`
	Pages    int                     `json:"pages"`
}

func (s *Service) ListRunsPage(ctx context.Context, page, pageSize int) (SyncRunPage, error) {
	if page < 1 {
		page = 1
	}
	if pageSize <= 0 {
		pageSize = 10
	}
	if pageSize > 200 {
		pageSize = 200
	}
	result := SyncRunPage{Items: make([]domain.VCenterSyncRun, 0), Page: page, PageSize: pageSize}
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM vcenter_sync_runs`).Scan(&result.Total); err != nil {
		return result, err
	}
	if result.Total == 0 {
		return result, nil
	}
	result.Pages = (result.Total + result.PageSize - 1) / result.PageSize
	if result.Page > result.Pages {
		result.Page = result.Pages
	}
	offset := (result.Page - 1) * result.PageSize
	rows, err := s.DB.QueryContext(ctx, runSelect+` ORDER BY r.id DESC LIMIT ? OFFSET ?`, result.PageSize, offset)
	if err != nil {
		return result, err
	}
	defer rows.Close()
	for rows.Next() {
		run, err := scanRun(rows)
		if err != nil {
			return result, err
		}
		result.Items = append(result.Items, run)
	}
	return result, rows.Err()
}

func (s *Service) ListRuns(ctx context.Context, limit int) ([]domain.VCenterSyncRun, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	page, err := s.ListRunsPage(ctx, 1, limit)
	return page.Items, err
}

func (s *Service) GetRun(ctx context.Context, id int64) (domain.VCenterSyncRun, error) {
	return scanRun(s.DB.QueryRowContext(ctx, runSelect+` WHERE r.id=?`, id))
}

func (s *Service) RunScheduler(ctx context.Context) {
	interval := s.Config.SchedulerInterval.Value()
	if interval <= 0 {
		interval = time.Minute
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		s.scheduleDue(ctx)
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}

func (s *Service) scheduleDue(ctx context.Context) {
	now := time.Now().In(s.Location)
	rows, err := s.DB.QueryContext(ctx, `SELECT id,daily_sync_time,last_success_at FROM vcenter_sources WHERE enabled=1 AND daily_sync_enabled=1`)
	if err != nil {
		if ctx.Err() == nil {
			s.Logger.Error("load scheduled vCenter sources", "error", err)
		}
		return
	}
	defer rows.Close()
	type dueSource struct {
		id   int64
		time string
		last sql.NullTime
	}
	var sources []dueSource
	for rows.Next() {
		var item dueSource
		if err := rows.Scan(&item.id, &item.time, &item.last); err == nil {
			sources = append(sources, item)
		}
	}
	for _, item := range sources {
		hour, minute, ok := parseClock(item.time)
		if !ok {
			continue
		}
		dueAt := time.Date(now.Year(), now.Month(), now.Day(), hour, minute, 0, 0, s.Location)
		if now.Before(dueAt) {
			continue
		}
		if item.last.Valid {
			last := item.last.Time.In(s.Location)
			if last.Year() == now.Year() && last.YearDay() == now.YearDay() {
				continue
			}
		}
		if _, err := s.StartSync(ctx, item.id, "scheduler", nil); err != nil && !strings.Contains(err.Error(), "already running") {
			s.Logger.Error("queue scheduled vCenter sync", "source_id", item.id, "error", err)
		}
	}
}

func (s *Service) executeSync(ctx context.Context, runID, sourceID int64) {
	started := time.Now().UTC()
	_, _ = s.DB.ExecContext(ctx, `UPDATE vcenter_sync_runs SET status='running',started_at=? WHERE id=? AND status='queued'`, started, runID)
	record, err := s.GetSourceRecord(ctx, sourceID)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	password, err := s.decryptPassword(record)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	client, err := NewClient(record.VCenterSource, password, s.Config.RequestTimeout.Value(), s.Config.DetailWorkers)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	remote, err := client.Inventory(ctx)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}

	conn, err := s.DB.Conn(ctx)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	defer conn.Close()
	lockName := fmt.Sprintf("vm-doc-vcenter-sync-%d", sourceID)
	var locked int
	if err := conn.QueryRowContext(ctx, `SELECT GET_LOCK(?,0)`, lockName).Scan(&locked); err != nil || locked != 1 {
		if err == nil {
			err = errors.New("another vCenter synchronization holds the database lock")
		}
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	defer conn.ExecContext(context.Background(), `SELECT RELEASE_LOCK(?)`, lockName)

	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	defer tx.Rollback()

	existing := map[string]int64{}
	rows, err := tx.QueryContext(ctx, `SELECT vcenter_moid,id FROM virtual_machines WHERE vcenter_source_id=?`, sourceID)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	for rows.Next() {
		var moid string
		var id int64
		if err := rows.Scan(&moid, &id); err != nil {
			rows.Close()
			s.failRun(ctx, runID, sourceID, err)
			return
		}
		existing[moid] = id
	}
	rows.Close()

	now := time.Now().UTC()
	created, updated, linked := 0, 0, 0
	for _, vm := range remote {
		attrs, _ := json.Marshal(vm.CustomAttributes)
		if len(attrs) == 0 || string(attrs) == "null" {
			attrs = []byte(`{}`)
		}
		_, exists := existing[vm.MoID]
		_, err = tx.ExecContext(ctx, `INSERT INTO virtual_machines(vcenter_source_id,vcenter_moid,instance_uuid,instance_uuid_normalized,bios_uuid,bios_uuid_normalized,name,power_state,cpu_count,memory_mib,hardware_version,guest_os,guest_hostname,primary_ip,custom_attributes_json,present_in_vcenter,first_seen_at,last_seen_at,missing_since,last_vcenter_sync_at,retired_note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,NULL,?,'') ON DUPLICATE KEY UPDATE instance_uuid=VALUES(instance_uuid),instance_uuid_normalized=VALUES(instance_uuid_normalized),bios_uuid=VALUES(bios_uuid),bios_uuid_normalized=VALUES(bios_uuid_normalized),name=VALUES(name),power_state=VALUES(power_state),cpu_count=VALUES(cpu_count),memory_mib=VALUES(memory_mib),hardware_version=VALUES(hardware_version),guest_os=VALUES(guest_os),guest_hostname=VALUES(guest_hostname),primary_ip=VALUES(primary_ip),custom_attributes_json=VALUES(custom_attributes_json),present_in_vcenter=1,last_seen_at=VALUES(last_seen_at),missing_since=NULL,last_vcenter_sync_at=VALUES(last_vcenter_sync_at)`, sourceID, vm.MoID, vm.InstanceUUID, normalizeUUID(vm.InstanceUUID), vm.BIOSUUID, normalizeUUID(vm.BIOSUUID), vm.Name, vm.PowerState, vm.CPUCount, vm.MemoryMiB, vm.HardwareVersion, vm.GuestOS, vm.GuestHostname, vm.PrimaryIP, attrs, now, now, now)
		if err != nil {
			s.failRun(ctx, runID, sourceID, err)
			return
		}
		var vmID int64
		if err := tx.QueryRowContext(ctx, `SELECT id FROM virtual_machines WHERE vcenter_source_id=? AND vcenter_moid=?`, sourceID, vm.MoID).Scan(&vmID); err != nil {
			s.failRun(ctx, runID, sourceID, err)
			return
		}
		if exists {
			updated++
		} else {
			created++
		}
		wasLinked, err := correlateVM(ctx, tx, vmID, vm)
		if err != nil {
			s.failRun(ctx, runID, sourceID, err)
			return
		}
		if wasLinked {
			linked++
		}
	}

	_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET present_in_vcenter=0,missing_since=COALESCE(missing_since,?),last_vcenter_sync_at=? WHERE vcenter_source_id=? AND last_seen_at<?`, now, now, sourceID, started)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	var missing int
	if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM virtual_machines WHERE vcenter_source_id=? AND present_in_vcenter=0`, sourceID).Scan(&missing); err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	finished := time.Now().UTC()
	if _, err := tx.ExecContext(ctx, `UPDATE vcenter_sources SET last_sync_at=?,last_success_at=?,last_error='' WHERE id=?`, finished, finished, sourceID); err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	if _, err := tx.ExecContext(ctx, `UPDATE vcenter_sync_runs SET status='succeeded',finished_at=?,found_count=?,created_count=?,updated_count=?,missing_count=?,linked_agent_count=?,error_message='' WHERE id=?`, finished, len(remote), created, updated, missing, linked, runID); err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	if err := tx.Commit(); err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	s.Logger.Info("vCenter synchronization completed", "source_id", sourceID, "run_id", runID, "found", len(remote), "created", created, "updated", updated, "missing", missing, "linked_agents", linked)
}

func correlateVM(ctx context.Context, tx *sql.Tx, vmID int64, remote RemoteVM) (bool, error) {
	var currentAgent sql.NullInt64
	if err := tx.QueryRowContext(ctx, `SELECT agent_id FROM virtual_machines WHERE id=?`, vmID).Scan(&currentAgent); err != nil {
		return false, err
	}
	if currentAgent.Valid {
		_, err := tx.ExecContext(ctx, `UPDATE virtual_machines vm JOIN agents a ON a.id=vm.agent_id SET vm.current_inventory_id=a.current_inventory_id WHERE vm.id=?`, vmID)
		return false, err
	}
	bios := normalizeUUID(remote.BIOSUUID)
	legacy := normalizeUUID(swapVMwareUUID(remote.BIOSUUID))
	var rows *sql.Rows
	var err error
	if bios != "" {
		rows, err = tx.QueryContext(ctx, `SELECT agent_id,id FROM inventory_snapshots WHERE product_uuid_normalized IN (?,?) OR product_uuid_legacy_normalized IN (?,?) ORDER BY received_at DESC LIMIT 10`, bios, legacy, bios, legacy)
	} else {
		names := uniqueNonEmpty(strings.ToLower(remote.Name), strings.ToLower(remote.GuestHostname))
		if len(names) == 0 {
			return false, nil
		}
		placeholders := strings.TrimRight(strings.Repeat("?,", len(names)), ",")
		args := make([]any, len(names))
		for i := range names {
			args[i] = names[i]
		}
		rows, err = tx.QueryContext(ctx, `SELECT agent_id,id FROM inventory_snapshots WHERE LOWER(hostname) IN (`+placeholders+`) OR LOWER(fqdn) IN (`+placeholders+`) ORDER BY received_at DESC LIMIT 10`, append(args, args...)...)
	}
	if err != nil {
		return false, err
	}
	defer rows.Close()
	candidateInventory := map[int64]int64{}
	for rows.Next() {
		var agentID, inventoryID int64
		if err := rows.Scan(&agentID, &inventoryID); err != nil {
			return false, err
		}
		if _, exists := candidateInventory[agentID]; !exists {
			candidateInventory[agentID] = inventoryID
		}
	}
	if len(candidateInventory) != 1 {
		return false, nil
	}
	var agentID, inventoryID int64
	for agentID, inventoryID = range candidateInventory {
	}
	if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=NULL,current_inventory_id=NULL WHERE agent_id=? AND id<>?`, agentID, vmID); err != nil {
		return false, err
	}
	_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=?,current_inventory_id=? WHERE id=?`, agentID, inventoryID, vmID)
	return err == nil, err
}

func (s *Service) failRun(ctx context.Context, runID, sourceID int64, err error) {
	message := truncate(err.Error(), 4000)
	now := time.Now().UTC()
	_, _ = s.DB.ExecContext(ctx, `UPDATE vcenter_sync_runs SET status='failed',finished_at=?,error_message=? WHERE id=?`, now, message, runID)
	_, _ = s.DB.ExecContext(ctx, `UPDATE vcenter_sources SET last_sync_at=?,last_error=? WHERE id=?`, now, message, sourceID)
	s.Logger.Error("vCenter synchronization failed", "source_id", sourceID, "run_id", runID, "error", err)
}

func (s *Service) decryptPassword(record SourceRecord) (string, error) {
	plain, err := s.Box.Decrypt(record.PasswordCiphertext, "vm-doc-vcenter-password:"+record.SecretRef)
	if err != nil {
		return "", err
	}
	return string(plain), nil
}

func (s *Service) normalizeSource(in *SourceInput, create bool) error {
	in.Name = strings.TrimSpace(in.Name)
	in.BaseURL = strings.TrimSpace(in.BaseURL)
	in.Username = strings.TrimSpace(in.Username)
	in.DailySyncTime = strings.TrimSpace(in.DailySyncTime)
	if in.DailySyncTime == "" {
		in.DailySyncTime = "05:00"
	}
	if in.Name == "" || in.BaseURL == "" || in.Username == "" {
		return errors.New("name, base_url and username are required")
	}
	if create && in.Password == "" {
		return errors.New("password is required")
	}
	u, err := url.Parse(in.BaseURL)
	if err != nil || u.Host == "" || u.Scheme == "" {
		return errors.New("invalid base_url")
	}
	if u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return errors.New("base_url must contain only scheme, host and optional port")
	}
	if u.Scheme != "https" && !(s.Config.AllowHTTP && u.Scheme == "http") {
		return errors.New("base_url must use HTTPS")
	}
	if !clockPattern.MatchString(in.DailySyncTime) {
		return errors.New("daily_sync_time must use HH:MM")
	}
	return nil
}

const sourceSelect = `SELECT s.id,s.secret_ref,s.name,s.base_url,s.username,s.password_ciphertext,s.enabled,s.verify_tls,s.tls_server_name,s.daily_sync_enabled,s.daily_sync_time,s.last_sync_at,s.last_success_at,s.last_error,s.created_at,s.updated_at FROM vcenter_sources s`

func scanSource(scanner interface{ Scan(...any) error }) (SourceRecord, error) {
	var record SourceRecord
	var lastSync, lastSuccess sql.NullTime
	err := scanner.Scan(&record.ID, &record.SecretRef, &record.Name, &record.BaseURL, &record.Username, &record.PasswordCiphertext, &record.Enabled, &record.VerifyTLS, &record.TLSServerName, &record.DailySyncEnabled, &record.DailySyncTime, &lastSync, &lastSuccess, &record.LastError, &record.CreatedAt, &record.UpdatedAt)
	if err != nil {
		return record, err
	}
	record.PasswordConfigured = record.PasswordCiphertext != ""
	if lastSync.Valid {
		record.LastSyncAt = &lastSync.Time
	}
	if lastSuccess.Valid {
		record.LastSuccessAt = &lastSuccess.Time
	}
	return record, nil
}

const runSelect = `SELECT r.id,r.vcenter_source_id,s.name,r.source,r.status,r.requested_by_user_id,r.started_at,r.finished_at,r.found_count,r.created_count,r.updated_count,r.missing_count,r.linked_agent_count,r.error_message,r.created_at FROM vcenter_sync_runs r JOIN vcenter_sources s ON s.id=r.vcenter_source_id`

func scanRun(scanner interface{ Scan(...any) error }) (domain.VCenterSyncRun, error) {
	var run domain.VCenterSyncRun
	var requested sql.NullInt64
	var started, finished sql.NullTime
	err := scanner.Scan(&run.ID, &run.VCenterSourceID, &run.VCenterSourceName, &run.Source, &run.Status, &requested, &started, &finished, &run.FoundCount, &run.CreatedCount, &run.UpdatedCount, &run.MissingCount, &run.LinkedAgentCount, &run.ErrorMessage, &run.CreatedAt)
	if err != nil {
		return run, err
	}
	if requested.Valid {
		v := requested.Int64
		run.RequestedByUserID = &v
	}
	if started.Valid {
		t := started.Time
		run.StartedAt = &t
	}
	if finished.Valid {
		t := finished.Time
		run.FinishedAt = &t
	}
	return run, nil
}

func normalizeUUID(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	value = strings.Trim(value, "{}")
	value = strings.ReplaceAll(value, " ", "")
	return value
}

func swapVMwareUUID(value string) string {
	raw := strings.ReplaceAll(normalizeUUID(value), "-", "")
	if len(raw) != 32 {
		return ""
	}
	pairs := make([]string, 16)
	for i := range pairs {
		pairs[i] = raw[i*2 : i*2+2]
	}
	order := []int{3, 2, 1, 0, 5, 4, 7, 6, 8, 9, 10, 11, 12, 13, 14, 15}
	out := make([]string, 16)
	for i, source := range order {
		out[i] = pairs[source]
	}
	joined := strings.Join(out, "")
	return joined[0:8] + "-" + joined[8:12] + "-" + joined[12:16] + "-" + joined[16:20] + "-" + joined[20:]
}

func parseClock(value string) (int, int, bool) {
	if !clockPattern.MatchString(value) {
		return 0, 0, false
	}
	var hour, minute int
	_, err := fmt.Sscanf(value, "%d:%d", &hour, &minute)
	return hour, minute, err == nil
}

func uniqueNonEmpty(values ...string) []string {
	set := map[string]struct{}{}
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value != "" {
			set[value] = struct{}{}
		}
	}
	out := make([]string, 0, len(set))
	for value := range set {
		out = append(out, value)
	}
	sort.Strings(out)
	return out
}

func truncate(value string, length int) string {
	if len(value) > length {
		return value[:length]
	}
	return value
}
