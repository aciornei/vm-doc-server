# Upgrade vm-doc-server 0.16.1 → 0.16.2

0.16.2 este un update de interfață și documentare. Nu adaugă migrare SQL și nu cere schimbarea agentului.

## Pași

1. Faceți backup aplicației și bazei de date.
2. Aplicați `vm-doc-server-0.16.2-update.tar.gz` peste sursa 0.16.1 sau patch-ul 0.16.1 → 0.16.2.
3. Compilați: `go build -o vm-doc-server ./cmd/vm-doc-server`.
4. Înlocuiți binarul folosit de systemd și reporniți `vm-doc-server`.
5. Reîncărcați aplicația în browser; asset-urile au cache-bust `0.16.2`.

`vm-doc-agent 1.6.1` rămâne compatibil și este suficient pentru această versiune.
