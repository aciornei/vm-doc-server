# Upgrade VM-DOC Server 0.21.28 → 0.21.29

Modificări frontend: beneficiari în lista instanțelor DB, date/ore și filtre Web. **Fără migrare SQL sau API nou.** Agent 1.7.18 neschimbat.

1. Faceți backup surselor și binarului actual. Creați o copie nouă a directorului 0.21.28, păstrând `vendor/` necesar compilării offline.
2. Aplicați arhiva `vm-doc-server-0.21.29-update.tar.gz` în rădăcina copiei.
3. Testați cu `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și `GOPROXY=off GOFLAGS=-mod=vendor make build`.
4. Numai după succes înlocuiți binarul cu procedura existentă, reporniți serviciul și faceți Ctrl+F5.
5. Verificați VM → Baze de date la instanțe cu mai multe baze și beneficiari; dacă aceeași persoană/OU apare pe mai multe baze, trebuie să fie afișată o singură dată în sumarul instanței. VM → Web: opt filtre, colapsare, resetare și păstrare selecții; serverele detectate pot fi extinse. Docker: data ultimei colectări este pe un singur rând în card, dar în tabele rămâne pe două.
6. Rollback: restaurați binarul și sursele 0.21.28. Nu sunt migrări de revenit.

**Limitări:** testele browser folosesc date simulate. Build-ul Go complet și testarea în mediul real sunt necesare în staging; dependențele din vendor/ lipsesc în mediul de generare.
