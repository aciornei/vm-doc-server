# VM-DOC — TODO / backlog

> Actualizat: 2026-10-15, după VM-DOC Server 0.21.29. Acest fișier păstrează funcționalitățile **amânate**, nu descrie funcții implementate.

## Amânate explicit — reluăm după maturizarea aplicației

### 1. Integrare Wazuh prin API — AMÂNAT

- Scop: Wazuh ca sursă externă pentru Security Configuration Assessment (SCA), politici CIS-referenced și ulterior vulnerabilități.
- VM-DOC rămâne proprietarul inventarului de VM/servicii/beneficiari și al rapoartelor de impact; nu devine scanner de securitate complet.
- Corelare agenți Wazuh cu VM-DOC prin ID legat persistent, FQDN/hostname/IP cu rezolvare manuală a ambiguităților.
- API read-only pentru agenți, politici și rezultate SCA; sincronizare programată, stare sursă, erori/timeout, paginare, export și Swagger.
- Autentificare cu permisiuni minime, TLS verificat și secrete ținute numai în server (niciodată în exporturi, Outline sau documente).
- Raportarea distinge explicit **Wazuh SCA** de **VM-DOC Baseline**. Scorurile nu se adună ca și cum ar folosi același set de reguli.
- Fază separată pentru vulnerabilități/CVE și impact pe VM, servicii și departamente.
- **Nu se implementează acum.** Hardening-ul existent rămâne baseline pentru VM-uri fără agent Wazuh, inclusiv legacy. Șabloanele draft Apache/Nginx/DB rămân pentru viitor, fără pretenție de conformitate CIS completă.

### 2. Consolă shell SSH din fișa VM, chei prin Vault — AMÂNAT

- Scop: sesiune SSH interactivă către VM din interfața VM-DOC, folosind credențiale/chei gestionate în Vault.
- Design obligatoriu înainte de implementare: RBAC separat, permisiuni pe VM/mediu, MFA/reautentificare după caz, aprobare pentru acces privilegiat.
- Sesiuni proxy prin backend controlat; nici cheia SSH, nici tokenul Vault nu sunt expuse browserului, jurnalelor sau documentației exportate.
- Audit sesiune (cine, VM, timp, acțiuni și rezultat), limite de timp, revocare, izolare, rate-limit; gestiunea înregistrării sesiunii după politica de confidențialitate.
- Verificări anti-SSRF/host-key și control destinație; nu permite comenzi arbitrare prin funcția obișnuită de colectare agent.
- **Nu se implementează acum.** Necesită model de securitate, review și test de intruziune înainte de activare PROD.

## Următoarea direcție activă

1. Continuarea uniformizării UI/UX după Server 0.21.29, verificând cu date reale paginile Docker, Baze de date și Web.
2. Testarea în staging a migrației 078 (beneficiari Compose), a afișării agregate a beneficiarilor instanțelor DB și a filtrelor Web, plus compilare completă cu `vendor/`.
3. Reluare Wazuh și SSH numai când VM-DOC este suficient de stabil și când există cerințele de securitate aprobate.
