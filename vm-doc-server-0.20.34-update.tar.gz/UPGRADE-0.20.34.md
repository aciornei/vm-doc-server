# Upgrade vm-doc-server 0.20.33 -> 0.20.34

Versiunea 0.20.34 este un update UI. Nu adaugă migrare DB și nu necesită update de vm-doc-agent.

## Schimbări

- Bifa `Nu se publică în Outline` apare direct în Rezumatul VM.
- Aceeași setare rămâne disponibilă și în `Configurare → Infrastructură`.
- După salvare rămâi în secțiunea curentă.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.33 \
      /usr/local/src/vm-doc-server-0.20.34

tar -xzf vm-doc-server-0.20.34-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.34

cd /usr/local/src/vm-doc-server-0.20.34
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După restart, folosește `Ctrl+F5` în browser pentru a încărca `app.js?v=0.20.34`.
