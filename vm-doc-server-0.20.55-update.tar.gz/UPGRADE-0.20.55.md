# Upgrade vm-doc-server 0.20.54 → 0.20.55

## Ce se schimbă

Versiunea 0.20.55 este un hotfix pentru testul adăugat în 0.20.54 la funcția **Ascunde porturile ascultate**.

În 0.20.54, `internal/server/vm_listening_ports_test.go` inițializa `inventory.DocumentSection` cu câmpul `Label`, dar structura curentă folosește `Title`. Din această cauză `go test ./...` se oprea cu:

```text
unknown field Label in struct literal of type inventory.DocumentSection
```

0.20.55 schimbă numai testul la `Title`. Funcționalitatea aplicației nu se modifică.

Nu există migrare DB și nu este necesar update de agent.

## Upgrade

```bash
cp -a /usr/local/src/vm-doc-server-0.20.54 /usr/local/src/vm-doc-server-0.20.55
tar -xzf vm-doc-server-0.20.55-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.55
cd /usr/local/src/vm-doc-server-0.20.55

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După build, repornește `vm-doc-server`. Nu este necesară nicio migrare.
