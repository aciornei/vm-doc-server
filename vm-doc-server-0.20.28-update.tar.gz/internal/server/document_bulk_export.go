package server

import (
	"archive/zip"
	"context"
	"encoding/csv"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/documents"
)

type bulkDocumentManifestRow struct {
	ObjectType     string
	ObjectID       int64
	ObjectName     string
	DocumentID     int64
	DocumentNumber string
	GeneratedAt    string
	ArchiveFile    string
	Status         string
	Detail         string
}

type bulkDocumentExportOptions struct {
	RegenerateVMDocuments     bool `json:"regenerate_vm_documents"`
	GenerateMissingServices   bool `json:"generate_missing_services"`
	IncludeServiceVMDocuments bool `json:"include_service_vm_documents"`
}

type bulkDocumentExportStats struct {
	Included    int
	Missing     int
	Failed      int
	Generated   int
	Regenerated int
	VMIncluded  int
	VMMissing   int
	VMFailed    int
}

func (a *App) exportVMDOCXArchive(w http.ResponseWriter, r *http.Request) {
	a.exportDocumentArchive(w, r, "vm", "docx", bulkDocumentExportOptions{})
}

func (a *App) exportVMDOCXArchiveAdvanced(w http.ResponseWriter, r *http.Request) {
	var options bulkDocumentExportOptions
	if err := decodeJSON(r, &options, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	options.GenerateMissingServices = false
	options.IncludeServiceVMDocuments = false
	a.exportDocumentArchive(w, r, "vm", "docx", options)
}

func (a *App) exportVMPDFArchive(w http.ResponseWriter, r *http.Request) {
	a.exportDocumentArchive(w, r, "vm", "pdf", bulkDocumentExportOptions{})
}

func (a *App) exportServiceDOCXArchive(w http.ResponseWriter, r *http.Request) {
	a.exportDocumentArchive(w, r, "service", "docx", bulkDocumentExportOptions{})
}

func (a *App) exportServiceDOCXArchiveAdvanced(w http.ResponseWriter, r *http.Request) {
	var options bulkDocumentExportOptions
	if err := decodeJSON(r, &options, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	options.RegenerateVMDocuments = false
	a.exportDocumentArchive(w, r, "service", "docx", options)
}

func (a *App) exportServicePDFArchive(w http.ResponseWriter, r *http.Request) {
	a.exportDocumentArchive(w, r, "service", "pdf", bulkDocumentExportOptions{})
}

func (a *App) exportDocumentArchive(w http.ResponseWriter, r *http.Request, objectType, format string, options bulkDocumentExportOptions) {
	items, err := a.Documents.ListBulkExportItems(r.Context(), objectType)
	if err != nil {
		respond(w, nil, err)
		return
	}

	var officeBinary string
	var vmTemplate *documents.Template
	var serviceTemplate *documents.Template

	if format == "pdf" {
		officeBinary, err = locateOfficeBinary()
		if err != nil {
			jsonResponse(w, http.StatusServiceUnavailable, map[string]any{"error": "pdf_converter_unavailable", "message": err.Error()})
			return
		}
	}
	if format == "docx" && objectType == "vm" && options.RegenerateVMDocuments {
		value, templateErr := a.Documents.DefaultTemplateFor(r.Context(), "vm")
		if templateErr != nil {
			respond(w, nil, fmt.Errorf("load default VM document template: %w", templateErr))
			return
		}
		vmTemplate = &value
	}
	if format == "docx" && objectType == "service" && options.GenerateMissingServices {
		value, templateErr := a.Documents.DefaultTemplateFor(r.Context(), "service")
		if templateErr != nil {
			respond(w, nil, fmt.Errorf("load default service document template: %w", templateErr))
			return
		}
		serviceTemplate = &value
	}

	// Bulk archives may need more time, especially when documents are generated
	// before they are streamed into the ZIP.
	_ = http.NewResponseController(w).SetWriteDeadline(time.Now().Add(30 * time.Minute))
	filename := bulkArchiveFileName(objectType, format, time.Now())
	w.Header().Set("Content-Type", "application/zip")
	w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "private, no-store")
	w.Header().Set("X-Accel-Buffering", "no")
	w.WriteHeader(http.StatusOK)

	zw := zip.NewWriter(w)
	manifest := make([]bulkDocumentManifestRow, 0, len(items))
	stats := bulkDocumentExportStats{}

	if err := writeBulkArchiveReadme(zw, objectType, format, options); err != nil {
		_ = zw.Close()
		return
	}
	flushBulkArchive(w, zw)

	if format == "docx" {
		rows, docxStats := a.writeBulkDOCXDocuments(r, zw, items, objectType, options, vmTemplate, serviceTemplate, w)
		manifest = append(manifest, rows...)
		stats = docxStats
	} else {
		pdfRows, inc, miss, fail := a.writeBulkPDFDocuments(r.Context(), zw, items, officeBinary, w)
		manifest = append(manifest, pdfRows...)
		stats.Included, stats.Missing, stats.Failed = inc, miss, fail
	}

	_ = writeBulkManifest(zw, manifest)
	_ = writeBulkSummary(zw, len(items), stats)
	_ = zw.Close()

	a.auditRequest(r, "document.bulk_export."+objectType+"."+format, "document_archive", objectType+":"+format, "success", map[string]any{
		"object_type":                  objectType,
		"format":                       format,
		"total":                        len(items),
		"included":                     stats.Included,
		"missing":                      stats.Missing,
		"failed":                       stats.Failed,
		"generated":                    stats.Generated,
		"regenerated":                  stats.Regenerated,
		"included_vm_documents":        stats.VMIncluded,
		"missing_vm_documents":         stats.VMMissing,
		"failed_vm_documents":          stats.VMFailed,
		"regenerate_vm_documents":      options.RegenerateVMDocuments,
		"generate_missing_services":    options.GenerateMissingServices,
		"include_service_vm_documents": options.IncludeServiceVMDocuments,
	})
}

func (a *App) writeBulkDOCXDocuments(r *http.Request, zw *zip.Writer, items []documents.BulkExportItem, objectType string, options bulkDocumentExportOptions, vmTemplate, serviceTemplate *documents.Template, w http.ResponseWriter) ([]bulkDocumentManifestRow, bulkDocumentExportStats) {
	manifest := make([]bulkDocumentManifestRow, 0, len(items))
	stats := bulkDocumentExportStats{}

	for _, original := range items {
		item := original
		rowDetail := ""

		if objectType == "vm" && options.RegenerateVMDocuments {
			data, dataErr := a.buildVMGenerationData(r, item.ObjectID)
			if dataErr != nil {
				row := bulkManifestBase(item)
				row.Status = "error"
				row.Detail = "Regenerarea fișei VM a eșuat: " + dataErr.Error()
				manifest = append(manifest, row)
				stats.Failed++
				continue
			}
			data.IncludeGeneratedBy = false
			generated, generateErr := a.Documents.Generate(r.Context(), *vmTemplate, data)
			if generateErr != nil {
				row := bulkManifestBase(item)
				row.Status = "error"
				row.Detail = "Regenerarea fișei VM a eșuat: " + generateErr.Error()
				manifest = append(manifest, row)
				stats.Failed++
				continue
			}
			a.auditRequest(r, "vm_document.generate", "generated_document", strconv.FormatInt(generated.ID, 10), "success", map[string]any{
				"vm_id": item.ObjectID, "document_number": generated.DocumentNumber, "template_id": generated.TemplateID,
				"sha256": generated.SHA256, "size_bytes": generated.SizeBytes, "bulk_export": true, "generated_by_in_document": false,
			})
			item = bulkItemFromGenerated(item, generated)
			stats.Regenerated++
			rowDetail = "Fișa a fost regenerată înainte de export. Câmpul „Generat de” nu este inclus în document."
		}

		if objectType == "service" && item.DocumentID == nil && options.GenerateMissingServices {
			request := templateRequest{TemplateID: serviceTemplate.ID, IncludeGeneratedBy: false}
			_, data, dataErr := a.serviceDocumentGenerationData(r, item.ObjectID, request, true)
			if dataErr != nil {
				row := bulkManifestBase(item)
				row.Status = "error"
				row.Detail = "Generarea fișei serviciului a eșuat: " + dataErr.Error()
				manifest = append(manifest, row)
				stats.Failed++
				if options.IncludeServiceVMDocuments {
					a.appendBulkServiceVMDocuments(r, zw, item, &manifest, &stats, w)
				}
				continue
			}
			generated, generateErr := a.Documents.GenerateService(r.Context(), *serviceTemplate, data)
			if generateErr != nil {
				row := bulkManifestBase(item)
				row.Status = "error"
				row.Detail = "Generarea fișei serviciului a eșuat: " + generateErr.Error()
				manifest = append(manifest, row)
				stats.Failed++
				if options.IncludeServiceVMDocuments {
					a.appendBulkServiceVMDocuments(r, zw, item, &manifest, &stats, w)
				}
				continue
			}
			a.auditRequest(r, "internal_service_document.generate", "generated_document", strconv.FormatInt(generated.ID, 10), "success", map[string]any{
				"internal_service_id": item.ObjectID, "document_number": generated.DocumentNumber, "template_id": generated.TemplateID,
				"sha256": generated.SHA256, "size_bytes": generated.SizeBytes, "bulk_export": true, "generated_by_in_document": false,
			})
			item = bulkItemFromGenerated(item, generated)
			stats.Generated++
			rowDetail = "Fișa lipsea și a fost generată înainte de export. Câmpul „Generat de” nu este inclus în document."
		}

		row := bulkManifestBase(item)
		if item.DocumentID == nil {
			row.Status = "missing_document"
			row.Detail = "Nu există încă o fișă generată pentru acest obiect."
			manifest = append(manifest, row)
			stats.Missing++
		} else {
			doc, getErr := a.Documents.GetGenerated(r.Context(), *item.DocumentID, true)
			if getErr != nil {
				row.Status = "error"
				row.Detail = getErr.Error()
				manifest = append(manifest, row)
				stats.Failed++
			} else {
				archiveName := bulkArchiveEntryName(item, doc.FileName, ".docx")
				if writeErr := writeZipBytes(zw, archiveName, doc.Content); writeErr != nil {
					row.Status = "error"
					row.Detail = writeErr.Error()
					manifest = append(manifest, row)
					stats.Failed++
				} else {
					row.ArchiveFile = archiveName
					row.Status = "included"
					row.Detail = rowDetail
					manifest = append(manifest, row)
					stats.Included++
					flushBulkArchive(w, zw)
				}
			}
		}

		if objectType == "service" && options.IncludeServiceVMDocuments {
			a.appendBulkServiceVMDocuments(r, zw, item, &manifest, &stats, w)
		}
	}
	return manifest, stats
}

func (a *App) appendBulkServiceVMDocuments(r *http.Request, zw *zip.Writer, serviceItem documents.BulkExportItem, manifest *[]bulkDocumentManifestRow, stats *bulkDocumentExportStats, w http.ResponseWriter) {
	service, err := a.Catalog.Get(r.Context(), serviceItem.ObjectID)
	if err != nil {
		*manifest = append(*manifest, bulkDocumentManifestRow{ObjectType: "service_vm", ObjectID: serviceItem.ObjectID, ObjectName: serviceItem.ObjectName, Status: "error", Detail: "Nu s-au putut încărca VM-urile proiectului: " + err.Error()})
		stats.VMFailed++
		return
	}

	servicePart := sanitizeBulkName(serviceItem.ObjectName)
	if servicePart == "" {
		servicePart = "serviciu"
	}
	serviceFolder := fmt.Sprintf("VM-uri/%06d_%s", serviceItem.ObjectID, servicePart)
	seen := make(map[int64]bool)

	for _, vm := range service.VMs {
		if vm.ID <= 0 || seen[vm.ID] {
			continue
		}
		seen[vm.ID] = true
		vmName := strings.TrimSpace(firstServerNonEmpty(vm.GuestHostname, vm.Name))
		vmItem := documents.BulkExportItem{ObjectType: "service_vm", ObjectID: vm.ID, ObjectName: vmName}
		existing, listErr := a.Documents.ListGeneratedVM(r.Context(), vm.ID)
		if listErr != nil {
			row := bulkManifestBase(vmItem)
			row.Status = "error"
			row.Detail = "Proiect " + serviceItem.ObjectName + ": " + listErr.Error()
			*manifest = append(*manifest, row)
			stats.VMFailed++
			continue
		}
		if len(existing) == 0 {
			row := bulkManifestBase(vmItem)
			row.Status = "missing_document"
			row.Detail = "Proiect " + serviceItem.ObjectName + ": VM-ul nu are încă fișă generată."
			*manifest = append(*manifest, row)
			stats.VMMissing++
			continue
		}

		generated := existing[0]
		vmItem = bulkItemFromGenerated(vmItem, generated)
		row := bulkManifestBase(vmItem)
		doc, getErr := a.Documents.GetGenerated(r.Context(), generated.ID, true)
		if getErr != nil {
			row.Status = "error"
			row.Detail = "Proiect " + serviceItem.ObjectName + ": " + getErr.Error()
			*manifest = append(*manifest, row)
			stats.VMFailed++
			continue
		}

		archiveName := filepath.ToSlash(filepath.Join(serviceFolder, bulkArchiveEntryName(vmItem, doc.FileName, ".docx")))
		if writeErr := writeZipBytes(zw, archiveName, doc.Content); writeErr != nil {
			row.Status = "error"
			row.Detail = "Proiect " + serviceItem.ObjectName + ": " + writeErr.Error()
			*manifest = append(*manifest, row)
			stats.VMFailed++
			continue
		}
		row.ArchiveFile = archiveName
		row.Status = "included"
		row.Detail = "Fișă VM asociată proiectului " + serviceItem.ObjectName + "."
		*manifest = append(*manifest, row)
		stats.VMIncluded++
		flushBulkArchive(w, zw)
	}
}

func bulkItemFromGenerated(item documents.BulkExportItem, generated documents.GeneratedDocument) documents.BulkExportItem {
	id := generated.ID
	generatedAt := generated.GeneratedAt
	item.DocumentID = &id
	item.DocumentNumber = generated.DocumentNumber
	item.FileName = generated.FileName
	item.GeneratedAt = &generatedAt
	return item
}

func (a *App) writeBulkPDFDocuments(ctx context.Context, zw *zip.Writer, items []documents.BulkExportItem, officeBinary string, w http.ResponseWriter) ([]bulkDocumentManifestRow, int, int, int) {
	manifest := make([]bulkDocumentManifestRow, 0, len(items))
	included, missing, failed := 0, 0, 0
	root, err := os.MkdirTemp("", "vm-doc-pdf-export-*")
	if err != nil {
		for _, item := range items {
			row := bulkManifestBase(item)
			if item.DocumentID == nil {
				row.Status = "missing_document"
				missing++
			} else {
				row.Status = "error"
				row.Detail = err.Error()
				failed++
			}
			manifest = append(manifest, row)
		}
		return manifest, included, missing, failed
	}
	defer os.RemoveAll(root)

	profileDir := filepath.Join(root, "profile")
	_ = os.MkdirAll(profileDir, 0700)
	profileURL := (&url.URL{Scheme: "file", Path: profileDir}).String()

	const chunkSize = 5
	for start := 0; start < len(items); start += chunkSize {
		end := start + chunkSize
		if end > len(items) {
			end = len(items)
		}
		chunk := items[start:end]
		inputDir := filepath.Join(root, fmt.Sprintf("input-%04d", start))
		outputDir := filepath.Join(root, fmt.Sprintf("output-%04d", start))
		_ = os.MkdirAll(inputDir, 0700)
		_ = os.MkdirAll(outputDir, 0700)

		type prepared struct {
			item      documents.BulkExportItem
			row       bulkDocumentManifestRow
			inputPath string
			pdfPath   string
			archive   string
		}
		preparedDocs := make([]prepared, 0, len(chunk))
		inputPaths := make([]string, 0, len(chunk))

		for _, item := range chunk {
			row := bulkManifestBase(item)
			if item.DocumentID == nil {
				row.Status = "missing_document"
				row.Detail = "Nu există încă o fișă generată pentru acest obiect."
				manifest = append(manifest, row)
				missing++
				continue
			}
			doc, getErr := a.Documents.GetGenerated(ctx, *item.DocumentID, true)
			if getErr != nil {
				row.Status = "error"
				row.Detail = getErr.Error()
				manifest = append(manifest, row)
				failed++
				continue
			}
			base := bulkArchiveStem(item, doc.FileName)
			inputPath := filepath.Join(inputDir, base+".docx")
			if writeErr := os.WriteFile(inputPath, doc.Content, 0600); writeErr != nil {
				row.Status = "error"
				row.Detail = writeErr.Error()
				manifest = append(manifest, row)
				failed++
				continue
			}
			preparedDocs = append(preparedDocs, prepared{item: item, row: row, inputPath: inputPath, pdfPath: filepath.Join(outputDir, base+".pdf"), archive: base + ".pdf"})
			inputPaths = append(inputPaths, inputPath)
		}

		commandDetail := ""
		if len(inputPaths) > 0 {
			args := []string{"-env:UserInstallation=" + profileURL, "--headless", "--nologo", "--nodefault", "--nofirststartwizard", "--convert-to", "pdf:writer_pdf_Export", "--outdir", outputDir}
			args = append(args, inputPaths...)
			timeout := 2*time.Minute + time.Duration(len(inputPaths))*15*time.Second
			if timeout > 6*time.Minute {
				timeout = 6 * time.Minute
			}
			chunkCtx, cancel := context.WithTimeout(ctx, timeout)
			cmd := exec.CommandContext(chunkCtx, officeBinary, args...)
			cmd.Env = append(os.Environ(), "HOME="+root, "TMPDIR="+root)
			output, cmdErr := cmd.CombinedOutput()
			cancel()
			if cmdErr != nil {
				commandDetail = strings.TrimSpace(string(output))
				if commandDetail == "" {
					commandDetail = cmdErr.Error()
				} else {
					commandDetail = cmdErr.Error() + ": " + trimBulkDetail(commandDetail)
				}
			}
		}

		for _, value := range preparedDocs {
			row := value.row
			content, readErr := os.ReadFile(value.pdfPath)
			if readErr != nil || len(content) == 0 {
				row.Status = "error"
				if commandDetail != "" {
					row.Detail = commandDetail
				} else if readErr != nil {
					row.Detail = readErr.Error()
				} else {
					row.Detail = "LibreOffice nu a produs fișierul PDF."
				}
				manifest = append(manifest, row)
				failed++
				continue
			}
			if writeErr := writeZipBytes(zw, value.archive, content); writeErr != nil {
				row.Status = "error"
				row.Detail = writeErr.Error()
				manifest = append(manifest, row)
				failed++
				continue
			}
			row.ArchiveFile = value.archive
			row.Status = "included"
			manifest = append(manifest, row)
			included++
		}
		flushBulkArchive(w, zw)
	}
	return manifest, included, missing, failed
}

func locateOfficeBinary() (string, error) {
	if configured := strings.TrimSpace(os.Getenv("VM_DOC_SOFFICE_BIN")); configured != "" {
		if filepath.IsAbs(configured) {
			if info, err := os.Stat(configured); err == nil && !info.IsDir() {
				return configured, nil
			}
			return "", fmt.Errorf("VM_DOC_SOFFICE_BIN points to an unavailable executable: %s", configured)
		}
		if path, err := exec.LookPath(configured); err == nil {
			return path, nil
		}
		return "", fmt.Errorf("VM_DOC_SOFFICE_BIN executable not found in PATH: %s", configured)
	}
	for _, candidate := range []string{"soffice", "libreoffice"} {
		if path, err := exec.LookPath(candidate); err == nil {
			return path, nil
		}
	}
	return "", errors.New("exportul PDF necesită LibreOffice/soffice pe server; instalează LibreOffice sau setează VM_DOC_SOFFICE_BIN către executabil")
}

func bulkArchiveFileName(objectType, format string, now time.Time) string {
	objectLabel := "vm"
	if objectType == "service" {
		objectLabel = "proiecte"
	}
	return fmt.Sprintf("vm-doc-%s-%s-%s.zip", objectLabel, format, now.UTC().Format("20060102-150405"))
}

func bulkManifestBase(item documents.BulkExportItem) bulkDocumentManifestRow {
	row := bulkDocumentManifestRow{ObjectType: item.ObjectType, ObjectID: item.ObjectID, ObjectName: item.ObjectName, DocumentNumber: item.DocumentNumber}
	if item.DocumentID != nil {
		row.DocumentID = *item.DocumentID
	}
	if item.GeneratedAt != nil {
		row.GeneratedAt = item.GeneratedAt.UTC().Format(time.RFC3339)
	}
	return row
}

func bulkArchiveEntryName(item documents.BulkExportItem, sourceFileName, extension string) string {
	return bulkArchiveStem(item, sourceFileName) + extension
}

func bulkArchiveStem(item documents.BulkExportItem, sourceFileName string) string {
	base := strings.TrimSuffix(filepath.Base(sourceFileName), filepath.Ext(sourceFileName))
	base = sanitizeBulkName(base)
	if base == "" {
		base = sanitizeBulkName(item.ObjectName)
	}
	if base == "" {
		base = item.ObjectType
	}
	return fmt.Sprintf("%06d_%s", item.ObjectID, base)
}

func sanitizeBulkName(value string) string {
	value = strings.TrimSpace(value)
	var b strings.Builder
	for _, r := range value {
		switch {
		case r >= 'a' && r <= 'z', r >= 'A' && r <= 'Z', r >= '0' && r <= '9', r == '-', r == '_', r == '.':
			b.WriteRune(r)
		default:
			b.WriteByte('-')
		}
	}
	return strings.Trim(b.String(), "-._")
}

func writeZipBytes(zw *zip.Writer, name string, content []byte) error {
	header := &zip.FileHeader{Name: filepath.ToSlash(name), Method: zip.Deflate}
	header.SetModTime(time.Now())
	entry, err := zw.CreateHeader(header)
	if err != nil {
		return err
	}
	_, err = entry.Write(content)
	return err
}

func writeBulkArchiveReadme(zw *zip.Writer, objectType, format string, options bulkDocumentExportOptions) error {
	label := "VM-urilor active (neretrase)"
	if objectType == "service" {
		label = "proiectelor/serviciilor active"
	}
	text := "VM-DOC - export în masă\n\n" +
		"Arhiva conține fișele pentru " + label + ".\n" +
		"Format export: " + strings.ToUpper(format) + ".\n" +
		"Obiectele fără fișă generată sau documentele care nu au putut fi pregătite sunt listate în _manifest.csv și _sumar.txt.\n"
	if format == "docx" && objectType == "vm" && options.RegenerateVMDocuments {
		text += "Fișele VM au fost regenerate înainte de export cu șablonul implicit; câmpul «Generat de» nu este inclus în document.\n"
	} else if format == "docx" && objectType == "service" {
		if options.GenerateMissingServices {
			text += "Fișele proiectelor care lipseau au fost generate cu șablonul implicit; câmpul «Generat de» nu este inclus în documentele nou generate.\n"
		}
		if options.IncludeServiceVMDocuments {
			text += "Fișele VM existente asociate proiectelor sunt incluse separat în directorul VM-uri/.\n"
		}
	}
	if !options.RegenerateVMDocuments && !options.GenerateMissingServices {
		text += "Exportul nu generează versiuni noi ale fișelor principale.\n"
	}
	return writeZipBytes(zw, "_README.txt", []byte(text))
}

func writeBulkSummary(zw *zip.Writer, total int, stats bulkDocumentExportStats) error {
	text := fmt.Sprintf("Total obiecte principale: %d\nIncluse în arhivă: %d\nFără fișă generată: %d\nErori: %d\nGenerate pentru că lipseau: %d\nRegenerate înainte de export: %d\n", total, stats.Included, stats.Missing, stats.Failed, stats.Generated, stats.Regenerated)
	if stats.VMIncluded > 0 || stats.VMMissing > 0 || stats.VMFailed > 0 {
		text += fmt.Sprintf("\nFișe VM asociate proiectelor incluse: %d\nFișe VM asociate lipsă: %d\nErori fișe VM asociate: %d\n", stats.VMIncluded, stats.VMMissing, stats.VMFailed)
	}
	return writeZipBytes(zw, "_sumar.txt", []byte(text))
}

func writeBulkManifest(zw *zip.Writer, rows []bulkDocumentManifestRow) error {
	entry, err := zw.Create("_manifest.csv")
	if err != nil {
		return err
	}
	writer := csv.NewWriter(entry)
	if err := writer.Write([]string{"object_type", "object_id", "object_name", "document_id", "document_number", "generated_at", "archive_file", "status", "detail"}); err != nil {
		return err
	}
	for _, row := range rows {
		if err := writer.Write([]string{row.ObjectType, strconv.FormatInt(row.ObjectID, 10), row.ObjectName, nullableBulkInt(row.DocumentID), row.DocumentNumber, row.GeneratedAt, row.ArchiveFile, row.Status, row.Detail}); err != nil {
			return err
		}
	}
	writer.Flush()
	return writer.Error()
}

func nullableBulkInt(value int64) string {
	if value <= 0 {
		return ""
	}
	return strconv.FormatInt(value, 10)
}

func flushBulkArchive(w http.ResponseWriter, zw *zip.Writer) {
	_ = zw.Flush()
	if flusher, ok := w.(http.Flusher); ok {
		flusher.Flush()
	}
}

func trimBulkDetail(value string) string {
	value = strings.TrimSpace(strings.ReplaceAll(value, "\x00", ""))
	if len(value) > 1000 {
		return value[:1000] + "…"
	}
	return value
}
