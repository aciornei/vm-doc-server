# Upgrade vm-doc-server 0.20.27 → 0.20.28

Versiunea 0.20.28 extinde numai exportul bulk **DOCX** din pagina Documente. Nu există migrare de bază de date și nu este necesar update de agent.

## Noutăți

- VM DOCX: checkbox **Regenerează toate fișele VM înainte de export**; implicit debifat.
- Fișele regenerate de bulk nu afișează `Generat de`; utilizatorul rămâne în istoricul documentului/Audit.
- Proiecte DOCX: checkbox **Generează fișa proiectului dacă nu există**; implicit debifat.
- Proiecte DOCX: checkbox **Include și fișele VM asociate proiectelor**; implicit debifat. Fișele VM sunt incluse separat sub `VM-uri/<proiect>/`.
- Exporturile PDF nu sunt modificate în această versiune.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.27 \
      /usr/local/src/vm-doc-server-0.20.28

tar -xzf vm-doc-server-0.20.28-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.28

cd /usr/local/src/vm-doc-server-0.20.28

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi înlocuiește binarul conform procedurii tale curente și repornește `vm-doc-server`. Nu este necesar restart/update pentru agent.

## Verificare funcțională

1. Deschide **Documente → Export în masă**.
2. Verifică faptul că toate checkboxurile noi sunt nebifate.
3. Testează VM DOCX fără bifă; trebuie să exporte ultima fișă existentă.
4. Bifează regenerarea VM și verifică în `_manifest.csv` că fișele au fost regenerate; documentele noi nu trebuie să afișeze `Generat de`.
5. La Proiecte DOCX, testează separat generarea fișelor lipsă și includerea fișelor VM.
6. PDF-urile trebuie să se comporte identic cu 0.20.27.
