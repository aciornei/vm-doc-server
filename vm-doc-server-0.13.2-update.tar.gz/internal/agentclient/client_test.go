package agentclient

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"

	"vm-doc-server/internal/domain"
)

func TestValidateTargetRejectsCredentialsAndPath(t *testing.T) {
	client, err := New([]string{"10.0.0.0/8"}, 1024)
	if err != nil {
		t.Fatal(err)
	}
	for _, raw := range []string{
		"https://user:password@vm1:9078",
		"https://vm1:9078/api",
		"file:///tmp/inventory.json",
	} {
		if err := client.validateTarget(context.Background(), raw); err == nil {
			t.Fatalf("target %q unexpectedly accepted", raw)
		}
	}
}

func TestUpdateStatusAndForceUpdate(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer secret" {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/v1/update":
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{"enabled":true,"auto_install":true,"channel":"testing","current_version":"1.3.3","state":"idle"}`))
		case r.Method == http.MethodPost && r.URL.Path == "/v1/update/check":
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{"enabled":true,"auto_install":true,"channel":"testing","current_version":"1.3.3","state":"installing","available_version":"1.3.4"}`))
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()

	client, err := New(nil, 1<<20)
	if err != nil {
		t.Fatal(err)
	}
	agent := domain.Agent{BaseURL: server.URL, RequestTimeoutSeconds: 5}
	status, err := client.UpdateStatus(context.Background(), agent, "secret")
	if err != nil {
		t.Fatal(err)
	}
	if status.Channel != "testing" || status.CurrentVersion != "1.3.3" || status.State != "idle" {
		t.Fatalf("unexpected status: %+v", status)
	}
	status, err = client.ForceUpdate(context.Background(), agent, "secret")
	if err != nil {
		t.Fatal(err)
	}
	if status.State != "installing" || status.AvailableVersion != "1.3.4" {
		t.Fatalf("unexpected forced update status: %+v", status)
	}
}
