-- 0.13.2: cache agent auto-update status for fast listing and forced update operations.

ALTER TABLE agents
  ADD COLUMN IF NOT EXISTS update_channel VARCHAR(16) NOT NULL DEFAULT '' AFTER agent_version,
  ADD COLUMN IF NOT EXISTS update_enabled TINYINT(1) NULL AFTER update_channel,
  ADD COLUMN IF NOT EXISTS update_auto_install TINYINT(1) NULL AFTER update_enabled,
  ADD COLUMN IF NOT EXISTS update_state VARCHAR(32) NOT NULL DEFAULT '' AFTER update_auto_install,
  ADD COLUMN IF NOT EXISTS update_available_version VARCHAR(64) NOT NULL DEFAULT '' AFTER update_state,
  ADD COLUMN IF NOT EXISTS update_last_check_at DATETIME(6) NULL AFTER update_available_version,
  ADD COLUMN IF NOT EXISTS update_last_success_at DATETIME(6) NULL AFTER update_last_check_at,
  ADD COLUMN IF NOT EXISTS update_last_error TEXT NULL AFTER update_last_success_at,
  ADD COLUMN IF NOT EXISTS update_status_checked_at DATETIME(6) NULL AFTER update_last_error;

CREATE INDEX IF NOT EXISTS idx_agents_update_channel ON agents(update_channel, enabled);
CREATE INDEX IF NOT EXISTS idx_agents_update_status_checked ON agents(update_status_checked_at);
