# Auto-update vm-doc-agent

`vm-doc-server 0.13.2` poate publica versiuni pentru `vm-doc-agent 1.3.0+`. Agentul nu accesează GitHub: manifestul și binarele sunt luate numai de la serverul central configurat.

## Configurare server

```yaml
agent_updates:
  enabled: true
  directory: "/var/lib/vm-doc-server/agent-updates"
```

Directorul este creat la pornire și are forma:

```text
/var/lib/vm-doc-server/agent-updates/
├── releases.json
└── files/
    ├── vm-doc-agent-1.3.1-linux-amd64
    ├── vm-doc-updater-1.3.1-linux-amd64
    ├── vm-doc-agent-1.3.1-windows-amd64.exe
    └── vm-doc-updater-1.3.1-windows-amd64.exe
```

## Repository preîncărcat 1.3.2

Pachetul release 0.11.1 conține `vm-doc-agent-update-repository-1.3.2.tar.gz`: 1.3.1 rămâne pe `stable`, iar 1.3.2 este publicat pe `testing` pentru validare. După testul pe un VM pilot, 1.3.2 poate fi promovat în `stable` direct din UI. Se poate instala direct în `/var/lib/vm-doc-server` și apoi se setează proprietarul `vm-doc:vm-doc`.


## Administrare din interfața web

În 0.12.0, secțiunea **Agenți → Release-uri agent** permite:

- publicarea unui release prin upload pentru `vm-doc-agent` și `vm-doc-updater`;
- alegerea canalului `testing` sau `stable`;
- promovarea unui release din `testing` în `stable`;
- ștergerea unui release.

Publicarea necesită permisiunea `agents.manage`. Serverul calculează SHA-256, copiază artifactele în `files/` și actualizează atomic `releases.json`.


## Verificare și update forțat din server

În 0.13.2, pagina **Agenți → Listare agenți** afișează canalul `stable` / `testing` raportat de agent și oferă butonul **Update**. Serverul folosește tokenul local deja configurat pentru agent și apelează:

```text
POST /v1/update/check
Authorization: Bearer <agent-token>
```

Acest endpoint există în `vm-doc-agent 1.3.3` și pornește imediat verificarea. Dacă există o versiune mai nouă pe canalul configurat local, agentul o descarcă și programează instalarea; dacă este deja la zi, răspunde cu starea `current`. Nu se modifică `updates.check_interval`.

Serverul cache-uiește ultimul status în tabela `agents`, astfel încât listarea a sute de agenți să nu genereze sute de request-uri. Cache-ul este reîmprospătat la Test/Colect/Update și periodic la heartbeat pentru agenții auto-înregistrați.

## Publicarea unui release

Serverul include utilitarul `/opt/vm-doc-server/bin/vm-doc-agent-release`. Acesta copiază artifactele, calculează SHA-256 și dimensiunile și actualizează atomic `releases.json`.

Linux stable:

```bash
sudo -u vm-doc /opt/vm-doc-server/bin/vm-doc-agent-release \
  -directory /var/lib/vm-doc-server/agent-updates \
  -version 1.3.1 -channel stable -os linux -arch amd64 \
  -agent /tmp/vm-doc-agent \
  -updater /tmp/vm-doc-updater \
  -notes 'Release stabil 1.3.1'
```

Windows stable, publicat de pe serverul Linux:

```bash
sudo -u vm-doc /opt/vm-doc-server/bin/vm-doc-agent-release \
  -directory /var/lib/vm-doc-server/agent-updates \
  -version 1.3.1 -channel stable -os windows -arch amd64 \
  -agent /tmp/vm-doc-agent.exe \
  -updater /tmp/vm-doc-updater.exe
```

Pentru pilot se folosește `-channel testing`. După validare se publică aceeași versiune pe `stable`.

## Protocol agent

Agentul cere manifestul:

```text
GET /api/v1/agent-updates/latest?channel=stable&os=linux&arch=amd64&current=1.3.0
Authorization: Bearer <central-registration-token>
```

Dacă există o versiune mai nouă, răspunsul conține versiunea, URL-urile locale, SHA-256, dimensiunile și data publicării. Download-ul este permis numai pentru fișiere enumerate în repository.

Endpoint-uri:

- `GET /api/v1/agent-updates/latest` — folosit de agent, autentificare cu registration token;
- `GET /api/v1/agent-updates/download/{filename}` — artifact, aceeași autentificare;
- `GET /api/v1/agent-updates/releases` — listă pentru UI, permisiune `agents.read`.

## Securitate

- serverul recalculează hash-ul artifactului înainte de a-l publica în manifest;
- agentul recalculează SHA-256 după download;
- agentul refuză URL-uri de download de la alt host/schemă/port decât `central.url`;
- agentul verifică versiunea executabilului înainte de instalare;
- noul agent trebuie să treacă `/health`, altfel helperul restaurează binarul anterior;
- pentru profilul curent `central.url` este HTTP intern; firewall-ul și segmentarea rețelei trebuie să limiteze traficul. Migrarea ulterioară la HTTPS este recomandată.

## Bootstrap

Auto-update-ul nu poate apărea retroactiv pe agenții vechi. `1.3.0` trebuie instalat manual o singură dată. Din acel moment, `1.3.1+` poate fi livrat automat.
