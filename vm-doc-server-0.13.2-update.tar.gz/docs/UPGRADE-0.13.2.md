# Upgrade vm-doc-server 0.13.1 → 0.13.2

## Ce se schimbă

- buton `Update` în lista Agenți;
- vizibilitate și filtru pentru canalul `stable` / `testing`;
- cache central pentru statusul auto-update;
- export Excel Agenți extins;
- migrare MariaDB `027_agent_update_status.up.sql`.

`vm-doc-agent 1.3.3` este suficient; nu este necesară actualizarea agentului pentru aceste funcții.

## Upgrade

Din sursa 0.13.1:

```bash
cp -a /usr/local/src/vm-doc-server-0.13.1 /usr/local/src/vm-doc-server-0.13.2
tar -xzf vm-doc-server-0.13.2-update.tar.gz -C /usr/local/src/vm-doc-server-0.13.2
cd /usr/local/src/vm-doc-server-0.13.2
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
make build
systemctl stop vm-doc-server vm-doc-collector
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
install -m 0755 bin/vm-doc-collector /opt/vm-doc-server/bin/vm-doc-collector
install -m 0755 bin/vm-doc-agent-release /opt/vm-doc-server/bin/vm-doc-agent-release
systemctl start vm-doc-server vm-doc-collector
```

Migrarea 027 este aplicată automat la pornirea serverului/collectorului.

## După pornire

La prima afișare, agenții pentru care serverul nu a citit încă `/v1/update` pot avea `—` la **Canal update**. Valoarea apare automat la următorul Test/Colect/heartbeat sau imediat după apăsarea butonului **Update**.

Verificări recomandate:

```bash
curl -s http://127.0.0.1:9080/version
journalctl -u vm-doc-server -n 100 --no-pager
```

În UI verifică un agent `testing` și unul `stable`, apoi testează butonul **Update** pe un VM pilot.
