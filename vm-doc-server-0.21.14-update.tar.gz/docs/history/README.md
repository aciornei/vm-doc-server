# Istoric de versiuni VM-DOC Server

Fișierele istorice din rădăcina proiectului au fost reorganizate, **nu șterse**.

- [`INDEX.md`](INDEX.md) — legături către toate fișierele istorice.
- [`upgrades/`](upgrades/) — instrucțiuni de upgrade, pe versiuni.
- [`release-notes/`](release-notes/) — descrierile release-urilor.
- [`verification/`](verification/) — verificări de release păstrate pentru referință.

**Upgrade-ul curent:** [`UPGRADE-0.21.14.md`](upgrades/UPGRADE-0.21.14.md).

## Rădăcină curată

Din această versiune, orice `UPGRADE-*.md`, `RELEASE-NOTES-*.txt` sau `VERIFICATION-*.md` nou trebuie creat direct aici, nu în rădăcina proiectului. Pentru o instalare peste o copie istorică folosește scriptul `scripts/cleanup-source-tree.sh` după extragerea update-ului.

**Nu muta** `migrations/`, `go.mod`, `go.sum`, `vendor/`, `web/`, `internal/`, `configs/`, `deploy/` sau directoarele runtime. Copiile vechi de surse `vm-doc-server-X.Y.Z` se pot arhiva prin script **în afara** proiectului activ.

Dacă două documente cu același nume sunt diferite, `cleanup-source-tree.sh` păstrează varianta din rădăcină sub `variants/` cu hash SHA-256 în nume; vezi UPGRADE-0.21.14.md.
