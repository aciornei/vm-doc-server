# Upgrade VM-DOC Server 0.21.13 → 0.21.14

**Scop:** corectarea erorii `ERROR: conflicting file, no changes made: UPGRADE-0.20.33.md` la `cleanup-source-tree.sh --apply`.

Nicio schimbare a logicii serverului, bazei de date, API/Swagger sau agentului. Niciun nou fișier de migrare SQL.

## Recomandare pentru sursele 0.21.13 existente

```bash
cd /usr/local/src/vm-doc-server-0.21.13
# Înlocuiește scriptul scripts/cleanup-source-tree.sh din update-ul 0.21.14.
# Poți aplica update-ul complet și păstra directorul 0.21.13 numai pentru curățare.
tar -xzf /cale/vm-doc-server-0.21.14-update.tar.gz -C .
bash scripts/cleanup-source-tree.sh --dry-run
bash scripts/cleanup-source-tree.sh --apply
bash scripts/cleanup-source-tree.sh --check
```

Pentru o versiune sursă separată, folosește un director nou `vm-doc-server-0.21.14`, creat ca copie a 0.21.13, înainte de extragerea update-ului.

**Regulă nouă:** dacă un document din rădăcină diferă de cel din `docs/history`, sunt păstrate ambele. Copia diferită din rădăcină este mutată în `docs/history/variants/<categorie>/<nume>.root-<sha256>.<ext>`. Copia existentă din istoric nu este modificată. Duplicate identice sunt eliminate numai după `cmp` byte cu byte. `--apply` poate fi repetat. Nu sunt modificate `vendor/`, `migrations/` sau datele runtime.

Dacă un director sursă vechi are deja aceeași destinație în directorul extern de arhivare, scriptul se oprește preventiv, fără schimbări; cazul respectiv necesită alegerea unei destinații externe diferite prin `VM_DOC_ARCHIVE_DIR`.

## Verificare offline

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Build-ul integral trebuie verificat pe mașina cu `vendor/` instalat. Nu este necesară reinstalarea binarului pentru a folosi doar scriptul reparat.
