package documents

import (
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
)

func TestRenderServiceMarkdownOutlineExport(t *testing.T) {
	data := ServiceGenerationData{
		Service: domain.InternalService{
			ID:                  7,
			Name:                "Metabase",
			ServiceCode:         "bi.metabase",
			ShortDescription:    "Rapoarte BI",
			Authentication:      "OIDC / Keycloak",
			ServiceURL:          "https://bi.example",
			Technologies:        "Java, PostgreSQL, Nginx",
			Criticality:         "high",
			DocumentationStatus: "approved",
			Active:              true,
			Description:         "Descriere",
			DescriptionRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{{Type: "paragraph", Runs: []domain.RichTextRun{{Text: "Important", Bold: true}, {Text: " text", Italic: true}}}}},
			Purpose:             "Scop",
			Objectives:          "Obiectiv",
			VMCount:             2,
			VMs: []domain.InternalServiceVM{
				{ID: 10, Name: "vm-prod", GuestHostname: "vm-prod", Environment: "prod", PrimaryIP: "10.0.0.10", LayerName: "App", TechnicalRole: "Frontend"},
				{ID: 11, Name: "vm-test", GuestHostname: "vm-test", Environment: "test", PrimaryIP: "10.0.1.10", LayerName: "App", TechnicalRole: "Frontend"},
			},
		},
		GeneratedAt:    time.Date(2026, 9, 14, 10, 0, 0, 0, time.UTC),
		DocumentNumber: "FSI-20260914-000007-ABCD",
		Attachments:    []domain.InternalServiceAttachment{{Title: "Arhitectură", FileName: "arhitectura.docx", ExtractedText: "Detalii proiect"}},
		VMDocuments:    []ServiceVMDocument{{VMID: 10, VMName: "vm-prod", Environment: "prod", DocumentNumber: "FVM-1", DownloadURL: "https://vm-doc.example/api/v1/documents/1/download"}},
	}

	text := string(RenderServiceMarkdown(data))
	for _, expected := range []string{
		"# Metabase",
		"**Număr electronic document:** FSI-20260914-000007-ABCD",
		"## 1. Identificare serviciu",
		"**Important**",
		"*text*",
		"### PROD",
		"### TEST",
		"Documentație suplimentară a serviciului",
		"Detalii proiect",
		"Anexe — fișe tehnice VM",
		"A1. vm-prod",
		"[Deschide fișa VM](https://vm-doc.example/api/v1/documents/1/download)",
	} {
		if !strings.Contains(text, expected) {
			t.Fatalf("markdown export missing %q:\n%s", expected, text)
		}
	}
}

func TestServiceMarkdownFileName(t *testing.T) {
	name := ServiceMarkdownFileName(ServiceGenerationData{Service: domain.InternalService{ID: 9, ServiceCode: "bi.metabase"}, DocumentNumber: "FSI-TEST"})
	if name != "bi.metabase-fsi-test.md" {
		t.Fatalf("unexpected markdown filename: %s", name)
	}
}
