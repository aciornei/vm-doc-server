# Upgrade vm-doc-server 0.20.1 → 0.20.2

Versiunea 0.20.2 adaugă exportul fișei serviciului intern în Markdown pentru import manual în Outline sau alt wiki.

## Noutăți

- buton nou **Markdown pentru Outline** în pagina serviciului, secțiunea Documentație;
- export `.md` prin `POST /api/v1/services/{id}/documents/markdown`;
- structura Markdown urmează capitolele fișei de serviciu DOCX;
- rich-text-ul descrierii, scopului și obiectivelor este convertit în Markdown;
- documentația suplimentară DOCX este inclusă prin textul extras;
- anexele VM sunt listate A1, A2… și includ linkul către fișa VM când `app.base_url` este configurat;
- exportul Markdown nu este salvat în istoricul documentelor;
- nu există migrare DB și nu este necesar update de agent.

## Upgrade offline

Pachetul incremental trebuie aplicat peste sursa 0.20.1 care are deja `go.mod`, `go.sum` și `vendor/` funcționale în mediul offline:

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.1 vm-doc-server-0.20.2
tar -xzf vm-doc-server-0.20.2-update.tar.gz -C vm-doc-server-0.20.2
cd vm-doc-server-0.20.2
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

După instalarea binarului, reporniți `vm-doc-server` și folosiți `Ctrl+F5` în browser pentru reîncărcarea JavaScript-ului.

## Utilizare

În Servicii → serviciul dorit → Documentație, apăsați **Markdown pentru Outline**. Browserul descarcă un fișier `.md`, care poate fi importat sau copiat manual în Outline.
