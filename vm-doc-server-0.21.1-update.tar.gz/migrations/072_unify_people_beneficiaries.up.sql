-- 0.21.1: canonical personnel registry is people (used by VM responsibilities).
-- Keep beneficiary_people as read-only legacy/migration trace, with person_id mapping.
ALTER TABLE people
  ADD COLUMN IF NOT EXISTS beneficiary_department_id BIGINT UNSIGNED NULL,
  ADD COLUMN IF NOT EXISTS beneficiary_ad_guid CHAR(36) NULL,
  ADD UNIQUE INDEX IF NOT EXISTS uq_people_beneficiary_ad_guid (beneficiary_ad_guid),
  ADD INDEX IF NOT EXISTS idx_people_beneficiary_department (beneficiary_department_id);
ALTER TABLE beneficiary_people
  ADD COLUMN IF NOT EXISTS person_id BIGINT UNSIGNED NULL,
  ADD INDEX IF NOT EXISTS idx_beneficiary_legacy_person (person_id);

-- Reuse previously imported persons by DN or email; do not modify their roles/IDs.
UPDATE beneficiary_people bp
SET bp.person_id=(SELECT p.id FROM people p
 WHERE (bp.ad_object_guid IS NOT NULL AND p.beneficiary_ad_guid=bp.ad_object_guid)
    OR (bp.source='ad' AND p.source='ldap' AND p.directory_dn<>'' AND LOWER(p.directory_dn)=LOWER(bp.ldap_dn))
    OR (bp.email<>'' AND LOWER(p.email)=LOWER(bp.email))
 ORDER BY CASE WHEN p.beneficiary_ad_guid=bp.ad_object_guid THEN 0 WHEN p.source='ldap' THEN 1 ELSE 2 END,p.id LIMIT 1)
WHERE bp.person_id IS NULL;

INSERT IGNORE INTO people(display_name,email,source,directory_dn,beneficiary_ad_guid,beneficiary_department_id,active)
SELECT bp.display_name,bp.email,IF(bp.source='ad','ldap','manual'),COALESCE(bp.ldap_dn,''),bp.ad_object_guid,bp.department_id,bp.active
FROM beneficiary_people bp WHERE bp.person_id IS NULL;

UPDATE beneficiary_people bp SET bp.person_id=(SELECT p.id FROM people p
 WHERE (bp.ad_object_guid IS NOT NULL AND p.beneficiary_ad_guid=bp.ad_object_guid)
    OR (bp.email<>'' AND LOWER(p.email)=LOWER(bp.email))
    OR (p.display_name=bp.display_name AND p.email=bp.email)
 ORDER BY CASE WHEN p.beneficiary_ad_guid=bp.ad_object_guid THEN 0 WHEN p.source='ldap' THEN 1 ELSE 2 END,p.id LIMIT 1)
WHERE bp.person_id IS NULL;

UPDATE people p JOIN beneficiary_people bp ON bp.person_id=p.id
SET p.beneficiary_department_id=COALESCE(bp.department_id,p.beneficiary_department_id),
    p.beneficiary_ad_guid=COALESCE(bp.ad_object_guid,p.beneficiary_ad_guid),
    p.directory_dn=IF(bp.source='ad' AND COALESCE(bp.ldap_dn,'')<>'',bp.ldap_dn,p.directory_dn),
    p.source=IF(bp.source='ad','ldap',p.source);

-- Durable staging table prevents losing legacy beneficiary assignments if a migration is interrupted.
CREATE TABLE IF NOT EXISTS beneficiary_assignment_people_072 (
 legacy_assignment_id BIGINT UNSIGNED PRIMARY KEY,
 resource_type VARCHAR(32) NOT NULL,
 resource_id BIGINT UNSIGNED NOT NULL,
 person_id BIGINT UNSIGNED NOT NULL,
 created_at DATETIME(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO beneficiary_assignment_people_072(legacy_assignment_id,resource_type,resource_id,person_id,created_at)
SELECT a.id,a.resource_type,a.resource_id,bp.person_id,a.created_at
FROM beneficiary_assignments a JOIN beneficiary_people bp ON bp.id=a.beneficiary_id
WHERE a.beneficiary_type='person' AND bp.person_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM beneficiary_assignment_people_072 LIMIT 1);
-- Remove legacy IDs only after the mapping has been durably backed up.
DELETE a FROM beneficiary_assignments a JOIN beneficiary_assignment_people_072 m ON m.legacy_assignment_id=a.id WHERE a.beneficiary_type='person';
INSERT IGNORE INTO beneficiary_assignments(resource_type,resource_id,beneficiary_type,beneficiary_id,created_at)
SELECT resource_type,resource_id,'person',person_id,created_at FROM beneficiary_assignment_people_072;

CREATE TABLE IF NOT EXISTS beneficiary_sync_roots (
 dn_hash CHAR(64) NOT NULL PRIMARY KEY,
 ldap_dn VARCHAR(1024) NOT NULL,
 selected_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
