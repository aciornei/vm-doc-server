# VM-DOC Server 0.21.0 → 0.21.1

## Înainte de actualizare
- Fă backup/snapshot MariaDB. **Migrarea 072 mută asocierile persoanelor** din nomenclatorul duplicat `beneficiary_people` în nomenclatorul canonic `people`.
- Se păstrează datele vechi în `beneficiary_people` și copia de siguranță `beneficiary_assignment_people_072`; nu le șterge.
- Este un update exclusiv de server; agentul și `vendor/` nu se schimbă.

## Instalare offline
```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.0 vm-doc-server-0.21.1
tar -xzf /cale/vm-doc-server-0.21.1-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.1
cd /usr/local/src/vm-doc-server-0.21.1
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```
**Nu înlocui binarul dacă testele/compilarea eșuează.** Folosește procedura existentă de stop, instalare binar și restart. Migrarea 072 rulează automat la pornire.

## Probe în staging
1. Numărul persoanelor din Nomenclatoare → Persoane și din selectorul Beneficiari → Persoană coincide; nu există al doilea nomenclator.
2. Responsabilitățile VM existente sunt păstrate; beneficiarii individuali existenți trimit la aceeași persoană și rămân în rapoarte.
3. Departamente → Sincronizare AD: bifează OU-uri, schimbă pagina, revino, așteaptă salvarea automată (sau apasă Salvează selecția), apoi reîncarcă browserul. Selecția trebuie păstrată.
4. Filtrează OU, bifează/debifează doar rezultatele afișate; ordinea coloanelor trebuie să rămână stabilă.
5. Deschide Adaugă departament manual și selectorul de beneficiari pe VM / Docker / Web / Bază în tema curentă: controalele sunt lizibile.
6. Adaugă/editează persoană din nomenclator și selectează OU beneficiar; verifică păstrarea rolurilor VM.
7. Verifică endpointurile Swagger GET /api/v1/beneficiaries/ad/ous, PUT /api/v1/beneficiaries/ad/roots și GET /api/v1/people.

## Rollback
Revino la binarul 0.21.0 numai împreună cu restaurarea backupului DB pre-migrare, deoarece 0.21.0 interpretează ID-urile beneficiarilor-persoană în vechiul tabel.
