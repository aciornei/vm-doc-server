# VM-DOC Server 0.21.1 — test report

Checks carried out in assembly environment:
- All 166 Go source files parse with Go parser; gofmt applied to modified files.
- node --check web/static/js/app.js: PASS.
- OpenAPI 3.1 YAML parse and new path: PASS.
- Go standard-library-only ./internal/xlsx unit tests: PASS.
- ZIP/TAR archive integrity: PASS.
- Update overlay on pristine 0.21.0 and patch -p1 application: byte-identical to 0.21.1 source: PASS.

Not tested here:
- Entire Go build and go test ./... (vendor not provided in uploaded source).
- Migration 072 against a live MariaDB dataset; AD sync against real Active Directory.
- Browser UI regression tests (screen/theme/interaction) on a running VM-DOC instance.

IMPORTANT: Migration 072 remaps existing person beneficiary references. Back up MariaDB and deploy first to staging.
