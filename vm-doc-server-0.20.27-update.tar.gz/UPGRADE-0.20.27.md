# Upgrade vm-doc-server 0.20.26 → 0.20.27

## Ce se schimbă

Versiunea 0.20.27 adaugă în pagina **Documente** patru exporturi bulk:

- toate fișele VM în DOCX (ZIP);
- toate fișele VM în PDF (ZIP);
- toate fișele proiectelor/serviciilor în DOCX (ZIP);
- toate fișele proiectelor/serviciilor în PDF (ZIP).

Fiecare export folosește **ultima fișă deja generată** pentru fiecare VM activ/neretras sau proiect activ. Exportul nu regenerează fișele și nu adaugă rânduri noi în `generated_documents`.

Arhiva conține și:

- `_manifest.csv` — fiecare obiect, documentul ales, fișierul din arhivă și starea (`included`, `missing_document`, `error`);
- `_sumar.txt` — total/incluse/lipsă/erori;
- `_README.txt` — explicația exportului.

## PDF / LibreOffice

Exportul PDF este realizat on-demand cu `soffice` / `libreoffice` în mod headless. Serverul caută automat executabilul în `PATH`.

Dacă executabilul este în altă locație, adaugă în unitatea systemd:

```ini
Environment="VM_DOC_SOFFICE_BIN=/usr/bin/soffice"
```

apoi:

```bash
systemctl daemon-reload
systemctl restart vm-doc-server
```

Verificare rapidă:

```bash
sudo -u vm-doc-server /usr/bin/soffice --headless --version
```

Înlocuiește `vm-doc-server` cu utilizatorul real al serviciului dacă unitatea rulează sub alt cont.

Conversia folosește profile și directoare temporare izolate, șterse automat la final. Arhiva este transmisă incremental; handlerul extinde deadline-ul de scriere pentru exporturile mari și trimite `X-Accel-Buffering: no` către Nginx.

## Bază de date și agent

Nu există migrare DB nouă.

Nu este necesar update pentru `vm-doc-agent`; agentul principal rămâne 1.7.9.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.26 \
      /usr/local/src/vm-doc-server-0.20.27

tar -xzf vm-doc-server-0.20.27-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.27

cd /usr/local/src/vm-doc-server-0.20.27

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

## Verificare funcțională

1. Deschide **Documente → Export în masă**.
2. Descarcă arhiva `VM-uri DOCX` și verifică `_sumar.txt` / `_manifest.csv`.
3. Descarcă `VM-uri PDF` și verifică 2-3 fișiere PDF.
4. Repetă pentru `Proiecte DOCX` și `Proiecte PDF`.
5. Un VM/proiect fără fișă generată trebuie să apară în manifest cu `missing_document`, fără să blocheze restul exportului.
