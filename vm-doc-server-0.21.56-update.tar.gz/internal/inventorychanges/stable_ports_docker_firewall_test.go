package inventorychanges

import (
	"encoding/json"
	"strings"
	"testing"
)

// Apache workers can change between collections without any endpoint change.
// The key MUST use the same unique process names as the stored JSON value.
func TestApachePortKeyStableAcrossWorkerCount(t *testing.T) {
	makeSnapshot := func(names ...string) []byte {
		processes := make([]map[string]string, 0, len(names))
		for _, name := range names {
			processes = append(processes, map[string]string{"name": name, "executable": "/usr/lib/apache2/mpm-prefork/apache2"})
		}
		raw, _ := json.Marshal(map[string]any{"listening_ports": []any{map[string]any{
			"protocol": "tcp", "port": 443, "processes": processes,
		}}})
		return raw
	}
	one, err := extractTracked(makeSnapshot("apache2"))
	if err != nil {
		t.Fatal(err)
	}
	many, err := extractTracked(makeSnapshot("apache2", "apache2", "apache2", "apache2"))
	if err != nil {
		t.Fatal(err)
	}
	const key = "ports|listening_port|tcp/443/apache2"
	if len(one) != 1 || len(many) != 1 {
		t.Fatalf("unexpected keys: one=%v many=%v", one, many)
	}
	if !canonicalEqual(one[key].Value, many[key].Value) {
		t.Fatalf("worker-count change must not change 443 identity or value: %v != %v", one, many)
	}
	if _, ok := many["ports|listening_port|tcp/443/apache2,apache2"]; ok {
		t.Fatal("duplicate workers leaked into object key")
	}
	other, err := extractTracked(makeSnapshot("apache2", "nginx"))
	if err != nil {
		t.Fatal(err)
	}
	if _, ok := other[key]; ok {
		t.Fatal("genuine process identity change lost")
	}
}

func TestDockerBridgeGuardNftablesIsSuppressedPrecisely(t *testing.T) {
	positive := []string{
		`ip daddr 172.18.0.9 iifname != "br-f392b3fbdb12" counter drop`,
		`ip daddr 172.18.0.9 iifname != "br-87894e600741" counter packets 12 bytes 945 drop # handle 12`,
		`ip daddr 10.10.4.5 iifname != "br-123456789abc" counter drop`,
	}
	for _, text := range positive {
		if !isGeneratedFirewallRule(map[string]any{"backend": "nftables", "chain": "FORWARD", "rule": text}) {
			t.Fatalf("missed generated Docker isolation rule: %s", text)
		}
	}
	negative := []struct{ backend, chain, rule string }{
		{"nftables", "FORWARD", `ip daddr 8.8.8.8 iifname != "br-f392b3fbdb12" counter drop`},
		{"nftables", "FORWARD", `ip daddr 172.18.0.9 iifname != "br-static" counter drop`},
		{"nftables", "FORWARD", `ip daddr 172.18.0.9 iifname != "br-f392b3fbdb12" counter accept`},
		{"nftables", "FORWARD", `ip daddr 172.18.0.9 iifname "br-f392b3fbdb12" counter drop`},
		{"nftables", "FORWARD", `ip daddr 172.18.0.9 iifname != "br-f392b3fbdb12" counter log drop`},
		{"nftables", "FORWARD", `ip daddr 172.18.0.9 iifname != "br-f392b3fbdb12" counter drop extra`},
		{"nftables", "DOCKER-USER", `ip daddr 172.18.0.9 iifname != "br-f392b3fbdb12" counter drop`},
		{"iptables", "FORWARD", `ip daddr 172.18.0.9 iifname != "br-f392b3fbdb12" counter drop`},
		{"windows_firewall", "FORWARD", `ip daddr 172.18.0.9 iifname != "br-f392b3fbdb12" counter drop`},
	}
	for _, tc := range negative {
		if isGeneratedFirewallRule(map[string]any{"backend": tc.backend, "chain": tc.chain, "rule": tc.rule}) {
			t.Fatalf("suppressed unrelated firewall policy: %+v", tc)
		}
	}
}

func TestDockerBridgeRotationNotTrackedButGenuineRuleRemains(t *testing.T) {
	makeInventory := func(bridge string) []byte {
		input := map[string]any{"firewall": map[string]any{"rules": []map[string]string{
			{"backend": "nftables", "family": "ip", "table": "filter", "chain": "FORWARD", "rule": `ip daddr 172.18.0.9 iifname != "` + bridge + `" counter drop`},
			{"backend": "nftables", "family": "ip", "table": "filter", "chain": "FORWARD", "rule": `tcp dport 443 accept`},
		}}}
		b, _ := json.Marshal(input)
		return b
	}
	a, err := extractTracked(makeInventory("br-f392b3fbdb12"))
	if err != nil {
		t.Fatal(err)
	}
	b, err := extractTracked(makeInventory("br-87894e600741"))
	if err != nil {
		t.Fatal(err)
	}
	if len(a) != 2 || len(b) != 2 { // general Firewall + explicit 443 rule
		t.Fatalf("unexpected tracked rule count: %d %d", len(a), len(b))
	}
	for key, item := range a {
		if strings.Contains(key, "br-") {
			t.Fatal("generated bridge rule tracked", key)
		}
		if !canonicalEqual(item.Value, b[key].Value) {
			t.Fatalf("false modification after bridge recreation: %s", key)
		}
	}
}
