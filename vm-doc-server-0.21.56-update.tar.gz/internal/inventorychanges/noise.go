package inventorychanges

import (
	"context"
	"database/sql"
	"fmt"
	"net/netip"
	"regexp"
	"strconv"
	"strings"
)

// Default change-history policy: retain all raw snapshots. Only suppress
// unstable observations in change events. A selected Principal port is exempt.
const ephemeralPortStart = 49152
const ephemeralPortEnd = 65535

// Automatically generated Linux veth peer names (commonly Docker/LXC) are
// ephemeral topology, not durable VM network configuration. Match only the
// kernel-style hexadecimal suffix; keep deliberately named veth interfaces,
// bridges, VLANs and normal NICs in documentation-change history.
var ephemeralVethNameRE = regexp.MustCompile(`(?i)^veth[0-9a-f]{5,}(?:@if[0-9]+)?$`)

func isEphemeralVethInterface(name string) bool {
	return ephemeralVethNameRE.MatchString(strings.TrimSpace(name))
}

// Linux transient instances: lxd-installer uses multi-number instance names
// such as lxd-installer@177-1372636-0.service. Do not match named templates.
var ephemeralServiceRE = regexp.MustCompile(`(?i)^(?:(?:user|user-runtime-dir)@[0-9]+|lxd-installer@[0-9]+(?:-[0-9]+)*)\.service$`)

// Windows per-user service instances have a session/logon-derived hexadecimal
// suffix. Match only Microsoft's known per-user service families, not every
// service ending with _<hex> (which might be an application service).
var windowsPerUserServiceRE = regexp.MustCompile(`(?i)^([a-z][a-z0-9]*)_([0-9a-f]{5,12})$`)

var windowsPerUserFamilies = map[string]bool{
	"aarsvc": true, "bcastdvruserservice": true,
	"bluetoothuserservice": true, "captureservice": true,
	"cbdhsvc": true, "cdpusersvc": true, "cloudbackuprestoresvc": true,
	"consentuxusersvc": true, "credentialenrollmentmanagerusersvc": true,
	"devicepickerusersvc": true, "devicesflowusersvc": true,
	"deviceassociationbrokersvc": true, "npsmsvc": true,
	"p9rdrservice":     true,
	"messagingservice": true, "onesyncsvc": true,
	"pimindexmaintenancesvc": true, "printworkflowusersvc": true,
	"udkusersvc": true, "unistoresvc": true, "userdatasvc": true,
	"webthreatdefusersvc": true, "wpnuserservice": true,
}

func isEphemeralService(name string) bool {
	name = strings.TrimSpace(name)
	if ephemeralServiceRE.MatchString(name) {
		return true
	}
	match := windowsPerUserServiceRE.FindStringSubmatch(name)
	return len(match) == 3 && windowsPerUserFamilies[strings.ToLower(match[1])]
}

var versionDiagnosticRE = regexp.MustCompile(`(?i)(?:\[(?:warning|error)\]|\b(?:warning|error):|\busing unique option prefix\b)`)
var versionOnlyPrefixRE = regexp.MustCompile(`(?i)^v?[0-9]+(?:\.[0-9]+){1,5}(?:[-+][a-z0-9._-]+)?$`)

// Do not mistake MySQL/MariaDB stderr warnings (often prefixed by changing
// timestamps) for installed software versions. The raw snapshot is untouched.
// Preserve actual version lines and package_version for real upgrade detection.
func trackedServiceFields(svc map[string]any) map[string]any {
	value := pick(svc, "name", "manager", "enabled_state", "software_name", "version", "package_name", "package_version")
	// On Windows SCM, software_name is Win32_Service.DisplayName: it can
	// alternate between a localized display name and the stable service name.
	// Name is the object identity; enabled_state and real versions remain tracked.
	// Do not apply this rule to Linux/systemd/SysV or unknown managers.
	if strings.EqualFold(strings.TrimSpace(first(svc, "manager")), "windows_scm") {
		delete(value, "software_name")
	}
	for _, field := range []string{"version", "package_version"} {
		if raw, ok := value[field].(string); ok && versionDiagnosticRE.MatchString(raw) {
			lines := strings.Split(strings.ReplaceAll(strings.ReplaceAll(raw, "\r\n", "\n"), "\r", "\n"), "\n")
			clean := make([]string, 0, len(lines))
			for _, line := range lines {
				line = strings.TrimSpace(line)
				if line == "" {
					continue
				}
				if at := versionDiagnosticRE.FindStringIndex(line); at != nil {
					// Preserve a legitimate leading version when warning text
					// was appended on the same line.
					if prefix := strings.TrimSpace(line[:at[0]]); versionOnlyPrefixRE.MatchString(prefix) {
						clean = append(clean, prefix)
					}
					continue
				}
				clean = append(clean, line)
			}
			if len(clean) == 0 {
				delete(value, field)
			} else {
				value[field] = strings.Join(clean, " ")
			}
		}
	}
	return value
}

// This is an intentionally narrow list of AUTOMATIC rules/chains. In particular
// ufw-user-*, DOCKER-USER and ordinary INPUT/OUTPUT/FORWARD rules are retained.
var generatedChainRE = regexp.MustCompile(`(?i)^(?:ufw-(?:before|after|track|logging|skip|reject|not-local)(?:-|$)|docker(?:-|$)|cni-|kube-|libvirt)`)

// Docker may insert one isolation guard per container IP on each recreated
// br-<12 hex> bridge, including in generic FORWARD chains. The chain name
// alone does not identify it as generated. Suppress only the exact, normalized
// IPv4 RFC1918 guard: ip daddr A.B.C.D iifname != "br-XXXXXXXXXXXX" counter drop.
// Do not suppress general nft rules, static bridges or DOCKER-USER overrides.
var dockerBridgeGuardRE = regexp.MustCompile(`(?i)^ip daddr ((?:[0-9]{1,3}\.){3}[0-9]{1,3}) iifname != "br-[0-9a-f]{12}" counter drop$`)

func isDockerBridgeGuardRule(text string) bool {
	parts := dockerBridgeGuardRE.FindStringSubmatch(normalizeFirewallRule(text))
	if len(parts) != 2 {
		return false
	}
	ip, err := netip.ParseAddr(parts[1])
	return err == nil && ip.Is4() && ip.IsPrivate()
}

func isGeneratedFirewallRule(rule map[string]any) bool {
	backend := strings.ToLower(first(rule, "backend"))
	if backend != "nftables" && backend != "iptables" && backend != "ip6tables" {
		return false
	}
	chain := first(rule, "chain")
	if strings.EqualFold(chain, "DOCKER-USER") || strings.HasPrefix(strings.ToLower(chain), "docker-user-") {
		return false
	}
	if backend == "nftables" && isDockerBridgeGuardRule(first(rule, "rule")) {
		return true
	}
	return generatedChainRE.MatchString(chain)
}

type portSelection struct {
	protocol string
	port     int
}

func loadPrimaryPortSelections(ctx context.Context, tx *sql.Tx, vmID int64) (map[portSelection]bool, error) {
	rows, err := tx.QueryContext(ctx, `SELECT protocol,port FROM vm_primary_agent_ports WHERE vm_id=?`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	selected := make(map[portSelection]bool)
	for rows.Next() {
		var protocol string
		var port int
		if err := rows.Scan(&protocol, &port); err != nil {
			return nil, err
		}
		selected[portSelection{strings.ToLower(strings.TrimSpace(protocol)), port}] = true
	}
	return selected, rows.Err()
}

func suppressDynamicPortChange(oldObj, newObj trackedObject, hadOld, hasNew bool, selected map[portSelection]bool) bool {
	o := newObj
	if !hasNew {
		o = oldObj
	}
	if o.Category != "ports" || o.Type != "listening_port" {
		return false
	}
	v, ok := o.Value.(map[string]any)
	if !ok {
		return false
	}
	pText := numberText(v["port"])
	port, err := strconv.Atoi(pText)
	if err != nil || port < ephemeralPortStart || port > ephemeralPortEnd {
		return false
	}
	proto := strings.ToLower(strings.TrimSpace(fmt.Sprint(v["protocol"])))
	return !selected[portSelection{proto, port}]
}
