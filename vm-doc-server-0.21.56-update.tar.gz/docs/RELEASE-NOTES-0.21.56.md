# VM-DOC Server 0.21.56 — porturi și reguli Docker fără evenimente false

**Bază:** Server 0.21.55. **Agent:** 1.7.18 neschimbat. **Data:** 2026-10-20.

- `listening_ports`: cheie de identificare construită după sortarea și deduplicarea numelor proceselor. Exemplu `TCP/443 apache2`: 1–10 workeri au aceeași cheie, iar JSON-ul semantic rămâne identic. Schimbările reale de proces, executabil și port persistente rămân urmărite; mecanismul de confirmare pe două colectări din 0.21.52 este păstrat.
- `firewall`: ignorare **numai în istoricul de modificări** a regulilor de izolare Docker cu forma exactă `ip daddr <IPv4 RFC1918> iifname != "br-<12 caractere hex>" counter drop`, backend `nftables` și non-`DOCKER-USER`. Normalizarea existentă elimină contoare/handle. Reguli explicite sau alte politici nftables continuă să fie urmărite.
- SQL manual cumulativ `scripts/preview-inventory-changes-cleanup.sql` și `scripts/cleanup-inventory-changes.sql` include: perechi opuse de port cu **același VM + inventar + port + JSON**, dar chei diferite; plus regulile Docker strict recunoscute. Review-uri, decizii de documentare și note manuale rămân protejate. Scriptul cumulativ include TOATE regulile din 0.21.50–0.21.55.
- Fără migrare DB automată, fără endpoint/API nou, fără modificare a snapshoturilor brute, fără modificarea agentului 1.7.18, fără dependențe Go noi.

**Limite:** testele Go unitare sunt posibile local; build-ul integral necesită `vendor/` pe serverul offline, iar preview/cleanup MariaDB trebuie validate într-o copie înainte de PROD. Nu executați ștergeri fără backup.
