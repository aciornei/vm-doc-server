# Upgrade VM-DOC Server 0.21.55 → 0.21.56

1. Verifică `VERSION=0.21.55` înainte de actualizare. Fă backup al bazei MariaDB (inclusiv `inventory_changes`), binarului, configurației și surselor; testează că backupul se poate restaura.
2. Aplică **ori** `vm-doc-server-0.21.56-update.tar.gz` peste sursele actuale 0.21.55, **ori** patch-ul 0.21.55→0.21.56. **Nu pe ambele.** Pentru reconstituire de la zero, folosește sursele complete. Păstrează `vendor/` și configurația locală.
3. Pe serverul offline: `GOPROXY=off GOSUMDB=off go test ./internal/inventorychanges`, `GOPROXY=off GOSUMDB=off go test ./...`, apoi `make build`. Nu instala binarul până nu trec testele și verificările staging. Repornește doar după instalarea binarului validat.
4. Validează pe staging: `TCP/443 apache2` cu număr variabil de workeri nu creează evenimente `added/removed` false; schimbările reale de proces și port persistente se detectează; `ip daddr 172.18.0.x iifname != "br-<hex>" counter drop` dispare din istoricul viitor; reguli nftables personalizate, `DOCKER-USER` și firewall FortiGate rămân neafectate.
5. **Curățare istorică opțională, manuală:** oprește serverul și rulează PREVIEW pe o copie/staging, verificând TOATE categoriile (SQL **cumulativ 0.21.50–0.21.56**, nu doar noutățile). Noutăți: `porturi_cheie_workeri_duplicate` și `nftables_docker_bridge_guard`. Verifică evenimentele cu review/manual decizie. După backup și aprobare, rulează CLEANUP pe baza corectă și compară numărul de rânduri rămase.
6. Repornește VM-DOC și urmărește 2–3 zile topul `inventory_changes`. Nu repeta scripturile SQL vechi după cel cumulativ nou. Pentru reducerea spațiului fizic pe disc, planifică separat o operație de mentenanță DB; `DELETE` nu reduce neapărat imediat fișierele InnoDB.

**Rollback cod:** reinstalează binarul/sursele 0.21.55; nu este necesar rollback de schemă. **Rollback date:** restaurare din backup; DELETE-urile nu pot fi anulate după COMMIT fără backup.

**Compatibilitate:** VM-DOC Agent 1.7.18 și legacy nemodificate; fără migrări, fără API nou. Compilarea completă cu vendor și MariaDB reală rămân teste de acceptanță necesare.
