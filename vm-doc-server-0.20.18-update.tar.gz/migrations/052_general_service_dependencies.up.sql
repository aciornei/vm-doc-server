-- 0.20.18 · dependențe generice între servicii
-- Extinde relația existentă serviciu -> serviciu astfel încât ținta să nu mai
-- fie limitată la servicii comune și permite relații diferențiate pe medii.

ALTER TABLE internal_service_dependencies
  ADD COLUMN IF NOT EXISTS source_environment_id BIGINT UNSIGNED NULL AFTER dependency_type_id,
  ADD COLUMN IF NOT EXISTS target_environment_id BIGINT UNSIGNED NULL AFTER source_environment_id,
  ADD COLUMN IF NOT EXISTS criticality VARCHAR(32) NOT NULL DEFAULT 'normal' AFTER target_environment_id,
  ADD COLUMN IF NOT EXISTS protocol VARCHAR(64) NOT NULL DEFAULT '' AFTER criticality,
  ADD COLUMN IF NOT EXISTS port SMALLINT UNSIGNED NULL AFTER protocol;

-- Cheia veche nu permitea două relații de același tip între aceleași servicii
-- pentru combinații diferite de medii (ex. TEST -> TEST și TEST -> PROD).
SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.STATISTICS
   WHERE TABLE_SCHEMA=DATABASE()
     AND TABLE_NAME='internal_service_dependencies'
     AND INDEX_NAME='uq_internal_service_dependency')>0,
  'ALTER TABLE internal_service_dependencies DROP INDEX uq_internal_service_dependency',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.STATISTICS
   WHERE TABLE_SCHEMA=DATABASE()
     AND TABLE_NAME='internal_service_dependencies'
     AND INDEX_NAME='idx_service_dependency_identity')=0,
  'ALTER TABLE internal_service_dependencies ADD INDEX idx_service_dependency_identity (source_service_id,target_service_id,dependency_type_id,source_environment_id,target_environment_id)',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA=DATABASE()
     AND TABLE_NAME='internal_service_dependencies'
     AND CONSTRAINT_NAME='fk_service_dependency_source_environment')=0,
  'ALTER TABLE internal_service_dependencies ADD CONSTRAINT fk_service_dependency_source_environment FOREIGN KEY (source_environment_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA=DATABASE()
     AND TABLE_NAME='internal_service_dependencies'
     AND CONSTRAINT_NAME='fk_service_dependency_target_environment')=0,
  'ALTER TABLE internal_service_dependencies ADD CONSTRAINT fk_service_dependency_target_environment FOREIGN KEY (target_environment_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
