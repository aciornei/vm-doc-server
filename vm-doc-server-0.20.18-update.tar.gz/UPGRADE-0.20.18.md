# Upgrade vm-doc-server 0.20.17 → 0.20.18

## Ce se schimbă

0.20.18 transformă dependențele existente Serviciu → Serviciu comun într-un model generic Serviciu → Serviciu, păstrând compatibilitatea cu serviciile comune/globale și cu dependențele directe VM.

Relațiile explicite pot conține:

- serviciu destinație;
- tip dependență;
- mediu sursă și mediu destinație;
- criticitate: Informativă / Normală / Critică;
- protocol și port;
- observații;
- stare activă.

## Migrare DB

La pornire se aplică automat:

```text
052_general_service_dependencies.up.sql
```

Migrarea extinde `internal_service_dependencies` și înlocuiește cheia unică veche, astfel încât să fie posibile relații distincte pentru combinații diferite de medii.

## Instalare

Peste arborele 0.20.17:

```bash
tar -xzf vm-doc-server-0.20.18-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.18
cd /usr/local/src/vm-doc-server-0.20.18
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi repornește `vm-doc-server`. Migrarea este rulată de server la startup.

## Agent

Nu este necesară nicio modificare de agent sau collector.

## Test recomandat

1. Deschide un serviciu normal (nemarcat Comun).
2. În `Dependențe → Între servicii`, adaugă o relație către un alt serviciu normal.
3. Setează medii diferite, de exemplu `TEST → PROD`, criticitate și protocol/port.
4. Verifică relația în `Depinde de`.
5. Deschide serviciul destinație și verifică apariția automată în `Este utilizat de`.
6. Dezactivează și reactivează relația.
7. Generează fișa serviciului și verifică secțiunea `Dependențe între servicii`.
