MIGRARE ALERTE GRAFANA 10 -> 13, DOAR ORGANIZATIA calculator
==============================================================

Prerequisites
-------------
- Organizatia 'calculator' exista deja pe Grafana 13.
- Folderele si datasource-urile au fost migrate cu scriptul anterior.
- Token sursa din organizatia 'calculator', token destinatie din
  organizatia 'calculator'. Tokenuri cu drept de administrare a alertelor.
- Linux: sudo apt install -y python3-requests

Configurare
-----------
export GRAFANA_OLD_URL='https://grafana10.exemplu.local'
export GRAFANA_NEW_URL='https://grafana13.exemplu.local'

read -rsp 'Grafana 10 token: ' GRAFANA_OLD_TOKEN; echo
export GRAFANA_OLD_TOKEN
read -rsp 'Grafana 13 token: ' GRAFANA_NEW_TOKEN; echo
export GRAFANA_NEW_TOKEN

Alternativa: daca nu ai token pentru organizatia calculator in Grafana13,
foloseste GRAFANA_NEW_ADMIN_USER si GRAFANA_NEW_ADMIN_PASSWORD (Basic Auth
server admin) in locul lui GRAFANA_NEW_TOKEN.

Comenzi
-------
1. Simulare si backup JSON, FARA scrieri pe Grafana:
   python3 grafana_calculator_alerte_10_13.py

2. Import reguli PAUSED + contact points + mute timings + templates,
   dar FARA sa inlocuiasca notification policies:
   python3 grafana_calculator_alerte_10_13.py --apply

3. Import inclusiv notification policy tree (INLOCUIESTE tree-ul destinatiei):
   python3 grafana_calculator_alerte_10_13.py --apply --replace-policies

4. Exclusiv la cutover, daca vrei reguli ACTIVE imediat la import, dupa
   dezactivarea celor din Grafana 10 (ATENTIE la notificari duplicate):
   python3 grafana_calculator_alerte_10_13.py --apply --activate-rules

IMPORTANTE
----------
- Daca ai facut deja importul cu --apply, rularea urmatoare NU activeaza
  regulile importate (UID-urile existente sunt omise). Activeaza-le din UI.
- Provenance este creat cu X-Disable-Provenance=true ca sa permita editari UI.
- Sunt importate numai Grafana-managed alert rules. Regulile create direct
  in Prometheus/Mimir/Loki trebuie migrate in sistemul lor.
- Credentialele secrete ale unor contact points nu se exporta prin API.
  Reintrodu parolele/tokenurile si testeaza canalele de notificare.
- Silences, istoricul alertelor, permisiunile specifice contact points,
  istoricul evaluarilor si configuratia externa Alertmanager NU se migreaza.
- Backupul JSON poate contine date sensibile (adresari, configurari, URL-uri).
  Se scrie local cu permisiuni restrictive. Nu il publica.
- Scriptul pastreaza UID-urile regulilor si ale folderelor, mapeaza UID-urile
  datasource dupa perechea (name,type). Folderele trebuie sa existe deja.
- La import, prima data regulile sunt PAUSED, ca sa eviti alerte duplicate.
- Daca utilizati o instanta Grafana 13 unde endpointurile vechi de provisioning
  au fost eliminate, utilizati versiunea de App Platform API corespunzatoare.
- Nu a fost testat pe serverele tale; am verificat sintaxa si transformarile
  in teste locale fara conectare la Grafana.
