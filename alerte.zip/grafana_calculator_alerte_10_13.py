#!/usr/bin/env python3
"""Migrate Grafana-managed alerting from org 'calculator', Grafana 10 -> 13.

Independent of the earlier dashboard migration. Source is read-only.
By default DRY-RUN and a local JSON backup; --apply writes ONLY to target.
New alert/recording rules are PAUSED unless --activate-rules is specified.

Features: rules and queries (preserve UID, folder, group, evaluation interval),
contact points, templates, mute timings. Policy tree requires explicitly
--replace-policies because Grafana replaces the entire target routing tree.
Existing resources are NEVER overwritten, except policy tree with explicit flag.

Excludes: datasource-managed Prometheus/Loki rules, silences, alert history,
secrets hidden by Grafana's API; these need separate consideration.

Environment:
 GRAFANA_OLD_URL, GRAFANA_OLD_TOKEN, GRAFANA_NEW_URL
 GRAFANA_NEW_TOKEN (token scoped to destination 'calculator'), OR
 GRAFANA_NEW_ADMIN_USER + GRAFANA_NEW_ADMIN_PASSWORD (Basic Auth server admin)
Run: python3 grafana_calculator_alerte_10_13.py
     python3 grafana_calculator_alerte_10_13.py --apply
     python3 grafana_calculator_alerte_10_13.py --apply --replace-policies
"""
import argparse
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
from urllib.parse import quote

try:
    import requests
except ImportError:
    sys.exit('Install python3-requests (or pip install requests)')

ORG = 'calculator'
BASE = '/api/v1/provisioning'
DS_SPECIAL = {'-100', '__expr__', '__dashboard__', 'grafana', '-- Grafana --', '-- Mixed --', 'expr', ''}


class MigrationError(Exception):
    pass


class Grafana:
    def __init__(self, url, token=None, username=None, password=None, org_id=None, verify=True):
        self.url = url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({'Accept': 'application/json', 'Content-Type': 'application/json'})
        if token:
            self.session.headers['Authorization'] = 'Bearer ' + token
        elif username is not None and password is not None:
            self.session.auth = (username, password)
        else:
            raise MigrationError('Need Grafana token or server-admin Basic credentials')
        if org_id is not None:
            self.session.headers['X-Grafana-Org-Id'] = str(org_id)
        self.verify = verify

    def call(self, method, path, *, body=None, headers=None, absent_ok=False):
        try:
            response = self.session.request(method, self.url + path, json=body,
                                            headers=headers, verify=self.verify, timeout=40)
        except requests.RequestException as exc:
            raise MigrationError(f'{method} {path}: connection error: {exc}') from exc
        if response.status_code == 404 and absent_ok:
            return None
        if not 200 <= response.status_code < 300:
            # Grafana API errors may have sensitive values. Only first 180 chars.
            info = response.text.replace('\n', ' ')[:180]
            raise MigrationError(f'{method} {path}: HTTP {response.status_code}: {info}')
        if not response.content:
            return {}
        try:
            return response.json()
        except ValueError as exc:
            raise MigrationError(f'{method} {path}: expected JSON response') from exc

    def get(self, path, **kwargs):
        return self.call('GET', path, **kwargs)

    def post(self, path, body, **kwargs):
        return self.call('POST', path, body=body, **kwargs)

    def put(self, path, body, **kwargs):
        return self.call('PUT', path, body=body, **kwargs)

    def verify_org(self):
        result = self.get('/api/org')
        if result.get('name') != ORG:
            raise MigrationError(f"STOP: connected to {result.get('name')!r}, not {ORG!r}. "
                                 'Use service-account tokens scoped to calculator.')
        return result


def safe_file(prefix, identity):
    slug = ''.join(c if c.isalnum() or c in '-_' else '_' for c in str(identity))[:48]
    digest = hashlib.sha256(str(identity).encode('utf-8')).hexdigest()[:10]
    return f'{prefix}_{slug}_{digest}.json'


def save_json(folder, name, contents):
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = folder / name
    with path.open('w', encoding='utf-8') as stream:
        json.dump(contents, stream, indent=2, ensure_ascii=False)
        stream.write('\n')
    path.chmod(0o600)


def ensure_list(value, label):
    if not isinstance(value, list):
        raise MigrationError(f'{label}: expected JSON array')
    return value


def ds_map_from_orgs(source, target):
    """Translate datasource UIDs by name+type, not by numeric ID."""
    target_index = {(d.get('name'), d.get('type')): d for d in target}
    mapping = {}
    for ds in source:
        uid = ds.get('uid')
        if not uid:
            continue
        candidate = target_index.get((ds.get('name'), ds.get('type')))
        if candidate and candidate.get('uid'):
            mapping[uid] = candidate['uid']
    return mapping


def clean_rule(original, target_org_id, mapping, known_source_uids, activate=False):
    """Return valid POST body + list of unmapped datasource references."""
    allowed = ('uid', 'title', 'ruleGroup', 'folderUID', 'condition', 'data', 'for',
               'keepFiringFor', 'noDataState', 'execErrState', 'annotations', 'labels',
               'record', 'notification_settings')
    prepared = {key: copy.deepcopy(original[key]) for key in allowed if key in original}
    prepared['orgId'] = target_org_id
    prepared['isPaused'] = (bool(original.get('isPaused', False)) if activate else True)
    if 'record' in prepared and not prepared['record']:
        prepared.pop('record')
    if not prepared.get('uid') or not prepared.get('folderUID') or not prepared.get('ruleGroup'):
        raise MigrationError('Alert missing uid, folderUID, or ruleGroup')

    missing = set()

    def uid_translate(value, location):
        if not isinstance(value, str) or value in DS_SPECIAL or value.startswith('$'):
            return value
        if value in mapping:
            return mapping[value]
        if value in known_source_uids:
            missing.add(location + ': ' + value)
        # For UIDs unknown to /api/datasources (e.g. plugin/virtual datasources),
        # retain the original; Grafana will validate. They are flagged separately.
        else:
            missing.add(location + ': unknown datasource UID ' + value)
        return value

    def walk(obj, loc='query'):
        if isinstance(obj, list):
            for index, child in enumerate(obj):
                walk(child, f'{loc}[{index}]')
        elif isinstance(obj, dict):
            for key, value in obj.items():
                current = loc + '.' + key
                if key in ('datasourceUid', 'datasource_uid', 'target_datasource_uid'):
                    obj[key] = uid_translate(value, current)
                elif key == 'datasource' and isinstance(value, dict) and 'uid' in value:
                    value['uid'] = uid_translate(value['uid'], current + '.uid')
                    walk({k: v for k, v in value.items() if k != 'uid'}, current)
                else:
                    walk(value, current)

    walk(prepared.get('data', []), 'data')
    if isinstance(prepared.get('record'), dict) and prepared['record'].get('target_datasource_uid'):
        prepared['record']['target_datasource_uid'] = uid_translate(
            prepared['record']['target_datasource_uid'], 'record.target_datasource_uid')
    return prepared, sorted(missing)


def clean_contact(cp):
    keys = ('uid', 'name', 'type', 'settings', 'disableResolveMessage')
    return {k: copy.deepcopy(cp[k]) for k in keys if k in cp}


def clean_policy(node):
    keys = ('receiver', 'group_by', 'group_wait', 'group_interval', 'repeat_interval',
            'match', 'match_re', 'matchers', 'object_matchers', 'mute_time_intervals',
            'active_time_intervals', 'continue')
    result = {k: copy.deepcopy(node[k]) for k in keys if k in node}
    if 'routes' in node:
        result['routes'] = [clean_policy(n) for n in node['routes']]
    return result


def policy_refs(node):
    receivers, mutes = set(), set()
    if node.get('receiver'):
        receivers.add(node['receiver'])
    mutes.update(node.get('mute_time_intervals') or [])
    for child in node.get('routes') or []:
        a, b = policy_refs(child)
        receivers.update(a)
        mutes.update(b)
    return receivers, mutes


def get_group(client, rule):
    folder = quote(rule['folderUID'], safe='')
    group = quote(rule['ruleGroup'], safe='')
    return client.get(f'{BASE}/folder/{folder}/rule-groups/{group}', absent_ok=True)


def client_pair(verify):
    for key in ('GRAFANA_OLD_URL', 'GRAFANA_OLD_TOKEN', 'GRAFANA_NEW_URL'):
        if not os.environ.get(key):
            raise MigrationError('Missing environment variable ' + key)
    old_url = os.environ['GRAFANA_OLD_URL']
    new_url = os.environ['GRAFANA_NEW_URL']
    if old_url.rstrip('/') == new_url.rstrip('/'):
        raise MigrationError('Old and new Grafana URLs cannot be equal')
    if not all(x.startswith(('http://', 'https://')) for x in (old_url, new_url)):
        raise MigrationError('Grafana URLs must start with http:// or https://')
    source = Grafana(old_url, token=os.environ['GRAFANA_OLD_TOKEN'], verify=verify)
    source_org = source.verify_org()
    target_token = os.environ.get('GRAFANA_NEW_TOKEN')
    admin_user = os.environ.get('GRAFANA_NEW_ADMIN_USER')
    admin_pass = os.environ.get('GRAFANA_NEW_ADMIN_PASSWORD')
    if target_token:
        target = Grafana(new_url, token=target_token, verify=verify)
    elif admin_user and admin_pass:
        admin = Grafana(new_url, username=admin_user, password=admin_pass, verify=verify)
        org = admin.get('/api/orgs/name/' + quote(ORG, safe=''), absent_ok=True)
        if not org:
            raise MigrationError("Target 'calculator' organization does not exist yet. "
                                 'Migrate dashboards / create organization first.')
        target = Grafana(new_url, username=admin_user, password=admin_pass,
                         org_id=org['id'], verify=verify)
    else:
        raise MigrationError('Supply GRAFANA_NEW_TOKEN for target calculator, or Basic admin credentials')
    target_org = target.verify_org()
    print('SOURCE: Grafana', source.get('/api/health').get('version'), 'org', source_org)
    print('TARGET: Grafana', target.get('/api/health').get('version'), 'org', target_org)
    return source, target, source_org, target_org


def export_everything(source, target, backup):
    print('Collecting source alerting resources and existing target inventory...')
    specs = {
        'rules': 'alert-rules', 'contacts': 'contact-points',
        'mutes': 'mute-timings', 'templates': 'templates', 'policies': 'policies',
    }
    old, new = {}, {}
    for key, endpoint in specs.items():
        old[key] = source.get(BASE + '/' + endpoint)
        new[key] = target.get(BASE + '/' + endpoint)
        save_json(backup / 'source', key + '.json', old[key])
        save_json(backup / 'target_before', key + '.json', new[key])
    old['datasources'] = source.get('/api/datasources')
    new['datasources'] = target.get('/api/datasources')
    save_json(backup / 'source', 'datasources.json', old['datasources'])
    save_json(backup / 'target_before', 'datasources.json', new['datasources'])
    for key in ('rules', 'contacts', 'mutes', 'templates', 'datasources'):
        ensure_list(old[key], 'source/' + key)
        ensure_list(new[key], 'target/' + key)
    if not isinstance(old['policies'], dict) or not isinstance(new['policies'], dict):
        raise MigrationError('Policy API did not return a JSON object')
    group_map = {}
    for rule in old['rules']:
        if not isinstance(rule, dict) or not rule.get('uid'):
            raise MigrationError('Malformed source alert rule')
        identity = (rule.get('folderUID'), rule.get('ruleGroup'))
        if not all(identity):
            raise MigrationError('Source rule lacks folderUID or ruleGroup: ' + str(rule.get('uid')))
        if identity not in group_map:
            group_map[identity] = get_group(source, rule)
            if group_map[identity] is None:
                raise MigrationError('Could not read source rule group ' + repr(identity))
    old['groups'] = group_map
    save_json(backup / 'source', 'rule_groups.json', [
        {'folderUID': k[0], 'ruleGroup': k[1], 'payload': v} for k, v in group_map.items()])
    return old, new


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--apply', action='store_true', help='Write migrated resources to Grafana 13')
    parser.add_argument('--activate-rules', action='store_true',
                        help='Preserve source isPaused state (can trigger duplicate notifications)')
    parser.add_argument('--replace-policies', action='store_true',
                        help='Replace ENTIRE destination notification routing tree')
    parser.add_argument('--backup-dir', help='Where to store source and target JSON snapshots')
    parser.add_argument('--insecure', action='store_true', help='Disable TLS validation (not recommended)')
    parser.add_argument('--ca-bundle', help='Path to internal CA bundle')
    args = parser.parse_args()
    if args.insecure and args.ca_bundle:
        parser.error('Use --insecure OR --ca-bundle')
    if args.activate_rules and not args.apply:
        parser.error('--activate-rules requires --apply')
    if args.replace_policies and not args.apply:
        parser.error('--replace-policies requires --apply')
    verify = False if args.insecure else args.ca_bundle or True
    if args.insecure:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    os.umask(0o077)
    timestamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup = Path(args.backup_dir or 'grafana_calculator_alerts_backup_' + timestamp)
    source, target, old_org, new_org = client_pair(verify)
    old, new = export_everything(source, target, backup)
    mapping = ds_map_from_orgs(old['datasources'], new['datasources'])
    known_source_uids = {x.get('uid') for x in old['datasources'] if x.get('uid')}
    target_rules = {x.get('uid') for x in new['rules']}
    target_contacts = {x.get('uid') for x in new['contacts'] if x.get('uid')}
    target_contact_names_types = {(x.get('name'), x.get('type')) for x in new['contacts']}
    target_mutes = {x.get('name') for x in new['mutes']}
    target_templates = {x.get('name') for x in new['templates']}
    src_groups = old['groups']
    imported = {'rules': 0, 'contacts': 0, 'mutes': 0, 'templates': 0, 'groups': 0,
                'policies': 0, 'skipped': 0, 'errors': 0}

    print('\nFOUND:', len(old['rules']), 'Grafana-managed rules,', len(src_groups),
          'rule groups,', len(old['contacts']), 'contact point receiver(s),',
          len(old['mutes']), 'mute timings,', len(old['templates']), 'templates')
    print('Target already has:', len(new['rules']), 'rules,', len(new['contacts']),
          'receivers,', len(new['mutes']), 'mute timings')
    print('BACKUP:', backup.resolve(), '(includes potentially sensitive notification settings)')

    # Validate folder existence first; source alert folders may be independent of dashboards.
    folder_status = {}
    for folder_uid, _ in src_groups:
        if folder_uid not in folder_status:
            folder_status[folder_uid] = target.get('/api/folders/' + quote(folder_uid, safe=''), absent_ok=True)
            if not folder_status[folder_uid]:
                print('WARNING: missing destination folder for alert rules:', folder_uid)
    contact_pending = []
    for cp in old['contacts']:
        uid, name, kind = cp.get('uid'), cp.get('name'), cp.get('type')
        if uid and uid in target_contacts:
            imported['skipped'] += 1
            print('SKIP contact UID already exists:', name, uid)
        elif (name, kind) in target_contact_names_types:
            imported['skipped'] += 1
            print('SKIP contact with same name and type (review settings):', name, kind)
        else:
            contact_pending.append(clean_contact(cp))
            print('PLAN contact:', name, f'({kind})')
            if kind != 'email':
                print('  WARNING: secret webhook/token settings may not be exported by API')

    mute_pending = []
    for mt in old['mutes']:
        name = mt.get('name')
        if name in target_mutes:
            imported['skipped'] += 1
            print('SKIP mute timing:', name)
        elif name:
            mute_pending.append({'name': name, 'time_intervals': mt.get('time_intervals') or []})
            print('PLAN mute timing:', name)

    template_pending = []
    for template in old['templates']:
        name = template.get('name')
        if name in target_templates:
            imported['skipped'] += 1
            print('SKIP template:', name)
        elif name:
            template_pending.append({'name': name, 'template': template.get('template', '')})
            print('PLAN template:', name)

    rule_pending = []
    for rule in old['rules']:
        uid = rule['uid']
        if uid in target_rules:
            imported['skipped'] += 1
            print('SKIP rule UID already exists:', rule.get('title'), uid)
            continue
        payload, missing = clean_rule(rule, new_org['id'], mapping, known_source_uids,
                                      activate=args.activate_rules)
        save_json(backup / 'prepared_rules', safe_file('rule', uid), payload)
        if missing:
            print('BLOCK rule', rule.get('title'), ': unmapped datasource reference(s):', ', '.join(missing))
        if not folder_status.get(rule['folderUID']):
            print('BLOCK rule', rule.get('title'), ': folder missing', rule['folderUID'])
        rule_pending.append((rule, payload, missing))
        print('PLAN rule:', rule.get('title'), uid, '(paused=' + str(payload['isPaused']) + ')')

    policy_payload = clean_policy(old['policies'])
    save_json(backup / 'prepared', 'policy.json', policy_payload)
    contact_in_target_or_plan = {x.get('name') for x in new['contacts']} | {x.get('name') for x in contact_pending}
    mute_in_target_or_plan = {x.get('name') for x in new['mutes']} | {x.get('name') for x in mute_pending}
    expected_receivers, expected_mutes = policy_refs(policy_payload)
    missing_receivers = expected_receivers - contact_in_target_or_plan
    missing_mutes = expected_mutes - mute_in_target_or_plan
    if missing_receivers:
        print('WARNING: source policy references unavailable receiver names:', sorted(missing_receivers))
    if missing_mutes:
        print('WARNING: source policy references unavailable mute timings:', sorted(missing_mutes))

    print('\nDRY-RUN PLAN:' if not args.apply else '\nAPPLY PLAN:',
          len(contact_pending), 'contact(s),', len(mute_pending), 'mute timing(s),',
          len(template_pending), 'template(s),', len(rule_pending), 'rule(s)')
    if not args.apply:
        print('No writes to either Grafana. Execute --apply to import (rules paused).')
        print('Policy tree import is OPTIONAL and needs --apply --replace-policies.')
        return 0

    headers = {'X-Disable-Provenance': 'true'}

    def attempt(label, func):
        try:
            func()
        except MigrationError as exc:
            imported['errors'] += 1
            print('ERROR', label, exc)
            return False
        return True

    # Dependencies go first. Contacts are created WITHOUT sending any messages.
    for item in template_pending:
        name = item['name']
        path = BASE + '/templates/' + quote(name, safe='')
        if attempt('template ' + name, lambda item=item, path=path:
                   target.put(path, {'template': item['template'], 'version': ''}, headers=headers)):
            imported['templates'] += 1
            print('CREATED template:', name)
    for item in mute_pending:
        name = item['name']
        if attempt('mute timing ' + name, lambda item=item:
                   target.post(BASE + '/mute-timings', item, headers=headers)):
            imported['mutes'] += 1
            print('CREATED mute timing:', name)
    for item in contact_pending:
        name = item.get('name') or ''
        if attempt('contact point ' + name, lambda item=item:
                   target.post(BASE + '/contact-points', item, headers=headers)):
            imported['contacts'] += 1
            print('CREATED contact point:', name)

    # Rules are paused by default. Preserve the dashboard-linked rule UIDs.
    group_new_uids = {}
    for original, prepared, missing in rule_pending:
        group_key = (original['folderUID'], original['ruleGroup'])
        group_new_uids.setdefault(group_key, []).append(original['uid'])
        if missing or not folder_status.get(original['folderUID']):
            imported['errors'] += 1
            continue
        if attempt('alert rule ' + original['uid'], lambda prepared=prepared:
                   target.post(BASE + '/alert-rules', prepared, headers=headers)):
            imported['rules'] += 1
            print('CREATED rule:', original['title'])

    # Grafana POST may create rule groups with a default evaluation interval.
    # Only update interval for wholly new groups. Existing target groups are left untouched.
    existing_groups = {(x.get('folderUID'), x.get('ruleGroup')) for x in new['rules']}
    for key, source_group in src_groups.items():
        if key in existing_groups:
            print('SKIP interval update: target group existed:', key)
            continue
        if not isinstance(source_group, dict) or not isinstance(source_group.get('interval'), int):
            print('WARNING: cannot determine original group interval:', key)
            continue
        group_rules = [r for r in old['rules'] if (r['folderUID'], r['ruleGroup']) == key]
        target_group = get_group(target, group_rules[0])
        if not target_group or len(target_group.get('rules') or []) != len(group_rules):
            print('WARNING: not all rules present, skipping interval update for:', key)
            continue
        # Updating the group replaces its contained rules. Take a source-target snapshot.
        save_json(backup / 'target_before', safe_file('group_post_import', key), target_group)
        group_body = {'folderUid': key[0], 'title': key[1],
                      'interval': source_group['interval'], 'rules': target_group['rules']}
        path = BASE + '/folder/' + quote(key[0], safe='') + '/rule-groups/' + quote(key[1], safe='')
        if attempt('interval for ' + repr(key), lambda path=path, body=group_body:
                   target.put(path, body, headers=headers)):
            imported['groups'] += 1
            print('SET rule group interval:', key, '->', source_group['interval'], 'seconds')

    # High impact: updates entire notification policy tree, requires explicit opt-in.
    if args.replace_policies:
        current_contacts = ensure_list(target.get(BASE + '/contact-points'), 'target/contacts')
        current_mutes = ensure_list(target.get(BASE + '/mute-timings'), 'target/mutes')
        available_c = {x.get('name') for x in current_contacts}
        available_m = {x.get('name') for x in current_mutes}
        missing_c = expected_receivers - available_c
        missing_m = expected_mutes - available_m
        if missing_c or missing_m:
            print('ERROR: policy not replaced: missing receivers or mute timings:',
                  sorted(missing_c), sorted(missing_m))
            imported['errors'] += 1
        elif attempt('notification policy tree', lambda: target.put(BASE + '/policies',
                                                                    policy_payload, headers=headers)):
            imported['policies'] += 1
            print('REPLACED destination notification policy tree')
    else:
        print('POLICY TREE NOT MODIFIED. Use --replace-policies to explicitly copy it.')

    save_json(backup, 'result.json', {'organization': ORG, 'source_org_id': old_org['id'],
                                      'target_org_id': new_org['id'], 'counts': imported,
                                      'imported_paused_by_default': not args.activate_rules,
                                      'policy_tree_replaced': bool(imported['policies'])})
    print('\nDONE:', imported)
    print('IMPORTANT: review contact point secrets, test queries, check rule-group intervals,')
    print('then activate rules only when Grafana 10 no longer evaluates/sends identical alerts.')
    return 1 if imported['errors'] else 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (MigrationError, OSError) as exc:
        print('FATAL:', exc, file=sys.stderr)
        sys.exit(2)
