# VM-DOC Server 0.21.3 → 0.21.4

## Modificări

1. Proiecte Docker Compose: câte un proiect pe rând, fără grid de carduri paralele; controalele Serviciu, Mediu, Status operațional, Tip soluție și Asociază sunt aranjate responsiv.
2. Exportul Excel al inventarelor Docker, Baze de date și Web se află în dreapta antetului tabelului principal, nu într-o bară separată deasupra.
3. Procentul de completare documentare VM are un nou criteriu obligatoriu, **Beneficiar VM**: este îndeplinit de existența a cel puțin unei asocieri explicite de departament sau persoană cu VM-ul. Numărul beneficiarilor nu multiplică punctele. La o VM fără beneficiar, criteriul apare în lista „De completat”.
4. Procentul din lista generală de VM-uri folosește aceeași regulă SQL ca detaliul VM; adăugarea/ștergerea beneficiarului recalculează procentul afișat în fișă. **Asocierile numai la Docker, Baze și Web nu îndeplinesc criteriul explicit Beneficiar VM**; beneficiarului unei resurse i se poate asocia separat și VM-ul gazdă, dacă este cazul.
5. Parametrii `v=0.21.4` din index.html invalidează cache-ul JS/CSS.

Nu sunt necesare migrări SQL suplimentare, modificări ale `go.mod` / `go.sum`, `vendor/`, Swagger sau ale vm-doc-agent.

## Upgrade offline

Porniți de la codul **0.21.3** funcțional cu `vendor/` și configurațiile existente:

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.3 vm-doc-server-0.21.4
tar -xzf /cale/vm-doc-server-0.21.4-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.4
cd /usr/local/src/vm-doc-server-0.21.4
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Înlocuiți binarul și reporniți serviciul conform procedurii locale obișnuite **doar dacă testele și compilarea au reușit**. Efectuați Ctrl+F5 după actualizare. Este recomandată validarea în staging și backup-ul configurației/bazei înainte de producție.

## Verificări funcționale

1. Pe o VM cu mai multe proiecte Compose, fiecare proiect ocupă propriul rând, cu toate cele patru selectoare vizibile, fără suprapuneri.
2. În Docker, Baze și Web, „Export Excel” este în antetul tabelului principal, la dreapta; descărcarea rămâne XLSX.
3. Într-o VM fără beneficiari, „Beneficiar VM” apare la De completat. Asociați o persoană sau un departament în Operațional → Responsabilități → Persoane → Beneficiari; procentul trebuie să crească. Ștergerea ultimei asocieri readuce criteriul lipsă.
4. Comparați procentul din fișa VM cu cel din tabelul VM-uri după reîncărcarea listei. Valorile ar trebui să fie echivalente dacă restul condițiilor calculului sunt aceleași (unele reguli istorice au particularități proprii).

## Limitări de validare în mediul de generare

- Sintaxa JavaScript verificată prin Node; fișierul Go formatat cu gofmt; layout simulat în Chromium pe mai multe viewporturi; sursele complete, patch-ul și update-ul comparate după aplicare pe 0.21.3.
- Compilarea integrală Go și testele DB/AD nu au putut fi executate fără `vendor/`/servicii; acestea trebuie rulate pe infrastructura de test.
