package inventorychanges

import (
	"encoding/json"
	"testing"
)

func TestExtractTrackedDetectsUserAndDatabase(t *testing.T) {
	raw := []byte(`{"host":{"hostname":"vm1"},"os":{"name":"Ubuntu","version":"24.04"},"accounts":{"local_users":[{"username":"app","uid":1000,"gid":1000,"system_account":false}]},"databases":{"instances":[{"engine":"postgresql","product":"PostgreSQL","instance_name":"main","data_dir":"/var/lib/postgresql/16/main","endpoints":[{"port":5432}],"catalogs":[{"name":"portal","kind":"database","system":false}]}]}}`)
	values, err := extractTracked(raw)
	if err != nil {
		t.Fatal(err)
	}
	foundUser, foundDB := false, false
	for _, v := range values {
		if v.Type == "local_user" && v.Key == "1000" {
			foundUser = true
		}
		if v.Type == "database" && v.Label == "Bază de date portal" {
			foundDB = true
		}
	}
	if !foundUser || !foundDB {
		b, _ := json.MarshalIndent(values, "", "  ")
		t.Fatalf("missing tracked objects: %s", b)
	}
}

func TestVolatileCollectionFieldsIgnored(t *testing.T) {
	a := []byte(`{"collected_at":"2026-01-01T00:00:00Z","collection":{"duration_ms":10},"host":{"hostname":"vm1"},"os":{"name":"Ubuntu","version":"24.04"}}`)
	b := []byte(`{"collected_at":"2026-01-01T00:05:00Z","collection":{"duration_ms":999},"host":{"hostname":"vm1"},"os":{"name":"Ubuntu","version":"24.04"}}`)
	aa, err := extractTracked(a)
	if err != nil {
		t.Fatal(err)
	}
	bb, err := extractTracked(b)
	if err != nil {
		t.Fatal(err)
	}
	if len(aa) != len(bb) {
		t.Fatalf("different normalized objects: %d %d", len(aa), len(bb))
	}
	for k, v := range aa {
		other, ok := bb[k]
		if !ok || !canonicalEqual(v.Value, other.Value) {
			t.Fatalf("volatile data changed %s", k)
		}
	}
}
