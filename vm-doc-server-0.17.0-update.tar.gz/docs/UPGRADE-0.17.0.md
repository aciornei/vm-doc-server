# Upgrade vm-doc-server 0.16.4 → 0.17.0

0.17.0 adaugă urmărirea modificărilor de inventar între snapshot-uri și trierea impactului asupra documentației.

## Pași

1. Faceți backup bazei de date și aplicației.
2. Aplicați `vm-doc-server-0.17.0-update.tar.gz` peste sursa 0.16.4.
3. Compilați: `go build -o vm-doc-server ./cmd/vm-doc-server`.
4. Înlocuiți binarul folosit de systemd și reporniți `vm-doc-server`.
5. Migrarea `032_inventory_changes.up.sql` se aplică automat la pornire.
6. Deschideți meniul **Modificări**. Pentru populare imediată din datele existente, folosiți **Compară ultimele snapshot-uri**.

`vm-doc-agent 1.6.1` este compatibil și nu necesită update. Noile colectări vor genera automat evenimente față de snapshot-ul anterior.
