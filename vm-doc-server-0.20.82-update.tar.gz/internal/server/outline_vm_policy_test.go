package server

import "testing"

func TestOutlineVMTitle(t *testing.T) {
	tests := map[string]string{
		"app01":     "vm-app01",
		" vm-db01 ": "vm-db01",
		"vm-web01":  "vm-web01",
		"VM-APP02":  "vm-APP02",
		"":          "vm",
	}
	for input, want := range tests {
		if got := outlineVMTitle(input); got != want {
			t.Fatalf("outlineVMTitle(%q) = %q, want %q", input, got, want)
		}
	}
}

func TestOutlineBulkProductionEnvironment(t *testing.T) {
	for _, value := range []string{"PROD", "prod", " Prod "} {
		if !outlineBulkProductionEnvironment(value) {
			t.Fatalf("expected %q to be eligible for bulk Outline publication", value)
		}
	}
	for _, value := range []string{"", "TEST", "DEV", "PRODUCTION"} {
		if outlineBulkProductionEnvironment(value) {
			t.Fatalf("expected %q to be skipped by bulk Outline publication", value)
		}
	}
}

func TestOutlineBulkEnvironmentSkipReason(t *testing.T) {
	if got := outlineBulkEnvironmentSkipReason(""); got != "Mediu nespecificat — publicarea în masă include numai PROD" {
		t.Fatalf("unexpected empty environment reason: %q", got)
	}
	if got := outlineBulkEnvironmentSkipReason("TEST"); got != "Mediu TEST — publicarea în masă include numai PROD" {
		t.Fatalf("unexpected TEST environment reason: %q", got)
	}
}
