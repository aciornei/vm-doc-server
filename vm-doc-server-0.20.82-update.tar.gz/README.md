# 0.20.82

**Server current: 0.20.82** — publicarea VM-urilor în Outline folosește titluri `vm-...`, iar publicarea în masă din Documente este limitată la mediul PROD și afișează explicit VM-urile sărite.

- titlul unei pagini VM în Outline este `vm-<numele VM>`; dacă numele are deja prefix `vm-`/`VM-`, acesta este normalizat fără dublare;
- **Documente → Publică în Outline → VM-uri** publică doar VM-urile cu mediul `PROD` dintre candidatele selectate de filtrul existent `Doar VM-uri pornite`;
- TEST, DEV și mediile nespecificate apar la **VM-uri sărite**, cu coloanele VM, Mediu și Motiv;
- VM-urile PROD excluse manual prin `Nu se publică în Outline` apar tot ca sărite, nu ca erori;
- publicarea individuală din fișa VM nu este blocată după mediu, dar folosește același prefix `vm-` pentru titlul Outline;
- fără migrare DB și fără schimbare de agent; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.81

**Server current: 0.20.81** — completează diagrama Network Map cu IP-urile exacte care au produs match-ul FortiGate și separă vizual contextul VDOM/NAT de numele policy-ului.

- pentru VM-urile corelate din Sursă/Destinație, numele VM-DOC rămâne afișat o singură dată, iar dedesubt apar `IP x.x.x.x` pentru IP-ul/IP-urile din `fortigate_vm_matches.vm_ip`;
- obiectele FortiGate rămân sub IP-uri și continuă să aibă expand/restrânge atunci când sunt multe;
- nodul policy are acum spațiu separat între `#policy nume` și contextul `VDOM · NAT` / `VDOM · FĂRĂ NAT` (plus VIP unde este cazul);
- serviciile/porturile TCP rămân listate vertical, UDP rămâne omis din diagramă, iar portul 53 rămâne ascuns pe VM-urile DNS;
- fără migrare DB și fără Sync FortiGate obligatoriu; datele IP sunt luate din matching-ul deja existent; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.80

**Server current: 0.20.80** — rafinează diagrama Network Map pentru reguli FortiGate și reduce zgomotul din porturile observate.

- numele VM-ului corelat în VM-DOC este afișat o singură dată în nodul sursă/destinație; obiectele/IP-urile FortiGate rămân dedesubt, fără repetarea numelui;
- policy-urile FortiGate afișează **SERVICII / PORTURI PERMISE** pe linii separate, fără limită artificială; nodul policy își mărește automat înălțimea;
- serviciile explicit UDP sunt omise din diagramă, iar corelarea săgeții către port nu mai folosește servicii UDP-only;
- nodurile VM afișează numai porturile TCP observate; pentru VM-urile identificate ca DNS, portul 53 este ascuns din diagramă;
- schimbările sunt exclusiv de prezentare Network Map: nu se șterg date de inventar sau reguli FortiGate și nu este necesar un nou Sync;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.79

**Server current: 0.20.79** — corectează scroll-ul orizontal global și rafinează diagrama de rețea: obiecte Forti expandabile, porturi verticale în nodurile VM și fluxuri fără limita artificială de 24.

- bara stânga–dreapta este din nou a paginii/browserului pe desktop atunci când tabelele sau diagrama depășesc viewport-ul;
- în diagramă, obiectele sursă/destinație Forti afișează primele 4 intrări pe verticală și `+N · extinde` pentru restul;
- nodurile VM afișează porturile observate unul sub altul; pentru servicii Forti mapabile sigur (numeric sau servicii uzuale), săgeata intră direct în portul observat;
- diagrama nu mai taie fluxurile la 24, iar backend-ul Network Map nu mai oprește lista la 200 de fluxuri;
- detaliile tehnice ale fluxurilor nu mai sunt tăiate la primele 120;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.78

**Server current: 0.20.78** — Network Map are acum o diagramă SVG interactivă, tip Visio, generată automat per VM și per serviciu din DECLARAT / OBSERVAT / PERMIS.


- adaugă diagramă de rețea SVG tip Visio în **VM → Securitate → Hartă rețea** și **Serviciu → Rețea**;
- VM-urile sunt noduri clickable, cu IP, componente observate și firewall host;
- policy-urile FortiGate sunt noduri intermediare pe fluxurile sursă → policy → destinație;
- dependențele declarate sunt desenate distinct, cu linii întrerupte;
- diagrama este compactă (max. 12 VM / 24 fluxuri), iar detaliile complete rămân disponibile sub diagramă;
- export SVG direct din interfață;
- fără schimbări DB, matching, sync sau agent; `vm-doc-agent 1.7.12` rămâne recomandat.

- mută **VM → Hartă rețea** sub grupul **Securitate**, reducând numărul de taburi principale;
- **VM → Securitate → Firewall** are carduri clickable pentru Source / Destination / VIP / Indicatori, tabel cu coloane separate Sursă/Destinație, Export Excel și panou pentru firewall-ul local al VM-ului;
- tabelele FortiGate au zonă verticală limitată și scrollbar orizontal accesibil în zona vizibilă a tabelului;
- reorganizează **Securitate → Firewall** în submeniurile **1. Caută / 2. Surse & Sync / 3. Analiză Forti**;
- filtrele Firewall și Analiză sunt compacte/orizontale, iar KPI-urile sunt micșorate pentru un singur rând pe desktop;
- Add/Edit sursă FortiGate este formular inline, fără prompt-uri succesive;
- adaugă `GET /api/v1/fortigate/rules/export`, cu export XLSX global filtrat și per VM;
- nu schimbă matching-ul FortiGate și nu necesită Sync doar pentru upgrade; fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.74

- adaugă **VM → Rețea → Hartă rețea** și **Serviciu → Rețea**, pe modelul **DECLARAT / OBSERVAT / PERMIS**;
- DECLARAT include servicii, dependențe interne inbound/outbound și conexiuni externe; OBSERVAT include porturi ascultate, Docker, baze și Web; PERMIS include firewall host și FortiGate;
- adaugă o vedere de fluxuri FortiGate `sursă → policy/service → destinație`, cu VM-urile corelate și obiectele FortiGate originale;
- adaugă **Securitate → Analiză FortiGate / Firewall Hygiene**, cu policies Corelate / Necorelate cu inventarul / Prea largi / Necesită verificare și indicatori ALL / fără comentariu;
- policies necorelate nu sunt declarate automat inutile; fără hit-count/last-used ele sunt doar candidați de verificare;
- analiza afișează VM-uri distincte și corelări source/destination/VIP per policy;
- Test/Sync FortiGate refuză acum răspunsurile `limited_permission=true`, evitând importul configurației mascate/default;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.73

- adaugă review pentru regulile FortiGate corelate cu VM-urile, direct în **Securitate → Firewall central** și în **VM → Securitate → Firewall**;
- review-ul Firewall folosește același flux ca pentru conturi, baze și Web ACL: interval 6/12 luni, justificat Da/Nu, observații, reviewer, last review și next review;
- cheia review-ului este stabilă la resincronizare: `VM + sursă FortiGate + VDOM + Policy ID + rol` (`source` / `destination` / `vip`), nu ID-ul temporar al match-ului;
- adaugă filtrul **Review** în Firewall central: Toate / Necesită review / Nerevizuite / La zi;
- **Rapoarte → Revizii securitate** include categoria nouă **Firewall**, cu policy, rol, indicatori de risc, corelarea FortiGate și calendarul review-ului; exportul Excel include automat și aceste rânduri;
- intervalul implicit pentru Firewall este 6 luni; nu există migrare DB nouă deoarece este reutilizată tabela generică `security_reviews`;
- fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.72

- FortiGate CMDB este citit din nou prin GET complet, fără `start/count`; 0.20.71 putea trunchia inventarul exact la 500 de policy-uri;
- dacă FortiGate raportează `limit_reached=true`, sincronizarea se oprește explicit și nu persistă un inventar parțial;
- corelarea IPv4 sigură acceptă `ipmask`, `iprange`, `interface-subnet` și `wildcard`, plus VIP/DNAT;
- `dynamic`, `geography`, FQDN, MAC, route-tag și `/0` nu sunt folosite ca dovadă de apartenență a unui VM;
- Test FortiGate afișează totalul active + disabled și distribuția tipurilor de address objects corelabile;
- fără migrare DB și fără agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.70

- corectează matcher-ul FortiGate: numai obiectele IPv4 statice `ipmask` și `iprange` pot dovedi apartenența unui VM la o policy; tipurile `geography`, `dynamic`, `interface-subnet`, `wildcard`, `mac`, `route-tag`, FQDN etc. sunt ignorate pentru corelarea VM;
- obiectele custom `0.0.0.0/0` sunt tratate ca `all` și nu mai generează match-uri către toate VM-urile;
- grupurile de adrese sunt păstrate recursive, dar produc match doar dacă traseul ajunge la un obiect IPv4 static valid;
- păstrează maximum un match `source` și unul `destination` per VM/policy, indiferent de numărul de IP-uri sau obiecte suprapuse; VIP-urile rămân distincte;
- migrarea `070_fortigate_strict_vm_matching.up.sql` șterge corelările vechi calculate cu algoritmul permisiv și adaugă indexuri pentru paginarea Firewall central; după upgrade este necesar un Sync FortiGate;
- optimizează `GET /api/v1/fortigate/rules`: statisticile sunt calculate într-o singură agregare, iar pagina este ordonată după cheile indexabile ale match-ului în loc de un filesort global după numele VM;
- Test FortiGate raportează separat obiectele IP corelabile și obiectele ignorate;
- nu necesită agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.69

- hotfix pentru migrarea `069_fortigate_ignore_disabled_policies.up.sql`: `disabled_policy_count` și indexul FortiGate sunt create cu `IF NOT EXISTS`, astfel încât migrarea poate fi reluată după un startup 0.20.68 întrerupt;
- rezolvă eroarea de pornire `Duplicate column name disabled_policy_count`;
- nu schimbă schema funcțională față de 0.20.68 și nu necesită agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.68

- FortiGate: policy-urile cu `status=disable` / `disabled` / `off` nu mai sunt salvate și nu mai intră în corelarea VM ↔ firewall;
- matcher-ul verifică defensiv starea policy-ului înainte de orice corelare, inclusiv pentru VIP/DNAT;
- **Securitate → Firewall central** afișează numai policy-uri active și nu mai oferă filtrul pentru Disabled;
- Test conexiune raportează separat `policies active` și `disabled ignorate`, iar istoricul de Sync păstrează numărul policy-urilor disabled sărite;
- migrarea `069_fortigate_ignore_disabled_policies.up.sql` elimină din inventarul existent policy-urile disabled și corelările lor și adaugă index pe status;
- `match_count` din noile sincronizări reprezintă exclusiv corelări provenite din policy-uri active;
- nu necesită agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.67

- adaugă integrarea **FortiGate REST API** în **Securitate → Firewall central**, cu surse multiple, VDOM, token API criptat, Test, Sync manual și scheduler;
- sincronizează address objects, address groups, firewall policies și VIP/DNAT din FortiGate;
- corelează IP-urile VM cu obiecte exacte, subneturi, intervale și grupuri nested/recursive; un obiect `all` singur nu este folosit ca dovadă de apartenență a unei VM, pentru a evita corelări false;
- corelează VIP/DNAT prin `mappedip` și afișează VM-ul ca sursă, destinație sau țintă VIP;
- adaugă filtre/paginare după FortiGate, VDOM, rol VM, action, policy status, service, interfață și indicator;
- evidențiază pentru review indicatori precum source ALL, destination ALL, service ALL, WAN → VM, VIP/DNAT și lipsa comentariului, fără a clasifica automat regula ca nesigură;
- adaugă **VM → Securitate → Firewall**, cu motivul exact al corelării și link către Firewall central;
- migrarea DB `068_fortigate_firewall_inventory.up.sql`; nu necesită agent nou, `vm-doc-agent 1.7.12` rămâne recomandat.

# 0.20.66

- adaugă raportul **Rapoarte → Revizii securitate**, ca plan calendaristic pentru Access Review;
- tabel paginat cu VM, versiune agent, categorie, resursă, indicatori, ultimul review, următorul review și numărul de zile până la scadență;
- filtre după VM, versiune agent, categorie (Conturi / Baze de date / Web), status, perioadă calendaristică, reviewer, justificare și risc, plus intervale Last review / Next review și min/max zile până la scadență;
- preseturi rapide pentru Nerevizuite, Expirate, Săptămâna aceasta, Săptămâna viitoare, Luna aceasta, Luna viitoare, Următoarele 30 zile și Risc ridicat;
- export Excel respectând filtrele active și acțiune **Revizuiește** direct din raport;
- raportul prioritizează automat nerevizuitele, expiratele și următoarele scadențe și include indicatori de risc derivați din conturi privilegiate, HBA warnings, GRANT OPTION, ALLOW ALL și lipsa ACL explicit;
- link direct **Calendar revizii** din Securitate;
- fără migrare DB și fără agent nou; vm-doc-agent 1.7.12 rămâne recomandat.

# 0.20.65

- adaugă în VM → Aplicație → Docker / Baze de date / Web filtre după Serviciu, Mediu, Status operațional și Tip soluție;
- filtrele listează numai valorile deja folosite pe VM-ul curent, nu toate valorile globale;
- adaugă filtre separate pentru Necesită/Nu necesită documentare și pentru resurse Complete/Nesetate;
- „Nesetate” include resurse fără asociere sau cu cel puțin o asociere incompletă;
- filtrele combinate se potrivesc pe aceeași asociere serviciu-context;
- fără migrare DB și fără agent nou.

# 0.20.64

- Web Access Control afișează toate site-urile/vhost-urile inventariate, inclusiv cele fără reguli ACL explicite;
- adaugă filtrul ACL: toate / cu reguli / fără ACL explicit / ALLOW ALL;
- pagina VM → Securitate → Web ACL afișează toate vhost-urile VM-ului;
- remediază cazul reverse-proxy în care UI-ul ascundea vhost-urile fără allow/deny, deși existau în inventarul Web.

# 0.20.63

Security / Access Review afișează acum și privilegiile detaliate ale conturilor de baze de date, plus PasswordLastSet / PasswordExpires pentru conturile VM. Privilegiile pot fi căutate și filtrate după GRANT OPTION / DENY și sunt disponibile atât în dashboard-ul global, cât și în pagina VM. Recomandat vm-doc-agent 1.7.12.

# 0.20.62

- adaugă filtre și paginare în **Securitate → Conturi VM / Database Access / Web Access Control**;
- conturile system fără login, fără privilegii și fără o stare de parolă relevantă sunt ascunse implicit; `root` rămâne întotdeauna vizibil, iar conturile system relevante (de ex. cu shell/login, privilegii sau parolă activă/goală) rămân în listă;
- filtrul Tip cont permite afișarea inventarului complet, numai a conturilor system sau numai a utilizatorilor + root;
- adaugă în fișa fiecărui VM zona **Securitate** cu Rezumat, Conturi, Baze de date și Web ACL;
- `GET /api/v1/security` acceptă `vm_id` pentru încărcarea eficientă a securității unei singure VM;
- nu necesită migrare DB și nu necesită o versiune nouă de agent; vm-doc-agent 1.7.11 rămâne recomandat.

# 0.20.61

- modul nou **Securitate / Access Review** cu Dashboard, Conturi VM, Database Access și Web Access Control;
- review configurabil la 6/12 luni, cu reviewed_at/by, justificare și observații;
- conturile VM afișează explicit shell-ul și starea parolei;
- persistă inventarul DB users/roles/HBA și Web allow/deny primit de la agent 1.7.11;
- Web ACL este asociat site-ului/vhost-ului și păstrează source_file pentru reguli provenite din include.
## 0.20.60 · versiuni curate în Componente software

Raportul **Rapoarte → Componente software** filtrează acum mesajele stderr/log capturate accidental ca versiune și normalizează bannerele lungi la versiunea reală a produsului. De exemplu `/usr/sbin/mysqld Ver 10.6.11-MariaDB-0ubuntu...` este afișat ca **10.6.11**, iar liniile `[Warning] ... deprecated ...` sunt ignorate complet.

Corecția se aplică și datelor deja existente și este folosită de interfață, filtre, Export Excel și paginile publicate în Outline. Fără migrare DB și fără update de agent.

## 0.20.59 · publicare Componente software în Outline

Raportul **Rapoarte → Componente software** poate publica acum inventarul în Outline. În **Documente → Configurare Outline** se configurează pagina părinte **Componente suport**; VM-DOC creează sau actualizează sub ea câte o pagină pentru fiecare tehnologie. Fără componentă selectată sunt publicate toate componentele pe rând, iar cu o componentă selectată este publicată numai acea pagină.

În raport și în paginile publicate, VM-urile folosesc linkul către fișa lor Outline, serviciile/proiectele folosesc Link documentație Outline, iar **Power** și **Mediu** sunt coloane separate cu Power normalizat la **ON/OFF**. Include migrarea 066; agentul rămâne neschimbat.

## 0.20.58 · inventar automat componente software

Rapoarte → **Componente software** răspunde direct la întrebări precum „care sunt VM-urile cu PostgreSQL?”, „unde am MongoDB?” sau „unde mai există Java 8?”. Inventarul este derivat automat din date deja colectate de VM-DOC și nu depinde de bifarea manuală Principal/Componentă suport.

Sursele sunt corelate și deduplicate în ordinea încrederii: colectoare DB/Web/Docker, imagini de containere, servicii agent și software instalat. Raportul are filtre, carduri clicabile, paginare și Export Excel. Nu există migrare DB și nu este necesar update de agent.

## 0.20.57 · hotfix numerotare fișă VM cu porturi ascunse

Când `Porturi ascultate` este eliminată intenționat din inventarul documentat, capitolul nu este afișat, dar poziția lui rămâne rezervată în numerotarea fișei. Astfel `Firewall` rămâne `9.7`, fără să se deplaseze la `9.6`. Porturile marcate **Principal** continuă să fie afișate separat.

## 0.20.56 · porturi principale + publicare Outline asincronă

Pentru VM-urile cu multe porturi dinamice (de exemplu AD/DNS), opțiunea **Ascunde porturile ascultate** ascunde numai inventarul complet `listening_ports`. Porturile marcate manual **Principal** rămân vizibile într-o secțiune separată și sunt păstrate în DOCX/Markdown/Outline. Secțiunea completă **Porturi ascultate** nu este generată deloc când politica este activă.

Publicarea individuală a unui VM în Outline este pornită ca job asincron. Browserul primește imediat `202 Accepted` și urmărește `/api/v1/documents/outline/jobs/{id}`, astfel încât un update Outline lent sau un document mai mare nu mai ține deschis request-ul către reverse proxy.

# vm-doc-server 0.20.55

## 0.20.55

- Hotfix de build/test pentru funcția **Ascunde porturile ascultate** introdusă în 0.20.54.
- Testul `vm_listening_ports_test.go` folosește acum structura curentă `inventory.DocumentSection` (`Title`, nu `Label`).
- Funcționalitatea 0.20.54 rămâne neschimbată; fără migrare DB și fără update de agent.


## 0.20.54

- VM-urile pot ascunde intenționat **Porturile ascultate** din interfață și din documentația generată, util pentru AD/DNS și alte servere cu multe porturi dinamice.
- Setarea este per VM în **Configurare → Infrastructură → Porturi ascultate** și nu șterge inventarul colectat; doar îl exclude din afișare/documentare cât timp bifa este activă.
- **Documente → Publică în Outline** afișează VM-urile și serviciile pe rânduri separate.
- Verificarea serviciilor are carduri clicabile, paginare și export Excel filtrat.
- Include migrarea 065; vm-doc-agent rămâne neschimbat.


## 0.20.53

> Repară timeout-ul `504` la verificarea serviciilor pentru Outline. Dry-run-ul rulează acum asincron ca job de fundal, iar UI urmărește progresul până la finalizare. Nu este necesară modificarea timeout-ului din Nginx. Fără migrare DB; agentul rămâne neschimbat.

## 0.20.52

- Publicarea în masă a serviciilor în Outline are acum un pas de verificare/dry-run obligatoriu.
- Dry-run-ul validează eligibilitatea, linkul/documentul Outline și generarea conținutului înainte de a afișa butonul de publicare.
- Publicarea folosește exact serviciile eligibile verificate și cere o nouă verificare înainte de o republicare.
- URL-ul Vault rămâne strict intern și publicarea este blocată defensiv dacă ar ajunge accidental în Markdown.
- Fără migrare DB; agent neschimbat.

## 0.20.51

- VM → Rezumat: Publicare Outline și Vault sunt afișate compact pe același rând.
- Configurare → Infrastructură nu mai conține nici Publicare Outline, nici Vault.
- Vault rămâne strict intern VM-DOC și este exclus din documentația generată/publicată.
- Fără migrare DB; agent neschimbat.


> Versiunea 0.20.50 compactează zona **Publicare Outline** de pe VM și adaugă linkuri **Vault** strict interne aplicației pentru VM-uri și servicii. Linkul Vault nu este inclus în fișe, exporturi de documentație sau Outline. Include migrarea 064; agentul rămâne neschimbat.

> Versiunea 0.20.49 elimină coloana **Hostname** doar din tabelul Inventar VM publicat în Outline. Lista VM și exporturile aplicației rămân neschimbate. Fără migrare DB și fără update de agent.

## 0.20.47


## 0.20.48

- Pagina nouă **Releasuri** oferă istoricul versiunilor aplicației în format colapsat: versiune, dată, modificarea principală și detalii la click.
- Versiunea curentă este evidențiată; istoricul este inclus în aplicație și nu depinde de accesul la internet.
- Fără migrare DB și fără update de agent.

Publicarea **Inventar VM → Outline** folosește acum un tabel mai compact: fără vCenter/Agent/Completare/Ultimul JSON, cu Hostname, Power ON/OFF, Mediu PROD/TEST/DEV și linkuri directe pe VM și servicii atunci când documentația Outline există. Butonul de publicare este afișat numai dacă Outline și destinația `Inventar VM` sunt active și linkul destinației este configurat. Fără migrare DB și fără update de agent.

## 0.20.46

Hotfix de test pentru exportul VM: testul automat reflectă acum cele 26 de coloane existente în export. Nu modifică funcționalitatea aplicației.

> Versiunea 0.20.45 adaugă filtrele **Outline DA/NU** și **OS suportat DA/NU** în lista VM și permite publicarea în Outline a tabelului rezultat din filtrele curente. Destinațiile de publicare sunt configurate generic din **Documente → Configurare Outline**, începând cu `Inventar VM`, pentru a putea reutiliza același mecanism ulterior la Componente suport, Backup, Monitorizare etc. Include migrarea 063; agentul rămâne neschimbat.
> Versiunea 0.20.44 întărește publicarea în masă a VM-urilor către Outline: bifa **Nu se publică în Outline** este verificată explicit pentru fiecare VM înainte de publicare, VM-urile excluse sunt sărite și raportate separat în progres. Fără migrare DB și fără update de agent.
> Versiunea 0.20.43 îmbunătățește raportul Suport sisteme de operare: adaugă coloana **Servicii**, selectează implicit **VM Pornit** și rafinează spațierea dintre filtre, carduri, grafice, tabel și rândul de acțiuni/Export Excel. Fără migrare DB și fără update de agent.

> Versiunea 0.20.42 adaugă în lista principală de VM-uri coloanele **Outline DA/NU** (din bifa existentă de publicare) și **Ultima publicare Outline** (din mapping-ul Virtualizare). Aceleași informații sunt incluse și în exportul Excel VM. Fără migrare DB și fără update de agent.

> Versiunea 0.20.41 reorganizează raportul **Suport sisteme de operare**: filtrele sunt primele, cardurile se recalculează după căutare și filtrele generale, graficele sunt într-o secțiune colapsată implicit, iar tabelul este paginat cu selector 10/25/50/100/200 pe pagină. Exportul Excel respectă filtrele active și nu este limitat la pagina curentă. Fără migrare DB și fără update de agent.

> Versiunea 0.20.40 repară filtrele interactive din rapoartele **Suport sisteme de operare**, **Outline · VM-uri** și **Outline · Servicii**: cardurile aplică filtrele la click, select-urile reacționează la schimbare, căutarea funcționează live/Enter și există butoane explicite **Caută / Aplică** și **Resetează**. Exportul Excel urmărește filtrele active. Fără migrare DB și fără update de agent.
> Versiunea 0.20.39 separă raportarea Outline în **Outline · VM-uri** și **Outline · Servicii**, adaugă filtre interactive și export Excel filtrat, carduri clicabile și filtre Pornit/Oprit/Stare. Raportul **Suport sisteme de operare** primește aceleași filtre operaționale. Migrarea 062 repară definitiv unicitatea nomenclatorului OS și prepopulează regulile EOL standard. Agentul rămâne neschimbat.
> Versiunea 0.20.37 adaugă nomenclatorul **Sisteme de operare nesuportate**, raportul de suport OS cu pie chart-uri și liste Suportate/Nesuportate/Nedeterminate, plus raportul **Publicare Outline** pentru VM-uri și servicii. Starea de publicare apare explicit și în rezumatele VM/Serviciu. Include migrarea 060; agentul rămâne neschimbat.
> Versiunea 0.20.38 repară publicarea Outline și cele două rapoarte introduse în 0.20.37: schema Outline este reparată idempotent prin migrarea 061, endpoint-ul VM acceptă câmpul corect și aliasul vechi, iar rapoartele Publicare Outline / Suport OS nu mai cad dacă o coloană istorică lipsește. Agentul rămâne neschimbat.
> Versiunea 0.20.36 corectează editarea **Componentelor suport**: bifarea și salvarea se fac inline, fără reload, iar Componenta propusă, Versiunea manuală, Porturile manuale și valorile detectate automat sunt vizibile imediat pe rândul serviciului. Fără migrare DB nouă și fără update de agent.
> Versiunea 0.20.35 adaugă **Componente suport** selectabile direct din serviciile observate de agent pe fiecare VM și un raport dedicat grupat Componentă → Versiune → Mediu, cu VM, IP, porturi și serviciile/proiectele asociate. Include migrarea 059 și nu necesită update de agent.
> Versiunea 0.20.34 face vizibil controlul **Nu se publică în Outline** direct în Rezumatul VM, păstrându-l și în Configurare → Infrastructură. Fără migrare DB nouă și fără update de agent.
> Versiunea 0.20.33 adaugă lifecycle pentru servicii (retras, motiv și dată), controlul explicit **Nu se documentează în Outline** pentru servicii și **Nu se publică în Outline** pentru VM-uri, ascunde temporar exporturile PDF din UI și afișează acțiunile Outline numai când integrarea este activată global. Dacă o pagină VM a fost ștearsă în Outline, este recreată automat la următoarea publicare. Include migrarea 058 și nu necesită update de agent.
> Versiunea 0.20.31 corectează structura Outline: VM-urile sunt publicate direct sub documentul **Virtualizare**, identificat prin propriul Document ID; proiectele nu mai sunt create automat în Outline, iar alte categorii pot primi ulterior părinți independenți. Include migrarea 057 și nu necesită update de agent.
> Versiunea 0.20.32 separă **Documente** în **Export / Publică** și **Șabloane**, completează publicarea Outline pentru servicii pe baza câmpului **Link documentație** și păstrează legăturile wiki exclusiv în Outline: VM → servicii și serviciu → VM. Titlul paginii VM este numele exact din vCenter. Nu include migrare DB și nu necesită update de agent.
> Versiunea 0.20.30 adaugă publicarea directă în **Outline**. Integrarea se configurează din Documente cu URL, API key criptat, colecție și opțional document părinte. Fiecare proiect devine o pagină Outline, iar fișele VM pot fi publicate ca pagini copil sub proiect. Există publicare individuală din fișa Proiect/VM și publicare în masă din Documente. Include migrarea 056 și nu necesită update de agent.
> Versiunea 0.20.29 rafinează exportul în masă DOCX: VM-urile pot fi limitate implicit la cele pornite, iar proiectele pot fi regenerate integral înainte de arhivare. Fișele regenerate nu includ rândul vizibil „Generat de”. PDF-ul rămâne neschimbat. Nu există migrare DB și nu necesită update de agent.
> Versiunea 0.20.27 adaugă exportul în masă al documentației: patru butoane în **Documente** pentru arhive ZIP cu ultima fișă a tuturor VM-urilor sau a tuturor proiectelor, separat în DOCX și PDF. Arhivele includ manifest și sumar; PDF-ul este convertit on-demand prin LibreOffice/soffice. Nu există migrare DB și nu necesită update de agent.
> Versiunea 0.20.26 adaugă **Echipamente** pentru dispozitive și resurse non-VM: identificare manuală, IP/locație/responsabil, tip editabil din nomenclator și asocieri multiple la servicii cu rol, protocol, port, sens și scop. Echipamentele apar în pagina serviciului, schema lui, căutarea globală, Audit și fișele DOCX/Markdown. Include migrarea 055; agentul rămâne neschimbat.
> Versiunea 0.20.25 permite mai multe fluxuri de dependență între aceleași două servicii chiar dacă au același tip de relație și aceleași medii. Fiecare rând este o dependență distinctă, diferențiabilă prin protocol/port și Scop / detalii; fluxurile multiple sunt păstrate și în schema serviciului, VM-urile dependente și documentația DOCX/Markdown. Nu adaugă migrare DB și nu necesită update de agent.
> Versiunea 0.20.24 transformă prima pagină într-un dashboard operațional: căutare globală, KPI-uri clickabile, listă de atenție, modificări recente, stare colectări, acoperire, HA și servicii cu lipsuri. Nu adaugă migrare DB și nu necesită update de agent.
> Versiunea 0.20.23 adaugă audit contextual direct pe VM și Serviciu, cu filtre și denumiri lizibile pentru resurse, plus rapoarte Persoane & responsabilități și Lipsuri operaționale cu export Excel. Nu adaugă migrare DB și nu necesită update de agent.
> Versiunea 0.20.18 generalizează dependențele Serviciu → Serviciu. Orice serviciu activ poate fi țintă, relațiile pot fi diferențiate pe mediu sursă/destinație și pot avea criticitate, protocol/port, observații și stare activă. Pagina serviciului afișează „Depinde de” și „Este utilizat de”, iar fișele DOCX/Markdown includ noile detalii. Include migrarea 052; nu necesită update de agent.
# vm-doc-server 0.20.47

> Versiunea 0.20.16 leagă proiectele/serviciile selectate în Docker, Baze de date și Web de Configurare servicii. Fiecare serviciu distinct folosit de aceste resurse devine criteriu de completare și trebuie să existe și în asocierea VM–serviciu cu domeniu, categorie, layer, rol tehnic și tip soluție. Fără migrare DB și fără update de agent.
> Versiunea 0.20.15 adaugă în Inventar → Servicii confirmarea persistentă `Servicii verificate`. Pe Linux, dacă nu există un serviciu agent marcat Principal, criteriul de completare este satisfăcut numai după această confirmare manuală. Include migrarea 051 și nu necesită update de agent.

> Versiunea 0.20.14 separă completarea documentației după OS: Windows cere software principal, Linux cere servicii selectate, și adaugă Baseline Da/Nu în fișa VM, filtre și exportul Excel. Fără migrare DB și fără update de agent.

> Versiunea 0.20.13 revizuiește completitudinea fișei VM pe resurse individuale, adaugă IP-ul principal și acțiunile Test/Colect în Inventar, repară layout-ul asocierilor și stabilizează navigarea la clickuri rapide. Fără migrare DB și fără update de agent.
> Versiunea 0.20.11 completează curățarea versiunilor în documentele generate: elimină Warning/[Warning] și din package_version, software instalat, preview-urile DB/Docker și fallback-urile inventarului, atât în DOCX cât și în Markdown. Fix exclusiv server-side; agentul rămâne neschimbat.
> Versiunea 0.20.10 curăță la nivel de server avertismentele incluse accidental în câmpurile de versiune raportate de aplicații și normalizează corect ieșirea MySQL/MariaDB de forma `Ver 14.14 Distrib 5.5.37`. Nu necesită update de agent.
> Versiunea 0.20.9 redenumește documentul generat pentru serviciu în **Fișă tehnică și operațională a serviciului** și documentele DOCX atașate în **Proceduri operaționale și fluxuri de lucru**. Procedurile sunt păstrate la final ca anexe B1/B2…, după anexele VM A1/A2…. Include migrarea 050 doar pentru metadatele șablonului implicit; fără update de agent.


> Versiunea 0.20.8 corectează eroarea HTTP 500 la deschiderea unui Serviciu care are Site-uri Web asociate. Query-ul de corelare Web selectează acum toate coloanele așteptate de Scan, inclusiv `documentation_exempt`. Fără migrare DB și fără update de agent.
> Versiunea 0.20.7 permite rândurilor lungi din tabelele DOCX să continue pe pagina următoare în loc să fie mutate integral, inclusiv pentru Site-uri Web/DB/Docker și celelalte tabele din fișele VM/Serviciu. Documentația DOCX suplimentară a serviciului nu mai întrerupe capitolul 2, ci este adăugată la final ca anexă B1/B2/etc. Nu include migrare DB și nu necesită update de agent.
> Versiunea 0.20.5 adaugă marcajul `Nu necesită documentare` la nivel de container Docker, bază logică și configurație/site Web, aliniază controalele în UI, simplifică tabelele fișei VM și face anexele Markdown să reproducă structurat secțiunile tehnice din Word (rețea, servicii, porturi, firewall, conturi, SSSD, integrări, cron și NTP). Include migrarea 049 și nu necesită update de agent.

> Versiunea 0.20.4 adaugă controlul `Data referință` / `Generat de`, IP principal documentație, RPO/RTO în Date operaționale, marcajul `Nu necesită documentare` pentru Docker/DB/Web, versiuni scurte și îmbunătățiri DOCX/Markdown. Include migrarea 048 și nu necesită update de agent.

> Versiunea 0.20.3 corectează exportul Markdown pentru Outline: dacă este bifată opțiunea **Lipește anexele A1, A2… în același document**, conținutul complet al fișelor VM este inclus în același `.md` ca secțiuni A1/A2/etc., nu doar referințele către fișele VM. Nu include migrare DB.

> Versiunea 0.20.2 adaugă exportul manual Markdown pentru Outline/wiki direct din fișa serviciului, păstrând structura documentației și rich-text-ul principal. Exportul `.md` nu se salvează în istoricul documentelor și nu include migrare DB.

> Versiunea 0.20.1 permite integrarea anexelor A1/A2 direct în DOCX-ul serviciului, păstrează formatarea originală a documentației DOCX suplimentare și simplifică tabelele VM-uri asociate / Monitorizare / Backup. Mediile sunt afișate ca PROD / TEST / DEV. Nu include migrare DB.

> Versiunea 0.20.0 extinde documentarea serviciilor: Tip soluție pe asocierile Docker/DB/Web, câmpuri noi de identificare (descriere scurtă, autentificare, link, tehnologii), documentație suplimentară DOCX, fișe VM mutate în Anexe și formatare îmbunătățită a fișei de serviciu. Documentele generate folosesc Arial 12 pentru text normal. Include migrarea 047.

> Versiunea 0.19.16 adaugă inventarul software instalat raportat de vm-doc-agent 1.7.2, fila din VM cu filtre/export și selecția persistentă `Principal`. Toate aplicațiile rămân în inventar, iar fișa VM include numai software-ul marcat Principal. Fila apare numai când există date software. Include migrarea 046.

> Versiunea 0.19.15 ascunde bazele tehnice/de sistem din UI și documentație, semnalează în Rezumat instanțele DB pentru care enumerarea bazelor a eșuat și adaugă Mediu + Status operațional din nomenclatoare pe asocierile Baze de date / Docker / Web. Include migrarea 045 și este recomandată împreună cu vm-doc-agent 1.6.11 pentru hosturi PostgreSQL 8/9 multi-instance.

> Versiunea 0.19.14 adaugă în inventarul structurat DB joburile PostgreSQL `pgAgent` / `pg_cron` raportate de vm-doc-agent 1.6.10 și le include în UI și documentația VM/serviciu. Sunt păstrate numai metadatele schedulerului; SQL-ul, comenzile și scripturile nu sunt colectate. Include migrarea 044.

> Versiunea 0.19.13 expune în UI publicarea release-urilor de agent Linux `386` pe lângă `amd64`. Repository-ul și protocolul de auto-update erau deja indexate după arhitectură; nu există migrare DB. Este versiunea recomandată pentru vm-doc-agent 1.6.8 pe servere x86_64 și i386/i686.

> Versiunea 0.19.12 filtrează serviciile OS din vederea implicită și din secțiunea `Servicii active` a documentației pe baza clasificării conservatoare raportate de vm-doc-agent 1.6.7. Serviciile principale și cazurile necunoscute rămân vizibile. Nu are migrare DB.

> Versiunea 0.18.3 separă configurarea VM-ului într-un job Veeam de existența unui restore point: VM-urile nou adăugate în job apar imediat ca „Așteaptă primul backup”, iar backupurile rămase după scoaterea din job sunt semnalate separat.

> Versiunea 0.18.0 adaugă integrarea read-only cu Veeam Backup & Replication: surse configurabile, test de conexiune, sincronizare periodică configurabilă și popularea automată a secțiunii Backup din fișa fiecărui VM. Corelarea se face după numele exact al VM-ului.

> Versiunea 0.17.2 adaugă baseline pentru inventarul de modificări: starea curentă este acceptată ca punct de pornire, iar evenimentele anterioare rămân în baza de date fără a produce zgomot sau a penaliza completarea documentației. Baseline-ul poate fi resetat global sau per VM.


> Hotfix 0.17.1: corectează tipurile FK din migrarea 032 (`BIGINT UNSIGNED`) pentru compatibilitate cu tabelele existente.

Platformă centrală pentru documentarea VM-urilor, cu **vCenter drept punctul 0 al inventarului** și `vm-doc-agent` drept sursă pentru detaliile din sistemul de operare.

```text
vCenter API ──> virtual_machines ──┐
                                  ├──> vm-doc-server ──> browser / API
vm-doc-agent ─> collector ─> JSON ┘
```







## Echipamente / dispozitive non-VM · 0.20.26

Meniul **Echipamente** documentează resurse care nu există în vCenter ca VM-uri: dispozitive medicale, analizoare de laborator, appliance-uri, servere fizice, storage sau echipamente embedded. Doar denumirea este obligatorie; opțional se pot completa tipul, producătorul/modelul/seria, hostname/IP/MAC, locația, responsabilul, descrierea, observațiile și URL-ul documentației.

Legătura cu un Serviciu este many-to-many. Un echipament poate fi folosit de mai multe servicii, iar între același echipament și același serviciu pot exista mai multe fluxuri cu **rol, protocol, port, sens și scop** distincte. Asocierile se administrează atât din fișa echipamentului, cât și din `Serviciu → Componente → Echipamente`. Ele apar în schema serviciului și în exporturile DOCX/Markdown.

Tipurile de echipament sunt valori editabile în `Nomenclatoare → Echipamente → Tip echipament`. Migrarea `055_equipment_inventory.up.sql` adaugă tabelele `equipment_devices` și `equipment_service_assignments` și permisiunile RBAC `equipment.read` / `equipment.manage`.


## Porturi și procese principale · 0.19.6

În **VM → Inventar → Porturi ascultate**, fiecare combinație `protocol + port + proces` poate fi marcată **Principal**. Selecția este persistentă și nu folosește PID-ul drept identificator, astfel încât rămâne valabilă după restartul procesului.

Fișa VM include o subsecțiune **Porturi și procese principale** cu port, protocol, proces, PID-ul curent, executabil, adresele de listen și starea detectării. Lista completă de porturi rămâne și în inventarul tehnic. Secțiunea separată **Politici** raportată de agent nu mai este inclusă în fișa VM; informațiile specifice firewall-ului, inclusiv politicile implicite ale firewall-ului, rămân în capitolul Firewall.

Migrare DB: `041_vm_primary_agent_ports.up.sql`. Nu este necesară modificarea agentului sau collectorului; `vm-doc-agent 1.6.3` rămâne versiunea curentă. Vezi `docs/UPGRADE-0.19.6.md`.

## Interfață VM și listbox-uri · 0.19.5

Meniul **VM-uri** este împărțit în **Inventar VM** și **Surse & sincronizări**. Lista VM are căutarea separată de filtre, controale pe 2–3 coloane în funcție de ecran, filtre active vizibile și mai mult spațiu între elemente.

Fișa unei VM folosește un meniu principal pe zone: Rezumat, Configurare, Aplicație, Inventar, Backup, Monitorizare, Documentație și Modificări. Zonele cu mai multe secțiuni au un al doilea nivel de navigare. Hash-urile vechi (`/services`, `/docker`, `/web` etc.) rămân compatibile.

Listbox-urile searchable păstrează aceeași componentă, dar dropdown-ul este randat în portal, își fixează direcția sus/jos pe durata deschiderii, iar săgeata este desenată CSS și are același aliniament în toată aplicația. Selecturile native rămase au același chevron și padding rezervat.

Nu există migrare DB în 0.19.5 și agentul rămâne 1.6.3. Vezi `docs/UPGRADE-0.19.5.md`.

## Curățare VM-uri dispărute · 0.19.4

În pagina **VM-uri**, filtrul `vCenter = Lipsă din vCenter` izolează VM-urile pe care ultimul Sync nu le mai găsește în sursă. Aceste înregistrări pot fi șterse definitiv individual sau bulk. Nu se creează o arhivă nouă. Înainte de delete, UI afișează impactul asupra asocierilor de servicii, fișelor generate, backupului, monitorizării și celorlalte date dependente. O VM încă prezentă în vCenter nu poate fi ștearsă din vm-doc.

Pentru curățare: șterge VM-ul în vCenter, rulează **Sincronizează vCenter**, filtrează `Lipsă din vCenter`, apoi șterge înregistrarea din vm-doc. Targeturile Prometheus/Blackbox rămân în inventarul de monitorizare și devin necorelate; agentul nu este șters automat.

Vezi `docs/UPGRADE-0.19.4.md`.

## Monitorizare Prometheus / Blackbox · 0.19.3

Serverul interoghează read-only API-urile Prometheus și păstrează numai inventarul/starea targeturilor. Sursele `metrics` și `blackbox` pot indica același Prometheus; targeturile sunt separate după metadatele `/probe`.

Corelarea targeturilor cu VM-urile este deterministă:

```text
label explicit (implicit vm_fqdn)
        ↓
FQDN exact
        ↓
hostname exact
        ↓
IP exact (agent + primary vCenter + toate IPv4-urile guest vCenter)
        ↓
/etc/hosts al agentului asociat sursei Prometheus
        ↓
alias manual
```

În 0.19.3, vCenter citește best-effort `/api/vcenter/vm/{vm}/guest/networking/interfaces` și persistă toate IPv4-urile utile. Astfel, dacă Prometheus are `app01 -> 172.20.2.10` în propriul `/etc/hosts`, iar vCenter raportează VM-ul cu `172.20.1.10` ca IP principal și `172.20.2.10` pe a doua interfață, targetul se corelează fără agent pe VM.

Meniul **Monitorizare** are două pagini: **Stare monitorizare** pentru VM-uri și targeturi, respectiv **Surse & sincronizări** pentru configurarea Prometheus/Blackbox și istoricul Sync. Formularul de sursă este mai mare și grupat pe Conexiune, Corelare și Sincronizare/TLS.

Vezi `docs/MONITORING.md` și `docs/UPGRADE-0.19.3.md`.

## Integrare Veeam · 0.18.0

Serverul se conectează direct la REST API-ul Veeam Backup & Replication, fără componentă nouă pe VM-uri. Din meniul **Backup** se configurează una sau mai multe surse, se testează autentificarea și se pornește sincronizarea. Parola este criptată în baza de date cu cheia master existentă.

Pentru VBR 12.1, configurația inițială recomandată este:

```text
URL: https://<veeam-server>:9419
REST API: 1.1-rev1
Sincronizare: 1440 minute
TLS verify: activ
```

Corelarea este intenționat strictă după numele VM-ului, fără fuzzy matching. Pe lângă `backupObjects`, 0.18.3 citește și `virtualMachines.includes` din definițiile joburilor. Astfel, apartenența la job este cunoscută înainte de primul restore point și este păstrată separat de starea efectivă de protecție. Detaliile apar în cardul Backup existent din pagina/fișa VM și în tabelul central paginat din meniul **Backup**, cu căutare și filtre de stare.

Vezi `docs/VEEAM.md` și `docs/UPGRADE-0.18.3.md`.

## Modificări inventar · 0.17.0

Serverul compară semantic fiecare snapshot de inventar cu snapshot-ul anterior și creează evenimente de modificare pentru obiectele relevante operațional. Câmpurile volatile precum timpii de colectare, uptime-ul, duratele și identificatorii de proces efemeri sunt ignorate pentru a evita zgomotul. Evenimentele sunt disponibile global din meniul **Modificări** și per VM din fila cu același nume. Fiecare eveniment are o decizie manuală de documentație (`Nesetat`, `Necesită documentație`, `Nu necesită`) și o stare de revizuire (`Nou`, `Revizuit`, `Ignorat`).

## Ce aduce versiunea 0.17.0

- meniu global **Modificări** și filă per VM;
- diferențe semantice între snapshot-uri succesive, fără zgomotul câmpurilor volatile;
- triere manuală pentru impactul asupra documentației și starea de revizuire;
- filtre, paginare, comparație valori vechi/noi și backfill pentru ultimele snapshot-uri;
- migrare `032_inventory_changes.up.sql`; `vm-doc-agent 1.6.1` rămâne suficient.

Vezi `docs/UPGRADE-0.17.0.md`.

## Ce aduce versiunea 0.16.4

- listbox-urile cu căutare nu mai „tremură” la click și își recalculează poziția după filtrare;
- lista filtrată rămâne ancorată de câmp indiferent dacă este afișată deasupra sau dedesubt;
- mesajul Docker pentru VM-urile fără Docker are padding și spațiere corectă.

Vezi `docs/UPGRADE-0.16.4.md`.

## Ce aduce versiunea 0.16.3

- dropdown-urile cu căutare sunt randate peste panouri/tabele și nu mai sunt ascunse de overflow/z-index, inclusiv la asocierea serviciilor din Web;
- detaliile Docker au padding mai clar;
- fișa VM elimină „Schema inventar” goală și folosește numerotare continuă pentru subsecțiunile Inventar agent;
- subsecțiunile de nivel 2 (de exemplu 5.1) sunt indentate explicit;
- tabelul Porturi ascultate păstrează o singură intrare per port/protocol și alege rândul cu cele mai complete date despre proces/executabil.

Nu există migrare SQL nouă; `vm-doc-agent 1.6.1` rămâne suficient.

Vezi `docs/UPGRADE-0.16.3.md`.

## Ce aduce versiunea 0.16.2

- listarea VM afișează versiunea agentului lângă starea Online/Offline, fără coloană separată;
- toate select-urile cu o singură valoare au căutare prin tastare, păstrând valorile și evenimentele native;
- istoricul sincronizărilor vCenter este paginat, implicit 10 rezultate/pagină;
- spațiere corectă după meniul VM pentru filele Docker, Baze de date și Web;
- previzualizarea fișei VM este mai lată și structurată pe secțiuni/row-uri compacte;
- secțiunea Conexiuni către sisteme externe are padding și delimitare vizuală;
- fișa VM corelează porturile cu `processes[]` și afișează numele procesului, PID-ul și executabilul;
- secțiunea Firewall nu mai este limitată la UFW: afișează backend-uri, politici implicite, zone firewalld și reguli nftables/iptables/UFW/SuSEfirewall2;
- conturile locale cu UID 1000 și, în general, conturile marcate de agent ca non-system sunt incluse în fișă.

Nu există migrare SQL nouă și nu este necesară o versiune nouă de agent; `vm-doc-agent 1.6.1` rămâne versiunea recomandată.

Vezi `docs/UPGRADE-0.16.2.md`.

## Ce aduce versiunea 0.16.1

- UI mai compact pentru VM/Docker/DB/Web și contrast corect în dark mode;
- listă VM cu versiune agent, servicii agregate și filtru după serviciu;
- OS scurt, Power ON/OFF și fără coloana vCenter în tabelul VM;
- completare documentație dinamică pentru Docker, baze de date și Web;
- fără migrare SQL nouă.

## Ce aduce versiunea 0.16.0

- inventar structurat pentru Nginx, Apache HTTP Server și HAProxy primit de la `vm-doc-agent 1.6.0`;
- site-urile, virtual host-urile și frontend-urile sunt obiecte distincte și pot fi asociate many-to-many cu servicii interne, independent de VM-ul gazdă;
- tab nou **Web** în pagina VM și agregare **Site-uri web asociate** în pagina serviciului;
- fișele DOCX de VM și serviciu includ Web numai când există date; secțiunile Docker și Baze de date sunt de asemenea omise când nu există inventar relevant;
- numerotarea fișei VM este dinamică, astfel încât subsecțiunile inventarului rămân sub capitolul corect;
- controalele de asociere din taburile Docker, Baze de date și Web au spațiere și butoane mai clare;
- migrare nouă `031_web_inventory.up.sql`.

Vezi `docs/UPGRADE-0.16.0.md`.

## Ce aduce versiunea 0.15.0

- inventar structurat pentru baze de date detectate pe VM: PostgreSQL, MySQL, MariaDB, MongoDB, Oracle Database, Microsoft SQL Server, IBM Db2, Redis, Firebird și CockroachDB;
- separă engine-ul instalat, instanța de server și baza de date logică/catalogul;
- asocierea instanță → serviciu și bază logică → serviciu este many-to-many și independentă de VM → serviciu, pentru hosturi DB partajate;
- enumerarea bazelor logice este best-effort și fără credențiale: PostgreSQL, MySQL/MariaDB și MongoDB sunt interogate local numai când accesul existent permite acest lucru;
- nu colectează parole, connection strings, query-uri, date din tabele sau variabile de mediu arbitrare;
- tab nou **Baze de date** în pagina VM și agregare în pagina serviciului;
- fișa DOCX a VM-ului și fișa serviciului includ resursele DB asociate;
- migrare nouă `030_database_inventory.up.sql`; necesită `vm-doc-agent 1.5.0` pentru colectare.

Vezi `docs/UPGRADE-0.15.0.md`.

## Ce aduce versiunea 0.14.1

- importă și inventarul Docker cu status de collector `partial`, nu doar `success`;
- repară automat inventarul Docker structurat din snapshot-ul JSON curent dacă 0.14.0 l-a păstrat în istoric dar nu l-a normalizat;
- nu necesită migrare DB și nu necesită o versiune nouă de agent.

Vezi `docs/UPGRADE-0.14.1.md`.

## Ce aduce versiunea 0.14.0

- suport complet pentru inventar Docker primit de la `vm-doc-agent 1.4.0`;
- model relațional pentru engine, containere, Compose, imagini, rețele și volume;
- containerele de pe același VM pot aparține unor servicii interne complet diferite;
- un container poate aparține mai multor servicii; relația container → serviciu nu este dedusă automat din relația VM → serviciu;
- asociere manuală per container sau per proiect Compose și asociere automată opțională din Docker labels;
- tab Docker în pagina VM și secțiune Docker în pagina serviciului;
- datele Docker intră în fișa VM și în fișa serviciului;
- migrare `029_docker_inventory.up.sql`.

Vezi `docs/UPGRADE-0.14.0.md`.

## Ce aduce versiunea 0.13.4

- repară reconcilierea statusului de auto-update după restart: dacă agentul raportează versiunea țintă, starea cached `installing` devine imediat `current`;
- pagina Agenți reîmprospătează temporar lista după un Update forțat, astfel încât finalizarea să fie vizibilă fără refresh manual;
- fără migrare de bază de date și fără modificări necesare în vm-doc-agent 1.3.6.

## Ce aduce versiunea 0.13.3

- repară panic-ul `invalid memory address or nil pointer dereference` observat la refresh-ul statusului de update al agentului;
- `vm-doc-server` construiește acum `agentclient.Client` la pornire și îl transmite serviciului de colectare folosit de API/heartbeat;
- protecție suplimentară: apelurile printr-un client neinițializat întorc eroare controlată, fără oprirea serverului;
- păstrează `collector.allowed_networks`, verificarea TLS și limita de răspuns existente;
- fără migrare de bază de date; agenții existenți rămân compatibili.

Vezi `docs/UPGRADE-0.13.4.md`.

## Ce aduce versiunea 0.13.2

- în **Agenți → Listare agenți** apare butonul **Update**, care forțează imediat verificarea și instalarea unei versiuni mai noi fără a aștepta `updates.check_interval`;
- update-ul forțat folosește canalul configurat pe agent (`stable` sau `testing`);
- lista afișează canalul auto-update raportat de fiecare agent și permite filtrare/căutare după canal;
- starea auto-update este memorată în server pentru ca pagina cu sute de agenți să nu interogheze toate VM-urile la fiecare afișare;
- statusul este actualizat la Test/Colect/Update și, pentru agenții auto-înregistrați, periodic prin heartbeat;
- exportul Excel Agenți include canalul, `enabled`, `auto_install`, starea update-ului și versiunea disponibilă;
- migrarea `027_agent_update_status.up.sql`;
- funcția este compatibilă cu `vm-doc-agent 1.3.3`; nu este necesară o versiune nouă de agent.

Vezi `docs/UPGRADE-0.13.2.md` și `docs/AGENT-UPDATES.md`.

## Ce aduce versiunea 0.13.1

- modulul **Agenți** folosește navigare orizontală pentru a păstra lățimea utilă a tabelului;
- lista agenților afișează **OS-ul și versiunea OS raportate de inventarul curent**;
- căutarea agenților include numele/versiunea OS și nu mai reconstruiește formularul de căutare;
- acțiuni compacte `Test`, `Colect`, `Edit`, `Del`;
- export Excel al listei de agenți, respectând filtrele active;
- formularul **Adaugă release** este colapsat implicit;
- release-urile publicate au căutare, filtre, paginare și export Excel;
- valoarea implicită pentru toate paginările este **10**;
- fără migrare de bază de date; agentul 1.3.3 rămâne compatibil.

Vezi `docs/UPGRADE-0.13.1.md`.

## Ce aduce versiunea 0.20.23

- audit contextual în fișa VM și fișa Serviciului intern, cu filtre locale;
- etichete de resursă rezolvate la numele VM/containerului/DB/site-ului/documentului, păstrând ID-ul tehnic;
- corelare contextuală pentru Docker, DB, Web, software, modificări inventar, documente și anexe;
- raport **Persoane & responsabilități** cu filtre și export Excel;
- raport **Lipsuri operaționale** cu filtre și export Excel;
- fără migrare DB; agentul rămâne neschimbat.

Vezi `UPGRADE-0.20.23.md` și `docs/REPORTS.md`.

## Ce aduce versiunea 0.13.0

- retenție automată pentru `inventory_snapshots`: implicit maximum 30 snapshot-uri/agent și maximum 90 zile, cu protejarea inventarului curent și a snapshot-urilor folosite de documente generate;
- rapoarte pentru volumul inventarului, dimensiunea tabelului/indexurilor și top agenți după spațiul consumat;
- pagina **Audit** are paginare, căutare, filtre și explicații umane; pentru operațiile instrumentate se afișează valorile create, șterse sau diferențele before/after;
- model nou **Rețea externă → Sistem extern → Conexiune externă**;
- rețelele externe au culoare configurabilă, tip zonă, risc, trust, CIDR-uri, proprietar, descriere și observații de securitate;
- sistemele externe (VM/server/endpoint/serviciu de rețea) se asociază rețelelor externe și moștenesc clasificarea acestora;
- conexiunile externe păstrează sensul, serviciul, protocolul/portul, TLS, autentificarea și scopul și apar în VM, Serviciu intern, rapoarte și DOCX;
- migrarea `026_inventory_retention_audit_external_systems.up.sql`.

Vezi `docs/UPGRADE-0.13.0.md` și `docs/EXTERNAL-CONNECTIVITY.md`.

## Ce aduce versiunea 0.12.0

- pagina VM este împărțită în tab-uri sticky: **Rezumat, Servicii, Operațional, Inventar agent, Continuitate, Infrastructură și Istoric**; URL-ul păstrează secțiunea curentă;
- lista VM afișează procentul de **Completare fișă**, calculat din 11 criterii tehnice și operaționale esențiale; procentul este inclus și în exportul Excel;
- Rezumatul VM arată criteriile care mai trebuie completate;
- Nomenclatoarele au selectorul **Pe pagină** în zona de filtre, cu 10/20/50/100/200 și memorarea preferinței separat pentru fiecare nomenclator;
- pagina Agenți este împărțită în **Listare agenți** și **Release-uri agent**; publicarea unui release are propria secțiune;
- căutarea din lista Agenți actualizează numai tabelul, fără rerandarea întregii pagini, eliminând pierderea focusului la tastare;
- fără migrare MariaDB nouă.

Vezi `docs/UPGRADE-0.12.0.md`.

## Ce aduce versiunea 0.11.1

- publicare de release-uri `vm-doc-agent` direct din pagina **Agenți → Auto-update agent**;
- upload separat pentru binarul agent și `vm-doc-updater`, cu SHA-256 și actualizare atomică a manifestului;
- promovare `testing → stable` direct din UI;
- ștergere controlată a release-urilor; artifactele comune altui canal nu sunt șterse;
- pregătit pentru `vm-doc-agent 1.3.2`, care repară și întărește detecția versiunilor serviciilor.

Vezi `docs/UPGRADE-0.11.1.md` și `docs/AGENT-UPDATES.md`.

## Ce aduce versiunea 0.11.0

- filtrare după nume și stare în lista serviciilor systemd/Windows din pagina VM; implicit sunt afișate serviciile active;
- rutele de rețea sunt afișate tabelar;
- firewall-ul separă regulile explicite de regulile tehnice generate de backend-uri și ascunde implicit zgomotul iptables/nftables;
- pagina Rapoarte este împărțită în subcategorii;
- repository central de auto-update pentru `vm-doc-agent 1.3.0+`, cu `stable/testing`, SHA256 și rollback prin `vm-doc-updater`;
- pagina Agenți afișează versiunea raportată și release-urile publicate.

Vezi `docs/UPGRADE-0.11.0.md` și `docs/AGENT-UPDATES.md`.

## Ce aduce versiunea 0.10.0

- serviciile raportate de agent pot fi marcate persistent ca **Principale** direct din fișa VM;
- selecția rămâne valabilă între snapshoturi și semnalează explicit un serviciu principal care nu mai este detectat;
- fișa DOCX a VM-ului evidențiază separat componentele software principale și versiunile raportate de agent;
- fișa DOCX a Serviciului intern agregă automat componentele software principale ale tuturor VM-urilor sale;
- interfața inventarului agentului folosește etichete utile pentru liste: mount point, port, username, comandă și nume serviciu în loc de `Element 1`, `Element 2` etc.;
- uptime-ul este prezentat în ani/luni/zile/ore în loc de secunde;
- suport pentru metadatele opționale `software_name`, `version`, `package_name`, `package_version` și `version_source` furnizate de `vm-doc-agent 1.3.1+`;
- migrarea `025_vm_primary_agent_services.up.sql` adaugă selecțiile persistente ale serviciilor principale.

Vezi `docs/UPGRADE-0.10.0.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.9.1

- hotfix pentru dependențele directe VM → Serviciu comun;
- citire robustă a dependențelor VM pe MariaDB;
- logging explicit pentru erorile endpointului de dependențe VM;
- fără migrare de bază de date.

Vezi `docs/UPGRADE-0.9.1.md`.

## Ce aduce versiunea 0.9.0

- pagina **Agenți** are căutare după nume/URL/UUID/eroare, filtru de status și paginare configurabilă;
- pagina **Servicii interne** are filtre după domeniu, categorie, criticitate, status documentație și tip serviciu, iar descrierile lungi sunt scurtate în tabel;
- cardurile de sumar din pagina serviciului sunt compacte, iar **PROD / TEST-UAT / DEV** apar numai dacă există VM-uri în mediul respectiv;
- concept nou **Serviciu comun / infrastructură partajată**, pentru AD, DNS, OpenLDAP, NTP, PKI, SMTP relay, proxy, logging, monitoring, backup, storage și alte servicii comune;
- un serviciu comun poate fi **global implicit** pentru toate serviciile sau poate fi asociat explicit numai serviciilor care îl folosesc;
- nomenclator nou **Tip dependență** și relații `Serviciu → Serviciu comun`;
- sunt suportate și **dependențe directe pe VM** pentru excepțiile tehnice care nu trebuie moștenite de tot serviciul;
- pagina VM afișează dependențele comune moștenite, globale și directe, inclusiv VM-urile care furnizează serviciul comun;
- pagina și schema Serviciului intern afișează infrastructura comună separat de VM-urile proprii, fără duplicarea acestora;
- fișele DOCX VM și Serviciu includ dependențele comune, furnizorii și proveniența relației; fișa unui serviciu comun include și analiza de impact asupra serviciilor dependente;
- modulul **Rapoarte** include servicii comune/globale, tipuri de dependență și analize de impact pe servicii și VM-uri.

Vezi `docs/UPGRADE-0.9.0.md`, `docs/SERVICE-CATALOG.md`, `docs/SERVICE-DIAGRAM.md`, `docs/DOCUMENT-GENERATION.md` și `docs/REPORTS.md`.


## Ce aduce versiunea 0.8.0

- mediul fiecărui VM este evidențiat în Serviciul intern și în fișa DOCX, cu grupare **PROD / TEST-UAT / DEV / alte medii**;
- fiecare VM asociat afișează ultima fișă tehnică generată, cu link direct către document;
- la generarea fișei serviciului se poate activa **Include fișele VM ca anexe**; aplicația reutilizează ultima fișă sau generează automat una dacă lipsește;
- opțiunea **Regenerează fișele VM înainte de anexare** produce un snapshot complet nou al documentației;
- pachetul ZIP al serviciului conține DOCX-ul principal și anexele VM exacte fixate la momentul generării;
- meniul **Rapoarte** oferă indicatori și grafice fără dependențe JavaScript externe: donut/pie, bare și timeline;
- rapoartele acoperă infrastructura VM, mediile, resursele, inventarul, agenții, backup-ul, serviciile, clasificarea, rolurile și gradul de documentare.

Vezi `docs/UPGRADE-0.8.0.md`, `docs/REPORTS.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.7.3

- corectează focusul editorului rich-text pentru **Scop și domeniu** și **Obiective**;
- zona `contenteditable` nu mai este învelită într-un element `<label>`, astfel încât clickul în editor nu mai selectează butonul **Bold**;
- adaugă etichete accesibile prin `aria-labelledby` și focus explicit prin `tabindex=0`;
- nu introduce migrare MariaDB și nu modifică datele existente.

## Ce aduce versiunea 0.7.2

- **Scop și domeniu** și **Obiective** folosesc acum editor rich-text direct în aplicație;
- editorul suportă paragrafe, rânduri noi, **bold**, *italic*, underline, liste cu bullets, liste numerotate și indentare;
- formatarea este stocată într-un format JSON restricționat, fără HTML executabil;
- câmpurile plain-text `purpose` și `objectives` sunt păstrate și sincronizate automat pentru compatibilitate API și placeholdere;
- fișa DOCX reproduce formatarea rich-text: stilurile de text, bullets, numerotarea și nivelurile de indentare;
- datele vechi plain-text sunt convertite automat în editor la citire, fără pierderea conținutului;
- migrarea `022_service_rich_text.up.sql` adaugă numai coloanele de formatare, fără să modifice valorile existente.

Vezi `docs/UPGRADE-0.7.2.md`, `docs/SERVICE-CATALOG.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.7.1

- serviciul intern are acum câmpurile narative **Scop și domeniu** și **Obiective**, afișate în carduri aerisite în pagina serviciului;
- valoarea tehnică `purpose` este păstrată pentru compatibilitate, dar în UI și documentație reprezintă **Scop și domeniu**;
- fișa DOCX a serviciului include automat Scop și domeniu, Obiective și **Schema logică a serviciului**;
- schema DOCX este construită din aceleași asocieri VM ca schema din interfață; un VM apare o singură dată chiar dacă are mai multe roluri;
- VM-urile multi-role / multi-layer păstrează toate asocierile în același nod, grupate într-o zonă **Multi-layer**;
- placeholdere noi pentru șabloane: `{{service.scope_domain}}` și `{{service.objectives}}`;
- migrarea `021_service_scope_objectives_docx_diagram.up.sql` adaugă numai coloana `objectives`; câmpul `purpose` existent este reutilizat fără pierdere de date.

Vezi `docs/UPGRADE-0.7.1.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.7.0

- schemă logică automată pe pagina fiecărui **Serviciu intern**, construită exclusiv din asocierile VM;
- fiecare VM apare **o singură dată** în schemă, chiar dacă are două sau mai multe asocieri pentru același serviciu;
- VM-urile cu un singur layer sunt grupate pe layer, iar cele cu roluri în mai multe layere apar în zona **Multi-layer**;
- fiecare nod VM afișează toate rolurile tehnice, layer-ele, tipurile de soluție și încadrarea Domeniu/Categorie;
- câmp nou `icon_key` pe valorile nomenclatoarelor, editabil din interfață și exportat în Excel;
- pictograme implicite pentru Domeniu, Categorie, Layer, Rol tehnic și Tip soluție, cu mapări mai expresive pentru aplicație, baze de date, web/proxy, integrare, monitorizare și securitate;
- migrarea `020_service_diagram_icons.up.sql` extinde nomenclatoarele fără a modifica asocierile existente.

Vezi `docs/UPGRADE-0.7.0.md` și `docs/SERVICE-DIAGRAM.md`.

## Ce aduce versiunea 0.6.0

- nomenclator nou **Tip soluție**, cu valorile inițiale **Open source**, **Dezvoltată intern** și **Comercială**;
- tipul soluției se salvează pe fiecare asociere `VM → Serviciu intern → Layer → Rol tehnic`;
- fișa VM afișează asocierile cu serviciile în carduri separate și mai aerisite: Clasificare serviciu, Arhitectură tehnică și Context;
- pagina Serviciului intern agregă automat domeniile/categoriile, tipurile de soluție, layer-ele/rolurile și VM-urile;
- generare DOCX și pentru **Serviciu intern**, cu previzualizare, număr `FSI-*`, SHA-256 și istoric;
- șabloanele DOCX sunt tipizate `vm` sau `service`, cu câte un șablon implicit pentru fiecare tip;
- migrarea `019_service_documents_solution_type.up.sql` extinde asocierile, șabloanele și istoricul documentelor.

Vezi `docs/UPGRADE-0.6.0.md`, `docs/SERVICE-CATALOG.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.5.1

- fișa DOCX folosește un inventar agent compact, cu tabele dedicate în locul listării brute a JSON-ului;
- secțiunile Agent și Proxy sunt eliminate din document, iar `uptime_seconds` nu mai este afișat;
- stocarea este afișată pe partiție, filesystem și capacitate umanizată în GB/TB;
- rețeaua, serviciile active, porturile, regulile UFW, conturile importante, SSSD, integrările, cron și NTP au tabele minimaliste;
- serviciile inactive, conturile de sistem neimportante și regulile firewall care nu provin din `ufw status numbered` sunt omise;
- tabelele DOCX au acum `w:tblGrid`, lățimi fixe și rânduri care nu se rup, pentru randare stabilă în Word și LibreOffice;
- actualizarea nu introduce migrare MariaDB.

Vezi `docs/UPGRADE-0.5.1.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.5.0

- generează fișa tehnică a unui VM în format DOCX, direct din pagina VM-ului;
- include datele vCenter, încadrarea operațională, servicii și roluri, responsabilități, backup și inventarul curent al agentului;
- previzualizare înainte de generare, cu avertismente pentru datele lipsă;
- șabloane DOCX administrabile din meniul **Documente**;
- șablon implicit creat automat la prima pornire după migrare;
- șabloanele personalizate folosesc placeholderul obligatoriu `{{VM_DOCUMENT_BODY}}` și placeholdere scalare pentru antet;
- istoric per VM, număr unic de document, autor, dată, snapshot sursă, SHA-256 și descărcare ulterioară;
- permisiuni RBAC separate: `documents.read` și `documents.manage`;
- migrarea `018_document_generation.up.sql` creează tabelele pentru șabloane și documentele generate.

Vezi `docs/UPGRADE-0.5.0.md` și `docs/DOCUMENT-GENERATION.md`.


## Ce aduce versiunea 0.4.4

- toate nomenclatoarele sunt afișate în ordinea ierarhică: ordinea părintelui, apoi ordinea proprie și denumirea;
- categoriile de serviciu urmează ordinea domeniilor, iar rolurile tehnice urmează ordinea layer-elor;
- fiecare pagină de nomenclator are căutare text și filtru de stare;
- categoriile de serviciu pot fi filtrate după domeniu, iar rolurile tehnice după layer;
- Persoanele pot fi filtrate după departament, sursă și stare;
- paginarea lucrează pe rezultatele filtrate, iar exportul Excel rămâne complet și folosește aceeași ordine;
- versiunea nu necesită migrare MariaDB.

Vezi `docs/UPGRADE-0.4.4.md`.

## Ce aduce versiunea 0.4.3

- toate listele din **Nomenclatoare**, inclusiv **Persoane**, au paginare cu 10, 20, 50 sau 100 de rânduri pe pagină;
- fiecare nomenclator are export Excel `.xlsx`, cu toate valorile active și inactive, indiferent de pagina afișată;
- exportul păstrează relațiile specifice: domeniul părinte pentru categoriile de serviciu și layer-ele permise pentru rolurile tehnice;
- exportul Persoane include departamentul, datele de contact, sursa și utilizatorul AD;
- actualizarea nu introduce migrare MariaDB.

Vezi `docs/UPGRADE-0.4.3.md`.

## Ce aduce versiunea 0.4.2

- corectează încărcarea inventarului curent din fișa VM; interogarea după `current_inventory_id` transmite acum identificatorul către MariaDB;
- elimină eroarea SQL `Error 1064 ... near '?' at line 1` și avertismentul „Fișa a fost încărcată parțial”;
- JSON-ul agentului nu este modificat și nu este necesară recollectarea inventarului;
- actualizarea nu introduce migrare MariaDB.

Vezi `docs/UPGRADE-0.4.2.md`.

## Ce aduce versiunea 0.4.1

- denumirea din interfață este **Categorie de serviciu**; identificatorul intern `itil_category` este păstrat pentru compatibilitate cu baza și API-ul;
- pagina **Nomenclatoare → Persoane** poate interoga Active Directory folosind configurația LDAP existentă;
- utilizatorii sunt citiți recursiv dintr-un OU rădăcină configurabil și sunt afișați arborescent după sub-OU-uri;
- lista este filtrată după atributul AD `department`; implicit este ales primul departament în ordine alfabetică, dacă `default_department` nu este configurat;
- utilizatorii selectați sunt importați sau actualizați în registrul local de persoane și devin disponibili în responsabilitățile VM;
- migrarea `016` include corecția ordinii indexurilor, iar migrarea `017` adaugă identitatea de director pentru persoane.

Vezi `docs/UPGRADE-0.4.1.md` și `docs/CONFIGURATION.md`.

## Ce aduce versiunea 0.4.0

- domeniul arhitectural și categoria de serviciu se selectează pe fiecare asociere din fișa VM;
- serviciul intern nu mai are domeniu sau categorie configurate manual;
- pagina Servicii agregă automat toate combinațiile `Domeniu → Categorie de serviciu` observate pe VM-urile asociate;
- un serviciu poate apărea în mai multe domenii sau categorii, fără duplicarea serviciului în catalog;
- fișa VM folosește cascada `Domeniu → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- backendul validează relația categorie–domeniu și relația rol–layer;
- migrarea `016_vm_service_classification.up.sql` copiază încadrarea existentă pe asocierile VM, fără pierderea datelor.

Vezi `docs/UPGRADE-0.4.0.md` și `docs/SERVICE-CATALOG.md`.

## Ce aduce versiunea 0.3.9

- pagina **Nomenclatoare** folosește un submeniu lateral și afișează o singură listă la un moment dat;
- opțiunile sunt grupate în **Catalog servicii**, **Arhitectură tehnică**, **Operare VM** și **Responsabilități**;
- fiecare opțiune afișează numărul de valori și are o rută proprie, păstrată la reîncărcarea paginii;
- pe ecrane mici, submeniul se transformă într-o grilă adaptivă;
- nu există modificări de bază de date.

Vezi `docs/UPGRADE-0.3.9.md`.

## Ce aduce versiunea 0.3.8

- selecția funcțională se face exclusiv pe fișa VM în cascada `Domeniu arhitectural → Serviciu intern → Layer → Rol tehnic`;
- domeniul filtrează serviciile, iar layer-ul filtrează rolurile tehnice permise global;
- serviciul intern nu mai configurează combinații layer–rol; pagina serviciului le agregă automat din VM-urile asociate;
- backendul validează numai existența serviciului și relația globală `Layer → Rol tehnic`;
- la adăugarea sau editarea unui rol tehnic, layer-ele se aleg dintr-un selector multiplu cu căutare, complet offline;
- rolurile tehnice sunt afișate după ordinea layer-ului, apoi după ordinea rolului în layer;
- versiunea nu introduce o migrare de schemă; tabelul vechi de configurare pe serviciu rămâne doar pentru compatibilitatea revenirii la 0.3.7 și nu mai este utilizat.

Vezi `docs/UPGRADE-0.3.8.md`.

## Ce aduce versiunea 0.3.7

- fiecare rol tehnic este legat de unul sau mai multe layer-e arhitecturale;
- în Nomenclatoare, rolul tehnic se editează împreună cu layer-ele permise;
- în pagina Serviciului intern, lista de roluri este filtrată după layer;
- backendul respinge orice combinație layer–rol care nu este definită global;
- perechile deja folosite sunt migrate automat și nu pot fi eliminate cât timp sunt utilizate.

Vezi `docs/UPGRADE-0.3.7.md`.

## Ce aduce versiunea 0.3.6

- un VM poate avea mai multe servicii interne asociate;
- același serviciu poate avea pe același VM mai multe combinații `Layer arhitectural → Rol tehnic`;
- fiecare asociere poate fi dedicată, partajată sau dependență și poate fi marcată drept principală;
- serviciul, layer-ul și rolul nu mai sunt câmpuri unice în formularul operațional;
- profilul și data provisionării sunt eliminate din modelul funcțional și din nomenclatoare;
- lifecycle-ul local `Retired` nu mai este expus în interfață/API; valorile existente sunt migrate la `Status operațional: Retras`;
- cardul redundant „Rezumat ultimul inventar” este eliminat; rămân ultimul inventar, datele agentului și istoricul paginat.

Vezi `docs/SERVICE-CATALOG.md` și `docs/UPGRADE-0.3.6.md`.

## Ce aduce versiunea 0.3.5

- corectează încărcarea fișei VM: erorile din datele operaționale sau backup nu mai blochează întreaga pagină;
- jurnalizează explicit toate etapele endpointului `GET /api/v1/vms/{id}` (`vm`, `operational`, `backup`, `agent`, `inventory`, `inventory_document`);
- afișează dinamic versiunea reală raportată de endpointul `/version`, eliminând eticheta hard-codată `0.3.2`.

## Ce aduce versiunea 0.3.4

- fișa VM nu mai cade complet dacă agentul sau inventarul curent au date inconsistente;
- erorile opționale sunt jurnalizate și afișate ca avertismente în interfață.

## Ce aduce versiunea 0.3.3

- datele detaliate colectate de agent sunt restrânse implicit;
- istoricul inventarelor și evenimentele de audit sunt paginate;

- meniu principal **Servicii**, separat de nomenclatoare;
- `Serviciu` ITIL este redenumit **Categorie de serviciu**, iar vechea `Componentă` devine **Serviciu intern**;
- încadrare strictă și selecție în cascadă: `Domeniu arhitectural → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- fiecare categorie de serviciu este legată de un domeniu arhitectural;
- fiecare serviciu intern definește combinațiile layer–rol permise;
- pagina serviciului centralizează informațiile serviciului, VM-urile asociate și pregătește unitatea viitoare de documentare DOCX/PDF;
- validare identică în browser și în API, astfel încât combinațiile incompatibile nu pot fi salvate;
- migrarea `013_internal_service_catalog.up.sql` păstrează și convertește datele existente.

Vezi `docs/SERVICE-CATALOG.md` și `docs/UPGRADE-0.3.3.md`.

## Ce aduce versiunea 0.3.1

- meniu administrativ **Nomenclatoare** cu liste controlate pentru încadrarea VM-urilor;
- serviciu, componentă, domeniu arhitectural, layer, mediu, status operațional, profil de provisionare și clasificare sunt selectate din list-box-uri;
- registru de persoane și responsabilități multiple pe VM;
- politica de backup este scoasă din formularul operațional și afișată într-o secțiune separată, pregătită pentru datele Veeam API;
- valorile text și responsabilitățile existente sunt migrate automat la prima pornire.

## Ce aduce versiunea 0.3.0

- fișa tehnică a VM-ului este afișată pe carduri și secțiuni, nu doar ca JSON brut;
- inventarul agentului este transformat într-o vedere structurată și ordonată pentru sistem, rețea, stocare, servicii, porturi, firewall, SSSD, integrări, politici și NTP;
- câmpurile care pot conține parole, tokenuri, secrete sau chei private sunt mascate în vederea structurată;
- date operaționale editabile, păstrate separat de snapshoturile agentului: serviciu, componentă, domeniu arhitectural, layer, mediu, status, scop, responsabili, profil/data provisionării, RPO/RTO, backup, clasificare, documentație, tichet și observații;
- migrarea `011_vm_operational_metadata.up.sql` și audit pentru modificarea datelor operaționale;
- endpoint nou `PUT /api/v1/vms/{id}/operational` și OpenAPI actualizat;
- interfață adaptivă, cu secțiuni pliabile și afișare ierarhică a listelor și obiectelor colectate.

## Ce aduce versiunea 0.2.2

- căutare VM în nume, hostname, power state, sistem de operare, IP, agent și sursă vCenter;
- filtre distincte pentru power, stare agent, `Retired` și sursă;
- paginare server-side cu 25, 50, 100 sau 200 de înregistrări pe pagină;
- statistici calculate pentru rezultatul filtrat;
- export Excel real `.xlsx`, cu aceleași filtre, antet fix, auto-filter și lățimi de coloane;
- corectarea antetului tabelului VM, care nu mai acoperă primul rând;
- răspunsuri `[]` pentru listele vCenter goale și corecția conflictului rutelor Swagger din Go 1.23.

## Ce aduce versiunea 0.2.0

- surse vCenter multiple, cu credențiale criptate individual;
- importul tuturor VM-urilor vizibile prin API-ul vCenter;
- buton de sincronizare manuală și sincronizare automată zilnică;
- istoric pentru fiecare rulare vCenter: găsite, adăugate, actualizate, lipsă și agenți asociați;
- câmp local `Retired`, notă și audit, păstrate la sincronizările ulterioare;
- VM-urile care dispar din vCenter sunt marcate `missing`, nu șterse automat;
- asociere automată VM–agent după BIOS/DMI UUID și asociere manuală din interfață;
- stare agent, ultimul contact, ultima colectare și butoane **Testează** / **Sincronizează acum** în fișa VM;
- parser corect pentru schema agentului 2.0: `agent.id`, `agent.version`, `collection.collectors` și câmpurile de corelare VMware;
- API/OpenAPI și interfață actualizate.

## Componente

- `vm-doc-server`: API, frontend, autentificare, RBAC, audit și scheduler vCenter;
- `vm-doc-collector`: coadă persistentă și interogarea agenților;
- MariaDB: surse vCenter, VM-uri, status operațional, asocieri multiple cu servicii, joburi și snapshoturi JSON.

Serverul web contactează vCenter. Numai `vm-doc-collector` contactează agenții.

## Compilare

Necesită Go 1.23 sau mai nou și modulele declarate în `go.mod`.

```bash
make test
make build
```

Binarele sunt generate în `bin/`.

Pentru un server fără internet, pregătiți pe o stație conectată un pachet cu `vendor/`:

```bash
go mod download
go mod vendor
go test -mod=vendor ./...
```

Apoi transferați întregul director al proiectului și compilați cu:

```bash
CGO_ENABLED=0 go build -mod=vendor -trimpath -o bin/vm-doc-server ./cmd/vm-doc-server
CGO_ENABLED=0 go build -mod=vendor -trimpath -o bin/vm-doc-collector ./cmd/vm-doc-collector
```

## Instalare și upgrade

Instalarea inițială rămâne aceeași ca în 0.1.0. La prima pornire, migrațiile sunt aplicate automat. Versiunea 0.4.1 aplică migrarea `017_service_category_ad_directory.up.sql`, păstrează compatibilitatea cu identificatorul `itil_category` și corectează reluarea sigură a migrării `016_vm_service_classification.up.sql`.

Pentru upgrade:

1. faceți backup la baza MariaDB și la configurație;
2. opriți `vm-doc-server` și `vm-doc-collector`;
3. înlocuiți binarele și fișierele web incluse în binar;
4. păstrați `version: 1` în `config.yaml` și adăugați secțiunea opțională `vcenter`;
5. porniți mai întâi serverul, apoi collectorul;
6. adăugați sursa vCenter din pagina **VM-uri** și porniți prima sincronizare.

Pentru actualizarea curentă consultați `docs/UPGRADE-0.4.1.md`. Pentru instalarea vCenter consultați și `docs/UPGRADE-0.2.0.md` și `docs/VCENTER.md`.

## API

- document OpenAPI: `/api/openapi.yaml`;
- Swagger UI: `/docs/`;
- health: `/healthz`;
- readiness: `/readyz`;
- versiune: `/version`.

## Securitate

- parolele vCenter și tokenurile agenților sunt criptate AES-256-GCM înainte de salvarea în MariaDB;
- API-ul nu returnează secretele;
- `verify_tls` trebuie menținut activ în producție;
- contul vCenter trebuie să fie dedicat și limitat la operațiile de inventariere necesare;
- modificările datelor operaționale, asocierilor multiple și sincronizările manuale sunt auditate.

## Limitări cunoscute

- custom attributes generale din vCenter nu sunt încă importate; statusul operațional este administrat local din nomenclator;
- operația REST `GET /api/vcenter/vm` returnează maximum 4.000 de VM-uri per sursă; pentru inventare mai mari este necesară împărțirea sursei sau o sincronizare filtrată într-o versiune ulterioară;
- exportul bulk DOCX/PDF este disponibil din 0.20.27; PDF-ul se convertește on-demand cu LibreOffice/soffice, însă PDF-urile nu sunt încă păstrate ca versiuni separate în istoricul `generated_documents`; retenția automată rămâne o direcție ulterioară;
- arhiva sursă standard nu conține dependențe vendorizate.


## Export în masă DOCX / PDF · 0.20.29

În **Documente → Export în masă** sunt disponibile cele patru arhive: VM-uri DOCX, VM-uri PDF, Proiecte DOCX și Proiecte PDF. Pentru DOCX, exportul VM are **Doar VM-uri pornite** bifat implicit; debifarea include toate VM-urile active/neretrase. Regenerarea VM este opțională și se aplică doar VM-urilor selectate.

Pentru Proiecte DOCX sunt disponibile trei opțiuni, toate implicit debifate: **Regenerează toate fișele proiectelor înainte de export**, **Generează fișa proiectului dacă nu există** și **Include și fișele VM asociate proiectelor**. Regenerarea are prioritate față de generarea doar a fișelor lipsă. Documentele generate/regenerate de bulk nu afișează `Generat de`.

Arhivele conțin fișierele individuale plus `_manifest.csv`, `_sumar.txt` și `_README.txt`. Exporturile PDF rămân neschimbate în 0.20.29: serverul caută `soffice` sau `libreoffice` în `PATH`, sau folosește `VM_DOC_SOFFICE_BIN`.

## Autoînregistrarea agenților

Versiunea 0.2.2 lucrează cu `vm-doc-agent 1.1.0` și creează automat agenții, primește heartbeat și inventarul push. Vezi `docs/AGENT-REGISTRATION.md`.


## Fișa serviciului pe taburi · 0.19.7

Pagina unui serviciu este împărțită în Rezumat, Detalii, Arhitectură, Componente, Dependențe și Documentație. Arhitectură, Componente și Dependențe folosesc subtabs. Tabul Detalii expune toate datele administrate ale serviciului și păstrează acțiunea de editare în context. Hash-urile `#services/<id>/<tab>` permit navigare directă și revenire pe secțiunea curentă după editare.


## Editare serviciu în fișă și filtre noi · 0.19.8

- butonul **Editează** din catalog deschide fișa serviciului, nu formularul modal;
- zona **Detalii** conține subtabs **General**, **Descriere**, **Scop și domeniu** și **Obiective**;
- fiecare subtab poate fi modificat și salvat direct, similar datelor operaționale din fișa VM;
- dialogul vechi este folosit doar la **Adaugă serviciu**;
- catalogul Servicii folosește un shell de filtre responsive, pe același model cu Inventar VM, cu listbox-uri searchable, filtre active și buton Reset separat;
- nu există migrare DB și nu este necesar upgrade de agent/collector.


## PostgreSQL multi-instance și joburi programate · 0.19.14

Cu vm-doc-agent 1.6.10, fiecare instanță PostgreSQL este documentată separat după port/data directory/socket. În **VM → Baze de date**, serverul afișează și metadata joburilor `pgAgent` / `pg_cron`: identificator/nume, programare, DB/user, stare și timpi disponibili. SQL-ul, comenzile și pașii/scripturile joburilor nu sunt stocate. Fișa VM și fișa serviciului folosesc aceeași metadata. Migrare DB: `044_database_scheduled_jobs.up.sql`.


## Outline · Virtualizare · 0.20.31

Publicarea automată în Outline este separată de proiectele VM-DOC. În **Documente → Outline** se configurează conexiunea și `Document ID` al paginii Outline **Virtualizare**. Toate fișele VM sunt publicate direct sub acest document:

```text
Virtualizare
├── VM — lis-app01
├── VM — lis-db01
└── VM — lis-worker01
```

Butonul **Trimite în Outline** din fișa VM folosește direct ținta Virtualizare și nu mai cere proiectul. Publicarea în masă procesează VM-urile direct și poate fi limitată la `POWERED_ON`. Mapping-ul este unic per VM pentru ținta `virtualization`, astfel încât o VM asociată mai multor servicii nu produce duplicate.

Proiectele/serviciile nu mai sunt publicate automat. Pentru ele se poate folosi câmpul existent **Link documentație** din Detalii pentru a indica pagina Outline organizată manual.

Modelul DB introduce `outline_targets`, astfel încât viitoare categorii (de exemplu Echipamente, Baze de date sau altă structură wiki) să poată avea propriul document părinte fără a fi forțate sub Virtualizare. Dacă ID-ul părintelui Virtualizare este schimbat, VM-DOC mută paginile VM deja mapate la noul părinte la următoarea publicare.

Migrarea este `057_outline_virtualization_target.up.sql`. Tabelele vechi din 0.20.30 sunt păstrate pentru compatibilitate/istoric, dar noua publicare VM folosește mapping-ul global `outline_vm_documents_global`.

## Integrare Outline · 0.20.30

Pagina **Documente** conține acum configurarea Outline și publicarea în masă. Cheia API este criptată cu cheia master VM-DOC și nu este returnată către browser după salvare. Pentru autentificarea API este suficient API key-ul Outline; username/parola nu sunt folosite de integrare.

Structura publicată este:

```text
Colecție Outline / document părinte opțional
└── Proiect — Nume serviciu
    ├── VM — vm01
    ├── VM — vm02
    └── ...
```

Publicarea este de tip **upsert**: la prima rulare documentele sunt create, iar la rulările următoare aceleași pagini sunt actualizate pe baza mapping-urilor persistente din DB. Dacă o pagină mapată a fost ștearsă din Outline, VM-DOC o recreează la următoarea publicare.

Butonul **Trimite în Outline** apare în Documentația proiectului și în Documentația VM. Pentru o VM asociată mai multor proiecte se alege proiectul sub care va fi publicată pagina. Din **Documente → Outline** se poate porni un job asincron pentru toate proiectele, opțional cu VM-urile lor; implicit sunt bifate **Include fișele VM** și **Doar VM-uri pornite**.

Conținutul trimis este Markdown generat din modelul curent de documentație VM-DOC, fără rândul vizibil **Generat de**. Dacă există deja o fișă DOCX generată pentru obiect, numărul electronic și data de referință ale ultimei fișe sunt reutilizate în pagina Outline.

Migrarea `056_outline_integration.up.sql` creează setările criptate și mapping-urile Outline pentru proiecte și VM-uri. Agentul nu se modifică.
