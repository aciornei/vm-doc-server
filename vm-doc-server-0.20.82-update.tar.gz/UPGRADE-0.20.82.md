# Upgrade VM-DOC Server 0.20.81 → 0.20.82

0.20.82 modifică publicarea VM-urilor în Outline. Nu există migrare DB și nu este necesar update de agent.

## Modificări

- titlul paginii Outline devine `vm-<nume VM>`;
- bulk publish din **Documente → Publică în Outline → VM-uri** publică numai `PROD`;
- TEST / DEV / mediu nespecificat sunt sărite și afișate cu motiv;
- VM-urile PROD marcate `Nu se publică în Outline` sunt sărite și afișate în aceeași listă;
- `Doar VM-uri pornite` continuă să limiteze candidatele înaintea filtrului de mediu;
- publicarea individuală din fișa VM rămâne permisă pentru orice mediu, dar folosește titlul `vm-...`.

## Upgrade offline

```bash
systemctl stop vm-doc-server
cp -a /usr/local/src/vm-doc-server-0.20.81 /usr/local/src/vm-doc-server-0.20.82
tar -xzf vm-doc-server-0.20.82-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.82
cd /usr/local/src/vm-doc-server-0.20.82
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
systemctl start vm-doc-server
```

După restart fă `Ctrl+F5` în browser.

## Verificare

1. Deschide **Documente → Publică în Outline**.
2. Publică VM-urile cu `Doar VM-uri pornite` bifat.
3. Confirmă că numai VM-urile `PROD` sunt publicate.
4. Confirmă că TEST/DEV/fără mediu apar în tabelul **VM-uri sărite**.
5. Confirmă că o pagină VM publicată/actualizată în Outline are titlul `vm-<nume>`.
