# VM-DOC Server 0.21.33 — 2026-10-15

## Schimbări
- Review (conturi relevante, principalii DB, Web ACL, firewall și rapoarte): ordine fixă **Revizuit / De către / Next review / Revizuiește**.
- Dialog pentru Revizuiește, fără prompt/confirm: interval 6/12 luni, decizie justificată Da/Nu obligatorie, observații. Serverul stabilește revizorul și data.
- Fișă VM → Securitate → Conturi system: la extindere apare direct tabelul fără bifă intermediară; fără Review pentru conturile system.

## Compatibilitate și upgrade
- Bază: **0.21.32**; Agent modern **1.7.18** fără schimbări.
- **Fără migrare SQL nouă**, fără schimbări de endpoint ori modele API.
- Aplică update-ul peste o copie curată a surselor 0.21.32, cu `vendor/` original păstrat, apoi verifică înainte de instalarea binarului:
  `GOPROXY=off GOFLAGS=-mod=vendor go test ./...`
  `GOPROXY=off GOFLAGS=-mod=vendor make build`
- După reușita build-ului, actualizează binarul prin procedura ta de instalare, repornește serviciul și folosește Ctrl+F5.
- Rollback: păstrează binarul 0.21.32, sursele și backup-ul DB; fiind un update strict UI nu sunt necesare schimbări de date pentru revenire.

## Verificări și limite
- JS `node --check`; Go: openapi, web, internal/buildinfo, internal/domain, internal/xlsx, migrations — trecute.
- Chromium la 1595/1024/390 cu API simulat: dialog, selecții, note, submit/cancel, câmp obligatoriu și absența prompt/confirm — trecute.
- **Nu** s-a validat build-ul complet cu dependențe Go/vendor sau salvarea reală în MariaDB; testează în staging.
