# VM-DOC Server 0.21.87 — Modificări / Timeline / Ghid (UI)

**Bază:** 0.21.86. **Data:** 2026-10-23. **Agent:** 1.7.18, neschimbat.

## Modificări
- Global → Modificări: panoul și tabelul folosesc lățimea completă disponibilă din pagină. Nu se modifică filtrarea semantică sau căutarea.
- De documentat global și VM: paginare existentă, pe server (10/20/50/100 rânduri); rândul Resursă afișează prioritar numele, cu tipul `(VM)` / `(Serviciu)` lângă acesta, iar numele VM-ului rămâne ca informație secundară pentru servicii. Căutarea, filtrele, exportul Excel și operațiile bulk sunt păstrate.
- VM → Timeline: data **și ora** sunt afișate exclusiv în coloana din stânga axei, pe fiecare eveniment. A fost eliminată data din dreapta cardului și antetul redundant `Istoricul reviziilor`. Switchul `Include evenimentele ignorate` este acum în headerul panoului, lângă `Timeline`, fără chenar sau fundal. Explicația de jos are margini proprii și descrie data afișată.
- VM → Modificări: tabel responsiv cu lățime 100%, fără scroll orizontal jos. Pe lățimi mai mici, fiecare modificare folosește un aranjament pe mai multe rânduri cu aceleași câmpuri și acțiuni, inclusiv selectarea și salvarea bulk. Nu sunt eliminate coloane sau funcții.
- Ghid global și VM: aceeași componentă, introdusă cu margini interioare, fără cardul `Cum lucrezi cu modificările`; fluxul Detectează → Revizuiește → Documentează rămâne vizibil într-o formă mai simplă, urmat de explicațiile pentru Documentație și Baseline.

## Compatibilitate și limite
- **Fără migrare SQL**, modificare API sau colector. Nu se șterg snapshoturi, evenimente sau baseline-uri.
- Reactivarea fluxurilor Modificări/Documentație și exportul XLSX pe date reale necesită verificare în staging pe MariaDB.
- Build-ul complet Go nu a putut rula în acest mediu fără `vendor/`. Testele unitare care nu au nevoie de modulele externe au trecut.
- Fixul de scroll este testat în Chromium cu date demonstrative, inclusiv la 600/760/880/1024/1280/1440 px; alte teme/fonturi/zoomuri trebuie validate în browserul din producție.
