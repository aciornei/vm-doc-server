# Upgrade VM-DOC Server 0.21.86 → 0.21.87

1. Păstrează o copie a surselor, binarului și configurației curente; realizează backup MariaDB.
2. Oprește serviciul VM-DOC și aplică `vm-doc-server-0.21.86-to-0.21.87-update.tar.gz` în rădăcina **exactă** a surselor 0.21.86 sau înlocuiește cu `vm-doc-server-0.21.87-source.zip`.
3. Verifică structura: `bash scripts/cleanup-source-tree.sh --check`.
4. Compilează offline: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build` folosind `vendor/` complet din mediul tău.
5. Instalează noul binar în calea exactă din `systemctl cat vm-doc-server`, apoi pornește serviciul.
6. Verifică în browser `app.js?v=0.21.87` și `app.css?v=0.21.87`.
7. Global → Modificări: tabelul ocupă întregul panou. Global → De documentat: paginare (10/20/50/100), numele și tipul resursei, căutare și Excel.
8. VM → Modificări: test fără scroll orizontal, selecție și salvare bulk, inclusiv la lățimi mici.
9. VM → Timeline: un singur timestamp pe fiecare eveniment în stânga, Include ignorate în header; navigare/paginare.
10. Ghid global și VM: explicații identice cu margini, fluxul de lucru prezentat fără card suplimentar.

**Rollback:** reinstalează binarul/sursele 0.21.86. Nu există migrare SQL nouă, baza este compatibilă. JavaScript/CSS sunt embed în binarul Go, deci trebuie recompilat. Agentul rămâne 1.7.18.
