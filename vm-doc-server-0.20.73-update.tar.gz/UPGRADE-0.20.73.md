# Upgrade VM-DOC Server 0.20.72 → 0.20.73

0.20.73 adaugă review-ul de securitate pentru regulile FortiGate corelate cu VM-urile și le include în calendarul central de revizii.

Nu există migrare DB nouă. Este reutilizată tabela `security_reviews`. Agentul rămâne 1.7.12.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.72 /usr/local/src/vm-doc-server-0.20.73
tar -xzf vm-doc-server-0.20.73-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.73
cd /usr/local/src/vm-doc-server-0.20.73
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi restart server și Ctrl+F5 în browser.

Verificare recomandată:

1. **Securitate → Firewall central**: apare coloana Review și filtrul Review.
2. Revizuiește o policy pentru un VM; refresh-ul trebuie să păstreze statusul.
3. Rulează un Sync FortiGate; review-ul trebuie să rămână asociat aceleiași combinații VM + Policy + rol.
4. **Rapoarte → Revizii securitate**: filtrul Categorie trebuie să includă Firewall, iar rândul revizuit trebuie să apară cu last/next review.
