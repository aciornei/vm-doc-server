package fortigate

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
)

type Service struct {
	DB     *sql.DB
	Box    *cryptox.Box
	Config config.FortiGateConfig
	Logger *slog.Logger
	ctx    context.Context
	wg     sync.WaitGroup
}

type SourceInput struct {
	Name                string `json:"name"`
	BaseURL             string `json:"base_url"`
	APIToken            string `json:"api_token,omitempty"`
	VDOM                string `json:"vdom,omitempty"`
	Enabled             *bool  `json:"enabled,omitempty"`
	VerifyTLS           *bool  `json:"verify_tls,omitempty"`
	TLSServerName       string `json:"tls_server_name,omitempty"`
	SyncIntervalMinutes int    `json:"sync_interval_minutes,omitempty"`
}

type Source struct {
	ID                  int64      `json:"id"`
	Name                string     `json:"name"`
	BaseURL             string     `json:"base_url"`
	VDOM                string     `json:"vdom"`
	Enabled             bool       `json:"enabled"`
	VerifyTLS           bool       `json:"verify_tls"`
	TLSServerName       string     `json:"tls_server_name,omitempty"`
	TokenConfigured     bool       `json:"token_configured"`
	SyncIntervalMinutes int        `json:"sync_interval_minutes"`
	LastSyncAt          *time.Time `json:"last_sync_at,omitempty"`
	LastSuccessAt       *time.Time `json:"last_success_at,omitempty"`
	LastError           string     `json:"last_error,omitempty"`
	CreatedAt           time.Time  `json:"created_at"`
	UpdatedAt           time.Time  `json:"updated_at"`
}

type sourceRecord struct {
	Source
	SecretRef       string
	TokenCiphertext string
}

type SyncRun struct {
	ID                  int64      `json:"id"`
	SourceID            int64      `json:"source_id"`
	SourceName          string     `json:"source_name,omitempty"`
	Trigger             string     `json:"source"`
	Status              string     `json:"status"`
	RequestedBy         *int64     `json:"requested_by_user_id,omitempty"`
	StartedAt           *time.Time `json:"started_at,omitempty"`
	FinishedAt          *time.Time `json:"finished_at,omitempty"`
	AddressCount        int        `json:"address_count"`
	GroupCount          int        `json:"group_count"`
	PolicyCount         int        `json:"policy_count"`
	DisabledPolicyCount int        `json:"disabled_policy_count"`
	VIPCount            int        `json:"vip_count"`
	MatchCount          int        `json:"match_count"`
	ErrorMessage        string     `json:"error_message,omitempty"`
	CreatedAt           time.Time  `json:"created_at"`
}

type SyncRunPage struct {
	Items    []SyncRun `json:"items"`
	Page     int       `json:"page"`
	PageSize int       `json:"page_size"`
	Total    int       `json:"total"`
	Pages    int       `json:"pages"`
}

type RuleReview struct {
	ResourceType   string     `json:"resource_type"`
	ResourceKey    string     `json:"resource_key"`
	IntervalMonths int        `json:"interval_months"`
	Justified      bool       `json:"justified"`
	Notes          string     `json:"notes,omitempty"`
	ReviewedAt     *time.Time `json:"reviewed_at,omitempty"`
	NextReviewAt   *time.Time `json:"next_review_at,omitempty"`
	ReviewedBy     string     `json:"reviewed_by,omitempty"`
	Due            bool       `json:"due"`
}

func ReviewResourceKey(sourceID int64, vdom string, policyID int64, direction string) string {
	return fmt.Sprintf("%d|%s|%d|%s", sourceID, strings.TrimSpace(vdom), policyID, strings.ToLower(strings.TrimSpace(direction)))
}

type RuleRow struct {
	MatchID      int64      `json:"match_id"`
	VMID         int64      `json:"vm_id"`
	VMName       string     `json:"vm_name"`
	PowerState   string     `json:"power_state,omitempty"`
	AgentVersion string     `json:"agent_version,omitempty"`
	VMIP         string     `json:"vm_ip"`
	SourceName   string     `json:"source_name"`
	VDOM         string     `json:"vdom"`
	Direction    string     `json:"direction"`
	PolicyID     int64      `json:"policy_id"`
	PolicyName   string     `json:"policy_name"`
	Status       string     `json:"status"`
	SrcIntf      []string   `json:"srcintf"`
	DstIntf      []string   `json:"dstintf"`
	SrcAddr      []string   `json:"srcaddr"`
	DstAddr      []string   `json:"dstaddr"`
	Services     []string   `json:"services"`
	Action       string     `json:"action"`
	Schedule     string     `json:"schedule"`
	NAT          bool       `json:"nat"`
	Comments     string     `json:"comments,omitempty"`
	MatchObject  string     `json:"match_object"`
	MatchReason  string     `json:"match_reason"`
	VIPName      string     `json:"vip_name,omitempty"`
	ExtIP        string     `json:"extip,omitempty"`
	Risks        []string   `json:"risks"`
	SyncedAt     time.Time  `json:"synced_at"`
	Review       RuleReview `json:"review"`
}

type RulePage struct {
	Items              []RuleRow `json:"items"`
	Page               int       `json:"page"`
	PageSize           int       `json:"page_size"`
	Total              int       `json:"total"`
	Pages              int       `json:"pages"`
	Sources            int       `json:"sources"`
	SourceMatches      int       `json:"source_matches"`
	DestinationMatches int       `json:"destination_matches"`
	VIPMatches         int       `json:"vip_matches"`
	HighRisk           int       `json:"high_risk"`
}

type vmRef struct {
	ID   int64
	Name string
	IPs  []string
}

func NewService(ctx context.Context, db *sql.DB, box *cryptox.Box, cfg config.Config, logger *slog.Logger) *Service {
	if logger == nil {
		logger = slog.Default()
	}
	return &Service{DB: db, Box: box, Config: cfg.FortiGate, Logger: logger, ctx: ctx}
}

func (s *Service) Wait() { s.wg.Wait() }

const sourceSelect = `SELECT id,secret_ref,name,base_url,api_token_ciphertext,vdom,enabled,verify_tls,tls_server_name,sync_interval_minutes,last_sync_at,last_success_at,last_error,created_at,updated_at FROM fortigate_sources`

func scanSource(sc interface{ Scan(...any) error }) (sourceRecord, error) {
	var r sourceRecord
	var last, lastOK sql.NullTime
	if err := sc.Scan(&r.ID, &r.SecretRef, &r.Name, &r.BaseURL, &r.TokenCiphertext, &r.VDOM, &r.Enabled, &r.VerifyTLS, &r.TLSServerName, &r.SyncIntervalMinutes, &last, &lastOK, &r.LastError, &r.CreatedAt, &r.UpdatedAt); err != nil {
		return r, err
	}
	r.TokenConfigured = r.TokenCiphertext != ""
	if last.Valid {
		t := last.Time
		r.LastSyncAt = &t
	}
	if lastOK.Valid {
		t := lastOK.Time
		r.LastSuccessAt = &t
	}
	return r, nil
}

func (s *Service) ListSources(ctx context.Context) ([]Source, error) {
	rows, err := s.DB.QueryContext(ctx, sourceSelect+` ORDER BY name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []Source{}
	for rows.Next() {
		r, err := scanSource(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, r.Source)
	}
	return out, rows.Err()
}

func (s *Service) getSourceRecord(ctx context.Context, id int64) (sourceRecord, error) {
	return scanSource(s.DB.QueryRowContext(ctx, sourceSelect+` WHERE id=?`, id))
}

func (s *Service) GetSource(ctx context.Context, id int64) (Source, error) {
	r, err := s.getSourceRecord(ctx, id)
	return r.Source, err
}

func (s *Service) normalize(in *SourceInput, create bool) error {
	in.Name = strings.TrimSpace(in.Name)
	in.BaseURL = strings.TrimSpace(in.BaseURL)
	in.APIToken = strings.TrimSpace(in.APIToken)
	in.VDOM = strings.TrimSpace(in.VDOM)
	in.TLSServerName = strings.TrimSpace(in.TLSServerName)
	if in.VDOM == "" {
		in.VDOM = "root"
	}
	if in.SyncIntervalMinutes == 0 {
		in.SyncIntervalMinutes = 15
	}
	if in.Name == "" || in.BaseURL == "" {
		return errors.New("name and base_url are required")
	}
	if create && in.APIToken == "" {
		return errors.New("api_token is required")
	}
	u, err := url.Parse(in.BaseURL)
	if err != nil || u.Host == "" {
		return errors.New("invalid base_url")
	}
	if u.Scheme != "https" && !(s.Config.AllowHTTP && u.Scheme == "http") {
		return errors.New("FortiGate URL must use HTTPS")
	}
	if in.SyncIntervalMinutes < 1 || in.SyncIntervalMinutes > 10080 {
		return errors.New("sync_interval_minutes must be between 1 and 10080")
	}
	return nil
}

func (s *Service) CreateSource(ctx context.Context, in SourceInput, userID int64) (Source, error) {
	if err := s.normalize(&in, true); err != nil {
		return Source{}, err
	}
	ref, err := cryptox.RandomToken(24)
	if err != nil {
		return Source{}, err
	}
	cipher, err := s.Box.Encrypt([]byte(in.APIToken), "vm-doc-fortigate-token:"+ref)
	if err != nil {
		return Source{}, err
	}
	enabled, verify := true, true
	if in.Enabled != nil {
		enabled = *in.Enabled
	}
	if in.VerifyTLS != nil {
		verify = *in.VerifyTLS
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO fortigate_sources(secret_ref,name,base_url,api_token_ciphertext,vdom,enabled,verify_tls,tls_server_name,sync_interval_minutes,last_error,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,'',?,?)`, ref, in.Name, strings.TrimRight(in.BaseURL, "/"), cipher, in.VDOM, enabled, verify, in.TLSServerName, in.SyncIntervalMinutes, userID, userID)
	if err != nil {
		return Source{}, err
	}
	id, _ := res.LastInsertId()
	return s.GetSource(ctx, id)
}

func (s *Service) UpdateSource(ctx context.Context, id int64, in SourceInput, userID int64) (Source, error) {
	cur, err := s.getSourceRecord(ctx, id)
	if err != nil {
		return Source{}, err
	}
	if strings.TrimSpace(in.Name) == "" {
		in.Name = cur.Name
	}
	if strings.TrimSpace(in.BaseURL) == "" {
		in.BaseURL = cur.BaseURL
	}
	if strings.TrimSpace(in.VDOM) == "" {
		in.VDOM = cur.VDOM
	}
	if in.SyncIntervalMinutes == 0 {
		in.SyncIntervalMinutes = cur.SyncIntervalMinutes
	}
	if in.Enabled == nil {
		v := cur.Enabled
		in.Enabled = &v
	}
	if in.VerifyTLS == nil {
		v := cur.VerifyTLS
		in.VerifyTLS = &v
	}
	if strings.TrimSpace(in.TLSServerName) == "" {
		in.TLSServerName = cur.TLSServerName
	}
	if err := s.normalize(&in, false); err != nil {
		return Source{}, err
	}
	cipher := cur.TokenCiphertext
	if in.APIToken != "" {
		cipher, err = s.Box.Encrypt([]byte(in.APIToken), "vm-doc-fortigate-token:"+cur.SecretRef)
		if err != nil {
			return Source{}, err
		}
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE fortigate_sources SET name=?,base_url=?,api_token_ciphertext=?,vdom=?,enabled=?,verify_tls=?,tls_server_name=?,sync_interval_minutes=?,updated_by=? WHERE id=?`, in.Name, strings.TrimRight(in.BaseURL, "/"), cipher, in.VDOM, *in.Enabled, *in.VerifyTLS, in.TLSServerName, in.SyncIntervalMinutes, userID, id)
	if err != nil {
		return Source{}, err
	}
	return s.GetSource(ctx, id)
}

func (s *Service) DeleteSource(ctx context.Context, id int64) error {
	res, err := s.DB.ExecContext(ctx, `DELETE FROM fortigate_sources WHERE id=?`, id)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s *Service) decrypt(r sourceRecord) (string, error) {
	plain, err := s.Box.Decrypt(r.TokenCiphertext, "vm-doc-fortigate-token:"+r.SecretRef)
	return string(plain), err
}

func (s *Service) client(ctx context.Context, id int64) (*Client, sourceRecord, error) {
	r, err := s.getSourceRecord(ctx, id)
	if err != nil {
		return nil, r, err
	}
	token, err := s.decrypt(r)
	if err != nil {
		return nil, r, err
	}
	c, err := NewClient(r.BaseURL, token, r.VDOM, r.VerifyTLS, r.TLSServerName, s.Config.RequestTimeout.Value(), s.Config.AllowHTTP)
	return c, r, err
}

func (s *Service) TestSource(ctx context.Context, id int64) (map[string]any, error) {
	c, r, err := s.client(ctx, id)
	if err != nil {
		return nil, err
	}
	counts, err := c.Test(ctx)
	if err != nil {
		return nil, err
	}
	return map[string]any{
		"status":                     "ok",
		"name":                       r.Name,
		"vdom":                       r.VDOM,
		"addresses":                  counts["addresses"],
		"addresses_matchable":        counts["addresses_matchable"],
		"addresses_ignored":          counts["addresses_ignored"],
		"addresses_ipmask":           counts["addresses_ipmask"],
		"addresses_iprange":          counts["addresses_iprange"],
		"addresses_interface_subnet": counts["addresses_interface_subnet"],
		"addresses_wildcard":         counts["addresses_wildcard"],
		"groups":                     counts["groups"],
		"policies":                   counts["policies"],
		"policies_disabled":          counts["policies_disabled"],
		"policies_total":             counts["policies_total"],
		"vips":                       counts["vips"],
	}, nil
}

func (s *Service) StartSync(ctx context.Context, id int64, trigger string, user *int64) (SyncRun, error) {
	if trigger != "manual" && trigger != "scheduler" {
		return SyncRun{}, errors.New("invalid sync source")
	}
	src, err := s.GetSource(ctx, id)
	if err != nil {
		return SyncRun{}, err
	}
	if trigger == "scheduler" && !src.Enabled {
		return SyncRun{}, errors.New("FortiGate source disabled")
	}
	var running int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM fortigate_sync_runs WHERE source_id=? AND status IN ('queued','running')`, id).Scan(&running); err != nil {
		return SyncRun{}, err
	}
	if running > 0 {
		return SyncRun{}, errors.New("a FortiGate synchronization is already running")
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO fortigate_sync_runs(source_id,source,status,requested_by_user_id,error_message) VALUES(?,?,'queued',?,'')`, id, trigger, user)
	if err != nil {
		return SyncRun{}, err
	}
	runID, _ := res.LastInsertId()
	run, err := s.getRun(ctx, runID)
	if err != nil {
		return run, err
	}
	s.wg.Add(1)
	go func() {
		defer s.wg.Done()
		s.executeSync(s.ctx, runID, id)
	}()
	return run, nil
}

func (s *Service) StartAll(ctx context.Context, user *int64) ([]SyncRun, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id FROM fortigate_sources WHERE enabled=1 ORDER BY name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	out := []SyncRun{}
	for _, id := range ids {
		run, err := s.StartSync(ctx, id, "manual", user)
		if err != nil {
			if strings.Contains(err.Error(), "already running") {
				continue
			}
			return out, err
		}
		out = append(out, run)
	}
	return out, nil
}

const runSelect = `SELECT r.id,r.source_id,s.name,r.source,r.status,r.requested_by_user_id,r.started_at,r.finished_at,r.address_count,r.group_count,r.policy_count,r.disabled_policy_count,r.vip_count,r.match_count,r.error_message,r.created_at FROM fortigate_sync_runs r JOIN fortigate_sources s ON s.id=r.source_id`

func scanRun(sc interface{ Scan(...any) error }) (SyncRun, error) {
	var r SyncRun
	var uid sql.NullInt64
	var started, finished sql.NullTime
	if err := sc.Scan(&r.ID, &r.SourceID, &r.SourceName, &r.Trigger, &r.Status, &uid, &started, &finished, &r.AddressCount, &r.GroupCount, &r.PolicyCount, &r.DisabledPolicyCount, &r.VIPCount, &r.MatchCount, &r.ErrorMessage, &r.CreatedAt); err != nil {
		return r, err
	}
	if uid.Valid {
		v := uid.Int64
		r.RequestedBy = &v
	}
	if started.Valid {
		v := started.Time
		r.StartedAt = &v
	}
	if finished.Valid {
		v := finished.Time
		r.FinishedAt = &v
	}
	return r, nil
}

func (s *Service) getRun(ctx context.Context, id int64) (SyncRun, error) {
	return scanRun(s.DB.QueryRowContext(ctx, runSelect+` WHERE r.id=?`, id))
}

func (s *Service) ListRunsPage(ctx context.Context, page, size int) (SyncRunPage, error) {
	if page < 1 {
		page = 1
	}
	if size < 1 {
		size = 10
	}
	if size > 200 {
		size = 200
	}
	out := SyncRunPage{Items: []SyncRun{}, Page: page, PageSize: size}
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM fortigate_sync_runs`).Scan(&out.Total); err != nil {
		return out, err
	}
	if out.Total == 0 {
		return out, nil
	}
	out.Pages = (out.Total + size - 1) / size
	if out.Page > out.Pages {
		out.Page = out.Pages
	}
	rows, err := s.DB.QueryContext(ctx, runSelect+` ORDER BY r.id DESC LIMIT ? OFFSET ?`, size, (out.Page-1)*size)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		r, err := scanRun(rows)
		if err != nil {
			return out, err
		}
		out.Items = append(out.Items, r)
	}
	return out, rows.Err()
}

func (s *Service) executeSync(ctx context.Context, runID, sourceID int64) {
	started := time.Now().UTC()
	_, _ = s.DB.ExecContext(ctx, `UPDATE fortigate_sync_runs SET status='running',started_at=? WHERE id=?`, started, runID)
	client, src, err := s.client(ctx, sourceID)
	if err != nil {
		s.fail(ctx, runID, sourceID, err)
		return
	}
	inv, err := client.Inventory(ctx)
	if err != nil {
		s.fail(ctx, runID, sourceID, err)
		return
	}
	s.Logger.Info("FortiGate CMDB inventory fetched", "source_id", sourceID, "addresses", len(inv.Addresses), "groups", len(inv.Groups), "policies_raw", len(inv.Policies), "vips", len(inv.VIPs))
	addresses := make([]Address, 0, len(inv.Addresses))
	groups := make([]Group, 0, len(inv.Groups))
	policies := make([]Policy, 0, len(inv.Policies))
	vips := make([]VIP, 0, len(inv.VIPs))
	for _, x := range inv.Addresses {
		if v := ParseAddress(x); v.Name != "" {
			addresses = append(addresses, v)
		}
	}
	for _, x := range inv.Groups {
		if v := ParseGroup(x); v.Name != "" {
			groups = append(groups, v)
		}
	}
	disabledPolicies := 0
	for _, x := range inv.Policies {
		if v := ParsePolicy(x); v.ID != 0 {
			if !policyEnabled(v) {
				disabledPolicies++
				continue
			}
			policies = append(policies, v)
		}
	}
	for _, x := range inv.VIPs {
		if v := ParseVIP(x); v.Name != "" {
			vips = append(vips, v)
		}
	}

	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		s.fail(ctx, runID, sourceID, err)
		return
	}
	defer tx.Rollback()
	for _, q := range []string{
		`DELETE FROM fortigate_vm_matches WHERE source_id=?`,
		`DELETE FROM fortigate_addresses WHERE source_id=?`,
		`DELETE FROM fortigate_address_groups WHERE source_id=?`,
		`DELETE FROM fortigate_policies WHERE source_id=?`,
		`DELETE FROM fortigate_vips WHERE source_id=?`,
	} {
		if _, err = tx.ExecContext(ctx, q, sourceID); err != nil {
			s.fail(ctx, runID, sourceID, err)
			return
		}
	}

	synced := time.Now().UTC()
	for _, a := range addresses {
		_, err = tx.ExecContext(ctx, `INSERT INTO fortigate_addresses(source_id,vdom,name,object_type,subnet,start_ip,end_ip,fqdn,raw_json,synced_at) VALUES(?,?,?,?,?,?,?,?,?,?)`, sourceID, src.VDOM, a.Name, a.Type, a.Subnet, a.StartIP, a.EndIP, a.FQDN, MustRaw(a.Raw), synced)
		if err != nil {
			s.fail(ctx, runID, sourceID, err)
			return
		}
	}
	for _, g := range groups {
		_, err = tx.ExecContext(ctx, `INSERT INTO fortigate_address_groups(source_id,vdom,name,members_json,raw_json,synced_at) VALUES(?,?,?,?,?,?)`, sourceID, src.VDOM, g.Name, MarshalStrings(g.Members), MustRaw(g.Raw), synced)
		if err != nil {
			s.fail(ctx, runID, sourceID, err)
			return
		}
	}
	for _, p := range policies {
		_, err = tx.ExecContext(ctx, `INSERT INTO fortigate_policies(source_id,vdom,policy_id,name,status,srcintf_json,dstintf_json,srcaddr_json,dstaddr_json,service_json,action,schedule_name,nat,comments,raw_json,synced_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, sourceID, src.VDOM, p.ID, p.Name, p.Status, MarshalStrings(p.SrcIntf), MarshalStrings(p.DstIntf), MarshalStrings(p.SrcAddr), MarshalStrings(p.DstAddr), MarshalStrings(p.Services), p.Action, p.Schedule, p.NAT, p.Comments, MustRaw(p.Raw), synced)
		if err != nil {
			s.fail(ctx, runID, sourceID, err)
			return
		}
	}
	for _, v := range vips {
		_, err = tx.ExecContext(ctx, `INSERT INTO fortigate_vips(source_id,vdom,name,extip,mappedip_json,extintf,protocol,portforward,extport,mappedport,raw_json,synced_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, sourceID, src.VDOM, v.Name, v.ExtIP, MarshalStrings(v.MappedIPs), v.ExtIntf, v.Protocol, v.PortForward, v.ExtPort, v.MappedPort, MustRaw(v.Raw), synced)
		if err != nil {
			s.fail(ctx, runID, sourceID, err)
			return
		}
	}

	matches, err := s.rebuildMatches(ctx, tx, sourceID, src.VDOM, addresses, groups, policies, vips, synced)
	if err != nil {
		s.fail(ctx, runID, sourceID, err)
		return
	}
	finished := time.Now().UTC()
	if _, err = tx.ExecContext(ctx, `UPDATE fortigate_sources SET last_sync_at=?,last_success_at=?,last_error='' WHERE id=?`, finished, finished, sourceID); err != nil {
		s.fail(ctx, runID, sourceID, err)
		return
	}
	if _, err = tx.ExecContext(ctx, `UPDATE fortigate_sync_runs SET status='succeeded',finished_at=?,address_count=?,group_count=?,policy_count=?,disabled_policy_count=?,vip_count=?,match_count=?,error_message='' WHERE id=?`, finished, len(addresses), len(groups), len(policies), disabledPolicies, len(vips), matches, runID); err != nil {
		s.fail(ctx, runID, sourceID, err)
		return
	}
	if err = tx.Commit(); err != nil {
		s.fail(ctx, runID, sourceID, err)
		return
	}
	s.Logger.Info("FortiGate synchronization completed", "source_id", sourceID, "active_policies", len(policies), "disabled_policies_skipped", disabledPolicies, "matches", matches)
}

func (s *Service) rebuildMatches(ctx context.Context, tx *sql.Tx, sourceID int64, vdom string, addresses []Address, groups []Group, policies []Policy, vips []VIP, synced time.Time) (int, error) {
	resolver := Resolver{Addresses: map[string]Address{}, Groups: map[string]Group{}}
	matchableAddresses := 0
	ignoredAddresses := 0
	for _, a := range addresses {
		resolver.Addresses[strings.ToLower(a.Name)] = a
		if addressMatchable(a) {
			matchableAddresses++
		} else {
			ignoredAddresses++
		}
	}
	for _, g := range groups {
		resolver.Groups[strings.ToLower(g.Name)] = g
	}
	vms, err := s.loadVMs(ctx, tx)
	if err != nil {
		return 0, err
	}
	vipByName := map[string]VIP{}
	for _, v := range vips {
		vipByName[strings.ToLower(v.Name)] = v
	}

	count := 0
	for _, vm := range vms {
		for _, p := range policies {
			if !policyEnabled(p) {
				continue
			}

			// Keep at most one source and one destination row per VM/policy.
			// A VM can have several inventory/vCenter IPs and the same policy can
			// reference several overlapping objects. Storing every equivalent path
			// adds no review value and can multiply the match table dramatically.
			if ip, obj, why := firstVMPolicyMatch(resolver, p.SrcAddr, vm.IPs); obj != "" {
				inserted, err := insertMatch(ctx, tx, sourceID, vm.ID, vdom, p.ID, "source", ip, obj, why, "", "", riskFlags(p, "source"), synced)
				if err != nil {
					return count, err
				}
				if inserted {
					count++
				}
			}
			if ip, obj, why := firstVMPolicyMatch(resolver, p.DstAddr, vm.IPs); obj != "" {
				inserted, err := insertMatch(ctx, tx, sourceID, vm.ID, vdom, p.ID, "destination", ip, obj, why, "", "", riskFlags(p, "destination"), synced)
				if err != nil {
					return count, err
				}
				if inserted {
					count++
				}
			}

			// VIPs remain distinct because one policy can legitimately contain
			// several DNAT objects. Still keep only one row per VIP/VM/policy.
			for _, ref := range p.DstAddr {
				v, ok := vipByName[strings.ToLower(strings.TrimSpace(ref))]
				if !ok {
					continue
				}
				ip, mapped := firstVIPMatch(v, vm.IPs)
				if ip == "" {
					continue
				}
				risks := appendUnique(riskFlags(p, "vip"), "VIP/DNAT")
				why := fmt.Sprintf("%s → mapped %s", v.Name, mapped)
				inserted, err := insertMatch(ctx, tx, sourceID, vm.ID, vdom, p.ID, "vip", ip, v.Name, why, v.Name, v.ExtIP, risks, synced)
				if err != nil {
					return count, err
				}
				if inserted {
					count++
				}
			}
		}
	}
	s.Logger.Info("FortiGate strict matcher completed", "source_id", sourceID, "vms", len(vms), "matchable_addresses", matchableAddresses, "ignored_addresses", ignoredAddresses, "matches", count)
	return count, nil
}

func firstPolicyMatch(r Resolver, refs []string, ip string) (string, string) {
	for _, ref := range refs {
		if ok, why := r.Match(ref, ip); ok {
			return ref, why
		}
	}
	return "", ""
}

func firstVMPolicyMatch(r Resolver, refs, ips []string) (string, string, string) {
	for _, ip := range ips {
		if obj, why := firstPolicyMatch(r, refs, ip); obj != "" {
			return ip, obj, why
		}
	}
	return "", "", ""
}

func firstVIPMatch(v VIP, ips []string) (string, string) {
	for _, ip := range ips {
		if yes, mapped := vipContains(v, ip); yes {
			return ip, mapped
		}
	}
	return "", ""
}

func insertMatch(ctx context.Context, tx *sql.Tx, sourceID, vmID int64, vdom string, policyID int64, direction, ip, obj, why, vip, extip string, risks []string, synced time.Time) (bool, error) {
	b, _ := json.Marshal(risks)
	res, err := tx.ExecContext(ctx, `INSERT IGNORE INTO fortigate_vm_matches(source_id,vm_id,vdom,policy_id,direction,vm_ip,match_object,match_reason,vip_name,extip,risk_json,synced_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, sourceID, vmID, vdom, policyID, direction, ip, obj, why, vip, extip, string(b), synced)
	if err != nil {
		return false, err
	}
	n, err := res.RowsAffected()
	if err != nil {
		return true, nil
	}
	return n > 0, nil
}

func riskFlags(p Policy, direction string) []string {
	var out []string
	if !strings.EqualFold(p.Action, "accept") {
		return out
	}
	if hasCI(p.SrcAddr, "all") {
		out = append(out, "source ALL")
	}
	if hasCI(p.DstAddr, "all") {
		out = append(out, "destination ALL")
	}
	if hasCI(p.Services, "ALL") {
		out = append(out, "service ALL")
	}
	if direction == "destination" || direction == "vip" {
		for _, i := range p.SrcIntf {
			low := strings.ToLower(i)
			if strings.Contains(low, "wan") || strings.Contains(low, "internet") {
				out = appendUnique(out, "WAN → VM")
			}
		}
	}
	if strings.TrimSpace(p.Comments) == "" {
		out = append(out, "fără comentariu")
	}
	return out
}

func appendUnique(values []string, value string) []string {
	for _, x := range values {
		if x == value {
			return values
		}
	}
	return append(values, value)
}

func hasCI(values []string, wanted string) bool {
	for _, x := range values {
		if strings.EqualFold(strings.TrimSpace(x), wanted) {
			return true
		}
	}
	return false
}

func (s *Service) loadVMs(ctx context.Context, tx *sql.Tx) ([]vmRef, error) {
	rows, err := tx.QueryContext(ctx, `SELECT vm.id,vm.name,COALESCE(NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,''),''),COALESCE(vip.ip_address,'') FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id LEFT JOIN vcenter_vm_ips vip ON vip.vm_id=vm.id WHERE vm.retired=0 ORDER BY vm.id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	byID := map[int64]*vmRef{}
	order := []int64{}
	sets := map[int64]map[string]bool{}
	for rows.Next() {
		var id int64
		var name, primary, guestIP string
		if err := rows.Scan(&id, &name, &primary, &guestIP); err != nil {
			return nil, err
		}
		if byID[id] == nil {
			byID[id] = &vmRef{ID: id, Name: name}
			order = append(order, id)
			sets[id] = map[string]bool{}
		}
		if validIPv4(primary) {
			sets[id][primary] = true
		}
		if validIPv4(guestIP) {
			sets[id][guestIP] = true
		}
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	out := make([]vmRef, 0, len(order))
	for _, id := range order {
		v := byID[id]
		for ip := range sets[id] {
			v.IPs = append(v.IPs, ip)
		}
		sort.Strings(v.IPs)
		if len(v.IPs) > 0 {
			out = append(out, *v)
		}
	}
	return out, nil
}

func validIPv4(v string) bool {
	ip := net.ParseIP(strings.TrimSpace(v))
	return ip != nil && ip.To4() != nil
}

func (s *Service) fail(ctx context.Context, runID, sourceID int64, err error) {
	message := err.Error()
	if len(message) > 4000 {
		message = message[:4000]
	}
	now := time.Now().UTC()
	_, _ = s.DB.ExecContext(ctx, `UPDATE fortigate_sync_runs SET status='failed',finished_at=?,error_message=? WHERE id=?`, now, message, runID)
	_, _ = s.DB.ExecContext(ctx, `UPDATE fortigate_sources SET last_sync_at=?,last_error=? WHERE id=?`, now, message, sourceID)
	s.Logger.Error("FortiGate synchronization failed", "source_id", sourceID, "error", err)
}

func (s *Service) RunScheduler(ctx context.Context) {
	interval := s.Config.SchedulerInterval.Value()
	if interval <= 0 {
		interval = time.Minute
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		s.scheduleDue(ctx)
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}

func (s *Service) scheduleDue(ctx context.Context) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,sync_interval_minutes,last_sync_at FROM fortigate_sources WHERE enabled=1`)
	if err != nil {
		return
	}
	defer rows.Close()
	now := time.Now().UTC()
	for rows.Next() {
		var id int64
		var minutes int
		var last sql.NullTime
		if rows.Scan(&id, &minutes, &last) != nil {
			continue
		}
		if minutes < 1 {
			minutes = 15
		}
		if !last.Valid || now.Sub(last.Time) >= time.Duration(minutes)*time.Minute {
			if _, err := s.StartSync(ctx, id, "scheduler", nil); err != nil && !strings.Contains(err.Error(), "already running") {
				s.Logger.Error("queue FortiGate sync", "source_id", id, "error", err)
			}
		}
	}
}

func (s *Service) ListRules(ctx context.Context, q, direction, risk, action, status, service, iface, vdom, review string, sourceID, vmID int64, page, size int) (RulePage, error) {
	if page < 1 {
		page = 1
	}
	if size < 1 {
		size = 50
	}
	if size > 500 {
		size = 500
	}
	clauses := []string{"vm.retired=0", "LOWER(TRIM(p.status)) NOT IN ('disable','disabled','off','false','0')"}
	args := []any{}
	if vmID > 0 {
		clauses = append(clauses, "m.vm_id=?")
		args = append(args, vmID)
	}
	if sourceID > 0 {
		clauses = append(clauses, "m.source_id=?")
		args = append(args, sourceID)
	}
	direction = strings.ToLower(strings.TrimSpace(direction))
	if direction != "" && direction != "all" {
		if direction != "source" && direction != "destination" && direction != "vip" {
			return RulePage{}, errors.New("invalid direction")
		}
		clauses = append(clauses, "m.direction=?")
		args = append(args, direction)
	}
	if strings.TrimSpace(q) != "" {
		like := "%" + strings.TrimSpace(q) + "%"
		clauses = append(clauses, "(vm.name LIKE ? OR m.vm_ip LIKE ? OR s.name LIKE ? OR p.name LIKE ? OR m.match_object LIKE ? OR p.srcaddr_json LIKE ? OR p.dstaddr_json LIKE ? OR p.service_json LIKE ?)")
		for i := 0; i < 8; i++ {
			args = append(args, like)
		}
	}
	switch strings.ToLower(strings.TrimSpace(risk)) {
	case "", "all":
	case "high":
		clauses = append(clauses, "m.risk_json<>'[]'")
	case "source_all":
		clauses = append(clauses, "m.risk_json LIKE '%source ALL%'")
	case "destination_all":
		clauses = append(clauses, "m.risk_json LIKE '%destination ALL%'")
	case "service_all":
		clauses = append(clauses, "m.risk_json LIKE '%service ALL%'")
	case "wan":
		clauses = append(clauses, "m.risk_json LIKE '%WAN → VM%'")
	case "vip":
		clauses = append(clauses, "m.direction='vip'")
	default:
		return RulePage{}, errors.New("invalid risk filter")
	}
	if action = strings.TrimSpace(action); action != "" {
		clauses = append(clauses, "LOWER(p.action)=LOWER(?)")
		args = append(args, action)
	}
	if status = strings.TrimSpace(status); status != "" {
		if policyDisabled(status) {
			return RulePage{Items: []RuleRow{}, Page: page, PageSize: size}, nil
		}
		clauses = append(clauses, "LOWER(p.status)=LOWER(?)")
		args = append(args, status)
	}
	if service = strings.TrimSpace(service); service != "" {
		clauses = append(clauses, "p.service_json LIKE ?")
		args = append(args, "%"+service+"%")
	}
	if iface = strings.TrimSpace(iface); iface != "" {
		clauses = append(clauses, "(p.srcintf_json LIKE ? OR p.dstintf_json LIKE ?)")
		like := "%" + iface + "%"
		args = append(args, like, like)
	}
	if vdom = strings.TrimSpace(vdom); vdom != "" {
		clauses = append(clauses, "m.vdom=?")
		args = append(args, vdom)
	}
	switch strings.ToLower(strings.TrimSpace(review)) {
	case "", "all":
	case "due":
		clauses = append(clauses, "(sr.id IS NULL OR sr.next_review_at<=UTC_TIMESTAMP(6))")
	case "unreviewed":
		clauses = append(clauses, "sr.id IS NULL")
	case "current":
		clauses = append(clauses, "sr.id IS NOT NULL AND sr.next_review_at>UTC_TIMESTAMP(6)")
	default:
		return RulePage{}, errors.New("invalid review filter")
	}
	where := " WHERE " + strings.Join(clauses, " AND ")
	baseCore := ` FROM fortigate_vm_matches m JOIN fortigate_sources s ON s.id=m.source_id JOIN virtual_machines vm ON vm.id=m.vm_id JOIN fortigate_policies p ON p.source_id=m.source_id AND p.vdom=m.vdom AND p.policy_id=m.policy_id LEFT JOIN security_reviews sr ON sr.vm_id=m.vm_id AND sr.resource_type='firewall' AND sr.resource_key=CONCAT(m.source_id,'|',m.vdom,'|',m.policy_id,'|',m.direction)`
	baseRows := baseCore + ` LEFT JOIN agents a ON a.id=vm.agent_id LEFT JOIN users ru ON ru.id=sr.reviewed_by`
	out := RulePage{Items: []RuleRow{}, Page: page, PageSize: size}
	// One aggregate pass instead of COUNT + a second SUM pass. On a large
	// FortiGate inventory this materially reduces the cost of opening Firewall
	// central before the paginated rows are fetched.
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*),COALESCE(SUM(m.direction='source'),0),COALESCE(SUM(m.direction='destination'),0),COALESCE(SUM(m.direction='vip'),0),COALESCE(SUM(m.risk_json<>'[]'),0)`+baseCore+where, args...).Scan(&out.Total, &out.SourceMatches, &out.DestinationMatches, &out.VIPMatches, &out.HighRisk); err != nil {
		return out, err
	}
	_ = s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM fortigate_sources WHERE enabled=1`).Scan(&out.Sources)
	if out.Total == 0 {
		return out, nil
	}
	out.Pages = (out.Total + size - 1) / size
	if out.Page > out.Pages {
		out.Page = out.Pages
	}
	queryArgs := append(append([]any{}, args...), size, (out.Page-1)*size)
	rows, err := s.DB.QueryContext(ctx, `SELECT m.id,m.vm_id,vm.name,COALESCE(vm.power_state,''),COALESCE(a.agent_version,''),m.vm_ip,s.name,m.source_id,m.vdom,m.direction,p.policy_id,p.name,p.status,p.srcintf_json,p.dstintf_json,p.srcaddr_json,p.dstaddr_json,p.service_json,p.action,p.schedule_name,p.nat,p.comments,m.match_object,m.match_reason,m.vip_name,m.extip,m.risk_json,m.synced_at,COALESCE(sr.interval_months,6),sr.justified,COALESCE(sr.notes,''),sr.reviewed_at,sr.next_review_at,COALESCE(ru.display_name,ru.username,'')`+baseRows+where+` ORDER BY m.vm_id,m.policy_id,m.direction,m.vm_ip,m.id LIMIT ? OFFSET ?`, queryArgs...)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var r RuleRow
		var sourceID int64
		var srcIntf, dstIntf, srcAddr, dstAddr, services, risks string
		var justified sql.NullBool
		var reviewedAt, nextReviewAt sql.NullTime
		if err := rows.Scan(&r.MatchID, &r.VMID, &r.VMName, &r.PowerState, &r.AgentVersion, &r.VMIP, &r.SourceName, &sourceID, &r.VDOM, &r.Direction, &r.PolicyID, &r.PolicyName, &r.Status, &srcIntf, &dstIntf, &srcAddr, &dstAddr, &services, &r.Action, &r.Schedule, &r.NAT, &r.Comments, &r.MatchObject, &r.MatchReason, &r.VIPName, &r.ExtIP, &risks, &r.SyncedAt, &r.Review.IntervalMonths, &justified, &r.Review.Notes, &reviewedAt, &nextReviewAt, &r.Review.ReviewedBy); err != nil {
			return out, err
		}
		r.Review.ResourceType = "firewall"
		r.Review.ResourceKey = ReviewResourceKey(sourceID, r.VDOM, r.PolicyID, r.Direction)
		r.Review.Justified = justified.Valid && justified.Bool
		r.Review.Due = true
		if reviewedAt.Valid {
			v := reviewedAt.Time
			r.Review.ReviewedAt = &v
		}
		if nextReviewAt.Valid {
			v := nextReviewAt.Time
			r.Review.NextReviewAt = &v
			r.Review.Due = !v.After(time.Now().UTC())
		}
		_ = json.Unmarshal([]byte(srcIntf), &r.SrcIntf)
		_ = json.Unmarshal([]byte(dstIntf), &r.DstIntf)
		_ = json.Unmarshal([]byte(srcAddr), &r.SrcAddr)
		_ = json.Unmarshal([]byte(dstAddr), &r.DstAddr)
		_ = json.Unmarshal([]byte(services), &r.Services)
		_ = json.Unmarshal([]byte(risks), &r.Risks)
		out.Items = append(out.Items, r)
	}
	return out, rows.Err()
}

func ParseIntQuery(v string) int64 {
	n, _ := strconv.ParseInt(strings.TrimSpace(v), 10, 64)
	return n
}
