# Upgrade vm-doc-server 0.17.0 → 0.17.1

0.17.1 este un hotfix pentru migrarea `032_inventory_changes.up.sql`.

În 0.17.0 coloanele FK din `inventory_changes` au fost definite `BIGINT` semnat, în timp ce cheile primare referențiate (`virtual_machines.id`, `agents.id`, `inventory_snapshots.id`, `users.id`) sunt `BIGINT UNSIGNED`. MariaDB/MySQL refuză cheia străină și serverul nu pornește.

## Pași

1. Opriți `vm-doc-server`.
2. Aplicați `vm-doc-server-0.17.1-update.tar.gz` peste sursa 0.17.0.
3. Recompilați: `go build -o vm-doc-server ./cmd/vm-doc-server`.
4. Instalați binarul rezultat peste binarul folosit de systemd.
5. Porniți `vm-doc-server`.

Nu este necesară intervenție manuală în `schema_migrations`: migrarea 032 eșuată nu a fost înregistrată și va fi reluată automat.

Dacă a rămas o tabelă `inventory_changes` creată manual sau parțial, verificați-o înainte de pornire. În mod normal, pentru eroarea 1005 din 0.17.0 tabela nu este creată.

Agentul 1.6.1 rămâne compatibil și nu necesită update.
