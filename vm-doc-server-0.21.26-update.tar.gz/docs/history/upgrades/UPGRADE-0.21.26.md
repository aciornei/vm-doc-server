# Upgrade VM-DOC Server 0.21.25 → 0.21.26

Release exclusiv UI / performanță JavaScript. Nu modifică API sau SQL, nu necesită agent nou.

1. Copiază sursele 0.21.25 în 0.21.26 și extrage update-ul peste ele; păstrează `vendor/` și configurațiile.
2. Rulează `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și `GOPROXY=off GOFLAGS=-mod=vendor make build`.
3. Testează în staging VM → Configurare → Infrastructură: Date vCenter apar înainte de lista agenților/conexiunile externe; apoi toate devin funcționale. Verifică agentul deja asociat, schimbarea agentului, salvarea și lista software în Inventar.
4. Testează Operațional → Beneficiari cu mai multe departamente și persoane, și dacă pagina se încarcă fără eroare.
5. Repornește binarul și folosește Ctrl+F5. Măsoară timpul răspunsului GET `/api/v1/vms/{id}` pentru a diferenția întârzierea serverului de browser.
