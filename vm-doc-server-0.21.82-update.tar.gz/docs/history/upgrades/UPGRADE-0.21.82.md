# Upgrade VM-DOC 0.21.81 → 0.21.82

1. Backup complet al bazei MariaDB și al configurației/binarului.
2. Aplică update TAR sau patch peste sursele 0.21.81; alternativ folosește source ZIP.
3. `bash scripts/cleanup-source-tree.sh --check`
4. Pe server cu vendor: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
5. Oprește serviciul VM-DOC, instalează binarul nou și pornește. Migrarea **083** rulează automat.
6. Verifică `Nou` în lista Modificări, `Revizuit` în timeline, `Ignorat` doar la opțiunea explicită, și revenirea automată ca `Revenit la baseline`.
7. Verifică în browser că nu există scrollbar orizontal la nivel de document; numai tabelul derulează când nu încape.

Rollback: înainte de reinstalarea binarului 0.21.81, rulează migrarea DOWN 083 în staging și revalidează schema. Nu executa scripturi în producție fără backup.
