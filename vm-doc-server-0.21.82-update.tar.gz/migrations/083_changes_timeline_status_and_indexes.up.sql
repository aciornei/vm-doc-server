-- VM-DOC 0.21.82: separă automatul de Ignorat și optimizează istoricul paginat.
-- Nu elimină evenimente și nu modifică baseline-ul acceptat.
UPDATE inventory_changes
   SET review_status='reverted'
 WHERE review_status='ignored'
   AND reviewed_by IS NULL
   AND notes LIKE '%Revenire automată la baseline%';
CREATE INDEX idx_inventory_changes_triage_status_time
    ON inventory_changes(review_status,occurred_at,id);
CREATE INDEX idx_inventory_changes_vm_timeline
    ON inventory_changes(vm_id,review_status,reviewed_at,id);
