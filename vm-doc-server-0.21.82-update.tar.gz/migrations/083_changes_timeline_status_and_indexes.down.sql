-- Compatibilitate rollback. Păstrează indexurile doar cât timp versiunea 0.21.82 este instalată.
UPDATE inventory_changes SET review_status='ignored'
 WHERE review_status='reverted' AND reviewed_by IS NULL
   AND notes LIKE '%Revenire automată la baseline%';
DROP INDEX idx_inventory_changes_vm_timeline ON inventory_changes;
DROP INDEX idx_inventory_changes_triage_status_time ON inventory_changes;
