# VM-DOC Server 0.21.82 — Ghid stări, ignorate și optimizare timeline

- Manual `Ignorat` rămâne acceptare semantică a baseline-ului pentru un obiect, însă nu apare implicit în timeline, nici în lista de lucru sau în contoarele active; se poate consulta la cerere.
- Revenirea automată la valoarea baseline-ului este marcată **`reverted`**, fără a pretinde că a fost ignorată de administrator. Migrarea 083 reclasifică numai evenimentele vechi identificate sigur din notă și absența utilizatorului.
- Timeline implicit: **`reviewed` + `reverted`**, opțiune „Include evenimentele ignorate”. Toate paginile sunt paginate, 25 evenimente/timeline.
- Sortarea timeline după `reviewed_at DESC`, nu data detectării.
- Indexuri MariaDB pentru filtrarea reviziilor și timeline. Nu există retenție fizică automată pentru `ignored` în această versiune; decizia va fi separată și necesită verificarea relațiilor cu baseline și audit.
- Ghidul de jos separă Nou, Revizuit, Ignorat, Revenit la baseline. Documentat încă nu este implementat.
- Fix overflow: documentul nu permite scroll orizontal la pagina Modificări / fila VM; tabelul are derulare proprie când este prea lat.
- Migrarea 083 este automată la pornirea serverului. Niciun impact asupra agentului 1.7.18 / API existent; `timeline_all` este valoare nouă opțională pentru parametrul `mode`.

## Testare / limitări
Testele Go independente și Chromium validate local; build integral necesită `vendor/`. Migrarea SQL nu este validată pe MariaDB reală; backup și staging obligatorii înainte de instalare.
