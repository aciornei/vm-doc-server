package inventorychanges

import (
	"reflect"
	"strings"
	"testing"
)

func TestReviewStatusFilterDefaultExcludesIgnored(t *testing.T) {
	cases := []struct {
		label    string
		input    Filter
		wantSQL  string
		wantArgs []any
	}{
		{"inbox", Filter{}, "c.review_status='new'", nil},
		{"timeline default", Filter{Mode: "timeline"}, "c.review_status IN ('reviewed','reverted')", nil},
		{"timeline including manual ignored", Filter{Mode: "timeline_all"}, "c.review_status IN ('reviewed','reverted','ignored')", nil},
		{"ignored explicit", Filter{ReviewStatus: "ignored"}, "c.review_status=?", []any{"ignored"}},
		{"all only explicit", Filter{Mode: "all"}, "", nil},
	}
	for _, tc := range cases {
		t.Run(tc.label, func(t *testing.T) {
			got, args := reviewStatusFilter(normalizeFilter(tc.input))
			if got != tc.wantSQL || !reflect.DeepEqual(args, tc.wantArgs) {
				t.Fatalf("got %q / %v; expected %q / %v", got, args, tc.wantSQL, tc.wantArgs)
			}
		})
	}
}

func TestReviewStatusFilterNoIgnoredInDefaultTimeline(t *testing.T) {
	got, _ := reviewStatusFilter(Filter{Mode: "timeline"})
	if strings.Contains(got, "ignored") {
		t.Fatal("ignored must be opt-in on timeline")
	}
	if !strings.Contains(got, "reverted") {
		t.Fatal("automatic reverted state must be in timeline")
	}
}
