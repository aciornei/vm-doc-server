-- 0.20.68: FortiGate security inventory keeps only active policies.
-- Add visibility for skipped disabled policies and purge legacy disabled correlations.

ALTER TABLE fortigate_sync_runs
  ADD COLUMN disabled_policy_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER policy_count;

ALTER TABLE fortigate_policies
  ADD KEY idx_fortigate_policy_status (status,source_id,vdom,policy_id);

DELETE m
FROM fortigate_vm_matches m
JOIN fortigate_policies p
  ON p.source_id=m.source_id AND p.vdom=m.vdom AND p.policy_id=m.policy_id
WHERE LOWER(TRIM(p.status)) IN ('disable','disabled','off','false','0');

DELETE FROM fortigate_policies
WHERE LOWER(TRIM(status)) IN ('disable','disabled','off','false','0');
