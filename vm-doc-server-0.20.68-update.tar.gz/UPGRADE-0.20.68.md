# Upgrade VM-DOC Server 0.20.67 → 0.20.68

0.20.68 exclude complet policy-urile FortiGate disabled din inventar și din corelarea VM ↔ firewall.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.67 /usr/local/src/vm-doc-server-0.20.68
tar -xzf vm-doc-server-0.20.68-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.68
cd /usr/local/src/vm-doc-server-0.20.68
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server`. Migrarea `069_fortigate_ignore_disabled_policies.up.sql` se aplică automat la startup și elimină corelările provenite din policy-uri disabled.

După upgrade rulează o sincronizare FortiGate manuală. În **Securitate → Firewall central → Sincronizări recente** verifică **Policies active**, **Disabled ignorate** și noul **Corelări**.

Agentul nu trebuie actualizat: `vm-doc-agent 1.7.12` rămâne recomandat.
