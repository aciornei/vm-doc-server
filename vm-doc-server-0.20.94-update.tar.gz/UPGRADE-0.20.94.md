# Upgrade VM-DOC Server 0.20.93 → 0.20.94

0.20.94 adaugă compatibilitate pentru politica de parole raportată de agenții Linux legacy, inclusiv SLES9 1.0.1.

Nu există migrare DB. După upgrade, rulează o colectare pe hostul SLES9 și fă Ctrl+F5 în browser.
