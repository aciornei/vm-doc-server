## 0.21.74 — Separare director LDAP / autentificare

- [x] Separarea autentificării LDAP de citirea directorului; mesaj și UI Login adaptate providerilor.
- [ ] Validare end-to-end pe AD LDAPS și Keycloak în staging; build integral cu `vendor/`.

## Detector semantic — dezvoltări și validări (după 0.21.73)

- [ ] P1: testare trei snapshoturi și stări reale ale colectorilor pentru Windows / Linux vechi / Docker / DB ACL; SQL diagnostic read-only pe MariaDB.
- [ ] P1: evaluare volum schimbări legitime când multe aplicații au upgrade simultan (grupare update de pachete și firewall `added+removed` într-o singură modificare de regulă).
- [ ] P1: confirmare HBA/User/Grants cu `access.status=discovered`; pentru surse DB incomplete nu genera `removed`.
- [ ] **ETAPA 2:** instrumentare baseline + diff pe sincronizările centrale FortiGate, Veeam și Prometheus (nu se află în agent). Deduplicare, sursă, resursă și VM/serviciu corelat; fără parole/tokenuri.
- [ ] **ETAPA 3:** stare `documented` distinctă de `required/reviewed`, user/time/evidence/link Outline, timeline cronologic Facebook-like pe VM, serviciu și infrastructură.
- [ ] P2: detector software Linux; agent 1.7.18 raportează software doar pe Windows (Win32/Windows features; AppX omis din diff implicit).
- [ ] P2: politica porturilor configurabilă pe categorii/protocol, dar UDP/DNS/RPC auto dezactivate implicit pentru zgomot minim.

## 0.21.72 — Validare politică STRICT (P1)

- [ ] Test pe inventare reale: Postfix `master`/`smtpd` port 25, Apache worker count, port Principal deschis/închis, agent collector missing.
- [ ] Confirmă pe VM-uri active că „Componente suport” selectate corespund serviciilor urmărite; completează selecțiile principale înainte de a activa STRICT global în producție.
- [ ] Validează pe MariaDB reală PREVIEW/CLEANUP (eșantion manual + backup); nu rula SQL automat.
- [ ] Decide ulterior dacă este nevoie de opțiune UI per VM pentru profilul de istoric STRICT/EXTINS; în 0.21.72 profilul STRICT este global.

## 0.21.71 — verificări staging

- [ ] Verifică după upgrade că actualizările de `systemd-fsck@...` și `systemd-fsckd.service` nu generează evenimente noi.
- [ ] Rulează PREVIEW-ul SQL pe copia MariaDB staging și verifică numărul de evenimente fsck candidate; cleanup manual doar după backup recuperabil.
- [ ] Confirmă că serviciile aplicațiilor și celelalte unități systemd continuă să genereze modificări reale.

## Validare VM-DOC 0.21.70 în staging

- [ ] `go test ./...` și `go build ./cmd/vm-doc-server` cu `vendor/` din mediul offline.
- [ ] Testează pe VM-ul MySQL 5.5.56-MariaDB două colectări cu startup note `[Note]` în ore/PID diferite: nicio modificare nouă în `inventory_changes`.
- [ ] Testează scenariul de upgrade la MariaDB 5.5.57: eveniment real `modified` păstrat.
- [ ] Rulează PREVIEW-ul SQL dedicat în staging; verifică candidate și backup înainte de CLEANUP manual; verifică și evenimentele revizuite protejate.
- [ ] Confirmă versiunea 0.21.70 în UI, audit, SQL și snapshoturile brute fără modificări.

## Validare VM-DOC 0.21.69 în staging

- [ ] Rebuild complet Go cu `vendor/`, test `go test ./...`; verifică `/version` și resursele embed `app.js?v=0.21.69`.
- [ ] Pe VM Docker care recreează bridge-urile, verifică absența evenimentelor noi pentru `iptables/ipv4/nat/POSTROUTING -s 172.18/16 ! -o br-... -j MASQUERADE`.
- [ ] Confirmă că alte NAT/iptables și `DOCKER-USER` continuă să apară ca modificări când se schimbă.
- [ ] Rulare `preview-iptables-nat-docker-02169.sql` pe MariaDB staging; comparație cu screenshotul/JSON-ul evenimentelor reale; backup verificat înainte de `cleanup-iptables-nat-docker-02169.sql`.
- [ ] Urmărește topul `inventory_changes` după câteva sincronizări pentru a confirma reducerea zgomotului.

## Validare 0.21.69 — iptables Docker NAT (2026-10-21)

- [ ] Build Go integral `go test ./...` și `make build` pe serverul offline cu `vendor/`.
- [ ] Staging MariaDB: execută `preview-iptables-nat-docker-02169.sql`, verifică COUNT și 50 exemple; backup restaurabil, serviciul VM-DOC oprit, apoi `cleanup-iptables-nat-docker-02169.sql` numai dacă rezultatele sunt strict NAT Docker.
- [ ] După deploy, recreează în staging bridge Docker `br-<12hex>` și colectează două snapshoturi: fără noi `added/removed` pe `iptables nat/POSTROUTING MASQUERADE`; regula explicită NAT `eth0` rămâne monitorizată.
- [ ] Repetă verificarea în VM-DOC „Modificări” separat pentru evenimentele vechi, care nu dispar fără cleanup manual.

## De verificat 0.21.68 — UI Arhivă BETA

- [ ] Browser real: panglică BETA roșie identică Hardening în Arhivă, teme Dark/Light, rezoluții desktop și mobil.
- [ ] KPI carduri clicabile: filtre VM, Servicii, Arhivate, Dispariții neconfirmate; Reset, căutare și paginare 10/25/50/100.
- [ ] Validare observații expandabile, escape HTML și scroll orizontal pe registru; acțiuni Retrage/Arhivează/Reactivează și dialogurile aferente.
- [ ] Build server Go complet cu vendor/ în staging; JS este embed în binar.

## După 0.21.67

- [ ] Validare staging MariaDB migrare 081, API, build cu vendor/ și vCenter 8.0.3.
- [ ] Verificare toate rapoartele/exporturile pentru excluderea resurselor retrase/arhivate.
- [ ] Snapshot complet al relațiilor istorice din Docker, DB, Web și alte dependențe (în 0.21.67 sunt fixate doar asocierile VM–serviciu directe).
- [ ] Workflow ulterior de retenție aprobată și purge explicit, fără ștergeri automate.

## De verificat 0.21.66 — Hotfix pagini VM (Docker, Databases, Web)
- [ ] Pe VM #264 (și alte VM-uri), deschide Docker, Baze de date și Web: paginile se afișează fără `ReferenceError: vmResourceContexts is not defined`.
- [ ] Testează butonul de configurare/editare documentație și asociere servicii/beneficiari pe toate 3 subpagini, inclusiv trecerea între două VM-uri.
- [ ] Console Chrome F12: fără alte `ReferenceError` la click pe resurse; după upgrade `app.js?v=0.21.66`.
- [ ] Rebuild complet server offline cu `vendor/`, test în browser conectat la MariaDB reală. Nu e migrare DB.

- [ ] Validează toate valorile Mediu din nomenclator pe cele 6 pagini și exporturi, inclusiv valoare personalizată și nomenclator inactiv.
## Validare 0.21.64 — filtre implicite, Docker UI

- [ ] Upgrade staging 0.21.63→0.21.64 cu build Go integral pe serverul offline și `vendor/`; verificați că resursele `/static/js/app.js?v=0.21.64` sunt încărcate după refresh.
- [ ] Pe un VM cu Docker, deschideți secțiunea Docker după Ctrl+F5; dacă rămâne `vmContext is not defined`, colectați URL, linia și stack trace din Developer Tools → Console; verificați sursa care emite eroarea.
- [ ] În fiecare din cele 6 zone, confirmați implicit Pornite+PROD, alegerea TEST/DEV, selectarea Toate, resetarea, paginarea și exportul XLSX corespunzător.
- [ ] Testați etichete mediu `PROD` și `Producție`, VM fără mediu, VM oprite, VM excluse prin pool, nume de pool duplicate, plus filtre simultane de căutare.
- [ ] Măsurați performanța listei Agenți cu paginarea SQL și filtre Power+Mediu la volumul real.

## Validare 0.21.63 — Arbore pool-uri și audit

- [ ] VCSA 8.0.3: permisiuni `System.Read` pentru GET resource-pool/{id}, copii reali și rădăcini/cluster, pool-uri omonime și liste mari.
- [ ] MariaDB: aplicarea migrației 080, tranzacții pentru audit, persistarea corectă a idempotentei pe pool și VM.
- [ ] Audit: o singură alertă pentru VM POWERED_ON exclusă la prima sincronizare, fără duplicate la sync repetat, re-alertare la tranziție OFF→ON sau mutare în alt pool exclus.
- [ ] UI reală: dialog 1595/1024/390, spacing, arbori colapsați, bifa părintelui, child override, scroll și avertizări.
- [ ] Go `go test ./...` și `make build` cu `vendor/` pe mașina offline.

## Validare 0.21.62 — resource pool (prioritate nouă)

- [ ] Testează împotriva vCenter 8.0.3: răspunsul `GET /api/vcenter/resource-pool` și filtrul `GET /api/vcenter/vm?resource_pools=...`, inclusiv pool-uri imbricate și root.
- [ ] Testează în staging migrarea 079 cu surse multiple, același nume de pool, pool nou șters/recreat, VM mutat din pool inclus în exclus și invers.
- [ ] Confirmă că documentarea/Outline pentru VM-uri excluse este blocată și că rapoartele de serviciu/beneficiar nu conțin accidental VM-uri excluse (audit suplimentar).
- [ ] Confirmă Go build cu vendor și e2e MariaDB/Keycloak API RBAC + sync scheduler.

## De validat — 0.21.61

- [ ] Validare în staging cu inventare reale Auditbeat/Filebeat: 9.4.1 numeric ↔ banner lung (nu produce eveniment), 9.4.1 ↔ 9.4.2 (produce eveniment).
- [ ] Rulare SQL PREVIEW pe MariaDB și inspecție mostre înainte de orice curățare, cu backup verificat; SQL CLEANUP numai după confirmare.
- [ ] Rebuild/test Go integral offline cu `vendor/`, apoi rollout și urmărirea istoricului de modificări.

## De validat — 0.21.60

- [ ] Build complet Go cu vendor/ și teste reale MariaDB/staging.
- [ ] Test comparații name/image-tag Docker vs MAC/IP/Compose/digest, plus UDP principal vs nonprincipal.
- [ ] Observați exact `firewall.rules[*].rule` pentru nftables NAT rămas, deoarece forma completă nu este încă furnizată; extindeți numai după diagnostic.
- [ ] Rulați preview și confirmați numărul/mostrele înaintea SQL DELETE manual.

## După 0.21.59 — guard-uri Docker iptables/raw

- [ ] Confirmați `version=0.21.59` în binarul efectiv, nu doar în surse; validați testul `GOPROXY=off go test ./...` și build-ul cu `vendor/` pe server.
- [ ] În MariaDB staging, verificați PREVIEW pentru evenimente `iptables / ipv4 / raw / PREROUTING`, protecția review-urilor și numărul exact șters în CLEANUP.
- [ ] Instalați după backup/rollback pregătit; după două colectări verificați că nu mai apar `-A PREROUTING -d 172.18.0.x/32 ! -i br-<12hex> -j DROP`.
- [ ] Confirmați că reguli explicite/DOCKER-USER/nftables neacoperite sunt păstrate. Observați 2–3 zile eventuale forme suplimentare, fără a extinde generic regexul.

## 0.21.58 — verificări după remedierea SQL Docker bridge

- [ ] Pe MariaDB staging, compară PREVIEW cu ștergerile reale pentru `bridge_docker` și `nftables_guard` înainte de PROD.
- [ ] Confirmă timestampurile evenimentelor vizibile și dacă 0.21.58 este în execuție, nu doar sursa instalată.
- [ ] Rulează build integral offline cu vendor/ și testează Docker network recreation.
- [ ] Inspectează separat evenimentele de port TCP/3181 și contul local; nu se șterg automat.

## De verificat după 0.21.57 — zgomot Docker / nftables

- [ ] Verifică pe staging și pe câteva VM-uri Docker: MAC-only nu generează modificări, IP/gateway/network ID/imagine generează.
- [ ] Rulează diagnosticul SQL nftables: când au fost generate rândurile (înainte/după 0.21.56), ce backend, chain și sintaxă au. Nu lărgi filtrul fără exemple reale.
- [ ] Verifică SQL PREVIEW cumulativ 0.21.50–0.21.57 pe MariaDB staging, apoi cleanup manual după backup și oprirea VM-DOC.
- [ ] Execută full `go test ./...` și `make build` cu `vendor/` pe serverul offline; validează 2–3 zile distribuția pe categorii.

## Verificări după 0.21.56 — Porturi & Docker firewall

- [ ] În staging, pe VM Apache prefork, confirmă că variația numărului de workeri pentru același TCP/80/443 nu creează schimbări, iar dispariția/alterarea portului persistență 2 colectări se detectează.
- [ ] În staging, după schimbarea rețelei Docker (`br-<hex>`), confirmă că regulile `ip daddr RFC1918 iifname != br-hex counter drop` nu se salvează; regulile DOCKER-USER, firewall-ul explicit și schimbările reale rămân.
- [ ] Backup, PREVIEW/CLEANUP cumulativ 0.21.50–0.21.56 testat pe MariaDB staging; verifică rândurile protejate și comparația înainte/după.
- [ ] Build `GOPROXY=off go test ./...` și `make build` cu `vendor/` pe serverul offline; monitorizează 2–3 zile topul `inventory_changes`.

## Verificări după 0.21.55 — Windows SCM DisplayName

- [ ] Confirmați pe staging că `wuauserv` și `workfolderssvc` cu `software_name` alternativ nu mai produc modificări; urmăriți că `enabled_state`, versiunile și eliminările reale sunt detectate.
- [ ] Rulați testele și compilarea completă pe mediul offline folosind `vendor/`; fără binary verificat în acest artefact.
- [ ] Backup MariaDB → oprire server → PREVIEW SQL cumulativ 0.21.55 (toate categoriile) → validare selecții/protecții → CLEANUP numai dacă rezultatele sunt conforme. Verificați numărul real de rânduri șterse; pe MariaDB SQL nu a fost executat local.
- [ ] Urmăriți 2–3 zile după instalare și nu excludeți mai mult decât arată dovezile colectate.

## Verificări după 0.21.54 — servicii Windows per-user

- [ ] Instalează 0.21.54 pe staging și confirmă că `P9RdrService_*`, `NPSMSvc_*`, `DeviceAssociationBrokerSvc_*` cu sufix hex nu mai ajung în `inventory_changes`; numele fără sufix și alte servicii rămân urmărite.
- [ ] Backup + PREVIEW cumulativ 0.21.54 + verificare criterii/protecții + CLEANUP manual și verificare post-ștergere; MariaDB reală netestată în această sesiune.
- [ ] Urmărește 2–3 zile alte familii Windows `*_hex` într-un top al modificărilor înainte de orice extindere a regulilor.
- [ ] Test și build complet server (`vendor/`, `GOPROXY=off`) pe mediul offline.

## Verificări după 0.21.53 — rețea/veth

- [ ] În staging confirmați că `veth` cu nume hex din Docker/LXC nu mai generează evenimente, iar `ens192`/`docker0`/`br-*`/`bond`/`vlan` și DNS/IP continuă să fie detectate.
- [ ] SQL PREVIEW → backup MariaDB → server oprit → SQL CLEANUP cumulativ 0.21.53 → verificarea rândurilor protejate; audit/test pe bază reală înainte de PROD.
- [ ] Urmăriți 2–3 zile distribuția categoriilor `network`, `ports`, `firewall`, `services`; rafinați exclusiv după dovezi reale și inventarele platformelor legacy.
- [ ] Build complet `GOPROXY=off go test ./...` / `make build` cu `vendor/` pe serverul offline.

## Verificări după 0.21.52 — porturi ascultate

- [ ] Test VM APP01, TCP/80, apache2: dispariție de o colectare urmată de revenire nu trebuie să producă modificare; dispariția persistentă două colectări produce un singur eveniment.
- [ ] Execută pe staging SQL preview/cleanup manual și compară `fluctuatii_porturi_confirmate`. Protejarea review-urilor/deciziilor și rollback din backup sunt obligatorii.
- [ ] Monitorizează după release încă 2–3 zile; verifică porturi reale persistente și falsele perechi, apoi ajustează dacă apar noi cauze.
- [ ] Build offline cu vendor (`GOPROXY=off go test ./...`, `make build`), test pe MariaDB reală, verificare retenție și backward compatibilitate.

## Verificări post-0.21.51 (2026-10-20)

- [ ] Rulați preview-ul SQL și comparați cele două grupe noi: `instante_windows_per_user`, `warning_versiune_mysql` pe staging înainte de curățare PROD.
- [ ] După backup și oprirea serverului, aplicați manual cleanup-ul SQL; verificați totalurile înainte/după și păstrarea evenimentelor revizuite/cu note.
- [ ] Urmăriți timp de 2–3 zile după 0.21.51 dacă dispar instanțele Windows per-user, `lxd-installer@N-N-N` și alertele MySQL, fără a pierde upgrade-uri reale.
- [ ] Testați full Go build cu `vendor/` offline și preview/cleanup pe MariaDB reală de staging.

# VM-DOC — TODO / backlog

> Actualizat: 2026-10-20, după VM-DOC Server 0.21.50. Acest fișier păstrează funcționalitățile **amânate**, nu descrie funcții implementate.

## De verificat / rafinat în staging — Modificări inventar 0.21.50

- [ ] Rulează preview SQL pe baza VM-DOC reală; salvează rezultatele, confirmă baza selectată și efectuează dump complet înainte de DELETE.
- [ ] Oprește VM-DOC pentru curățare, rulează scriptul explicit și verifică numărul șters per motiv / rândurile rămase; verifică evenimentele deja revizuite și `Principal`.
- [ ] Confirmă că numărul de evenimente zilnice noi a scăzut în următoarele zile, separat pentru porturi, nftables, servicii, DB și NTP; rafinează numai după mostre reale.
- [ ] Verifică porturi de aplicație pe 49152–65535: selectate ca Principal rămân în istoricul modificărilor; cele ne-selectate sunt vizibile în inventarul brut.
- [ ] Confirmă că schimbarea `enabled_state`, `version`, reguli nftables INPUT/user și porturi joase generează evenimente; instalare/ștergere reală de serviciu relevant rămâne urmărită.
- [ ] Rulează `GOPROXY=off GOSUMDB=off go test ./...` și `make build` cu `vendor/` offline; probează SQL și sistemul în staging înainte de PROD.
- [ ] Dacă încă există multe `nftables` `added/removed` pe lanțurile rămase, colectează câteva valori complete `object_key`/old/new pentru rafinare, nu exclude automat tot nftables.

## De verificat în staging — Hartă rețea 0.21.49

- [ ] Verifică numele/IP-urile VM-urilor externe în Sursă și Destinație: `VM(IP)` pe un rând, apoi `Obiecte FortiGate:` cu lista completă, fără dubluri de identitate.
- [ ] Verifică antetele SURSĂ/DESTINAȚIE, porturi TCP din VM cu spațiere mărită și nota „Interpretare” cu margine stânga.
- [ ] Exportă SVG pentru VM cu peste 100 de obiecte și nume foarte lungi: toate trebuie păstrate integral, fără butoane Extinde/Restrânge, pe fundal/casete albe; viewer SVG/PDF independent de tema browserului.
- [ ] Confirmă că în UI rămân limitele și controalele de navigare a obiectelor, iar click port ↔ policy/linie și excluderile UDP/DNS funcționează ca înainte.
- [ ] Confirmă `go test ./...`, `make build` cu `vendor/`, apoi test pe inventarul real FortiGate și pagini desktop/mobil.

## De verificat în staging — Hartă rețea 0.21.48

- [ ] Compară policy FortiGate cu 0.21.46: număr vizibil, servicii/porturi enumerate sub număr, VDOM/NAT în tooltip și detaliile complete.
- [ ] Testează 100+ obiecte în Sursă/Destinație: primele 4 vizibile, Extinde pentru ferestre de 16, Anterioare/Următoarele și Restrânge accesibile până la ultimul obiect, fără SVG uriaș.
- [ ] Verifică porturi `9078/tcp` fără descrierea generică „port ascultat”, dar cu nume tehnice relevante păstrate.
- [ ] Confirmă export SVG, click port ↔ linie/policy/nod, regulile UDP și DNS, două VM-uri și fluxuri bidirecționale, inclusiv pe dispozitive înguste.

## De verificat în staging — Hartă rețea 0.21.47

- [ ] Testează port selectat și toate legăturile FortiGate spre acel port, inclusiv multiple reguli spre același port, apoi selecție inversă din linie/policy.
- [ ] Testează fluxuri fără port TCP corelabil: nu evidenția un port arbitrar; tooltip/panoul de detalii păstrează datele complete.
- [ ] Verifică cele opt KPI într-un singur rând la 1595/1366px și comportamentul la 1024/390/350 px; nu trebuie să existe overflow orizontal global.
- [ ] Verifică numele VM lungi, 10+ porturi, două VM-uri într-un serviciu, lizibilitatea policy-urilor și exportul SVG.

## De verificat în staging — Hartă rețea 0.21.46

- [ ] Verifică în Chrome/Firefox la 1595/1366/1024/390 px scrollul numai în diagramă, fără intercalare cu navigarea laterală sticky.
- [ ] Verifică în SVG VM cu un singur nod și servicii/porturi multe, precum și hartă de serviciu cu două sau mai multe VM-uri; conexiunile către porturi trebuie să rămână la nodul corect.
- [ ] Verifică fluxuri FortiGate cu multe obiecte sursă/destinație și servicii, expandare/restrângere liste, inclusiv alinierea dintre DECLARAT și Corelate.
- [ ] Verifică exportul SVG, opțiunea +N pentru adresele din diagramă, linkurile din noduri și panourile DECLARAT/Corelate.

## De verificat în staging — Server 0.21.45

- [ ] Verifică VM → Securitate → Hardening pe date reale: trei carduri compacte aliniate (Profil de evaluare / Evaluare curentă / Profil aplicat), funcționalitatea Salvează profilul, RBAC fără drept de editare și actualizarea corectă a datelor după salvare.
- [ ] Verifică Export Excel în dreapta antetului „Controale evaluate”, fișierul descărcat per VM și compatibilitatea cu modurile light/dark.
- [ ] Verifică marcajul roșu BETA ca semn de carte în colțul superior drept (VM, raport Securitate, Nomenclatoare) și nota de validare de jos, fără suprapuneri sau interpretare drept eroare tehnică.
- [ ] Verifică Hardening → Securitate pe date reale: **BETA** vizibil, KPI corecți, search/filtre limitate la pagina curentă, Reset, paginare 10/25/50/100, export și RBAC.
- [ ] Verifică Hardening pe fișa VM și în Nomenclatoare (marcaj BETA, meniuri, salvare profil Draft/clone, fără schimbări de calcul).
- [ ] Verifică Firewall central/per VM (FortiGate și Local): nu mai există săgeata `↕` izolată; reviziile în trei coloane și detaliile policy rămân funcționale.
- [ ] Confirmă în staging Chrome/Firefox la 1595/1024/390 px și contrastul dark/light, inclusiv meniul sticky.
- [ ] Verifică în Firefox/Chrome la rezoluțiile reale că FortiGate/Local sunt în stânga pe același rând cu celelalte carduri în dreapta și există distanța centrală dorită; testează și pagina centrală, și fișa VM.
- [ ] Verifică indicatorul „Revizuite X din Y” aliniat la dreapta și fără atingerea marginii tabelului, inclusiv la redimensionare.
- [ ] Verifică Policy # aliniat cu celelalte celule și expandarea detaliilor, fără schimbări ale scrollului sau reviziilor.
- [ ] Confirmă `GOPROXY=off go test ./...` și `make build` cu `vendor/` local; testează pe MariaDB reală.

## Amânate explicit — reluăm după maturizarea aplicației

### 1. Integrare Wazuh prin API — AMÂNAT

- Scop: Wazuh ca sursă externă pentru Security Configuration Assessment (SCA), politici CIS-referenced și ulterior vulnerabilități.
- VM-DOC rămâne proprietarul inventarului de VM/servicii/beneficiari și al rapoartelor de impact; nu devine scanner de securitate complet.
- Corelare agenți Wazuh cu VM-DOC prin ID legat persistent, FQDN/hostname/IP cu rezolvare manuală a ambiguităților.
- API read-only pentru agenți, politici și rezultate SCA; sincronizare programată, stare sursă, erori/timeout, paginare, export și Swagger.
- Autentificare cu permisiuni minime, TLS verificat și secrete ținute numai în server (niciodată în exporturi, Outline sau documente).
- Raportarea distinge explicit **Wazuh SCA** de **VM-DOC Baseline**. Scorurile nu se adună ca și cum ar folosi același set de reguli.
- Fază separată pentru vulnerabilități/CVE și impact pe VM, servicii și departamente.
- **Nu se implementează acum.** Hardening-ul existent rămâne baseline pentru VM-uri fără agent Wazuh, inclusiv legacy. Șabloanele draft Apache/Nginx/DB rămân pentru viitor, fără pretenție de conformitate CIS completă.

### 2. Consolă shell SSH din fișa VM, chei prin Vault — AMÂNAT

- Scop: sesiune SSH interactivă către VM din interfața VM-DOC, folosind credențiale/chei gestionate în Vault.
- Design obligatoriu înainte de implementare: RBAC separat, permisiuni pe VM/mediu, MFA/reautentificare după caz, aprobare pentru acces privilegiat.
- Sesiuni proxy prin backend controlat; nici cheia SSH, nici tokenul Vault nu sunt expuse browserului, jurnalelor sau documentației exportate.
- Audit sesiune (cine, VM, timp, acțiuni și rezultat), limite de timp, revocare, izolare, rate-limit; gestiunea înregistrării sesiunii după politica de confidențialitate.
- Verificări anti-SSRF/host-key și control destinație; nu permite comenzi arbitrare prin funcția obișnuită de colectare agent.
- **Nu se implementează acum.** Necesită model de securitate, review și test de intruziune înainte de activare PROD.

### Verificări pentru Firewall 0.21.41 — de făcut în staging

- [ ] Verifică ambele moduri FortiGate/Local în Firewall central și fișa VM, inclusiv VM-uri fără inventar local, reguli UFW/firewalld/SuSEfirewall2 și reguli nftables/iptables directe.
- [ ] Verifică revizia individuală a firewall-ului local, revizia colectivă pe un singur VM, auditul, rollback-ul, comportamentul cu reguli șterse/recolectate și faptul că filtrele vizuale nu limitează greșit revizia.
- [ ] Compară exporturile XLSX FortiGate și Local cu inventarul real, mai ales policy/VDOM/NAT, obiecte/servicii multiple și datele reviziilor.
- [ ] Testează compactarea la 1595/1024/390 px și navigarea cu tastatura pe tabelul scrollabil; măsoară memoria Chrome și verifică absența suprapunerii cu meniul global.

## Validare 0.21.42 — staging

- [ ] Verifică în interfața reală Securitate → Firewall: FortiGate/Local ca două carduri, butoane Export/Revizuiește în panel-header, Policy # cu expandarea detaliilor sub rând, fără coloană Detalii.
- [ ] Verifică reviziile individuale FortiGate și locale în cele trei coloane (Revizuit / De / Next review), inclusiv cazuri expirate și fără revizie; verifică după salvare progresul „Revizuite X din Y”.
- [ ] Verifică în Database Access numărătoarea per principal Users/Grants și per regulă HBA; în Web ACL numărătoarea per site. Nu confunda cele 20.000 de granturi obiect cu unitățile de revizie per principal.
- [ ] Testează exporturile și bulk review existente cu RBAC/CSRF și date MariaDB reale. Confirmă că patchul JS/CSS nu schimbă identitatea/istoricul reviziilor.

## Următoarea direcție activă

1. [ ] Verifică vizual în staging **Securitate 0.21.41**, cu date reale: Dashboard, Conturi VM (politică parole și conturi system colapsabile fără checkbox, popup review), Database Access (revizii pe principal DB), Web ACL, Firewall/Caută, Surse & Sync, Analiză și Hardening. Verifică panourile la 1595/1024/390 px, selecțiile active, review-urile și resetarea filtrelor.
2. [ ] Testează în staging salvarea și raportarea review-urilor DB per principal: utilizatori omonimi pe instanțe diferite, user@host, reconciliere după colectare, date istorice de review pe instanță; verifică lipsa modificărilor de review ale conturilor system.
3. [ ] Confirmă `go test ./...` și `make build` cu `vendor/` pe serverul offline; optimizează eventualele ecrane lente pe date MariaDB reale.
4. [ ] Confirmă migrarea 078 și beneficiarii Compose, precum și afișarea beneficiarilor DB agregați; nu modifica retrospectiv asocierile existente.
5. [ ] Păstrează backlogurile Wazuh și Shell SSH prin Vault amânate până la maturizarea aplicației și aprobarea măsurilor de securitate.

- [ ] Validează în staging formularul popup de revizie pentru cont relevant, principal DB, Web ACL și Firewall: revizor/date server-side, precompletare, anulare, drepturi RBAC, afișare Next review și tratarea erorilor API.

- [ ] Validează UI 0.21.34: trei coloane Revizuit/De/Next review la Conturi VM (inclusiv system), DB principals, Web ACL, Firewall; data+ora pe un rând, rândurile nerevizuite colspan=3 și nume VM/cont corecte în popup. Testează salvarea cu RBAC și MariaDB real.

- [ ] **0.21.35:** testează pe serverul offline cu `vendor/`: `go test ./...`, `make build`, noul endpoint `PUT /api/v1/security/review/bulk`, autentificarea, drepturile, CSRF și tranzacțiile MySQL/MariaDB. Încearcă operații bulk pe VM/instanțe DB cu review deja existent, apoi review individual și verifică auditul.
- [ ] **0.21.35:** în staging, compară gruparea 2.000+ granturi cu inventarul brut `access_json` la PostgreSQL, verifică păstrarea `DENY` / `GRANT OPTION` / `source`, roluri custom NOLOGIN și filtrele în Calendar revizii.
- [ ] **0.21.35:** verifică paginile Securitate Database Access, Conturi, Web ACL la lățimile 1595 / 1024 / 390 cu date reale și performanța la tabele foarte mari. Confirma popup-ul bulk cu observații obligatorii și corelația cu VM-ul selectat.

- [ ] **0.21.36:** execută `go test ./...` și `make build` cu vendor/ offline; testează GET `/api/v1/security/databases/export` cu 1, 2, 3 sheet-uri, 20.000+ grants și `vm_id`; confirmă că workbook include toate granturile fără trunchiere.
- [ ] **0.21.36:** validează DB bulk pe `database_principals`, `database_grants` și `database_hba` exclusiv per instanță; asigură că review-ul Users nu afectează Grants/HBA, că cele individuale pot suprascrie colectivul și că drepturile RBAC/CSRF/audit funcționează.
- [ ] **0.21.36:** testează identitatea granturilor după resync și reconcilierea HBA după schimbarea numerelor de linie; decide dacă este dorit un mecanism explicit de invalidare automată a review-ului pe apariția de privilegii noi.
- [ ] **0.21.36:** în Chromium cu inventar real: un server cu 20k grants / 282 grupuri în versiunea anterioară, grupare efectiv per user, expand și încărcare câte 200; PostgreSQL HBA explicat fără warnings redundante; MySQL fără HBA.

- [ ] **0.21.37 · P1 memorie:** profilare cu Chrome Task Manager (Shift+Esc), DevTools → Memory (heap snapshots și Detached DOM), Performance Monitor, compară 0.21.36 vs 0.21.37 pe aceleași VM-uri: Securitate Dashboard, Conturi, DB PostgreSQL 20k+ grants, pagini VM și navigări repetate. Notează memory footprint/JS heap per tab și response size /api/v1/security?section=... .
- [ ] **0.21.37:** verifică proiectarea API și consistența KPI la toate secțiunile cu MariaDB reală; verifică pagina Review după schimbarea secțiunii, Export Excel și aplicațiile care consumă vechiul GET /api/v1/security fără parametrul section.
- [ ] **Optimizare viitoare:** endpoint paginat server-side pentru DB Access, cu granturi încărcate per instanță/utilizator numai la expand; noua proiecție secțiune încă transportă toate DB/grants când fila Database Access este deschisă. Implementare cu filtre/căutare server-side și test de stabilitate 20k+.

- [ ] **0.21.38:** verifică vizibilitatea permanentă a butonului „Aplică revizia” și a checkbox-ului la zoom 100%/125%/150%, pe 390/1024/1595 px, inclusiv în ferestre Chrome cu înălțime mică, cu texte lungi și erori API.
- [ ] **0.21.38:** verifică revizia individuală Grants pe roluri/user@host reale, păstrarea datei/verificatorului, extensia exclusivă a grupurilor tehnice și memoria la 20k+ granturi.

- [ ] **Validare Web ACL 0.21.39:** verifică site-uri Nginx/Apache cu/fără ACL, ALLOW ALL, review în summary, revizie colectivă, export global și per VM. Confirmă numărul de rânduri din Excel, sursele include și memoria Chrome după navigare.

- [ ] **0.21.40 · Web ACL UI:** validează în staging panoul Filtre global și per VM la 1595/1024/390/350 px; ambele butoane vizibile când panoul este restrâns, căutare generală, bifa Doar cele cu ACL, reset, schimbare VM, filtre persistente în același VM. Confirmă că revizia globală fără VM selectat nu se execută și că filtrarea UI nu limitează scopul reviziei colective sau exportul Excel.

- [ ] Verificare pe Keycloak real: mapper `department` în ID token, logout/login și afișare în header după 0.21.75.
