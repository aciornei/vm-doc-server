package auth

import "testing"

func TestOIDCDisplayNameLDAPConvention(t *testing.T) {
	cases := []struct {
		name            string
		claims          map[string]any
		departmentClaim string
		want            string
	}{
		{"full profile", map[string]any{"given_name": "Daniel", "family_name": "Popescu", "name": "Daniel Popescu", "department": "IT"}, "", "Popescu Daniel (IT)"},
		{"spaces", map[string]any{"given_name": " Ana  Maria ", "family_name": "  Ionescu", "department": "Financiar  Contabil"}, "", "Ionescu Ana Maria (Financiar Contabil)"},
		{"no department", map[string]any{"given_name": "Daniel", "family_name": "Popescu"}, "", "Popescu Daniel"},
		{"custom flat claim", map[string]any{"given_name": "Maria", "family_name": "Stan", "org_unit": "Resurse Umane"}, "org_unit", "Stan Maria (Resurse Umane)"},
		{"nested claim", map[string]any{"given_name": "Maria", "family_name": "Stan", "attributes": map[string]any{"department": "Suport"}}, "attributes.department", "Stan Maria (Suport)"},
		{"one element claim array", map[string]any{"given_name": "Ion", "family_name": "Dumitru", "department": []any{"Securitate"}}, "", "Dumitru Ion (Securitate)"},
		{"no first/last fallback", map[string]any{"name": "Maria Popescu", "department": "IT"}, "", "Maria Popescu (IT)"},
		{"partial claims fallback", map[string]any{"given_name": "Maria", "name": "Maria Stan"}, "", "Maria Stan"},
		{"username fallback", map[string]any{"preferred_username": "m.stan"}, "", "m.stan"},
		{"nothing available", map[string]any{}, "", ""},
		{"do not duplicate department", map[string]any{"name": "Stan Maria (IT)", "department": "IT"}, "", "Stan Maria (IT)"},
		{"reject multi department values", map[string]any{"given_name": "Maria", "family_name": "Stan", "department": []any{"IT", "HR"}}, "", "Stan Maria"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got := oidcDisplayName(c.claims, c.departmentClaim)
			if got != c.want {
				t.Fatalf("oidcDisplayName()=%q want %q", got, c.want)
			}
		})
	}
}
