package auth

import "strings"

// oidcDisplayName matches the AD display convention in the application header:
// surname first, given name second, optional department in parentheses.
// Only presentation data is changed; subject, username and groups are untouched.
func oidcDisplayName(claims map[string]any, departmentClaim string) string {
	family := cleanOIDCString(oidcStringClaim(claims, "family_name"))
	given := cleanOIDCString(oidcStringClaim(claims, "given_name"))
	name := strings.TrimSpace(strings.Join([]string{family, given}, " "))
	if family == "" || given == "" {
		// A partial name must not discard names provided in the full OIDC claim.
		if fallback := cleanOIDCString(oidcStringClaim(claims, "name")); fallback != "" {
			name = fallback
		}
	}
	if name == "" {
		name = cleanOIDCString(oidcStringClaim(claims, "preferred_username"))
	}
	if departmentClaim == "" {
		departmentClaim = "department"
	}
	department := cleanOIDCString(oidcStringClaim(claims, departmentClaim))
	if department != "" && name != "" && !strings.HasSuffix(name, "("+department+")") {
		name += " (" + department + ")"
	}
	return name
}

func cleanOIDCString(value string) string { return strings.Join(strings.Fields(value), " ") }

// Supports a flat custom claim ("department") or a nested mapping
// ("attributes.department") for installations that expose nested claims.
func oidcStringClaim(claims map[string]any, path string) string {
	if value, ok := claims[path]; ok {
		return oidcClaimText(value)
	}
	var current any = claims
	for _, part := range strings.Split(path, ".") {
		node, ok := current.(map[string]any)
		if !ok {
			return ""
		}
		current, ok = node[part]
		if !ok {
			return ""
		}
	}
	return oidcClaimText(current)
}

func oidcClaimText(value any) string {
	switch v := value.(type) {
	case string:
		return v
	case []any:
		if len(v) == 1 {
			return oidcClaimText(v[0])
		}
	case []string:
		if len(v) == 1 {
			return v[0]
		}
	}
	return ""
}
