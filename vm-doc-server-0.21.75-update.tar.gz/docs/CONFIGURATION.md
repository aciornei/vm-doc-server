# Configuration

Configurația este YAML și păstrează `version: 1`. Parolele globale nu se introduc în `config.yaml`; parolele surselor vCenter și tokenurile agenților sunt criptate individual în MariaDB.

## vCenter

```yaml
vcenter:
  allow_http: false
  request_timeout: "60s"
  detail_workers: 8
  scheduler_interval: "1m"
```

- `allow_http`: numai pentru laborator; în producție trebuie să fie `false`;
- `request_timeout`: timeout pentru cererile REST vCenter;
- `detail_workers`: numărul de VM-uri citite concurent, între 1 și 64;
- `scheduler_interval`: frecvența cu care serverul verifică programările zilnice.

Ora fiecărei surse se configurează în interfață și este interpretată folosind `app.timezone`.

## Collector

`collector.allowed_networks` trebuie restrâns la rețelele în care se află VM-urile. Conexiunea către agent este directă, fără proxy HTTP și fără redirecturi.

În producție, `collector.allow_http` trebuie să rămână `false`, iar `verify_tls` trebuie activat pentru agenți.

## Autoînregistrarea agenților

```yaml
agent_registration:
  enabled: true
  max_request_body_bytes: 26214400
```

Tokenul se află în fișierul criptat de secrete sub cheia `agent_registration_token`.

## Directorul Active Directory pentru persoane

Importul persoanelor utilizează conexiunea LDAP de citire și secretele tehnice `ldap_bind_dn`/`ldap_bind_password`, independent de loginul LDAP. Astfel, `auth.ldap.enabled: false` dezactivează autentificarea pe bază de parolă în VM-DOC, iar `auth.ldap.directory.enabled: true` păstrează importul responsabililor, persoanelor, beneficiarilor și OU-urilor din AD. Căutarea folosește un OU rădăcină dedicat:

```yaml
auth:
  ldap:
    enabled: false  # doar login LDAP; nu oprește importul AD
    hosts: ["dc01.example.ro:636", "dc02.example.ro:636"]
    mode: "ldaps"
    base_dn: "DC=example,DC=ro"
    user_base_dn: "OU=Users,DC=example,DC=ro"
    user_filter: "(&(objectClass=user)(sAMAccountName={username}))"
    username_attribute: "sAMAccountName"
    display_name_attribute: "displayName"
    email_attribute: "mail"
    groups_attribute: "memberOf"
    directory:
      enabled: true
      base_dn: "OU=Users,DC=example,DC=ro"
      user_filter: "(&(objectCategory=person)(objectClass=user)(!(objectClass=computer))(!(userAccountControl:1.2.840.113556.1.4.803:=2)))"
      identity_attribute: "objectGUID"
      department_attribute: "department"
      phone_attribute: "telephoneNumber"
      page_size: 500
      default_department: ""
```

`directory.base_dn` este parcurs cu scope subtree. `identity_attribute` este implicit `objectGUID`, pentru identificare stabilă chiar dacă utilizatorul este mutat între sub-OU-uri. Interfața afișează sub-OU-urile ca arbore, dar filtrarea principală se face după `department`. Dacă `default_department` este gol sau nu există în AD, se selectează primul departament în ordine alfabetică.

Contul din `ldap_bind_dn` trebuie să aibă drepturi de citire pentru atributele configurate. Parola rămâne numai în fișierul criptat de secrete.

## Retenție inventory_snapshots (0.13.0)

```yaml
inventory:
  accepted_schema_major: 2
  retain_snapshots_per_agent: 30
  retain_days: 90
  cleanup_interval: "24h"
```

`retain_snapshots_per_agent` și `retain_days` se aplică împreună. Inventarul curent și snapshot-urile referite de documente generate nu sunt șterse.

### Pagina de autentificare (0.21.74)

`GET /api/v1/auth/providers` indică separat `ldap`, `oidc` și `dev`. Pagina Login afișează metodele active: numai Keycloak pentru configurația OIDC-only, fără formular LDAP sau separator „sau”. Contul tehnic LDAP **nu este o metodă de login**. Serverul refuză direct autentificarea LDAP când aceasta este dezactivată.

### Numele afișat pentru OIDC/Keycloak (0.21.75)

`auth.oidc.department_claim` (implicit `department`) indică claim-ul de departament din **ID token**, nu din LDAP. Configurați un mapper Keycloak `User Attribute` cu `Token Claim Name=department` și `Add to ID token=ON`. Sunt necesare `family_name` și `given_name` din scope `profile` pentru ordinea `Nume Prenume`; dacă lipsesc, aplicația folosește `name` fără să încerce să inverseze automat cuvintele. `display_name` se actualizează la următorul login OIDC; LDAP rămâne pe `displayName`.
