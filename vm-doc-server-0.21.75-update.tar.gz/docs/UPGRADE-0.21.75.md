# Upgrade VM-DOC Server 0.21.74 → 0.21.75

1. Back-up pentru directorul sursă, configurația `config.yaml` și binarul curent; nu există migrare SQL nouă.
2. Din **directorul de surse 0.21.74**, aplică patch-ul sau dezarhivează `vm-doc-server-0.21.75-update.tar.gz` (nu peste un alt director, cu versiune diferită).
3. Pentru upgrade TAR: rulează `bash scripts/cleanup-source-tree.sh --dry-run`, apoi `bash scripts/cleanup-source-tree.sh --apply` dacă există documente istorice în rădăcină. Acest pas este obligatoriu înainte de `make build`; vechiul `UPGRADE-0.21.74.md` este mutat în `docs/history/upgrades/`.
4. În `config.yaml`, sub `auth.oidc`, adaugă opțional `department_claim: "department"`. Dacă lipsește se folosește `department` implicit. Nu dezactiva directorul LDAP folosit pentru responsabili.
5. Verifică în Keycloak că ID tokenul conține `given_name`, `family_name`, `department` (mapper User Attribute, claim `department`, ID token = ON). Nu publica tokenul în jurnale.
6. Pe serverul offline, cu dependențe `vendor/`: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
7. Oprește serviciul, instalează `bin/vm-doc-server` în calea reală din `systemctl cat vm-doc-server`, repornește-l și verifică jurnalele.
8. Logout/login prin Keycloak; bara dreapta sus arată `Nume Prenume (Departament)`. Dacă departamentul lipsește, verifică maparea tokenului. LDAP păstrează displayName existent.

## Rollback

Restabilește binarul vechi 0.21.74 și configurația anterioară (noua opțiune poate fi ignorată de parsere, dar recomandată restaurarea). Nu există date de migrat înapoi.
