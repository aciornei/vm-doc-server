# VM-DOC Server 0.21.75 — Afișare utilizator Keycloak / LDAP

## Comportament

- LDAP rămâne **neschimbat**: `display_name` vine din AD `displayName`, conform `auth.ldap.display_name_attribute`.
- OIDC (Keycloak) afișează `family_name` + `given_name` + ` (department)` când toate claim-urile sunt disponibile: **Popescu Daniel (IT)**.
- `auth.oidc.department_claim` este opțional, implicit `department`; poate fi și `attributes.department` dacă tokenul are structură nested.
- În lipsa departamentului, nu se afișează `()`; în lipsa `given_name` sau `family_name`, se folosește `name` fără inversare nesigură a numelui.
- Nicio schimbare la `username`, `sub`, `groups`, login, RBAC, LDAP directory, import beneficiari/OU/persoane.

## Keycloak — configurare necesară

OIDC **nu include standard** departamentul în ID token. În Keycloak, pentru clientul VM-DOC (sau client scope dedicat), configurează un mapper de tip **User Attribute**: User Attribute = `department` (sau atributul importat din AD), Token Claim Name = `department`, Claim JSON Type = `String`, **Add to ID token = ON**. Dacă valoarea nu există în profilul Keycloak, configurează maparea atributului prin LDAP federation sau sincronizarea profilului. Pentru nume, verifică prezența `given_name` și `family_name` prin scope `profile`.

După modificare, fă logout și login Keycloak; valoarea `display_name` din tabela `users` se actualizează la autentificare, iar browserul o preia prin `/api/v1/auth/me`. Nu modifica manual tabela și nu adăuga departamentul în `preferred_username`.

## Testare/limitări

- Teste unitare pentru format și fallback, fără dependințe externe; testele complete auth/LDAP/OIDC necesită `vendor/` pe serverul offline.
- Nicio migrare SQL, niciun update de agent.
- Direct upgrade de la **0.21.74**; patch și update sunt pentru sursele, nu pentru binarul precompilat. Fișierele web sunt `go:embed`, deci recompilează și înlocuiește binarul serverului.
