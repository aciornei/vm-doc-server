# Upgrade VM-DOC Server 0.20.87 → 0.20.88

Hotfix exclusiv UI pentru panoul Firewall.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.87 vm-doc-server-0.20.88
tar -xzf /cale/vm-doc-server-0.20.88-update.tar.gz -C vm-doc-server-0.20.88
cd vm-doc-server-0.20.88
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Instalați binarul, reporniți `vm-doc-server`, apoi faceți `Ctrl+F5` în browser.

Nu există migrare DB și nu este necesar update de agent.
