# Upgrade vm-doc-server 0.20.0 → 0.20.1

0.20.1 este un update de server/UI/documentație. **Nu are migrare DB** și nu necesită o versiune nouă de vm-doc-agent.

## Noutăți

- generarea fișei serviciului are o bifă nouă **Lipește anexele A1, A2… în același document**;
- anexele VM integrate sunt introduse în același DOCX, fiecare pe pagină nouă, păstrând numerotarea A1, A2 etc.;
- opțiunea pentru pachetul ZIP rămâne separată;
- documentele DOCX încărcate la **Documentație suplimentară a serviciului** sunt inserate în capitolul 2 cu formatarea Word originală păstrată prin `altChunk`;
- din `VM-uri asociate` dispare coloana `Fișă VM`;
- din `Monitorizare` dispar `Versiune`, `Targets`, `Probe`;
- din `Backup și restaurare` dispar `Job`, `Storage`;
- mediile sunt afișate cu cod uppercase: `PROD`, `TEST`, `DEV`.

## Upgrade offline recomandat

Porniți de la sursa 0.20.0 care **deja compilează pe serverul vostru** și care are perechea corectă `go.mod` + `go.sum` + `vendor/`:

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.0 vm-doc-server-0.20.1
tar -xzf /cale/vm-doc-server-0.20.1-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.1
cd /usr/local/src/vm-doc-server-0.20.1

GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build

systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

Nu rulați `go mod vendor` pe serverul izolat și nu înlocuiți `vendor/`, `go.mod` sau `go.sum` care funcționează deja în 0.20.0.

După upgrade faceți `Ctrl+F5` în browser.

## Verificare

1. `/version` trebuie să raporteze `0.20.1`.
2. La generarea fișei serviciului verificați noua bifă pentru anexele integrate.
3. Generați o fișă cu bifa activă și verificați A1/A2 în același DOCX.
4. Încărcați un DOCX formatat în Documentație suplimentară și verificați formatarea în capitolul 2.
5. Verificați tabelele simplificate Monitorizare și Backup și mediile PROD/TEST/DEV.

## Compatibilitate

- baza de date 0.20.0 rămâne neschimbată; migrarea 047 rămâne ultima;
- nu este necesar update de agent;
- pentru păstrarea exactă a formatării documentului suplimentar este recomandat Microsoft Word, care procesează nativ `altChunk`.
