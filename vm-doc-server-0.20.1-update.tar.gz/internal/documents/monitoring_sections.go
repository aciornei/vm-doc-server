package documents

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

func monitoringStateLabel(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "monitored":
		return "Monitorizat · UP"
	case "down":
		return "Monitorizat · DOWN"
	case "exporter_only":
		return "Node Exporter activ · fără target Prometheus"
	case "exporter_stopped":
		return "Node Exporter instalat · oprit"
	case "unmonitored":
		return "Nemonitorizat"
	default:
		return "Neverificat"
	}
}

func monitoringYesNo(value bool) string {
	if value {
		return "Da"
	}
	return "Nu"
}

func monitoringUpDown(monitored, up bool) string {
	if !monitored {
		return "Nu"
	}
	if up {
		return "UP"
	}
	return "DOWN"
}

func exporterStateLabel(installed, running bool) string {
	if !installed {
		return "Absent"
	}
	if running {
		return "Activ"
	}
	return "Oprit"
}

func monitoringTargetState(target domain.MonitoringTarget) string {
	if target.SourceType == "blackbox" && target.ProbeSuccess != nil {
		if *target.ProbeSuccess {
			return "UP"
		}
		return "DOWN"
	}
	if strings.EqualFold(strings.TrimSpace(target.Health), "up") {
		return "UP"
	}
	if strings.TrimSpace(target.Health) != "" {
		return strings.ToUpper(strings.TrimSpace(target.Health))
	}
	return "Necunoscut"
}

func monitoringMatchLabel(target domain.MonitoringTarget) string {
	method := strings.TrimSpace(target.MatchMethod)
	value := strings.TrimSpace(target.MatchValue)
	if method == "" {
		return "—"
	}
	labels := map[string]string{
		"label":            "Label explicit",
		"fqdn":             "FQDN",
		"hostname":         "Hostname",
		"ip":               "IP",
		"prometheus_hosts": "/etc/hosts Prometheus",
		"alias":            "Alias manual",
	}
	if label, ok := labels[method]; ok {
		method = label
	}
	if value != "" {
		return method + " · " + value
	}
	return method
}

func monitoringPreviewRows(summary domain.VMMonitoringSummary) []PreviewRow {
	rows := []PreviewRow{
		{Label: "Stare generală", Value: monitoringStateLabel(summary.MonitoringState)},
		{Label: "Node Exporter", Value: strings.Join(nonEmpty(exporterStateLabel(summary.ExporterInstalled, summary.ExporterRunning), summary.ExporterVersion, summary.ExporterEndpoint), " · ")},
		{Label: "Prometheus metrics", Value: fmt.Sprintf("%s · %d targeturi", monitoringUpDown(summary.MetricsMonitored, summary.MetricsUp), len(summary.MetricsTargets))},
		{Label: "Blackbox", Value: fmt.Sprintf("%s · %d probe", monitoringUpDown(summary.BlackboxMonitored, summary.BlackboxUp), len(summary.BlackboxTargets))},
	}
	for _, target := range summary.MetricsTargets {
		label := firstNonEmpty(target.Instance, target.ScrapeURL, target.JobName, "target metrics")
		value := strings.Join(nonEmpty(target.PrometheusSourceName, target.JobName, monitoringTargetState(target), monitoringMatchLabel(target)), " · ")
		rows = append(rows, PreviewRow{Label: "Metrics · " + label, Value: value})
	}
	for _, target := range summary.BlackboxTargets {
		label := firstNonEmpty(target.TargetURL, target.Instance, target.ScrapeURL, "probe blackbox")
		details := []string{target.PrometheusSourceName, monitoringTargetState(target)}
		if target.HTTPStatusCode != nil {
			details = append(details, "HTTP "+strconv.Itoa(*target.HTTPStatusCode))
		}
		if target.ProbeDurationSeconds != nil {
			details = append(details, fmt.Sprintf("%.3fs", *target.ProbeDurationSeconds))
		}
		if target.TLSExpiryAt != nil {
			details = append(details, "TLS expiră "+formatMonitoringTime(target.TLSExpiryAt))
		}
		details = append(details, monitoringMatchLabel(target))
		rows = append(rows, PreviewRow{Label: "Blackbox · " + label, Value: strings.Join(nonEmpty(details...), " · ")})
	}
	return rows
}

func monitoringDocumentXML(summary domain.VMMonitoringSummary) string {
	var out strings.Builder
	out.WriteString(keyValueTable([]PreviewRow{
		{Label: "Stare generală", Value: monitoringStateLabel(summary.MonitoringState)},
		{Label: "Node Exporter instalat", Value: monitoringYesNo(summary.ExporterInstalled)},
		{Label: "Node Exporter activ", Value: monitoringYesNo(summary.ExporterRunning)},
		{Label: "Versiune Node Exporter", Value: firstNonEmpty(summary.ExporterVersion, "—")},
		{Label: "Endpoint Node Exporter", Value: firstNonEmpty(summary.ExporterEndpoint, "—")},
		{Label: "Prometheus metrics", Value: monitoringUpDown(summary.MetricsMonitored, summary.MetricsUp)},
		{Label: "Targeturi metrics", Value: strconv.Itoa(len(summary.MetricsTargets))},
		{Label: "Blackbox", Value: monitoringUpDown(summary.BlackboxMonitored, summary.BlackboxUp)},
		{Label: "Probe Blackbox", Value: strconv.Itoa(len(summary.BlackboxTargets))},
	}))

	if len(summary.MetricsTargets) > 0 {
		rows := make([][]string, 0, len(summary.MetricsTargets))
		for _, target := range summary.MetricsTargets {
			rows = append(rows, []string{
				firstNonEmpty(target.PrometheusSourceName, "—"),
				firstNonEmpty(target.JobName, "—"),
				firstNonEmpty(target.Instance, target.ScrapeURL, "—"),
				monitoringTargetState(target),
				monitoringMatchLabel(target),
				formatMonitoringTime(target.LastScrapeAt),
			})
		}
		out.WriteString(heading("Targeturi Prometheus metrics", 3))
		out.WriteString(tableWithWidths([]string{"Sursă", "Job", "Target", "Stare", "Corelare", "Ultimul scrape"}, rows, []int{1500, 1400, 2200, 800, 1900, 1200}))
	}

	if len(summary.BlackboxTargets) > 0 {
		rows := make([][]string, 0, len(summary.BlackboxTargets))
		for _, target := range summary.BlackboxTargets {
			httpStatus := "—"
			if target.HTTPStatusCode != nil {
				httpStatus = strconv.Itoa(*target.HTTPStatusCode)
			}
			duration := "—"
			if target.ProbeDurationSeconds != nil {
				duration = fmt.Sprintf("%.3fs", *target.ProbeDurationSeconds)
			}
			rows = append(rows, []string{
				firstNonEmpty(target.PrometheusSourceName, "—"),
				firstNonEmpty(target.TargetURL, target.Instance, target.ScrapeURL, "—"),
				monitoringTargetState(target),
				httpStatus,
				duration,
				formatMonitoringTime(target.TLSExpiryAt),
				monitoringMatchLabel(target),
			})
		}
		out.WriteString(heading("Probe Blackbox", 3))
		out.WriteString(tableWithWidths([]string{"Sursă", "Țintă", "Stare", "HTTP", "Durată", "Expirare TLS", "Corelare"}, rows, []int{1200, 2100, 700, 600, 750, 1150, 1600}))
	}
	return out.String()
}

func serviceMonitoringPreviewRows(items []ServiceVMMonitoring) []PreviewRow {
	rows := make([]PreviewRow, 0, len(items))
	for _, item := range items {
		summary := item.Monitoring
		value := strings.Join(nonEmpty(
			firstNonEmpty(environmentCode(item.Environment), "mediu nespecificat"),
			monitoringStateLabel(summary.MonitoringState),
			"Node Exporter: "+exporterStateLabel(summary.ExporterInstalled, summary.ExporterRunning),
			"Prometheus: "+monitoringUpDown(summary.MetricsMonitored, summary.MetricsUp),
			"Blackbox: "+monitoringUpDown(summary.BlackboxMonitored, summary.BlackboxUp),
		), " · ")
		rows = append(rows, PreviewRow{Label: item.VMName, Value: value})
	}
	return rows
}

func serviceMonitoringXML(items []ServiceVMMonitoring) string {
	if len(items) == 0 {
		return paragraph("Nu există informații de monitorizare pentru VM-urile serviciului.", "IntenseQuote")
	}
	rows := make([][]string, 0, len(items))
	for _, item := range items {
		summary := item.Monitoring
		rows = append(rows, []string{
			item.VMName,
			emptyDash(environmentCode(item.Environment)),
			monitoringStateLabel(summary.MonitoringState),
			exporterStateLabel(summary.ExporterInstalled, summary.ExporterRunning),
			monitoringUpDown(summary.MetricsMonitored, summary.MetricsUp),
			monitoringUpDown(summary.BlackboxMonitored, summary.BlackboxUp),
		})
	}
	return tableWithWidths([]string{"VM", "Mediu", "Stare", "Node Exporter", "Prometheus", "Blackbox"}, rows, []int{1900, 900, 2000, 1400, 1400, 1400})
}

func formatMonitoringTime(value *time.Time) string {
	if value == nil || value.IsZero() {
		return "—"
	}
	return formatTime(*value)
}
