# Upgrade vm-doc-server 0.18.0 → 0.18.1

0.18.1 stabilizează integrarea Veeam și extinde afișarea/documentația backupurilor.

## Pași

1. Opriți `vm-doc-server`.
2. Aplicați `vm-doc-server-0.18.1-update.tar.gz` peste o copie a sursei 0.18.0.
3. Rulați testele/buildul offline cu directorul `vendor/` existent.
4. Instalați noul binar și porniți `vm-doc-server`.
5. Faceți `Ctrl+F5` în browser.
6. În **Backup**, rulați din nou **Sync** pentru sursa Veeam; sincronizarea repopulează Job, Repository și Next run folosind corelarea corectată.

Nu există migrare DB nouă. `vm-doc-agent 1.6.2` rămâne neschimbat.

Pentru sincronizare zilnică, editați sursa existentă și setați `1440` minute. Sursele noi folosesc implicit 1440 minute.
