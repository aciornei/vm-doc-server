# Integrarea Veeam Backup & Replication

## Scop

vm-doc-server citește în mod read-only starea backupurilor din Veeam Backup & Replication și o corelează cu VM-urile deja importate din vCenter.

## Conectare

Pentru VBR 12.1, porniți cu:

- URL: `https://<veeam-server>:9419`
- REST API / `x-api-version`: `1.1-rev1`
- interval sincronizare recomandat: `1440` minute (o dată pe zi)
- verificare TLS: activă

Folosiți un cont dedicat cu rolul **Veeam Backup Viewer**. Test-ul vm-doc folosește un endpoint read-only și nu necesită Backup Administrator. Parola este criptată de vm-doc-server cu aceeași cheie master folosită pentru celelalte secrete dinamice și nu este returnată prin API/UI.

Dacă serverul Veeam folosește certificat intern, soluția recomandată este ca sistemul vm-doc-server să aibă încredere în CA-ul intern. Dezactivarea verificării TLS există pentru test/compatibilitate, dar nu este recomandată permanent.

## Date citite

Sincronizarea folosește REST API pentru:

- obiecte protejate (`backupObjects`);
- backupuri (`backups`);
- starea joburilor (`jobs/states`);
- cel mai recent restore point per obiect corelat.

vm-doc nu pornește joburi, nu șterge restore points și nu modifică configurația Veeam.

## Corelare

Corelarea este strictă și deterministă:

```text
Veeam backup object name == vm-doc virtual machine name
```

Nu se face fuzzy matching. Dacă nu există exact un singur VM cu acel nume, obiectul este lăsat neasociat și apare în contorul `Neasociate / ambigue` al sincronizării.

## Date salvate per VM

În `vm_backup_summary` se actualizează:

- `protected`;
- sursa Veeam;
- jobul/joburile;
- repository-ul/repository-urile;
- ultimul rezultat al jobului;
- data celui mai nou restore point;
- următoarea rulare cunoscută;
- numărul total de restore points;
- ultima sincronizare și eventualele erori.

Datele sunt afișate în fila dedicată **Backup** din pagina VM, inclusiv lanțurile Veeam corelate, și sunt disponibile generatorului de fișe VM. Fișa serviciului include la rândul ei un tabel de backup pentru toate VM-urile asociate.
În plus, meniul global **Backup** oferă tabel paginat, căutare și filtre separate după protecție, power state și rezultat.

## Scheduler

Fiecare sursă are propriul `sync_interval_minutes`. Implicit pentru sursele noi: 1440 minute (o dată pe zi). Sursele existente își păstrează intervalul deja configurat. Scheduler-ul global verifică periodic dacă o sursă este scadentă și evită două sincronizări simultane pentru aceeași sursă.
