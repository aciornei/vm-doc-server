package config

import (
	"strings"
	"testing"
	"time"
)

func validConfigForTest() Config {
	cfg := Config{
		Version:           1,
		App:               AppConfig{Environment: "test", Timezone: "Europe/Bucharest"},
		Database:          DatabaseConfig{Host: "db", Name: "vm_doc", User: "vm_doc"},
		Secrets:           SecretsConfig{EncryptedFile: "/tmp/secrets", MasterKeyEnv: "TEST_KEY"},
		Session:           SessionConfig{IdleTimeout: Duration(time.Minute), AbsoluteTimeout: Duration(time.Hour)},
		Auth:              AuthConfig{Dev: DevConfig{Enabled: true}},
		Collector:         CollectorConfig{Workers: 1},
		VCenter:           VCenterConfig{RequestTimeout: Duration(time.Minute), DetailWorkers: 4, SchedulerInterval: Duration(time.Minute)},
		Veeam:             VeeamConfig{RequestTimeout: Duration(time.Minute), SchedulerInterval: Duration(time.Minute)},
		AgentRegistration: AgentRegistrationConfig{MaxRequestBody: 25 << 20},
		OpenAPI:           OpenAPIConfig{SwaggerPath: "/docs/"},
	}
	applyDefaults(&cfg)
	return cfg
}

func TestValidateVCenterSchedulerAndTimezone(t *testing.T) {
	cfg := validConfigForTest()
	if err := cfg.Validate(); err != nil {
		t.Fatalf("valid config: %v", err)
	}
	cfg.App.Timezone = "Invalid/Timezone"
	cfg.VCenter.SchedulerInterval = Duration(-time.Second)
	err := cfg.Validate()
	if err == nil || !strings.Contains(err.Error(), "invalid app.timezone") || !strings.Contains(err.Error(), "scheduler_interval") {
		t.Fatalf("unexpected validation error: %v", err)
	}
}

func TestLDAPDirectoryDefaults(t *testing.T) {
	cfg := validConfigForTest()
	cfg.Auth.Dev.Enabled = false
	cfg.Auth.LDAP = LDAPConfig{
		Enabled:           true,
		Hosts:             []string{"ldap.example.test:636"},
		UserBaseDN:        "OU=Users,DC=example,DC=test",
		UsernameAttribute: "sAMAccountName",
		Directory:         LDAPDirectoryConfig{Enabled: true},
	}
	applyDefaults(&cfg)
	if cfg.Auth.LDAP.Directory.BaseDN != cfg.Auth.LDAP.UserBaseDN {
		t.Fatalf("unexpected directory base DN: %q", cfg.Auth.LDAP.Directory.BaseDN)
	}
	if cfg.Auth.LDAP.Directory.IdentityAttribute != "objectGUID" || cfg.Auth.LDAP.Directory.DepartmentAttribute != "department" || cfg.Auth.LDAP.Directory.PageSize != 500 {
		t.Fatalf("unexpected directory defaults: %#v", cfg.Auth.LDAP.Directory)
	}
	if err := cfg.Validate(); err != nil {
		t.Fatalf("valid LDAP directory config: %v", err)
	}
}

func TestLDAPDirectoryRequiresLDAP(t *testing.T) {
	cfg := validConfigForTest()
	cfg.Auth.LDAP.Directory = LDAPDirectoryConfig{Enabled: true, BaseDN: "OU=Users,DC=example,DC=test", PageSize: 500}
	err := cfg.Validate()
	if err == nil || !strings.Contains(err.Error(), "requires auth.ldap.enabled") {
		t.Fatalf("unexpected validation error: %v", err)
	}
}

func TestLDAPDirectoryRejectsInvalidAttribute(t *testing.T) {
	cfg := validConfigForTest()
	cfg.Auth.Dev.Enabled = false
	cfg.Auth.LDAP = LDAPConfig{
		Enabled: true,
		Hosts:   []string{"ldap.example.test:636"},
		Directory: LDAPDirectoryConfig{
			Enabled:             true,
			BaseDN:              "OU=Users,DC=example,DC=test",
			IdentityAttribute:   "objectGUID",
			DepartmentAttribute: "department)(cn=*",
			PhoneAttribute:      "telephoneNumber",
			PageSize:            500,
		},
	}
	err := cfg.Validate()
	if err == nil || !strings.Contains(err.Error(), "department_attribute is invalid") {
		t.Fatalf("unexpected validation error: %v", err)
	}
}
