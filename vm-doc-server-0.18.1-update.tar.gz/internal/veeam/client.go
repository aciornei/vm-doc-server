package veeam

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

const maxResponseSize = 32 << 20

type Client struct {
	baseURL    *url.URL
	username   string
	password   string
	apiVersion string
	http       *http.Client
}

type tokenResponse struct {
	AccessToken string `json:"access_token"`
}

type Pagination struct {
	Total int `json:"total"`
	Count int `json:"count"`
	Skip  int `json:"skip"`
	Limit int `json:"limit"`
}

type ServerInfo struct {
	VBRID          string `json:"vbrId"`
	Name           string `json:"name"`
	BuildVersion   string `json:"buildVersion"`
	DatabaseVendor string `json:"databaseVendor"`
}

type BackupObject struct {
	VIType             string `json:"viType"`
	ObjectID           string `json:"objectId"`
	Path               string `json:"path"`
	PlatformName       any    `json:"platformName"`
	BackupID           string `json:"backupId"`
	ID                 string `json:"id"`
	Name               string `json:"name"`
	Type               string `json:"type"`
	RestorePointsCount int    `json:"restorePointsCount"`
}

type Backup struct {
	PlatformName   any    `json:"platformName"`
	ID             string `json:"id"`
	JobID          string `json:"jobId"`
	JobType        string `json:"jobType"`
	PolicyUniqueID string `json:"policyUniqueId"`
	Name           string `json:"name"`
	CreationTime   *VTime `json:"creationTime"`
	RepositoryID   string `json:"repositoryId"`
	RepositoryName string `json:"repositoryName"`
}

type JobState struct {
	Type           string `json:"type"`
	Status         string `json:"status"`
	LastResult     string `json:"lastResult"`
	Workload       string `json:"workload"`
	ID             string `json:"id"`
	Name           string `json:"name"`
	LastRun        *VTime `json:"lastRun"`
	NextRun        *VTime `json:"nextRun"`
	RepositoryID   string `json:"repositoryId"`
	RepositoryName string `json:"repositoryName"`
}

type RestorePoint struct {
	ID           string `json:"id"`
	Name         string `json:"name"`
	Type         string `json:"type"`
	PlatformName any    `json:"platformName"`
	CreationTime *VTime `json:"creationTime"`
	BackupID     string `json:"backupId"`
}

type VTime struct{ time.Time }

func (t *VTime) UnmarshalJSON(data []byte) error {
	if string(data) == "null" || string(data) == `""` {
		return nil
	}
	var value string
	if err := json.Unmarshal(data, &value); err != nil {
		return err
	}
	parsed, err := time.Parse(time.RFC3339Nano, value)
	if err != nil {
		return err
	}
	t.Time = parsed
	return nil
}

type backupObjectResult struct {
	Data       []BackupObject `json:"data"`
	Pagination Pagination     `json:"pagination"`
}
type backupResult struct {
	Data       []Backup   `json:"data"`
	Pagination Pagination `json:"pagination"`
}
type jobStateResult struct {
	Data       []JobState `json:"data"`
	Pagination Pagination `json:"pagination"`
}
type restorePointResult struct {
	Data       []RestorePoint `json:"data"`
	Pagination Pagination     `json:"pagination"`
}

func NewClient(source domain.VeeamSource, password string, timeout time.Duration) (*Client, error) {
	base, err := url.Parse(strings.TrimRight(source.BaseURL, "/"))
	if err != nil || base.Scheme == "" || base.Host == "" {
		return nil, errors.New("invalid Veeam base URL")
	}
	if timeout <= 0 {
		timeout = 60 * time.Second
	}
	transport := &http.Transport{
		Proxy: nil,
		TLSClientConfig: &tls.Config{
			MinVersion:         tls.VersionTLS12,
			ServerName:         source.TLSServerName,
			InsecureSkipVerify: !source.VerifyTLS, // Explicitly configurable for internal/self-signed VBR certificates.
		},
		ForceAttemptHTTP2: true,
	}
	return &Client{
		baseURL:    base,
		username:   source.Username,
		password:   password,
		apiVersion: strings.TrimSpace(source.APIVersion),
		http:       &http.Client{Transport: transport, Timeout: timeout},
	}, nil
}

func (c *Client) Test(ctx context.Context) (ServerInfo, int, error) {
	token, err := c.login(ctx)
	if err != nil {
		return ServerInfo{}, 0, err
	}
	// /serverInfo requires administrative rights in some VBR builds. Test a
	// read-only endpoint so a dedicated Backup Viewer account is sufficient.
	var page backupObjectResult
	if err := c.get(ctx, token, "/api/v1/backupObjects", url.Values{"skip": {"0"}, "limit": {"1"}}, &page); err != nil {
		return ServerInfo{}, 0, fmt.Errorf("read Veeam backup objects: %w", err)
	}
	total := page.Pagination.Total
	if total == 0 {
		total = len(page.Data)
	}
	return ServerInfo{}, total, nil
}

func (c *Client) Inventory(ctx context.Context) ([]BackupObject, map[string]Backup, map[string]JobState, string, error) {
	token, err := c.login(ctx)
	if err != nil {
		return nil, nil, nil, "", err
	}
	objects, err := c.listBackupObjects(ctx, token)
	if err != nil {
		return nil, nil, nil, "", fmt.Errorf("list Veeam backup objects: %w", err)
	}
	backups, err := c.listBackups(ctx, token)
	if err != nil {
		return nil, nil, nil, "", fmt.Errorf("list Veeam backups: %w", err)
	}
	jobs, err := c.listJobStates(ctx, token)
	if err != nil {
		return nil, nil, nil, "", fmt.Errorf("list Veeam job states: %w", err)
	}
	backupMap := make(map[string]Backup, len(backups))
	for _, item := range backups {
		if key := normalizeID(item.ID); key != "" {
			backupMap[key] = item
		}
	}
	jobMap := make(map[string]JobState, len(jobs)*2)
	for _, item := range jobs {
		if key := normalizeID(item.ID); key != "" {
			jobMap[key] = item
		}
		if name := normalizeName(item.Name); name != "" {
			jobMap["name:"+name] = item
		}
	}
	return objects, backupMap, jobMap, token, nil
}

func (c *Client) LatestRestorePoint(ctx context.Context, token, objectID string) (*RestorePoint, error) {
	var page restorePointResult
	values := url.Values{"skip": {"0"}, "limit": {"1"}, "orderColumn": {"CreationTime"}, "orderAsc": {"false"}}
	if err := c.get(ctx, token, "/api/v1/backupObjects/"+url.PathEscape(objectID)+"/restorePoints", values, &page); err != nil {
		return nil, err
	}
	if len(page.Data) == 0 {
		return nil, nil
	}
	return &page.Data[0], nil
}

func normalizeID(v string) string {
	v = strings.TrimSpace(v)
	v = strings.TrimPrefix(v, "{")
	v = strings.TrimSuffix(v, "}")
	return strings.ToLower(v)
}

func normalizeName(v string) string { return strings.ToLower(strings.TrimSpace(v)) }

func (c *Client) login(ctx context.Context) (string, error) {
	version := c.apiVersion
	if version == "" || strings.EqualFold(version, "auto") {
		version = "1.1-rev1"
	}
	form := url.Values{}
	form.Set("grant_type", "password")
	form.Set("username", c.username)
	form.Set("password", c.password)
	req, err := c.request(ctx, http.MethodPost, "/api/oauth2/token", nil, strings.NewReader(form.Encode()))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("x-api-version", version)
	var token tokenResponse
	if err := c.do(req, &token); err != nil {
		return "", fmt.Errorf("Veeam authentication failed (x-api-version %s): %w", version, err)
	}
	if token.AccessToken == "" {
		return "", errors.New("Veeam authentication returned no access token")
	}
	c.apiVersion = version
	return token.AccessToken, nil
}

func (c *Client) listBackupObjects(ctx context.Context, token string) ([]BackupObject, error) {
	var out []BackupObject
	for skip := 0; ; {
		var page backupObjectResult
		if err := c.get(ctx, token, "/api/v1/backupObjects", url.Values{"skip": {strconv.Itoa(skip)}, "limit": {"200"}}, &page); err != nil {
			return nil, err
		}
		out = append(out, page.Data...)
		skip += len(page.Data)
		if len(page.Data) == 0 || (page.Pagination.Total > 0 && skip >= page.Pagination.Total) || len(page.Data) < 200 {
			break
		}
	}
	return out, nil
}

func (c *Client) listBackups(ctx context.Context, token string) ([]Backup, error) {
	var out []Backup
	for skip := 0; ; {
		var page backupResult
		if err := c.get(ctx, token, "/api/v1/backups", url.Values{"skip": {strconv.Itoa(skip)}, "limit": {"200"}}, &page); err != nil {
			return nil, err
		}
		out = append(out, page.Data...)
		skip += len(page.Data)
		if len(page.Data) == 0 || (page.Pagination.Total > 0 && skip >= page.Pagination.Total) || len(page.Data) < 200 {
			break
		}
	}
	return out, nil
}

func (c *Client) listJobStates(ctx context.Context, token string) ([]JobState, error) {
	var out []JobState
	for skip := 0; ; {
		var page jobStateResult
		if err := c.get(ctx, token, "/api/v1/jobs/states", url.Values{"skip": {strconv.Itoa(skip)}, "limit": {"200"}}, &page); err != nil {
			return nil, err
		}
		out = append(out, page.Data...)
		skip += len(page.Data)
		if len(page.Data) == 0 || (page.Pagination.Total > 0 && skip >= page.Pagination.Total) || len(page.Data) < 200 {
			break
		}
	}
	return out, nil
}

func (c *Client) get(ctx context.Context, token, path string, query url.Values, target any) error {
	req, err := c.request(ctx, http.MethodGet, path, query, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("x-api-version", c.apiVersion)
	return c.do(req, target)
}

func (c *Client) request(ctx context.Context, method, path string, query url.Values, body io.Reader) (*http.Request, error) {
	ref, err := url.Parse(path)
	if err != nil {
		return nil, err
	}
	target := c.baseURL.ResolveReference(ref)
	if query != nil {
		target.RawQuery = query.Encode()
	}
	return http.NewRequestWithContext(ctx, method, target.String(), body)
}

func (c *Client) do(req *http.Request, target any) error {
	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	reader := io.LimitReader(resp.Body, maxResponseSize+1)
	body, err := io.ReadAll(reader)
	if err != nil {
		return err
	}
	if len(body) > maxResponseSize {
		return errors.New("Veeam response exceeds size limit")
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		message := strings.TrimSpace(string(body))
		var problem struct {
			Message string `json:"message"`
			Error   string `json:"error"`
		}
		if json.Unmarshal(body, &problem) == nil {
			if problem.Message != "" {
				message = problem.Message
			} else if problem.Error != "" {
				message = problem.Error
			}
		}
		if len(message) > 700 {
			message = message[:700]
		}
		return fmt.Errorf("HTTP %d %s: %s", resp.StatusCode, resp.Status, message)
	}
	if target == nil || len(strings.TrimSpace(string(body))) == 0 {
		return nil
	}
	if err := json.Unmarshal(body, target); err != nil {
		return fmt.Errorf("decode Veeam response: %w", err)
	}
	return nil
}
