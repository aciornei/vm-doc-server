package buildinfo

var (
	Version = "0.18.1-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
