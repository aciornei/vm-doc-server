# Upgrade vm-doc-server 0.19.0 → 0.19.1

0.19.1 este un bugfix pentru fundația de monitorizare. Agentul rămâne 1.6.2 și nu există migrare nouă de bază de date.

## Schimbări

- o sursă `metrics` și una `blackbox` pot indica același Prometheus fără dublarea targeturilor;
- `metrics` exclude targeturile Blackbox;
- `blackbox` importă numai targeturile cu `/probe` / `__param_target`;
- butonul Test raportează numărul de targeturi după filtrarea sursei;
- conexiunile Prometheus ocolesc `HTTP_PROXY` / `HTTPS_PROXY`.

## Pași

1. Aplicați `vm-doc-server-0.19.1-update.tar.gz` peste o copie a sursei 0.19.0.
2. Rulați `gofmt`/test/build offline cu `vendor/`.
3. Instalați binarul `vm-doc-server`; collectorul și agentul nu trebuie schimbate.
4. Faceți `Ctrl+F5`.
5. Rulați Sync pe sursa `metrics`, apoi pe sursa `blackbox`. Targeturile importate greșit de 0.19.0 vor fi marcate automat `present=0`.
6. Verificați că sursa `metrics` conține doar targeturile normale, iar `blackbox` doar probele HTTP/HTTPS.
