package monitoring

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
)

func TestIsBlackboxTarget(t *testing.T) {
	tests := []struct {
		name   string
		target ActiveTarget
		want   bool
	}{
		{
			name: "param target",
			target: ActiveTarget{DiscoveredLabels: map[string]string{
				"__param_target": "https://example.test/health",
			}},
			want: true,
		},
		{
			name: "metrics path",
			target: ActiveTarget{DiscoveredLabels: map[string]string{
				"__metrics_path__": "/probe",
			}},
			want: true,
		},
		{
			name:   "scrape url",
			target: ActiveTarget{ScrapeURL: "http://blackbox:9115/probe?module=http_2xx&target=https%3A%2F%2Fexample.test"},
			want:   true,
		},
		{
			name: "node exporter",
			target: ActiveTarget{
				DiscoveredLabels: map[string]string{"__metrics_path__": "/metrics", "__address__": "10.0.0.10:9100"},
				ScrapeURL:        "http://10.0.0.10:9100/metrics",
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := IsBlackboxTarget(tt.target); got != tt.want {
				t.Fatalf("IsBlackboxTarget()=%v want %v", got, tt.want)
			}
		})
	}
}

func TestFilterTargetsSeparatesLogicalSources(t *testing.T) {
	node := ActiveTarget{ScrapePool: "node", ScrapeURL: "http://vm01:9100/metrics"}
	blackbox := ActiveTarget{ScrapePool: "http", ScrapeURL: "http://blackbox:9115/probe?target=https://app.example.test", DiscoveredLabels: map[string]string{"__param_target": "https://app.example.test"}}
	all := []ActiveTarget{node, blackbox}

	metrics := FilterTargets("metrics", all)
	if len(metrics) != 1 || metrics[0].ScrapePool != "node" {
		t.Fatalf("metrics filter returned %#v", metrics)
	}
	probes := FilterTargets("blackbox", all)
	if len(probes) != 1 || probes[0].ScrapePool != "http" {
		t.Fatalf("blackbox filter returned %#v", probes)
	}
}

func TestPrometheusClientDoesNotUseEnvironmentProxy(t *testing.T) {
	client, err := NewClient(domain.PrometheusSource{BaseURL: "http://127.0.0.1:9090", SourceType: "metrics"}, "", time.Second)
	if err != nil {
		t.Fatal(err)
	}
	transport, ok := client.http.Transport.(*http.Transport)
	if !ok {
		t.Fatalf("unexpected transport type %T", client.http.Transport)
	}
	if transport.Proxy != nil {
		t.Fatal("Prometheus transport must bypass environment proxy")
	}
}

func TestClientTestCountsOnlyMatchingSourceType(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/v1/status/buildinfo":
			w.Write([]byte(`{"status":"success","data":{"version":"3.0.0","revision":"abc"}}`))
		case "/api/v1/targets":
			w.Write([]byte(`{"status":"success","data":{"activeTargets":[{"scrapePool":"node","scrapeUrl":"http://vm01:9100/metrics","health":"up"},{"scrapePool":"http","scrapeUrl":"http://blackbox:9115/probe?target=https%3A%2F%2Fapp.example.test","discoveredLabels":{"__param_target":"https://app.example.test","__metrics_path__":"/probe"},"health":"up"}]}}`))
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()

	for _, tt := range []struct {
		name       string
		sourceType string
		want       int
	}{{"metrics", "metrics", 1}, {"blackbox", "blackbox", 1}} {
		t.Run(tt.name, func(t *testing.T) {
			client, err := NewClient(domain.PrometheusSource{BaseURL: server.URL, SourceType: tt.sourceType}, "", time.Second)
			if err != nil {
				t.Fatal(err)
			}
			build, count, err := client.Test(context.Background())
			if err != nil {
				t.Fatal(err)
			}
			if build.Version != "3.0.0" || count != tt.want {
				t.Fatalf("version=%q count=%d want count=%d", build.Version, count, tt.want)
			}
		})
	}
}
