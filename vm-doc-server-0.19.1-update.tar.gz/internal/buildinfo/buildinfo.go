package buildinfo

var (
	Version = "0.19.1-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
