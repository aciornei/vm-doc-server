-- 0.20.37: catalog controlat pentru sisteme de operare nesuportate.
INSERT IGNORE INTO nomenclature_categories(code,label,sort_order,active)
VALUES ('unsupported_os','Sisteme de operare nesuportate',90,1);

UPDATE nomenclature_categories
SET label='Sisteme de operare nesuportate',sort_order=90,active=1
WHERE code='unsupported_os';
