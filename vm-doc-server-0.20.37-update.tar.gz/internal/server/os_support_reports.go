package server

import (
	"context"
	"net/http"
	"regexp"
	"sort"
	"strings"
	"time"

	"vm-doc-server/internal/xlsx"
)

type unsupportedOSRule struct {
	ID          int64
	Name        string
	VersionCode string
	Description string
}

type osSupportReportRow struct {
	VMID            int64  `json:"vm_id"`
	VMName          string `json:"vm_name"`
	Hostname        string `json:"hostname"`
	Environment     string `json:"environment"`
	IP              string `json:"ip"`
	OSName          string `json:"os_name"`
	OSVersion       string `json:"os_version"`
	Status          string `json:"status"`
	MatchedRule     string `json:"matched_rule,omitempty"`
	MatchedRuleNote string `json:"matched_rule_note,omitempty"`
	OutlinePublish  bool   `json:"outline_publish"`
}

type osSupportReportSummary struct {
	Total        int `json:"total"`
	Supported    int `json:"supported"`
	Unsupported  int `json:"unsupported"`
	Undetermined int `json:"undetermined"`
}

type osSupportReportResponse struct {
	GeneratedAt time.Time              `json:"generated_at"`
	Summary     osSupportReportSummary `json:"summary"`
	StatusChart []reportPoint          `json:"status_chart"`
	EnvChart    []reportPoint          `json:"unsupported_environment_chart"`
	OSChart     []reportPoint          `json:"unsupported_os_chart"`
	Rows        []osSupportReportRow   `json:"rows"`
}

var osMatchSeparators = regexp.MustCompile(`[^a-z0-9.]+`)

func normalizeOSMatch(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	value = strings.ReplaceAll(value, "ț", "t")
	value = strings.ReplaceAll(value, "ţ", "t")
	value = strings.ReplaceAll(value, "ș", "s")
	value = strings.ReplaceAll(value, "ş", "s")
	value = strings.ReplaceAll(value, "ă", "a")
	value = strings.ReplaceAll(value, "â", "a")
	value = strings.ReplaceAll(value, "î", "i")
	value = osMatchSeparators.ReplaceAllString(value, "-")
	return strings.Trim(value, "-")
}

func osRuleMatches(rule unsupportedOSRule, osName, osVersion string) bool {
	ruleName := normalizeOSMatch(rule.Name)
	name := normalizeOSMatch(osName)
	if ruleName == "" || name == "" || !strings.Contains(name, ruleName) {
		return false
	}
	versionRule := normalizeOSMatch(rule.VersionCode)
	if versionRule == "" {
		return true
	}
	version := normalizeOSMatch(osVersion)
	if version != "" && strings.HasPrefix(version, versionRule) {
		return true
	}
	// Util pentru Windows, unde anul poate apărea în os_name, iar os_version este build-ul NT.
	return strings.Contains(name, versionRule)
}

func (a *App) activeUnsupportedOSRules(ctx context.Context) ([]unsupportedOSRule, error) {
	rows, err := a.DB.QueryContext(ctx, `SELECT id,name,COALESCE(item_code,''),COALESCE(description,'')
        FROM nomenclature_items
        WHERE category_code='unsupported_os' AND active=1
        ORDER BY sort_order,name,id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]unsupportedOSRule, 0)
	for rows.Next() {
		var item unsupportedOSRule
		if err := rows.Scan(&item.ID, &item.Name, &item.VersionCode, &item.Description); err != nil {
			return nil, err
		}
		out = append(out, item)
	}
	return out, rows.Err()
}

func (a *App) osSupportReport(ctx context.Context) (osSupportReportResponse, error) {
	out := osSupportReportResponse{GeneratedAt: time.Now().UTC(), Rows: []osSupportReportRow{}}
	rules, err := a.activeUnsupportedOSRules(ctx)
	if err != nil {
		return out, err
	}
	outlineEnabled := false
	if a.Outline != nil {
		if settings, settingsErr := a.Outline.GetSettings(ctx); settingsErr == nil {
			outlineEnabled = settings.Enabled
		}
	}
	rows, err := a.DB.QueryContext(ctx, `SELECT vm.id,vm.name,
        COALESCE(NULLIF(i.hostname,''),NULLIF(vm.guest_hostname,''),''),
        COALESCE(m.environment,''),
        COALESCE(NULLIF(m.preferred_ip,''),NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,''),''),
        COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),''),
        COALESCE(i.os_version,''),
        vm.outline_documentation_disabled
        FROM virtual_machines vm
        LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id
        LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id
        WHERE vm.retired=0
        ORDER BY LOWER(vm.name),vm.id`)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var row osSupportReportRow
		var outlineDisabled bool
		if err := rows.Scan(&row.VMID, &row.VMName, &row.Hostname, &row.Environment, &row.IP, &row.OSName, &row.OSVersion, &outlineDisabled); err != nil {
			return out, err
		}
		row.OutlinePublish = outlineEnabled && !outlineDisabled
		if strings.TrimSpace(row.OSName) == "" {
			row.Status = "undetermined"
		} else {
			row.Status = "supported"
			for _, rule := range rules {
				if osRuleMatches(rule, row.OSName, row.OSVersion) {
					row.Status = "unsupported"
					row.MatchedRule = strings.TrimSpace(rule.Name)
					if strings.TrimSpace(rule.VersionCode) != "" {
						row.MatchedRule += " " + strings.TrimSpace(rule.VersionCode)
					}
					row.MatchedRuleNote = rule.Description
					break
				}
			}
		}
		out.Rows = append(out.Rows, row)
	}
	if err := rows.Err(); err != nil {
		return out, err
	}
	out.Summary = summarizeOSSupportRows(out.Rows)
	out.StatusChart = []reportPoint{{Label: "Suportate", Value: int64(out.Summary.Supported)}, {Label: "Nesuportate", Value: int64(out.Summary.Unsupported)}, {Label: "Nedeterminat", Value: int64(out.Summary.Undetermined)}}
	envCounts := map[string]int64{}
	osCounts := map[string]int64{}
	for _, row := range out.Rows {
		if row.Status != "unsupported" {
			continue
		}
		env := strings.TrimSpace(row.Environment)
		if env == "" {
			env = "Nespecificat"
		}
		envCounts[env]++
		name := strings.TrimSpace(row.OSName)
		if row.OSVersion != "" {
			name += " " + strings.TrimSpace(row.OSVersion)
		}
		if name == "" {
			name = "Nespecificat"
		}
		osCounts[name]++
	}
	out.EnvChart = mapReportPoints(envCounts)
	out.OSChart = mapReportPoints(osCounts)
	return out, nil
}

func mapReportPoints(values map[string]int64) []reportPoint {
	out := make([]reportPoint, 0, len(values))
	for label, value := range values {
		out = append(out, reportPoint{Label: label, Value: value})
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Value != out[j].Value {
			return out[i].Value > out[j].Value
		}
		return strings.ToLower(out[i].Label) < strings.ToLower(out[j].Label)
	})
	return out
}

func summarizeOSSupportRows(rows []osSupportReportRow) osSupportReportSummary {
	s := osSupportReportSummary{Total: len(rows)}
	for _, row := range rows {
		switch row.Status {
		case "supported":
			s.Supported++
		case "unsupported":
			s.Unsupported++
		default:
			s.Undetermined++
		}
	}
	return s
}

func (a *App) reportsOSSupport(w http.ResponseWriter, r *http.Request) {
	value, err := a.osSupportReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, value)
}

func (a *App) exportReportOSSupport(w http.ResponseWriter, r *http.Request) {
	value, err := a.osSupportReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	wanted := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("status")))
	rows := [][]xlsx.Cell{{xlsx.Text("Stare suport"), xlsx.Text("VM"), xlsx.Text("Hostname"), xlsx.Text("Mediu"), xlsx.Text("IP"), xlsx.Text("Sistem de operare"), xlsx.Text("Versiune"), xlsx.Text("Regulă nesuportat"), xlsx.Text("Observații"), xlsx.Text("Publicare Outline")}}
	for _, item := range value.Rows {
		if wanted != "" && item.Status != wanted {
			continue
		}
		label := map[string]string{"supported": "Suportat", "unsupported": "Nesuportat", "undetermined": "Nedeterminat"}[item.Status]
		rows = append(rows, []xlsx.Cell{xlsx.Text(label), xlsx.Text(item.VMName), xlsx.Text(item.Hostname), xlsx.Text(item.Environment), xlsx.Text(item.IP), xlsx.Text(item.OSName), xlsx.Text(item.OSVersion), xlsx.Text(item.MatchedRule), xlsx.Text(item.MatchedRuleNote), xlsx.Text(yesNo(item.OutlinePublish))})
	}
	if err := writeXLSXResponse(w, "Suport OS", "suport-os", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write OS support report XLSX", "error", err)
	}
}
