package server

import "testing"

func TestOSRuleMatches(t *testing.T) {
	tests := []struct {
		name      string
		rule      unsupportedOSRule
		osName    string
		osVersion string
		want      bool
	}{
		{"centos7", unsupportedOSRule{Name: "CentOS", VersionCode: "7"}, "CentOS Linux", "7.9.2009", true},
		{"centos8not7", unsupportedOSRule{Name: "CentOS", VersionCode: "7"}, "CentOS Linux", "8.5", false},
		{"ubuntu2004", unsupportedOSRule{Name: "Ubuntu", VersionCode: "20.04"}, "Ubuntu", "20.04.6 LTS", true},
		{"allDebian", unsupportedOSRule{Name: "Debian"}, "Debian GNU/Linux", "11", true},
		{"windowsYearInName", unsupportedOSRule{Name: "Windows Server 2008", VersionCode: "2008-r2"}, "Microsoft Windows Server 2008 R2 Standard", "6.1.7601", true},
		{"differentFamily", unsupportedOSRule{Name: "CentOS", VersionCode: "7"}, "Ubuntu", "20.04", false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := osRuleMatches(tt.rule, tt.osName, tt.osVersion); got != tt.want {
				t.Fatalf("osRuleMatches()=%v want %v", got, tt.want)
			}
		})
	}
}
