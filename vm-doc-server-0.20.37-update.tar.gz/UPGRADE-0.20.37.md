# Upgrade vm-doc-server 0.20.36 -> 0.20.37

Versiunea 0.20.37 adaugă raportarea suportului sistemelor de operare și vizibilitatea publicării Outline. Nu necesită update de vm-doc-agent.

## Schimbări

- Nomenclatoare → **Sisteme de operare nesuportate**.
- O regulă folosește **Sistem / familie OS** și opțional **Versiune / familie**; versiunea se potrivește ca prefix normalizat.
- Rapoarte → **Suport sisteme de operare**: pie chart-uri și liste Suportate / Nesuportate / Nedeterminate.
- Rapoarte → **Publicare Outline**: VM-uri și servicii, cu motivul pentru care se publică sau nu.
- Rezumatul VM și Serviciu afișează explicit starea efectivă Outline.
- Migrare nouă: `060_unsupported_os_nomenclature.up.sql`.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.36 \
      /usr/local/src/vm-doc-server-0.20.37

tar -xzf vm-doc-server-0.20.37-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.37

cd /usr/local/src/vm-doc-server-0.20.37
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

La prima pornire, serverul aplică automat migrarea 060. După restart folosește `Ctrl+F5` pentru `app.js?v=0.20.37`.
