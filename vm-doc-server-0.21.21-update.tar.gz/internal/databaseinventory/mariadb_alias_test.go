package databaseinventory

import (
	"testing"
	"vm-doc-server/internal/domain"
)

func TestMariaDBCompatAliasSuppressedOnlyWithoutMySQLInstance(t *testing.T) {
	maria := agentDatabaseEngine{Engine: "mariadb", Product: "MariaDB", Version: "mariadbd Ver 10.11.14-MariaDB"}
	mysql := agentDatabaseEngine{Engine: "mysql", Product: "MySQL", Version: "mysqld Ver 10.11.14-MariaDB"}
	pair := []agentDatabaseEngine{maria, mysql}
	if got := withoutMariaDBMySQLCompatAliases(pair, nil); len(got) != 1 || got[0].Engine != "mariadb" {
		t.Fatalf("MariaDB alias not removed: %#v", got)
	}
	if got := withoutMariaDBMySQLCompatAliases(pair, []agentDatabaseInstance{{Engine: "mysql", InstanceName: "mysql-real"}}); len(got) != 2 {
		t.Fatalf("real MySQL instance was dropped: %#v", got)
	}
	independent := agentDatabaseEngine{Engine: "mysql", Product: "MySQL", Version: "mysqld Ver 8.0.36"}
	if got := withoutMariaDBMySQLCompatAliases([]agentDatabaseEngine{maria, independent}, nil); len(got) != 2 {
		t.Fatalf("independent MySQL dropped: %#v", got)
	}
}
func TestMariaDBAliasExistingSnapshots(t *testing.T) {
	maria := domain.DatabaseEngine{Engine: "mariadb", Version: "mariadbd Ver 10.11.14-MariaDB"}
	mysql := domain.DatabaseEngine{Engine: "mysql", Version: "mysqld Ver 10.11.14-MariaDB"}
	if got := withoutPersistedMySQLCompatAliases([]domain.DatabaseEngine{maria, mysql}, nil); len(got) != 1 {
		t.Fatalf("existing alias retained: %#v", got)
	}
}
func TestMariaDBAliasRequiresVersionEvidence(t *testing.T) {
	for _, test := range []struct {
		mysql, maria string
		want         bool
	}{
		{"mysqld Ver 10.11.14-MariaDB", "mariadbd Ver 10.11.14-MariaDB", true},
		{"mysqld Ver 8.0.36", "mariadbd Ver 10.11.14-MariaDB", false},
		{"mysqld Ver 10.6.1", "mariadbd Ver 10.11.14-MariaDB", false},
		{"", "mariadbd Ver 10.11.14-MariaDB", false},
	} {
		if got := mariaDBAliasVersion(test.mysql, test.maria); got != test.want {
			t.Errorf("alias(%q,%q)=%v want=%v", test.mysql, test.maria, got, test.want)
		}
	}
}
