const state={user:null,csrf:'',timezone:'Europe/Bucharest',agents:[],sources:[],veeamSources:[],prometheusSources:[],vms:[],documentTemplates:[],agentFilters:{q:'',status:'',channel:'',page:1,pageSize:10},agentReleaseFilters:{q:'',channel:'',os:'',arch:'',validity:'',page:1,pageSize:10},serviceFilters:{q:'',domain:'',category:'',criticality:'',docStatus:'',common:'',page:1,pageSize:10},vmFilters:{q:'',power:'',agent:'',presence:'',baseline:'',serviceId:'',sourceId:'',page:1,pageSize:10},vcenterRunPaging:{page:1,pageSize:10},veeamRunPaging:{page:1,pageSize:10},veeamVMFilters:{q:'',status:'',power:'',result:'',page:1,pageSize:10},monitoringVMFilters:{q:'',state:'',power:'',page:1,pageSize:10},monitoringTargetFilters:{q:'',sourceType:'',health:'',matched:'',page:1,pageSize:10},monitoringRunPaging:{page:1,pageSize:10},vmHistory:{vmId:0,page:1,pageSize:10},changes:{q:'',category:'',changeType:'',doc:'',review:'',page:1,pageSize:10},vmChanges:{vmId:0,q:'',category:'',changeType:'',doc:'',review:'',page:1,pageSize:10},audit:{page:1,pageSize:10,q:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:null},vmAudit:{vmId:0,page:1,pageSize:10,q:'',area:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:null},serviceAudit:{serviceId:0,page:1,pageSize:10,q:'',area:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:null},externalFilters:{q:'',network:'',status:'active'},externalNetworkEdit:0,nomenclaturePaging:{},nomenclatureFilters:{},reportsData:null};
let routeGeneration=0;
let vmDetailGeneration=0;
const content=document.getElementById('content');
const title=document.getElementById('pageTitle');
const subtitle=document.getElementById('pageSubtitle');
const agentDialog=document.getElementById('agentDialog');
const agentForm=document.getElementById('agentForm');
const vcenterDialog=document.getElementById('vcenterDialog');
const vcenterForm=document.getElementById('vcenterForm');
const veeamDialog=document.getElementById('veeamDialog');
const veeamForm=document.getElementById('veeamForm');
const prometheusDialog=document.getElementById('prometheusDialog');
const prometheusForm=document.getElementById('prometheusForm');
const nomenclatureDialog=document.getElementById('nomenclatureDialog');
const nomenclatureForm=document.getElementById('nomenclatureForm');
const personDialog=document.getElementById('personDialog');
const personForm=document.getElementById('personForm');
const directoryDialog=document.getElementById('directoryDialog');
const directoryForm=document.getElementById('directoryForm');
const internalServiceDialog=document.getElementById('internalServiceDialog');
const internalServiceForm=document.getElementById('internalServiceForm');
const documentTemplateDialog=document.getElementById('documentTemplateDialog');
const documentTemplateForm=document.getElementById('documentTemplateForm');
const documentPreviewDialog=document.getElementById('documentPreviewDialog');

const rolePermissions={
  admin:new Set(['*']),
  operator:new Set(['dashboard.read','reports.read','agents.read','agents.manage','collections.read','collections.run','inventories.read','inventories.raw.read','vcenter.read','vcenter.manage','veeam.read','veeam.manage','monitoring.read','monitoring.manage','vms.manage','nomenclatures.read','services.read','services.manage','documents.read','documents.manage','external.read','external.manage']),
  viewer:new Set(['dashboard.read','reports.read','agents.read','collections.read','inventories.read','vcenter.read','veeam.read','monitoring.read','nomenclatures.read','services.read','documents.read','external.read']),
  auditor:new Set(['dashboard.read','reports.read','agents.read','collections.read','inventories.read','inventories.raw.read','audit.read','vcenter.read','veeam.read','monitoring.read','nomenclatures.read','services.read','documents.read','external.read'])
};
function can(permission){return (state.user?.roles||[]).some(role=>rolePermissions[role]?.has('*')||rolePermissions[role]?.has(permission))}

async function api(path,options={}){
  const headers={Accept:'application/json',...(options.headers||{})};
  if(options.body&&!(options.body instanceof FormData)&&!headers['Content-Type'])headers['Content-Type']='application/json';
  if(!['GET','HEAD'].includes((options.method||'GET').toUpperCase())&&state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{...options,headers});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  const type=response.headers.get('content-type')||'';
  const body=response.status===204?null:type.includes('json')?await response.json():await response.text();
  if(!response.ok)throw new Error(body?.message||body?.error||`HTTP ${response.status}`);
  return body;
}
async function postDownload(path,body,fallbackName='document'){
  const headers={Accept:'*/*','Content-Type':'application/json'};if(state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{method:'POST',headers,body:JSON.stringify(body||{})});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  if(!response.ok){const type=response.headers.get('content-type')||'';const value=type.includes('json')?await response.json():await response.text();throw new Error(value?.message||value?.error||value||`HTTP ${response.status}`)}
  const blob=await response.blob(),disposition=response.headers.get('content-disposition')||'';
  const match=disposition.match(/filename="?([^";]+)"?/i),name=(match?.[1]||fallbackName).trim();
  const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
const e=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const dt=v=>v?new Date(v).toLocaleString('ro-RO',{timeZone:state.timezone||'Europe/Bucharest'}):'—';
const badge=v=>{const text=String(v??'unknown');return `<span class="badge ${e(text.toLowerCase().replaceAll('_','-'))}">${e(text)}</span>`};
const boolText=v=>v?'Da':'Nu';
const memory=v=>v?`${(Number(v)/1024).toFixed(Number(v)>=10240?0:1)} GB`:'—';
function shortOS(v){
  const raw=String(v?.inventory_os_name||v?.guest_os||'').trim(),versionRaw=String(v?.inventory_os_version||'').trim();
  if(!raw&&!versionRaw)return '—';
  const rules=[[/windows server/i,'Windows Server'],[/windows/i,'Windows'],[/ubuntu/i,'Ubuntu'],[/debian/i,'Debian'],[/red hat enterprise|\brhel\b/i,'RHEL'],[/rocky/i,'Rocky'],[/alma/i,'AlmaLinux'],[/centos/i,'CentOS'],[/suse linux enterprise|\bsles\b/i,'SLES'],[/opensuse/i,'openSUSE']];
  let name=raw.replace(/\s*\(64-bit\)\s*/ig,' ').replace(/\s+/g,' ').trim();for(const [re,label] of rules){if(re.test(name)){name=label;break}}
  const version=(versionRaw||raw).match(/\b\d{1,4}(?:\.\d+){0,3}\b/)?.[0]||'';
  return `${name||'OS'}${version&&!name.includes(version)?` ${version}`:''}`.trim();
}
function powerShortBadge(value){const raw=String(value||'').toUpperCase(),on=raw==='POWERED_ON';return `<span class="badge ${on?'powered-on':'powered-off'}" title="${e(raw||'unknown')}">${on?'ON':'OFF'}</span>`}
function vmServiceNamesHTML(values){const names=Array.isArray(values)?values.filter(Boolean):[];if(!names.length)return '<span class="muted">—</span>';return `<div class="vm-service-tags">${names.map(name=>`<span>${e(name)}</span>`).join('')}</div>`}
function toast(message,error=false){const box=document.getElementById('toast');box.textContent=message;box.className=`toast show${error?' error':''}`;setTimeout(()=>box.className='toast',3200)}
function pageMeta(name,sub){title.textContent=name;subtitle.textContent=sub||''}
function panel(head,body,tools=''){return `<section class="panel"><div class="panel-header"><h2>${head}</h2><div class="toolbar">${tools}</div></div>${body}</section>`}
function empty(text){return `<div class="empty">${e(text)}</div>`}
function detail(label,value,mono=false){return `<div class="detail-item"><span>${e(label)}</span><div class="${mono?'mono':''}">${value??'—'}</div></div>`}
function jsonSections(raw){const entries=raw&&typeof raw==='object'&&!Array.isArray(raw)?Object.entries(raw):[['inventory',raw]];return `<div class="json-sections">${entries.map(([name,value])=>`<details><summary>${e(name)}</summary><pre class="json">${e(JSON.stringify(value,null,2))}</pre></details>`).join('')}</div>`}


function richTextFromPlain(value){
  const text=String(value??'').replace(/\r\n?/g,'\n');if(!text)return {version:1,blocks:[]};
  return {version:1,blocks:text.split('\n').map(line=>{let type='paragraph',content=line;if(/^\s*[-*•]\s+/.test(line)){type='bullet';content=line.replace(/^\s*[-*•]\s+/,'')}else if(/^\s*\d+[.)]\s+/.test(line)){type='number';content=line.replace(/^\s*\d+[.)]\s+/,'')}return {type,level:0,runs:content?[{text:content}]:[]}})};
}
function normalizeRichTextDocument(value,fallback=''){
  const source=value&&typeof value==='object'&&Array.isArray(value.blocks)?value:richTextFromPlain(fallback);
  return {version:1,blocks:source.blocks.slice(0,250).map(block=>({type:['bullet','number'].includes(block?.type)?block.type:'paragraph',level:Math.max(0,Math.min(4,Number(block?.level||0))),runs:Array.isArray(block?.runs)?block.runs.map(run=>({text:String(run?.text??''),bold:!!run?.bold,italic:!!run?.italic,underline:!!run?.underline})).filter(run=>run.text!==''):[]}))};
}
function richTextPlain(value,fallback=''){
  const doc=normalizeRichTextDocument(value,fallback);const counters=[0,0,0,0,0];let prevType='',prevLevel=0;
  return doc.blocks.map(block=>{let prefix='';const level=Math.max(0,Math.min(4,Number(block.level||0)));if(block.type==='bullet')prefix=`${'  '.repeat(level)}• `;else if(block.type==='number'){if(prevType!=='number'||level>prevLevel)counters[level]=0;for(let i=level+1;i<counters.length;i++)counters[i]=0;counters[level]++;prefix=`${'  '.repeat(level)}${counters[level]}. `}prevType=block.type;prevLevel=level;return prefix+block.runs.map(run=>run.text).join('')}).join('\n').trim();
}
function richTextRunHTML(run){
  let html=e(run.text).replace(/\n/g,'<br>');if(run.underline)html=`<u>${html}</u>`;if(run.italic)html=`<em>${html}</em>`;if(run.bold)html=`<strong>${html}</strong>`;return html;
}
function richTextView(value,fallback=''){
  const doc=normalizeRichTextDocument(value,fallback);if(!doc.blocks.length)return '<div class="rich-text-readonly empty-rich">—</div>';
  const counters=[0,0,0,0,0];let prevType='',prevLevel=0;
  const blocks=doc.blocks.map(block=>{const level=Math.max(0,Math.min(4,Number(block.level||0)));let marker='';if(block.type==='bullet')marker='•';else if(block.type==='number'){if(prevType!=='number'||level>prevLevel)counters[level]=0;for(let i=level+1;i<counters.length;i++)counters[i]=0;counters[level]++;marker=`${counters[level]}.`}prevType=block.type;prevLevel=level;const body=block.runs.map(richTextRunHTML).join('')||'<br>';return `<div class="rich-text-block ${e(block.type)} level-${level}">${marker?`<span class="rich-text-marker">${e(marker)}</span>`:''}<div>${body}</div></div>`}).join('');
  return `<div class="rich-text-readonly">${blocks}</div>`;
}
function appendRichRuns(parent,runs){
  for(const run of runs||[]){let node=document.createTextNode(String(run.text??''));if(run.underline){const tag=document.createElement('u');tag.append(node);node=tag}if(run.italic){const tag=document.createElement('em');tag.append(node);node=tag}if(run.bold){const tag=document.createElement('strong');tag.append(node);node=tag}parent.append(node)}
}
function setRichTextEditor(id,value,fallback=''){
  const editor=document.getElementById(id);if(!editor)return;const doc=normalizeRichTextDocument(value,fallback);editor.replaceChildren();
  let index=0;while(index<doc.blocks.length){const block=doc.blocks[index];if(block.type==='paragraph'){const p=document.createElement('p');appendRichRuns(p,block.runs);if(!block.runs.length)p.append(document.createElement('br'));editor.append(p);index++;continue}
    const type=block.type,level=block.level;const list=document.createElement(type==='number'?'ol':'ul');list.dataset.rtLevel=String(level);list.classList.add(`rt-level-${level}`);while(index<doc.blocks.length&&doc.blocks[index].type===type&&Number(doc.blocks[index].level||0)===level){const li=document.createElement('li');appendRichRuns(li,doc.blocks[index].runs);if(!doc.blocks[index].runs.length)li.append(document.createElement('br'));list.append(li);index++}editor.append(list)}
}
function richRunStyle(node,parentStyle){
  const style={...parentStyle};if(node.nodeType!==Node.ELEMENT_NODE)return style;const tag=node.tagName.toLowerCase();if(tag==='b'||tag==='strong')style.bold=true;if(tag==='i'||tag==='em')style.italic=true;if(tag==='u')style.underline=true;const css=node.style||{};if(css.fontWeight&&(['bold','600','700','800','900'].includes(css.fontWeight)||Number(css.fontWeight)>=600))style.bold=true;if(css.fontStyle==='italic')style.italic=true;if(String(css.textDecoration||css.textDecorationLine||'').includes('underline'))style.underline=true;return style;
}
function collectRichRuns(node,style={}){
  const runs=[];const push=(text,current)=>{if(text==='')return;const next={text,bold:!!current.bold,italic:!!current.italic,underline:!!current.underline};const last=runs[runs.length-1];if(last&&last.bold===next.bold&&last.italic===next.italic&&last.underline===next.underline)last.text+=next.text;else runs.push(next)};
  const walk=(current,currentStyle)=>{if(current.nodeType===Node.TEXT_NODE){push(current.nodeValue||'',currentStyle);return}if(current.nodeType!==Node.ELEMENT_NODE)return;const tag=current.tagName.toLowerCase();if(tag==='ul'||tag==='ol')return;if(tag==='br'){push('\n',currentStyle);return}const childStyle=richRunStyle(current,currentStyle);for(const child of current.childNodes)walk(child,childStyle)};
  for(const child of node.childNodes)walk(child,style);return runs.map(run=>({...run,text:run.text.replace(/\u00a0/g,' ')})).filter(run=>run.text!=='');
}
function richTextDocumentFromEditor(id){
  const editor=document.getElementById(id);if(!editor)return {version:1,blocks:[]};const blocks=[];
  const addBlock=(type,node,level=0)=>{const runs=collectRichRuns(node);blocks.push({type,level:Math.max(0,Math.min(4,Number(level||0))),runs})};
  const process=node=>{if(node.nodeType===Node.TEXT_NODE){if((node.nodeValue||'').trim()){const holder=document.createElement('span');holder.textContent=node.nodeValue;addBlock('paragraph',holder,0)}return}if(node.nodeType!==Node.ELEMENT_NODE)return;const tag=node.tagName.toLowerCase();if(tag==='ul'||tag==='ol'){const type=tag==='ol'?'number':'bullet';const explicitRaw=node.dataset.rtLevel;let level=explicitRaw!==undefined&&explicitRaw!==''?Number(explicitRaw):NaN;if(!Number.isFinite(level)){level=0;let nesting=0,parent=node.parentElement;while(parent&&parent!==editor){if(parent.matches?.('ul,ol')){nesting++;const baseRaw=parent.dataset.rtLevel;const base=baseRaw!==undefined&&baseRaw!==''?Number(baseRaw):NaN;if(Number.isFinite(base)){level=base+nesting;break}level=nesting}parent=parent.parentElement}}for(const li of [...node.children].filter(child=>child.tagName?.toLowerCase()==='li')){addBlock(type,li,level);for(const nested of [...li.children].filter(child=>['ul','ol'].includes(child.tagName?.toLowerCase())))process(nested)}return}if(tag==='p'||tag==='div'||tag==='blockquote'){addBlock('paragraph',node,0);for(const nested of [...node.children].filter(child=>['ul','ol'].includes(child.tagName?.toLowerCase())))process(nested);return}for(const child of node.childNodes)process(child)};
  for(const child of editor.childNodes)process(child);return normalizeRichTextDocument({version:1,blocks});
}
function bindRichTextToolbars(){
  document.querySelectorAll('.rich-text-toolbar [data-rich-command]').forEach(button=>{if(button.dataset.richBound==='1')return;button.dataset.richBound='1';button.addEventListener('mousedown',event=>{event.preventDefault();const wrapper=button.closest('[data-rich-editor]');const editor=document.getElementById(wrapper?.dataset.richEditor||'');if(!editor)return;editor.focus();document.execCommand(button.dataset.richCommand,false,null)})});
}
function richTextEditorHTML(id,label,placeholder){return `<div class="rich-text-field"><div class="rich-text-field-label" id="${e(id)}Label">${e(label)}</div><div class="rich-text-editor" data-rich-editor="${e(id)}"><div class="rich-text-toolbar" role="toolbar" aria-label="Formatare ${e(label)}"><button type="button" data-rich-command="bold" title="Bold"><strong>B</strong></button><button type="button" data-rich-command="italic" title="Italic"><em>I</em></button><button type="button" data-rich-command="underline" title="Subliniat"><u>U</u></button><span class="rich-toolbar-separator"></span><button type="button" data-rich-command="insertUnorderedList" title="Listă cu bullets">• Listă</button><button type="button" data-rich-command="insertOrderedList" title="Listă numerotată">1. Listă</button><button type="button" data-rich-command="outdent" title="Micșorează indentarea">←</button><button type="button" data-rich-command="indent" title="Mărește indentarea">→</button></div><div id="${e(id)}" class="rich-text-surface" contenteditable="true" role="textbox" aria-multiline="true" aria-labelledby="${e(id)}Label" tabindex="0" data-placeholder="${e(placeholder)}"></div></div></div>`}

async function init(){
  try{
    const versionElement=document.getElementById('appVersion');
    try{const build=await api('/version');state.timezone=build.timezone||state.timezone;if(versionElement)versionElement.textContent=`Server ${build.version||''}`.trim()}catch{if(versionElement)versionElement.textContent='Server'}
    state.user=await api('/api/v1/auth/me');state.csrf=state.user.csrf_token;
    document.getElementById('currentUser').textContent=state.user.display_name||state.user.username;
    document.querySelector('[data-page="audit"]').hidden=!can('audit.read');
    document.querySelector('[data-page="access"]').hidden=!can('rbac.manage');
    document.querySelector('[data-page="nomenclatures"]').hidden=!can('nomenclatures.read');
    document.querySelector('[data-page="services"]').hidden=!can('services.read');
    document.querySelector('[data-page="reports"]').hidden=!can('reports.read');
    document.querySelector('[data-page="documents"]').hidden=!can('documents.read');
    document.querySelector('[data-page="external"]').hidden=!can('external.read');
    document.querySelector('[data-page="changes"]').hidden=!can('inventories.read');
    document.querySelector('[data-page="backup"]').hidden=!can('veeam.read');
    document.querySelector('[data-page="monitoring"]').hidden=!can('monitoring.read');
    document.body.classList.remove('booting');route();
  }catch{location.href='/login'}
}

async function route(){
  const routeID=++routeGeneration;
  const raw=(location.hash||'#dashboard').slice(1);const [page,id,section]=raw.split('/');
  document.querySelectorAll('#nav a[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
  content.innerHTML='<div class="loading">Se încarcă…</div>';
  try{
    if(page==='dashboard')await dashboard();
    else if(page==='agents')await agentsPage(id||'list');
    else if(page==='vms'&&id&&/^\d+$/.test(id))await vmDetail(Number(id),section||'overview');
    else if(page==='vms')await vmsPage(id||'inventory');
    else if(page==='changes')await changesPage();
    else if(page==='backup')await backupPage(id||'backup');
    else if(page==='monitoring')await monitoringPage(id||'overview');
    else if(page==='services'&&id)await internalServiceDetail(Number(id),section||'overview');
    else if(page==='services')await internalServicesPage();
    else if(page==='external')await externalSystemsPage(id||'');
    else if(page==='nomenclatures')await nomenclaturesPage(id||'');
    else if(page==='documents')await documentsPage();
    else if(page==='reports')await reportsPage(id||'overview');
    else if(page==='audit')await auditPage();
    else if(page==='access')await accessPage();
    else location.hash='#dashboard';
  }catch(err){if(routeID!==routeGeneration)return;content.innerHTML=empty(err.message);toast(err.message,true)}
}

async function dashboard(){
  pageMeta('Dashboard','Starea centralizată a platformei');
  const d=await api('/api/v1/dashboard');
  content.innerHTML=`<div class="cards">
    <div class="card"><div class="label">VM-uri din vCenter</div><div class="value">${d.vms}</div></div>
    <div class="card"><div class="label">Agenți configurați</div><div class="value">${d.agents_total}</div></div>
    <div class="card"><div class="label">Agenți online</div><div class="value">${d.agents_online}</div></div>
    <div class="card"><div class="label">Joburi în așteptare</div><div class="value">${d.jobs_pending}</div></div>
  </div>${panel('Fluxul 0 → inventar',`<div class="detail-grid">${detail('0. vCenter','Lista completă de VM-uri')}${detail('1. Corelare','BIOS UUID / hostname unic')}${detail('2. Agent','Colectare JSON și stare')}${detail('3. Operațional','Status, servicii interne și istoric')}</div>`)}`;
}

function agentSectionNavigation(selected){
  const items=[['list','Listare agenți','Inventar, stare și colectare'],['releases','Release-uri agent','Publicare și auto-update']];
  return `<nav class="agent-section-tabs" aria-label="Secțiuni agenți">${items.map(([code,label,help])=>`<a href="#agents/${code}" class="${selected===code?'active':''}"><strong>${e(label)}</strong><small>${e(help)}</small></a>`).join('')}</nav>`;
}
function agentOSLabel(agent){const name=String(agent.os_name||'').trim(),version=String(agent.os_version||'').trim();return name?`${e(name)}${version?`<div class="muted">${e(version)}</div>`:''}`:'—'}
function agentManagementLabel(agent){
  let ip=String(agent?.management_ip||'').trim();
  if(!ip){try{ip=new URL(agent?.base_url||'').hostname||''}catch(_){ip=''}}
  const registration=String(agent?.registration_ip||'').trim();
  const source=registration&&registration!==ip?`<div class="muted" title="IP sursă observat la register/heartbeat">Sursă HTTP: ${e(registration)}</div>`:'';
  return ip?`<strong class="mono" title="IP folosit de server pentru Test / Colect / Update">${e(ip)}</strong>${source}`:'—';
}
function agentUpdateLabel(agent){
  const u=agent?.update||{};if(!u.known)return '<span class="muted" title="Se detectează la următorul Test, Colect sau heartbeat">—</span>';
  const channel=u.channel?badge(u.channel):'<span class="muted">necunoscut</span>';
  const detail=!u.enabled?' <span class="muted">(oprit)</span>':u.state&&u.state!=='idle'&&u.state!=='current'?`<div class="muted">${e(u.state)}${u.available_version?` · ${e(u.available_version)}`:''}</div>`:'';
  return `${channel}${detail}`;
}

function agentListTable(result){
  const f=state.agentFilters;state.agents=Array.isArray(result?.items)?result.items:[];f.page=Number(result?.page||1);
  const rows=state.agents.map(a=>{const actions=[can('collections.run')?`<button class="small secondary" data-action="test" data-id="${a.id}">Test</button><button class="small" data-action="collect" data-id="${a.id}">Colect</button>`:'',can('agents.manage')?`<button class="small" data-action="update" data-id="${a.id}">Update</button><button class="small secondary" data-action="edit" data-id="${a.id}">Edit</button><button class="small danger" data-action="delete" data-id="${a.id}">Del</button>`:''].join('');return `<tr><td><strong>${e(a.name)}</strong></td><td>${badge(a.status)}</td><td>${agentManagementLabel(a)}</td><td>${agentOSLabel(a)}</td><td><strong>${e(a.agent_version||'—')}</strong></td><td>${agentUpdateLabel(a)}</td><td class="mono">${e(a.agent_uuid||'—')}</td><td>${dt(a.last_contact_at)}<div class="muted">Colect: ${dt(a.last_success_at)}</div></td><td class="muted agent-error-cell">${e(a.last_error||'—')}</td><td><div class="actions agent-row-actions">${actions||'—'}</div></td></tr>`}).join('');
  const total=Number(result?.total||0),pages=Number(result?.pages||0),startRow=total?(f.page-1)*f.pageSize+1:0,endRow=Math.min(f.page*f.pageSize,total);
  const pager=`<div class="pagination"><span>Afișate ${startRow.toLocaleString('ro-RO')}–${endRow.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="agentPageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'agent-page')}</div></div>`;
  return `${rows?`<div class="table-wrap agent-table-wrap"><table><thead><tr><th>Agent</th><th>Status</th><th>IP management</th><th>OS raportat</th><th>Versiune agent</th><th>Canal update</th><th>UUID</th><th>Contact / colectare</th><th>Ultima eroare</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există agenți pentru filtrele selectate.')}${pager}`;
}
function bindAgentTableActions(scope=document){
  scope.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>agentAction(b.dataset.action,Number(b.dataset.id)));
  scope.querySelectorAll('.agent-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.agentFilters.page){state.agentFilters.page=page;loadAgentList()}}));
  document.getElementById('agentPageSize')?.addEventListener('change',event=>{state.agentFilters.pageSize=Number(event.target.value);state.agentFilters.page=1;loadAgentList()});
}
function agentQuery(includePage=true){const f=state.agentFilters,p=new URLSearchParams();if(f.q)p.set('q',f.q);if(f.status)p.set('status',f.status);if(f.channel)p.set('channel',f.channel);if(includePage){p.set('page',String(f.page));p.set('page_size',String(f.pageSize))}return p.toString()}
async function loadAgentList(){
  const area=document.getElementById('agentTableArea');if(!area)return;
  area.classList.add('is-loading');
  try{const result=await api(`/api/v1/agents?${agentQuery(true)}`);area.innerHTML=agentListTable(result);bindAgentTableActions(area);const exportLink=document.getElementById('exportAgents');if(exportLink)exportLink.href=`/api/v1/agents/export?${agentQuery(false)}`}catch(err){area.innerHTML=empty(err.message);toast(err.message,true)}finally{area.classList.remove('is-loading')}
}
function agentReleaseQuery(includePage=true){const f=state.agentReleaseFilters,p=new URLSearchParams();[['q',f.q],['channel',f.channel],['os',f.os],['arch',f.arch],['validity',f.validity]].forEach(([k,v])=>{if(v)p.set(k,v)});if(includePage){p.set('page',String(f.page));p.set('page_size',String(f.pageSize))}return p.toString()}
function releaseListTable(result){
  const f=state.agentReleaseFilters,items=Array.isArray(result?.items)?result.items:[];f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
  const rows=items.map(r=>{const actions=can('agents.manage')?`<div class="actions">${r.channel==='testing'?`<button type="button" class="small agent-release-promote" data-version="${e(r.version)}" data-os="${e(r.os)}" data-arch="${e(r.arch)}">Promovează stable</button>`:''}<button type="button" class="small danger agent-release-delete" data-version="${e(r.version)}" data-channel="${e(r.channel)}" data-os="${e(r.os)}" data-arch="${e(r.arch)}">Șterge</button></div>`:'—';return `<tr><td><strong>${e(r.version)}</strong></td><td>${badge(r.channel)}</td><td>${e(r.os)} / ${e(r.arch)}</td><td>${r.valid?badge('ready'):badge('invalid')}</td><td>${dt(r.published_at)}</td><td class="muted">${e(r.notes||'—')}</td><td>${actions}</td></tr>`}).join('');
  const total=Number(result?.total||0),pages=Number(result?.pages||0),start=total?(f.page-1)*f.pageSize+1:0,end=Math.min(f.page*f.pageSize,total);
  const pager=`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="releasePageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'release-page')}</div></div>`;
  return `${rows?`<div class="table-wrap"><table><thead><tr><th>Versiune</th><th>Canal</th><th>Platformă</th><th>Repository</th><th>Publicat</th><th>Note</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există release-uri pentru filtrele selectate.')}${pager}`;
}
function bindReleaseTableActions(scope=document){
  scope.querySelectorAll('.agent-release-promote').forEach(button=>button.addEventListener('click',()=>promoteAgentRelease(button)));
  scope.querySelectorAll('.agent-release-delete').forEach(button=>button.addEventListener('click',()=>deleteAgentRelease(button)));
  scope.querySelectorAll('.release-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.agentReleaseFilters.page){state.agentReleaseFilters.page=page;loadReleaseList()}}));
  document.getElementById('releasePageSize')?.addEventListener('change',event=>{state.agentReleaseFilters.pageSize=Number(event.target.value);state.agentReleaseFilters.page=1;loadReleaseList()});
}
async function loadReleaseList(){
  const area=document.getElementById('releaseTableArea');if(!area)return;area.classList.add('is-loading');
  try{const result=await api(`/api/v1/agent-updates/releases?${agentReleaseQuery(true)}`);area.innerHTML=releaseListTable(result);bindReleaseTableActions(area);const exportLink=document.getElementById('exportAgentReleases');if(exportLink)exportLink.href=`/api/v1/agent-updates/releases/export?${agentReleaseQuery(false)}`}catch(err){area.innerHTML=empty(err.message);toast(err.message,true)}finally{area.classList.remove('is-loading')}
}
async function agentsPage(requestedSection='list'){
  const section=['list','releases'].includes(requestedSection)?requestedSection:'list';if(section!==requestedSection)history.replaceState(null,'',`#agents/${section}`);
  pageMeta('Agenți',section==='list'?'Inventar, stare și colectare':'Publicare versiuni și auto-update');
  let workspace='';
  if(section==='list'){
    const f=state.agentFilters,result=await api(`/api/v1/agents?${agentQuery(true)}`);
    const filter=`<div class="filterbar agent-filterbar"><label><span>Căutare</span><input id="agentSearch" type="search" value="${e(f.q)}" placeholder="Nume, IP management, IP VM, URL, UUID, versiune, OS, canal sau eroare"></label><label><span>Status</span><select id="agentStatusFilter"><option value="">Toate</option><option value="online" ${f.status==='online'?'selected':''}>Online</option><option value="offline" ${f.status==='offline'?'selected':''}>Offline</option><option value="unknown" ${f.status==='unknown'?'selected':''}>Necunoscut</option><option value="disabled" ${f.status==='disabled'?'selected':''}>Dezactivat</option></select></label><label><span>Canal update</span><select id="agentChannelFilter"><option value="">Toate</option><option value="stable" ${f.channel==='stable'?'selected':''}>stable</option><option value="testing" ${f.channel==='testing'?'selected':''}>testing</option><option value="unknown" ${f.channel==='unknown'?'selected':''}>Necunoscut</option></select></label><button id="clearAgentFilters" type="button" class="secondary">Resetează</button></div>`;
    const tools=`<a id="exportAgents" class="button secondary" href="/api/v1/agents/export">Export Excel</a>${can('agents.manage')?'<button id="newAgent">Adaugă agent</button>':''}`;
    workspace=panel('Lista agenților',`${filter}<div id="agentTableArea">${agentListTable(result)}</div>`,tools);
  }else{
    const f=state.agentReleaseFilters,result=await api(`/api/v1/agent-updates/releases?${agentReleaseQuery(true)}`).catch(()=>({items:[],page:1,page_size:f.pageSize,total:0,pages:0}));
    const publishForm=can('agents.manage')?`<form id="agentReleaseForm" class="form-grid upload-form agent-release-form"><label><span>Versiune</span><input name="version" required placeholder="1.3.4"></label><label><span>Canal</span><select name="channel"><option value="testing">testing</option><option value="stable">stable</option></select></label><label><span>OS</span><select name="os"><option value="linux">Linux</option><option value="windows">Windows</option></select></label><label><span>Arhitectură</span><select name="arch"><option value="amd64">amd64</option><option value="386">386 (i386/i686)</option></select></label><label class="span-2"><span>Agent</span><input name="agent" type="file" required></label><label class="span-2"><span>Updater</span><input name="updater" type="file" required></label><label class="span-2"><span>Note release</span><textarea name="notes" rows="2" placeholder="Modificările acestei versiuni"></textarea></label><div class="span-2 actions"><button type="submit">Publică în repository</button></div></form>`:'<p class="muted agent-release-form">Nu ai permisiunea agents.manage.</p>';
    const addRelease=`<details class="panel collapsible-panel agent-release-publish"><summary><span><strong>Adaugă release</strong><small>Închis implicit · deschide pentru publicare</small></span><span class="collapse-indicator">▾</span></summary><div class="collapsible-panel-body">${publishForm}<p class="muted panel-note">Publică mai întâi pe testing, validează pe un VM pilot, apoi promovează în stable.</p></div></details>`;
    const filters=`<div class="filterbar release-filterbar"><label class="release-search-field"><span>Căutare</span><input id="releaseSearch" type="search" value="${e(f.q)}" placeholder="Versiune, note sau fișier"></label><label><span>Canal</span><select id="releaseChannel"><option value="">Toate</option><option value="testing" ${f.channel==='testing'?'selected':''}>testing</option><option value="stable" ${f.channel==='stable'?'selected':''}>stable</option></select></label><label><span>OS</span><select id="releaseOS"><option value="">Toate</option><option value="linux" ${f.os==='linux'?'selected':''}>Linux</option><option value="windows" ${f.os==='windows'?'selected':''}>Windows</option></select></label><label><span>Arhitectură</span><select id="releaseArch"><option value="">Toate</option><option value="amd64" ${f.arch==='amd64'?'selected':''}>amd64</option><option value="386" ${f.arch==='386'?'selected':''}>386 (i386/i686)</option></select></label><label><span>Repository</span><select id="releaseValidity"><option value="">Toate</option><option value="valid" ${f.validity==='valid'?'selected':''}>Ready</option><option value="invalid" ${f.validity==='invalid'?'selected':''}>Invalid</option></select></label><button id="clearReleaseFilters" type="button" class="secondary">Resetează</button></div>`;
    workspace=addRelease+panel('Release-uri publicate',`${filters}<div id="releaseTableArea">${releaseListTable(result)}</div>`,`<a id="exportAgentReleases" class="button secondary" href="/api/v1/agent-updates/releases/export">Export Excel</a>`);
  }
  content.innerHTML=`<div class="agent-layout">${agentSectionNavigation(section)}<div class="nomenclature-workspace">${workspace}</div></div>`;
  if(section==='list'){
    document.getElementById('newAgent')?.addEventListener('click',()=>openAgent());bindAgentTableActions(document.getElementById('agentTableArea')||document);const exportLink=document.getElementById('exportAgents');if(exportLink)exportLink.href=`/api/v1/agents/export?${agentQuery(false)}`;
    let timer;const search=document.getElementById('agentSearch');search?.addEventListener('input',event=>{clearTimeout(timer);const value=event.target.value;timer=setTimeout(()=>{state.agentFilters.q=value.trim();state.agentFilters.page=1;loadAgentList()},300)});
    document.getElementById('agentStatusFilter')?.addEventListener('change',event=>{state.agentFilters.status=event.target.value;state.agentFilters.page=1;loadAgentList()});document.getElementById('agentChannelFilter')?.addEventListener('change',event=>{state.agentFilters.channel=event.target.value;state.agentFilters.page=1;loadAgentList()});
    document.getElementById('clearAgentFilters')?.addEventListener('click',()=>{state.agentFilters={q:'',status:'',channel:'',page:1,pageSize:10};if(search)search.value='';const status=document.getElementById('agentStatusFilter');if(status)status.value='';const channel=document.getElementById('agentChannelFilter');if(channel)channel.value='';loadAgentList();search?.focus()});
  }else{
    document.getElementById('agentReleaseForm')?.addEventListener('submit',publishAgentRelease);bindReleaseTableActions(document.getElementById('releaseTableArea')||document);const exportLink=document.getElementById('exportAgentReleases');if(exportLink)exportLink.href=`/api/v1/agent-updates/releases/export?${agentReleaseQuery(false)}`;
    let timer;document.getElementById('releaseSearch')?.addEventListener('input',event=>{clearTimeout(timer);const value=event.target.value;timer=setTimeout(()=>{state.agentReleaseFilters.q=value.trim();state.agentReleaseFilters.page=1;loadReleaseList()},300)});
    [['releaseChannel','channel'],['releaseOS','os'],['releaseArch','arch'],['releaseValidity','validity']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{state.agentReleaseFilters[key]=event.target.value;state.agentReleaseFilters.page=1;loadReleaseList()}));
    document.getElementById('clearReleaseFilters')?.addEventListener('click',()=>{state.agentReleaseFilters={q:'',channel:'',os:'',arch:'',validity:'',page:1,pageSize:10};agentsPage('releases')});
  }
}
async function publishAgentRelease(event){
  event.preventDefault();const form=event.currentTarget;const data=new FormData(form);const button=form.querySelector('button[type=submit]');if(button)button.disabled=true;
  try{const release=await api('/api/v1/agent-updates/releases',{method:'POST',body:data});toast(`Agent ${release.version} publicat pe ${release.channel}.`);form.reset();await loadReleaseList()}catch(err){toast(err.message,true)}finally{if(button)button.disabled=false}
}
async function promoteAgentRelease(button){
  const {version,os,arch}=button.dataset;if(!confirm(`Promovezi agentul ${version} ${os}/${arch} din testing în stable?`))return;
  try{await api(`/api/v1/agent-updates/releases/${encodeURIComponent(version)}/promote?os=${encodeURIComponent(os)}&arch=${encodeURIComponent(arch)}`,{method:'POST'});toast(`Agent ${version} promovat în stable.`);loadReleaseList()}catch(err){toast(err.message,true)}
}
async function deleteAgentRelease(button){
  const {version,channel,os,arch}=button.dataset;if(!confirm(`Ștergi release-ul ${version} ${channel} ${os}/${arch}?`))return;
  try{await api(`/api/v1/agent-updates/releases/${encodeURIComponent(version)}?channel=${encodeURIComponent(channel)}&os=${encodeURIComponent(os)}&arch=${encodeURIComponent(arch)}`,{method:'DELETE'});toast('Release șters.');loadReleaseList()}catch(err){toast(err.message,true)}
}
function openAgent(agent=null){
  document.getElementById('agentDialogTitle').textContent=agent?'Editare agent':'Agent nou';
  document.getElementById('agentId').value=agent?.id||'';document.getElementById('agentName').value=agent?.name||'';document.getElementById('agentURL').value=agent?.base_url||'';document.getElementById('agentToken').value='';document.getElementById('agentToken').required=!agent;
  document.getElementById('agentInterval').value=agent?.collection_interval_seconds||900;document.getElementById('agentTimeout').value=agent?.request_timeout_seconds||45;document.getElementById('agentOffline').value=agent?.offline_after_seconds||2700;document.getElementById('agentEnabled').checked=agent?.enabled??true;document.getElementById('agentVerifyTLS').checked=agent?.verify_tls??true;agentDialog.showModal();
}
async function agentAction(action,id){
  const agent=state.agents.find(a=>a.id===id);
  if(action==='edit'){openAgent(agent);return}
  if(action==='delete'){if(!confirm(`Ștergi agentul ${agent.name}? Istoricul lui va fi șters.`))return;await api(`/api/v1/agents/${id}`,{method:'DELETE'});toast('Agent șters.');loadAgentList();return}
  if(action==='update'){
    const channel=agent?.update?.channel||'canalul configurat pe agent';if(!confirm(`Forțezi verificarea și instalarea update-ului pentru ${agent.name} pe ${channel}?`))return;
    try{const u=await api(`/api/v1/agents/${id}/update`,{method:'POST'});if(u.state==='disabled')toast(`Update dezactivat pe ${agent.name}.`,true);else if(u.state==='current')toast(`${agent.name} este deja la zi (${u.current_version||agent.agent_version||'versiune curentă'}) · ${u.channel||channel}.`);else if(u.state==='installing')toast(`Update ${u.available_version||''} pornit pe ${agent.name} · ${u.channel||channel}.`);else toast(`Update ${agent.name}: ${u.state||'verificare terminată'}${u.available_version?` · ${u.available_version}`:''}.`);[1200,3500,7000,15000].forEach(delay=>setTimeout(()=>{if(location.hash.startsWith('#agents/list'))loadAgentList()},delay))}catch(err){toast(err.message,true);setTimeout(loadAgentList,800)}return
  }
  const job=await api(`/api/v1/agents/${id}/${action==='test'?'test':'collect'}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(loadAgentList,1000);
}
agentForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('agentId').value||0);
  const body={name:document.getElementById('agentName').value.trim(),base_url:document.getElementById('agentURL').value.trim(),token:document.getElementById('agentToken').value,enabled:document.getElementById('agentEnabled').checked,verify_tls:document.getElementById('agentVerifyTLS').checked,collection_interval_seconds:Number(document.getElementById('agentInterval').value),request_timeout_seconds:Number(document.getElementById('agentTimeout').value),offline_after_seconds:Number(document.getElementById('agentOffline').value)};
  if(id&&!body.token)delete body.token;
  try{await api(id?`/api/v1/agents/${id}`:'/api/v1/agents',{method:id?'PATCH':'POST',body:JSON.stringify(body)});agentDialog.close();toast(id?'Agent actualizat.':'Agent creat.');agentsPage()}catch(err){toast(err.message,true)}
});

function vmsCurrentSection(){
  const parts=(location.hash||'#vms/inventory').slice(1).split('/');
  return parts[0]==='vms'&&parts[1]==='sources'?'sources':'inventory';
}
function vmsSectionNavigation(selected){
  const items=[['inventory','Inventar VM','Căutare, filtre și administrarea VM-urilor'],['sources','Surse & sincronizări','vCenter, programare și istoricul sincronizărilor']];
  return `<nav class="vm-section-tabs" aria-label="Secțiuni VM">${items.map(([code,label,help])=>`<a href="#vms/${code}" class="${selected===code?'active':''}"><span>${e(label)}</span><small>${e(help)}</small></a>`).join('')}</nav>`;
}
async function vmsPage(section='inventory'){
  section=section==='sources'?'sources':'inventory';
  if((location.hash||'')==='#vms')history.replaceState(null,'','#vms/inventory');
  const nav=vmsSectionNavigation(section),runPaging=state.vcenterRunPaging||{page:1,pageSize:10};
  const requests=[can('vcenter.read')?api('/api/v1/vcenter/sources'):Promise.resolve([]),section==='sources'&&can('vcenter.read')?api(`/api/v1/vcenter/sync-runs?page=${runPaging.page}&page_size=${runPaging.pageSize}`):Promise.resolve({items:[],page:1,page_size:10,total:0,pages:0}),section==='inventory'?api('/api/v1/services?include_inactive=true'):Promise.resolve([])];
  const results=await Promise.all(requests);state.sources=Array.isArray(results[0])?results[0]:[];const runPage=results[1]||{},runs=Array.isArray(runPage.items)?runPage.items:[],vmServices=Array.isArray(results[2])?results[2]:[];
  if(section==='sources'){
    state.vcenterRunPaging.page=Number(runPage.page||1);state.vcenterRunPaging.pageSize=Number(runPage.page_size||state.vcenterRunPaging.pageSize||10);
    pageMeta('VM-uri','Surse vCenter și istoricul sincronizărilor');
    const tools=can('vcenter.manage')?'<button id="syncAll">Sincronizează toate</button><button id="newVCenter" class="secondary">Adaugă sursă</button>':'';
    const sourceRows=state.sources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${e(s.username)}</td><td>${s.daily_sync_enabled?`Zilnic ${e(s.daily_sync_time)} · ${e(state.timezone)}`:'Manual'}</td><td>${dt(s.last_success_at)}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions">${can('vcenter.manage')?`<button class="small secondary vc-action" data-action="test" data-id="${s.id}">Test</button><button class="small vc-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary vc-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger vc-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
    const runRows=runs.map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.vcenter_source_name)}</td><td>${badge(r.status)}</td><td>${r.found_count}</td><td>+${r.created_count} / ~${r.updated_count} / lipsă ${r.missing_count}</td><td>${r.linked_agent_count}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');
    const runTotal=Number(runPage.total||0),runCurrent=Number(runPage.page||1),runPageSize=Number(runPage.page_size||10),runStart=runTotal?(runCurrent-1)*runPageSize+1:0,runEnd=Math.min(runCurrent*runPageSize,runTotal);
    const runPager=runTotal?`<div class="pagination"><span>Afișate ${runStart.toLocaleString('ro-RO')}–${runEnd.toLocaleString('ro-RO')} din ${runTotal.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="vcenterRunPageSize">${pageSizeOptions(runPageSize,[10,25,50,100,200])}</select></label>${paginationButtons(runCurrent,Number(runPage.pages||1),'vcenter-run-page')}</div></div>`:'';
    content.innerHTML=`<div class="vm-page-workspace">${nav}${panel('Surse vCenter',state.sources.length?`<div class="table-wrap vcenter-source-table"><table><thead><tr><th>Sursă</th><th>Utilizator</th><th>Program</th><th>Ultima sincronizare</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse vCenter configurate.'),tools)}${panel('Ultimele sincronizări',runRows?`<div class="table-wrap vcenter-run-table"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Găsite</th><th>Modificări</th><th>Agenți legați</th><th>Eroare</th></tr></thead><tbody>${runRows}</tbody></table></div>${runPager}`:empty('Nu există sincronizări.'))}</div>`;
    document.getElementById('syncAll')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/vcenter/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări introduse în coadă.`);setTimeout(()=>vmsPage('sources'),1200)}catch(err){toast(err.message,true)}});
    document.getElementById('newVCenter')?.addEventListener('click',()=>openVCenter());
    content.querySelectorAll('.vc-action').forEach(b=>b.onclick=()=>vcenterAction(b.dataset.action,Number(b.dataset.id)));
    content.querySelectorAll('.vcenter-run-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vcenterRunPaging.page){state.vcenterRunPaging.page=page;vmsPage('sources')}}));
    document.getElementById('vcenterRunPageSize')?.addEventListener('change',event=>{state.vcenterRunPaging.pageSize=Number(event.target.value);state.vcenterRunPaging.page=1;vmsPage('sources')});
    return;
  }
  pageMeta('VM-uri','Inventar, stare, servicii și documentație');
  const filters=state.vmFilters,sourceOptions=state.sources.map(s=>`<option value="${s.id}" ${String(filters.sourceId)===String(s.id)?'selected':''}>${e(s.name)}</option>`).join(''),serviceOptions=vmServices.filter(s=>s.active!==false).map(s=>`<option value="${s.id}" ${String(filters.serviceId)===String(s.id)?'selected':''}>${e(s.name)}</option>`).join('');
  const tools=`<a id="exportVMs" class="button secondary" href="/api/v1/vms/export">Export Excel</a>`;
  const filterBody=`<div class="vm-filter-shell">
    <label class="vm-search-field"><span>Căutare VM</span><input id="vmSearch" type="search" value="${e(filters.q)}" placeholder="Nume, hostname, OS, IP, agent, serviciu sau sursă"></label>
    <div class="vm-filter-grid">
      <label><span>Power</span><select id="vmPower"><option value="">Toate</option><option value="POWERED_ON" ${filters.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${filters.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${filters.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label>
      <label><span>Agent</span><select id="vmAgentFilter"><option value="">Toți</option><option value="configured" ${filters.agent==='configured'?'selected':''}>Asociat</option><option value="unconfigured" ${filters.agent==='unconfigured'?'selected':''}>Fără agent</option><option value="online" ${filters.agent==='online'?'selected':''}>Online</option><option value="offline" ${filters.agent==='offline'?'selected':''}>Offline</option><option value="unknown" ${filters.agent==='unknown'?'selected':''}>Necunoscut</option><option value="disabled" ${filters.agent==='disabled'?'selected':''}>Dezactivat</option></select></label>
      <label><span>vCenter</span><select id="vmPresence"><option value="">Toate</option><option value="present" ${filters.presence==='present'?'selected':''}>Prezente</option><option value="missing" ${filters.presence==='missing'?'selected':''}>Lipsă din vCenter</option></select></label>
      <label><span>Baseline</span><select id="vmBaseline"><option value="">Toate</option><option value="yes" ${filters.baseline==='yes'?'selected':''}>Da</option><option value="no" ${filters.baseline==='no'?'selected':''}>Nu</option></select></label>
      <label><span>Serviciu</span><select id="vmServiceFilter"><option value="">Toate serviciile</option>${serviceOptions}</select></label>
      <label><span>Sursă vCenter</span><select id="vmSource"><option value="">Toate sursele</option>${sourceOptions}</select></label>
      <label><span>Pe pagină</span><select id="vmPageSize">${[10,25,50,100,200].map(n=>`<option value="${n}" ${Number(filters.pageSize)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    </div>
    <div class="vm-filter-actions"><div id="vmActiveFilters" class="vm-active-filters"></div><button id="clearVMFilters" class="secondary vm-clear-filter" type="button">Resetează filtrele</button></div>
  </div><div id="vmTableArea" class="loading">Se încarcă VM-urile…</div>`;
  content.innerHTML=`<div class="vm-page-workspace">${nav}<div class="cards vm-list-summary-cards"><div class="card"><div class="label">Rezultate</div><div id="vmTotal" class="value">—</div></div><div class="card"><div class="label">Prezente în vCenter</div><div id="vmPresent" class="value">—</div><div id="vmPresentPct" class="card-percent">—</div></div><div class="card"><div class="label">Lipsă din vCenter</div><div id="vmMissing" class="value">—</div><div id="vmMissingPct" class="card-percent">—</div></div><div class="card"><div class="label">Cu agent asociat</div><div id="vmWithAgent" class="value">—</div><div id="vmWithAgentPct" class="card-percent">—</div></div></div>${panel('Inventar VM',filterBody,tools)}</div>`;
  bindVMFilters();await loadVMPage();
}

function vmQuery(includePage=true){
  const f=state.vmFilters,params=new URLSearchParams();
  if(f.q)params.set('q',f.q);if(f.power)params.set('power',f.power);if(f.agent)params.set('agent',f.agent);if(f.presence)params.set('presence',f.presence);if(f.baseline)params.set('baseline',f.baseline);if(f.serviceId)params.set('service_id',f.serviceId);if(f.sourceId)params.set('source_id',f.sourceId);
  if(includePage){params.set('page',String(f.page));params.set('page_size',String(f.pageSize))}
  return params.toString();
}

function updateVMActiveFilters(){
  const host=document.getElementById('vmActiveFilters');if(!host)return;const f=state.vmFilters,items=[];
  if(f.q)items.push(`Căutare: ${f.q}`);
  const picks=[['vmPower','power'],['vmAgentFilter','agent'],['vmPresence','presence'],['vmBaseline','baseline'],['vmServiceFilter','serviceId'],['vmSource','sourceId']];
  for(const [id,key] of picks){if(!f[key])continue;const select=document.getElementById(id),text=select?.options?.[select.selectedIndex]?.textContent?.trim();if(text)items.push(text)}
  host.innerHTML=items.length?`<span class="vm-filter-caption">Filtre active</span>${items.map(v=>`<span class="vm-filter-chip">${e(v)}</span>`).join('')}`:'<span class="muted">Niciun filtru activ</span>';
}
function bindVMFilters(){
  let timer;
  document.getElementById('vmSearch')?.addEventListener('input',event=>{clearTimeout(timer);timer=setTimeout(()=>{state.vmFilters.q=event.target.value.trim();state.vmFilters.page=1;updateVMActiveFilters();loadVMPage()},300)});
  const bindings={vmPower:'power',vmAgentFilter:'agent',vmPresence:'presence',vmBaseline:'baseline',vmServiceFilter:'serviceId',vmSource:'sourceId'};
  Object.entries(bindings).forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{state.vmFilters[key]=event.target.value;state.vmFilters.page=1;updateVMActiveFilters();loadVMPage()}));
  document.getElementById('vmPageSize')?.addEventListener('change',event=>{state.vmFilters.pageSize=Number(event.target.value);state.vmFilters.page=1;loadVMPage()});
  document.getElementById('clearVMFilters')?.addEventListener('click',()=>{state.vmFilters={q:'',power:'',agent:'',presence:'',baseline:'',serviceId:'',sourceId:'',page:1,pageSize:10};vmsPage('inventory')});updateVMActiveFilters();
}

async function loadVMPage(){
  const area=document.getElementById('vmTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă VM-urile…';
  try{
    const result=await api(`/api/v1/vms?${vmQuery(true)}`);state.vms=Array.isArray(result?.items)?result.items:[];state.vmFilters.page=Number(result?.page||1);
    const vmTotal=Number(result?.total||0),vmPresent=Number(result?.present_count||0),vmMissing=Math.max(0,vmTotal-vmPresent),vmAgent=Number(result?.with_agent_count||0),vmPct=value=>vmTotal?`${(Number(value)*100/vmTotal).toFixed(1)}%`:'0%';document.getElementById('vmTotal').textContent=vmTotal.toLocaleString('ro-RO');document.getElementById('vmPresent').textContent=vmPresent.toLocaleString('ro-RO');document.getElementById('vmMissing').textContent=vmMissing.toLocaleString('ro-RO');document.getElementById('vmWithAgent').textContent=vmAgent.toLocaleString('ro-RO');const setPct=(id,value)=>{const n=document.getElementById(id);if(n)n.textContent=vmPct(value)};setPct('vmPresentPct',vmPresent);setPct('vmMissingPct',vmMissing);setPct('vmWithAgentPct',vmAgent);
    const exportLink=document.getElementById('exportVMs');if(exportLink)exportLink.href=`/api/v1/vms/export?${vmQuery(false)}`;
    area.className='';area.innerHTML=renderVMPage(result);bindVMDeleteActions(area);
    area.querySelectorAll('.vm-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmFilters.page){state.vmFilters.page=page;loadVMPage();area.scrollIntoView({behavior:'smooth',block:'start'})}}));
  }catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}

function vmVCenterState(v){
  if(v.present_in_vcenter)return '<span class="badge vm-vcenter-present">Prezentă</span>';
  return `<span class="badge vm-vcenter-missing">Lipsă</span>${v.missing_since?`<div class="muted">din ${dt(v.missing_since)}</div>`:''}`;
}
function vmDeleteImpactText(impact){
  const values=[];
  if(impact.agent_id)values.push('agent asociat: da (agentul NU va fi șters)');
  if(impact.direct_service_assignments)values.push(`asocieri directe servicii: ${impact.direct_service_assignments}`);
  if(impact.resource_service_links)values.push(`asocieri servicii pe Docker/DB/Web: ${impact.resource_service_links}`);
  if(impact.generated_documents)values.push(`fișe generate: ${impact.generated_documents}`);
  if(impact.monitoring_targets)values.push(`targeturi monitorizare ce vor deveni necorelate: ${impact.monitoring_targets}`);
  if(impact.backup_records)values.push(`înregistrări backup: ${impact.backup_records}`);
  if(impact.external_connections)values.push(`conexiuni externe: ${impact.external_connections}`);
  if(impact.common_dependencies)values.push(`dependențe comune: ${impact.common_dependencies}`);
  if(impact.responsibilities)values.push(`responsabilități: ${impact.responsibilities}`);
  if(impact.inventory_changes)values.push(`modificări inventar: ${impact.inventory_changes}`);
  return values.length?values.map(v=>`• ${v}`).join('\n'):'• nu sunt legături funcționale importante identificate';
}
async function deleteVMPermanent(id,afterDelete){
  try{
    const impact=await api(`/api/v1/vms/${id}/delete-impact`);
    if(impact.present_in_vcenter){toast('VM-ul este încă prezent în vCenter. Șterge-l din vCenter și rulează Sync înainte.',true);return}
    const message=`Ștergi DEFINITIV VM-ul ${impact.name}?\n\nAceastă operație nu folosește arhivare și nu poate fi anulată.\n${vmDeleteImpactText(impact)}\n\nÎnregistrările dependente ale VM-ului vor fi eliminate; agentul asociat rămâne în pagina Agenți.`;
    if(!confirm(message))return;
    await api(`/api/v1/vms/${id}`,{method:'DELETE'});
    toast(`VM ${impact.name} ștearsă definitiv.`);
    if(afterDelete)await afterDelete();
  }catch(err){toast(err.message,true)}
}
async function deleteSelectedVMs(){
  const ids=[...document.querySelectorAll('.vm-delete-select:checked')].map(x=>Number(x.value)).filter(Boolean);
  if(!ids.length){toast('Selectează cel puțin o VM lipsă din vCenter.',true);return}
  if(!confirm(`Ștergi DEFINITIV ${ids.length} VM-uri selectate?\n\nSe șterg și legăturile/datele dependente ale acestor VM-uri. Targeturile de monitorizare rămân, dar devin necorelate. Agenții nu sunt șterși.`))return;
  try{const result=await api('/api/v1/vms/delete-bulk',{method:'POST',body:JSON.stringify({ids})});toast(`${result.count||ids.length} VM-uri șterse definitiv.`);await loadVMPage()}catch(err){toast(err.message,true)}
}
function bindVMDeleteActions(area){
  const selected=()=>[...area.querySelectorAll('.vm-delete-select:checked')].length;
  const refresh=()=>{const b=area.querySelector('#deleteSelectedVMs');if(b){const n=selected();b.disabled=!n;b.textContent=n?`Șterge definitiv selectate (${n})`:'Șterge definitiv selectate'}};
  area.querySelectorAll('.vm-delete-one').forEach(button=>button.addEventListener('click',()=>deleteVMPermanent(Number(button.dataset.id),loadVMPage)));
  area.querySelectorAll('.vm-delete-select').forEach(input=>input.addEventListener('change',refresh));
  area.querySelector('#selectMissingVMs')?.addEventListener('change',event=>{area.querySelectorAll('.vm-delete-select').forEach(input=>input.checked=event.target.checked);refresh()});
  area.querySelector('#deleteSelectedVMs')?.addEventListener('click',deleteSelectedVMs);
  refresh();
}
function renderVMPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există VM-uri pentru filtrele selectate.');
  const deletable=items.filter(v=>!v.present_in_vcenter);
  const rows=items.map(v=>{const completion=Math.max(0,Math.min(100,Number(v.completion_percent||0))),version=v.agent_version?`<span class="vm-agent-inline-version mono">${e(v.agent_version)}</span>`:'';return `<tr><td class="vm-select-col">${!v.present_in_vcenter&&can('vms.manage')?`<input class="vm-delete-select" type="checkbox" value="${v.id}" aria-label="Selectează ${e(v.name)} pentru ștergere">`:''}</td><td><a href="#vms/${v.id}/overview"><strong>${e(v.name)}</strong></a></td><td>${vmVCenterState(v)}</td><td>${powerShortBadge(v.power_state)}</td><td>${v.cpu_count||'—'} / ${memory(v.memory_mib)}</td><td>${e(shortOS(v))}</td><td class="mono">${e(v.inventory_primary_ip||v.primary_ip||'—')}</td><td><div class="vm-agent-status-line">${badge(v.agent_status)}${version}</div><div class="muted">${e(v.agent_name||'Fără agent')}</div></td><td>${vmServiceNamesHTML(v.service_names)}</td><td><div class="completion-cell"><strong>${completion}%</strong><div class="completion-progress"><i style="width:${completion}%"></i></div></div></td><td>${dt(v.inventory_received_at)}</td><td>${!v.present_in_vcenter&&can('vms.manage')?`<button class="small danger vm-delete-one" data-id="${v.id}">Șterge definitiv</button>`:'—'}</td></tr>`}).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||10),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  const cleanup=can('vms.manage')&&deletable.length?`<div class="vm-cleanup-toolbar"><label><input id="selectMissingVMs" type="checkbox"> Selectează VM-urile lipsă de pe această pagină</label><span class="muted">Ștergerea este permisă numai după ce VM-ul nu mai este prezent în vCenter.</span><button id="deleteSelectedVMs" class="danger" type="button" disabled>Șterge definitiv selectate</button></div>`:'';
  return `${cleanup}<div class="table-wrap vm-table-wrap"><table><thead><tr><th class="vm-select-col"></th><th>VM</th><th>vCenter</th><th>Power</th><th>CPU / RAM</th><th>OS</th><th>IP</th><th>Agent</th><th>Servicii</th><th>Completare</th><th>Ultimul JSON</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons">${paginationButtons(page,Number(result.pages||1))}</div></div>`;
}

function paginationButtons(page,pages,buttonClass='vm-page'){
  if(pages<=1)return '';
  const values=new Set([1,pages,page-2,page-1,page,page+1,page+2]);const valid=[...values].filter(n=>n>=1&&n<=pages).sort((a,b)=>a-b);let previous=0,html=`<button class="small secondary ${buttonClass}" data-page="${page-1}" ${page<=1?'disabled':''}>Anterior</button>`;
  valid.forEach(n=>{if(previous&&n>previous+1)html+='<span class="pagination-gap">…</span>';html+=`<button class="small ${n===page?'':'secondary'} ${buttonClass}" data-page="${n}" ${n===page?'disabled':''}>${n}</button>`;previous=n});
  return html+`<button class="small secondary ${buttonClass}" data-page="${page+1}" ${page>=pages?'disabled':''}>Următor</button>`;
}
function pageSizeOptions(selected,values=[10,20,50,100]){return values.map(value=>`<option value="${value}" ${Number(selected)===value?'selected':''}>${value}</option>`).join('')}

function nomenclaturePageInfo(code,total){
  const stored=Number(localStorage.getItem(`vm-doc:nomenclature-page-size:${code}`)||0);
  const current=state.nomenclaturePaging[code]||{page:1,pageSize:[10,20,50,100,200].includes(stored)?stored:10};
  current.pageSize=[10,20,50,100,200].includes(Number(current.pageSize))?Number(current.pageSize):10;
  const pages=Math.max(1,Math.ceil(total/current.pageSize));
  current.page=Math.min(Math.max(1,Number(current.page)||1),pages);
  state.nomenclaturePaging[code]=current;
  const offset=(current.page-1)*current.pageSize;
  return {page:current.page,pageSize:current.pageSize,pages,total,offset,end:Math.min(offset+current.pageSize,total)};
}
function nomenclaturePagination(code,info){
  if(!info.total)return '';
  const start=info.offset+1;
  return `<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${info.end.toLocaleString('ro-RO')} din ${info.total.toLocaleString('ro-RO')}</span><div class="pagination-buttons">${paginationButtons(info.page,info.pages,'nomenclature-page')}</div></div>`;
}

function openVCenter(source=null){
  document.getElementById('vcenterDialogTitle').textContent=source?'Editare sursă vCenter':'Sursă vCenter nouă';document.getElementById('vcenterId').value=source?.id||'';document.getElementById('vcenterName').value=source?.name||'';document.getElementById('vcenterURL').value=source?.base_url||'';document.getElementById('vcenterUsername').value=source?.username||'';document.getElementById('vcenterPassword').value='';document.getElementById('vcenterPassword').required=!source;document.getElementById('vcenterSyncTime').value=source?.daily_sync_time||'05:00';document.getElementById('vcenterTLSServerName').value=source?.tls_server_name||'';document.getElementById('vcenterEnabled').checked=source?.enabled??true;document.getElementById('vcenterVerifyTLS').checked=source?.verify_tls??true;document.getElementById('vcenterDailySync').checked=source?.daily_sync_enabled??true;vcenterDialog.showModal();
}
async function vcenterAction(action,id){
  const source=state.sources.find(s=>s.id===id);
  try{
    if(action==='edit'){openVCenter(source);return}
    if(action==='delete'){if(!confirm(`Ștergi sursa ${source.name} și VM-urile sincronizate din ea?`))return;await api(`/api/v1/vcenter/sources/${id}`,{method:'DELETE'});toast('Sursă vCenter ștearsă.');vmsPage('sources');return}
    if(action==='test'){const r=await api(`/api/v1/vcenter/sources/${id}/test`,{method:'POST'});toast(`Conexiune reușită: ${r.vm_count} VM-uri vizibile.`);return}
    if(action==='sync'){const r=await api(`/api/v1/vcenter/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea ${r.id} a fost pornită.`);setTimeout(()=>vmsPage('sources'),1200)}
  }catch(err){toast(err.message,true)}
}
vcenterForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('vcenterId').value||0);const body={name:document.getElementById('vcenterName').value.trim(),base_url:document.getElementById('vcenterURL').value.trim(),username:document.getElementById('vcenterUsername').value.trim(),password:document.getElementById('vcenterPassword').value,enabled:document.getElementById('vcenterEnabled').checked,verify_tls:document.getElementById('vcenterVerifyTLS').checked,tls_server_name:document.getElementById('vcenterTLSServerName').value.trim(),daily_sync_enabled:document.getElementById('vcenterDailySync').checked,daily_sync_time:document.getElementById('vcenterSyncTime').value};if(id&&!body.password)delete body.password;
  try{await api(id?`/api/v1/vcenter/sources/${id}`:'/api/v1/vcenter/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});vcenterDialog.close();toast(id?'Sursă actualizată.':'Sursă creată.');vmsPage('sources')}catch(err){toast(err.message,true)}
});


function veeamIntervalLabel(minutes){
  const value=Number(minutes||0);if(!value)return 'Manual';if(value%1440===0)return `La ${value/1440} ${value===1440?'zi':'zile'}`;if(value%60===0)return `La ${value/60} ${value===60?'oră':'ore'}`;return `La ${value} minute`;
}
function openVeeam(source=null){
  document.getElementById('veeamDialogTitle').textContent=source?'Editare sursă Veeam':'Sursă Veeam nouă';document.getElementById('veeamId').value=source?.id||'';document.getElementById('veeamName').value=source?.name||'';document.getElementById('veeamURL').value=source?.base_url||'';document.getElementById('veeamUsername').value=source?.username||'';document.getElementById('veeamPassword').value='';document.getElementById('veeamPassword').required=!source;document.getElementById('veeamAPIVersion').value=source?.api_version||'1.1-rev1';document.getElementById('veeamSyncInterval').value=source?.sync_interval_minutes||1440;document.getElementById('veeamTLSServerName').value=source?.tls_server_name||'';document.getElementById('veeamEnabled').checked=source?.enabled??true;document.getElementById('veeamVerifyTLS').checked=source?.verify_tls??true;veeamDialog.showModal();
}
async function veeamAction(action,id){
  const source=state.veeamSources.find(s=>Number(s.id)===Number(id));
  try{
    if(action==='edit'){openVeeam(source);return}
    if(action==='delete'){if(!confirm(`Ștergi sursa Veeam ${source?.name||id}? Datele Veeam colectate de la această sursă vor fi eliminate din fișele VM.`))return;await api(`/api/v1/veeam/sources/${id}`,{method:'DELETE'});toast('Sursa Veeam a fost ștearsă.');backupPage('sources');return}
    if(action==='test'){const r=await api(`/api/v1/veeam/sources/${id}/test`,{method:'POST'});toast(`Conectare reușită: ${r.server_name||source?.name||'Veeam'} · ${r.build_version||'versiune necunoscută'} · ${Number(r.backup_objects||0)} obiecte backup.`);return}
    if(action==='sync'){const r=await api(`/api/v1/veeam/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea Veeam ${r.id} a fost pornită.`);[1200,3500,7000].forEach(delay=>setTimeout(()=>{if((location.hash||'').startsWith('#backup'))backupPage('sources')},delay))}
  }catch(err){toast(err.message,true)}
}
function renderVeeamRuns(result){
  const items=Array.isArray(result?.items)?result.items:[],paging=state.veeamRunPaging;paging.page=Number(result?.page||1);paging.pageSize=Number(result?.page_size||paging.pageSize||10);
  const rows=items.map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.veeam_source_name||'—')}</td><td>${badge(r.status)}</td><td>${Number(r.backup_object_count||0)}</td><td>${Number(r.matched_vm_count||0)}</td><td>${Number(r.protected_vm_count||0)}</td><td>${Number(r.unprotected_vm_count||0)}</td><td>${Number(r.ambiguous_count||0)}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');
  const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total),pager=total?`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="veeamRunPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result?.pages||1),'veeam-run-page')}</div></div>`:'';
  return rows?`<div class="table-wrap"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Obiecte</th><th>VM corelate</th><th>Protejate</th><th>Neprotejate</th><th>Neasociate / ambigue</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>${pager}`:empty('Nu există sincronizări Veeam.');
}
function veeamStateBadge(value){
  switch(String(value||'')){
    case 'protected':return '<span class="badge protected">Protejată</span>';
    case 'waiting':return '<span class="badge waiting">Așteaptă primul backup</span>';
    case 'job_disabled':return '<span class="badge job-disabled">Job dezactivat · fără backup</span>';
    case 'stale':return '<span class="badge stale">Backup existent · în afara jobului</span>';
    case 'unprotected':return '<span class="badge unprotected">Neprotejată</span>';
    default:return '<span class="muted">Neverificată</span>';
  }
}
function veeamStateText(value){
  return {protected:'Protejată · restore point disponibil',waiting:'În job · așteaptă primul backup',job_disabled:'În job · job dezactivat · fără restore point',stale:'Backup existent · nu mai este în job',unprotected:'Neprotejată · nu este în job',never:'Neverificată'}[String(value||'')]||'—';
}
function veeamVMQuery(){
  const f=state.veeamVMFilters,p=new URLSearchParams();if(f.q)p.set('q',f.q);if(f.status)p.set('status',f.status);if(f.power)p.set('power',f.power);if(f.result)p.set('result',f.result);p.set('page',String(f.page));p.set('page_size',String(f.pageSize));return p.toString();
}
function renderVeeamVMs(result){
  const f=state.veeamVMFilters,items=Array.isArray(result?.items)?result.items:[];f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
  const filters=`<div class="filterbar veeam-filterbar"><label class="veeam-search-field"><span>Caută</span><input id="veeamVMSearch" type="search" value="${e(f.q)}" placeholder="VM, job, storage, sursă sau power state"></label><label><span>Stare backup</span><select id="veeamVMStatus"><option value="" ${!f.status?'selected':''}>Toate</option><option value="protected" ${f.status==='protected'?'selected':''}>Protejate</option><option value="configured" ${f.status==='configured'?'selected':''}>În job Veeam</option><option value="waiting" ${f.status==='waiting'?'selected':''}>Așteaptă primul backup</option><option value="stale" ${f.status==='stale'?'selected':''}>Backup existent, în afara jobului</option><option value="unprotected" ${f.status==='unprotected'?'selected':''}>Neprotejate</option><option value="never" ${f.status==='never'?'selected':''}>Neverificate</option></select></label><label><span>Power state</span><select id="veeamVMPower"><option value="" ${!f.power?'selected':''}>Toate</option><option value="POWERED_ON" ${f.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${f.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${f.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label><label><span>Rezultat backup</span><select id="veeamVMResult"><option value="" ${!f.result?'selected':''}>Toate</option><option value="success" ${f.result==='success'?'selected':''}>Success</option><option value="warning" ${f.result==='warning'?'selected':''}>Warning</option><option value="failed" ${f.result==='failed'?'selected':''}>Failed</option><option value="none" ${f.result==='none'?'selected':''}>Fără rezultat</option></select></label><button id="clearVeeamVMFilters" type="button" class="secondary">Resetează</button></div>`;
  const rows=items.map(v=>{const protection=`${veeamStateBadge(v.veeam_state)}${v.cron_backup_enabled&&!v.protected?'<div class="muted">+ backup cron declarat</div>':''}`;const inJob=v.veeam_in_job?(v.veeam_job_enabled?'<span class="badge configured">Da</span>':'<span class="badge job-disabled">Da · dezactivat</span>'):'<span class="muted">Nu</span>';const storage=[v.primary_repository_name||v.repository_name,v.secondary_repository_names?`Secundar: ${v.secondary_repository_names}`:''].filter(Boolean).map((x,i)=>i?`<div class="muted">${e(x)}</div>`:e(x)).join('');return `<tr><td><a href="#vms/${v.vm_id}/backup"><strong>${e(v.vm_name)}</strong></a><div class="muted">${e(v.source_name||'—')}</div></td><td>${v.power_state?badge(v.power_state):'—'}</td><td>${protection}</td><td>${inJob}</td><td>${v.last_result?badge(v.last_result):'—'}</td><td>${e(v.job_name||'—')}</td><td>${storage||'—'}</td><td>${e(v.schedule_text||v.cron_backup_schedule||'—')}</td><td>${v.restore_points??'—'}</td><td>${dt(v.last_backup_at)}</td><td>${dt(v.next_run_at)}</td><td>${dt(v.synced_at)}</td><td class="error-text">${e(v.error_message||'—')}</td></tr>`}).join('');
  const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total),pager=total?`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="veeamVMPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result?.pages||1),'veeam-vm-page')}</div></div>`:'';
  return `${filters}${rows?`<div class="table-wrap veeam-vm-table"><table><thead><tr><th>VM / sursă</th><th>Power state</th><th>Stare Veeam</th><th>În job</th><th>Rezultat</th><th>Job</th><th>Storage</th><th>Programare</th><th>Restore points</th><th>Ultimul backup</th><th>Next run</th><th>Sync vm-doc</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există VM-uri pentru filtrele selectate.')}${pager}`;
}
function updateVeeamSummaryCards(result){
  const total=Number(result?.total||0),protectedCount=Number(result?.protected_count||0),configured=Number(result?.configured_count||0),waiting=Number(result?.waiting_count||0),stale=Number(result?.stale_count||0),unprotected=Number(result?.unprotected_count||0),never=Number(result?.never_synchronized_count||0),failed=Number(result?.failed_count||0),warning=Number(result?.warning_count||0),pct=v=>total?`${(Number(v)*100/total).toFixed(1)}%`:'0%';
  const set=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=value};set('backupTotal',total);set('backupProtected',protectedCount);set('backupProtectedPct',pct(protectedCount));set('backupConfigured',configured);set('backupConfiguredPct',pct(configured));set('backupWaiting',waiting);set('backupWaitingPct',pct(waiting));set('backupUnprotected',unprotected);set('backupUnprotectedPct',pct(unprotected));set('backupStale',stale);set('backupStalePct',pct(stale));set('backupNever',never);set('backupNeverPct',pct(never));set('backupFailedWarning',`${failed} / ${warning}`);
}

async function loadVeeamVMs(focusPosition=null){
  const area=document.getElementById('veeamVMTableArea');if(!area)return;area.classList.add('is-loading');
  try{const result=await api(`/api/v1/veeam/vms?${veeamVMQuery()}`);updateVeeamSummaryCards(result);area.innerHTML=renderVeeamVMs(result);bindVeeamVMControls();updateBackupExportLink();if(focusPosition!==null){const input=document.getElementById('veeamVMSearch');if(input){input.focus();const pos=Math.min(Number(focusPosition)||0,input.value.length);input.setSelectionRange(pos,pos)}}}catch(err){toast(err.message,true)}finally{area.classList.remove('is-loading')}
}
function bindVeeamVMControls(){
  const search=document.getElementById('veeamVMSearch');let timer;search?.addEventListener('input',event=>{clearTimeout(timer);const input=event.currentTarget,value=input.value,pos=input.selectionStart??value.length;timer=setTimeout(()=>{state.veeamVMFilters.q=value.trim();state.veeamVMFilters.page=1;loadVeeamVMs(pos)},300)});
  const bindSelect=(id,key)=>document.getElementById(id)?.addEventListener('change',event=>{state.veeamVMFilters[key]=event.target.value;state.veeamVMFilters.page=1;loadVeeamVMs()});bindSelect('veeamVMStatus','status');bindSelect('veeamVMPower','power');bindSelect('veeamVMResult','result');
  document.getElementById('clearVeeamVMFilters')?.addEventListener('click',()=>{state.veeamVMFilters={q:'',status:'',power:'',result:'',page:1,pageSize:10};loadVeeamVMs(0)});document.querySelectorAll('.veeam-vm-page').forEach(b=>b.addEventListener('click',()=>{const page=Number(b.dataset.page);if(page>0&&page!==state.veeamVMFilters.page){state.veeamVMFilters.page=page;loadVeeamVMs()}}));document.getElementById('veeamVMPageSize')?.addEventListener('change',event=>{state.veeamVMFilters.pageSize=Number(event.target.value);state.veeamVMFilters.page=1;loadVeeamVMs()});
}




veeamForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('veeamId').value||0);const body={name:document.getElementById('veeamName').value.trim(),base_url:document.getElementById('veeamURL').value.trim(),username:document.getElementById('veeamUsername').value.trim(),password:document.getElementById('veeamPassword').value,api_version:document.getElementById('veeamAPIVersion').value.trim(),sync_interval_minutes:Number(document.getElementById('veeamSyncInterval').value),enabled:document.getElementById('veeamEnabled').checked,verify_tls:document.getElementById('veeamVerifyTLS').checked,tls_server_name:document.getElementById('veeamTLSServerName').value.trim()};if(id&&!body.password)delete body.password;
  try{await api(id?`/api/v1/veeam/sources/${id}`:'/api/v1/veeam/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});veeamDialog.close();toast(id?'Sursa Veeam a fost actualizată.':'Sursa Veeam a fost creată.');backupPage('sources')}catch(err){toast(err.message,true)}
});


function monitoringCurrentSection(){
  const parts=(location.hash||'#monitoring/overview').slice(1).split('/');
  return parts[0]==='monitoring'&&parts[1]==='sources'?'sources':'overview';
}
function monitoringSectionNavigation(selected){
  const items=[['overview','Stare monitorizare','VM-uri, targeturi și corelare'],['sources','Surse & sincronizări','Prometheus, Blackbox și istoric']];
  return `<nav class="monitoring-section-tabs" aria-label="Secțiuni monitorizare">${items.map(([code,label,help])=>`<a href="#monitoring/${code}" class="${selected===code?'active':''}"><span>${e(label)}</span><small>${e(help)}</small></a>`).join('')}</nav>`;
}
function openPrometheus(source=null){
  document.getElementById('prometheusDialogTitle').textContent=source?'Editare sursă Prometheus':'Sursă Prometheus nouă';
  document.getElementById('prometheusId').value=source?.id||'';
  document.getElementById('prometheusName').value=source?.name||'';
  document.getElementById('prometheusType').value=source?.source_type||'metrics';
  document.getElementById('prometheusURL').value=source?.base_url||'';
  const agentSelect=document.getElementById('prometheusAgent'),agentOptions=Array.isArray(state.prometheusAgentOptions)?state.prometheusAgentOptions:[];
  agentSelect.innerHTML='<option value="">— Fără agent asociat —</option>'+agentOptions.map(a=>`<option value="${a.id}" ${Number(source?.agent_id||0)===Number(a.id)?'selected':''}>${e(a.name)}${a.agent_version?` · ${e(a.agent_version)}`:''}${a.enabled?'':' · inactiv'}</option>`).join('');
  document.getElementById('prometheusAuthMode').value=source?.auth_mode||'none';
  document.getElementById('prometheusUsername').value=source?.username||'';
  document.getElementById('prometheusSecret').value='';
  document.getElementById('prometheusVMLabel').value=source?.vm_label||'vm_fqdn';
  document.getElementById('prometheusTargetLabel').value=source?.target_label||'instance';
  document.getElementById('prometheusSyncInterval').value=source?.sync_interval_minutes||15;
  document.getElementById('prometheusTLSServerName').value=source?.tls_server_name||'';
  document.getElementById('prometheusEnabled').checked=source?.enabled??true;
  document.getElementById('prometheusVerifyTLS').checked=source?.verify_tls??true;
  prometheusDialog.showModal();
}
async function prometheusAction(action,id){
  const source=state.prometheusSources.find(s=>Number(s.id)===Number(id));
  try{
    if(action==='edit'){openPrometheus(source);return}
    if(action==='delete'){
      if(!confirm(`Ștergi sursa ${source?.name||id} și targeturile sincronizate din ea?`))return;
      await api(`/api/v1/monitoring/sources/${id}`,{method:'DELETE'});toast('Sursa Prometheus a fost ștearsă.');monitoringPage('sources');return;
    }
    if(action==='test'){
      const r=await api(`/api/v1/monitoring/sources/${id}/test`,{method:'POST'});
      toast(`Prometheus OK · ${r.version||'versiune necunoscută'} · ${Number(r.target_count||0)} targeturi active${r.agent_associated?` · agent ${r.agent_name||''} · hosts ${r.hosts_available?Number(r.hosts_entry_count||0)+' intrări':'indisponibil'}`:' · fără agent asociat'}.`);return;
    }
    if(action==='sync'){
      const r=await api(`/api/v1/monitoring/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea ${r.id} a fost pornită.`);
      [1000,3000,6000].forEach(delay=>setTimeout(()=>{if((location.hash||'').startsWith('#monitoring'))monitoringPage(monitoringCurrentSection())},delay));
    }
  }catch(err){toast(err.message,true)}
}
function monitoringVMQuery(){const f=state.monitoringVMFilters,p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize)});if(f.q)p.set('q',f.q);if(f.state)p.set('state',f.state);if(f.power)p.set('power',f.power);return p.toString()}
function monitoringTargetQuery(){const f=state.monitoringTargetFilters,p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize)});if(f.q)p.set('q',f.q);if(f.sourceType)p.set('source_type',f.sourceType);if(f.health)p.set('health',f.health);if(f.matched)p.set('matched',f.matched);return p.toString()}
function pct(value,total){return total?`${Math.round(Number(value||0)*100/total)}%`:'0%'}
function monitoringStateBadge(value){const labels={monitored:'Monitorizată',down:'Target DOWN',exporter_only:'Exporter fără target',exporter_stopped:'Exporter oprit',unmonitored:'Nemontorizată'};return `<span class="badge monitoring-${e(value||'unknown')}">${e(labels[value]||value||'—')}</span>`}
function renderMonitoringVMs(result){
  const f=state.monitoringVMFilters;f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
  const filters=`<div class="filterbar monitoring-filterbar"><label class="monitoring-search-field"><span>Caută</span><input id="monitoringVMSearch" type="search" value="${e(f.q)}" placeholder="VM, job, target, sursă sau exporter"></label><label><span>Stare</span><select id="monitoringVMState"><option value="" ${!f.state?'selected':''}>Toate</option><option value="monitored" ${f.state==='monitored'?'selected':''}>Monitorizate</option><option value="up" ${f.state==='up'?'selected':''}>Target UP</option><option value="down" ${f.state==='down'?'selected':''}>Target DOWN</option><option value="exporter_only" ${f.state==='exporter_only'?'selected':''}>Exporter fără target</option><option value="unmonitored" ${f.state==='unmonitored'?'selected':''}>Fără Prometheus</option><option value="no_exporter" ${f.state==='no_exporter'?'selected':''}>Fără Node Exporter</option></select></label><label><span>Power</span><select id="monitoringVMPower"><option value="" ${!f.power?'selected':''}>Toate</option><option value="POWERED_ON" ${f.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${f.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${f.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label><button id="clearMonitoringVMFilters" class="secondary monitoring-reset-filter" type="button">Resetează</button></div>`;
  const items=Array.isArray(result?.items)?result.items:[],rows=items.map(v=>`<tr><td><a href="#vms/${v.vm_id}/monitoring"><strong>${e(v.vm_name)}</strong></a></td><td>${powerShortBadge(v.power_state)}</td><td>${v.exporter_installed?(v.exporter_running?badge('running'):badge('stopped')):badge('absent')}<div class="muted">${e(v.exporter_version||'')}${v.exporter_endpoint?` · ${e(v.exporter_endpoint)}`:''}</div></td><td>${monitoringStateBadge(v.monitoring_state)}</td><td>${v.metrics_monitored?(v.metrics_up?badge('up'):badge('down')):'—'}<div class="muted">${e(v.metrics_source||'')} ${e(v.metrics_job||'')}</div></td><td class="mono">${e(v.metrics_target||'—')}</td><td>${e(v.metrics_match||'—')}</td><td>${v.blackbox_monitored?(v.blackbox_up?badge('up'):badge('down')):'—'}<div class="muted">${Number(v.blackbox_targets||0)} probe</div></td></tr>`).join('');
  const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total),pager=`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="monitoringVMPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result?.pages||1),'monitoring-vm-page')}</div></div>`;
  return `${filters}${rows?`<div class="table-wrap monitoring-vm-table"><table><thead><tr><th>VM</th><th>Power</th><th>Node Exporter</th><th>Stare</th><th>Prometheus</th><th>Target</th><th>Corelare</th><th>Blackbox</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există VM-uri pentru filtrele selectate.')}${pager}`;
}
function updateMonitoringCards(r){const total=Number(r.total||0),set=(id,v)=>{const n=document.getElementById(id);if(n)n.textContent=v};set('monTotal',total);set('monExporter',Number(r.exporter_running_count||0));set('monExporterPct',pct(r.exporter_running_count,total));set('monMetrics',Number(r.metrics_monitored_count||0));set('monMetricsPct',pct(r.metrics_monitored_count,total));set('monUp',Number(r.metrics_up_count||0));set('monDown',Number(r.metrics_down_count||0));set('monBlackbox',Number(r.blackbox_monitored_count||0));set('monBlackboxPct',pct(r.blackbox_monitored_count,total))}
function renderMonitoringTargets(result){
  const f=state.monitoringTargetFilters;f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
  const filters=`<div class="filterbar monitoring-target-filterbar"><label class="monitoring-search-field"><span>Caută target</span><input id="monitoringTargetSearch" type="search" value="${e(f.q)}" placeholder="instance, URL, job, VM"></label><label><span>Tip</span><select id="monitoringTargetType"><option value="" ${!f.sourceType?'selected':''}>Toate</option><option value="metrics" ${f.sourceType==='metrics'?'selected':''}>Metrics</option><option value="blackbox" ${f.sourceType==='blackbox'?'selected':''}>Blackbox</option></select></label><label><span>Health</span><select id="monitoringTargetHealth"><option value="" ${!f.health?'selected':''}>Toate</option><option value="up" ${f.health==='up'?'selected':''}>UP</option><option value="down" ${f.health==='down'?'selected':''}>DOWN</option></select></label><label><span>Corelare VM</span><select id="monitoringTargetMatched"><option value="" ${!f.matched?'selected':''}>Toate</option><option value="yes" ${f.matched==='yes'?'selected':''}>Corelate</option><option value="no" ${f.matched==='no'?'selected':''}>Necorelate</option></select></label><button id="clearMonitoringTargetFilters" class="secondary monitoring-reset-filter" type="button">Resetează</button></div>`;
  const items=Array.isArray(result?.items)?result.items:[],rows=items.map(t=>`<tr><td>${badge(t.source_type)}</td><td><strong>${e(t.prometheus_source_name)}</strong><div class="muted">${e(t.job_name||'—')}</div></td><td class="mono">${e(t.target_url||t.instance||'—')}</td><td>${targetVisualStatus(t)}</td><td>${t.http_status_code??'—'}</td><td>${t.probe_duration_seconds!=null?`${(Number(t.probe_duration_seconds)*1000).toFixed(0)} ms`:'—'}</td><td>${t.tls_expiry_at?dt(t.tls_expiry_at):'—'}</td><td>${t.matched_vm_id?`<a href="#vms/${t.matched_vm_id}/monitoring">${e(t.matched_vm_name)}</a>`:'<span class="muted">Necorelat</span>'}<div class="muted">${e(t.match_method||'')}${t.match_value?` · <span class="mono">${e(t.match_value)}</span>`:''}</div></td><td class="error-text">${e(t.last_error||'—')}</td></tr>`).join('');
  const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total);
  return `${filters}<div class="target-summary-line"><span>UP <strong>${Number(result.up_count||0)}</strong></span><span>DOWN <strong>${Number(result.down_count||0)}</strong></span><span>Corelate <strong>${Number(result.matched_count||0)}</strong></span><span>Necorelate <strong>${Number(result.unmatched_count||0)}</strong></span></div>${rows?`<div class="table-wrap monitoring-target-table"><table><thead><tr><th>Tip</th><th>Sursă / job</th><th>Target</th><th>Stare</th><th>HTTP</th><th>Durată</th><th>TLS expiră</th><th>VM / corelare</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există targeturi pentru filtrele selectate.')}<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="monitoringTargetPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result?.pages||1),'monitoring-target-page')}</div></div>`;
}
function targetVisualStatus(t){if(t.probe_success!==undefined&&t.probe_success!==null)return t.probe_success?badge('up'):badge('down');return badge(t.health||'unknown')}
function renderMonitoringRuns(result){const p=state.monitoringRunPaging;p.page=Number(result?.page||1);p.pageSize=Number(result?.page_size||p.pageSize||10);const items=Array.isArray(result?.items)?result.items:[],rows=items.map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.prometheus_source_name||'—')}</td><td>${badge(r.status)}</td><td>${Number(r.target_count||0)}</td><td>${Number(r.matched_vm_count||0)}</td><td>${Number(r.up_count||0)}</td><td>${Number(r.down_count||0)}</td><td>${Number(r.unmatched_count||0)}</td><td>${Number(r.ambiguous_count||0)}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total);return `${rows?`<div class="table-wrap monitoring-run-table"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Targeturi</th><th>VM corelate</th><th>UP</th><th>DOWN</th><th>Necorelate</th><th>Ambigue</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există sincronizări Prometheus.')}<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="monitoringRunPageSize">${pageSizeOptions(pageSize,[10,25,50,100])}</select></label>${paginationButtons(page,Number(result?.pages||1),'monitoring-run-page')}</div></div>`}
function bindMonitoringControls(){
  let timer;document.getElementById('monitoringVMSearch')?.addEventListener('input',ev=>{clearTimeout(timer);const value=ev.target.value,pos=ev.target.selectionStart??value.length;timer=setTimeout(()=>{state.monitoringVMFilters.q=value.trim();state.monitoringVMFilters.page=1;loadMonitoringVMs(pos)},250)});[['monitoringVMState','state'],['monitoringVMPower','power']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{state.monitoringVMFilters[key]=ev.target.value;state.monitoringVMFilters.page=1;loadMonitoringVMs()}));document.getElementById('clearMonitoringVMFilters')?.addEventListener('click',()=>{state.monitoringVMFilters={q:'',state:'',power:'',page:1,pageSize:10};loadMonitoringVMs(0)});document.querySelectorAll('.monitoring-vm-page').forEach(b=>b.onclick=()=>{state.monitoringVMFilters.page=Number(b.dataset.page);loadMonitoringVMs()});document.getElementById('monitoringVMPageSize')?.addEventListener('change',ev=>{state.monitoringVMFilters.pageSize=Number(ev.target.value);state.monitoringVMFilters.page=1;loadMonitoringVMs()});
  let tt;document.getElementById('monitoringTargetSearch')?.addEventListener('input',ev=>{clearTimeout(tt);const value=ev.target.value,pos=ev.target.selectionStart??value.length;tt=setTimeout(()=>{state.monitoringTargetFilters.q=value.trim();state.monitoringTargetFilters.page=1;loadMonitoringTargets(pos)},250)});[['monitoringTargetType','sourceType'],['monitoringTargetHealth','health'],['monitoringTargetMatched','matched']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{state.monitoringTargetFilters[key]=ev.target.value;state.monitoringTargetFilters.page=1;loadMonitoringTargets()}));document.getElementById('clearMonitoringTargetFilters')?.addEventListener('click',()=>{state.monitoringTargetFilters={q:'',sourceType:'',health:'',matched:'',page:1,pageSize:10};loadMonitoringTargets(0)});document.querySelectorAll('.monitoring-target-page').forEach(b=>b.onclick=()=>{state.monitoringTargetFilters.page=Number(b.dataset.page);loadMonitoringTargets()});document.getElementById('monitoringTargetPageSize')?.addEventListener('change',ev=>{state.monitoringTargetFilters.pageSize=Number(ev.target.value);state.monitoringTargetFilters.page=1;loadMonitoringTargets()});
}
async function loadMonitoringVMs(focusPosition=null){const area=document.getElementById('monitoringVMTableArea');if(!area)return;try{const r=await api(`/api/v1/monitoring/vms?${monitoringVMQuery()}`);updateMonitoringCards(r);area.innerHTML=renderMonitoringVMs(r);bindMonitoringControls();updateMonitoringExportLinks();if(focusPosition!==null){const input=document.getElementById('monitoringVMSearch');if(input){input.focus();const pos=Math.min(Number(focusPosition)||0,input.value.length);input.setSelectionRange(pos,pos)}}}catch(err){toast(err.message,true)}}
async function loadMonitoringTargets(focusPosition=null){const area=document.getElementById('monitoringTargetTableArea');if(!area)return;try{const r=await api(`/api/v1/monitoring/targets?${monitoringTargetQuery()}`);area.innerHTML=renderMonitoringTargets(r);bindMonitoringControls();updateMonitoringExportLinks();if(focusPosition!==null){const input=document.getElementById('monitoringTargetSearch');if(input){input.focus();const pos=Math.min(Number(focusPosition)||0,input.value.length);input.setSelectionRange(pos,pos)}}}catch(err){toast(err.message,true)}}
function monitoringSourceRows(){
  return state.prometheusSources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${badge(s.source_type)}</td><td>${s.agent_id?`<strong>${e(s.agent_name||('#'+s.agent_id))}</strong><div class="muted">${e(s.agent_version||'')}${s.agent_inventory_id?` · inventar #${s.agent_inventory_id}`:''}</div>`:'<span class="muted">Neasociat</span>'}</td><td>${e(s.auth_mode||'none')}${s.username?`<div class="muted">${e(s.username)}</div>`:''}</td><td><span class="mono">${e(s.vm_label||'—')}</span><div class="muted">target: ${e(s.target_label||'instance')}</div></td><td>${veeamIntervalLabel(s.sync_interval_minutes)}<div class="muted">${s.enabled?'Activ':'Dezactivat'}</div></td><td>${dt(s.last_success_at)}${s.last_sync_at?`<div class="muted">Încercare: ${dt(s.last_sync_at)}</div>`:''}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions monitoring-source-actions">${can('monitoring.manage')?`<button class="small secondary prometheus-action" data-action="test" data-id="${s.id}">Test</button><button class="small prometheus-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary prometheus-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger prometheus-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
}
async function monitoringPage(section='overview'){
  section=section==='sources'?'sources':'overview';
  if((location.hash||'')==='#monitoring')history.replaceState(null,'','#monitoring/overview');
  const nav=monitoringSectionNavigation(section);
  if(section==='sources'){
    pageMeta('Monitorizare','Surse Prometheus / Blackbox și istoricul sincronizărilor');
    const p=state.monitoringRunPaging||{page:1,pageSize:10};
    const [sources,agentOptions,runs]=await Promise.all([api('/api/v1/monitoring/sources'),api('/api/v1/monitoring/agent-options'),api(`/api/v1/monitoring/sync-runs?page=${p.page}&page_size=${p.pageSize}`)]);
    state.prometheusSources=Array.isArray(sources)?sources:[];state.prometheusAgentOptions=Array.isArray(agentOptions)?agentOptions:[];
    const sourceRows=monitoringSourceRows();
    const tools=can('monitoring.manage')?'<button id="syncAllPrometheus">Sincronizează toate</button><button id="newPrometheus" class="secondary">Adaugă sursă</button>':'';
    const hint='<div class="baseline-hint monitoring-source-hint"><strong>Corelare</strong><span>Prioritate: <b>label explicit</b> → FQDN → hostname → IP → <b>/etc/hosts al agentului asociat</b> → alias manual. IP-urile vCenter de pe toate interfețele guest sunt incluse în matching.</span></div>';
    content.innerHTML=`<div class="monitoring-workspace">${nav}${panel('Surse Prometheus',`${hint}${sourceRows?`<div class="table-wrap monitoring-source-table"><table><thead><tr><th>Sursă</th><th>Tip</th><th>Agent asociat</th><th>Auth</th><th>Corelare</th><th>Program</th><th>Ultimul sync</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse Prometheus configurate.')}`,tools)}${panel('Ultimele sincronizări',renderMonitoringRuns(runs))}</div>`;
    document.getElementById('newPrometheus')?.addEventListener('click',()=>openPrometheus());
    document.getElementById('syncAllPrometheus')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/monitoring/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări introduse în coadă.`);setTimeout(()=>monitoringPage('sources'),1200)}catch(err){toast(err.message,true)}});
    content.querySelectorAll('.prometheus-action').forEach(b=>b.onclick=()=>prometheusAction(b.dataset.action,Number(b.dataset.id)));
    document.querySelectorAll('.monitoring-run-page').forEach(b=>b.onclick=()=>{state.monitoringRunPaging.page=Number(b.dataset.page);monitoringPage('sources')});
    document.getElementById('monitoringRunPageSize')?.addEventListener('change',ev=>{state.monitoringRunPaging.pageSize=Number(ev.target.value);state.monitoringRunPaging.page=1;monitoringPage('sources')});
    return;
  }
  pageMeta('Monitorizare','Node Exporter → Prometheus → Blackbox · stare și corelare VM');
  const [vms,targets]=await Promise.all([api(`/api/v1/monitoring/vms?${monitoringVMQuery()}`),api(`/api/v1/monitoring/targets?${monitoringTargetQuery()}`)]);
  const cards=`<div class="cards monitoring-summary-cards"><div class="card"><div class="label">VM-uri</div><div id="monTotal" class="value">${Number(vms.total||0)}</div><div class="muted">Conform filtrelor curente</div></div><div class="card"><div class="label">Node Exporter pornit</div><div id="monExporter" class="value">0</div><div id="monExporterPct" class="backup-percent">0%</div></div><div class="card"><div class="label">În Prometheus</div><div id="monMetrics" class="value">0</div><div id="monMetricsPct" class="backup-percent">0%</div></div><div class="card"><div class="label">VM metrics UP / DOWN</div><div class="value compact"><span id="monUp">0</span> / <span id="monDown">0</span></div></div><div class="card"><div class="label">Cu Blackbox</div><div id="monBlackbox" class="value">0</div><div id="monBlackboxPct" class="backup-percent">0%</div></div></div>`;
  content.innerHTML=`<div class="monitoring-workspace">${nav}${cards}${panel('VM-uri și monitorizare',`<div id="monitoringVMTableArea">${renderMonitoringVMs(vms)}</div>`,`<a id="exportMonitoringVMs" class="button secondary" href="/api/v1/monitoring/vms/export">Export Excel</a>`)}${panel('Targeturi Prometheus / Blackbox',`<div id="monitoringTargetTableArea">${renderMonitoringTargets(targets)}</div>`,`<a id="exportMonitoringTargets" class="button secondary" href="/api/v1/monitoring/targets/export">Export Excel</a>`)}</div>`;
  updateMonitoringCards(vms);bindMonitoringControls();updateMonitoringExportLinks();
}
prometheusForm.addEventListener('submit',async event=>{
  event.preventDefault();
  const id=Number(document.getElementById('prometheusId').value||0),body={name:document.getElementById('prometheusName').value.trim(),base_url:document.getElementById('prometheusURL').value.trim(),source_type:document.getElementById('prometheusType').value,auth_mode:document.getElementById('prometheusAuthMode').value,username:document.getElementById('prometheusUsername').value.trim(),secret:document.getElementById('prometheusSecret').value,vm_label:document.getElementById('prometheusVMLabel').value.trim(),target_label:document.getElementById('prometheusTargetLabel').value.trim(),agent_id:Number(document.getElementById('prometheusAgent').value||0),sync_interval_minutes:Number(document.getElementById('prometheusSyncInterval').value),enabled:document.getElementById('prometheusEnabled').checked,verify_tls:document.getElementById('prometheusVerifyTLS').checked,tls_server_name:document.getElementById('prometheusTLSServerName').value.trim()};
  if(id&&!body.secret)delete body.secret;
  try{await api(id?`/api/v1/monitoring/sources/${id}`:'/api/v1/monitoring/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});prometheusDialog.close();toast(id?'Sursa Prometheus a fost actualizată.':'Sursa Prometheus a fost creată.');monitoringPage('sources')}catch(err){toast(err.message,true)}
});

function fieldLabel(key){
  const labels={hostname:'Hostname',fqdn:'FQDN',uuid:'UUID',product_uuid:'Product UUID',machine_id:'Machine ID',pretty_name:'Denumire OS',version_id:'Versiune',primary_ip:'IP principal',boot_time:'Pornire sistem',uptime_seconds:'Uptime',status:'Stare',name:'Nume',software_name:'Software',version:'Versiune',package_name:'Pachet',package_version:'Versiune pachet',version_source:'Sursă versiune',enabled:'Activ',active:'Activ',installed:'Instalat',service:'Serviciu',port:'Port',protocol:'Protocol',address:'Adresă',mount_point:'Mount point',username:'Username',command:'Comandă',classification:'Clasificare',classification_reason:'Motiv clasificare'};
  if(labels[key])return labels[key];
  return String(key||'').replaceAll('_',' ').replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase());
}
function humanUptimeSeconds(raw){
  let total=Math.max(0,Math.floor(Number(raw)||0));
  const units=[['an','ani',365*24*3600],['lună','luni',30*24*3600],['zi','zile',24*3600],['oră','ore',3600],['minut','minute',60]];
  const parts=[];
  for(const [one,many,size] of units){const value=Math.floor(total/size);if(value>0){parts.push(`${value} ${value===1?one:many}`);total-=value*size}if(parts.length>=4)break}
  return parts.length?parts.join(', '):'sub un minut';
}
function inventoryItemSummary(item,index,parentKey=''){
  if(item&&typeof item==='object'&&!Array.isArray(item)){
    if(item.mount_point!==undefined&&String(item.mount_point).trim()!=='')return String(item.mount_point);
    if(item.port!==undefined&&String(item.port).trim()!=='')return `${item.port}${item.protocol?` / ${item.protocol}`:''}`;
    if(item.username!==undefined&&String(item.username).trim()!=='')return String(item.username);
    if(item.command!==undefined&&String(item.command).trim()!=='')return String(item.command).length>90?String(item.command).slice(0,87)+'…':String(item.command);
    if(item.name!==undefined&&String(item.name).trim()!=='')return String(item.name);
    if(item.path!==undefined&&String(item.path).trim()!=='')return String(item.path);
    if(item.address!==undefined&&String(item.address).trim()!=='')return String(item.address);
  }
  return `Element ${index+1}`;
}
function serviceState(item,stale=false){
  if(stale||String(item?.active_state||'').toLowerCase()==='missing')return 'missing';
  return String(item?.active_state||'').toLowerCase()==='active'?'active':'inactive';
}
function serviceStateLabel(value){return value==='active'?'<span class="badge active">Activ</span>':value==='missing'?'<span class="badge missing">Nedetectat</span>':'<span class="badge disabled">Inactiv</span>'}
function serviceClassification(item){
  const value=String(item?.classification||'').trim().toLowerCase();
  return ['system','application','unknown'].includes(value)?value:'unknown';
}
function serviceClassificationLabel(value){
  const classification=String(value||'unknown').toLowerCase();
  if(classification==='application')return '<span class="badge active">Aplicație</span>';
  if(classification==='system')return '<span class="badge disabled">Sistem OS</span>';
  return '<span class="badge">Necunoscut</span>';
}
function serviceInventoryList(value,context={}){
  const selected=new Set((context.primaryServices||[]).map(item=>String(item.service_name||'').toLowerCase()));
  const observed=new Set((value||[]).map(item=>String(item?.name||'').toLowerCase()));
  const stale=(context.primaryServices||[]).filter(item=>!observed.has(String(item.service_name||'').toLowerCase()));
  const rows=[...(value||[]).map(item=>({item,stale:false})),...stale.map(item=>({item:{name:item.service_name,active_state:'missing',description:'Serviciu principal nedetectat în inventarul curent',classification:item.classification||'unknown',classification_reason:item.classification_reason||''},stale:true}))]
    .sort((a,b)=>{const ap=selected.has(String(a.item?.name||'').toLowerCase())?0:1,bp=selected.has(String(b.item?.name||'').toLowerCase())?0:1;return ap-bp||String(a.item?.name||'').localeCompare(String(b.item?.name||''),'ro')});
  const reviewChecked=!!context.servicesReviewed;
  const reviewControl=context.canManage?`<div class="agent-services-review"><label><input id="vmAgentServicesReviewed" type="checkbox" ${reviewChecked?'checked':''}><span><strong>Servicii verificate</strong><small>Bifează după verificarea categoriei. Dacă nu există niciun serviciu marcat Principal, această confirmare satisface criteriul de completare.</small></span></label></div>`:(reviewChecked?'<div class="agent-services-review readonly"><strong>Servicii verificate</strong><small>Categoria a fost verificată manual.</small></div>':'');
  if(!rows.length)return `${reviewControl}<span class="muted">Listă goală</span>`;
  const filter=`<div class="filterbar service-inventory-filterbar"><label><span>Caută serviciu</span><input id="vmAgentServiceSearch" type="search" placeholder="tomcat, solr, postgres…"></label><label><span>Stare</span><select id="vmAgentServiceStatus"><option value="active" selected>Active</option><option value="inactive">Inactive</option><option value="missing">Nedetectate</option><option value="all">Toate</option></select></label><label><span>Tip serviciu</span><select id="vmAgentServiceClassification"><option value="non-system" selected>Aplicație + necunoscut</option><option value="application">Aplicație</option><option value="unknown">Necunoscut</option><option value="system">Sistem OS</option><option value="all">Toate</option></select></label><span id="vmAgentServiceCount" class="muted"></span></div>`;
  return `${reviewControl}${filter}<div class="structured-list service-inventory-list">${rows.map(({item,stale})=>{const name=String(item?.name||'Serviciu');const checked=selected.has(name.toLowerCase());const rawVersion=item?.version||item?.package_version||'',version=shortVersionText(rawVersion)||cleanVersionText(rawVersion);const status=serviceState(item,stale),classification=serviceClassification(item);const search=[name,item?.software_name,item?.description,version,item?.package_name,classification,item?.classification_reason].filter(Boolean).join(' ').toLowerCase();const checkbox=context.canManage?`<label class="primary-service-check" title="Include ca serviciu software principal în documentație"><input type="checkbox" class="primary-agent-service-toggle" data-service="${e(name)}" ${checked?'checked':''}><span>Principal</span></label>`:(checked?'<span class="badge primary">Principal</span>':'');return `<details class="service-inventory-row ${stale?'stale-primary-service':''}" data-service-status="${status}" data-service-classification="${classification}" data-service-primary="${checked?'true':'false'}" data-service-search="${e(search)}"><summary><span class="inventory-summary-main"><strong>${e(name)}</strong> ${serviceStateLabel(status)} ${serviceClassificationLabel(classification)}${version?` <span class="muted">· ${e(version)}</span>`:''}</span>${checkbox}</summary>${structuredValue(item,1,{...context,parentKey:'services'})}</details>`}).join('')}</div>`;
}
function applyServiceInventoryFilters(){
  const search=document.getElementById('vmAgentServiceSearch'),status=document.getElementById('vmAgentServiceStatus'),classification=document.getElementById('vmAgentServiceClassification'),rows=[...document.querySelectorAll('.service-inventory-row')];if(!rows.length)return;
  const q=String(search?.value||'').trim().toLowerCase(),wanted=status?.value||'active',wantedClass=classification?.value||'non-system';let shown=0;
  rows.forEach(row=>{const primary=row.dataset.servicePrimary==='true',actualClass=row.dataset.serviceClassification||'unknown',okStatus=primary||wanted==='all'||row.dataset.serviceStatus===wanted,okClass=primary||wantedClass==='all'||(wantedClass==='non-system'&&actualClass!=='system')||actualClass===wantedClass,okSearch=!q||String(row.dataset.serviceSearch||'').includes(q);row.hidden=!(okStatus&&okClass&&okSearch);if(!row.hidden)shown++});
  const count=document.getElementById('vmAgentServiceCount');if(count)count.textContent=`${shown} din ${rows.length}`;
}
function bindServiceInventoryFilters(){
  const search=document.getElementById('vmAgentServiceSearch'),status=document.getElementById('vmAgentServiceStatus'),classification=document.getElementById('vmAgentServiceClassification');let timer;
  search?.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(applyServiceInventoryFilters,120)});status?.addEventListener('change',applyServiceInventoryFilters);classification?.addEventListener('change',applyServiceInventoryFilters);applyServiceInventoryFilters();
}
function primaryPortKey(protocol,port,processName){return `${String(protocol||'').trim().toLowerCase()}/${Number(port||0)}/${String(processName||'').trim().toLowerCase()}`}
function normalizedListeningPorts(value){
  const merged=new Map();
  for(const endpoint of (Array.isArray(value)?value:[])){
    const protocol=String(endpoint?.protocol||'').trim().toLowerCase(),port=Number(endpoint?.port||0),address=String(endpoint?.address||endpoint?.local_address||endpoint?.listen||'').trim();
    if(!protocol||!port)continue;
    let processes=Array.isArray(endpoint?.processes)?endpoint.processes:[];
    if(!processes.length)processes=[{name:endpoint?.name||endpoint?.process_name||'',pid:endpoint?.pid||'',executable:endpoint?.executable||endpoint?.exec||''}];
    for(const process of processes){
      const processName=String(process?.name||process?.process||process?.process_name||process?.service||process?.program||'').trim();
      const executable=String(process?.executable||process?.exec||process?.exec_path||process?.binary||process?.path||process?.command||'').trim();
      const pid=Number(process?.pid||process?.process_id||0),key=primaryPortKey(protocol,port,processName);
      const current=merged.get(key)||{protocol,port,process_name:processName,pids:[],executable:'',addresses:[],detected:true};
      if(pid>0&&!current.pids.includes(pid))current.pids.push(pid);
      if(address&&!current.addresses.includes(address))current.addresses.push(address);
      if(!current.executable&&executable)current.executable=executable;
      merged.set(key,current);
    }
  }
  return [...merged.values()].map(item=>({...item,pids:item.pids.sort((a,b)=>a-b),addresses:item.addresses.sort((a,b)=>a.localeCompare(b,'ro'))}));
}
function portInventoryList(value,context={}){
  const selectedValues=Array.isArray(context.primaryPorts)?context.primaryPorts:[],selected=new Set(selectedValues.map(item=>primaryPortKey(item.protocol,item.port,item.process_name)));
  const observed=normalizedListeningPorts(value),observedKeys=new Set(observed.map(item=>primaryPortKey(item.protocol,item.port,item.process_name)));
  const stale=selectedValues.filter(item=>!observedKeys.has(primaryPortKey(item.protocol,item.port,item.process_name))).map(item=>({...item,detected:false,pids:[],addresses:[]}));
  const rows=[...observed,...stale].sort((a,b)=>{const ap=selected.has(primaryPortKey(a.protocol,a.port,a.process_name))?0:1,bp=selected.has(primaryPortKey(b.protocol,b.port,b.process_name))?0:1;return ap-bp||Number(a.port)-Number(b.port)||String(a.protocol).localeCompare(String(b.protocol))||String(a.process_name||'').localeCompare(String(b.process_name||''),'ro')});
  if(!rows.length)return '<span class="muted">Listă goală</span>';
  const filter=`<div class="filterbar service-inventory-filterbar"><label><span>Caută port / proces</span><input id="vmAgentPortSearch" type="search" placeholder="8100, soffice.bin, java, solr…"></label><label><span>Afișare</span><select id="vmAgentPortStatus"><option value="all" selected>Toate</option><option value="selected">Principale</option><option value="detected">Detectate</option><option value="missing">Nedetectate</option></select></label><span id="vmAgentPortCount" class="muted"></span></div>`;
  const html=rows.map(item=>{const key=primaryPortKey(item.protocol,item.port,item.process_name),checked=selected.has(key),detected=item.detected!==false,processName=String(item.process_name||'').trim(),search=[item.port,item.protocol,processName,item.executable,...(item.addresses||[])].filter(Boolean).join(' ').toLowerCase(),status=!detected?'missing':checked?'selected':'detected';const checkbox=context.canManage?`<label class="primary-service-check" title="Include portul/procesul ca principal în documentația VM"><input type="checkbox" class="primary-agent-port-toggle" data-protocol="${e(item.protocol)}" data-port="${e(item.port)}" data-process="${e(processName)}" ${checked?'checked':''}><span>Principal</span></label>`:(checked?'<span class="badge primary">Principal</span>':'');const processLabel=processName?` · ${e(processName)}`:'';return `<details class="service-inventory-row port-inventory-row ${!detected?'stale-primary-service':''}" data-port-status="${status}" data-port-search="${e(search)}"><summary><span class="inventory-summary-main"><strong>${e(item.port)} / ${e(String(item.protocol||'').toUpperCase())}</strong>${processLabel} ${!detected?'<span class="badge missing">Nedetectat</span>':''}</span>${checkbox}</summary><dl class="inventory-kv"><div><dt>Proces</dt><dd>${e(processName||'—')}</dd></div><div><dt>PID</dt><dd>${(item.pids||[]).length?e(item.pids.join(', ')):'—'}</dd></div><div><dt>Executabil</dt><dd class="mono pre-wrap">${e(item.executable||'—')}</dd></div><div><dt>Adresă listen</dt><dd class="mono">${(item.addresses||[]).length?e(item.addresses.join(', ')):'—'}</dd></div></dl></details>`}).join('');
  return `${filter}<div class="structured-list service-inventory-list port-inventory-list">${html}</div>`;
}
function applyPortInventoryFilters(){
  const search=document.getElementById('vmAgentPortSearch'),status=document.getElementById('vmAgentPortStatus'),rows=[...document.querySelectorAll('.port-inventory-row')];if(!rows.length)return;
  const q=String(search?.value||'').trim().toLowerCase(),wanted=status?.value||'all';let shown=0;
  rows.forEach(row=>{const actual=row.dataset.portStatus||'detected',okStatus=wanted==='all'||actual===wanted||(wanted==='detected'&&actual!=='missing'),okSearch=!q||String(row.dataset.portSearch||'').includes(q);row.hidden=!(okStatus&&okSearch);if(!row.hidden)shown++});
  const count=document.getElementById('vmAgentPortCount');if(count)count.textContent=`${shown} din ${rows.length}`;
}
function bindPortInventoryFilters(){const search=document.getElementById('vmAgentPortSearch'),status=document.getElementById('vmAgentPortStatus');let timer;search?.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(applyPortInventoryFilters,120)});status?.addEventListener('change',applyPortInventoryFilters);applyPortInventoryFilters()}

function routesInventoryTable(value){
  const rows=Array.isArray(value)?value:[];if(!rows.length)return '<span class="muted">Nu sunt rute raportate.</span>';
  return `<div class="table-wrap inventory-table"><table><thead><tr><th>Familie</th><th>Destinație</th><th>Gateway</th><th>Interfață</th><th>Protocol</th><th>Sursă</th><th>Default</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${e(r?.family||'—')}</td><td class="mono">${e(r?.destination||'—')}</td><td class="mono">${e(r?.gateway||'—')}</td><td>${e(r?.interface||'—')}</td><td>${e(r?.protocol||'—')}</td><td class="mono">${e(r?.source||'—')}</td><td>${r?.default?badge('Da'):'Nu'}</td></tr>`).join('')}</tbody></table></div>`;
}
function firewallRuleTable(rules){
  const rows=Array.isArray(rules)?rules:[];if(!rows.length)return '<span class="muted">Nu există reguli.</span>';
  return `<div class="table-wrap inventory-table"><table><thead><tr><th>Backend</th><th>Familie</th><th>Tabel</th><th>Chain</th><th>Acțiune</th><th>Regulă</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${e(r?.backend||'—')}</td><td>${e(r?.family||'—')}</td><td>${e(r?.table||'—')}</td><td>${e(r?.chain||'—')}</td><td>${e(r?.action||'—')}</td><td class="mono pre-wrap">${e(r?.rule||'—')}</td></tr>`).join('')}</tbody></table></div>`;
}
function firewallInventory(value,context={}){
  const data=value&&typeof value==='object'?value:{},backends=Array.isArray(data.backends)?data.backends:[],rules=Array.isArray(data.rules)?data.rules:[],backendSet=new Set(backends.map(v=>String(v).toLowerCase())),managed=['ufw','firewalld','susefirewall2'].filter(v=>backendSet.has(v)),explicit=managed.length?rules.filter(r=>managed.includes(String(r?.backend||'').toLowerCase())):rules;
  const policies=Object.entries(data.default_policies||{});const zones=Array.isArray(data.zones)?data.zones:[];
  const summary=`<div class="detail-grid firewall-summary">${detail('Detectat',data.detected?'Da':'Nu')}${detail('Activ',data.active?'Da':'Nu')}${detail('Backend-uri',backends.length?backends.map(e).join(', '):'—')}${detail('Reguli configurate',String(explicit.length))}</div>`;
  const policyHTML=policies.length?`<div class="table-wrap inventory-table"><table><thead><tr><th>Backend / chain</th><th>Politică</th></tr></thead><tbody>${policies.map(([k,v])=>`<tr><td class="mono">${e(k)}</td><td>${e(v)}</td></tr>`).join('')}</tbody></table></div>`:'<span class="muted">Nu sunt raportate politici implicite.</span>';
  const explicitHTML=explicit.length?firewallRuleTable(explicit):empty(managed.includes('firewalld')?'Regulile firewalld sunt documentate prin zone, servicii și porturi.':'Nu există reguli configurate identificate.');
  const zoneHTML=zones.length?`<details class="firewall-extra"><summary>Zone firewalld (${zones.length})</summary>${structuredValue(zones,1,{...context,parentKey:'zones'})}</details>`:'';
  const configs=Array.isArray(data.config_files)&&data.config_files.length?`<details class="firewall-extra"><summary>Fișiere configurare (${data.config_files.length})</summary>${structuredValue(data.config_files,1,{...context,parentKey:'config_files'})}</details>`:'';
  return `${summary}<h4>Politici implicite</h4>${policyHTML}<h4>Reguli configurate</h4>${explicitHTML}${zoneHTML}${configs}`;
}
function structuredValue(value,depth=0,context={}){
  if(value===null||value===undefined||value==='')return '<span class="muted">—</span>';
  if(context.sectionKey==='firewall'&&depth===0&&value&&typeof value==='object'&&!Array.isArray(value))return firewallInventory(value,context);
  if(typeof value==='boolean')return value?badge('active'):badge('disabled');
  if(typeof value==='number'){
    if(context.parentKey==='uptime_seconds')return `<span>${e(humanUptimeSeconds(value))}</span>`;
    return `<span>${e(value)}</span>`;
  }
  if(typeof value==='string'){
    if(context.parentKey==='uptime_seconds'&&!Number.isNaN(Number(value)))return `<span>${e(humanUptimeSeconds(value))}</span>`;
    if(context.parentKey==='version'){const cleaned=shortVersionText(value)||cleanVersionText(value);return cleaned?`<span>${e(cleaned)}</span>`:'<span class="muted">—</span>'}
    if(context.parentKey==='package_version'){const cleaned=cleanVersionText(value);return cleaned?`<span>${e(cleaned)}</span>`:'<span class="muted">—</span>'}
    const low=value.toLowerCase();
    if(['ok','active','enabled','running','installed','success','succeeded','online','configured'].includes(low))return badge(low);
    if(['error','failed','disabled','stopped','missing','offline','not_installed','unconfigured','timeout'].includes(low))return badge(low);
    return `<span class="${value.length>70?'pre-wrap':''}">${e(value)}</span>`;
  }
  if(Array.isArray(value)){
    if(!value.length)return '<span class="muted">Listă goală</span>';
    if(context.sectionKey==='services'&&depth===0)return serviceInventoryList(value,context);
    if(context.sectionKey==='listening_ports'&&depth===0)return portInventoryList(value,context);
    if(context.sectionKey==='network'&&context.parentKey==='routes')return routesInventoryTable(value);
    const primitives=value.every(item=>item===null||['string','number','boolean'].includes(typeof item));
    if(primitives)return `<div class="value-list">${value.map(item=>`<span>${structuredValue(item,depth+1,context)}</span>`).join('')}</div>`;
    return `<div class="structured-list">${value.map((item,index)=>`<details><summary>${e(inventoryItemSummary(item,index,context.parentKey))}</summary>${structuredValue(item,depth+1,context)}</details>`).join('')}</div>`;
  }
  const entries=Object.entries(value);
  if(!entries.length)return '<span class="muted">Fără date</span>';
  return `<dl class="inventory-kv ${depth>1?'nested':''}">${entries.map(([key,item])=>`<div><dt>${e(fieldLabel(key))}</dt><dd>${structuredValue(item,depth+1,{...context,parentKey:key})}</dd></div>`).join('')}</dl>`;
}
function structuredInventory(documentView,{vmID=0,primaryServices=[],primaryPorts=[],servicesReviewed=false,canManage=false}={}){
  const sections=Array.isArray(documentView?.sections)?documentView.sections:[];
  if(!sections.length)return empty('Agentul nu a furnizat încă date structurate.');
  return `<div class="inventory-sections">${sections.map(section=>`<details class="inventory-section"><summary><span>${e(section.title||fieldLabel(section.key))}</span>${section.status?badge(section.status):''}</summary><div class="inventory-section-body">${structuredValue(section.data,0,{sectionKey:section.key,vmID,primaryServices,primaryPorts,servicesReviewed,canManage})}</div></details>`).join('')}</div>`;
}
function categoryItems(categories,code){return (categories||[]).find(item=>item.code===code)?.items||[]}
function selectOptions(items,selected,placeholder='— Neselectat —',label=value=>value.name){return `<option value="">${e(placeholder)}</option>${(items||[]).filter(item=>item.active||Number(item.id)===Number(selected)).map(item=>`<option value="${item.id}" ${Number(selected)===Number(item.id)?'selected':''}>${e(label(item))}${item.active?'':' (inactiv)'}</option>`).join('')}`}
function multiSelectOptions(items,selected=[]){const selectedSet=new Set((selected||[]).map(Number));return (items||[]).filter(item=>item.active||selectedSet.has(Number(item.id))).map(item=>`<option value="${item.id}" ${selectedSet.has(Number(item.id))?'selected':''}>${e(item.name)}${item.active?'':' (inactiv)'}</option>`).join('')}
function selectDropdownPortalHost(anchor){return anchor.closest('dialog')||document.body}
function positionSelectDropdown(anchor,dropdown){
  if(!anchor?.isConnected||!dropdown?.isConnected)return;
  const rect=anchor.getBoundingClientRect(),gap=5,viewportGap=10,maxAllowed=300;
  const availableBelow=Math.max(0,window.innerHeight-rect.bottom-gap-viewportGap),availableAbove=Math.max(0,rect.top-gap-viewportGap);
  // Measure the rendered list. Using its real height prevents a filtered list
  // from staying suspended too high when the dropdown is placed above the field.
  const previousMax=dropdown.style.maxHeight;dropdown.style.maxHeight=`${maxAllowed}px`;
  const naturalHeight=Math.min(maxAllowed,Math.max(1,dropdown.scrollHeight||dropdown.getBoundingClientRect().height||1));
  dropdown.style.maxHeight=previousMax;
  const locked=dropdown.dataset.lockedPlacement;
  const useAbove=locked?locked==='above':availableBelow<naturalHeight&&availableAbove>availableBelow;
  if(!locked)dropdown.dataset.lockedPlacement=useAbove?'above':'below';
  const available=useAbove?availableAbove:availableBelow;
  const maxHeight=Math.max(80,Math.min(maxAllowed,available||maxAllowed));
  const renderedHeight=Math.min(naturalHeight,maxHeight);
  const top=useAbove?Math.max(viewportGap,rect.top-gap-renderedHeight):Math.min(window.innerHeight-viewportGap-renderedHeight,rect.bottom+gap);
  const width=Math.min(Math.max(190,rect.width),Math.max(190,window.innerWidth-2*viewportGap));
  const left=Math.min(Math.max(viewportGap,rect.left),Math.max(viewportGap,window.innerWidth-width-viewportGap));
  Object.assign(dropdown.style,{position:'fixed',left:`${left}px`,right:'auto',top:`${Math.max(viewportGap,top)}px`,width:`${width}px`,maxHeight:`${maxHeight}px`,zIndex:'10050'});
  dropdown.dataset.placement=useAbove?'above':'below';
}
function scheduleSelectDropdownPosition(anchor,dropdown){
  cancelAnimationFrame(Number(dropdown.dataset.positionFrame||0));
  dropdown.dataset.positionFrame=String(requestAnimationFrame(()=>{delete dropdown.dataset.positionFrame;positionSelectDropdown(anchor,dropdown)}));
}
function mountSelectDropdown(anchor,dropdown){const host=selectDropdownPortalHost(anchor);if(dropdown.parentElement!==host)host.appendChild(dropdown);dropdown.classList.add('select-dropdown-portal');scheduleSelectDropdownPosition(anchor,dropdown)}
const enhancedMultiSelects=new WeakMap();
function destroyEnhancedMultiSelect(select){
  const current=enhancedMultiSelects.get(select);if(!current)return;
  current.cleanup?.();current.wrapper.remove();select.hidden=false;select.classList.remove('select2-lite-source');enhancedMultiSelects.delete(select);
}
function enhanceMultiSelect(select,{placeholder='Alege valorile'}={}){
  destroySearchableSelect(select);destroyEnhancedMultiSelect(select);if(!select.multiple)return;
  select.hidden=true;select.classList.add('select2-lite-source');
  const wrapper=document.createElement('div');wrapper.className='select2-lite';
  wrapper.innerHTML=`<button type="button" class="select2-lite-control" aria-haspopup="listbox" aria-expanded="false"><span class="select2-lite-values"></span><span class="select2-lite-arrow" aria-hidden="true"></span></button><div class="select2-lite-dropdown" hidden><input type="search" class="select2-lite-search" placeholder="Caută layer…" autocomplete="off"><div class="select2-lite-options" role="listbox" aria-multiselectable="true"></div></div>`;
  select.insertAdjacentElement('afterend',wrapper);
  const control=wrapper.querySelector('.select2-lite-control'),values=wrapper.querySelector('.select2-lite-values'),dropdown=wrapper.querySelector('.select2-lite-dropdown'),search=wrapper.querySelector('.select2-lite-search'),optionsArea=wrapper.querySelector('.select2-lite-options');
  function selectedOptions(){return [...select.options].filter(option=>option.selected)}
  function renderValues(){const selected=selectedOptions();values.innerHTML=selected.length?selected.map(option=>`<span class="select2-lite-chip">${e(option.textContent)}</span>`).join(''):`<span class="select2-lite-placeholder">${e(placeholder)}</span>`}
  function renderOptions(){const query=search.value.trim().toLocaleLowerCase('ro');const options=[...select.options].filter(option=>!query||option.textContent.toLocaleLowerCase('ro').includes(query));optionsArea.innerHTML=options.length?options.map(option=>`<label class="select2-lite-option"><input type="checkbox" value="${e(option.value)}" ${option.selected?'checked':''} ${option.disabled?'disabled':''}><span>${e(option.textContent)}</span></label>`).join(''):'<div class="select2-lite-empty">Niciun rezultat</div>';if(!dropdown.hidden)scheduleSelectDropdownPosition(control,dropdown)}
  const reposition=()=>{if(!dropdown.hidden)scheduleSelectDropdownPosition(control,dropdown)};
  function setOpen(open){if(open===!dropdown.hidden)return;dropdown.hidden=!open;control.setAttribute('aria-expanded',String(open));wrapper.classList.toggle('open',open);if(open){delete dropdown.dataset.lockedPlacement;mountSelectDropdown(control,dropdown);renderOptions();setTimeout(()=>search.focus({preventScroll:true}),0)}else delete dropdown.dataset.lockedPlacement}
  control.addEventListener('click',()=>setOpen(dropdown.hidden));
  search.addEventListener('input',renderOptions);
  search.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();setOpen(false);control.focus({preventScroll:true})}});
  optionsArea.addEventListener('change',event=>{const checkbox=event.target.closest('input[type="checkbox"]');if(!checkbox)return;const option=[...select.options].find(item=>item.value===checkbox.value);if(option)option.selected=checkbox.checked;renderValues();select.dispatchEvent(new Event('change',{bubbles:true}))});
  const outsideClick=event=>{if(!wrapper.contains(event.target)&&!dropdown.contains(event.target))setOpen(false)};document.addEventListener('click',outsideClick);window.addEventListener('resize',reposition);document.addEventListener('scroll',reposition,true);
  renderValues();enhancedMultiSelects.set(select,{wrapper,cleanup(){document.removeEventListener('click',outsideClick);window.removeEventListener('resize',reposition);document.removeEventListener('scroll',reposition,true);dropdown.remove()},refresh(){renderValues();renderOptions()}});
}


/* 0.16.2 · all single-value listboxes are searchable without changing their underlying values/events. */
const enhancedSearchableSelects=new WeakMap();
function destroySearchableSelect(select){
  const current=enhancedSearchableSelects.get(select);if(!current)return;
  current.cleanup?.();current.wrapper.remove();select.classList.remove('search-select-source');select.removeAttribute('aria-hidden');enhancedSearchableSelects.delete(select);
}
function refreshSearchableSelect(select){
  const current=enhancedSearchableSelects.get(select);if(!current)return;
  const option=select.options[select.selectedIndex]||null;
  if(document.activeElement!==current.input)current.input.value=option?.textContent||'';
  current.input.disabled=select.disabled;current.wrapper.classList.toggle('disabled',select.disabled);
  if(current.wrapper.classList.contains('open'))current.renderOptions();
}
function enhanceSearchableSelect(select){
  if(!(select instanceof HTMLSelectElement)||select.multiple||select.classList.contains('select2-lite-source')||select.dataset.searchable==='off'||select.closest('.filterbar,.vm-filter-shell,.service-filter-shell,.ui-filter-shell,.pagination,.audit-filters,.nomenclature-filters')||enhancedSearchableSelects.has(select))return;
  const wrapper=document.createElement('div');wrapper.className='search-select';
  wrapper.innerHTML='<input type="search" class="search-select-input" autocomplete="off" role="combobox" aria-expanded="false"><span class="search-select-arrow" aria-hidden="true"></span><div class="search-select-dropdown" role="listbox" hidden></div>';
  select.insertAdjacentElement('afterend',wrapper);select.classList.add('search-select-source');select.setAttribute('aria-hidden','true');
  const input=wrapper.querySelector('.search-select-input'),dropdown=wrapper.querySelector('.search-select-dropdown');
  function renderOptions(queryValue=input.value){
    const query=String(queryValue||'').trim().toLocaleLowerCase('ro');
    const options=[...select.options].filter(option=>!option.hidden&&(!query||option.textContent.toLocaleLowerCase('ro').includes(query)));
    dropdown.innerHTML=options.length?options.map(option=>`<button type="button" class="search-select-option${option.selected?' selected':''}" data-value="${e(option.value)}" ${option.disabled?'disabled':''}>${e(option.textContent)}</button>`).join(''):'<div class="search-select-empty">Niciun rezultat</div>';
    if(!dropdown.hidden)scheduleSelectDropdownPosition(input,dropdown);
  }
  const reposition=()=>{if(!dropdown.hidden)scheduleSelectDropdownPosition(input,dropdown)};
  function open(showAll=false){if(select.disabled)return;const wasOpen=!dropdown.hidden;wrapper.classList.add('open');dropdown.hidden=false;input.setAttribute('aria-expanded','true');if(!wasOpen)mountSelectDropdown(input,dropdown);renderOptions(showAll?'':input.value)}
  function close(sync=true){wrapper.classList.remove('open');dropdown.hidden=true;delete dropdown.dataset.lockedPlacement;input.setAttribute('aria-expanded','false');if(sync)refreshSearchableSelect(select)}
  input.addEventListener('focus',()=>{refreshSearchableSelect(select)});
  input.addEventListener('click',()=>{if(dropdown.hidden){input.select();open(true)}});
  input.addEventListener('input',()=>{if(dropdown.hidden)open(false);else renderOptions(input.value)});
  input.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();close();input.blur();return}if(event.key==='Enter'){event.preventDefault();const first=dropdown.querySelector('.search-select-option:not(:disabled)');if(first)first.click()}});
  dropdown.addEventListener('click',event=>{const button=event.target.closest('.search-select-option');if(!button||button.disabled)return;select.value=button.dataset.value;select.dispatchEvent(new Event('change',{bubbles:true}));close();input.focus({preventScroll:true});input.select()});
  select.addEventListener('invalid',event=>{event.preventDefault();input.focus();open()});
  window.addEventListener('resize',reposition);document.addEventListener('scroll',reposition,true);
  enhancedSearchableSelects.set(select,{wrapper,input,dropdown,renderOptions,close,cleanup(){window.removeEventListener('resize',reposition);document.removeEventListener('scroll',reposition,true);dropdown.remove()}});refreshSearchableSelect(select);
}
function enhanceSearchableSelects(root=document){
  if(root instanceof HTMLSelectElement)enhanceSearchableSelect(root);
  root.querySelectorAll?.('select').forEach(select=>{if(select.multiple){destroySearchableSelect(select);return}enhanceSearchableSelect(select)});
}
function refreshSearchableSelects(root=document){root.querySelectorAll?.('select').forEach(refreshSearchableSelect)}
function cleanupEnhancedSelects(root){
  if(root instanceof HTMLSelectElement){destroySearchableSelect(root);destroyEnhancedMultiSelect(root)}
  root.querySelectorAll?.('select').forEach(select=>{destroySearchableSelect(select);destroyEnhancedMultiSelect(select)})
}
document.addEventListener('click',event=>{document.querySelectorAll('.search-select.open').forEach(wrapper=>{const select=wrapper.previousElementSibling,current=select instanceof HTMLSelectElement?enhancedSearchableSelects.get(select):null;if(wrapper.contains(event.target)||current?.dropdown?.contains(event.target))return;current?.close()})});
document.addEventListener('change',event=>{if(event.target instanceof HTMLSelectElement)refreshSearchableSelect(event.target)});
const searchableSelectObserver=new MutationObserver(mutations=>{
  for(const mutation of mutations){
    if(mutation.type==='childList'){
      mutation.removedNodes.forEach(node=>{if(node.nodeType===1)cleanupEnhancedSelects(node)});
      mutation.addedNodes.forEach(node=>{if(node.nodeType===1)enhanceSearchableSelects(node)});
      const owner=mutation.target instanceof HTMLOptionElement?mutation.target.parentElement:mutation.target instanceof HTMLSelectElement?mutation.target:mutation.target.closest?.('select');if(owner instanceof HTMLSelectElement)refreshSearchableSelect(owner);
    }else if(mutation.type==='attributes'){
      const target=mutation.target;
      if(target instanceof HTMLSelectElement){if(target.multiple){destroySearchableSelect(target)}else enhanceSearchableSelect(target);refreshSearchableSelect(target)}
      if(target instanceof HTMLDialogElement&&target.open)refreshSearchableSelects(target);
    }
  }
});
function nomenclatureOptions(categories,code,selected){return selectOptions(categoryItems(categories,code),selected,'— Neselectat —',item=>code==='environment'?String(item.item_code||item.name||'').toLocaleUpperCase('ro-RO'):item.name)}
function resourceContextSelect(categories,code,id,placeholder){return `<select id="${e(id)}" data-searchable="off">${selectOptions(categoryItems(categories,code),null,`— ${placeholder} —`,item=>code==='environment'?String(item.item_code||item.name||'').toLocaleUpperCase('ro-RO'):item.name)}</select>`}
function resourceContextValue(id){const value=Number(document.getElementById(id)?.value||0);return value>0?value:null}
function resourceAssignmentMeta(a){const values=[a?.environment?environmentDisplay(a.environment):'',a?.operational_status,a?.solution_type].filter(Boolean).map(e);return values.length?`<small class="resource-context-meta">${values.join(' · ')}</small>`:''}
const responsibilityTypes={technical_admin:'Administrator tehnic',service_owner:'Responsabil serviciu',business_owner:'Responsabil business',application_owner:'Responsabil aplicație',infrastructure_owner:'Responsabil infrastructură',security_contact:'Contact securitate',backup_contact:'Contact backup',other:'Altă responsabilitate'};
function responsibilityTypeOptions(selected){return Object.entries(responsibilityTypes).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function peopleOptions(people,selected){return `<option value="">— Alege persoana —</option>${(people||[]).filter(person=>person.active||Number(person.id)===Number(selected)).map(person=>`<option value="${person.id}" ${Number(selected)===Number(person.id)?'selected':''}>${e(person.display_name)}${person.email?` · ${e(person.email)}`:''}${person.active?'':' (inactiv)'}</option>`).join('')}`}
function responsibilityRow(item,people,index){return `<div class="responsibility-row" data-index="${index}"><label>Persoană<select class="responsibility-person">${peopleOptions(people,item?.person_id)}</select></label><label>Rol<select class="responsibility-type">${responsibilityTypeOptions(item?.responsibility_type||'technical_admin')}</select></label><label class="responsibility-notes">Detalii<input class="responsibility-note" value="${e(item?.notes||'')}" placeholder="Opțional"></label><button type="button" class="small danger remove-responsibility">Elimină</button></div>`}
function responsibilitySummary(values){if(!values?.length)return '—';return `<div class="responsibility-summary">${values.map(item=>`<div><strong>${e(item.person_name)}</strong><span>${e(responsibilityTypes[item.responsibility_type]||item.responsibility_type)}${item.person_email?` · ${e(item.person_email)}`:''}</span></div>`).join('')}</div>`}
function minutesText(value){if(value===null||value===undefined)return '—';if(value<60)return `${value} min`;if(value%1440===0)return `${value/1440} zile`;if(value%60===0)return `${value/60} ore`;return `${value} min`}
function backupRetentionLabel(backup){if(backup?.retention_quantity===null||backup?.retention_quantity===undefined)return backup?.retention_type||'—';return `${backup.retention_type||'Retenție'} · ${backup.retention_quantity}`}
function gfsLabel(value,unit,detail){return value===null||value===undefined?'—':`${value} ${unit}${detail?` · ${detail}`:''}`}
function backupSection(backup){
  const hasData=backup&&(backup.synced_at||backup.policy_name||backup.job_name||backup.source_name||backup.error_message||backup.provider==='manual'||backup.cron_backup_enabled);
  if(!hasData)return empty('Nu există încă date Veeam sau un backup cron declarat pentru această VM.');
  const effective=!!(backup.protected||backup.cron_backup_enabled);
  const inJob=backup.veeam_in_job?(backup.veeam_job_enabled?'<span class="badge configured">Da</span>':'<span class="badge job-disabled">Da · job dezactivat</span>'):'Nu';
  return `<div class="detail-grid">${detail('Furnizor',e(backup.provider||'veeam'))}${detail('Sursă Veeam',e(backup.source_name||'—'))}${detail('Stare Veeam',veeamStateBadge(backup.veeam_state))}${detail('În job Veeam',inJob)}${detail('Protecție efectivă',effective?badge(backup.cron_backup_enabled&&!backup.protected?'cron':'protected'):badge('unprotected'))}${detail('Ultimul rezultat',backup.last_result?badge(backup.last_result):'—')}${detail('Job',e(backup.job_name||'—'))}${detail('Politică',e(backup.policy_name||'—'))}${detail('Storage primar',e(backup.primary_repository_name||backup.repository_name||'—'))}${detail('Storage secundar',e(backup.secondary_repository_names||'—'))}${detail('Programare Veeam',e(backup.schedule_text||'—'))}${detail('Retenție',e(backupRetentionLabel(backup)))}${detail('GFS Weekly',e(gfsLabel(backup.gfs_weekly_weeks,'săptămâni',backup.gfs_weekly_day)))}${detail('GFS Monthly',e(gfsLabel(backup.gfs_monthly_months,'luni',backup.gfs_monthly_week)))}${detail('GFS Yearly',e(gfsLabel(backup.gfs_yearly_years,'ani',backup.gfs_yearly_month)))}${detail('Restore points',backup.restore_points??'—')}${detail('Ultimul backup',dt(backup.last_backup_at))}${detail('Următoarea rulare',dt(backup.next_run_at))}${detail('RPO',minutesText(backup.rpo_minutes))}${detail('RTO',minutesText(backup.rto_minutes))}${detail('Ultima sincronizare',dt(backup.synced_at))}${detail('Backup cron',backup.cron_backup_enabled?badge('enabled'):badge('disabled'))}${detail('Expresie cron',e(backup.cron_backup_schedule||'—'),true)}${detail('Comandă / script',e(backup.cron_backup_command||'—'),true)}${detail('Observații cron',e(backup.cron_backup_notes||'—'))}${detail('Eroare',e(backup.error_message||'—'))}</div>`;
}
function cronInventoryEntries(documentView){
  const sections=Array.isArray(documentView?.sections)?documentView.sections:[];
  const cronSection=sections.find(section=>String(section?.key||'').toLowerCase()==='cron');
  if(!cronSection)return [];
  const values=[];
  const pick=(obj,keys)=>{for(const key of keys){const value=obj?.[key];if(value!==undefined&&value!==null&&String(value).trim())return String(value).trim()}return ''};
  const visit=value=>{
    if(Array.isArray(value)){value.forEach(visit);return}
    if(!value||typeof value!=='object')return;
    const schedule=pick(value,['schedule','expression','cron','cron_expression','timer','when']);
    const command=pick(value,['command','cmd','script','exec','job']);
    const user=pick(value,['user','username','owner']);
    const source=pick(value,['source','file','path']);
    if(schedule||command){values.push({schedule,command,user,source});return}
    Object.values(value).forEach(visit);
  };
  visit(cronSection.data);
  const seen=new Set();
  return values.filter(item=>{const key=`${item.schedule}\u0000${item.command}\u0000${item.user}`;if(seen.has(key))return false;seen.add(key);return true});
}
function cronBackupForm(backup,documentView){
  if(!can('vms.manage'))return '';
  const detected=cronInventoryEntries(documentView);
  const currentSchedule=String(backup?.cron_backup_schedule||'').trim(),currentCommand=String(backup?.cron_backup_command||'').trim();
  const detectedHTML=detected.length?`<div class="cron-detected-list">${detected.map((item,index)=>{const selected=Boolean(backup?.cron_backup_enabled)&&item.schedule===currentSchedule&&item.command===currentCommand;return `<label class="cron-detected-row"><input type="radio" name="cronBackupDetected" value="${index}" ${selected?'checked':''}><span><strong>${e(item.schedule||'Program necunoscut')}</strong><code>${e(item.command||'—')}</code><small>${e([item.user?`user ${item.user}`:'',item.source].filter(Boolean).join(' · ')||'detectat de agent')}</small></span></label>`}).join('')}</div>`:`<p class="muted">Agentul nu a raportat sarcini cron pentru această VM. Poți completa manual mai jos.</p>`;
  return `<form id="cronBackupForm" class="operational-form cron-backup-form"><div class="form-section"><label class="check-row"><input id="cronBackupEnabled" type="checkbox" ${backup?.cron_backup_enabled?'checked':''}> VM-ul are și backup realizat prin cron / script local</label><div class="cron-detected"><h4>Cron-uri detectate de agent</h4><p class="muted">Selectează cron-ul care realizează backupul. Programul și comanda sunt completate automat și pot fi ajustate manual.</p>${detectedHTML}</div><div class="form-grid"><label>Expresie cron<input id="cronBackupSchedule" class="mono" value="${e(currentSchedule)}" placeholder="0 2 * * *"></label><label class="span-2">Comandă / script<input id="cronBackupCommand" class="mono" value="${e(currentCommand)}" placeholder="/usr/local/sbin/backup.sh"></label></div><label>Observații<textarea id="cronBackupNotes" rows="3">${e(backup?.cron_backup_notes||'')}</textarea></label><p class="muted">Această bifă documentează un backup existent. vm-doc nu execută și nu modifică jobul cron.</p></div><div class="form-actions"><button type="submit">Salvează backup cron</button></div></form>`
}

function backupCandidateDetails(details){
  const candidates=Array.isArray(details?.candidates)?details.candidates:[];
  if(!candidates.length)return empty('Nu există detalii brute Veeam pentru această VM. Rulează o sincronizare după upgrade.');
  const rows=candidates.map(item=>{const object=item.object||{},backup=item.backup||{},job=item.job||{},definition=item.job_definition||{},latest=item.latest_restore_point||{},storage=definition.storage||{},configured=!!item.configured_in_job;return `<tr><td>${configured?'<span class="badge configured">În job</span>':'<span class="muted">Doar backup existent</span>'}</td><td><strong>${e(backup.name||object.name||definition.name||'—')}</strong><div class="muted mono">${e(object.backupId||latest.backupId||backup.id||'—')}</div></td><td>${e(job.name||definition.name||'—')}</td><td>${job.lastResult?badge(job.lastResult):'—'}</td><td>${e(item.repository_name||backup.repositoryName||job.repositoryName||'—')}</td><td>${e(definition.schedule?JSON.stringify(definition.schedule):'—')}</td><td>${e(storage.retentionPolicy?`${storage.retentionPolicy.type||''} ${storage.retentionPolicy.quantity??''}`:'—')}</td><td>${object.restorePointsCount??'—'}</td><td>${dt(latest.creationTime||backup.creationTime)}</td><td>${dt(job.nextRun)}</td><td class="error-text">${e(item.restore_point_error||'—')}</td></tr>`}).join('');
  return `<div class="table-wrap backup-candidate-table"><table><thead><tr><th>Configurație</th><th>Backup chain</th><th>Job</th><th>Rezultat</th><th>Repository</th><th>Schedule brut</th><th>Retenție</th><th>Restore points</th><th>Ultimul RP</th><th>Next run</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

function cleanVersionText(value){
  const lines=String(value||'').replace(/\r/g,'').split('\n').map(line=>line.trim()).filter(Boolean).filter(line=>!/^warning(?:\s|:)/i.test(line)&&!/(?:^|:\s*)\[warning\]/i.test(line));
  return lines.join(' ').trim();
}
function shortVersionText(value){
  const text=cleanVersionText(value);if(!text)return '';
  const distrib=text.match(/\bDistrib\s+v?([0-9]+(?:\.[0-9]+){1,3})/i);if(distrib)return distrib[1];
  const m=text.match(/(?:^|[^0-9])v?([0-9]+(?:\.[0-9]+){1,3})/i);return m?m[1]:text.split(' (')[0].split(',')[0].trim();
}
function bytesText(value){const size=Number(value||0);if(size<1024)return `${size} B`;if(size<1024*1024)return `${(size/1024).toFixed(1)} KB`;return `${(size/1024/1024).toFixed(1)} MB`}
function documentTemplateOptions(values){return (values||[]).filter(item=>item.active).map(item=>`<option value="${item.id}" ${item.is_default?'selected':''}>${e(item.name)}${item.is_default?' · implicit':''}</option>`).join('')}
function generatedDocumentRows(values,emptyMessage='Nu a fost generată încă nicio fișă pentru acest obiect.',servicePackage=false){
  if(!values?.length)return empty(emptyMessage);
  const rows=values.map(item=>`<tr><td><strong>${e(item.document_number)}</strong><div class="muted">${e(item.file_name)}</div></td><td>${e(item.template_name||'—')}</td><td>${dt(item.generated_at)}</td><td>${e(item.generated_by_name||'sistem')}</td><td>${bytesText(item.size_bytes)}</td><td><div class="actions"><a class="button-link small secondary" href="/api/v1/documents/${item.id}/download">DOCX</a>${servicePackage?`<a class="button-link small" href="/api/v1/documents/${item.id}/package">Pachet + anexe</a>`:''}</div></td></tr>`).join('');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Număr electronic document</th><th>Șablon</th><th>Data referință</th><th>Autor</th><th>Mărime</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function vmDocumentsPanel(vmID,templates,generated){
  const active=(templates||[]).filter(item=>item.active);
  const generator=can('documents.manage')?(active.length?`<form id="vmDocumentForm" class="document-generation-form"><label>Șablon DOCX<select id="vmDocumentTemplate">${documentTemplateOptions(active)}</select></label><div class="service-document-options"><label><input id="vmIncludeGeneratedBy" type="checkbox" checked> Include „Generat de”</label></div><div class="document-generation-actions"><button id="previewVMDocument" type="button" class="secondary">Previzualizează datele</button><button type="submit">Generează DOCX</button></div><p class="muted">Fișa este generată din datele vCenter, datele operaționale, servicii, responsabilități, backup și inventarul curent al agentului.</p></form>`:empty('Nu există niciun șablon DOCX activ. Activează sau încarcă un șablon din meniul Documente.')):'';
  return panel('Fișe tehnice generate',`${generator}<div class="generated-documents-history">${generatedDocumentRows(generated)}</div>`,can('documents.manage')?'<a class="button-link small secondary" href="#documents">Administrează șabloanele</a>':'');
}

function serviceDocumentsPanel(serviceID,templates,generated){
  const active=(templates||[]).filter(item=>item.active);
  const generator=can('documents.manage')?(active.length?`<form id="serviceDocumentForm" class="document-generation-form service-document-generation-form"><label>Șablon DOCX<select id="serviceDocumentTemplate">${documentTemplateOptions(active)}</select></label><div class="document-generation-actions"><button id="previewServiceDocument" type="button" class="secondary">Previzualizează datele</button><button id="downloadServiceMarkdown" type="button" class="secondary">Markdown pentru Outline</button><button type="submit">Generează fișa</button></div><div class="service-document-options"><label><input id="serviceIncludeVMAnnexes" type="checkbox" checked> Include fișele VM în pachetul ZIP</label><label><input id="serviceEmbedVMAnnexes" type="checkbox"> Lipește anexele A1, A2… în același document</label><label><input id="serviceRegenerateVMAnnexes" type="checkbox"> Regenerează fișele VM înainte de anexare</label><label><input id="serviceIncludeGeneratedBy" type="checkbox" checked> Include „Generat de”</label></div><p class="muted">Anexele integrate sunt inserate în același DOCX, fiecare pe pagină nouă. La exportul Markdown, aceeași bifă include conținutul complet al fișelor VM ca A1, A2… . Opțiunea ZIP păstrează și fișierele VM separat.</p></form>`:empty('Nu există niciun șablon DOCX activ pentru servicii interne.')):'';
  return panel('Fișe tehnice și operaționale generate',`${generator}<div class="generated-documents-history">${generatedDocumentRows(generated,'Nu a fost generată încă nicio fișă pentru acest serviciu.',true)}</div>`,can('documents.manage')?'<a class="button-link small secondary" href="#documents">Administrează șabloanele</a>':'');
}
function serviceSupplementalDocumentsPanel(serviceID,values){
  const list=(values||[]).length?`<div class="table-wrap"><table class="compact-table"><thead><tr><th>Titlu</th><th>Fișier</th><th>Încărcat</th><th>Autor</th><th>Mărime</th><th></th></tr></thead><tbody>${values.map(item=>`<tr><td><strong>${e(item.title||item.file_name)}</strong></td><td>${e(item.file_name)}</td><td>${dt(item.created_at)}</td><td>${e(item.created_by_name||'sistem')}</td><td>${bytesText(item.size_bytes)}</td><td><div class="actions"><a class="button-link small secondary" href="/api/v1/services/${serviceID}/attachments/${item.id}">DOCX</a>${can('documents.manage')?`<button type="button" class="small danger delete-service-supplemental" data-id="${item.id}">Șterge</button>`:''}</div></td></tr>`).join('')}</tbody></table></div>`:empty('Nu a fost încărcată încă nicio procedură operațională.');
  const form=can('documents.manage')?`<form id="serviceSupplementalForm" class="document-generation-form"><label>Titlu document<input id="serviceSupplementalTitle" maxlength="255" placeholder="ex. Flux aprobare, Procedură operare curentă"></label><label>Document Word (.docx)<input id="serviceSupplementalFile" type="file" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required></label><div class="document-generation-actions"><button type="submit">Încarcă documentul</button></div><p class="muted">Documentul este anexat la finalul fișei ca B1, B2… și își păstrează formatarea Word. Fișierul original rămâne disponibil pentru descărcare.</p></form>`:'';
  return panel('Proceduri operaționale și fluxuri de lucru',`${form}${list}`);
}
function bindServiceSupplementalActions(serviceID){
  document.getElementById('serviceSupplementalForm')?.addEventListener('submit',async event=>{event.preventDefault();const input=document.getElementById('serviceSupplementalFile'),file=input?.files?.[0];if(!file){toast('Alege un fișier DOCX.',true);return}const form=new FormData();form.append('file',file);const titleValue=document.getElementById('serviceSupplementalTitle')?.value?.trim()||'';if(titleValue)form.append('title',titleValue);const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent='Se încarcă…';try{await api(`/api/v1/services/${serviceID}/attachments`,{method:'POST',body:form});toast('Procedura operațională a fost încărcată.');internalServiceDetail(serviceID,'documents')}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Încarcă documentul'}});
  document.querySelectorAll('.delete-service-supplemental').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi procedura operațională selectată?'))return;try{await api(`/api/v1/services/${serviceID}/attachments/${button.dataset.id}`,{method:'DELETE'});toast('Procedura operațională a fost ștearsă.');internalServiceDetail(serviceID,'documents')}catch(err){toast(err.message,true)}}));
}
function serviceDocumentPreviewHTML(preview){
  const warnings=(preview.warnings||[]).length?`<div class="notice warning"><strong>Observații înainte de generare</strong><ul>${preview.warnings.map(item=>`<li>${e(item)}</li>`).join('')}</ul></div>`:'';
  const sections=(preview.sections||[]).map(section=>`<section class="document-preview-section"><h3>${e(section.title)}</h3><div class="detail-grid">${(section.rows||[]).map(row=>detail(row.label,e(row.value||'—'))).join('')}</div></section>`).join('');
  return `${warnings}<div class="document-preview-meta">${detail('Serviciu',e(preview.internal_service_name))}${detail('Șablon',e(preview.template_name))}${detail('Număr electronic document',e(preview.document_number),true)}${detail('Data referință',dt(preview.generated_at))}</div>${sections}`;
}
function bindServiceDocumentActions(serviceID){
  const selected=()=>Number(document.getElementById('serviceDocumentTemplate')?.value||0);
  const requestBody=()=>({template_id:selected(),include_vm_annexes:!!document.getElementById('serviceIncludeVMAnnexes')?.checked,embed_vm_annexes:!!document.getElementById('serviceEmbedVMAnnexes')?.checked,regenerate_vm_annexes:!!document.getElementById('serviceRegenerateVMAnnexes')?.checked,include_generated_by:!!document.getElementById('serviceIncludeGeneratedBy')?.checked});
  document.getElementById('previewServiceDocument')?.addEventListener('click',async()=>{const body=requestBody();if(!body.template_id){toast('Alege un șablon DOCX.',true);return}try{const preview=await api(`/api/v1/services/${serviceID}/documents/preview`,{method:'POST',body:JSON.stringify(body)});document.querySelector('#documentPreviewDialog h2').textContent='Previzualizare fișă tehnică și operațională';document.getElementById('documentPreviewContent').innerHTML=serviceDocumentPreviewHTML(preview);documentPreviewDialog.showModal()}catch(err){toast(err.message,true)}});
  document.getElementById('downloadServiceMarkdown')?.addEventListener('click',async event=>{const body=requestBody();if(!body.template_id){toast('Alege un șablon DOCX.',true);return}const button=event.currentTarget;button.disabled=true;button.textContent='Se generează Markdown…';try{await postDownload(`/api/v1/services/${serviceID}/documents/markdown`,body,`serviciu-${serviceID}.md`);toast('Fișierul Markdown a fost generat.')}catch(err){toast(err.message,true)}finally{button.disabled=false;button.textContent='Markdown pentru Outline'}});
  document.getElementById('serviceDocumentForm')?.addEventListener('submit',async event=>{event.preventDefault();const body=requestBody();if(!body.template_id){toast('Alege un șablon DOCX.',true);return}const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent=body.regenerate_vm_annexes?'Se generează fișele VM…':'Se generează…';try{const generated=await api(`/api/v1/services/${serviceID}/documents`,{method:'POST',body:JSON.stringify(body)});toast(`Fișa ${generated.document_number} a fost generată.`);const link=document.createElement('a');link.href=body.include_vm_annexes?`/api/v1/documents/${generated.id}/package`:`/api/v1/documents/${generated.id}/download`;link.click();setTimeout(()=>internalServiceDetail(serviceID),700)}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Generează fișa'}});
}
function documentPreviewHTML(preview){
  const warnings=(preview.warnings||[]).length?`<div class="notice warning"><strong>Observații înainte de generare</strong><ul>${preview.warnings.map(item=>`<li>${e(item)}</li>`).join('')}</ul></div>`:'';
  const sections=(preview.sections||[]).map(section=>`<section class="document-preview-section vm-document-preview-section"><h3>${e(section.title)}</h3><div class="document-preview-rows">${(section.rows||[]).map(row=>`<div class="document-preview-row"><span>${e(row.label)}</span><div>${e(row.value||'—')}</div></div>`).join('')}</div></section>`).join('');
  return `<div class="vm-document-preview">${warnings}<div class="document-preview-meta">${detail('VM',e(preview.vm_name))}${detail('Șablon',e(preview.template_name))}${detail('Număr electronic document',e(preview.document_number),true)}${detail('Data referință',dt(preview.generated_at))}</div><div class="document-preview-sections">${sections}</div></div>`;
}
function selectedDocumentTemplateID(){return Number(document.getElementById('vmDocumentTemplate')?.value||0)}
function bindVMDocumentActions(vmID){
  document.getElementById('previewVMDocument')?.addEventListener('click',async()=>{const templateID=selectedDocumentTemplateID();if(!templateID){toast('Alege un șablon DOCX.',true);return}try{const preview=await api(`/api/v1/vms/${vmID}/documents/preview`,{method:'POST',body:JSON.stringify({template_id:templateID,include_generated_by:!!document.getElementById('vmIncludeGeneratedBy')?.checked})});document.querySelector('#documentPreviewDialog h2').textContent='Previzualizare fișă VM';document.getElementById('documentPreviewContent').innerHTML=documentPreviewHTML(preview);documentPreviewDialog.showModal()}catch(err){toast(err.message,true)}});
  document.getElementById('vmDocumentForm')?.addEventListener('submit',async event=>{event.preventDefault();const templateID=selectedDocumentTemplateID();if(!templateID){toast('Alege un șablon DOCX.',true);return}const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent='Se generează…';try{const generated=await api(`/api/v1/vms/${vmID}/documents`,{method:'POST',body:JSON.stringify({template_id:templateID,include_generated_by:!!document.getElementById('vmIncludeGeneratedBy')?.checked})});toast(`Fișa ${generated.document_number} a fost generată.`);const link=document.createElement('a');link.href=`/api/v1/documents/${generated.id}/download`;link.click();setTimeout(()=>vmDetail(vmID),500)}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Generează DOCX'}});
}
function sortNomenclatureValues(values){return [...(values||[])].sort((left,right)=>Number(left.sort_order||0)-Number(right.sort_order||0)||String(left.name||'').localeCompare(String(right.name||''),'ro',{sensitivity:'base'}))}
const serviceUsageLabels={dedicated:'Dedicat',shared:'Partajat',dependency:'Dependență'};
function domainAssignmentOptions(categories,selected){return selectOptions(sortNomenclatureValues(categoryItems(categories,'architectural_domain')),selected,'— Alege domeniul —')}
function categoryAssignmentOptions(categories,domainID,selected){const values=sortNomenclatureValues(categoryItems(categories,'itil_category').filter(item=>Number(item.parent_id)===Number(domainID)));return selectOptions(values,selected,domainID?'— Alege categoria de serviciu —':'— Alege domeniul —')}
function serviceAssignmentOptions(services,selected){const values=[...(services||[])].sort((left,right)=>String(left.name||'').localeCompare(String(right.name||''),'ro',{sensitivity:'base'}));return `<option value="">— Alege serviciul intern —</option>${values.filter(service=>service.active||Number(service.id)===Number(selected)).map(service=>`<option value="${service.id}" ${Number(selected)===Number(service.id)?'selected':''}>${e(service.name)}${service.service_code?` · ${e(service.service_code)}`:''}${service.active?'':' (inactiv)'}</option>`).join('')}`}
function serviceUsageOptions(selected='dedicated'){return Object.entries(serviceUsageLabels).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function solutionTypeAssignmentOptions(categories,selected){return selectOptions(sortNomenclatureValues(categoryItems(categories,'solution_type')),selected,'— Alege tipul soluției —')}
function serviceAssignmentRow(item,services,categories,index){
  const domainID=item?.architectural_domain_id||'',categoryID=item?.itil_category_id||'';
  return `<article class="vm-service-assignment-card" data-index="${index}">
    <div class="vm-service-assignment-head"><div><span class="assignment-kicker">Încadrare ${index+1}</span><strong>${e(item?.internal_service_name||'Serviciu intern nou')}</strong></div><div class="assignment-head-actions"><label class="assignment-primary"><input class="assignment-primary-input" type="checkbox" ${item?.is_primary?'checked':''}><span>Asociere principală</span></label>${can('vms.manage')?'<button type="button" class="small danger remove-service-assignment">Elimină</button>':''}</div></div>
    <div class="assignment-section"><h4>Clasificare serviciu</h4><div class="assignment-grid classification-grid"><label>Domeniu arhitectural<select class="assignment-domain" required>${domainAssignmentOptions(categories,domainID)}</select></label><label>Categorie de serviciu<select class="assignment-category" required>${categoryAssignmentOptions(categories,domainID,categoryID)}</select></label><label>Serviciu intern<select class="assignment-service" required>${serviceAssignmentOptions(services,item?.internal_service_id)}</select></label></div></div>
    <div class="assignment-section"><h4>Arhitectură tehnică</h4><div class="assignment-grid technical-grid"><label>Layer arhitectural<select class="assignment-layer" required></select></label><label>Rol tehnic<select class="assignment-role" required></select></label><label>Tip soluție<select class="assignment-solution-type" required>${solutionTypeAssignmentOptions(categories,item?.solution_type_id)}</select></label></div></div>
    <div class="assignment-section assignment-context"><h4>Context</h4><div class="assignment-grid context-grid"><label>Utilizare<select class="assignment-usage">${serviceUsageOptions(item?.usage_type||'dedicated')}</select></label><label class="assignment-notes">Observații<input class="assignment-note" maxlength="1000" value="${e(item?.notes||'')}" placeholder="Rolul acestei VM în serviciu, particularități, dependențe…"></label></div></div>
  </article>`
}
function wireServiceAssignmentRow(row,services,categories,initial={}){
  const domain=row.querySelector('.assignment-domain'),category=row.querySelector('.assignment-category'),service=row.querySelector('.assignment-service'),layer=row.querySelector('.assignment-layer'),role=row.querySelector('.assignment-role');
  const layers=sortNomenclatureValues(categoryItems(categories,'layer'));
  const roles=categoryItems(categories,'technical_role');
  function fillCategories(selected=''){category.innerHTML=categoryAssignmentOptions(categories,domain.value,selected);category.disabled=!domain.value}
  function fillServices(selected=''){service.innerHTML=serviceAssignmentOptions(services,selected);service.disabled=!category.value}
  function fillLayers(selected=''){let values=layers;if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.layer_name)values=[...values,{id:Number(selected),name:`${initial.layer_name} · inactiv`,active:false}];layer.innerHTML=selectOptions(values,selected,'— Alege layer-ul —')}
  function fillRoles(selected=''){let values=sortNomenclatureValues(roles.filter(item=>(item.layer_ids||[]).some(id=>Number(id)===Number(layer.value))));if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.technical_role)values=[...values,{id:Number(selected),name:`${initial.technical_role} · nemapat`,active:false}];role.innerHTML=selectOptions(values,selected,layer.value?'— Alege rolul tehnic —':'— Alege layer-ul —');role.disabled=!layer.value}
  fillCategories(initial.itil_category_id);fillServices(initial.internal_service_id);fillLayers(initial.layer_id);fillRoles(initial.technical_role_id);
  domain.addEventListener('change',()=>{fillCategories();fillServices()});category.addEventListener('change',()=>fillServices());layer.addEventListener('change',()=>fillRoles());
  service.addEventListener('change',()=>{const title=row.querySelector('.vm-service-assignment-head strong');const selected=services.find(item=>Number(item.id)===Number(service.value));if(title)title.textContent=selected?.name||'Serviciu intern nou'});
}
function serviceAssignmentsSummary(values){
  if(!values?.length)return '<span class="muted">Niciun serviciu intern asociat.</span>';
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie</th><th>Layer / Rol tehnic</th><th>Tip soluție</th><th>Utilizare</th><th></th></tr></thead><tbody>${values.map(item=>`<tr><td><a href="#services/${item.internal_service_id}">${e(item.internal_service_name)}</a></td><td>${e(item.architectural_domain||'—')}<div class="muted">${e(item.itil_category||'—')}</div></td><td>${e(item.layer_name||'—')}<div class="muted">${e(item.technical_role||'—')}</div></td><td>${e(item.solution_type||'—')}</td><td>${e(serviceUsageLabels[item.usage_type]||item.usage_type||'—')}</td><td>${item.is_primary?badge('principal'):''}</td></tr>`).join('')}</tbody></table></div>`;
}

function vmCommonDependencies(vmID,values,services,categories){
  const commonServices=(services||[]).filter(item=>item.active&&item.is_common),types=categoryItems(categories,'dependency_type');
  const form=can('vms.manage')&&commonServices.length&&types.length?`<form id="vmDependencyForm" class="service-dependency-form vm-dependency-form"><label>Serviciu comun<select id="vmDependencyTarget" required><option value="">— Alege serviciul —</option>${commonServices.map(item=>`<option value="${item.id}">${e(item.name)}${item.implicit_global?' · GLOBAL':''}</option>`).join('')}</select></label><label>Tip dependență<select id="vmDependencyType" required>${selectOptions(types,'','— Alege tipul —')}</select></label><label>Detalii<input id="vmDependencyNotes" maxlength="1000" placeholder="Excepție specifică acestei VM"></label><button type="submit">Adaugă direct</button></form>`:'';
  const list=values?.length?`<div class="common-dependency-list">${values.map(dep=>`<div class="common-dependency-item ${dep.global?'global':''}">${nomenclatureIcon(dep.dependency_type_icon||'integration','small')}<div><a href="#services/${dep.target_service_id}"><strong>${e(dep.target_service_name)}</strong></a><span>${e(dep.dependency_type||'Serviciu comun')} · ${dep.global?'Global':dep.direct?'Direct VM':'Comun'}</span><small>${e(dep.source_label||dep.source_service_name||'Dependență directă')}${dep.target_vm_names?` · Furnizat de: ${e(dep.target_vm_names)}`:''}${dep.notes?` · ${e(dep.notes)}`:''}</small></div><div class="common-dependency-actions"><b>${dep.target_vm_count||0} VM</b>${dep.direct&&dep.id&&can('vms.manage')?`<button type="button" class="small danger delete-vm-dependency" data-id="${dep.id}">Elimină</button>`:''}</div></div>`).join('')}</div>`:empty('Nu sunt identificate dependențe către infrastructura comună.');
  return `${form}${list}`;
}
function bindVMDependencyActions(vmID){
  document.getElementById('vmDependencyForm')?.addEventListener('submit',async event=>{event.preventDefault();const target=Number(document.getElementById('vmDependencyTarget').value||0),type=Number(document.getElementById('vmDependencyType').value||0),notes=document.getElementById('vmDependencyNotes').value.trim();if(!target||!type){toast('Alege serviciul comun și tipul dependenței.',true);return}try{await api(`/api/v1/vms/${vmID}/dependencies`,{method:'POST',body:JSON.stringify({target_service_id:target,dependency_type_id:type,notes})});toast('Dependența directă a VM-ului a fost adăugată.');vmDetail(vmID)}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.delete-vm-dependency').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Elimini dependența directă de pe această VM?'))return;try{await api(`/api/v1/vms/${vmID}/dependencies/${button.dataset.id}`,{method:'DELETE'});toast('Dependența directă a fost eliminată.');vmDetail(vmID)}catch(err){toast(err.message,true)}}));
}

function bindPrimaryAgentServiceActions(vmID){
  bindServiceInventoryFilters();
  const reviewed=document.getElementById('vmAgentServicesReviewed');
  reviewed?.addEventListener('change',async()=>{
    try{
      await api(`/api/v1/vms/${vmID}/agent-services/reviewed`,{method:'PUT',body:JSON.stringify({reviewed:reviewed.checked})});
      toast(reviewed.checked?'Categoria Servicii a fost marcată ca verificată.':'Marcajul Servicii verificate a fost eliminat.');
      refreshVMCompletion(vmID);
    }catch(err){reviewed.checked=!reviewed.checked;toast(err.message,true)}
  });
  document.querySelectorAll('.primary-agent-service-toggle').forEach(input=>{
    input.addEventListener('click',event=>event.stopPropagation());
    input.addEventListener('change',async event=>{
      event.stopPropagation();
      const serviceName=input.dataset.service||'';
      try{
        await api(`/api/v1/vms/${vmID}/primary-services`,{method:'POST',body:JSON.stringify({service_name:serviceName,primary:input.checked})});
        toast(input.checked?`${serviceName} marcat ca principal.`:`${serviceName} nu mai este principal.`);refreshVMCompletion(vmID);
      }catch(err){input.checked=!input.checked;toast(err.message,true)}
    });
  });
}

function bindPrimaryAgentPortActions(vmID){
  bindPortInventoryFilters();
  document.querySelectorAll('.primary-agent-port-toggle').forEach(input=>{
    input.addEventListener('click',event=>event.stopPropagation());
    input.addEventListener('change',async event=>{
      event.stopPropagation();
      const protocol=input.dataset.protocol||'',port=Number(input.dataset.port||0),processName=input.dataset.process||'',label=`${port}/${String(protocol).toUpperCase()}${processName?` · ${processName}`:''}`;
      try{
        await api(`/api/v1/vms/${vmID}/primary-ports`,{method:'POST',body:JSON.stringify({protocol,port,process_name:processName,primary:input.checked})});
        toast(input.checked?`${label} marcat ca principal.`:`${label} nu mai este principal.`);
        const row=input.closest('.port-inventory-row');if(row){if(!input.checked&&row.classList.contains('stale-primary-service'))row.remove();else row.dataset.portStatus=input.checked?'selected':'detected'}applyPortInventoryFilters();refreshVMCompletion(vmID);
      }catch(err){input.checked=!input.checked;toast(err.message,true)}
    });
  });
}

function dockerPortText(ports){
  if(!Array.isArray(ports)||!ports.length)return '—';
  return ports.map(p=>p.host_port?`${e(p.host_ip||'*')}:${p.host_port} → ${p.container_port}/${e(p.protocol||'tcp')}`:`${p.container_port}/${e(p.protocol||'tcp')}`).join('<br>');
}
function dockerAssignmentChips(container){
  const values=Array.isArray(container?.service_assignments)?container.service_assignments:[];
  if(!values.length)return '<span class="muted">Neasociat</span>';
  return `<div class="docker-service-chips">${values.map(a=>`<span class="docker-service-chip ${a.source==='label'?'from-label':''}"><a href="#services/${a.service_id}">${e(a.service_name)}</a>${resourceAssignmentMeta(a)}<small>${a.source==='label'?'label':'manual'}</small>${a.source==='manual'&&can('vms.manage')?`<button type="button" class="docker-remove-service" data-container="${container.id}" data-service="${a.service_id}" title="Elimină asocierea manuală">×</button>`:''}</span>`).join('')}</div>`;
}
function dockerSecurityFlags(c){const flags=[];if(c.privileged)flags.push(badge('privileged'));if(c.docker_socket_mounted)flags.push(badge('docker.sock'));if(c.network_mode==='host')flags.push(badge('host network'));if(c.readonly_rootfs)flags.push(badge('read-only'));return flags.length?flags.join(' '):'<span class="muted">standard</span>'}
function dockerServiceSelect(services,idSuffix){return `<select class="docker-service-select" id="docker-service-${idSuffix}"><option value="">— Serviciu —</option>${(services||[]).filter(x=>x.active!==false).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('')}</select>`}
function resourceDocumentationToggle(cls,dataAttr,id,checked,label='Nu necesită documentare'){return can('vms.manage')?`<label class="resource-exempt-label"><input type="checkbox" class="${cls}" ${dataAttr}="${id}" ${checked?'checked':''}><span>${e(label)}</span></label>`:(checked?'<span class="muted">Nu necesită documentare</span>':'—')}
function dockerVMSection(view,services,categories){
  const host=view?.host,containers=Array.isArray(view?.containers)?view.containers:[],projects=Array.isArray(view?.compose_projects)?view.compose_projects:[];
  if(!host)return panel('Docker',empty('Nu există încă inventar Docker structurat. Este necesar vm-doc-agent 1.4.0+ și un snapshot Docker utilizabil.'));
  if(!host.installed)return panel('Docker',`<div class="notice docker-install-notice"><strong>Docker nu este instalat pe această VM.</strong><div class="muted">Ultima colectare: ${dt(host.observed_at)}</div></div>`);
  const docControl=can('vms.manage')?`<div class="resource-documentation-control"><label><input id="dockerDocumentationExempt" type="checkbox" ${host.documentation_exempt?'checked':''}> Nu necesită documentare</label><span class="muted">Păstrează inventarul, dar Docker nu mai este cerut în completitudinea și fișa VM.</span></div>`:'';
  const kpis=`<div class="resource-kpis resource-kpis-6"><div class="card"><div class="label">Engine</div><div class="value compact">${e(host.version||'—')}</div><div class="muted">${host.available?badge('running'):badge(host.service_state||'unavailable')}</div></div><div class="card"><div class="label">Containere</div><div class="value">${host.container_count||0}</div><div class="muted">${host.running_count||0} running</div></div><div class="card"><div class="label">Images</div><div class="value">${host.image_count||0}</div></div><div class="card"><div class="label">Networks</div><div class="value">${host.network_count||0}</div></div><div class="card"><div class="label">Volumes</div><div class="value">${host.volume_count||0}</div></div><div class="card"><div class="label">Compose</div><div class="value">${host.compose_project_count||0}</div></div></div>`;
  const projectHTML=projects.length?`<div class="docker-compose-projects">${projects.map((p,index)=>`<div class="docker-compose-card"><div><strong>${e(p.name)}</strong><span>${p.container_count} containere · ${e((p.services||[]).join(', ')||'fără servicii Compose')}</span></div>${can('vms.manage')?`<div class="docker-compose-assign resource-assignment">${dockerServiceSelect(services,`project-${index}`)}${resourceContextSelect(categories,'environment',`docker-environment-project-${index}`,'Mediu')}${resourceContextSelect(categories,'operational_status',`docker-status-project-${index}`,'Status operațional')}${resourceContextSelect(categories,'solution_type',`docker-solution-project-${index}`,'Tip soluție')}<button type="button" class="small secondary docker-assign-project" data-project="${e(p.name)}" data-select="docker-service-project-${index}" data-environment="docker-environment-project-${index}" data-status="docker-status-project-${index}" data-solution="docker-solution-project-${index}">Asociază</button></div>`:''}</div>`).join('')}</div>`:empty('Nu au fost detectate proiecte Docker Compose.');
  const rows=containers.map((c,index)=>`<tr><td><strong>${e(c.name)}</strong><div class="muted mono">${e((c.engine_container_id||'').slice(0,12))}</div></td><td><span class="mono">${e(c.image||'—')}</span></td><td>${badge(c.state||'unknown')}${c.health?`<div class="muted">health: ${e(c.health)}</div>`:''}</td><td>${c.compose_project?`<strong>${e(c.compose_project)}</strong><div class="muted">${e(c.compose_service||'')}</div>`:'—'}</td><td class="mono">${dockerPortText(c.ports)}</td><td>${dockerSecurityFlags(c)}</td><td class="resource-tools-cell"><div class="resource-doc-inline">${resourceDocumentationToggle('docker-container-documentation-exempt','data-container',c.id,c.documentation_exempt)}</div>${dockerAssignmentChips(c)}${can('vms.manage')?`<div class="docker-container-assign resource-assignment">${dockerServiceSelect(services,`container-${index}`)}${resourceContextSelect(categories,'environment',`docker-environment-container-${index}`,'Mediu')}${resourceContextSelect(categories,'operational_status',`docker-status-container-${index}`,'Status operațional')}${resourceContextSelect(categories,'solution_type',`docker-solution-container-${index}`,'Tip soluție')}<button type="button" class="small secondary docker-add-service" data-container="${c.id}" data-select="docker-service-container-${index}" data-environment="docker-environment-container-${index}" data-status="docker-status-container-${index}" data-solution="docker-solution-container-${index}">Asociază</button></div>`:''}</td></tr>`).join('');
  const inventory=`<details class="docker-details"><summary>Engine și obiecte Docker</summary><div class="detail-grid">${detail('Executable',e(host.executable||'—'),true)}${detail('Service',e(host.service_state||'—'))}${detail('API',e(host.api_version||'—'))}${detail('Storage driver',e(host.storage_driver||'—'))}${detail('Logging driver',e(host.logging_driver||'—'))}${detail('Cgroup',e([host.cgroup_driver,host.cgroup_version].filter(Boolean).join(' / ')||'—'))}${detail('Docker root',e(host.docker_root_dir||'—'),true)}${detail('Ultima observație',dt(host.observed_at))}</div><div class="docker-object-summary"><strong>Images:</strong> ${(view.images||[]).map(i=>e((i.repo_tags||[])[0]||i.engine_id)).join(', ')||'—'}</div><div class="docker-object-summary"><strong>Networks:</strong> ${(view.networks||[]).map(n=>e(`${n.name}${n.driver?` (${n.driver})`:''}`)).join(', ')||'—'}</div><div class="docker-object-summary"><strong>Volumes:</strong> ${(view.volumes||[]).map(v=>e(v.name)).join(', ')||'—'}</div></details>`;
  return `${docControl}${kpis}${panel('Proiecte Docker Compose',projectHTML,'<span class="muted">Asocierea unui proiect adaugă serviciul tuturor containerelor curente din proiect</span>')}${panel('Containere Docker',rows?`<div class="table-wrap"><table><thead><tr><th>Container</th><th>Imagine</th><th>Stare</th><th>Compose</th><th>Porturi</th><th>Indicatori</th><th>Documentare și servicii interne</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Docker este instalat, dar nu există containere.'),'<span class="muted">Un container poate aparține unuia sau mai multor servicii, independent de VM-ul gazdă.</span>')}${inventory}`;
}
function dockerManualAssignments(container){return (container?.service_assignments||[]).filter(a=>a.source==='manual').map(a=>({service_id:Number(a.service_id),environment_id:a.environment_id?Number(a.environment_id):null,operational_status_id:a.operational_status_id?Number(a.operational_status_id):null,solution_type_id:a.solution_type_id?Number(a.solution_type_id):null,component_name:a.component_name||'',role_name:a.role_name||'',notes:a.notes||''}))}
function bindDockerActions(vmID,view,services){
  const byID=new Map((view?.containers||[]).map(c=>[Number(c.id),c]));
  document.getElementById('dockerDocumentationExempt')?.addEventListener('change',async event=>{try{await api(`/api/v1/vms/${vmID}/docker/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:event.target.checked})});toast('Setarea de documentare Docker a fost salvată.');if(view?.host)view.host.documentation_exempt=event.target.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);event.target.checked=!event.target.checked}});
  document.querySelectorAll('.docker-container-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const id=Number(input.dataset.container);try{await api(`/api/v1/vms/${vmID}/docker/containers/${id}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare a containerului a fost salvată.');const item=byID.get(id);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  document.querySelectorAll('.docker-add-service').forEach(button=>button.addEventListener('click',async()=>{const cid=Number(button.dataset.container),select=document.getElementById(button.dataset.select),serviceID=Number(select?.value||0);if(!serviceID){toast('Alege un serviciu.',true);return}const environmentID=resourceContextValue(button.dataset.environment),statusID=resourceContextValue(button.dataset.status),solutionTypeID=resourceContextValue(button.dataset.solution);if(!environmentID||!statusID||!solutionTypeID){toast('Alege mediul, statusul operațional și tipul soluției.',true);return}const container=byID.get(cid),assignments=dockerManualAssignments(container),existing=assignments.find(a=>a.service_id===serviceID);if(existing){existing.environment_id=environmentID;existing.operational_status_id=statusID;existing.solution_type_id=solutionTypeID}else assignments.push({service_id:serviceID,environment_id:environmentID,operational_status_id:statusID,solution_type_id:solutionTypeID});try{await api(`/api/v1/vms/${vmID}/docker/containers/${cid}/services`,{method:'PUT',body:JSON.stringify({assignments})});toast('Container asociat serviciului.');vmDetail(vmID,'docker')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.docker-remove-service').forEach(button=>button.addEventListener('click',async()=>{const cid=Number(button.dataset.container),serviceID=Number(button.dataset.service),container=byID.get(cid),assignments=dockerManualAssignments(container).filter(a=>a.service_id!==serviceID);try{await api(`/api/v1/vms/${vmID}/docker/containers/${cid}/services`,{method:'PUT',body:JSON.stringify({assignments})});toast('Asocierea containerului a fost eliminată.');vmDetail(vmID,'docker')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.docker-assign-project').forEach(button=>button.addEventListener('click',async()=>{const select=document.getElementById(button.dataset.select),serviceID=Number(select?.value||0);if(!serviceID){toast('Alege un serviciu.',true);return}const environmentID=resourceContextValue(button.dataset.environment),statusID=resourceContextValue(button.dataset.status),solutionTypeID=resourceContextValue(button.dataset.solution);if(!environmentID||!statusID||!solutionTypeID){toast('Alege mediul, statusul operațional și tipul soluției.',true);return}try{await api(`/api/v1/vms/${vmID}/docker/compose/${encodeURIComponent(button.dataset.project)}/services`,{method:'PUT',body:JSON.stringify({assignments:[{service_id:serviceID,environment_id:environmentID,operational_status_id:statusID,solution_type_id:solutionTypeID}]})});toast('Proiectul Compose a fost asociat serviciului.');vmDetail(vmID,'docker')}catch(err){toast(err.message,true)}}));
}

function databaseEndpointText(values){
  if(!Array.isArray(values)||!values.length)return '—';
  return values.map(x=>{const addr=x.address||'';const port=x.port||'';if(addr&&port)return `${e(addr)}:${port}`;if(port)return `port ${port}`;return e(addr||'—')}).join('<br>');
}
function databaseCatalogReasonLabel(reason){
  const labels={authentication_required:'Autentificare necesară',permission_denied:'Permisiuni insuficiente',socket_unavailable:'Socket local indisponibil',server_unavailable:'Server DB indisponibil',client_not_found:'Client DB lipsă',timeout:'Timeout la interogare',os_user_unavailable:'Utilizator OS indisponibil',user_switch_unavailable:'Schimbarea userului OS nu este disponibilă',maintenance_database_missing:'Baza tehnică postgres/template1 nu este disponibilă',query_failed:'Interogarea catalogului a eșuat',unsupported_engine:'Enumerare catalog nesuportată'};
  return labels[String(reason||'').trim()]||String(reason||'').trim();
}
function databaseCatalogDiscoveryCell(x){
  const discovered=x?.catalog_discovery_status==='discovered';
  if(discovered)return `${badge('discovered')}<div class="muted">${(x.catalogs||[]).length} baze</div>`;
  const reason=databaseCatalogReasonLabel(x?.catalog_discovery_reason);
  return `<span class="muted">metadata only</span>${reason?`<div class="muted"><strong>Motiv:</strong> ${e(reason)}</div>`:''}<div class="muted">${(x.catalogs||[]).length} baze</div>`;
}
function databaseScheduledJobDiscoveryCell(x){
  const jobs=Array.isArray(x?.scheduled_jobs)?x.scheduled_jobs:[],status=String(x?.scheduled_job_discovery_status||'').trim();
  if(status==='discovered')return `${badge('discovered')}<div class="muted">${jobs.length} joburi</div>`;
  if(status==='not_detected')return '<span class="muted">Nedetectat</span><div class="muted">0 joburi</div>';
  if(!status)return '<span class="muted">agent anterior 1.6.10</span>';
  const reason=databaseCatalogReasonLabel(x?.scheduled_job_discovery_reason),label=status==='partial'?'Parțial':'metadata only';
  return `<span class="muted">${e(label)}</span>${reason?`<div class="muted"><strong>Motiv:</strong> ${e(reason)}</div>`:''}<div class="muted">${jobs.length} joburi</div>`;
}
function databaseScheduledJobs(instances){
  return (Array.isArray(instances)?instances:[]).flatMap(instance=>(Array.isArray(instance.scheduled_jobs)?instance.scheduled_jobs:[]).map(job=>({...job,_instance:instance})));
}
function databaseScheduledJobState(job){
  if(job?.enabled===true)return badge('active');
  if(job?.enabled===false)return badge('disabled');
  return '<span class="muted">—</span>';
}
function databaseScheduledJobSummary(values){
  const jobs=Array.isArray(values)?values:[];if(!jobs.length)return '—';
  const schedulers=[...new Set(jobs.map(x=>x.scheduler).filter(Boolean))];
  return `<strong>${jobs.length}</strong><div class="muted">${e(schedulers.join(', ')||'PostgreSQL')}</div>`;
}
function databaseServiceSelect(services,idSuffix){return `<select class="database-service-select" id="database-service-${idSuffix}"><option value="">— Serviciu —</option>${(services||[]).filter(x=>x.active!==false).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('')}</select>`}
function databaseAssignments(value,type){
  const values=Array.isArray(value?.service_assignments)?value.service_assignments:[];
  if(!values.length)return '<span class="muted">Neasociat</span>';
  const attr=type==='catalog'?'catalog':'instance';
  return `<div class="docker-service-chips">${values.map(a=>`<span class="docker-service-chip"><a href="#services/${a.service_id}">${e(a.service_name)}</a>${resourceAssignmentMeta(a)}${can('vms.manage')?`<button type="button" class="database-remove-service" data-type="${attr}" data-object="${value.id}" data-service="${a.service_id}" title="Elimină asocierea">×</button>`:''}</span>`).join('')}</div>`;
}
function databaseVMSection(view,services,categories){
  const host=view?.host,engines=Array.isArray(view?.engines)?view.engines:[],instances=Array.isArray(view?.instances)?view.instances:[];
  if(!host)return panel('Baze de date',empty('Nu există încă inventar de baze de date structurat. Este necesar vm-doc-agent 1.5.0+ și un snapshot cu collectorul databases.'));
  const catalogs=instances.flatMap(i=>(i.catalogs||[]).filter(c=>!c.system).map(c=>({...c,_instance:i}))),scheduledJobs=databaseScheduledJobs(instances);
  const products=[...new Set(engines.map(x=>x.product||x.engine).filter(Boolean))];
  const kpis=`<div class="resource-kpis resource-kpis-6"><div class="card"><div class="label">Engine-uri</div><div class="value">${host.engine_count||0}</div></div><div class="card"><div class="label">Instanțe</div><div class="value">${host.instance_count||0}</div></div><div class="card"><div class="label">Baze aplicație</div><div class="value">${catalogs.length}</div></div><div class="card"><div class="label">Joburi PostgreSQL</div><div class="value">${scheduledJobs.length}</div></div><div class="card"><div class="label">Produse</div><div class="value compact">${e(products.join(', ')||'—')}</div></div><div class="card"><div class="label">Ultima observație</div><div class="value compact">${dt(host.observed_at)}</div></div></div>`;
  const engineRows=engines.map(x=>`<tr><td><strong>${e(x.product||x.engine)}</strong><div class="muted mono">${e(x.engine)}</div></td><td>${e(shortVersionText(x.version)||'—')}</td><td class="mono">${e(x.executable||'—')}</td><td>${(x.sources||[]).map(e).join('<br>')||'—'}</td></tr>`).join('');
  const instanceRows=instances.map((x,index)=>`<tr><td><strong>${e(x.product||x.engine)}</strong><div class="muted mono">${e(x.engine)}</div></td><td><strong>${e(x.instance_name||'implicit')}</strong><div class="muted">${e(x.service_name||'')}</div>${x.data_dir?`<div class="muted mono">${e(x.data_dir)}</div>`:''}</td><td>${e(shortVersionText(x.version)||'—')}</td><td>${badge(x.status||'unknown')}</td><td class="mono">${databaseEndpointText(x.endpoints)}${(x.socket_paths||[]).length?`<div class="muted">socket: ${(x.socket_paths||[]).map(e).join('<br>')}</div>`:''}</td><td>${databaseCatalogDiscoveryCell(x)}</td><td>${x.engine==='postgresql'?databaseScheduledJobDiscoveryCell(x):'—'}</td><td class="resource-tools-cell"><div class="resource-doc-inline">${resourceDocumentationToggle('database-documentation-exempt','data-instance',x.id,x.documentation_exempt)}</div>${databaseAssignments(x,'instance')}${can('vms.manage')?`<div class="docker-container-assign resource-assignment">${databaseServiceSelect(services,`instance-${index}`)}${resourceContextSelect(categories,'environment',`database-environment-instance-${index}`,'Mediu')}${resourceContextSelect(categories,'operational_status',`database-status-instance-${index}`,'Status operațional')}${resourceContextSelect(categories,'solution_type',`database-solution-instance-${index}`,'Tip soluție')}<button type="button" class="small secondary database-add-service" data-type="instance" data-object="${x.id}" data-select="database-service-instance-${index}" data-environment="database-environment-instance-${index}" data-status="database-status-instance-${index}" data-solution="database-solution-instance-${index}">Asociază</button></div>`:''}</td></tr>`).join('');
  const catalogRows=catalogs.map((c,index)=>`<tr><td><strong>${e(c.name)}</strong>${c.system?' <span class="muted">(system)</span>':''}</td><td>${e(c._instance.product||c._instance.engine)}</td><td>${e(c._instance.instance_name||'implicit')}</td><td>${e(c.kind||'database')}</td><td class="resource-tools-cell"><div class="resource-doc-inline">${resourceDocumentationToggle('database-catalog-documentation-exempt','data-catalog',c.id,c.documentation_exempt)}</div>${databaseAssignments(c,'catalog')}${can('vms.manage')?`<div class="docker-container-assign resource-assignment">${databaseServiceSelect(services,`catalog-${index}`)}${resourceContextSelect(categories,'environment',`database-environment-catalog-${index}`,'Mediu')}${resourceContextSelect(categories,'operational_status',`database-status-catalog-${index}`,'Status operațional')}${resourceContextSelect(categories,'solution_type',`database-solution-catalog-${index}`,'Tip soluție')}<button type="button" class="small secondary database-add-service" data-type="catalog" data-object="${c.id}" data-select="database-service-catalog-${index}" data-environment="database-environment-catalog-${index}" data-status="database-status-catalog-${index}" data-solution="database-solution-catalog-${index}">Asociază</button></div>`:''}</td></tr>`).join('');
  const jobRows=scheduledJobs.map(job=>{const x=job._instance||{},db=[job.database,job.username].filter(Boolean).map(e).join(' / ')||'—',times=[job.next_run?`Următoarea: ${e(job.next_run)}`:'',job.last_run?`Ultima: ${e(job.last_run)}`:''].filter(Boolean).join('<br>')||'—';return `<tr><td><strong>${e(job.scheduler||'PostgreSQL')}</strong></td><td><strong>${e(job.name||('job '+(job.job_id||''))||'—')}</strong>${job.job_id?`<div class="muted mono">ID ${e(job.job_id)}</div>`:''}</td><td>${e(x.instance_name||'implicit')}<div class="muted">${e(shortVersionText(x.version)||cleanVersionText(x.version)||'')}</div></td><td class="mono">${e(job.schedule||'—')}</td><td>${db}</td><td>${e(job.source_database||'—')}</td><td>${databaseScheduledJobState(job)}</td><td>${times}</td></tr>`}).join('');
  return `${kpis}${panel('Engine-uri detectate',engineRows?`<div class="table-wrap"><table><thead><tr><th>Produs</th><th>Versiune</th><th>Executabil</th><th>Surse detecție</th></tr></thead><tbody>${engineRows}</tbody></table></div>`:empty('Nu au fost detectate engine-uri de baze de date.'))}${panel('Instanțe baze de date',instanceRows?`<div class="table-wrap"><table><thead><tr><th>Engine</th><th>Instanță</th><th>Versiune</th><th>Stare</th><th>Endpoint / socket</th><th>Catalog</th><th>Joburi DB</th><th>Documentare și servicii interne</th></tr></thead><tbody>${instanceRows}</tbody></table></div>`:empty('Nu există instanțe active detectate.'),'<span class="muted">Instanțele PostgreSQL sunt tratate separat după port, data directory și socket.</span>')}${panel('Baze de date logice',catalogRows?`<div class="table-wrap"><table><thead><tr><th>Bază</th><th>Engine</th><th>Instanță</th><th>Tip</th><th>Documentare și servicii interne</th></tr></thead><tbody>${catalogRows}</tbody></table></div>`:empty('Numele bazelor nu au putut fi enumerate fără credențiale locale sau instanțele nu conțin baze vizibile.'),'<span class="muted">Asocierea bază → serviciu este independentă de asocierea VM → serviciu.</span>')}${panel('Joburi programate PostgreSQL',jobRows?`<div class="table-wrap"><table><thead><tr><th>Scheduler</th><th>Job</th><th>Instanță</th><th>Program</th><th>DB / user</th><th>Catalog sursă</th><th>Stare</th><th>Execuții</th></tr></thead><tbody>${jobRows}</tbody></table></div>`:empty('Nu au fost detectate joburi pgAgent/pg_cron sau metadata lor nu este accesibilă.'),'<span class="muted">Sunt inventariate numai metadatele schedulerului. SQL-ul, comenzile și scripturile joburilor nu sunt colectate.</span>')}`;
}
function databaseAssignmentInputs(value){return (value?.service_assignments||[]).map(a=>({service_id:Number(a.service_id),environment_id:a.environment_id?Number(a.environment_id):null,operational_status_id:a.operational_status_id?Number(a.operational_status_id):null,solution_type_id:a.solution_type_id?Number(a.solution_type_id):null,component_name:a.component_name||'',role_name:a.role_name||'',notes:a.notes||''}))}
function bindDatabaseActions(vmID,view,services){
  const instances=new Map((view?.instances||[]).map(x=>[Number(x.id),x])),catalogs=new Map();(view?.instances||[]).forEach(i=>(i.catalogs||[]).forEach(c=>catalogs.set(Number(c.id),c)));
  document.querySelectorAll('.database-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const id=Number(input.dataset.instance);try{await api(`/api/v1/vms/${vmID}/databases/instances/${id}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare a instanței a fost salvată.');const item=instances.get(id);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  document.querySelectorAll('.database-catalog-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const id=Number(input.dataset.catalog);try{await api(`/api/v1/vms/${vmID}/databases/catalogs/${id}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare a bazei a fost salvată.');const item=catalogs.get(id);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  
  const target=(type,id)=>type==='catalog'?catalogs.get(Number(id)):instances.get(Number(id));
  const endpoint=(type,id)=>type==='catalog'?`/api/v1/vms/${vmID}/databases/catalogs/${id}/services`:`/api/v1/vms/${vmID}/databases/instances/${id}/services`;
  document.querySelectorAll('.database-add-service').forEach(button=>button.addEventListener('click',async()=>{const type=button.dataset.type,id=Number(button.dataset.object),select=document.getElementById(button.dataset.select),serviceID=Number(select?.value||0);if(!serviceID){toast('Alege un serviciu.',true);return}const environmentID=resourceContextValue(button.dataset.environment),statusID=resourceContextValue(button.dataset.status),solutionTypeID=resourceContextValue(button.dataset.solution);if(!environmentID||!statusID||!solutionTypeID){toast('Alege mediul, statusul operațional și tipul soluției.',true);return}const value=target(type,id),assignments=databaseAssignmentInputs(value),existing=assignments.find(a=>a.service_id===serviceID);if(existing){existing.environment_id=environmentID;existing.operational_status_id=statusID;existing.solution_type_id=solutionTypeID}else assignments.push({service_id:serviceID,environment_id:environmentID,operational_status_id:statusID,solution_type_id:solutionTypeID});try{await api(endpoint(type,id),{method:'PUT',body:JSON.stringify({assignments})});toast(type==='catalog'?'Baza a fost asociată serviciului.':'Instanța a fost asociată serviciului.');vmDetail(vmID,'databases')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.database-remove-service').forEach(button=>button.addEventListener('click',async()=>{const type=button.dataset.type,id=Number(button.dataset.object),serviceID=Number(button.dataset.service),value=target(type,id),assignments=databaseAssignmentInputs(value).filter(a=>a.service_id!==serviceID);try{await api(endpoint(type,id),{method:'PUT',body:JSON.stringify({assignments})});toast('Asocierea a fost eliminată.');vmDetail(vmID,'databases')}catch(err){toast(err.message,true)}}));
}
function serviceDatabasePanel(resources,serviceID){
  const values=Array.isArray(resources)?resources:[];if(!values.length)return empty('Nu există baze de date sau instanțe asociate acestui serviciu. Asocierea se face din fila Baze de date a VM-ului gazdă.');
  const rows=values.map(x=>{const assigned=(x.service_assignments||[]).filter(a=>Number(a.service_id)===Number(serviceID));const role=assigned.map(a=>[a.environment?environmentDisplay(a.environment):'',a.operational_status,a.solution_type,a.component_name,a.role_name].filter(Boolean).map(e).join(' · ')).filter(Boolean).join('<br>')||'—';return `<tr><td><a href="#vms/${x.vm_id}/databases"><strong>${e(x.vm_hostname||x.vm_name)}</strong></a></td><td>${e(x.product||x.engine)}</td><td>${e(x.instance_name||'implicit')}</td><td>${x.resource_type==='database'?`<strong>${e(x.database_name)}</strong>`:'<span class="muted">întreaga instanță</span>'}</td><td class="mono">${databaseEndpointText(x.endpoints)}</td><td>${badge(x.status||'unknown')}</td><td>${databaseScheduledJobSummary(x.scheduled_jobs)}</td><td>${role}</td></tr>`}).join('');
  return `<div class="table-wrap"><table><thead><tr><th>VM gazdă</th><th>Engine</th><th>Instanță</th><th>Bază</th><th>Endpoint</th><th>Stare</th><th>Joburi DB</th><th>Mediu / status / tip soluție / componentă / rol</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

function serviceDockerPanel(containers,serviceID){
  const values=Array.isArray(containers)?containers:[];if(!values.length)return empty('Nu există containere Docker asociate acestui serviciu. Asocierea se face din fila Docker a VM-ului gazdă sau prin labels vm-doc.service / vm-doc.services.');
  const rows=values.map(c=>{const related=(c.service_assignments||[]).filter(a=>Number(a.service_id)===Number(serviceID));const mine=related.map(a=>`${a.environment?`${e(environmentDisplay(a.environment))} · `:''}${a.operational_status?`${e(a.operational_status)} · `:''}${a.solution_type?`${e(a.solution_type)} · `:''}${e(a.component_name||'')}${a.role_name?` · ${e(a.role_name)}`:''}${a.source?` <span class="muted">(${e(a.source)})</span>`:''}`).filter(Boolean).join('<br>');return `<tr><td><a href="#vms/${c.vm_id}/docker"><strong>${e(c.vm_hostname||c.vm_name)}</strong></a></td><td><strong>${e(c.name)}</strong></td><td class="mono">${e(c.image||'—')}</td><td>${c.compose_project?`${e(c.compose_project)} / ${e(c.compose_service||'')}`:'—'}</td><td>${badge(c.state||'unknown')}${c.health?`<div class="muted">${e(c.health)}</div>`:''}</td><td>${dockerPortText(c.ports)}</td><td>${mine||'—'}</td></tr>`}).join('');return `<div class="table-wrap"><table><thead><tr><th>VM gazdă</th><th>Container</th><th>Imagine</th><th>Compose</th><th>Stare</th><th>Porturi</th><th>Mediu / status / tip soluție / componentă / rol</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

function webBindingText(values){
  if(!Array.isArray(values)||!values.length)return '—';
  return values.map(x=>{const address=x.address||'*',protocol=x.protocol||((x.tls)?'https':'http'),port=x.port?`:${x.port}`:'';return `${e(protocol)}://${e(address)}${port}`}).join('<br>');
}
function webAssignmentChips(site){
  const values=Array.isArray(site?.service_assignments)?site.service_assignments:[];
  if(!values.length)return '<span class="muted">Neasociat</span>';
  return `<div class="docker-service-chips">${values.map(a=>`<span class="docker-service-chip"><a href="#services/${a.service_id}">${e(a.service_name)}</a>${resourceAssignmentMeta(a)}${can('vms.manage')?`<button type="button" class="web-remove-service" data-site="${site.id}" data-service="${a.service_id}" title="Elimină asocierea">×</button>`:''}</span>`).join('')}</div>`;
}
function webServiceSelect(services,idSuffix){return `<select class="web-service-select" id="web-service-${idSuffix}"><option value="">— Serviciu —</option>${(services||[]).filter(x=>x.active!==false).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('')}</select>`}
function webSiteTarget(site){
  const values=[];
  if(site.document_root)values.push(`<strong>root:</strong> <span class="mono">${e(site.document_root)}</span>`);
  if(Array.isArray(site.backends)&&site.backends.length)values.push(`<strong>backend:</strong> ${site.backends.map(e).join(', ')}`);
  if(Array.isArray(site.proxy_targets)&&site.proxy_targets.length)values.push(`<strong>proxy:</strong> ${site.proxy_targets.map(x=>`<span class="mono">${e(x)}</span>`).join('<br>')}`);
  return values.length?values.join('<br>'):'—';
}
function webVMSection(view,services,categories){
  const host=view?.host,servers=Array.isArray(view?.servers)?view.servers:[],sites=Array.isArray(view?.sites)?view.sites:[];
  if(!host)return panel('Web',empty('Nu există încă inventar Web structurat. Este necesar vm-doc-agent 1.6.0+ și un snapshot cu collectorul web.'));
  const products=[...new Set(servers.map(x=>x.product||x.engine).filter(Boolean))];
  const kpis=`<div class="resource-kpis resource-kpis-4"><div class="card"><div class="label">Servere web</div><div class="value">${host.server_count||0}</div></div><div class="card"><div class="label">Site-uri / frontends</div><div class="value">${host.site_count||0}</div></div><div class="card"><div class="label">Produse</div><div class="value compact">${e(products.join(', ')||'—')}</div></div><div class="card"><div class="label">Ultima observație</div><div class="value compact">${dt(host.observed_at)}</div></div></div>`;
  const serverRows=servers.map(x=>`<tr><td><strong>${e(x.product||x.engine)}</strong><div class="muted mono">${e(x.engine)}</div></td><td>${e(shortVersionText(x.version)||'—')}</td><td>${badge(x.status||'unknown')}</td><td>${e(x.service_name||'—')}</td><td class="mono">${(x.config_files||[]).map(e).join('<br>')||'—'}</td><td class="mono">${e(x.executable||'—')}</td><td class="resource-doc-cell">${resourceDocumentationToggle('web-documentation-exempt','data-server',x.id,x.documentation_exempt)}</td></tr>`).join('');
  const siteRows=sites.map((x,index)=>`<tr><td><strong>${e(x.name||'—')}</strong>${x.default?' <span class="muted">(default)</span>':''}<div class="muted">${e(x.site_type||'site')} · ${x.enabled?badge('active'):badge('disabled')}</div></td><td><strong>${e(x.product||x.engine)}</strong><div class="muted mono">${e(x.engine)}</div></td><td>${(x.server_names||[]).map(e).join('<br>')||'—'}</td><td class="mono">${webBindingText(x.bindings)}</td><td>${webSiteTarget(x)}</td><td class="mono">${e(x.config_file||'—')}</td><td class="resource-tools-cell"><div class="resource-doc-inline">${resourceDocumentationToggle('web-site-documentation-exempt','data-site',x.id,x.documentation_exempt)}</div>${webAssignmentChips(x)}${can('vms.manage')?`<div class="resource-assignment">${webServiceSelect(services,`site-${index}`)}${resourceContextSelect(categories,'environment',`web-environment-site-${index}`,'Mediu')}${resourceContextSelect(categories,'operational_status',`web-status-site-${index}`,'Status operațional')}${resourceContextSelect(categories,'solution_type',`web-solution-site-${index}`,'Tip soluție')}<button type="button" class="small secondary web-add-service" data-site="${x.id}" data-select="web-service-site-${index}" data-environment="web-environment-site-${index}" data-status="web-status-site-${index}" data-solution="web-solution-site-${index}">Asociază</button></div>`:''}</td></tr>`).join('');
  return `${kpis}${panel('Servere web detectate',serverRows?`<div class="table-wrap"><table><thead><tr><th>Produs</th><th>Versiune</th><th>Stare</th><th>Serviciu OS</th><th>Config</th><th>Executabil</th><th>Documentare</th></tr></thead><tbody>${serverRows}</tbody></table></div>`:empty('Nu au fost detectate Nginx, Apache HTTP Server sau HAProxy.'))}${panel('Site-uri web și frontends',siteRows?`<div class="table-wrap"><table><thead><tr><th>Site / frontend</th><th>Engine</th><th>Nume publice</th><th>Bind</th><th>Root / backend / proxy</th><th>Config</th><th>Documentare și servicii interne</th></tr></thead><tbody>${siteRows}</tbody></table></div>`:empty('Serverul web este detectat, dar nu au fost identificate site-uri, virtual hosts sau frontends.'),'<span class="muted">Un site sau frontend poate aparține unuia sau mai multor servicii, independent de VM-ul gazdă.</span>')}`;
}
function webAssignmentInputs(site){return (site?.service_assignments||[]).map(a=>({service_id:Number(a.service_id),environment_id:a.environment_id?Number(a.environment_id):null,operational_status_id:a.operational_status_id?Number(a.operational_status_id):null,solution_type_id:a.solution_type_id?Number(a.solution_type_id):null,component_name:a.component_name||'',role_name:a.role_name||'',notes:a.notes||''}))}
function bindWebActions(vmID,view){
  const sites=new Map((view?.sites||[]).map(x=>[Number(x.id),x]));
  document.querySelectorAll('.web-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const serverID=Number(input.dataset.server);try{await api(`/api/v1/vms/${vmID}/web/servers/${serverID}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare Web a fost salvată.');const item=(view?.servers||[]).find(x=>Number(x.id)===serverID);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  document.querySelectorAll('.web-site-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const siteID=Number(input.dataset.site);try{await api(`/api/v1/vms/${vmID}/web/sites/${siteID}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare a configurației Web a fost salvată.');const item=sites.get(siteID);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  const endpoint=id=>`/api/v1/vms/${vmID}/web/sites/${id}/services`;
  document.querySelectorAll('.web-add-service').forEach(button=>button.addEventListener('click',async()=>{const id=Number(button.dataset.site),select=document.getElementById(button.dataset.select),serviceID=Number(select?.value||0);if(!serviceID){toast('Alege un serviciu.',true);return}const environmentID=resourceContextValue(button.dataset.environment),statusID=resourceContextValue(button.dataset.status),solutionTypeID=resourceContextValue(button.dataset.solution);if(!environmentID||!statusID||!solutionTypeID){toast('Alege mediul, statusul operațional și tipul soluției.',true);return}const site=sites.get(id),assignments=webAssignmentInputs(site),existing=assignments.find(a=>a.service_id===serviceID);if(existing){existing.environment_id=environmentID;existing.operational_status_id=statusID;existing.solution_type_id=solutionTypeID}else assignments.push({service_id:serviceID,environment_id:environmentID,operational_status_id:statusID,solution_type_id:solutionTypeID});try{await api(endpoint(id),{method:'PUT',body:JSON.stringify({assignments})});toast('Site-ul web a fost asociat serviciului.');vmDetail(vmID,'web')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.web-remove-service').forEach(button=>button.addEventListener('click',async()=>{const id=Number(button.dataset.site),serviceID=Number(button.dataset.service),site=sites.get(id),assignments=webAssignmentInputs(site).filter(a=>a.service_id!==serviceID);try{await api(endpoint(id),{method:'PUT',body:JSON.stringify({assignments})});toast('Asocierea site-ului web a fost eliminată.');vmDetail(vmID,'web')}catch(err){toast(err.message,true)}}));
}
function serviceWebPanel(sites,serviceID){
  const values=Array.isArray(sites)?sites:[];if(!values.length)return empty('Nu există site-uri web sau frontends asociate acestui serviciu. Asocierea se face din fila Web a VM-ului gazdă.');
  const rows=values.map(x=>{const assigned=(x.service_assignments||[]).filter(a=>Number(a.service_id)===Number(serviceID));const role=assigned.map(a=>[a.environment?environmentDisplay(a.environment):'',a.operational_status,a.solution_type,a.component_name,a.role_name].filter(Boolean).map(e).join(' · ')).filter(Boolean).join('<br>')||'—';return `<tr><td><a href="#vms/${x.vm_id}/web"><strong>${e(x.vm_hostname||x.vm_name)}</strong></a></td><td><strong>${e(x.name||'—')}</strong><div class="muted">${e(x.site_type||'site')}</div></td><td>${e(x.product||x.engine)}</td><td>${(x.server_names||[]).map(e).join('<br>')||'—'}</td><td class="mono">${webBindingText(x.bindings)}</td><td>${webSiteTarget(x)}</td><td>${role}</td></tr>`}).join('');
  return `<div class="table-wrap"><table><thead><tr><th>VM gazdă</th><th>Site / frontend</th><th>Engine</th><th>Nume publice</th><th>Bind</th><th>Root / backend</th><th>Mediu / status / tip soluție / componentă / rol</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}


const changeCategoryLabels={system:'Sistem',storage:'Stocare',network:'Rețea',services:'Servicii OS',ports:'Porturi',firewall:'Firewall',accounts:'Conturi',identity:'Identitate',integrations:'Integrări',time:'Timp',databases:'Baze de date',docker:'Docker',web:'Web'};
const changeTypeLabels={added:'Adăugat',removed:'Eliminat',modified:'Modificat'};
const changeDocLabels={unset:'Nesetat',required:'Necesită documentație',not_required:'Nu necesită'};
const changeReviewLabels={new:'Nou',reviewed:'Revizuit',ignored:'Ignorat'};
function changeParsedValue(value){if(value===undefined||value===null||value==='')return undefined;try{return typeof value==='string'?JSON.parse(value):value}catch{return value}}
function changeJSONPreview(value){const parsed=changeParsedValue(value);if(parsed===undefined)return '—';return `<pre class="change-json">${e(typeof parsed==='string'?parsed:JSON.stringify(parsed,null,2))}</pre>`}
function changeValueText(value){if(value===undefined)return '—';if(value===null)return 'null';if(typeof value==='object')return JSON.stringify(value);return String(value)}
function changeValueEqual(a,b){try{return JSON.stringify(a)===JSON.stringify(b)}catch{return String(a)===String(b)}}
function changeDiffEntries(before,after,prefix=''){
  const plain=value=>value&&typeof value==='object'&&!Array.isArray(value);
  if(plain(before)&&plain(after)){const keys=[...new Set([...Object.keys(before),...Object.keys(after)])].sort((a,b)=>a.localeCompare(b,'ro'));return keys.flatMap(key=>changeDiffEntries(before[key],after[key],prefix?`${prefix}.${key}`:key))}
  return changeValueEqual(before,after)?[]:[{key:prefix||'valoare',before,after}];
}
function changeDetailsHTML(change){
  const before=changeParsedValue(change.old_json),after=changeParsedValue(change.new_json),diffs=changeDiffEntries(before,after).slice(0,80);
  const diffHTML=diffs.length?`<div class="change-diff-wrap"><table class="change-diff-table"><thead><tr><th>Câmp</th><th>Anterior</th><th>Nou</th></tr></thead><tbody>${diffs.map(item=>`<tr><td class="mono">${e(item.key)}</td><td class="change-old-value">${e(changeValueText(item.before))}</td><td class="change-new-value">${e(changeValueText(item.after))}</td></tr>`).join('')}</tbody></table>${changeDiffEntries(before,after).length>80?'<div class="muted">Sunt afișate primele 80 de diferențe.</div>':''}</div>`:'<div class="muted">Nu există diferențe semantice între valorile normalizate.</div>';
  const raw=`<details class="change-raw-details"><summary>JSON complet</summary><div class="change-compare"><div><span>Anterior</span>${changeJSONPreview(change.old_json)}</div><div><span>Nou</span>${changeJSONPreview(change.new_json)}</div></div></details>`;
  return `${diffHTML}${raw}`;
}
function changeFilterQuery(f,vmID=0,includePage=true){const p=new URLSearchParams();if(vmID)p.set('vm_id',String(vmID));if(f.q)p.set('q',f.q);if(f.category)p.set('category',f.category);if(f.changeType)p.set('change_type',f.changeType);if(f.doc)p.set('documentation_requirement',f.doc);if(f.review)p.set('review_status',f.review);if(includePage){p.set('page',String(f.page||1));p.set('page_size',String(f.pageSize||10))}return p.toString()}
function changesFilterHTML(f,{vm=false}={}){return `<div class="filterbar changes-filterbar"><label class="changes-search-field"><span>Căutare</span><input id="changeSearch" type="search" value="${e(f.q)}" placeholder="${vm?'Obiect sau descriere':'VM, hostname, obiect sau descriere'}"></label><label><span>Categorie</span><select id="changeCategory"><option value="">Toate</option>${Object.entries(changeCategoryLabels).map(([v,l])=>`<option value="${v}" ${f.category===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label><span>Tip</span><select id="changeType"><option value="">Toate</option>${Object.entries(changeTypeLabels).map(([v,l])=>`<option value="${v}" ${f.changeType===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label><span>Documentație</span><select id="changeDoc"><option value="">Toate</option>${Object.entries(changeDocLabels).map(([v,l])=>`<option value="${v}" ${f.doc===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label><span>Stare</span><select id="changeReview"><option value="">Toate</option>${Object.entries(changeReviewLabels).map(([v,l])=>`<option value="${v}" ${f.review===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><button id="clearChangeFilters" class="secondary" type="button">Curăță</button></div>`}
function changesTable(result,{vm=false}={}){const items=Array.isArray(result?.items)?result.items:[],f=vm?state.vmChanges:state.changes;f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);const rows=items.map(c=>`<tr data-change-row="${c.id}">${vm?'':`<td><a href="#vms/${c.vm_id}/changes"><strong>${e(c.vm_hostname||c.vm_name)}</strong></a><div class="muted">${e(c.vm_name)}</div></td>`}<td>${dt(c.occurred_at)}</td><td>${e(changeCategoryLabels[c.category]||c.category)}<div class="muted">${e(c.object_type)}</div></td><td><strong>${e(c.object_label)}</strong><div class="muted">${e(c.summary)}</div><details class="change-details"><summary>Detalii</summary>${changeDetailsHTML(c)}</details></td><td>${badge(changeTypeLabels[c.change_type]||c.change_type)}</td><td><select class="change-doc-select" data-searchable="off">${Object.entries(changeDocLabels).map(([v,l])=>`<option value="${v}" ${c.documentation_requirement===v?'selected':''}>${e(l)}</option>`).join('')}</select></td><td><select class="change-review-select" data-searchable="off">${Object.entries(changeReviewLabels).map(([v,l])=>`<option value="${v}" ${c.review_status===v?'selected':''}>${e(l)}</option>`).join('')}</select></td><td><input class="change-notes" value="${e(c.notes||'')}" placeholder="Observații"><button class="small secondary save-change" data-id="${c.id}" type="button">Salvează</button></td></tr>`).join('');const total=Number(result?.total||0),pages=Number(result?.pages||0),start=total?(f.page-1)*f.pageSize+1:0,end=Math.min(f.page*f.pageSize,total);const pager=`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="changePageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'change-page')}</div></div>`;return `${rows?`<div class="table-wrap changes-table-wrap"><table><thead><tr>${vm?'':'<th>VM</th>'}<th>Detectat</th><th>Categorie</th><th>Modificare</th><th>Tip</th><th>Documentație</th><th>Stare</th><th>Observații</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există modificări pentru filtrele selectate.')}${pager}`}
async function saveInventoryChange(button,reload){const row=button.closest('[data-change-row]'),id=Number(button.dataset.id);const body={documentation_requirement:row.querySelector('.change-doc-select').value,review_status:row.querySelector('.change-review-select').value,notes:row.querySelector('.change-notes').value.trim()};try{await api(`/api/v1/changes/${id}`,{method:'PATCH',body:JSON.stringify(body)});toast('Modificarea a fost actualizată.');reload()}catch(err){toast(err.message,true)}}
function bindChangesArea(area,reload,f){area.querySelectorAll('.save-change').forEach(b=>b.onclick=()=>saveInventoryChange(b,reload));area.querySelectorAll('.change-page').forEach(b=>b.onclick=()=>{const page=Number(b.dataset.page);if(page>0&&page!==f.page){f.page=page;reload()}});document.getElementById('changePageSize')?.addEventListener('change',ev=>{f.pageSize=Number(ev.target.value);f.page=1;reload()})}
function bindChangeFilters(reload,f){let timer;document.getElementById('changeSearch')?.addEventListener('input',ev=>{clearTimeout(timer);timer=setTimeout(()=>{f.q=ev.target.value.trim();f.page=1;reload()},250)});[['changeCategory','category'],['changeType','changeType'],['changeDoc','doc'],['changeReview','review']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{f[key]=ev.target.value;f.page=1;reload()}));document.getElementById('clearChangeFilters')?.addEventListener('click',()=>{Object.assign(f,{q:'',category:'',changeType:'',doc:'',review:'',page:1});reload(true)})}
async function loadGlobalChanges(){const area=document.getElementById('changesTableArea');if(!area)return;area.classList.add('is-loading');try{const result=await api(`/api/v1/changes?${changeFilterQuery(state.changes)}`);document.getElementById('changeTotal').textContent=Number(result.total||0).toLocaleString('ro-RO');document.getElementById('changeNew').textContent=Number(result.new_count||0).toLocaleString('ro-RO');document.getElementById('changeUnset').textContent=Number(result.unset_count||0).toLocaleString('ro-RO');document.getElementById('changeRequired').textContent=Number(result.required_count||0).toLocaleString('ro-RO');area.innerHTML=changesTable(result);bindChangesArea(area,loadGlobalChanges,state.changes)}catch(err){area.innerHTML=empty(err.message);toast(err.message,true)}finally{area.classList.remove('is-loading')}}
async function changesPage(){pageMeta('Modificări','Diferențe semnificative apărute după baseline-ul acceptat');const f=state.changes;const baselineTools=can('vms.manage')?'<button id="setGlobalChangesBaseline" class="secondary">Stabilește inventarul curent ca baseline</button>':'';const baselineHint='<div class="baseline-hint"><strong>Baseline</strong><span>Modificările de dinaintea baseline-ului rămân în baza de date pentru audit, dar nu mai apar în lista curentă și nu afectează procentul de documentație.</span></div>';content.innerHTML=`<div class="cards changes-summary-cards"><div class="card"><div class="label">Modificări</div><div id="changeTotal" class="value">—</div></div><div class="card"><div class="label">Noi</div><div id="changeNew" class="value">—</div></div><div class="card"><div class="label">Documentație nesetată</div><div id="changeUnset" class="value">—</div></div><div class="card"><div class="label">Necesită documentație</div><div id="changeRequired" class="value">—</div></div></div>${panel('Modificări inventar',`${baselineHint}${changesFilterHTML(f)}<div id="changesTableArea" class="loading">Se încarcă modificările…</div>`,baselineTools)}`;bindChangeFilters(flag=>flag?changesPage():loadGlobalChanges,f);document.getElementById('setGlobalChangesBaseline')?.addEventListener('click',async()=>{if(!confirm('Stabilești inventarul curent al tuturor VM-urilor ca baseline? Modificările existente vor rămâne în istoric, dar vor fi ascunse din trierea curentă.'))return;try{const r=await api('/api/v1/changes/baseline',{method:'POST',body:JSON.stringify({})});toast(`Baseline actualizat pentru ${Number(r.vm_count||0)} VM-uri.`);state.changes.page=1;loadGlobalChanges()}catch(err){toast(err.message,true)}});await loadGlobalChanges()}
async function loadVMChanges(vmID){if(Number(state.vmChanges.vmId)!==Number(vmID))state.vmChanges={vmId:vmID,q:'',category:'',changeType:'',doc:'',review:'',page:1,pageSize:10};const f=state.vmChanges,area=document.getElementById('vmChangesArea');if(!area)return;try{const result=await api(`/api/v1/changes?${changeFilterQuery(f,vmID)}`);area.innerHTML=changesTable(result,{vm:true});bindChangesArea(area,()=>loadVMChanges(vmID),f)}catch(err){area.innerHTML=empty(err.message);toast(err.message,true)}}
function vmChangesSection(vmID){const f=Number(state.vmChanges.vmId)===Number(vmID)?state.vmChanges:{vmId:vmID,q:'',category:'',changeType:'',doc:'',review:'',page:1,pageSize:10};state.vmChanges=f;return `${changesFilterHTML(f,{vm:true})}<div id="vmChangesArea" class="loading">Se încarcă modificările…</div>`}


function monitoringTargetTable(values,type){const items=Array.isArray(values)?values:[];if(!items.length)return empty(type==='blackbox'?'Nu există probe Blackbox corelate cu această VM.':'Nu există target Prometheus metrics corelat cu această VM.');const rows=items.map(t=>type==='blackbox'?`<tr><td><strong>${e(t.prometheus_source_name)}</strong><div class="muted">${e(t.job_name||'—')}</div></td><td class="mono">${e(t.target_url||t.instance||'—')}</td><td>${targetVisualStatus(t)}</td><td>${t.http_status_code??'—'}</td><td>${t.probe_duration_seconds!=null?`${(Number(t.probe_duration_seconds)*1000).toFixed(0)} ms`:'—'}</td><td>${t.tls_expiry_at?dt(t.tls_expiry_at):'—'}</td><td>${e(t.match_method||'—')}<div class="muted mono">${e(t.match_value||'')}</div></td></tr>`:`<tr><td><strong>${e(t.prometheus_source_name)}</strong></td><td>${e(t.job_name||'—')}</td><td class="mono">${e(t.instance||'—')}</td><td>${badge(t.health||'unknown')}</td><td>${dt(t.last_scrape_at)}</td><td>${t.scrape_duration_seconds!=null?`${(Number(t.scrape_duration_seconds)*1000).toFixed(0)} ms`:'—'}</td><td>${e(t.match_method||'—')}<div class="muted mono">${e(t.match_value||'')}</div></td><td class="error-text">${e(t.last_error||'—')}</td></tr>`).join('');return `<div class="table-wrap monitoring-vm-target-table"><table><thead><tr>${type==='blackbox'?'<th>Sursă / job</th><th>URL</th><th>Probe</th><th>HTTP</th><th>Durată</th><th>TLS expiră</th><th>Corelare</th>':'<th>Sursă</th><th>Job</th><th>Instance</th><th>Health</th><th>Ultimul scrape</th><th>Durată</th><th>Corelare</th><th>Eroare</th>'}</tr></thead><tbody>${rows}</tbody></table></div>`}
function vmMonitoringSection(m){
  m=m||{};
  const aliases=Array.isArray(m.aliases)?m.aliases:[],aliasText=aliases.map(a=>a.alias).join('\n'),vcenterIPs=Array.isArray(m.vcenter_ips)?m.vcenter_ips:[];
  const ipHTML=vcenterIPs.length?`<div class="monitoring-ip-list">${vcenterIPs.map(ip=>`<code>${e(ip)}</code>`).join('')}</div>`:'<span class="muted">—</span>';
  const node=`<div class="detail-grid monitoring-vm-summary-grid">${detail('Instalat / detectat',(m.exporter_installed||m.exporter_running)?badge('yes'):badge('no'))}${detail('Rulează',m.exporter_running?badge('running'):badge('stopped'))}${detail('Versiune',e(shortVersionText(m.exporter_version)||'—'))}${detail('Endpoint local',e(m.exporter_endpoint||'—'),true)}${detail('IP-uri vCenter',ipHTML)}${detail('Prometheus metrics',m.metrics_monitored?(m.metrics_up?badge('up'):badge('down')):badge('missing'))}${detail('Blackbox',m.blackbox_monitored?(m.blackbox_up?badge('up'):badge('down')):'—')}${detail('Stare',monitoringStateBadge(m.monitoring_state||'unmonitored'))}</div>`;
  const aliasPanel=can('monitoring.manage')?panel('Aliasuri corelare',`<form id="monitoringAliasForm" class="monitoring-vm-form"><label>Aliasuri Prometheus / hosts<textarea id="monitoringAliases" rows="5" class="mono" placeholder="prometheus-web-prod\nweb-prod">${e(aliasText)}</textarea><small>Un alias pe linie. Se folosește după label, FQDN, hostname, IP și /etc/hosts. După salvare rulează Sync Prometheus.</small></label><div class="form-actions"><button type="submit">Salvează aliasurile</button></div></form>`):'';
  return `<div class="vm-monitoring-workspace">${panel('Node Exporter și stare monitorizare',node,'<a class="button-link small secondary" href="#monitoring/overview">Monitorizare globală</a>')}${panel('Prometheus metrics',monitoringTargetTable(m.metrics_targets,'metrics'))}${panel('Blackbox HTTP / HTTPS',monitoringTargetTable(m.blackbox_targets,'blackbox'))}${aliasPanel}</div>`;
}


function softwareKindLabel(value){const labels={desktop:'Desktop',appx:'AppX / MSIX',windows_feature:'Windows Feature / Role'};return labels[String(value||'').toLowerCase()]||value||'—'}
function softwareVMSection(vmID,view){
  const items=Array.isArray(view?.items)?view.items:[];
  if(!view?.host||!items.length)return empty('Agentul nu a raportat software instalat pentru această VM.');
  const publishers=[...new Set(items.map(item=>String(item.publisher||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
  const rows=items.map(item=>`<tr class="software-row" data-search="${e([item.name,item.version,item.publisher,item.install_location].join(' ').toLowerCase())}" data-kind="${e(item.kind||'')}" data-arch="${e(item.architecture||'')}" data-publisher="${e(item.publisher||'')}" data-primary="${item.primary?'yes':'no'}" data-present="${item.present?'yes':'no'}"><td><strong>${e(item.name)}</strong>${item.install_location?`<div class="muted mono">${e(item.install_location)}</div>`:''}</td><td>${e(item.version||'—')}</td><td>${e(item.publisher||'—')}</td><td>${e(item.architecture||'—')}</td><td>${e(item.scope||'—')}</td><td>${e(softwareKindLabel(item.kind))}</td><td>${item.present?badge(item.state||'installed'):badge('missing')}</td><td>${can('vms.manage')?`<label class="inline-check"><input type="checkbox" class="software-primary-toggle" data-id="${item.id}" ${item.primary?'checked':''}> Principal</label>`:(item.primary?badge('primary'):'—')}</td></tr>`).join('');
  const filters=`<div class="filterbar software-filterbar"><label>Căutare<input id="vmSoftwareSearch" placeholder="Nume, versiune, publisher…"></label><label>Tip<select id="vmSoftwareKind"><option value="">Toate</option><option value="desktop">Desktop</option><option value="appx">AppX / MSIX</option><option value="windows_feature">Windows Feature / Role</option></select></label><label>Arhitectură<select id="vmSoftwareArch"><option value="">Toate</option><option value="x64">x64</option><option value="x86">x86</option></select></label><label>Publisher<select id="vmSoftwarePublisher"><option value="">Toți</option>${publishers.map(v=>`<option value="${e(v)}">${e(v)}</option>`).join('')}</select></label><label>Principal<select id="vmSoftwarePrimary"><option value="">Toate</option><option value="yes">Da</option><option value="no">Nu</option></select></label><label>Prezență<select id="vmSoftwarePresence"><option value="yes">Detectat</option><option value="">Toate</option><option value="no">Nedetectat</option></select></label></div>`;
  return `${filters}<div class="section-actions"><span id="vmSoftwareCount" class="muted"></span><a class="button-link small secondary" href="/api/v1/vms/${vmID}/software/export">Export Excel</a></div><div class="table-wrap"><table><thead><tr><th>Software</th><th>Versiune</th><th>Publisher</th><th>Arh.</th><th>Scope</th><th>Tip</th><th>Stare</th><th>Documentație</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function bindSoftwareActions(vmID,view){
  const apply=()=>{const q=String(document.getElementById('vmSoftwareSearch')?.value||'').trim().toLowerCase(),kind=document.getElementById('vmSoftwareKind')?.value||'',arch=document.getElementById('vmSoftwareArch')?.value||'',publisher=document.getElementById('vmSoftwarePublisher')?.value||'',primary=document.getElementById('vmSoftwarePrimary')?.value||'',present=document.getElementById('vmSoftwarePresence')?.value||'';let visible=0;document.querySelectorAll('.software-row').forEach(row=>{const ok=(!q||row.dataset.search.includes(q))&&(!kind||row.dataset.kind===kind)&&(!arch||row.dataset.arch===arch)&&(!publisher||row.dataset.publisher===publisher)&&(!primary||row.dataset.primary===primary)&&(!present||row.dataset.present===present);row.hidden=!ok;if(ok)visible++});const count=document.getElementById('vmSoftwareCount');if(count)count.textContent=`${visible} din ${document.querySelectorAll('.software-row').length} elemente`;};
  ['vmSoftwareSearch','vmSoftwareKind','vmSoftwareArch','vmSoftwarePublisher','vmSoftwarePrimary','vmSoftwarePresence'].forEach(id=>document.getElementById(id)?.addEventListener(id==='vmSoftwareSearch'?'input':'change',apply));
  document.querySelectorAll('.software-primary-toggle').forEach(input=>input.addEventListener('change',async()=>{try{await api(`/api/v1/vms/${vmID}/software/${input.dataset.id}/primary`,{method:'POST',body:JSON.stringify({primary:input.checked})});toast(input.checked?'Software marcat Principal.':'Marcaj Principal eliminat.');vmDetail(vmID,'software')}catch(err){input.checked=!input.checked;toast(err.message,true)}}));
  apply();
}

const vmDetailGroups=[
  {code:'summary',label:'Rezumat',help:'Identitate și stare',sections:[['overview','Rezumat']]},
  {code:'configuration',label:'Configurare',help:'Servicii și operare',sections:[['services','Servicii'],['operational','Operațional'],['infrastructure','Infrastructură']]},
  {code:'application',label:'Aplicație',help:'Docker, DB și Web',sections:[['docker','Docker'],['databases','Baze de date'],['web','Web']]},
  {code:'inventory',label:'Inventar',help:'Agent și istoric',sections:[['inventory','Inventar agent'],['history','Istoric']]},
  {code:'backup',label:'Backup',help:'Veeam și cron',sections:[['backup','Backup']]},
  {code:'monitoring',label:'Monitorizare',help:'Prometheus și Blackbox',sections:[['monitoring','Monitorizare']]},
  {code:'documents',label:'Documentație',help:'Fișe VM',sections:[['continuity','Fișe și documente']]},
  {code:'changes',label:'Modificări',help:'Diferențe inventar',sections:[['changes','Modificări']]}
];
const vmDetailSections=[...vmDetailGroups.flatMap(group=>group.sections),['software','Software instalat']];
function vmDetailGroupsFor(hasSoftware=false){const groups=vmDetailGroups.map(group=>group.code==='inventory'&&hasSoftware?{...group,sections:[['software','Software instalat'],...group.sections]}:group);if(can('audit.read'))groups.push({code:'audit',label:'Audit',help:'Cine a schimbat ce',sections:[['audit','Audit']]});return groups}
function vmDetailGroupForSection(section,hasSoftware=false){const groups=vmDetailGroupsFor(hasSoftware);return groups.find(group=>group.sections.some(([code])=>code===section))||groups[0]}
function vmDetailNavigation(vmID,selected,hasSoftware=false){
  const groups=vmDetailGroupsFor(hasSoftware),activeGroup=vmDetailGroupForSection(selected,hasSoftware);
  const primary=`<nav class="vm-detail-tabs vm-detail-primary-tabs" aria-label="Zone VM">${groups.map(group=>{const target=group.sections[0][0];return `<a href="#vms/${vmID}/${target}" class="${activeGroup.code===group.code?'active':''}"><strong>${e(group.label)}</strong><small>${e(group.help)}</small></a>`}).join('')}</nav>`;
  const secondary=activeGroup.sections.length>1?`<nav class="vm-detail-subtabs" aria-label="Secțiuni ${e(activeGroup.label)}">${activeGroup.sections.map(([code,label])=>`<a href="#vms/${vmID}/${code}" class="${selected===code?'active':''}">${e(label)}</a>`).join('')}</nav>`:'';
  return `<div class="vm-detail-navigation">${primary}${secondary}</div>`;
}
function databaseOverviewNotice(view){
  const engines=Array.isArray(view?.engines)?view.engines:[],instances=Array.isArray(view?.instances)?view.instances:[];
  if(!engines.length)return '';
  const issues=[];
  for(const engine of engines){if(!instances.some(i=>i.engine===engine.engine))issues.push(`${engine.product||engine.engine}: engine detectat, dar instanța nu a putut fi determinată`)}
  for(const instance of instances){const status=String(instance.catalog_discovery_status||'').trim();if(status!=='discovered'&&(!(instance.catalogs||[]).length||status)){const reason=databaseCatalogReasonLabel(instance.catalog_discovery_reason)||status||'stare necunoscută';issues.push(`${instance.product||instance.engine} / ${instance.instance_name||'implicit'}: bazele nu au putut fi enumerate (${reason})`)}}
  if(!issues.length)return '';
  return `<div class="notice warning database-summary-warning"><strong>Inventar baze de date incomplet.</strong><div>${issues.map(e).map(x=>`<div>${x}</div>`).join('')}</div><a href="#vms/${view?.host?.vm_id||''}/databases">Vezi detalii Baze de date</a></div>`;
}

function inventorySectionValues(documentView,key){
  const section=(Array.isArray(documentView?.sections)?documentView.sections:[]).find(item=>String(item?.key||'').toLowerCase()===key);
  const data=section?.data;
  if(Array.isArray(data))return data;
  if(data&&typeof data==='object'){
    for(const candidate of [data.items,data.services,data.ports,data.listening_ports,data.entries])if(Array.isArray(candidate))return candidate;
    return Object.keys(data).length?[data]:[];
  }
  return [];
}
function resourceServiceRequirements(dockerView,databaseView,webView){
  const required=new Map();
  const add=(assignment,source)=>{const id=Number(assignment?.service_id||0);if(!id)return;const current=required.get(id)||{id,name:assignment?.service_name||`Serviciu #${id}`,sources:new Set()};if(assignment?.service_name)current.name=assignment.service_name;current.sources.add(source);required.set(id,current)};
  for(const container of (Array.isArray(dockerView?.containers)?dockerView.containers:[]))for(const assignment of (container.service_assignments||[]))add(assignment,'Docker');
  for(const instance of (Array.isArray(databaseView?.instances)?databaseView.instances:[])){
    for(const assignment of (instance.service_assignments||[]))add(assignment,'Baze de date');
    for(const catalog of (instance.catalogs||[])){if(catalog.system)continue;for(const assignment of (catalog.service_assignments||[]))add(assignment,'Baze de date')}
  }
  for(const site of (Array.isArray(webView?.sites)?webView.sites:[])){if(site.enabled===false)continue;for(const assignment of (site.service_assignments||[]))add(assignment,'Web')}
  return [...required.values()].sort((a,b)=>String(a.name).localeCompare(String(b.name),'ro'));
}
function directServiceAssignmentComplete(assignment){return !!(Number(assignment?.internal_service_id||0)&&Number(assignment?.architectural_domain_id||0)&&Number(assignment?.itil_category_id||0)&&Number(assignment?.layer_id||0)&&Number(assignment?.technical_role_id||0)&&Number(assignment?.solution_type_id||0))}
function resourceServiceConfigurationNotice(requirements,directServices){
  if(!requirements.length)return '';
  const configured=new Set((directServices||[]).filter(directServiceAssignmentComplete).map(item=>Number(item.internal_service_id)));
  const missing=requirements.filter(item=>!configured.has(Number(item.id)));
  if(!missing.length)return `<div class="notice success"><strong>Proiectele folosite în Docker/Baze/Web sunt configurate.</strong><span>${requirements.length} ${requirements.length===1?'proiect este legat':'proiecte sunt legate'} și în asocierile serviciilor și rolurilor tehnice.</span></div>`;
  return `<div class="notice warning"><strong>Necesită configurare pentru procentul VM.</strong><span>Proiectele selectate în Docker/Baze/Web trebuie să existe și aici cu domeniu, categorie, layer, rol tehnic și tip soluție.</span><div class="resource-service-requirements">${missing.map(item=>`<span><b>${e(item.name)}</b> · ${e([...item.sources].join(', '))}</span>`).join('')}</div></div>`;
}
function vmCompletion(vm,inventory,operational,dockerView,databaseView,webView,documentView,primaryServices=[],primaryPorts=[],servicesReviewed=false){
  const dockerContainers=Array.isArray(dockerView?.containers)?dockerView.containers:[];
  const dockerHostExempt=!!dockerView?.host?.documentation_exempt;
  const dbInstances=Array.isArray(databaseView?.instances)?databaseView.instances:[];
  const allDbCatalogs=dbInstances.flatMap(i=>(i.catalogs||[]).filter(c=>!c.system).map(c=>({...c,_instanceExempt:!!i.documentation_exempt})));
  const dbResources=allDbCatalogs.length?allDbCatalogs:dbInstances;
  const allWebSites=(Array.isArray(webView?.sites)?webView.sites:[]).filter(site=>site.enabled!==false);
  const webServers=Array.isArray(webView?.servers)?webView.servers:[];
  const serverExempt=site=>webServers.some(server=>server.engine===site.engine&&server.documentation_exempt);
  const directServices=Array.isArray(operational.service_assignments)?operational.service_assignments:[];
  const resourceServices=resourceServiceRequirements(dockerView,databaseView,webView);
  const configuredDirectServices=new Set(directServices.filter(directServiceAssignmentComplete).map(item=>Number(item.internal_service_id)));
  const hasResourceService=resourceServices.length>0;
  const osName=String(inventory.os_name||vm.guest_os||'').toLowerCase(),isWindows=osName.includes('windows');
  const serviceCriterion=isWindows?['Software principal',Number(vm.primary_software_count||0)>0]:['Serviciu documentat',directServices.length>0||hasResourceService];
  const checks=[
    ['Agent asociat',!!vm.agent_id],['Inventar agent',!!vm.current_inventory_id],['Hostname',!!(inventory.hostname||vm.guest_hostname)],['Sistem de operare',!!(inventory.os_name||vm.guest_os)],['IP principal',!!(operational.preferred_ip||inventory.primary_ip||vm.primary_ip)],
    ['Mediu',!!operational.environment_id],['Status operațional',!!operational.operational_status_id],['Clasificare',!!operational.classification_id],['Scop VM',!!String(operational.purpose||'').trim()],serviceCriterion,['Responsabilitate',Array.isArray(operational.responsibilities)&&operational.responsibilities.length>0]
  ];
  dockerContainers.forEach(x=>checks.push([`Docker: ${x.name||x.id}`,dockerHostExempt||!!x.documentation_exempt||(x.service_assignments||[]).length>0]));
  dbResources.forEach(x=>checks.push([`DB: ${x.name||x.instance_name||x.product||x.engine||x.id}`,!!x.documentation_exempt||!!x._instanceExempt||(x.service_assignments||[]).length>0]));
  allWebSites.forEach(x=>checks.push([`Web: ${x.name||x.id}`,!!x.documentation_exempt||serverExempt(x)||(x.service_assignments||[]).length>0]));
  resourceServices.forEach(item=>checks.push([`Configurare serviciu: ${item.name}`,configuredDirectServices.has(Number(item.id))]));
  if(vm.current_inventory_id){
    if(!isWindows)checks.push(['Serviciu software principal / servicii verificate',primaryServices.length>0||servicesReviewed]);
    checks.push(['Port / proces principal',primaryPorts.length>0]);
  }
  if(Number(vm.required_change_count||0)>0)checks.push(['Modificări ce necesită documentație',Number(vm.outstanding_required_changes||0)===0]);
  const done=checks.filter(([,ok])=>ok).length,percent=checks.length?Math.round(done*100/checks.length):0;return {percent,done,total:checks.length,missing:checks.filter(([,ok])=>!ok).map(([label])=>label)};
}

function vmCompletionHTML(value){const missing=value.missing.length?`<div class="completion-missing"><strong>De completat</strong><div>${value.missing.map(label=>`<span>${e(label)}</span>`).join('')}</div></div>`:`<div class="completion-complete">Fișa are toate câmpurile esențiale completate.</div>`;return `<div class="completion-detail"><div class="completion-score"><strong>${value.percent}%</strong><span>${value.done} din ${value.total} criterii esențiale</span></div><div class="completion-progress large"><i style="width:${value.percent}%"></i></div>${missing}</div>`}
const vmCompletionRefreshTimers=new Map();let vmCompletionRefreshGeneration=0;
function paintVMCompletion(value){document.querySelectorAll('[data-vm-completion-percent]').forEach(node=>node.textContent=`${value.percent}%`);document.querySelectorAll('[data-vm-completion-progress]').forEach(node=>node.style.width=`${value.percent}%`);const detailNode=document.getElementById('vmCompletionDetail');if(detailNode)detailNode.innerHTML=vmCompletionHTML(value)}
function refreshVMCompletion(vmID,delay=250){const key=Number(vmID);const prior=vmCompletionRefreshTimers.get(key);if(prior)clearTimeout(prior);const timer=setTimeout(async()=>{vmCompletionRefreshTimers.delete(key);const generation=++vmCompletionRefreshGeneration;try{const [data,dockerView,databaseView,webView]=await Promise.all([api(`/api/v1/vms/${key}`),api(`/api/v1/vms/${key}/docker`).catch(()=>({host:null,containers:[]})),api(`/api/v1/vms/${key}/databases`).catch(()=>({host:null,instances:[]})),api(`/api/v1/vms/${key}/web`).catch(()=>({host:null,servers:[],sites:[]}))]);if(generation!==vmCompletionRefreshGeneration)return;const hashParts=(location.hash||'').slice(1).split('/');if(hashParts[0]!=='vms'||Number(hashParts[1])!==key)return;const vm=data.vm||{},inventory=data.inventory||{},operational=data.operational||{},documentView=data.inventory_document||{},primaryServices=Array.isArray(data.primary_agent_services)?data.primary_agent_services:[],primaryPorts=Array.isArray(data.primary_agent_ports)?data.primary_agent_ports:[],servicesReviewed=!!data.agent_services_reviewed;paintVMCompletion(vmCompletion(vm,inventory,operational,dockerView,databaseView,webView,documentView,primaryServices,primaryPorts,servicesReviewed))}catch(err){console.warn('completion refresh failed',err)}},delay);vmCompletionRefreshTimers.set(key,timer)}
function documentationGroupTypeLabel(value){return ({active_active:'Active / Active',active_standby:'Active / Standby',cluster:'Cluster'})[value]||'Cluster'}
function vmDocumentationInheritancePanel(vm,inheritance,vms){
  const value=inheritance||{},members=Array.isArray(value.members)?value.members:[];
  if(value.is_source){
    const memberRows=members.map(item=>`<tr><td><a href="#vms/${item.vm_id}/services"><strong>${e(item.vm_name)}</strong></a></td><td>${e(item.hostname||'—')}</td><td class="mono">${e(item.primary_ip||'—')}</td></tr>`).join('');
    return panel('Cluster / grup HA',`<div class="notice inheritance-source-notice inheritance-panel-notice"><strong>Acest VM este sursa documentației comune.</strong><p>Modificările de servicii, date operaționale și asocieri Docker/DB/Web sunt propagate către membrii care au moștenirea activă.</p><div class="detail-grid">${detail('Grup',e(value.group_name||'—'))}${detail('Tip',e(documentationGroupTypeLabel(value.group_type)))}</div></div>${memberRows?`<div class="table-wrap"><table><thead><tr><th>Membru</th><th>Hostname</th><th>IP</th></tr></thead><tbody>${memberRows}</tbody></table></div>`:empty('Nu există membri în grup.')}`,'<span class="muted">Pentru a schimba sursa, modifică relația din fișa VM-ului membru.</span>');
  }
  const sourceID=Number(value.source_vm_id||0),sourceOptions=(vms||[]).filter(item=>Number(item.id)!==Number(vm.id)).map(item=>`<option value="${item.id}" ${Number(item.id)===sourceID?'selected':''}>${e(item.name)}${item.primary_ip?` · ${e(item.primary_ip)}`:''}</option>`).join('');
  const inherited=sourceID>0,resourceSyncAction=inherited&&value.inherit_resource_assignments&&can('vms.manage')?'<button type="button" id="syncInheritedResources" class="small secondary inheritance-sync-resources">Sincronizează acum Docker / DB / Web</button>':'',help=inherited?`<div class="notice inheritance-member-notice inheritance-panel-notice"><strong>Documentație moștenită din ${e(value.source_vm_name||'VM sursă')}.</strong><p>Dezactivează sursa pentru a păstra valorile curente și a continua documentarea local.</p>${resourceSyncAction?`<div class="inheritance-notice-actions">${resourceSyncAction}<span class="muted">Folosește inventarul tehnic deja colectat. Resursele noi sunt sincronizate automat la următorul Colect.</span></div>`:''}</div>`:'<p class="muted inheritance-local-help">Alege un VM sursă pentru perechi LB, noduri Active/Active, Active/Standby sau alte clustere. Datele tehnice colectate rămân individuale.</p>';
  if(!can('vms.manage'))return panel('Cluster / grup HA',help);
  return panel('Cluster / grup HA',`${help}<form id="documentationInheritanceForm" class="inheritance-form"><div class="form-grid"><label>VM sursă<select id="documentationSourceVM"><option value="">— Documentație locală —</option>${sourceOptions}</select></label><label>Nume grup<input id="documentationGroupName" value="${e(value.group_name||'')}" placeholder="ex. LB-PROD"></label><label>Tip grup<select id="documentationGroupType"><option value="active_active" ${value.group_type==='active_active'?'selected':''}>Active / Active</option><option value="active_standby" ${value.group_type==='active_standby'?'selected':''}>Active / Standby</option><option value="cluster" ${!value.group_type||value.group_type==='cluster'?'selected':''}>Cluster</option></select></label></div><div class="inheritance-options"><label><input id="inheritServiceAssignments" type="checkbox" ${value.inherit_service_assignments!==false?'checked':''}> Moștenește servicii, clasificare, layer, rol și tip soluție</label><label><input id="inheritOperationalMetadata" type="checkbox" ${value.inherit_operational_metadata!==false?'checked':''}> Moștenește documentația operațională comună</label><label><input id="inheritResourceAssignments" type="checkbox" ${(!value.source_vm_id||value.inherit_resource_assignments)?'checked':''}> Moștenește asocierile și documentarea Docker / DB / Web</label></div><div class="form-actions"><button type="submit">Salvează grupul HA</button>${inherited?'<button type="button" id="clearDocumentationInheritance" class="secondary">Treci pe documentație locală</button>':''}</div></form>`,'<span class="muted">Hostname, IP, UUID, inventarul tehnic al resurselor, agentul, backupul și monitorizarea nu se moștenesc.</span>');
}

async function vmDetail(id,requestedSection=''){
  const detailID=++vmDetailGeneration;
  if(Number(state.vmHistory.vmId)!==Number(id))state.vmHistory={vmId:id,page:1,pageSize:10};
  const hashParts=(location.hash||'').slice(1).split('/');const hashSection=hashParts[0]==='vms'&&Number(hashParts[1])===Number(id)?hashParts[2]:'';
  const candidate=requestedSection||hashSection||'overview';let selectedSection=(vmDetailSections.some(([code])=>code===candidate)||(candidate==='audit'&&can('audit.read')))?candidate:'overview';if(candidate!==selectedSection)history.replaceState(null,'',`#vms/${id}/${selectedSection}`);
  const [data,agents,categories,people,services,documentTemplates,generatedDocuments,externalSystems,externalConnections,dockerView,databaseView,webView,softwareView,monitoringView]=await Promise.all([api(`/api/v1/vms/${id}`),can('agents.read')?api('/api/v1/agents'):Promise.resolve([]),api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true'),api('/api/v1/services?include_inactive=true'),can('documents.read')?api('/api/v1/document-templates?object_type=vm'):Promise.resolve([]),can('documents.read')?api(`/api/v1/vms/${id}/documents`):Promise.resolve([]),can('external.read')?api('/api/v1/external-systems?active=active'):Promise.resolve([]),can('external.read')?api(`/api/v1/external-connections?vm_id=${id}`):Promise.resolve([]),api(`/api/v1/vms/${id}/docker`).catch(()=>({host:null,containers:[],images:[],networks:[],volumes:[],compose_projects:[]})),api(`/api/v1/vms/${id}/databases`).catch(()=>({host:null,engines:[],instances:[]})),api(`/api/v1/vms/${id}/web`).catch(()=>({host:null,servers:[],sites:[]})),api(`/api/v1/vms/${id}/software`).catch(()=>({host:null,items:[]})),can('monitoring.read')?api(`/api/v1/vms/${id}/monitoring`).catch(()=>({metrics_targets:[],blackbox_targets:[],aliases:[]})):Promise.resolve({metrics_targets:[],blackbox_targets:[],aliases:[]})]);
  if(detailID!==vmDetailGeneration)return;
  const documentationVMs=selectedSection==='services'&&can('vms.manage')?await fetchAllVMsForSelect():[];if(detailID!==vmDetailGeneration)return;
  const vm=data.vm,v=data.inventory||{},op=data.operational||{},inheritance=data.documentation_inheritance||{},backup=data.backup||{},backupDetails=data.backup_details||{},documentView=data.inventory_document||{},commonDependencies=Array.isArray(data.common_dependencies)?data.common_dependencies:[],primaryServices=Array.isArray(data.primary_agent_services)?data.primary_agent_services:[],primaryPorts=Array.isArray(data.primary_agent_ports)?data.primary_agent_ports:[],servicesReviewed=!!data.agent_services_reviewed;
  const serviceInherited=!!inheritance.source_vm_id&&!!inheritance.inherit_service_assignments,operationalInherited=!!inheritance.source_vm_id&&!!inheritance.inherit_operational_metadata,resourceInherited=!!inheritance.source_vm_id&&!!inheritance.inherit_resource_assignments;
  const ipAddresses=[...new Set([...(Array.isArray(data.ip_addresses)?data.ip_addresses:[]),op.preferred_ip,v.primary_ip,vm.primary_ip].filter(Boolean))];const preferredIP=op.preferred_ip||v.primary_ip||vm.primary_ip||'';const ipOptions='<option value="">— automat —</option>'+ipAddresses.map(ip=>`<option value="${e(ip)}" ${ip===preferredIP?'selected':''}>${e(ip)}</option>`).join('');
  const warningLabels={agent_data_unavailable:'Datele agentului asociat nu au putut fi încărcate.',inventory_data_unavailable:'Inventarul curent nu a putut fi încărcat.',inventory_document_unavailable:'Inventarul curent există, dar vederea structurată nu a putut fi generată.',operational_data_unavailable:'Datele operaționale nu au putut fi încărcate.',backup_data_unavailable:'Datele de backup nu au putut fi încărcate.',backup_details_unavailable:'Detaliile brute Veeam nu au putut fi interpretate.',common_dependencies_unavailable:'Dependențele către infrastructura comună nu au putut fi încărcate.',primary_agent_services_unavailable:'Selecția serviciilor software principale nu a putut fi încărcată.',primary_agent_ports_unavailable:'Selecția porturilor și proceselor principale nu a putut fi încărcată.',agent_services_review_unavailable:'Marcajul Servicii verificate nu a putut fi încărcat.',documentation_inheritance_unavailable:'Configurația de moștenire HA / cluster nu a putut fi încărcată.'};
  const vmWarnings=(Array.isArray(data.warnings)?data.warnings:[]).map(code=>warningLabels[code]||code),assignments=Array.isArray(op.service_assignments)?op.service_assignments:[];
  const hasSoftware=!!softwareView?.host&&((softwareView.items||[]).length>0||Number(softwareView.host.item_count||0)>0);if(selectedSection==='software'&&!hasSoftware)selectedSection='inventory';
  const sectionLabel=vmDetailSections.find(([code])=>code===selectedSection)?.[1]||'Rezumat';pageMeta(vm.name,`${sectionLabel} · fișă tehnică VM`);
  const agentOptions=`<option value="">Fără agent</option>${agents.map(x=>`<option value="${x.id}" ${vm.agent_id===x.id?'selected':''}>${e(x.name)} (${e(x.status)})</option>`).join('')}`;
  const documentLink=op.documentation_url?`<a href="${e(op.documentation_url)}" target="_blank" rel="noopener">${e(op.documentation_url)}</a>`:'—',initialResponsibilities=Array.isArray(op.responsibilities)?op.responsibilities:[],assignmentRows=assignments.map((item,index)=>serviceAssignmentRow(item,services,categories,index)).join(''),vmDocumentPanel=can('documents.read')?vmDocumentsPanel(id,documentTemplates,generatedDocuments):'';
  const completion=vmCompletion(vm,v,op,dockerView,databaseView,webView,documentView,primaryServices,primaryPorts,servicesReviewed);
  const overview=`${panel('Identificare și încadrare',`<div class="detail-grid">${detail('Nume VM',e(vm.name))}${detail('Hostname',e(v.hostname||vm.guest_hostname||'—'),true)}${detail('IP principal',e(preferredIP||'—'),true)}${detail('Sistem de operare',`${e(v.os_name||vm.guest_os||'—')} ${e(v.os_version||'')}`)}${detail('Mediu',e(op.environment?environmentDisplay(op.environment):'—'))}${detail('Status operațional',op.operational_status?badge(op.operational_status):'—')}${detail('Clasificare',e(op.classification||'—'))}${detail('Responsabilități',responsibilitySummary(op.responsibilities))}${detail('Documentație',documentLink)}${detail('Referință tichet',e(op.ticket_reference||'—'))}</div>`)}${databaseOverviewNotice(databaseView)}${panel('Completarea fișei',`<div id="vmCompletionDetail">${vmCompletionHTML(completion)}</div>`,'<span class="muted">Criterii tehnice și operaționale esențiale</span>')}`;
  const resourceRequirements=resourceServiceRequirements(dockerView,databaseView,webView),resourceRequirementsNotice=resourceServiceConfigurationNotice(resourceRequirements,assignments);
  const inheritancePanel=vmDocumentationInheritancePanel(vm,inheritance,documentationVMs);
  const inheritedServiceNotice=serviceInherited?`<div class="notice inheritance-member-notice"><strong>Asocierile sunt moștenite din ${e(inheritance.source_vm_name||'VM-ul sursă')}.</strong><p>Modifică serviciile pe sursă sau treci acest VM pe documentație locală.</p></div>`:'';
  const servicesSection=`${inheritancePanel}${panel('Servicii interne și roluri tehnice',`${resourceRequirementsNotice}${inheritedServiceNotice}<form id="serviceAssignmentsForm" class="service-assignments-form"><fieldset class="inheritance-fieldset" ${serviceInherited?'disabled':''}><p class="muted">Fiecare asociere descrie unde se încadrează VM-ul în serviciu: clasificare, rol tehnic, tipul soluției și modul de utilizare.</p><div id="vmServiceAssignmentRows" class="vm-service-assignment-rows">${assignmentRows}</div>${can('vms.manage')&&!serviceInherited?'<div class="form-actions"><button type="button" id="addServiceAssignment" class="secondary">Adaugă asociere</button><button type="submit">Salvează asocierile</button></div>':serviceInherited?'<div class="muted form-actions">Configurare moștenită; editarea locală este blocată.</div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}</fieldset></form>`)}${panel('Dependențe infrastructură comună',vmCommonDependencies(id,commonDependencies,services,categories),'<span class="muted">Moștenite din servicii, globale implicit sau adăugate direct pe VM</span>')}`;
  const operationalInheritedNotice=operationalInherited?`<div class="notice inheritance-member-notice"><strong>Date comune moștenite din ${e(inheritance.source_vm_name||'VM-ul sursă')}.</strong><p>Scopul, clasificarea, responsabilitățile, RPO/RTO, URL-ul documentației și observațiile se actualizează de pe sursă. Mediul, statusul, IP-ul principal și tichetul rămân locale.</p></div>`:'';
  const operationalSection=panel('Date operaționale',`${operationalInheritedNotice}<form id="operationalForm" class="operational-form"><div class="form-section"><h3>Încadrare operațională</h3><div class="form-grid"><label>Mediu<select id="opEnvironment">${nomenclatureOptions(categories,'environment',op.environment_id)}</select></label><label>Status operațional<select id="opStatus">${nomenclatureOptions(categories,'operational_status',op.operational_status_id)}</select></label><label>Clasificare<select id="opClassification">${nomenclatureOptions(categories,'classification',op.classification_id)}</select></label></div><label>Scopul VM-ului<textarea id="opPurpose" rows="3">${e(op.purpose||'')}</textarea></label><div class="form-grid"><label>IP principal documentație<select id="opPreferredIP">${ipOptions}</select></label><label>RPO (minute)<input id="opRPO" type="number" min="0" value="${op.rpo_minutes??''}" placeholder="ex. 1440"></label><label>RTO (minute)<input id="opRTO" type="number" min="0" value="${op.rto_minutes??''}" placeholder="ex. 240"></label></div><p class="muted">IP-ul selectat este folosit în liste și fișe. RPO/RTO sunt valori de continuitate documentate pentru VM.</p></div><div class="form-section"><div class="section-heading"><h3>Responsabilități</h3>${can('vms.manage')?'<button type="button" id="addResponsibility" class="small secondary">Adaugă persoană</button>':''}</div><div id="responsibilityRows" class="responsibility-rows">${initialResponsibilities.map((item,index)=>responsibilityRow(item,people,index)).join('')}</div>${!people.length?'<p class="muted">Adaugă mai întâi persoane din meniul Nomenclatoare.</p>':''}</div><div class="form-section"><h3>Referințe și observații</h3><div class="form-grid"><label class="span-2">URL documentație<input id="opDocumentation" type="url" value="${e(op.documentation_url||'')}" placeholder="https://..."></label><label>Referință tichet<input id="opTicket" value="${e(op.ticket_reference||'')}"></label></div><label>Observații<textarea id="opNotes" rows="4">${e(op.notes||'')}</textarea></label></div>${can('vms.manage')?'<div class="form-actions"><button type="submit">Salvează datele operaționale</button></div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}</form>`);
  const resourceInheritedNotice=resourceInherited?`<div class="notice inheritance-member-notice"><strong>Asocierile resurselor sunt moștenite din ${e(inheritance.source_vm_name||'VM-ul sursă')}.</strong><p>Inventarul tehnic rămâne local. Pentru resursele potrivite automat se sincronizează proiectul/serviciul, mediul, statusul, tipul soluției, componenta, rolul, observațiile și marcajele de documentare.</p></div>`:'';
  const dockerSection=`${resourceInheritedNotice}${dockerVMSection(dockerView,services,categories)}`;
  const databaseSection=`${resourceInheritedNotice}${databaseVMSection(databaseView,services,categories)}`;
  const webSection=`${resourceInheritedNotice}${webVMSection(webView,services,categories)}`;
  const softwareSection=softwareVMSection(id,softwareView);
  const inventoryTools=[can('collections.run')&&vm.agent_id?'<button id="testVMAgent" class="secondary">Test</button><button id="collectVM">Colect</button>':'',v.id&&can('inventories.raw.read')?'<button id="latestRaw" class="secondary">Vezi JSON brut</button>':''].filter(Boolean).join('');
  const inventorySection=`${panel('Date colectate de agent',structuredInventory(documentView,{vmID:id,primaryServices,primaryPorts,servicesReviewed,canManage:can('vms.manage')}),inventoryTools)}<section id="rawPanel"></section>`;
  const backupTabSection=`${panel('Backup și restaurare · sumar',backupSection(backup),'<span class="muted">Veeam + backup cron declarat</span>')}${can('vms.manage')?panel('Backup cron / script local',cronBackupForm(backup,documentView),'<span class="muted">Detectat de agent sau completat manual</span>'):''}${panel('Detalii Veeam',backupCandidateDetails(backupDetails),'<span class="muted">Lanțurile, joburile și politicile corelate cu această VM</span>')}`;
  const monitoringSection=vmMonitoringSection(monitoringView);
  const continuitySection=`${vmDocumentPanel}`;
  const deletePanel=!vm.present_in_vcenter&&can('vms.manage')?panel('Curățare înregistrare VM',`<div class="vm-delete-detail"><div><strong>VM-ul nu mai este prezent în vCenter.</strong><p>Poți elimina definitiv înregistrarea și datele dependente. Nu se creează arhivă. Agentul asociat, dacă există, nu este șters.</p><span class="muted">Lipsă din vCenter: ${dt(vm.missing_since)}</span></div><button id="deleteVMPermanent" class="danger" type="button">Șterge definitiv VM</button></div>`):'';
  const infrastructureSection=`${panel('Date vCenter',`<div class="detail-grid">${detail('Sursă',e(vm.vcenter_source_name))}${detail('MoID',e(vm.vcenter_moid),true)}${detail('BIOS UUID',e(vm.bios_uuid||'—'),true)}${detail('Instance UUID',e(vm.instance_uuid||'—'),true)}${detail('CPU',e(vm.cpu_count))}${detail('RAM',memory(vm.memory_mib))}${detail('Hardware',e(vm.hardware_version||'—'))}${detail('Ultima vedere',dt(vm.last_seen_at))}${detail('Guest hostname',e(vm.guest_hostname||'—'))}${detail('Guest OS',e(vm.guest_os||'—'))}${detail('IP vCenter',e(vm.primary_ip||'—'),true)}${detail('Prezentă în vCenter',boolText(vm.present_in_vcenter))}${detail('Lipsă din vCenter din',vm.missing_since?dt(vm.missing_since):'—')}</div>`)}${panel('Asociere agent',`<form id="vmManageForm" class="detail-grid"><label><span>Agent asociat</span><select id="vmAgent">${agentOptions}</select></label>${can('vms.manage')?'<label class="form-submit"><button type="submit">Salvează</button></label>':''}</form>`,can('collections.run')&&vm.agent_id?'<button id="testVMAgent" class="secondary">Testează agentul</button><button id="collectVM">Colectează acum</button>':'')}${can('external.read')?panel('Conexiuni către sisteme externe',scopedExternalConnectionPanel('vm',id,externalConnections,externalSystems),'<a class="button-link small secondary" href="#external">Sisteme externe</a>'):''}${deletePanel}`;
  const changesTools=`<span class="muted">Câmpurile volatile sunt ignorate; sunt afișate doar modificările după baseline.</span>${can('vms.manage')?'<button id="setVMBaseline" class="small secondary" type="button">Stabilește baseline VM</button>':''}`;
  const changesSection=panel('Modificări inventar',vmChangesSection(id),changesTools);
  const historySection=`${panel('Istoric inventare','<div id="inventoryHistoryArea" class="loading">Se încarcă istoricul…</div>')}<section id="rawPanel"></section>`;
  const auditSection='<div id="scopedAuditRoot" class="loading">Se încarcă auditul VM-ului…</div>';
  const sectionBodies={overview,services:servicesSection,operational:operationalSection,docker:dockerSection,databases:databaseSection,web:webSection,software:softwareSection,inventory:inventorySection,backup:backupTabSection,monitoring:monitoringSection,continuity:continuitySection,infrastructure:infrastructureSection,changes:changesSection,history:historySection,audit:auditSection};
  const warnings=vmWarnings.length?`<div class="notice warning"><strong>Fișa a fost încărcată parțial.</strong><ul>${vmWarnings.map(message=>`<li>${e(message)}</li>`).join('')}</ul><span class="muted">Detaliul tehnic este în jurnalul serviciului vm-doc-server.</span></div>`:'';
  const workspaceClass=vmDetailGroupForSection(selectedSection,hasSoftware).code==='configuration'?'vm-detail-workspace vm-detail-workspace-configuration':'vm-detail-workspace';
  content.innerHTML=`${warnings}<div class="cards vm-summary-cards"><div class="card"><div class="label">Completare fișă</div><div class="value compact" data-vm-completion-percent>${completion.percent}%</div><div class="completion-progress"><i data-vm-completion-progress style="width:${completion.percent}%"></i></div></div><div class="card"><div class="label">IP principal</div><div class="value compact mono">${e(preferredIP||'—')}</div></div><div class="card"><div class="label">Baseline</div><div class="value compact">${vm.baseline_established?badge('yes'):badge('no')}</div></div><div class="card"><div class="label">Power state</div><div class="value compact">${badge(vm.power_state||'unknown')}</div></div><div class="card"><div class="label">Agent</div><div class="value compact">${badge(vm.agent_status)}</div><div class="muted">${e(vm.agent_name||'Neasociat')}</div></div><div class="card"><div class="label">Mediu</div><div class="value compact">${e(op.environment?environmentDisplay(op.environment):'—')}</div></div><div class="card"><div class="label">Status operațional</div><div class="value compact">${op.operational_status?badge(op.operational_status):'—'}</div></div></div>${vmDetailNavigation(id,selectedSection,hasSoftware)}<div class="${workspaceClass}">${sectionBodies[selectedSection]}</div>`;

  document.getElementById('documentationInheritanceForm')?.addEventListener('submit',async ev=>{ev.preventDefault();const sourceValue=document.getElementById('documentationSourceVM').value,sourceID=sourceValue?Number(sourceValue):null,inheritServices=document.getElementById('inheritServiceAssignments').checked,inheritOperational=document.getElementById('inheritOperationalMetadata').checked,inheritResources=document.getElementById('inheritResourceAssignments').checked,groupName=document.getElementById('documentationGroupName').value.trim(),groupType=document.getElementById('documentationGroupType').value;if(sourceID&&(!groupName)){toast('Completează numele grupului HA / cluster.',true);return}if(sourceID&&(inheritServices||inheritOperational||inheritResources)&&!confirm('Activarea moștenirii va înlocui pe acest VM valorile locale selectate cu cele de pe VM-ul sursă. Pentru Docker/DB/Web se copiază doar documentarea/asocierile resurselor potrivite, nu inventarul tehnic. Continui?'))return;try{await api(`/api/v1/vms/${id}/documentation-inheritance`,{method:'PUT',body:JSON.stringify({source_vm_id:sourceID,group_name:groupName,group_type:groupType,inherit_service_assignments:inheritServices,inherit_operational_metadata:inheritOperational,inherit_resource_assignments:inheritResources})});toast(sourceID?'Moștenirea documentației a fost activată.':'Documentația VM-ului este locală.');vmDetail(id,'services')}catch(err){toast(err.message,true)}});
  document.getElementById('clearDocumentationInheritance')?.addEventListener('click',async()=>{if(!confirm('Treci acest VM pe documentație locală? Valorile copiate până acum rămân și pot fi modificate independent.'))return;try{await api(`/api/v1/vms/${id}/documentation-inheritance`,{method:'PUT',body:JSON.stringify({source_vm_id:null,group_name:'',group_type:'cluster',inherit_service_assignments:false,inherit_operational_metadata:false,inherit_resource_assignments:false})});toast('Moștenirea a fost dezactivată; valorile curente au rămas locale.');vmDetail(id,'services')}catch(err){toast(err.message,true)}});
  document.getElementById('syncInheritedResources')?.addEventListener('click',async()=>{const button=document.getElementById('syncInheritedResources');if(button)button.disabled=true;try{const result=await api(`/api/v1/vms/${id}/documentation-inheritance/sync-resources`,{method:'POST'});const matched=Number(result.docker_matched||0)+Number(result.database_matched||0)+Number(result.database_catalogs_matched||0)+Number(result.web_matched||0),unmatched=Number(result.docker_unmatched||0)+Number(result.database_unmatched||0)+Number(result.web_unmatched||0);toast(`Sincronizare terminată: ${matched} resurse potrivite${unmatched?`, ${unmatched} fără corespondent`:''}.`);vmDetail(id,'services')}catch(err){toast(err.message,true);if(button)button.disabled=false}});
  if(operationalInherited){['opClassification','opPurpose','opRPO','opRTO','opDocumentation','opNotes'].forEach(key=>{const el=document.getElementById(key);if(el)el.disabled=true});document.getElementById('addResponsibility')?.setAttribute('disabled','disabled');document.querySelectorAll('#responsibilityRows input,#responsibilityRows select,#responsibilityRows button').forEach(el=>el.disabled=true)}
  if(resourceInherited&&['docker','databases','web'].includes(selectedSection)){document.querySelectorAll('.vm-detail-workspace input,.vm-detail-workspace select,.vm-detail-workspace textarea,.vm-detail-workspace button').forEach(el=>el.disabled=true)}

  const assignmentContainer=document.getElementById('vmServiceAssignmentRows');
  assignmentContainer?.querySelectorAll('.vm-service-assignment-card').forEach((row,index)=>wireServiceAssignmentRow(row,services,categories,assignments[index]||{}));
  document.getElementById('addServiceAssignment')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=serviceAssignmentRow(null,services,categories,assignmentContainer.children.length);const row=wrapper.firstElementChild;assignmentContainer.appendChild(row);wireServiceAssignmentRow(row,services,categories,{})});
  assignmentContainer?.addEventListener('click',event=>{const button=event.target.closest('.remove-service-assignment');if(button)button.closest('.vm-service-assignment-card').remove()});
  assignmentContainer?.addEventListener('change',event=>{if(!event.target.classList.contains('assignment-primary-input')||!event.target.checked)return;assignmentContainer.querySelectorAll('.assignment-primary-input').forEach(input=>{if(input!==event.target)input.checked=false})});
  bindVMDependencyActions(id);bindPrimaryAgentServiceActions(id);bindPrimaryAgentPortActions(id);
  if(selectedSection==='docker'&&!resourceInherited)bindDockerActions(id,dockerView,services);
  if(selectedSection==='databases'&&!resourceInherited)bindDatabaseActions(id,databaseView,services);
  if(selectedSection==='web'&&!resourceInherited)bindWebActions(id,webView);
  if(selectedSection==='software')bindSoftwareActions(id,softwareView);
  document.getElementById('serviceAssignmentsForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const rows=[...assignmentContainer.querySelectorAll('.vm-service-assignment-card')];const values=rows.map((row,index)=>({architectural_domain_id:Number(row.querySelector('.assignment-domain').value||0),itil_category_id:Number(row.querySelector('.assignment-category').value||0),internal_service_id:Number(row.querySelector('.assignment-service').value||0),layer_id:Number(row.querySelector('.assignment-layer').value||0),technical_role_id:Number(row.querySelector('.assignment-role').value||0),solution_type_id:Number(row.querySelector('.assignment-solution-type').value||0),usage_type:row.querySelector('.assignment-usage').value,is_primary:row.querySelector('.assignment-primary-input').checked,notes:row.querySelector('.assignment-note').value.trim(),sort_order:index}));if(values.some(item=>!item.architectural_domain_id||!item.itil_category_id||!item.internal_service_id||!item.layer_id||!item.technical_role_id||!item.solution_type_id)){toast('Completează domeniul, categoria de serviciu, serviciul intern, layer-ul, rolul tehnic și tipul soluției pentru fiecare asociere.',true);return}try{await api(`/api/v1/vms/${id}/service-assignments`,{method:'PUT',body:JSON.stringify({assignments:values})});toast('Asocierile cu serviciile interne au fost salvate.');vmDetail(id,'services')}catch(err){toast(err.message,true)}});
  const responsibilityRows=document.getElementById('responsibilityRows');document.getElementById('addResponsibility')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=responsibilityRow(null,people,responsibilityRows.children.length);responsibilityRows.appendChild(wrapper.firstElementChild)});responsibilityRows?.addEventListener('click',event=>{const button=event.target.closest('.remove-responsibility');if(button)button.closest('.responsibility-row').remove()});
  document.getElementById('operationalForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const responsibilities=[...document.querySelectorAll('.responsibility-row')].map((row,index)=>({person_id:Number(row.querySelector('.responsibility-person').value||0),responsibility_type:row.querySelector('.responsibility-type').value,notes:row.querySelector('.responsibility-note').value.trim(),sort_order:index})).filter(item=>item.person_id>0);const selected=elementId=>{const value=document.getElementById(elementId).value;return value?Number(value):null};const body={environment_id:selected('opEnvironment'),operational_status_id:selected('opStatus'),purpose:document.getElementById('opPurpose').value.trim(),responsibilities,classification_id:selected('opClassification'),documentation_url:document.getElementById('opDocumentation').value.trim(),ticket_reference:document.getElementById('opTicket').value.trim(),notes:document.getElementById('opNotes').value.trim(),preferred_ip:document.getElementById('opPreferredIP').value,rpo_minutes:document.getElementById('opRPO').value===''?null:Number(document.getElementById('opRPO').value),rto_minutes:document.getElementById('opRTO').value===''?null:Number(document.getElementById('opRTO').value)};try{await api(`/api/v1/vms/${id}/operational`,{method:'PUT',body:JSON.stringify(body)});toast('Datele operaționale au fost salvate.');vmDetail(id,'operational')}catch(err){toast(err.message,true)}});
  document.getElementById('vmManageForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const selected=document.getElementById('vmAgent').value;const body={};if(selected)body.agent_id=Number(selected);else if(vm.agent_id)body.clear_agent=true;try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify(body)});toast('Asocierea agentului a fost actualizată.');vmDetail(id,'infrastructure')}catch(err){toast(err.message,true)}});
  document.getElementById('deleteVMPermanent')?.addEventListener('click',()=>deleteVMPermanent(Number(id),async()=>{location.hash='#vms'}));
  document.getElementById('testVMAgent')?.addEventListener('click',()=>vmJob(id,'test-agent'));document.getElementById('collectVM')?.addEventListener('click',()=>vmJob(id,'collect'));bindVMDocumentActions(id);
  document.querySelectorAll('input[name="cronBackupDetected"]').forEach(input=>input.addEventListener('change',()=>{if(!input.checked)return;const entry=cronInventoryEntries(documentView)[Number(input.value)];if(!entry)return;document.getElementById('cronBackupEnabled').checked=true;document.getElementById('cronBackupSchedule').value=entry.schedule||'';document.getElementById('cronBackupCommand').value=entry.command||'';const notes=document.getElementById('cronBackupNotes');if(!notes.value.trim()&&entry.user)notes.value=`Cron detectat de agent · user ${entry.user}${entry.source?` · ${entry.source}`:''}`}));
  document.getElementById('cronBackupForm')?.addEventListener('submit',async ev=>{ev.preventDefault();const body={enabled:document.getElementById('cronBackupEnabled').checked,schedule:document.getElementById('cronBackupSchedule').value.trim(),command:document.getElementById('cronBackupCommand').value.trim(),notes:document.getElementById('cronBackupNotes').value.trim()};try{await api(`/api/v1/vms/${id}/backup-settings`,{method:'PUT',body:JSON.stringify(body)});toast('Backup-ul cron a fost salvat în documentație.');vmDetail(id,'backup')}catch(err){toast(err.message,true)}});
  document.getElementById('monitoringAliasForm')?.addEventListener('submit',async ev=>{ev.preventDefault();const aliases=document.getElementById('monitoringAliases').value.split(/\r?\n/).map(v=>v.trim()).filter(Boolean);try{await api(`/api/v1/vms/${id}/monitoring/aliases`,{method:'PUT',body:JSON.stringify({aliases})});toast('Aliasurile au fost salvate. Rulează Sync Prometheus pentru recorelare.');vmDetail(id,'monitoring')}catch(err){toast(err.message,true)}});
  if(can('external.read'))bindScopedExternalConnectionActions('vm',id,()=>vmDetail(id,'infrastructure'));
  document.getElementById('latestRaw')?.addEventListener('click',async()=>{try{const raw=await api(`/api/v1/inventories/${v.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${v.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}});
  if(selectedSection==='changes'){document.getElementById('setVMBaseline')?.addEventListener('click',async()=>{if(!confirm('Stabilești inventarul curent al acestei VM ca baseline? Modificările existente rămân în istoric, dar nu vor mai apărea în trierea curentă.'))return;try{await api('/api/v1/changes/baseline',{method:'POST',body:JSON.stringify({vm_id:Number(id)})});toast('Baseline-ul VM-ului a fost actualizat.');state.vmChanges.page=1;vmDetail(id,'changes')}catch(err){toast(err.message,true)}});bindChangeFilters(()=>loadVMChanges(id),state.vmChanges);await loadVMChanges(id)}
  if(selectedSection==='history')await loadInventoryHistory(id);
  if(selectedSection==='audit'&&can('audit.read'))await scopedAuditPage('vm',id);
}
function bindRawInventoryButtons(scope=document){scope.querySelectorAll('.show-raw').forEach(button=>button.onclick=async()=>{try{const raw=await api(`/api/v1/inventories/${button.dataset.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${button.dataset.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}})}
function renderInventoryHistoryPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există snapshoturi pentru această VM.');
  const rows=items.map(item=>`<tr><td>${dt(item.received_at)}</td><td>${e(item.hostname)}</td><td>${e(item.os_name)} ${e(item.os_version)}</td><td>${item.collector_ok}/${item.collector_total}</td><td>${item.changed_from_previous?badge('changed'):badge('same')}</td><td>${can('inventories.raw.read')?`<button class="small secondary show-raw" data-id="${item.id}">JSON</button>`:''}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||10),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Primit</th><th>Hostname</th><th>OS</th><th>Colectori</th><th>Schimbare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="inventoryHistoryPageSize">${pageSizeOptions(pageSize,[10,20,50,100])}</select></label>${paginationButtons(page,Number(result.pages||1),'inventory-history-page')}</div></div>`;
}
async function loadInventoryHistory(vmID){
  const area=document.getElementById('inventoryHistoryArea');if(!area)return;area.className='loading';area.textContent='Se încarcă istoricul…';
  try{const result=await api(`/api/v1/vms/${vmID}/inventories?page=${state.vmHistory.page}&page_size=${state.vmHistory.pageSize}`);state.vmHistory.page=Number(result?.page||1);state.vmHistory.pageSize=Number(result?.page_size||10);area.className='';area.innerHTML=renderInventoryHistoryPage(result);bindRawInventoryButtons(area);area.querySelectorAll('.inventory-history-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmHistory.page){state.vmHistory.page=page;loadInventoryHistory(vmID)}}));document.getElementById('inventoryHistoryPageSize')?.addEventListener('change',event=>{state.vmHistory.pageSize=Number(event.target.value);state.vmHistory.page=1;loadInventoryHistory(vmID)})}catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}
async function vmJob(id,action){try{const job=await api(`/api/v1/vms/${id}/${action}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(()=>vmDetail(id),1200)}catch(err){toast(err.message,true)}}

let internalServicesCache=[];
const criticalityLabels={low:'Scăzută',normal:'Normală',high:'Ridicată',critical:'Critică'};
const documentationStatusLabels={draft:'Draft',in_progress:'În lucru',review:'În verificare',approved:'Aprobată',obsolete:'Depășită'};
function criticalityBadge(value){return badge(value||'normal')}
function openInternalService(service=null){
  document.getElementById('internalServiceDialogTitle').textContent=service?'Editare serviciu intern':'Serviciu intern nou';
  document.getElementById('internalServiceId').value=service?.id||'';
  document.getElementById('internalServiceName').value=service?.name||'';
  document.getElementById('internalServiceCode').value=service?.service_code||'';
  document.getElementById('internalServiceShortDescription').value=service?.short_description||'';
  document.getElementById('internalServiceAuthentication').value=service?.authentication||'';
  document.getElementById('internalServiceURL').value=service?.service_url||'';
  document.getElementById('internalServiceTechnologies').value=service?.technologies||'';
  document.getElementById('internalServiceCriticality').value=service?.criticality||'normal';
  document.getElementById('internalServiceDocStatus').value=service?.documentation_status||'draft';
  setRichTextEditor('internalServiceDescriptionRich',service?.description_richtext,service?.description||'');
  setRichTextEditor('internalServicePurposeRich',service?.purpose_richtext,service?.purpose||'');
  setRichTextEditor('internalServiceObjectivesRich',service?.objectives_richtext,service?.objectives||'');
  document.getElementById('internalServiceDocumentationURL').value=service?.documentation_url||'';
  document.getElementById('internalServiceActive').checked=service?.active??true;
  document.getElementById('internalServiceCommon').checked=!!service?.is_common;
  document.getElementById('internalServiceImplicitGlobal').checked=!!service?.implicit_global;
  const dependencyType=document.getElementById('internalServiceCommonDependencyType');dependencyType.innerHTML=selectOptions(categoryItems(nomenclatureCache,'dependency_type'),service?.common_dependency_type_id,'— Alege tipul dependenței —');
  dependencyType.disabled=!document.getElementById('internalServiceCommon').checked;
  internalServiceDialog.showModal();
}
function serviceClassificationSummary(values){
  if(!values?.length)return '<span class="muted">Neîncadrat încă</span>';
  return `<div class="service-classification-summary">${values.map(item=>`<div><strong>${e(item.architectural_domain)}</strong><span>${e(item.itil_category)} · ${item.vm_count||0} VM</span></div>`).join('')}</div>`;
}
function serviceSolutionSummary(values){
  if(!values?.length)return '<span class="muted">Nespecificat</span>';
  return `<div class="service-solution-summary">${values.map(item=>`<span>${e(item.solution_type)} <b>${item.vm_count||0}</b></span>`).join('')}</div>`;
}
function observedServiceClassifications(values){
  if(!values?.length)return empty('Domeniul și categoria de serviciu vor apărea automat după prima asociere făcută din fișa unui VM.');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Domeniu arhitectural</th><th>Categorie de serviciu</th><th>VM-uri</th><th>Asocieri</th></tr></thead><tbody>${values.map(item=>`<tr><td>${e(item.architectural_domain)}</td><td>${e(item.itil_category)}</td><td>${item.vm_count||0}</td><td>${item.assignment_count||0}</td></tr>`).join('')}</tbody></table></div>`;
}
function observedServiceRoles(values){
  if(!values?.length)return empty('Nu există încă layer-e și roluri tehnice. Acestea apar automat după asocierea VM-urilor.');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Layer</th><th>Rol tehnic</th><th>VM-uri</th><th>Stare</th></tr></thead><tbody>${values.map(mapping=>`<tr><td>${e(mapping.layer_name)}</td><td>${e(mapping.technical_role)}</td><td>${mapping.vm_count||0}</td><td>${mapping.active?badge('active'):badge('disabled')}</td></tr>`).join('')}</tbody></table></div>`;
}
function observedServiceSolutionTypes(values){
  if(!values?.length)return empty('Tipul soluției va apărea automat după ce este ales pe asocierile VM ale serviciului.');
  return `<div class="service-solution-cards">${values.map(item=>`<div class="service-solution-card"><span>${e(item.solution_type)}</span><strong>${item.vm_count||0} VM</strong><small>${item.assignment_count||0} asocieri</small></div>`).join('')}</div>`;
}
function environmentKind(value){const v=String(value||'').toLocaleLowerCase('ro-RO');if(v.includes('prod')||v.includes('produc'))return 'prod';if(v.includes('test')||v.includes('uat')||v.includes('qa'))return 'test';if(v.includes('dev')||v.includes('dezvolt'))return 'dev';return v?'other':'missing'}
function environmentDisplay(value){const raw=String(value||'').trim(),kind=environmentKind(raw);if(kind==='prod')return 'PROD';if(kind==='test')return 'TEST';if(kind==='dev')return 'DEV';return raw?raw.toLocaleUpperCase('ro-RO'):'Nespecificat'}
function environmentBadge(value){const kind=environmentKind(value),label=environmentDisplay(value);return `<span class="environment-badge ${kind}">${e(label)}</span>`}
function serviceEnvironmentStats(values){const unique=new Map();for(const item of values||[]){if(!unique.has(Number(item.id)))unique.set(Number(item.id),item)}const stats={prod:0,test:0,dev:0,other:0,missing:0,total:unique.size,groups:new Map()};for(const vm of unique.values()){const kind=environmentKind(vm.environment);stats[kind]=(stats[kind]||0)+1;const label=environmentDisplay(vm.environment);if(!stats.groups.has(label))stats.groups.set(label,[]);stats.groups.get(label).push(vm)}return stats}
function serviceEnvironmentPanel(values){const stats=serviceEnvironmentStats(values);if(!stats.total)return empty('Nu există VM-uri asociate.');const rows=[...stats.groups.entries()].sort((a,b)=>{const order={prod:1,test:2,dev:3,other:4,missing:5};return (order[environmentKind(a[0])]||9)-(order[environmentKind(b[0])]||9)||a[0].localeCompare(b[0],'ro')}).map(([env,vms])=>`<div class="service-environment-group"><div>${environmentBadge(env)}<strong>${vms.length} VM</strong></div><span>${vms.map(vm=>`<a href="#vms/${vm.id}">${e(vm.guest_hostname||vm.name)}</a>`).join(', ')}</span></div>`).join('');const kpis=[];if(stats.prod)kpis.push(`<div class="environment-kpi prod"><span>PROD</span><strong>${stats.prod}</strong></div>`);if(stats.test)kpis.push(`<div class="environment-kpi test"><span>TEST / UAT</span><strong>${stats.test}</strong></div>`);if(stats.dev)kpis.push(`<div class="environment-kpi dev"><span>DEV</span><strong>${stats.dev}</strong></div>`);if(stats.other+stats.missing)kpis.push(`<div class="environment-kpi other"><span>Altele / lipsă</span><strong>${stats.other+stats.missing}</strong></div>`);return `<div class="service-environment-summary">${kpis.length?`<div class="service-environment-kpis">${kpis.join('')}</div>`:''}<div class="service-environment-groups">${rows}</div></div>`}
function serviceTopCards(service){const stats=serviceEnvironmentStats(service.vms),cards=[`<div class="card"><div class="label">Criticitate</div><div class="value compact">${criticalityBadge(service.criticality)}</div></div>`,`<div class="card"><div class="label">Documentație</div><div class="value compact">${badge(service.documentation_status||'draft')}</div></div>`,`<div class="card"><div class="label">VM-uri</div><div class="value">${service.vm_count||0}</div></div>`];if(service.is_common){cards.push(`<div class="card common-service-card"><div class="label">Serviciu comun</div><div class="value compact">${service.implicit_global?badge('global'):badge('common')}</div></div>`);cards.push(`<div class="card common-service-card"><div class="label">Servicii afectate</div><div class="value">${service.dependent_service_count||0}</div></div>`);if((service.direct_vm_dependents||[]).length)cards.push(`<div class="card common-service-card"><div class="label">VM direct afectate</div><div class="value">${service.direct_vm_dependents.length}</div></div>`)}if(stats.prod)cards.push(`<div class="card environment-card prod"><div class="label">PROD</div><div class="value">${stats.prod}</div></div>`);if(stats.test)cards.push(`<div class="card environment-card test"><div class="label">TEST / UAT</div><div class="value">${stats.test}</div></div>`);if(stats.dev)cards.push(`<div class="card environment-card dev"><div class="label">DEV</div><div class="value">${stats.dev}</div></div>`);return `<div class="cards service-summary-cards">${cards.join('')}</div>`}

const nomenclatureIconGlyphs={domain:'🧭',category:'🗂️',layers:'🧱',role:'⚙️',app:'🧩',database:'🗄️',web:'🌐',integration:'🔌',monitor:'📈',shield:'🛡️',package:'📦',code:'⌨️',store:'🏢',environment:'🌍',status:'●',tag:'🏷️',server:'🖥️'};
function nomenclatureIcon(key,size='normal'){
  const normalized=String(key||'').trim();const glyph=nomenclatureIconGlyphs[normalized]||'◆';
  return `<span class="nomenclature-icon ${e(size)}" title="${e(normalized||'implicit')}">${glyph}</span>`;
}
function nomenclatureItemByID(categories,id){
  const numeric=Number(id||0);for(const category of (categories||[])){const found=(category.items||[]).find(item=>Number(item.id)===numeric);if(found)return found}return null;
}
function serviceAllDependencies(service){const out=[],seen=new Set();for(const item of [...(service.dependencies||[]),...(service.global_dependencies||[])]){if(item.active===false)continue;const key=`${item.target_service_id}:${item.dependency_type_id}:${item.source_environment_id||0}:${item.target_environment_id||0}`;if(seen.has(key))continue;seen.add(key);out.push(item)}return out}
function dependencyCriticalityBadge(value){const v=String(value||'normal').toLowerCase();const labels={informational:'Informativă',normal:'Normală',critical:'Critică'};return `<span class="dependency-criticality ${e(v)}">${e(labels[v]||v)}</span>`}
function dependencyEnvironmentText(dep){const source=dep.source_environment||'Oricare',target=dep.target_environment||'Oricare';return `${e(source)} <span class="dependency-flow-arrow">→</span> ${e(target)}`}
function dependencyEndpointText(dep){const parts=[];if(dep.protocol)parts.push(e(dep.protocol));if(dep.port)parts.push(`<span class="mono">${Number(dep.port)}</span>`);return parts.length?parts.join(' / '):'—'}
function serviceDependencyStrip(service){const deps=serviceAllDependencies(service);if(!deps.length)return '';return `<section class="service-common-diagram"><header><strong>Dependențe către alte servicii</strong><span>${deps.length} relații</span></header><div class="service-common-nodes">${deps.map(dep=>`<a href="#services/${dep.target_service_id}" class="service-common-node ${dep.global?'global':''}">${nomenclatureIcon(dep.dependency_type_icon||'integration','small')}<div><strong>${e(dep.target_service_name)}</strong><span>${e(dep.dependency_type)}${dep.source_environment||dep.target_environment?` · ${e(dep.source_environment||'Oricare')} → ${e(dep.target_environment||'Oricare')}`:''}${dep.global?' · global':''}</span></div><b>${dependencyCriticalityBadge(dep.criticality)}</b></a>`).join('')}</div><div class="dependency-arrow">↓ servicii de care depinde</div></section>`}
function serviceDependenciesPanel(service,services,categories){
  const explicit=service.dependencies||[],global=service.global_dependencies||[],all=[...explicit,...global];
  const rows=all.map(dep=>`<tr class="${dep.active===false?'dependency-inactive':''}"><td><a href="#services/${dep.target_service_id}"><strong>${e(dep.target_service_name)}</strong></a>${dep.global?'<div class="muted">Serviciu global implicit</div>':''}</td><td>${nomenclatureIcon(dep.dependency_type_icon||'integration','tiny')} ${e(dep.dependency_type)}</td><td>${dependencyEnvironmentText(dep)}</td><td>${dependencyCriticalityBadge(dep.criticality)}</td><td>${dependencyEndpointText(dep)}</td><td>${dep.target_vm_count||0}${dep.target_vm_names?`<div class="muted">${e(dep.target_vm_names)}</div>`:''}</td><td>${dep.global?badge('global'):(dep.active===false?badge('disabled'):badge('active'))}</td><td>${e(dep.notes||'—')}</td><td>${dep.id&&can('services.manage')?`<div class="dependency-actions"><button class="small secondary toggle-service-dependency" data-id="${dep.id}" data-active="${dep.active===false?'0':'1'}">${dep.active===false?'Activează':'Dezactivează'}</button><button class="small danger delete-service-dependency" data-id="${dep.id}">Șterge</button></div>`:'—'}</td></tr>`).join('');
  const targetServices=(services||[]).filter(item=>item.active&&Number(item.id)!==Number(service.id));const types=categoryItems(categories,'dependency_type'),environments=categoryItems(categories,'environment');
  const form=can('services.manage')&&targetServices.length&&types.length?`<form id="serviceDependencyForm" class="service-dependency-form service-dependency-editor"><label class="span-2">Acest serviciu depinde de<select id="serviceDependencyTarget" required><option value="">— Alege serviciul —</option>${targetServices.map(item=>`<option value="${item.id}">${e(item.name)}${item.is_common?(item.implicit_global?' · GLOBAL':' · comun'):''}</option>`).join('')}</select></label><label>Tip relație<select id="serviceDependencyType" required>${selectOptions(types,'','— Alege tipul —')}</select></label><label>Criticitate<select id="serviceDependencyCriticality"><option value="informational">Informativă</option><option value="normal" selected>Normală</option><option value="critical">Critică</option></select></label><label>Mediu sursă<select id="serviceDependencySourceEnvironment">${selectOptions(environments,'','Oricare / nespecificat')}</select></label><label>Mediu destinație<select id="serviceDependencyTargetEnvironment">${selectOptions(environments,'','Oricare / nespecificat')}</select></label><label>Protocol<input id="serviceDependencyProtocol" maxlength="64" placeholder="HTTPS, LDAP, JDBC, TCP…"></label><label>Port<input id="serviceDependencyPort" type="number" min="1" max="65535" placeholder="443"></label><label class="span-3">Observații<input id="serviceDependencyNotes" maxlength="1000" placeholder="Scopul relației, endpoint, particularități…"></label><label class="check-inline dependency-active-check"><input id="serviceDependencyActive" type="checkbox" checked> Activă</label><button type="submit">Adaugă dependență</button></form>`:'';
  return `<div class="dependency-direction-section"><div class="dependency-section-heading"><div><strong>Depinde de</strong><span>Relații ieșite din ${e(service.name)}</span></div><span class="muted">${all.filter(x=>x.active!==false).length} active</span></div>${form}${rows?`<div class="table-wrap"><table class="compact-table dependency-table"><thead><tr><th>Serviciu destinație</th><th>Tip</th><th>Medii</th><th>Criticitate</th><th>Protocol / port</th><th>VM-uri</th><th>Stare</th><th>Detalii</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există dependențe declarate. Serviciile marcate Global implicit vor apărea automat aici.')}</div>`
}
function bindServiceDependencyActions(serviceID){
  document.getElementById('serviceDependencyForm')?.addEventListener('submit',async event=>{event.preventDefault();const sourceEnv=document.getElementById('serviceDependencySourceEnvironment').value,targetEnv=document.getElementById('serviceDependencyTargetEnvironment').value,port=document.getElementById('serviceDependencyPort').value;const body={target_service_id:Number(document.getElementById('serviceDependencyTarget').value),dependency_type_id:Number(document.getElementById('serviceDependencyType').value),source_environment_id:sourceEnv?Number(sourceEnv):null,target_environment_id:targetEnv?Number(targetEnv):null,criticality:document.getElementById('serviceDependencyCriticality').value,protocol:document.getElementById('serviceDependencyProtocol').value.trim(),port:port?Number(port):null,notes:document.getElementById('serviceDependencyNotes').value.trim(),active:document.getElementById('serviceDependencyActive').checked};if(!body.target_service_id||!body.dependency_type_id){toast('Alege serviciul destinație și tipul relației.',true);return}try{await api(`/api/v1/services/${serviceID}/dependencies`,{method:'POST',body:JSON.stringify(body)});toast('Dependența a fost salvată.');internalServiceDetail(serviceID,'dependencies')}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.toggle-service-dependency').forEach(button=>button.addEventListener('click',async()=>{const active=button.dataset.active!=='1';try{await api(`/api/v1/services/${serviceID}/dependencies/${button.dataset.id}`,{method:'PATCH',body:JSON.stringify({active})});toast(active?'Dependența a fost activată.':'Dependența a fost dezactivată.');internalServiceDetail(serviceID,'dependencies')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.delete-service-dependency').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi definitiv această dependență?'))return;try{await api(`/api/v1/services/${serviceID}/dependencies/${button.dataset.id}`,{method:'DELETE'});toast('Dependența a fost ștearsă.');internalServiceDetail(serviceID,'dependencies')}catch(err){toast(err.message,true)}}))
}

function serviceDependentsPanel(service){
  const rows=(service.dependents||[]).map(dep=>`<tr class="${dep.active===false?'dependency-inactive':''}"><td><a href="#services/${dep.source_service_id}"><strong>${e(dep.source_service_name)}</strong></a></td><td>${nomenclatureIcon(dep.dependency_type_icon||'integration','tiny')} ${e(dep.dependency_type)}</td><td>${dependencyEnvironmentText(dep)}</td><td>${dependencyCriticalityBadge(dep.criticality)}</td><td>${dependencyEndpointText(dep)}</td><td>${dep.active===false?badge('disabled'):badge('active')}</td><td>${e(dep.notes||'—')}</td></tr>`).join('');
  const directRows=(service.direct_vm_dependents||[]).map(dep=>`<tr><td><a href="#vms/${dep.vm_id}"><strong>${e(dep.vm_name)}</strong></a></td><td>${e(dep.dependency_type)}</td><td>${e(dep.notes||'—')}</td></tr>`).join('');
  const global=service.implicit_global?`<div class="notice info"><strong>Serviciu global implicit.</strong> Este considerat dependență pentru toate celelalte servicii active (${service.dependent_service_count||0}).</div>`:'';
  const serviceTable=rows?`<div class="table-wrap"><table class="compact-table dependency-table"><thead><tr><th>Serviciu sursă</th><th>Tip</th><th>Medii</th><th>Criticitate</th><th>Protocol / port</th><th>Stare</th><th>Detalii</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Niciun alt serviciu nu declară încă o dependență către acest serviciu.');
  const vmTable=directRows?`<div class="common-direct-impact"><h3>VM-uri dependente direct</h3><div class="table-wrap"><table class="compact-table"><thead><tr><th>VM</th><th>Tip dependență</th><th>Detalii</th></tr></thead><tbody>${directRows}</tbody></table></div></div>`:'';
  return `<div class="dependency-direction-section incoming"><div class="dependency-section-heading"><div><strong>Este utilizat de</strong><span>Relații care au ca destinație ${e(service.name)}</span></div><span class="muted">${(service.dependents||[]).filter(x=>x.active!==false).length} active</span></div>${global}${serviceTable}${vmTable}</div>`;
}
function serviceDiagram(service,categories){
  const assignments=service.vms||[];const dependencyStrip=serviceDependencyStrip(service);if(!assignments.length)return dependencyStrip+empty('Schema proprie va apărea după ce asociezi cel puțin un VM serviciului.');
  const byVM=new Map();
  for(const item of assignments){
    const key=Number(item.id);if(!byVM.has(key))byVM.set(key,{id:key,name:item.name,hostname:item.guest_hostname,ip:item.primary_ip,power_state:item.power_state,environment:item.environment,assignments:[]});
    byVM.get(key).assignments.push(item);
  }
  const groups=new Map();
  for(const vm of byVM.values()){
    const layers=[...new Map(vm.assignments.filter(a=>a.layer_id).map(a=>[Number(a.layer_id),{id:Number(a.layer_id),name:a.layer_name}])).values()];
    let groupKey,groupName,groupIcon;
    if(layers.length===1){groupKey=`layer-${layers[0].id}`;groupName=layers[0].name||'Layer';groupIcon=nomenclatureItemByID(categories,layers[0].id)?.icon_key||'layers'}
    else if(layers.length>1){groupKey='multi';groupName='Multi-layer';groupIcon='layers'}
    else{groupKey='none';groupName='Fără layer';groupIcon='layers'}
    if(!groups.has(groupKey))groups.set(groupKey,{name:groupName,icon:groupIcon,vms:[]});groups.get(groupKey).vms.push(vm);
  }
  const lanes=[...groups.values()].sort((a,b)=>a.name==='Multi-layer'?1:b.name==='Multi-layer'?-1:a.name.localeCompare(b.name,'ro'));
  const laneHTML=lanes.map(lane=>`<section class="service-diagram-lane"><header>${nomenclatureIcon(lane.icon)}<div><strong>${e(lane.name)}</strong><span>${lane.vms.length} VM</span></div></header><div class="service-diagram-nodes">${lane.vms.map(vm=>serviceDiagramVM(vm,categories)).join('')}</div></section>`).join('');
  return `${dependencyStrip}<div class="service-diagram-toolbar"><div><strong>Schemă generată din asocierile VM</strong><span>${byVM.size} VM unice · ${assignments.length} asocieri</span></div><div class="service-diagram-legend">${nomenclatureIcon('server','small')} VM unic ${nomenclatureIcon('role','small')} rol ${nomenclatureIcon('database','small')} layer/rol specializat</div></div><div class="service-diagram">${laneHTML}</div>`;
}
function serviceDiagramVM(vm,categories){
  const associations=vm.assignments.map(a=>{
    const layer=nomenclatureItemByID(categories,a.layer_id);const role=nomenclatureItemByID(categories,a.technical_role_id);const solution=nomenclatureItemByID(categories,a.solution_type_id);
    const icon=role?.icon_key||layer?.icon_key||'role';
    return `<div class="service-diagram-association"><div class="service-diagram-role">${nomenclatureIcon(icon,'small')}<div><strong>${e(a.technical_role||'Rol nespecificat')}</strong><span>${e(a.layer_name||'Fără layer')}</span></div></div><div class="service-diagram-tags"><span>${nomenclatureIcon(solution?.icon_key||'package','tiny')}${e(a.solution_type||'—')}</span><span>${e(a.architectural_domain||'—')} / ${e(a.itil_category||'—')}</span>${a.is_primary?'<span class="primary-tag">principal</span>':''}</div></div>`;
  }).join('');
  return `<article class="service-diagram-vm ${environmentKind(vm.environment)}"><div class="service-diagram-vm-head">${nomenclatureIcon('server')}<div><a href="#vms/${vm.id}"><strong>${e(vm.name)}</strong></a><span>${e(vm.hostname||vm.ip||'—')}</span></div><div class="service-diagram-state">${environmentBadge(vm.environment)}${badge(vm.power_state||'unknown')}</div></div><div class="service-diagram-vm-meta"><span class="mono">${e(vm.ip||'IP —')}</span><span>${vm.assignments.length} ${vm.assignments.length===1?'asociere':'asocieri'}</span></div><div class="service-diagram-associations">${associations}</div></article>`;
}
function serviceVMRows(values){
  const grouped=new Map();for(const item of values||[]){const id=Number(item.id);if(!grouped.has(id))grouped.set(id,{...item,assignments:[]});grouped.get(id).assignments.push(item)}
  return [...grouped.values()].map(vm=>{const uniq=(items,key)=>[...new Set(items.map(key).filter(Boolean))];const classifications=uniq(vm.assignments,a=>[a.architectural_domain,a.itil_category].filter(Boolean).join(' / '));const roles=uniq(vm.assignments,a=>[a.layer_name,a.technical_role].filter(Boolean).join(' / '));const solutions=uniq(vm.assignments,a=>a.solution_type);const usages=uniq(vm.assignments,a=>serviceUsageLabels[a.usage_type]||a.usage_type);return `<tr><td><a href="#vms/${vm.id}"><strong>${e(vm.name)}</strong></a><div class="muted mono">${e(vm.guest_hostname||'—')}</div></td><td>${environmentBadge(vm.environment)}</td><td class="mono">${e(vm.primary_ip||'—')}</td><td>${classifications.map(e).join('<br>')||'—'}</td><td>${roles.map(e).join('<br>')||'—'}</td><td>${solutions.map(e).join('<br>')||'—'}</td><td>${usages.map(e).join('<br>')||'—'}</td><td>${vm.latest_document_id?`<a class="button-link tiny secondary" href="/api/v1/documents/${vm.latest_document_id}/download" title="${e(vm.latest_document_number||'Fișă VM')}">${e(vm.latest_document_number||'Fișă VM')}</a><div class="muted">${vm.latest_document_at?dt(vm.latest_document_at):''}</div>`:'<span class="muted">Fără fișă</span>'}</td><td>${vm.assignments.some(a=>a.is_primary)?badge('principal'):''}</td><td>${badge(vm.power_state||'unknown')}</td></tr>`}).join('');
}
function cropText(value,limit=150){const text=String(value||'').trim().replace(/\s+/g,' ');return text.length>limit?text.slice(0,limit-1).trimEnd()+'…':text}
function serviceMatchesFilters(service,f){const q=f.q.toLocaleLowerCase('ro');if(q&&!`${service.name} ${service.service_code||''} ${service.description||''}`.toLocaleLowerCase('ro').includes(q))return false;if(f.domain&&!(service.classifications||[]).some(x=>x.architectural_domain===f.domain))return false;if(f.category&&!(service.classifications||[]).some(x=>x.itil_category===f.category))return false;if(f.criticality&&service.criticality!==f.criticality)return false;if(f.docStatus&&service.documentation_status!==f.docStatus)return false;if(f.common==='common'&&(!service.is_common||service.implicit_global))return false;if(f.common==='global'&&!service.implicit_global)return false;if(f.common==='normal'&&service.is_common)return false;return true}
function serviceActiveFilterHTML(){const f=state.serviceFilters,items=[];if(f.q)items.push(`Căutare: ${f.q}`);const picks=[['serviceDomainFilter','domain'],['serviceCategoryFilter','category'],['serviceCriticalityFilter','criticality'],['serviceDocFilter','docStatus'],['serviceCommonFilter','common']];for(const [id,key] of picks){if(!f[key])continue;const select=document.getElementById(id),text=select?.options?.[select.selectedIndex]?.textContent?.trim();if(text)items.push(text)}return items.length?`<span class="vm-filter-caption">Filtre active</span>${items.map(v=>`<span class="vm-filter-chip">${e(v)}</span>`).join('')}`:'<span class="muted">Niciun filtru activ</span>'}


async function internalServicesPage(){pageMeta('Servicii','Catalog, filtre și dependențe comune');const [services,categories]=await Promise.all([api('/api/v1/services?include_inactive=true'),api('/api/v1/nomenclatures?include_inactive=true')]);internalServicesCache=services;nomenclatureCache=categories;renderInternalServicesCatalog()}

const externalTypeLabels={vm:'VM extern',server:'Server extern',endpoint:'Endpoint',network_service:'Serviciu de rețea'};
const externalDirectionLabels={outbound:'Ieșire → extern',inbound:'Intrare ← extern',bidirectional:'Bidirecțional ↔'};
const externalZoneTypeLabels={internet:'Internet',partner:'Partener',institution:'Altă instituție',cloud:'Cloud',external_dmz:'DMZ extern',other:'Altă rețea'};
const externalRiskLabels={unknown:'Necunoscut',low:'Scăzut',medium:'Mediu',high:'Ridicat',critical:'Critic'};
const externalTrustLabels={untrusted:'Untrusted',restricted:'Restricted',trusted:'Trusted'};
function safeExternalColor(value){const v=String(value||'').trim();return /^#[0-9a-fA-F]{6}$/.test(v)?v:'#6B7280'}
function externalNetworkBadge(item){const name=item.network_name||item.name||'Neclasificat',color=safeExternalColor(item.network_color||item.color),risk=item.network_risk_level||item.risk_level||'unknown';return `<span class="external-network-badge" style="--external-color:${color}"><i></i><span>${e(name)}</span><small>${e(externalRiskLabels[risk]||risk)}</small></span>`}
function externalRiskBadge(value){const v=String(value||'unknown');return `<span class="external-risk ${e(v)}">${e(externalRiskLabels[v]||v)}</span>`}
function externalDirectionBadge(value){const direction=String(value||'outbound');return `<span class="external-direction ${e(direction)}">${e(externalDirectionLabels[direction]||direction)}</span>`}
function externalConnectionEndpoint(item){const transport=[item.protocol||'tcp',item.port||''].filter(Boolean).join('/');return `<strong>${e(item.remote_service||'—')}</strong><div class="muted mono">${e(transport||'—')}${item.tls_enabled?' · TLS':''}</div>`}
function externalConnectionTable(values,{showSource=false,manage=false}={}){
  if(!values?.length)return empty('Nu există conexiuni externe definite.');
  const rows=values.map(item=>`<tr><td><a href="#external/${item.external_system_id}"><strong>${e(item.external_system_name)}</strong></a><div class="muted mono">${e(item.external_hostname||item.external_ip_addresses||'—')}</div>${externalNetworkBadge(item)}</td>${showSource?`<td>${item.internal_service_id?`Serviciu: <strong>${e(item.internal_service_name)}</strong>`:''}${item.internal_service_id&&item.vm_id?'<br>':''}${item.vm_id?`VM: <strong>${e(item.vm_name)}</strong>`:''}</td>`:''}<td>${externalDirectionBadge(item.direction)}</td><td>${externalConnectionEndpoint(item)}</td><td>${e(item.authentication||'—')}</td><td>${e(item.purpose||'—')}</td><td>${item.active?badge('active'):badge('disabled')}</td>${manage?`<td><button class="small danger delete-external-connection" data-id="${item.id}">Șterge</button></td>`:''}</tr>`).join('');
  return `<div class="table-wrap external-connections-table"><table><thead><tr><th>Sistem extern / rețea</th>${showSource?'<th>Sursă internă</th>':''}<th>Sens</th><th>Serviciu / port</th><th>Autentificare</th><th>Scop</th><th>Stare</th>${manage?'<th></th>':''}</tr></thead><tbody>${rows}</tbody></table></div>`;
}
function scopedExternalConnectionPanel(scopeType,scopeID,connections,systems){
  const sourceLabel=scopeType==='vm'?'VM':'serviciu intern';
  const form=can('external.manage')&&systems?.length?`<form id="scopedExternalConnectionForm" class="external-connection-form">
    <label>Sistem extern<select id="externalConnectionSystem" required><option value="">— Alege —</option>${systems.filter(x=>x.active).map(x=>`<option value="${x.id}">${e(x.name)} · ${e(x.network_name||'Neclasificat')}</option>`).join('')}</select></label>
    <label>Sens<select id="externalConnectionDirection"><option value="outbound">Ieșire → extern</option><option value="inbound">Intrare ← extern</option><option value="bidirectional">Bidirecțional ↔</option></select></label>
    <label>Serviciu destinație<input id="externalConnectionRemoteService" required placeholder="HTTPS API, SMTP, LDAP…"></label>
    <label>Protocol<input id="externalConnectionProtocol" value="tcp" placeholder="tcp"></label>
    <label>Port<input id="externalConnectionPort" type="number" min="1" max="65535" placeholder="443"></label>
    <label>Autentificare<input id="externalConnectionAuth" placeholder="mTLS, Basic, OAuth2…"></label>
    <label class="span-2">Scop<input id="externalConnectionPurpose" placeholder="De ce este necesară conexiunea"></label>
    <label class="check-inline"><input id="externalConnectionTLS" type="checkbox"> TLS</label>
    <button type="submit">Adaugă conexiune</button>
  </form>`:can('external.manage')?'<p class="muted">Definește mai întâi un sistem extern.</p>':'';
  return `<div class="external-connections-body">${form}${externalConnectionTable(connections,{manage:can('external.manage')})}<p class="muted panel-note">Sensul este privit din perspectiva infrastructurii noastre: „Ieșire” înseamnă că ${sourceLabel} inițiază conexiunea către sistemul extern.</p></div>`;
}
function bindScopedExternalConnectionActions(scopeType,scopeID,refresh){
  document.getElementById('scopedExternalConnectionForm')?.addEventListener('submit',async event=>{event.preventDefault();const portValue=document.getElementById('externalConnectionPort').value;const body={external_system_id:Number(document.getElementById('externalConnectionSystem').value),direction:document.getElementById('externalConnectionDirection').value,remote_service:document.getElementById('externalConnectionRemoteService').value.trim(),protocol:document.getElementById('externalConnectionProtocol').value.trim(),port:portValue?Number(portValue):null,tls_enabled:document.getElementById('externalConnectionTLS').checked,authentication:document.getElementById('externalConnectionAuth').value.trim(),purpose:document.getElementById('externalConnectionPurpose').value.trim()};body[scopeType==='vm'?'vm_id':'internal_service_id']=Number(scopeID);try{await api('/api/v1/external-connections',{method:'POST',body:JSON.stringify(body)});toast('Conexiunea externă a fost adăugată.');refresh()}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.delete-external-connection').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi această conexiune externă?'))return;try{await api(`/api/v1/external-connections/${button.dataset.id}`,{method:'DELETE'});toast('Conexiunea externă a fost ștearsă.');refresh()}catch(err){toast(err.message,true)}}));
}
async function fetchAllVMsForSelect(){let page=1,items=[];for(;;){const result=await api(`/api/v1/vms?page=${page}&page_size=200&retired=false`);items.push(...(result.items||[]));if(page>=Number(result.pages||1))break;page++}return items}
function externalNetworkForm(network){return `<form id="externalNetworkForm" class="external-system-form"><div class="form-grid">
  <label>Denumire<input id="externalNetworkName" required value="${e(network?.name||'')}"></label><label>Cod<input id="externalNetworkCode" value="${e(network?.code||'')}" placeholder="internet, partner_x"></label>
  <label>Culoare<div class="external-color-input"><input id="externalNetworkColor" type="color" value="${safeExternalColor(network?.color||'#6B7280')}"><input id="externalNetworkColorText" class="mono" value="${safeExternalColor(network?.color||'#6B7280')}" maxlength="7"></div></label>
  <label>Tip zonă<select id="externalNetworkZoneType">${Object.entries(externalZoneTypeLabels).map(([v,l])=>`<option value="${v}" ${(network?.zone_type||'other')===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
  <label>Nivel risc<select id="externalNetworkRisk">${Object.entries(externalRiskLabels).map(([v,l])=>`<option value="${v}" ${(network?.risk_level||'unknown')===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
  <label>Trust<select id="externalNetworkTrust">${Object.entries(externalTrustLabels).map(([v,l])=>`<option value="${v}" ${(network?.trust_level||'restricted')===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
  <label class="span-2">CIDR-uri / intervale IP<textarea id="externalNetworkCIDRs" rows="2" placeholder="203.0.113.0/24, 2001:db8::/32">${e(network?.cidrs||'')}</textarea></label>
  <label class="span-2">Organizație / proprietar<input id="externalNetworkOwner" value="${e(network?.owner_organization||'')}"></label>
  <label class="span-2">Descriere<textarea id="externalNetworkDescription" rows="3">${e(network?.description||'')}</textarea></label>
  <label class="span-2">Observații securitate<textarea id="externalNetworkSecurity" rows="3">${e(network?.security_notes||'')}</textarea></label>
  </div><div class="checks"><label><input id="externalNetworkActive" type="checkbox" ${network?.active===false?'':'checked'}> Activ</label></div><div class="form-actions"><button type="submit">${network?'Salvează rețeaua':'Adaugă rețea'}</button>${network?'<button id="cancelExternalNetworkEdit" type="button" class="secondary">Renunță</button>':''}</div></form>`}
function readExternalNetworkForm(){return {name:document.getElementById('externalNetworkName').value.trim(),code:document.getElementById('externalNetworkCode').value.trim(),color:document.getElementById('externalNetworkColorText').value.trim(),zone_type:document.getElementById('externalNetworkZoneType').value,risk_level:document.getElementById('externalNetworkRisk').value,trust_level:document.getElementById('externalNetworkTrust').value,cidrs:document.getElementById('externalNetworkCIDRs').value.trim(),owner_organization:document.getElementById('externalNetworkOwner').value.trim(),description:document.getElementById('externalNetworkDescription').value.trim(),security_notes:document.getElementById('externalNetworkSecurity').value.trim(),active:document.getElementById('externalNetworkActive').checked}}
function bindExternalNetworkForm(network){const color=document.getElementById('externalNetworkColor'),text=document.getElementById('externalNetworkColorText');color?.addEventListener('input',()=>text.value=color.value.toUpperCase());text?.addEventListener('input',()=>{if(/^#[0-9a-fA-F]{6}$/.test(text.value))color.value=text.value});document.getElementById('externalNetworkForm')?.addEventListener('submit',async event=>{event.preventDefault();try{await api(network?`/api/v1/external-networks/${network.id}`:'/api/v1/external-networks',{method:network?'PATCH':'POST',body:JSON.stringify(readExternalNetworkForm())});toast(network?'Rețeaua externă a fost actualizată.':'Rețeaua externă a fost adăugată.');state.externalNetworkEdit=0;externalSystemsPage('networks')}catch(err){toast(err.message,true)}});document.getElementById('cancelExternalNetworkEdit')?.addEventListener('click',()=>{state.externalNetworkEdit=0;externalSystemsPage('networks')})}
function externalSystemForm(system,networks){return `<form id="externalSystemForm" class="external-system-form">
  <div class="form-grid"><label>Denumire<input id="externalSystemName" required value="${e(system?.name||'')}"></label><label>Tip<select id="externalSystemType"><option value="vm" ${system?.system_type==='vm'?'selected':''}>VM extern</option><option value="server" ${system?.system_type==='server'?'selected':''}>Server extern</option><option value="endpoint" ${system?.system_type==='endpoint'?'selected':''}>Endpoint</option><option value="network_service" ${system?.system_type==='network_service'?'selected':''}>Serviciu de rețea</option></select></label><label>Rețea externă<select id="externalSystemNetwork"><option value="">Neclasificat</option>${networks.filter(n=>n.active||Number(n.id)===Number(system?.network_id)).map(n=>`<option value="${n.id}" ${Number(system?.network_id)===Number(n.id)?'selected':''}>${e(n.name)} · ${e(externalRiskLabels[n.risk_level]||n.risk_level)}</option>`).join('')}</select></label><label>Hostname / FQDN<input id="externalSystemHostname" value="${e(system?.hostname||'')}"></label><label class="span-2">IP-uri<input id="externalSystemIPs" value="${e(system?.ip_addresses||'')}" placeholder="10.10.10.5, 2001:db8::5"></label><label>Organizație / proprietar<input id="externalSystemOwner" value="${e(system?.owner_organization||'')}"></label><label>URL documentație<input id="externalSystemDocumentation" type="url" value="${e(system?.documentation_url||'')}"></label></div>
  <label>Descriere<textarea id="externalSystemDescription" rows="3">${e(system?.description||'')}</textarea></label><div class="checks"><label><input id="externalSystemActive" type="checkbox" ${system?.active===false?'':'checked'}> Activ</label></div><div class="form-actions"><button type="submit">${system?'Salvează modificările':'Adaugă sistemul'}</button></div></form>`}
function readExternalSystemForm(){const network=document.getElementById('externalSystemNetwork').value;return {name:document.getElementById('externalSystemName').value.trim(),system_type:document.getElementById('externalSystemType').value,network_id:network?Number(network):null,hostname:document.getElementById('externalSystemHostname').value.trim(),ip_addresses:document.getElementById('externalSystemIPs').value.trim(),owner_organization:document.getElementById('externalSystemOwner').value.trim(),documentation_url:document.getElementById('externalSystemDocumentation').value.trim(),description:document.getElementById('externalSystemDescription').value.trim(),active:document.getElementById('externalSystemActive').checked}}
function bindExternalSystemForm(system){document.getElementById('externalSystemForm')?.addEventListener('submit',async event=>{event.preventDefault();try{const saved=await api(system?`/api/v1/external-systems/${system.id}`:'/api/v1/external-systems',{method:system?'PATCH':'POST',body:JSON.stringify(readExternalSystemForm())});toast(system?'Sistemul extern a fost actualizat.':'Sistemul extern a fost adăugat.');location.hash=`#external/${saved.id}`;if(system)externalSystemsPage(String(saved.id))}catch(err){toast(err.message,true)}})}
function externalSourceOptions(type,services,vms){if(type==='service')return services.filter(x=>x.active).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('');return vms.filter(x=>!x.retired).map(x=>`<option value="${x.id}">${e(x.name)}${x.guest_hostname?` · ${e(x.guest_hostname)}`:''}</option>`).join('')}
async function externalSystemDetailPage(id){
  const [system,networks,services,vms]=await Promise.all([api(`/api/v1/external-systems/${id}`),api('/api/v1/external-networks?active=all'),api('/api/v1/services?include_inactive=true'),fetchAllVMsForSelect()]);pageMeta(system.name,'Sistem extern, rețea și conexiuni cu infrastructura internă');
  const connectionForm=can('external.manage')?`<form id="externalSystemConnectionForm" class="external-connection-form extended"><label>Sursă<select id="externalSourceType"><option value="service">Serviciu intern</option><option value="vm">VM specific</option></select></label><label id="externalSourceValueLabel">Serviciu intern<select id="externalSourceValue"></select></label><label>Sens<select id="externalSystemConnectionDirection"><option value="outbound">Ieșire → extern</option><option value="inbound">Intrare ← extern</option><option value="bidirectional">Bidirecțional ↔</option></select></label><label>Serviciu destinație<input id="externalSystemConnectionService" required placeholder="HTTPS API, SMTP, LDAP…"></label><label>Protocol<input id="externalSystemConnectionProtocol" value="tcp"></label><label>Port<input id="externalSystemConnectionPort" type="number" min="1" max="65535"></label><label>Autentificare<input id="externalSystemConnectionAuth"></label><label class="span-2">Scop<input id="externalSystemConnectionPurpose"></label><label class="check-inline"><input id="externalSystemConnectionTLS" type="checkbox"> TLS</label><button type="submit">Adaugă conexiune</button></form>`:'';
  content.innerHTML=`<div class="service-detail-toolbar"><a href="#external/systems" class="button-link secondary">← Înapoi la sisteme externe</a>${can('external.manage')?'<button id="deleteExternalSystem" class="danger">Șterge sistemul</button>':''}</div><div class="cards"><div class="card"><div class="label">Tip</div><div class="value compact">${e(externalTypeLabels[system.system_type]||system.system_type)}</div></div><div class="card"><div class="label">Rețea</div><div class="value compact">${externalNetworkBadge(system)}</div></div><div class="card"><div class="label">Conexiuni</div><div class="value">${system.connection_count||0}</div></div><div class="card"><div class="label">Stare</div><div class="value compact">${system.active?badge('active'):badge('disabled')}</div></div></div>${system.network_id?panel('Clasificare rețea',`<div class="detail-grid">${detail('Rețea',externalNetworkBadge(system))}${detail('Tip zonă',e(externalZoneTypeLabels[system.network_zone_type]||system.network_zone_type||'—'))}${detail('Risc',externalRiskBadge(system.network_risk_level))}${detail('Trust',e(externalTrustLabels[system.network_trust_level]||system.network_trust_level||'—'))}</div>`):''}${panel('Identificare',can('external.manage')?externalSystemForm(system,networks):`<div class="detail-grid">${detail('Denumire',e(system.name))}${detail('Hostname',e(system.hostname||'—'),true)}${detail('IP-uri',e(system.ip_addresses||'—'),true)}${detail('Organizație',e(system.owner_organization||'—'))}${detail('Rețea',externalNetworkBadge(system))}${detail('Descriere',e(system.description||'—'))}</div>`)}${panel('Conexiuni',`${connectionForm}${externalConnectionTable(system.connections,{showSource:true,manage:can('external.manage')})}`)}`;
  bindExternalSystemForm(system);const sourceType=document.getElementById('externalSourceType'),sourceValue=document.getElementById('externalSourceValue'),sourceLabel=document.getElementById('externalSourceValueLabel');const refreshSource=()=>{const type=sourceType.value;sourceLabel.firstChild.textContent=type==='service'?'Serviciu intern':'VM specific';sourceValue.innerHTML=externalSourceOptions(type,services,vms)};sourceType?.addEventListener('change',refreshSource);if(sourceType)refreshSource();
  document.getElementById('externalSystemConnectionForm')?.addEventListener('submit',async event=>{event.preventDefault();const type=sourceType.value,idValue=Number(sourceValue.value||0),port=document.getElementById('externalSystemConnectionPort').value;if(!idValue){toast('Alege sursa internă.',true);return}const body={external_system_id:Number(system.id),direction:document.getElementById('externalSystemConnectionDirection').value,remote_service:document.getElementById('externalSystemConnectionService').value.trim(),protocol:document.getElementById('externalSystemConnectionProtocol').value.trim(),port:port?Number(port):null,tls_enabled:document.getElementById('externalSystemConnectionTLS').checked,authentication:document.getElementById('externalSystemConnectionAuth').value.trim(),purpose:document.getElementById('externalSystemConnectionPurpose').value.trim()};body[type==='service'?'internal_service_id':'vm_id']=idValue;try{await api('/api/v1/external-connections',{method:'POST',body:JSON.stringify(body)});toast('Conexiunea a fost adăugată.');externalSystemDetailPage(system.id)}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.delete-external-connection').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi conexiunea?'))return;try{await api(`/api/v1/external-connections/${button.dataset.id}`,{method:'DELETE'});externalSystemDetailPage(system.id)}catch(err){toast(err.message,true)}}));document.getElementById('deleteExternalSystem')?.addEventListener('click',async()=>{if(!confirm(`Ștergi sistemul extern ${system.name} și toate conexiunile lui?`))return;try{await api(`/api/v1/external-systems/${system.id}`,{method:'DELETE'});toast('Sistemul extern a fost șters.');location.hash='#external/systems'}catch(err){toast(err.message,true)}})
}
function externalSubnav(section){return `<nav class="subnav external-subnav"><a href="#external/systems" class="${section==='systems'?'active':''}">Sisteme externe</a><a href="#external/networks" class="${section==='networks'?'active':''}">Rețele externe</a></nav>`}

async function externalSystemsPage(id=''){
  if(id&&Number(id)>0){await externalSystemDetailPage(Number(id));return}const section=id==='networks'?'networks':'systems';const [systems,networks]=await Promise.all([api('/api/v1/external-systems?active=all'),api('/api/v1/external-networks?active=all')]);pageMeta(section==='networks'?'Rețele externe':'Sisteme externe','Conectivitate către infrastructuri și servicii din afara rețelelor proprii');content.innerHTML=externalSubnav(section);if(section==='networks')await renderExternalNetworks(networks);else await renderExternalSystems(systems,networks)
}


const serviceDetailGroupsBase=[
  {code:'summary',label:'Rezumat',help:'Stare și structură',sections:[['overview','Rezumat']]},
  {code:'details',label:'Detalii',help:'Date administrate',sections:[['details','General'],['description','Descriere'],['purpose','Scop și domeniu'],['objectives','Obiective']]},
  {code:'architecture',label:'Arhitectură',help:'Medii și roluri',sections:[['environments','Medii'],['classification','Clasificare'],['diagram','Schemă']]},
  {code:'components',label:'Componente',help:'VM, DB, Docker și Web',sections:[['vms','VM-uri'],['databases','Baze de date'],['docker','Docker'],['web','Web']]},
  {code:'dependencies',label:'Dependențe',help:'Între servicii și externe',sections:[['dependencies','Între servicii'],['external','Sisteme externe']]},
  {code:'documents',label:'Documentație',help:'Fișe serviciu',sections:[['documents','Fișe și documente']]}
];
function serviceDetailGroups(service){
  const groups=[...serviceDetailGroupsBase];if(can('audit.read'))groups.push({code:'audit',label:'Audit',help:'Istoric și operații',sections:[['audit','Audit']]});return groups;
}
function serviceDetailSections(service){return serviceDetailGroups(service).flatMap(group=>group.sections)}
function serviceDetailGroupForSection(service,section){return serviceDetailGroups(service).find(group=>group.sections.some(([code])=>code===section))||serviceDetailGroups(service)[0]}
function serviceDetailNavigation(serviceID,service,selected){
  const groups=serviceDetailGroups(service),activeGroup=serviceDetailGroupForSection(service,selected);
  const primary=`<nav class="vm-detail-tabs vm-detail-primary-tabs service-detail-primary-tabs" aria-label="Zone serviciu">${groups.map(group=>{const target=group.sections[0][0];return `<a href="#services/${serviceID}/${target}" class="${activeGroup.code===group.code?'active':''}"><strong>${e(group.label)}</strong><small>${e(group.help)}</small></a>`}).join('')}</nav>`;
  const secondary=activeGroup.sections.length>1?`<nav class="vm-detail-subtabs service-detail-subtabs" aria-label="Secțiuni ${e(activeGroup.label)}">${activeGroup.sections.map(([code,label])=>`<a href="#services/${serviceID}/${code}" class="${selected===code?'active':''}">${e(label)}</a>`).join('')}</nav>`:'';
  return `<div class="vm-detail-navigation service-detail-navigation">${primary}${secondary}</div>`;
}
function serviceUpdateBody(service,changes={}){
  const base={name:service.name||'',service_code:service.service_code||'',short_description:service.short_description||'',authentication:service.authentication||'',service_url:service.service_url||'',technologies:service.technologies||'',description:service.description||'',description_richtext:normalizeRichTextDocument(service.description_richtext,service.description||''),purpose:service.purpose||'',purpose_richtext:normalizeRichTextDocument(service.purpose_richtext,service.purpose||''),objectives:service.objectives||'',objectives_richtext:normalizeRichTextDocument(service.objectives_richtext,service.objectives||''),criticality:service.criticality||'normal',documentation_status:service.documentation_status||'draft',documentation_url:service.documentation_url||'',active:service.active!==false,is_common:!!service.is_common,implicit_global:!!service.implicit_global,common_dependency_type_id:service.common_dependency_type_id?Number(service.common_dependency_type_id):null};return {...base,...changes}
}
function serviceGeneralPanel(service,categories){
  if(!can('services.manage'))return panel('Date generale',`<div class="detail-grid">${detail('Denumire',e(service.name))}${detail('Cod intern',e(service.service_code||'—'),true)}${detail('Descriere scurtă',e(service.short_description||'—'))}${detail('Autentificare',e(service.authentication||'—'))}${detail('Link serviciu',service.service_url?`<a href="${e(service.service_url)}" target="_blank" rel="noopener">${e(service.service_url)}</a>`:'—')}${detail('Tehnologii folosite',e(service.technologies||'—'))}${detail('Criticitate',criticalityLabels[service.criticality]||e(service.criticality))}${detail('Status documentație',documentationStatusLabels[service.documentation_status]||e(service.documentation_status))}${detail('Activ',service.active?badge('active'):badge('disabled'))}${detail('Tip serviciu',service.is_common?(service.implicit_global?badge('global'):badge('common')):'Serviciu aplicație')}${detail('Tip dependență implicit',e(service.common_dependency_type||'—'))}${detail('Documentație existentă',service.documentation_url?`<a href="${e(service.documentation_url)}" target="_blank" rel="noopener">${e(service.documentation_url)}</a>`:'—')}${detail('Ultima actualizare',dt(service.updated_at))}</div>`);
  const types=categoryItems(categories,'dependency_type');
  return panel('Date generale',`<form id="serviceGeneralForm" class="operational-form service-inline-form"><div class="form-section"><h3>Identificare și stare</h3><div class="form-grid"><label>Denumire<input id="serviceDetailName" required value="${e(service.name||'')}"></label><label>Cod intern<input id="serviceDetailCode" value="${e(service.service_code||'')}" placeholder="ex. bi.metabase"></label><label class="span-2">Descriere scurtă<textarea id="serviceDetailShortDescription" rows="2" maxlength="2000" placeholder="Rezumat scurt pentru identificarea serviciului">${e(service.short_description||'')}</textarea></label><label class="span-2">Autentificare<textarea id="serviceDetailAuthentication" rows="2" maxlength="4000" placeholder="ex. OIDC prin Keycloak, LDAP/AD">${e(service.authentication||'')}</textarea></label><label class="span-2">Link serviciu<input id="serviceDetailServiceURL" type="url" value="${e(service.service_url||'')}" placeholder="https://..."></label><label class="span-2">Tehnologii folosite<textarea id="serviceDetailTechnologies" rows="3" maxlength="10000" placeholder="ex. Java 17, PostgreSQL, Nginx">${e(service.technologies||'')}</textarea></label><label>Criticitate<select id="serviceDetailCriticality">${Object.entries(criticalityLabels).map(([v,l])=>`<option value="${v}" ${service.criticality===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label>Status documentație<select id="serviceDetailDocStatus">${Object.entries(documentationStatusLabels).map(([v,l])=>`<option value="${v}" ${service.documentation_status===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label class="span-2">Link documentație<input id="serviceDetailDocumentationURL" type="url" value="${e(service.documentation_url||'')}" placeholder="https://..."></label></div></div><div class="form-section"><h3>Tip serviciu</h3><div class="form-grid common-service-config"><label>Tip dependență implicit pentru serviciul comun<select id="serviceDetailCommonDependencyType"><option value="">— Alege tipul dependenței —</option>${selectOptions(types,service.common_dependency_type_id,'— Alege tipul dependenței —').replace('<option value="">— Alege tipul dependenței —</option>','')}</select><small>Exemple: DNS / Name resolution, Directory / Identity, NTP / Time.</small></label></div><div class="checks"><label><input id="serviceDetailActive" type="checkbox" ${service.active?'checked':''}> Activ</label><label><input id="serviceDetailCommon" type="checkbox" ${service.is_common?'checked':''}> Serviciu comun / infrastructură partajată</label><label><input id="serviceDetailImplicitGlobal" type="checkbox" ${service.implicit_global?'checked':''}> Global implicit pentru toate serviciile</label></div></div><div class="form-actions"><button type="submit">Salvează datele generale</button></div></form>`)
}
function serviceDescriptionPanel(service){const title='Descriere detaliată',editorID='serviceDetailDescriptionRich';if(!can('services.manage'))return panel(title,`<div class="service-text-block service-single-narrative"><section>${richTextView(service.description_richtext,service.description||'')}</section></div>`);return panel(title,`<form id="serviceDescriptionForm" class="operational-form service-inline-form"><div class="form-section">${richTextEditorHTML(editorID,title,'Descriere funcțională și tehnică a serviciului, structurată pe paragrafe și liste.') }<small>Descrierea formatată este folosită în fișa tehnică și operațională a serviciului.</small></div><div class="form-actions"><button type="submit">Salvează descrierea</button></div></form>`)}
function serviceRichDetailPanel(service,kind){const purpose=kind==='purpose',title=purpose?'Scop și domeniu':'Obiective',editorID=purpose?'serviceDetailPurposeRich':'serviceDetailObjectivesRich',placeholder=purpose?'Descrie scopul serviciului, aria funcțională acoperită, utilizatorii/beneficiarii și limitele serviciului.':'Descrie rezultatele urmărite, obiectivele operaționale și criteriile principale de succes.',value=purpose?service.purpose_richtext:service.objectives_richtext,fallback=purpose?service.purpose:service.objectives;if(!can('services.manage'))return panel(title,`<div class="service-text-block service-single-narrative"><section>${richTextView(value,fallback||'')}</section></div>`);return panel(title,`<form id="${purpose?'servicePurposeForm':'serviceObjectivesForm'}" class="operational-form service-inline-form"><div class="form-section">${richTextEditorHTML(editorID,title,placeholder)}</div><div class="form-actions"><button type="submit">Salvează ${purpose?'scopul și domeniul':'obiectivele'}</button></div></form>`)}
function syncServiceGeneralCommon(){const common=document.getElementById('serviceDetailCommon'),global=document.getElementById('serviceDetailImplicitGlobal'),type=document.getElementById('serviceDetailCommonDependencyType');if(!common||!global||!type)return;if(global.checked)common.checked=true;if(!common.checked){global.checked=false;type.value=''}type.disabled=!common.checked;refreshSearchableSelect(type)}
async function saveServiceInline(service,changes,section){try{const saved=await api(`/api/v1/services/${service.id}`,{method:'PATCH',body:JSON.stringify(serviceUpdateBody(service,changes))});toast('Serviciul a fost actualizat.');internalServiceDetail(saved.id,section)}catch(err){toast(err.message,true)}}
function bindServiceInlineDetail(service,section){
  if(section==='details'){
    syncServiceGeneralCommon();document.getElementById('serviceDetailCommon')?.addEventListener('change',syncServiceGeneralCommon);document.getElementById('serviceDetailImplicitGlobal')?.addEventListener('change',syncServiceGeneralCommon);
    document.getElementById('serviceGeneralForm')?.addEventListener('submit',event=>{event.preventDefault();const isCommon=document.getElementById('serviceDetailCommon').checked,implicit=document.getElementById('serviceDetailImplicitGlobal').checked,typeValue=document.getElementById('serviceDetailCommonDependencyType').value;if((isCommon||implicit)&&!typeValue){toast('Alege tipul dependenței pentru serviciul comun.',true);return}saveServiceInline(service,{name:document.getElementById('serviceDetailName').value.trim(),service_code:document.getElementById('serviceDetailCode').value.trim(),short_description:document.getElementById('serviceDetailShortDescription').value.trim(),authentication:document.getElementById('serviceDetailAuthentication').value.trim(),service_url:document.getElementById('serviceDetailServiceURL').value.trim(),technologies:document.getElementById('serviceDetailTechnologies').value.trim(),criticality:document.getElementById('serviceDetailCriticality').value,documentation_status:document.getElementById('serviceDetailDocStatus').value,documentation_url:document.getElementById('serviceDetailDocumentationURL').value.trim(),active:document.getElementById('serviceDetailActive').checked,is_common:isCommon||implicit,implicit_global:implicit,common_dependency_type_id:typeValue?Number(typeValue):null},'details')});
  }
  if(section==='description'){setRichTextEditor('serviceDetailDescriptionRich',service.description_richtext,service.description||'');bindRichTextToolbars();document.getElementById('serviceDescriptionForm')?.addEventListener('submit',event=>{event.preventDefault();const rich=richTextDocumentFromEditor('serviceDetailDescriptionRich');saveServiceInline(service,{description:richTextPlain(rich),description_richtext:rich},'description')})}
  if(section==='purpose'){setRichTextEditor('serviceDetailPurposeRich',service.purpose_richtext,service.purpose||'');bindRichTextToolbars();document.getElementById('servicePurposeForm')?.addEventListener('submit',event=>{event.preventDefault();const rich=richTextDocumentFromEditor('serviceDetailPurposeRich');saveServiceInline(service,{purpose:richTextPlain(rich),purpose_richtext:rich},'purpose')})}
  if(section==='objectives'){setRichTextEditor('serviceDetailObjectivesRich',service.objectives_richtext,service.objectives||'');bindRichTextToolbars();document.getElementById('serviceObjectivesForm')?.addEventListener('submit',event=>{event.preventDefault();const rich=richTextDocumentFromEditor('serviceDetailObjectivesRich');saveServiceInline(service,{objectives:richTextPlain(rich),objectives_richtext:rich},'objectives')})}
}

function serviceImpactSummary(impact){
  const parts=[];if(Number(impact?.vm_assignments||0))parts.push(`${impact.vm_assignments} asocieri VM`);if(Number(impact?.docker_assignments||0))parts.push(`${impact.docker_assignments} Docker`);if(Number(impact?.database_instances||0)+Number(impact?.database_catalogs||0))parts.push(`${Number(impact.database_instances||0)+Number(impact.database_catalogs||0)} DB`);if(Number(impact?.web_sites||0))parts.push(`${impact.web_sites} Web/LB`);if(Number(impact?.outgoing_dependencies||0)+Number(impact?.incoming_dependencies||0)+Number(impact?.vm_dependencies||0))parts.push(`${Number(impact.outgoing_dependencies||0)+Number(impact.incoming_dependencies||0)+Number(impact.vm_dependencies||0)} dependențe`);if(Number(impact?.generated_documents||0))parts.push(`${impact.generated_documents} documente`);if(Number(impact?.attachments||0))parts.push(`${impact.attachments} anexe`);return parts.join(', ')||'fără asocieri dependente';
}
function serviceAdministrationPanel(service,allServices){
  if(!can('services.manage'))return '';
  if(service.implicit_global)return panel('Administrare proiect / serviciu',`<div class="notice warning"><strong>Serviciu global implicit protejat.</strong><p>Dezactivează mai întâi opțiunea Global implicit dacă vrei să îl comasezi sau să îl ștergi.</p></div>`);
  const targets=(allServices||[]).filter(item=>Number(item.id)!==Number(service.id)&&item.active!==false).map(item=>`<option value="${item.id}">${e(item.name)}</option>`).join('');
  return panel('Administrare proiect / serviciu',`<p class="muted">Folosește <strong>Comasează</strong> când ai creat proiecte separate și vrei să le concentrezi într-un proiect mai mare. Asocierile tehnice, VM-urile, dependențele, documentele și anexele sunt mutate în proiectul destinație.</p><div class="service-management-actions"><label>Comasează în<select id="serviceMergeTarget"><option value="">— Alege proiectul destinație —</option>${targets}</select></label><button id="mergeInternalService" type="button" class="secondary" ${targets?'':'disabled'}>Comasează proiectul</button><button id="deleteInternalService" type="button" class="danger">Șterge definitiv</button></div>`,'<span class="muted">Ștergerea este permanentă. Comasarea păstrează proiectul destinație ca sursă principală.</span>');
}

async function internalServiceDetail(id,requestedSection=''){
  const [service,documentTemplates,generatedDocuments,serviceAttachments,diagramNomenclatures,allServices,externalSystems,externalConnections]=await Promise.all([api(`/api/v1/services/${id}`),can('documents.read')?api('/api/v1/document-templates?object_type=service'):Promise.resolve([]),can('documents.read')?api(`/api/v1/services/${id}/documents`):Promise.resolve([]),can('documents.read')?api(`/api/v1/services/${id}/attachments`):Promise.resolve([]),api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/services?include_inactive=true'),can('external.read')?api('/api/v1/external-systems?active=active'):Promise.resolve([]),can('external.read')?api(`/api/v1/external-connections?service_id=${id}`):Promise.resolve([])]);nomenclatureCache=diagramNomenclatures;internalServicesCache=allServices;
  const hashParts=(location.hash||'').slice(1).split('/');const hashSection=hashParts[0]==='services'&&Number(hashParts[1])===Number(id)?hashParts[2]:'';
  const sections=serviceDetailSections(service),candidate=requestedSection||hashSection||'overview',selectedSection=sections.some(([code])=>code===candidate)?candidate:'overview';if(candidate!==selectedSection)history.replaceState(null,'',`#services/${id}/${selectedSection}`);
  const sectionLabel=sections.find(([code])=>code===selectedSection)?.[1]||'Rezumat';
  const vmRows=serviceVMRows(service.vms);
  const serviceDocumentPanel=can('documents.read')?`${serviceDocumentsPanel(id,documentTemplates,generatedDocuments)}${serviceSupplementalDocumentsPanel(id,serviceAttachments)}`:empty('Nu ai acces la documentele serviciului.');
  pageMeta(service.name,`${sectionLabel} · serviciu intern`);

  const summarySection=`${panel('Serviciu pe scurt',`<div class="detail-grid">${detail('Serviciu intern',e(service.name))}${detail('Cod intern',e(service.service_code||'—'),true)}${detail('Stare',service.active?badge('active'):badge('disabled'))}${detail('Tip',service.is_common?(service.implicit_global?badge('global'):badge('common')):'Serviciu aplicație')}${detail('Documentație',documentationStatusLabels[service.documentation_status]||e(service.documentation_status))}${detail('Ultima actualizare',dt(service.updated_at))}</div><div class="service-summary-description"><strong>Descriere scurtă</strong><p>${e(service.short_description||'—')}</p></div>`)}${panel('Încadrare pe medii',serviceEnvironmentPanel(service.vms))}${panel('Încadrare arhitecturală',`<div class="service-summary-two-column"><section><h3>Domenii / categorii</h3>${serviceClassificationSummary(service.classifications)}</section><section><h3>Tipuri de soluție</h3>${serviceSolutionSummary(service.solution_types)}</section></div>`)}${serviceDependencyStrip(service)}${serviceAdministrationPanel(service,allServices)}`;
  const detailsSection=serviceGeneralPanel(service,diagramNomenclatures);
  const descriptionSection=serviceDescriptionPanel(service);
  const purposeSection=serviceRichDetailPanel(service,'purpose');
  const objectivesSection=serviceRichDetailPanel(service,'objectives');
  const environmentsSection=panel('Încadrare pe medii',serviceEnvironmentPanel(service.vms));
  const classificationSection=`${panel('Domenii și categorii observate automat',`<p class="muted service-observed-note">Încadrarea este calculată exclusiv din fișele VM asociate serviciului.</p>${observedServiceClassifications(service.classifications)}`)}${panel('Tipuri de soluție observate automat',`<p class="muted service-observed-note">Open source, dezvoltată intern sau comercială, conform alegerii făcute pe fiecare asociere VM.</p>${observedServiceSolutionTypes(service.solution_types)}`)}${panel('Layer-e și roluri tehnice observate automat',`<p class="muted service-observed-note">Această vedere este calculată din asocierile VM-urilor. Nu se configurează manual la nivelul serviciului.</p>${observedServiceRoles(service.role_mappings)}`)}`;
  const diagramSection=panel('Schemă serviciu',serviceDiagram(service,diagramNomenclatures));
  const vmsSection=panel('VM-uri asociate',vmRows?`<div class="table-wrap"><table><thead><tr><th>VM</th><th>Mediu</th><th>IP</th><th>Domeniu / Categorie</th><th>Layer / Rol</th><th>Tip soluție</th><th>Utilizare</th><th>Fișă VM</th><th></th><th>Power state</th></tr></thead><tbody>${vmRows}</tbody></table></div>`:empty('Niciun VM nu este asociat încă acestui serviciu. Asocierea se face din fișa VM.'));
  const databasesSection=panel('Baze de date asociate',serviceDatabasePanel(service.database_resources,service.id),'<span class="muted">Bazele pot fi găzduite pe VM-uri partajate și sunt asociate independent de VM</span>');
  const dockerSection=panel('Containere Docker asociate',serviceDockerPanel(service.docker_containers,service.id),'<span class="muted">Containerele pot fi găzduite pe VM-uri partajate care nu aparțin exclusiv acestui serviciu</span>');
  const webSection=panel('Site-uri web asociate',serviceWebPanel(service.web_sites,service.id),'<span class="muted">Site-urile Nginx/Apache și frontend-urile HAProxy pot fi găzduite pe VM-uri partajate și sunt asociate independent de VM</span>');
  const dependenciesSection=panel('Dependențe între servicii',`${serviceDependenciesPanel(service,allServices,diagramNomenclatures)}${serviceDependentsPanel(service)}`,service.is_common?'<span class="common-service-pill">Serviciu comun disponibil și pentru dependențe VM</span>':'<span class="muted">Orice serviciu activ poate fi sursă sau destinație a unei dependențe.</span>');
  const externalSection=can('external.read')?panel('Conexiuni către sisteme externe',scopedExternalConnectionPanel('service',id,externalConnections,externalSystems),'<a class="button-link small secondary" href="#external">Sisteme externe</a>'):empty('Nu ai acces la conexiunile externe.');
  const auditSection='<div id="scopedAuditRoot" class="loading">Se încarcă auditul serviciului…</div>';
  const sectionBodies={overview:summarySection,details:detailsSection,description:descriptionSection,purpose:purposeSection,objectives:objectivesSection,environments:environmentsSection,classification:classificationSection,diagram:diagramSection,vms:vmsSection,databases:databasesSection,docker:dockerSection,web:webSection,dependencies:dependenciesSection,external:externalSection,documents:serviceDocumentPanel,audit:auditSection};

  content.innerHTML=`<div class="service-detail-toolbar"><a href="#services" class="button-link secondary">← Înapoi la servicii</a><span class="service-detail-context">${e(sectionLabel)}</span></div>${serviceTopCards(service)}${serviceDetailNavigation(id,service,selectedSection)}<div class="service-detail-workspace">${sectionBodies[selectedSection]||summarySection}</div>`;
  bindServiceInlineDetail(service,selectedSection);
  if(selectedSection==='documents'){bindServiceDocumentActions(id);bindServiceSupplementalActions(id);}
  if(selectedSection==='dependencies')bindServiceDependencyActions(id);
  if(selectedSection==='external'&&can('external.read'))bindScopedExternalConnectionActions('service',id,()=>internalServiceDetail(id,'external'));
  if(selectedSection==='audit'&&can('audit.read'))await scopedAuditPage('service',id);
  document.getElementById('mergeInternalService')?.addEventListener('click',async()=>{const targetID=Number(document.getElementById('serviceMergeTarget')?.value||0);if(!targetID){toast('Alege proiectul destinație.',true);return}const target=allServices.find(item=>Number(item.id)===targetID);try{const impact=await api(`/api/v1/services/${id}/delete-impact`);if(!confirm(`Comasezi „${service.name}” în „${target?.name||targetID}”?\n\nSe vor muta: ${serviceImpactSummary(impact)}.\nProiectul „${service.name}” va fi șters la final.`))return;await api(`/api/v1/services/${id}/merge`,{method:'POST',body:JSON.stringify({target_service_id:targetID})});toast('Proiectele au fost comasate.');location.hash=`#services/${targetID}/overview`}catch(err){toast(err.message,true)}});
  document.getElementById('deleteInternalService')?.addEventListener('click',async()=>{try{const impact=await api(`/api/v1/services/${id}/delete-impact`);const related=serviceImpactSummary(impact);if(!confirm(`Ștergi definitiv proiectul „${service.name}”?\n\nImpact: ${related}.\nAceastă operație nu poate fi anulată.`))return;await api(`/api/v1/services/${id}`,{method:'DELETE'});toast('Proiectul a fost șters definitiv.');location.hash='#services'}catch(err){toast(err.message,true)}});
}

internalServiceForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('services.manage'))return;
  const id=Number(document.getElementById('internalServiceId').value||0);
  const descriptionRichText=richTextDocumentFromEditor('internalServiceDescriptionRich');const purposeRichText=richTextDocumentFromEditor('internalServicePurposeRich');const objectivesRichText=richTextDocumentFromEditor('internalServiceObjectivesRich');
  const isCommon=document.getElementById('internalServiceCommon').checked,implicitGlobal=document.getElementById('internalServiceImplicitGlobal').checked,commonTypeValue=document.getElementById('internalServiceCommonDependencyType').value;
  if((isCommon||implicitGlobal)&&!commonTypeValue){toast('Alege tipul dependenței pentru serviciul comun.',true);return}
  const body={name:document.getElementById('internalServiceName').value.trim(),service_code:document.getElementById('internalServiceCode').value.trim(),short_description:document.getElementById('internalServiceShortDescription').value.trim(),authentication:document.getElementById('internalServiceAuthentication').value.trim(),service_url:document.getElementById('internalServiceURL').value.trim(),technologies:document.getElementById('internalServiceTechnologies').value.trim(),criticality:document.getElementById('internalServiceCriticality').value,documentation_status:document.getElementById('internalServiceDocStatus').value,description:richTextPlain(descriptionRichText),description_richtext:descriptionRichText,purpose:richTextPlain(purposeRichText),purpose_richtext:purposeRichText,objectives:richTextPlain(objectivesRichText),objectives_richtext:objectivesRichText,documentation_url:document.getElementById('internalServiceDocumentationURL').value.trim(),active:document.getElementById('internalServiceActive').checked,is_common:isCommon||implicitGlobal,implicit_global:implicitGlobal,common_dependency_type_id:commonTypeValue?Number(commonTypeValue):null};
  try{const saved=await api(id?`/api/v1/services/${id}`:'/api/v1/services',{method:id?'PATCH':'POST',body:JSON.stringify(body)});internalServiceDialog.close();toast(id?'Serviciu actualizat.':'Serviciu creat.');const parts=(location.hash||'').slice(1).split('/'),section=id&&parts[0]==='services'&&Number(parts[1])===id?(parts[2]||'details'):'details',target=`#services/${saved.id}/${section}`;if(location.hash===target)internalServiceDetail(saved.id,section);else location.hash=target}catch(err){toast(err.message,true)}
});

function syncCommonServiceForm(){
  const common=document.getElementById('internalServiceCommon'),global=document.getElementById('internalServiceImplicitGlobal'),type=document.getElementById('internalServiceCommonDependencyType');if(!common||!global||!type)return;
  if(global.checked)common.checked=true;
  if(!common.checked){global.checked=false;type.value=''}
  type.disabled=!common.checked;
}
document.getElementById('internalServiceCommon')?.addEventListener('change',syncCommonServiceForm);
document.getElementById('internalServiceImplicitGlobal')?.addEventListener('change',syncCommonServiceForm);

let nomenclatureCache=[];
let peopleCache=[];
let directoryDepartmentCache=null;
let directoryUsersCache=[];
function updateNomenclatureParent(selected=[]){
  const category=document.getElementById('nomenclatureCategory').value;
  const parentLabel=document.getElementById('nomenclatureParentLabel');
  const parentText=document.getElementById('nomenclatureParentText');
  const parentHelp=document.getElementById('nomenclatureParentHelp');
  const orderText=document.getElementById('nomenclatureOrderText');
  const orderHelp=document.getElementById('nomenclatureOrderHelp');
  const parent=document.getElementById('nomenclatureParent');
  const isServiceCategory=category==='itil_category';
  const isTechnicalRole=category==='technical_role';
  destroyEnhancedMultiSelect(parent);
  parentLabel.hidden=!(isServiceCategory||isTechnicalRole);
  parent.required=isServiceCategory;
  parent.multiple=isTechnicalRole;
  parent.removeAttribute('size');
  orderText.textContent=isTechnicalRole?'Ordine în layer':'Ordine';
  orderHelp.textContent=isTechnicalRole?'Rolurile sunt afișate după ordinea layer-ului, apoi după această valoare.':'';
  if(isServiceCategory){
    parentText.textContent='Domeniu arhitectural';
    parentHelp.textContent='Categoria de serviciu aparține unui singur domeniu arhitectural.';
    const domains=sortNomenclatureValues(categoryItems(nomenclatureCache,'architectural_domain'));
    parent.innerHTML=selectOptions(domains,Array.isArray(selected)?selected[0]:selected,'— Alege domeniul arhitectural —');
  }else if(isTechnicalRole){
    parentText.textContent='Layer-e permise';
    parentHelp.textContent='Selectează unul sau mai multe layer-e. Rolul va fi disponibil numai în layer-ele alese.';
    const layers=sortNomenclatureValues(categoryItems(nomenclatureCache,'layer'));
    parent.innerHTML=multiSelectOptions(layers,Array.isArray(selected)?selected:[]);
    enhanceMultiSelect(parent,{placeholder:'Alege layer-ele'});
  }else{
    parentText.textContent='Relație';
    parentHelp.textContent='';
    parent.innerHTML='<option value="">— Nu se aplică —</option>';
  }
}
function openNomenclature(item=null,categoryCode='architectural_domain'){
  const selectedCategory=item?.category_code||categoryCode;
  const categoryOptions=nomenclatureCache.map(category=>`<option value="${e(category.code)}" ${selectedCategory===category.code?'selected':''}>${e(category.label)}</option>`).join('');
  document.getElementById('nomenclatureDialogTitle').textContent=item?'Editare valoare':'Valoare nouă';
  document.getElementById('nomenclatureId').value=item?.id||'';
  const category=document.getElementById('nomenclatureCategory');
  category.innerHTML=categoryOptions;
  category.disabled=Boolean(item);
  document.getElementById('nomenclatureName').value=item?.name||'';
  document.getElementById('nomenclatureCode').value=item?.item_code||'';
  document.getElementById('nomenclatureIcon').value=item?.icon_key||'';
  document.getElementById('nomenclatureDescription').value=item?.description||'';
  document.getElementById('nomenclatureOrder').value=item?.sort_order??0;
  document.getElementById('nomenclatureActive').checked=item?.active??true;
  updateNomenclatureParent(selectedCategory==='technical_role'?(item?.layer_ids||[]):(item?.parent_id||''));
  nomenclatureDialog.showModal();
}
document.getElementById('nomenclatureCategory').addEventListener('change',()=>updateNomenclatureParent([]));
function openPerson(person=null){
  document.getElementById('personDialogTitle').textContent=person?'Editare persoană':'Persoană nouă';
  document.getElementById('personId').value=person?.id||'';
  document.getElementById('personName').value=person?.display_name||'';
  document.getElementById('personEmail').value=person?.email||'';
  document.getElementById('personPhone').value=person?.phone||'';
  document.getElementById('personDepartment').value=person?.department||'';
  document.getElementById('personActive').checked=person?.active??true;
  personDialog.showModal();
}
const nomenclatureNavigationGroups=[
  {label:'Catalog servicii',codes:['architectural_domain','itil_category']},
  {label:'Arhitectură tehnică',codes:['layer','technical_role','solution_type']},
  {label:'Dependențe între servicii',codes:['dependency_type']},
  {label:'Operare VM',codes:['environment','operational_status','classification']},
  {label:'Responsabilități',codes:['people']}
];
const nomenclatureDescriptions={
  architectural_domain:'Domeniile arhitecturale grupează categoriile de serviciu și serviciile interne.',
  itil_category:'Categoriile de serviciu aparțin unui domeniu arhitectural și grupează serviciile interne.',
  layer:'Layer-ele descriu zona arhitecturală în care o VM îndeplinește o funcție.',
  technical_role:'Rolurile tehnice sunt legate de layer-ele în care pot fi selectate.',
  solution_type:'Tipul soluției indică natura tehnologiei folosite de o asociere VM–serviciu: open source, dezvoltată intern sau comercială.',
  dependency_type:'Tipurile de dependență descriu relația dintre două servicii: autentificare, DNS, baze de date, API, mesagerie, storage, backup și altele.',
  environment:'Mediile separă utilizarea VM-urilor, de exemplu producție, test sau dezvoltare.',
  operational_status:'Statusurile operaționale descriu starea curentă a unei VM în exploatare.',
  classification:'Clasificările permit marcarea nivelului sau tipului de informație gestionată.',
  people:'Registrul persoanelor care pot primi responsabilități pe fișele VM.'
};
function nomenclatureFilterState(code){
  if(!state.nomenclatureFilters[code])state.nomenclatureFilters[code]={q:'',status:'all',parent:'',layer:'',department:'',source:''};
  return state.nomenclatureFilters[code];
}
function normalizedFilterText(value){return String(value||'').trim().toLocaleLowerCase('ro-RO')}
function nomenclatureValueMatches(item,categoryCode,filter){
  if(filter.status==='active'&&!item.active)return false;
  if(filter.status==='inactive'&&item.active)return false;
  if(categoryCode==='itil_category'&&filter.parent&&Number(item.parent_id)!==Number(filter.parent))return false;
  if(categoryCode==='technical_role'&&filter.layer&&!(item.layer_ids||[]).some(id=>Number(id)===Number(filter.layer)))return false;
  const query=normalizedFilterText(filter.q);
  if(!query)return true;
  const haystack=[item.name,item.item_code,item.icon_key,item.description,item.parent_name,...(item.layer_names||[])].join(' ').toLocaleLowerCase('ro-RO');
  return haystack.includes(query);
}
function nomenclatureFilterForm(category,visibleCount,totalCount,pageSize){
  const filter=nomenclatureFilterState(category.code);
  const parentField=category.code==='itil_category'?`<label>Domeniu arhitectural<select name="parent"><option value="">Toate domeniile</option>${sortNomenclatureValues(categoryItems(nomenclatureCache,'architectural_domain')).map(item=>`<option value="${item.id}" ${String(filter.parent)===String(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}</select></label>`:'';
  const layerField=category.code==='technical_role'?`<label>Layer<select name="layer"><option value="">Toate layer-ele</option>${sortNomenclatureValues(categoryItems(nomenclatureCache,'layer')).map(item=>`<option value="${item.id}" ${String(filter.layer)===String(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}</select></label>`:'';
  return `<form id="nomenclatureFilters" class="nomenclature-filters">
    <label class="nomenclature-filter-search">Caută<input name="q" type="search" value="${e(filter.q)}" placeholder="Denumire, cod sau descriere"></label>
    ${parentField}${layerField}
    <label>Stare<select name="status"><option value="all" ${filter.status==='all'?'selected':''}>Toate</option><option value="active" ${filter.status==='active'?'selected':''}>Active</option><option value="inactive" ${filter.status==='inactive'?'selected':''}>Inactive</option></select></label>
    <label>Pe pagină<select name="page_size" id="nomenclatureTopPageSize">${pageSizeOptions(pageSize,[10,20,50,100,200])}</select></label>
    <div class="nomenclature-filter-actions"><button type="submit" class="small">Aplică filtre</button><button type="button" id="clearNomenclatureFilters" class="small secondary">Resetează</button></div>
    <span class="nomenclature-filter-summary">${visibleCount.toLocaleString('ro-RO')} rezultate din ${totalCount.toLocaleString('ro-RO')}</span>
  </form>`;
}
function nomenclaturePanel(category){
  const hasParent=category.code==='itil_category';
  const hasLayerLinks=category.code==='technical_role';
  const relationHead=hasParent?'<th>Domeniu arhitectural</th>':hasLayerLinks?'<th>Layer-e permise</th>':'';
  const head=`<tr><th>Denumire</th>${relationHead}<th>Cod</th><th>Pictogramă</th><th>Ordine</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  const filter=nomenclatureFilterState(category.code);
  const filteredItems=category.items.filter(item=>nomenclatureValueMatches(item,category.code,filter));
  const info=nomenclaturePageInfo(category.code,filteredItems.length);
  const visibleItems=filteredItems.slice(info.offset,info.end);
  const rows=visibleItems.map(item=>{
    const relation=hasParent?`<td>${e(item.parent_name||'—')}</td>`:hasLayerLinks?`<td>${item.layer_names?.length?e(item.layer_names.join(', ')):'<span class="muted">Nemapate</span>'}</td>`:'';
    return `<tr><td><strong>${e(item.name)}</strong>${item.description?`<div class="muted">${e(item.description)}</div>`:''}</td>${relation}<td class="mono">${e(item.item_code||'—')}</td><td>${nomenclatureIcon(item.icon_key,'small')} <span class="muted mono">${e(item.icon_key||'—')}</span></td><td>${item.sort_order}</td><td>${item.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-nomenclature" data-id="${item.id}">Editează</button></td>`:''}</tr>`;
  }).join('');
  const result=rows?`<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>${nomenclaturePagination(category.code,info)}`:empty(category.items.length?'Nu există valori pentru filtrele selectate.':'Nu există valori definite.');
  const body=`${nomenclatureFilterForm(category,filteredItems.length,category.items.length,info.pageSize)}${result}`;
  const tools=`<a class="button-link small secondary" href="/api/v1/nomenclatures/export?category=${encodeURIComponent(category.code)}&include_inactive=true">Export Excel</a>${can('nomenclatures.manage')?`<button class="small add-nomenclature" data-category="${e(category.code)}">Adaugă</button>`:''}`;
  return panel(e(category.label),body,tools);
}
async function loadDirectoryDepartments(force=false){
  if(directoryDepartmentCache&&!force)return directoryDepartmentCache;
  try{directoryDepartmentCache=await api('/api/v1/directory/departments')}
  catch(err){directoryDepartmentCache={enabled:false,departments:[],default_department:'',error:err.message}}
  return directoryDepartmentCache;
}
function directoryUserMatches(user,query){
  if(!query)return true;
  const haystack=[user.display_name,user.username,user.email,user.department,...(user.ou_path||[])].join(' ').toLocaleLowerCase('ro-RO');
  return haystack.includes(query.toLocaleLowerCase('ro-RO'));
}
function directoryUserRow(user){
  const imported=peopleCache.some(person=>person.source==='ldap'&&person.directory_username&&String(person.directory_username).toLocaleLowerCase('ro-RO')===String(user.username||'').toLocaleLowerCase('ro-RO'));
  return `<label class="directory-user"><input type="checkbox" class="directory-user-check" value="${e(user.distinguished_name)}"><span><strong>${e(user.display_name||user.username)}</strong><small>${e(user.username||'')}${user.email?` · ${e(user.email)}`:''}</small></span>${imported?'<em>importat</em>':''}</label>`;
}
function directoryTreeHTML(users){
  const root={children:new Map(),users:[]};
  for(const user of users){let node=root;for(const segment of (user.ou_path||[])){if(!node.children.has(segment))node.children.set(segment,{children:new Map(),users:[]});node=node.children.get(segment)}node.users.push(user)}
  const renderNode=(name,node,rootNode=false)=>{
    const childHTML=[...node.children.entries()].sort((a,b)=>a[0].localeCompare(b[0],'ro')).map(([childName,child])=>renderNode(childName,child)).join('');
    const userHTML=node.users.map(directoryUserRow).join('');
    const body=`${userHTML}${childHTML}`||'<div class="directory-empty muted">Fără utilizatori</div>';
    if(rootNode)return body;
    const count=(node.users?.length||0)+[...node.children.values()].reduce((sum,child)=>sum+directoryNodeCount(child),0);
    return `<details class="directory-ou" open><summary><span>${e(name)}</span><b>${count}</b></summary><div>${body}</div></details>`;
  };
  return renderNode('',root,true);
}
function directoryNodeCount(node){return (node.users?.length||0)+[...(node.children?.values?.()||[])].reduce((sum,child)=>sum+directoryNodeCount(child),0)}
function renderDirectoryUsers(){
  const query=document.getElementById('directorySearch').value.trim();
  const visible=directoryUsersCache.filter(user=>directoryUserMatches(user,query));
  document.getElementById('directorySummary').textContent=`${visible.length} utilizatori afișați din ${directoryUsersCache.length}`;
  document.getElementById('directoryUsers').innerHTML=visible.length?directoryTreeHTML(visible):empty('Nu există utilizatori pentru filtrul ales.');
}
async function loadDirectoryUsers(){
  const department=document.getElementById('directoryDepartment').value;
  const target=document.getElementById('directoryUsers');
  directoryUsersCache=[];
  target.innerHTML='<div class="loading">Se încarcă utilizatorii…</div>';
  document.getElementById('directorySummary').textContent='';
  if(!department){target.innerHTML=empty('Nu există departamente disponibile.');return}
  try{directoryUsersCache=await api(`/api/v1/directory/users?department=${encodeURIComponent(department)}`);renderDirectoryUsers()}
  catch(err){target.innerHTML=empty(err.message);toast(err.message,true)}
}
async function openDirectoryImport(){
  const info=await loadDirectoryDepartments();
  if(!info.enabled){toast(info.error||'Importul din Active Directory nu este activat.',true);return}
  const department=document.getElementById('directoryDepartment');
  department.innerHTML=(info.departments||[]).map(value=>`<option value="${e(value)}" ${value===info.default_department?'selected':''}>${e(value)}</option>`).join('');
  document.getElementById('directorySearch').value='';
  directoryDialog.showModal();
  await loadDirectoryUsers();
}
function personMatchesFilters(person,filter){
  if(filter.status==='active'&&!person.active)return false;
  if(filter.status==='inactive'&&person.active)return false;
  if(filter.department&&person.department!==filter.department)return false;
  if(filter.source&&person.source!==filter.source)return false;
  const query=normalizedFilterText(filter.q);
  if(!query)return true;
  return [person.display_name,person.department,person.email,person.phone,person.directory_username].join(' ').toLocaleLowerCase('ro-RO').includes(query);
}
function peopleFilterForm(visibleCount,totalCount,pageSize){
  const filter=nomenclatureFilterState('people');
  const departments=[...new Set(peopleCache.map(person=>String(person.department||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro',{sensitivity:'base'}));
  return `<form id="nomenclatureFilters" class="nomenclature-filters">
    <label class="nomenclature-filter-search">Caută<input name="q" type="search" value="${e(filter.q)}" placeholder="Nume, departament, email sau telefon"></label>
    <label>Departament<select name="department"><option value="">Toate departamentele</option>${departments.map(value=>`<option value="${e(value)}" ${filter.department===value?'selected':''}>${e(value)}</option>`).join('')}</select></label>
    <label>Sursă<select name="source"><option value="" ${!filter.source?'selected':''}>Toate</option><option value="ldap" ${filter.source==='ldap'?'selected':''}>Active Directory</option><option value="manual" ${filter.source==='manual'?'selected':''}>Manual</option></select></label>
    <label>Stare<select name="status"><option value="all" ${filter.status==='all'?'selected':''}>Toate</option><option value="active" ${filter.status==='active'?'selected':''}>Active</option><option value="inactive" ${filter.status==='inactive'?'selected':''}>Inactive</option></select></label>
    <label>Pe pagină<select name="page_size" id="nomenclatureTopPageSize">${pageSizeOptions(pageSize,[10,20,50,100,200])}</select></label>
    <div class="nomenclature-filter-actions"><button type="submit" class="small">Aplică filtre</button><button type="button" id="clearNomenclatureFilters" class="small secondary">Resetează</button></div>
    <span class="nomenclature-filter-summary">${visibleCount.toLocaleString('ro-RO')} rezultate din ${totalCount.toLocaleString('ro-RO')}</span>
  </form>`;
}
function peopleNomenclaturePanel(directoryInfo){
  const filter=nomenclatureFilterState('people');
  const filteredPeople=peopleCache.filter(person=>personMatchesFilters(person,filter));
  const info=nomenclaturePageInfo('people',filteredPeople.length);
  const visiblePeople=filteredPeople.slice(info.offset,info.end);
  const rows=visiblePeople.map(person=>`<tr><td><strong>${e(person.display_name)}</strong><div class="muted">${e(person.department||'')}</div></td><td>${e(person.email||'—')}</td><td>${e(person.phone||'—')}</td><td>${person.source==='ldap'?badge('AD'):badge('manual')}</td><td>${person.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-person" data-id="${person.id}">Editează</button></td>`:''}</tr>`).join('');
  const head=`<tr><th>Persoană</th><th>Email</th><th>Telefon</th><th>Sursă</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  const result=rows?`<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>${nomenclaturePagination('people',info)}`:empty(peopleCache.length?'Nu există persoane pentru filtrele selectate.':'Nu există persoane definite.');
  let body=`${peopleFilterForm(filteredPeople.length,peopleCache.length,info.pageSize)}${result}`;
  if(directoryInfo?.error)body=`<div class="notice warning">Active Directory nu a putut fi interogat: ${e(directoryInfo.error)}</div>${body}`;
  const tools=`<a class="button-link small secondary" href="/api/v1/nomenclatures/export?category=people&include_inactive=true">Export Excel</a>${can('nomenclatures.manage')?`<button id="addPerson" class="small secondary">Adaugă manual</button>${directoryInfo?.enabled?'<button id="importDirectoryPeople" class="small">Importă din AD</button>':''}`:''}`;
  return panel('Persoane',body,tools);
}
function nomenclatureNavigation(selectedCode){
  const categories=new Map(nomenclatureCache.map(category=>[category.code,category]));
  const rendered=new Set();
  const groups=nomenclatureNavigationGroups.map(group=>{
    const links=group.codes.map(code=>{
      if(code==='people'){
        rendered.add(code);
        return `<a href="#nomenclatures/people" class="${selectedCode==='people'?'active':''}"><span>Persoane</span><b>${peopleCache.length}</b></a>`;
      }
      const category=categories.get(code);if(!category)return '';
      rendered.add(code);
      return `<a href="#nomenclatures/${e(code)}" class="${selectedCode===code?'active':''}"><span>${e(category.label)}</span><b>${category.items.length}</b></a>`;
    }).join('');
    return links?`<section><h3>${e(group.label)}</h3>${links}</section>`:'';
  }).join('');
  const other=[...categories.values()].filter(category=>!rendered.has(category.code));
  const otherGroup=other.length?`<section><h3>Altele</h3>${other.map(category=>`<a href="#nomenclatures/${e(category.code)}" class="${selectedCode===category.code?'active':''}"><span>${e(category.label)}</span><b>${category.items.length}</b></a>`).join('')}</section>`:'';
  return `<aside class="nomenclature-submenu"><div class="nomenclature-submenu-title">Nomenclatoare</div>${groups}${otherGroup}</aside>`;
}
function refreshNomenclatureSection(code){
  const target=`#nomenclatures/${code}`;
  if(location.hash===target)nomenclaturesPage(code);else location.hash=target;
}
async function nomenclaturesPage(requestedCode=''){
  [nomenclatureCache,peopleCache]=await Promise.all([api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true')]);
  const allowedCodes=new Set([...nomenclatureCache.map(category=>category.code),'people']);
  const selectedCode=allowedCodes.has(requestedCode)?requestedCode:(nomenclatureCache[0]?.code||'people');
  if(requestedCode!==selectedCode)history.replaceState(null,'',`#nomenclatures/${selectedCode}`);
  const category=nomenclatureCache.find(value=>value.code===selectedCode);
  const label=selectedCode==='people'?'Persoane':category?.label||'Nomenclatoare';
  const description=nomenclatureDescriptions[selectedCode]||'Listă controlată folosită în fișele VM.';
  pageMeta('Nomenclatoare',`${label} · ${description}`);
  const directoryInfo=selectedCode==='people'?await loadDirectoryDepartments():null;
  const selectedPanel=selectedCode==='people'?peopleNomenclaturePanel(directoryInfo):nomenclaturePanel(category);
  content.innerHTML=`<div class="nomenclature-layout">
    ${nomenclatureNavigation(selectedCode)}
    <div class="nomenclature-workspace">
      <div class="nomenclature-context"><span>${e(label)}</span><p>${e(description)}</p></div>
      ${selectedPanel}
    </div>
  </div>`;
  content.querySelectorAll('.add-nomenclature').forEach(button=>button.onclick=()=>openNomenclature(null,button.dataset.category));
  content.querySelectorAll('.edit-nomenclature').forEach(button=>button.onclick=()=>{const item=nomenclatureCache.flatMap(value=>value.items).find(value=>value.id===Number(button.dataset.id));openNomenclature(item)});
  document.getElementById('addPerson')?.addEventListener('click',()=>openPerson());
  document.getElementById('importDirectoryPeople')?.addEventListener('click',openDirectoryImport);
  content.querySelectorAll('.edit-person').forEach(button=>button.onclick=()=>openPerson(peopleCache.find(person=>person.id===Number(button.dataset.id))));
  document.getElementById('nomenclatureFilters')?.addEventListener('submit',event=>{
    event.preventDefault();
    const values=Object.fromEntries(new FormData(event.currentTarget).entries());
    state.nomenclatureFilters[selectedCode]={q:String(values.q||'').trim(),status:String(values.status||'all'),parent:String(values.parent||''),layer:String(values.layer||''),department:String(values.department||''),source:String(values.source||'')};
    const requestedSize=Number(values.page_size||10),pageSize=[10,20,50,100,200].includes(requestedSize)?requestedSize:10;const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize};paging.page=1;paging.pageSize=pageSize;state.nomenclaturePaging[selectedCode]=paging;localStorage.setItem(`vm-doc:nomenclature-page-size:${selectedCode}`,String(pageSize));
    nomenclaturesPage(selectedCode);
  });
  document.getElementById('clearNomenclatureFilters')?.addEventListener('click',()=>{
    state.nomenclatureFilters[selectedCode]={q:'',status:'all',parent:'',layer:'',department:'',source:''};
    const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize:10};paging.page=1;state.nomenclaturePaging[selectedCode]=paging;
    nomenclaturesPage(selectedCode);
  });
  content.querySelectorAll('.nomenclature-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize:10};if(page>0&&page!==paging.page){paging.page=page;state.nomenclaturePaging[selectedCode]=paging;nomenclaturesPage(selectedCode)}}));
  document.getElementById('nomenclatureTopPageSize')?.addEventListener('change',event=>{const pageSize=Number(event.target.value);state.nomenclaturePaging[selectedCode]={page:1,pageSize};localStorage.setItem(`vm-doc:nomenclature-page-size:${selectedCode}`,String(pageSize));nomenclaturesPage(selectedCode)});
}

nomenclatureForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('nomenclatureId').value||0);
  const categoryCode=document.getElementById('nomenclatureCategory').value;
  const parent=document.getElementById('nomenclatureParent');
  const parentValue=parent.value;
  const layerIDs=categoryCode==='technical_role'?[...parent.selectedOptions].map(option=>Number(option.value)).filter(Boolean):[];
  if(categoryCode==='technical_role'&&!layerIDs.length){toast('Selectează cel puțin un layer pentru rolul tehnic.',true);return}
  const body={category_code:categoryCode,name:document.getElementById('nomenclatureName').value.trim(),item_code:document.getElementById('nomenclatureCode').value.trim(),description:document.getElementById('nomenclatureDescription').value.trim(),icon_key:document.getElementById('nomenclatureIcon').value.trim(),sort_order:Number(document.getElementById('nomenclatureOrder').value||0),active:document.getElementById('nomenclatureActive').checked,parent_id:categoryCode==='itil_category'&&parentValue?Number(parentValue):null,layer_ids:layerIDs};
  try{await api(id?`/api/v1/nomenclatures/items/${id}`:'/api/v1/nomenclatures/items',{method:id?'PATCH':'POST',body:JSON.stringify(body)});nomenclatureDialog.close();toast(id?'Valoare actualizată.':'Valoare creată.');refreshNomenclatureSection(categoryCode)}catch(err){toast(err.message,true)}
});
personForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('personId').value||0);const body={display_name:document.getElementById('personName').value.trim(),email:document.getElementById('personEmail').value.trim(),phone:document.getElementById('personPhone').value.trim(),department:document.getElementById('personDepartment').value.trim(),active:document.getElementById('personActive').checked};
  try{await api(id?`/api/v1/people/${id}`:'/api/v1/people',{method:id?'PATCH':'POST',body:JSON.stringify(body)});personDialog.close();toast(id?'Persoană actualizată.':'Persoană creată.');refreshNomenclatureSection('people')}catch(err){toast(err.message,true)}
});

document.getElementById('directoryDepartment').addEventListener('change',loadDirectoryUsers);
document.getElementById('directorySearch').addEventListener('input',renderDirectoryUsers);
document.getElementById('directoryToggleAll').addEventListener('click',()=>{
  const checks=[...document.querySelectorAll('#directoryUsers .directory-user-check')];
  const select=checks.some(check=>!check.checked);checks.forEach(check=>check.checked=select);
});
directoryForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const distinguishedNames=[...document.querySelectorAll('#directoryUsers .directory-user-check:checked')].map(check=>check.value);
  if(!distinguishedNames.length){toast('Selectează cel puțin un utilizator din Active Directory.',true);return}
  try{const imported=await api('/api/v1/people/import-directory',{method:'POST',body:JSON.stringify({distinguished_names:distinguishedNames})});directoryDialog.close();toast(`${imported.length} persoane importate sau actualizate din AD.`);refreshNomenclatureSection('people')}catch(err){toast(err.message,true)}
});


function documentObjectTypeLabel(value){return value==='service'?'Serviciu intern':'VM'}
function updateDocumentTemplateHelp(){
  const type=document.getElementById('documentTemplateObjectType')?.value||'vm';
  const help=document.getElementById('documentTemplateFileHelp');
  if(help)help.textContent=`Șablonul trebuie să conțină placeholderul ${type==='service'?'{{SERVICE_DOCUMENT_BODY}}':'{{VM_DOCUMENT_BODY}}'} într-un paragraf separat.`;
}
function openDocumentTemplate(template=null){
  document.getElementById('documentTemplateDialogTitle').textContent=template?'Editare șablon DOCX':'Șablon DOCX nou';
  document.getElementById('documentTemplateId').value=template?.id||'';
  document.getElementById('documentTemplateName').value=template?.name||'';
  document.getElementById('documentTemplateCode').value=template?.code||'';
  document.getElementById('documentTemplateDescription').value=template?.description||'';
  const objectType=document.getElementById('documentTemplateObjectType');objectType.value=template?.object_type||'vm';objectType.disabled=Boolean(template);
  document.getElementById('documentTemplateActive').checked=template?.active??true;
  document.getElementById('documentTemplateDefault').checked=template?.is_default??false;
  const file=document.getElementById('documentTemplateFile');file.value='';file.required=!template;
  document.getElementById('documentTemplateFileLabel').hidden=Boolean(template);
  updateDocumentTemplateHelp();
  documentTemplateDialog.showModal();
}
function documentTemplateRows(values){
  if(!values?.length)return empty('Nu există șabloane DOCX.');
  const rows=values.map(item=>`<tr><td><strong>${e(item.name)}</strong>${item.description?`<div class="muted">${e(item.description)}</div>`:''}</td><td>${badge(documentObjectTypeLabel(item.object_type))}</td><td class="mono">${e(item.code)}</td><td>${e(item.file_name)}</td><td>${bytesText(item.size_bytes)}</td><td>${item.is_default?badge('implicit'):''}</td><td>${item.active?badge('active'):badge('disabled')}</td><td><div class="actions"><a class="button-link small secondary" href="/api/v1/document-templates/${item.id}/download">Descarcă</a>${can('documents.manage')?`<button class="small secondary edit-document-template" data-id="${item.id}">Editează</button>`:''}</div></td></tr>`).join('');
  return `<div class="table-wrap"><table><thead><tr><th>Șablon</th><th>Tip fișă</th><th>Cod</th><th>Fișier</th><th>Mărime</th><th>Implicit</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
async function documentsPage(){
  pageMeta('Documente','Șabloane DOCX pentru fișele VM și serviciile interne');
  state.documentTemplates=await api(`/api/v1/document-templates${can('documents.manage')?'?include_inactive=true':''}`);
  const active=state.documentTemplates.filter(item=>item.active).length;
  const vmDefault=state.documentTemplates.find(item=>item.object_type==='vm'&&item.is_default);
  const serviceDefault=state.documentTemplates.find(item=>item.object_type==='service'&&item.is_default);
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Șabloane</div><div class="value">${state.documentTemplates.length}</div></div><div class="card"><div class="label">Șabloane active</div><div class="value">${active}</div></div><div class="card"><div class="label">Implicit VM</div><div class="value compact">${e(vmDefault?.name||'—')}</div></div><div class="card"><div class="label">Implicit serviciu</div><div class="value compact">${e(serviceDefault?.name||'—')}</div></div></div>${panel('Șabloane DOCX',documentTemplateRows(state.documentTemplates),can('documents.manage')?'<button id="newDocumentTemplate">Încarcă șablon</button>':'')}${panel('Placeholdere acceptate',`<div class="document-placeholders"><code>{{VM_DOCUMENT_BODY}}</code><span>corp obligatoriu pentru fișa VM</span><code>{{SERVICE_DOCUMENT_BODY}}</code><span>corp obligatoriu pentru fișa tehnică și operațională a serviciului</span><code>{{document.number}}</code><span>numărul fișei</span><code>{{document.generated_at}}</code><span>data referință</span><code>{{document.generated_by}}</code><span>utilizatorul care generează</span><code>{{vm.name}}</code><span>numele VM-ului</span><code>{{vm.hostname}}</code><span>hostname</span><code>{{vm.ip}}</code><span>IP principal</span><code>{{vm.os}}</code><span>sistemul de operare</span><code>{{vm.environment}}</code><span>mediul</span><code>{{vm.status}}</code><span>status operațional</span><code>{{vm.classification}}</code><span>clasificarea</span><code>{{vm.purpose}}</code><span>scopul VM-ului</span><code>{{service.name}}</code><span>numele serviciului intern</span><code>{{service.code}}</code><span>codul serviciului</span><code>{{service.criticality}}</code><span>criticitatea serviciului</span><code>{{service.status}}</code><span>statusul documentației</span><code>{{service.description}}</code><span>descrierea serviciului</span><code>{{service.purpose}}</code><span>Scop și domeniu (compatibilitate)</span><code>{{service.scope_domain}}</code><span>Scop și domeniu</span><code>{{service.objectives}}</code><span>Obiectivele serviciului</span></div>`)} `;
  document.getElementById('newDocumentTemplate')?.addEventListener('click',()=>openDocumentTemplate());
  content.querySelectorAll('.edit-document-template').forEach(button=>button.addEventListener('click',()=>openDocumentTemplate(state.documentTemplates.find(item=>item.id===Number(button.dataset.id)))));
}

document.getElementById('documentTemplateObjectType')?.addEventListener('change',updateDocumentTemplateHelp);
documentTemplateForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('documents.manage'))return;
  const id=Number(document.getElementById('documentTemplateId').value||0);
  const name=document.getElementById('documentTemplateName').value.trim();
  const code=document.getElementById('documentTemplateCode').value.trim();
  const objectType=document.getElementById('documentTemplateObjectType').value;
  const description=document.getElementById('documentTemplateDescription').value.trim();
  const active=document.getElementById('documentTemplateActive').checked;
  const isDefault=document.getElementById('documentTemplateDefault').checked;
  try{
    if(id){await api(`/api/v1/document-templates/${id}`,{method:'PATCH',body:JSON.stringify({name,code,description,active,is_default:isDefault})})}
    else{const file=document.getElementById('documentTemplateFile').files[0];if(!file){toast('Alege fișierul DOCX.',true);return}const body=new FormData();body.set('name',name);body.set('code',code);body.set('object_type',objectType);body.set('description',description);body.set('active',String(active));body.set('is_default',String(isDefault));body.set('file',file);await api('/api/v1/document-templates',{method:'POST',body})}
    documentTemplateDialog.close();toast(id?'Șablon actualizat.':'Șablon încărcat.');documentsPage();
  }catch(err){toast(err.message,true)}
});

const reportPalette=['var(--accent)','var(--ok)','var(--warn)','var(--bad)','#8b5cf6','#06b6d4','var(--muted)','var(--text)'];
function reportSeriesPoints(points){return (points||[]).filter(item=>Number(item.value||0)>0)}
function reportDonut(title,points){const data=reportSeriesPoints(points);const total=data.reduce((s,p)=>s+Number(p.value||0),0);if(!total)return `<article class="report-chart">${empty('Fără date pentru '+title)}</article>`;let cursor=0;const stops=data.map((p,i)=>{const start=cursor;cursor+=Number(p.value)/total*100;return `${reportPalette[i%reportPalette.length]} ${start.toFixed(2)}% ${cursor.toFixed(2)}%`}).join(',');return `<article class="report-chart"><header><h3>${e(title)}</h3><strong>${total.toLocaleString('ro-RO')}</strong></header><div class="report-donut-wrap"><div class="report-donut" style="background:conic-gradient(${stops})"><span>${total.toLocaleString('ro-RO')}</span></div><div class="report-legend">${data.map((p,i)=>`<div><i style="background:${reportPalette[i%reportPalette.length]}"></i><span>${e(p.label)}</span><strong>${Number(p.value).toLocaleString('ro-RO')}</strong></div>`).join('')}</div></div></article>`}
function reportBars(title,points,limit=15){const data=reportSeriesPoints(points).slice(0,limit),max=Math.max(1,...data.map(p=>Number(p.value)));return `<article class="report-chart report-bar-chart"><header><h3>${e(title)}</h3></header>${data.length?`<div class="report-bars">${data.map(p=>`<div class="report-bar-row"><span title="${e(p.label)}">${e(p.label)}</span><div><i style="width:${Math.max(2,Number(p.value)/max*100)}%"></i></div><strong>${Number(p.value).toLocaleString('ro-RO')}</strong></div>`).join('')}</div>`:empty('Fără date.')}</article>`}
function reportTimeline(title,points){const data=points||[],max=Math.max(1,...data.map(p=>Number(p.vm||0)+Number(p.service||0)));return `<article class="report-chart report-timeline"><header><h3>${e(title)}</h3><span>ultimele 30 zile</span></header>${data.length?`<div class="timeline-bars">${data.map(p=>{const vm=Number(p.vm||0),sv=Number(p.service||0);return `<div class="timeline-day" title="${e(p.date)} · VM ${vm} · Servicii ${sv}"><div><i class="timeline-vm" style="height:${vm/max*100}%"></i><i class="timeline-service" style="height:${sv/max*100}%"></i></div><span>${e(p.date.slice(5))}</span></div>`}).join('')}</div><div class="timeline-legend"><span><i class="timeline-vm"></i> Fișe VM</span><span><i class="timeline-service"></i> Fișe servicii</span></div>`:empty('Nu au fost generate documente în ultimele 30 de zile.')}</article>`}
function reportSummaryCard(label,value,kind=''){return `<div class="card report-summary-card ${e(kind)}"><div class="label">${e(label)}</div><div class="value">${Number(value||0).toLocaleString('ro-RO')}</div></div>`}
function reportServiceIssues(rows){if(!rows?.length)return empty('Nu sunt identificate probleme de documentare la servicii.');return `<div class="table-wrap"><table><thead><tr><th>Serviciu</th><th>Criticitate</th><th>Status documentație</th><th>VM-uri</th><th>De completat</th></tr></thead><tbody>${rows.map(r=>`<tr><td><a href="#services/${r.id}"><strong>${e(r.name)}</strong></a></td><td>${criticalityBadge(r.criticality)}</td><td>${badge(r.documentation_status)}</td><td>${r.vm_count}</td><td class="warning-text">${e(r.issue)}</td></tr>`).join('')}</tbody></table></div>`}
function reportVMIssues(rows){if(!rows?.length)return empty('Nu sunt identificate probleme de documentare la VM-uri.');return `<div class="table-wrap"><table><thead><tr><th>VM</th><th>Mediu</th><th>Power</th><th>De completat</th></tr></thead><tbody>${rows.map(r=>`<tr><td><a href="#vms/${r.id}"><strong>${e(r.name)}</strong></a><div class="muted mono">${e(r.hostname||'—')}</div></td><td>${environmentBadge(r.environment)}</td><td>${badge(r.power_state||'unknown')}</td><td class="warning-text">${e(r.issue)}</td></tr>`).join('')}</tbody></table></div>`}
function reportInventoryStorage(stats){stats=stats||{};const agents=stats.top_agents||[];const rows=agents.map(a=>`<tr><td><strong>${e(a.agent_name||`Agent #${a.agent_id}`)}</strong></td><td>${Number(a.snapshots||0).toLocaleString('ro-RO')}</td><td>${bytesText(a.payload_bytes||0)}</td><td>${a.oldest_snapshot?dt(a.oldest_snapshot):'—'}</td><td>${a.newest_snapshot?dt(a.newest_snapshot):'—'}</td></tr>`).join('');return `<div class="cards inventory-storage-summary"><div class="card"><div class="label">Snapshot-uri</div><div class="value">${Number(stats.snapshots||0).toLocaleString('ro-RO')}</div></div><div class="card"><div class="label">Payload JSON</div><div class="value compact">${bytesText(stats.payload_bytes||0)}</div></div><div class="card"><div class="label">Date tabelă</div><div class="value compact">${bytesText(stats.table_data_bytes||0)}</div></div><div class="card"><div class="label">Indexuri</div><div class="value compact">${bytesText(stats.table_index_bytes||0)}</div></div></div><div class="inventory-storage-range"><span>Cel mai vechi: <strong>${stats.oldest_snapshot?dt(stats.oldest_snapshot):'—'}</strong></span><span>Cel mai nou: <strong>${stats.newest_snapshot?dt(stats.newest_snapshot):'—'}</strong></span></div>${rows?`<div class="table-wrap"><table><thead><tr><th>Agent</th><th>Snapshot-uri</th><th>Payload</th><th>Cel mai vechi</th><th>Cel mai nou</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există snapshot-uri de inventar.')}`}
const reportCategories=[
  {id:'overview',label:'Prezentare generală'},
  {id:'vms',label:'VM & resurse'},
  {id:'agents',label:'Agenți & inventar'},
  {id:'services',label:'Servicii & arhitectură'},
  {id:'people',label:'Persoane & responsabilități'},
  {id:'operations',label:'Lipsuri operaționale'},
  {id:'software',label:'Software principal'},
  {id:'dependencies',label:'Dependențe & impact'},
  {id:'documents',label:'Documentație'}
];
function reportSubmenu(active){return `<aside class="nomenclature-submenu report-submenu"><div class="nomenclature-submenu-title">Rapoarte</div><section>${reportCategories.map(item=>`<a href="#reports/${item.id}" class="${active===item.id?'active':''}"><span>${e(item.label)}</span></a>`).join('')}</section></aside>`}
function reportCategoryBody(category,data){
  const s=data.summary||{},c=data.charts||{},topServicePoints=(data.top_services||[]).map(r=>({label:r.name,value:r.vm_count}));
  if(category==='vms')return `${panel('VM & resurse',`<div class="report-grid">${reportDonut('Power state',c.vm_power_state)}${reportDonut('Medii PROD / TEST / DEV',c.vm_environment)}${reportDonut('Status operațional',c.vm_operational_status)}${reportDonut('Dimensionare vCPU',c.vm_cpu_size)}${reportDonut('Dimensionare RAM',c.vm_memory_size)}${reportBars('Sisteme de operare',c.vm_os,12)}${reportBars('Distribuție pe vCenter',c.vm_source,12)}${reportBars('Versiuni hardware VM',c.vm_hardware_version,15)}</div>`)}`;
  if(category==='agents')return `${panel('Agenți & inventar',`<div class="report-grid">${reportDonut('Acoperire agent',c.agent_coverage)}${reportDonut('Prospețime inventar',c.inventory_freshness)}${reportDonut('Protecție backup',c.backup_protection)}</div>`)}${panel('Stocare inventory_snapshots',reportInventoryStorage(data.inventory_storage),'<span class="muted">Retenția implicită păstrează maximum 30 snapshot-uri/agent și maximum 90 zile; snapshot-urile curente și cele referite de documente generate sunt protejate.</span>')}`;
  if(category==='services')return `${panel('Servicii & arhitectură',`<div class="report-grid">${reportDonut('Criticitate servicii',c.service_criticality)}${reportDonut('Tip soluție',c.solution_type)}${reportDonut('Soluții omogene / mixte',c.service_solution_mix)}${reportDonut('Dimensiune servicii după VM-uri',c.service_vm_size)}${reportDonut('Tip utilizare asociere',c.assignment_usage)}${reportDonut('Asocieri principale / secundare',c.assignment_primary)}${reportDonut('Completitudine asocieri',c.assignment_completeness)}${reportBars('Servicii prezente pe medii',c.service_environment_presence,15)}${reportBars('Servicii pe domeniu',c.service_domain,15)}${reportBars('Servicii pe categorie',c.service_category,15)}${reportBars('VM-uri pe layer',c.layer_usage,15)}${reportBars('Roluri tehnice utilizate',c.technical_role_usage,20)}${reportBars('Servicii cu cele mai multe VM-uri',topServicePoints,20)}</div>`)}`;
  if(category==='people'){
    const rows=Array.isArray(data.people_assignments)?data.people_assignments:[],departments=[...new Set(rows.map(r=>r.department).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro')),environments=[...new Set(rows.map(r=>r.environment).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
    const filters=`<div class="filterbar report-table-filters"><label>Căutare<input id="peopleReportSearch" type="search" placeholder="Persoană, VM, serviciu…"></label><label>Rol<select id="peopleReportRole"><option value="">Toate</option>${Object.entries(responsibilityTypes).map(([v,l])=>`<option value="${e(v)}">${e(l)}</option>`).join('')}</select></label><label>Departament<select id="peopleReportDepartment"><option value="">Toate</option>${departments.map(v=>`<option value="${e(v)}">${e(v)}</option>`).join('')}</select></label><label>Mediu<select id="peopleReportEnvironment"><option value="">Toate</option>${environments.map(v=>`<option value="${e(v)}">${e(environmentDisplay(v))}</option>`).join('')}</select></label></div>`;
    const table=rows.length?`<div class="section-actions"><span id="peopleReportCount" class="muted"></span><a id="peopleReportExport" class="button-link small secondary" href="/api/v1/reports/people/export">Export Excel</a></div><div class="table-wrap"><table><thead><tr><th>Persoană</th><th>Departament</th><th>Responsabilitate</th><th>VM</th><th>Mediu</th><th>Servicii</th></tr></thead><tbody>${rows.map(r=>`<tr class="people-report-row" data-search="${e([r.person_name,r.email,r.department,r.vm_name,r.services].join(' ').toLowerCase())}" data-role="${e(r.responsibility_type||'')}" data-department="${e(r.department||'')}" data-environment="${e(r.environment||'')}"><td><strong>${e(r.person_name)}</strong><div class="muted">${e(r.email||'—')}</div></td><td>${e(r.department||'—')}</td><td>${e(responsibilityTypes[r.responsibility_type]||r.responsibility_type)}</td><td><a href="#vms/${r.vm_id}/overview"><strong>${e(r.vm_name)}</strong></a></td><td>${r.environment?environmentBadge(r.environment):'—'}</td><td>${e(r.services||'—')}</td></tr>`).join('')}</tbody></table></div>`:empty('Nu există responsabilități VM definite.');
    return `<div class="cards report-summary">${reportSummaryCard('Persoane active',s.people_active)}${reportSummaryCard('Persoane cu VM-uri',s.people_with_vms)}${reportSummaryCard('VM fără responsabil',s.vms_without_responsibility,'warning')}${reportSummaryCard('VM cu mai mulți responsabili',s.vms_multi_responsibility)}</div>${panel('Persoane → VM-uri',`${filters}${table}`,'<span class="muted">Un rând reprezintă o persoană, o VM și un tip de responsabilitate; exportul Excel păstrează aceeași structură filtrabilă.</span>')}`;
  }
  if(category==='operations'){
    const rows=Array.isArray(data.operational_gaps)?data.operational_gaps:[];
    const filters=`<div class="filterbar report-table-filters"><label>Căutare<input id="gapReportSearch" type="search" placeholder="VM, hostname, problemă…"></label><label>Problemă<select id="gapReportIssue"><option value="">Toate</option><option value="responsibility">Fără responsabil</option><option value="service">Fără serviciu</option><option value="environment">Fără mediu</option><option value="agent">Fără agent</option><option value="agent_offline">Agent offline</option><option value="inventory">Inventar lipsă / vechi</option><option value="backup">Backup neacoperit</option><option value="monitoring">Fără monitorizare</option><option value="baseline">Fără baseline</option><option value="document">Fără fișă VM</option></select></label></div>`;
    const table=rows.length?`<div class="section-actions"><span id="gapReportCount" class="muted"></span><a id="gapReportExport" class="button-link small secondary" href="/api/v1/reports/operational-gaps/export">Export Excel</a></div><div class="table-wrap"><table><thead><tr><th>VM</th><th>Mediu</th><th>Power</th><th>Probleme</th></tr></thead><tbody>${rows.map(r=>`<tr class="gap-report-row" data-search="${e([r.name,r.hostname,r.environment,r.issue].join(' ').toLowerCase())}" data-responsibility="${r.no_responsibility?'1':'0'}" data-service="${r.no_service?'1':'0'}" data-environment="${r.no_environment?'1':'0'}" data-agent="${r.no_agent?'1':'0'}" data-agent_offline="${r.agent_offline?'1':'0'}" data-inventory="${r.inventory_stale?'1':'0'}" data-backup="${r.backup_gap?'1':'0'}" data-monitoring="${r.monitoring_gap?'1':'0'}" data-baseline="${r.no_baseline?'1':'0'}" data-document="${r.no_document?'1':'0'}"><td><a href="#vms/${r.id}/overview"><strong>${e(r.name)}</strong></a><div class="muted mono">${e(r.hostname||'—')}</div></td><td>${r.environment?environmentBadge(r.environment):'—'}</td><td>${badge(r.power_state||'unknown')}</td><td class="warning-text">${e(r.issue)}</td></tr>`).join('')}</tbody></table></div>`:empty('Nu sunt identificate lipsuri operaționale.');
    return `${panel('Listă de lucru operațională',`${filters}${table}`,'<span class="muted">Raportul combină responsabilități, servicii, agent/inventar, backup, monitorizare, baseline și existența fișei VM.</span>')}`;
  }
  if(category==='software')return `${panel('Software principal',`<div class="report-grid">${reportBars('Servicii software marcate principal',c.primary_agent_software,30)}</div><p class="muted report-note">Selecțiile provin din serviciile observate de agent și marcate Principal pe fiecare VM.</p>`)}`;
  if(category==='dependencies')return `${panel('Servicii comune și analiză de impact',`<div class="report-grid">${reportDonut('Servicii comune / globale',c.common_service_kind)}${reportDonut('Tipuri de dependență declarate',c.dependency_type_usage)}${reportBars('Servicii dependente per serviciu comun',c.common_service_impact,20)}${reportBars('VM-uri potențial afectate',c.common_service_vm_impact,20)}${reportDonut('Sisteme externe pe rețele',c.external_network_usage)+reportDonut('Sisteme externe după risc',c.external_network_risk)}</div>`,'<span class="muted">Impactul global include serviciile active; conexiunile externe moștenesc rețeaua, riscul și nivelul de trust.</span>')}`;
  if(category==='documents')return `${panel('Documentație',`<div class="report-grid">${reportDonut('Fișe tehnice VM',c.vm_documentation)}${reportDonut('Status documentație servicii',c.service_documentation_status)}${reportDonut('Fișe servicii',c.service_documentation)}</div>`)}${panel('Activitate documentație',reportTimeline('Documente generate',data.document_timeline))}${panel('Servicii care necesită completări',reportServiceIssues(data.service_issues))}${panel('VM-uri care necesită completări',reportVMIssues(data.vm_issues))}`;
  return `<div class="cards report-summary">${reportSummaryCard('VM-uri active',s.vms_present)}${reportSummaryCard('VM-uri pornite',s.vms_powered_on)}${reportSummaryCard('Servicii active',s.services_active)}${reportSummaryCard('Servicii critice',s.services_critical,'danger')}${reportSummaryCard('Servicii comune',s.services_common)}${reportSummaryCard('Globale implicite',s.services_global)}${reportSummaryCard('Dependențe declarate',s.service_dependencies)}${reportSummaryCard('Rețele externe',s.external_networks)}${reportSummaryCard('Sisteme externe',s.external_systems)}${reportSummaryCard('Conexiuni externe',s.external_connections)}${reportSummaryCard('VM fără mediu',s.vms_without_environment,'warning')}${reportSummaryCard('VM fără serviciu',s.vms_without_service,'warning')}${reportSummaryCard('VM fără fișă',s.vms_without_document,'warning')}${reportSummaryCard('Servicii fără fișă',s.services_without_document,'warning')}</div>${panel('Indicatori cheie',`<div class="report-grid">${reportDonut('Power state',c.vm_power_state)}${reportDonut('Acoperire agent',c.agent_coverage)}${reportDonut('Criticitate servicii',c.service_criticality)}${reportDonut('Fișe tehnice VM',c.vm_documentation)}</div>`)}`;
}
async function reportsPage(category='overview'){
  if(!reportCategories.some(item=>item.id===category))category='overview';
  pageMeta('Rapoarte',reportCategories.find(item=>item.id===category)?.label||'Indicatori');
  if(!state.reportsData)state.reportsData=await api('/api/v1/reports/overview');const data=state.reportsData;
  content.innerHTML=`<div class="nomenclature-layout report-layout">${reportSubmenu(category)}<div class="nomenclature-workspace"><div class="report-header"><div><strong>${e(reportCategories.find(item=>item.id===category)?.label||'Rapoarte')}</strong><span>Generat ${dt(data.generated_at)}</span></div><button id="refreshReports" class="secondary">Reîncarcă</button></div>${reportCategoryBody(category,data)}</div></div>`;
  document.getElementById('refreshReports')?.addEventListener('click',async()=>{state.reportsData=null;await reportsPage(category)});
  bindReportTableFilters(category);
}

function bindReportTableFilters(category){
  if(category==='people'){
    const apply=()=>{const q=String(document.getElementById('peopleReportSearch')?.value||'').trim().toLowerCase(),role=document.getElementById('peopleReportRole')?.value||'',department=document.getElementById('peopleReportDepartment')?.value||'',environment=document.getElementById('peopleReportEnvironment')?.value||'';let visible=0;document.querySelectorAll('.people-report-row').forEach(row=>{const ok=(!q||row.dataset.search.includes(q))&&(!role||row.dataset.role===role)&&(!department||row.dataset.department===department)&&(!environment||row.dataset.environment===environment);row.hidden=!ok;if(ok)visible++});const count=document.getElementById('peopleReportCount');if(count)count.textContent=`${visible} din ${document.querySelectorAll('.people-report-row').length} asocieri`;const params=new URLSearchParams();if(q)params.set('q',q);if(role)params.set('responsibility',role);if(department)params.set('department',department);if(environment)params.set('environment',environment);const link=document.getElementById('peopleReportExport');if(link)link.href=`/api/v1/reports/people/export${params.toString()?`?${params}`:''}`};['peopleReportSearch','peopleReportRole','peopleReportDepartment','peopleReportEnvironment'].forEach(id=>document.getElementById(id)?.addEventListener(id==='peopleReportSearch'?'input':'change',apply));apply();
  }
  if(category==='operations'){
    const apply=()=>{const q=String(document.getElementById('gapReportSearch')?.value||'').trim().toLowerCase(),issue=document.getElementById('gapReportIssue')?.value||'';let visible=0;document.querySelectorAll('.gap-report-row').forEach(row=>{const ok=(!q||row.dataset.search.includes(q))&&(!issue||row.dataset[issue]==='1');row.hidden=!ok;if(ok)visible++});const count=document.getElementById('gapReportCount');if(count)count.textContent=`${visible} din ${document.querySelectorAll('.gap-report-row').length} VM-uri`;const params=new URLSearchParams();if(q)params.set('q',q);if(issue)params.set('issue',issue);const link=document.getElementById('gapReportExport');if(link)link.href=`/api/v1/reports/operational-gaps/export${params.toString()?`?${params}`:''}`};['gapReportSearch','gapReportIssue'].forEach(id=>document.getElementById(id)?.addEventListener(id==='gapReportSearch'?'input':'change',apply));apply();
  }
}

function scopedAuditState(scope,id){
  const key=scope==='vm'?'vmAudit':'serviceAudit',idKey=scope==='vm'?'vmId':'serviceId';let f=state[key];if(Number(f[idKey])!==Number(id)){f={...f,[idKey]:Number(id),page:1,q:'',area:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:null};state[key]=f}return f;
}
function scopedAuditQuery(scope,id){return scope==='vm'?['vm_id',id]:['service_id',id]}
function scopedAuditFiltersHTML(f,facets){return `<form id="scopedAuditFilters" class="audit-filters"><label class="span-2"><span>Caută</span><input id="scopedAuditSearch" type="search" value="${e(f.q||'')}" placeholder="actor, acțiune, resursă sau detalii"></label><label><span>Zonă</span><select id="scopedAuditArea"><option value="">Toate</option>${[['configuration','Configurare'],['docker','Docker'],['database','Baze de date'],['web','Web'],['documents','Documente'],['operations','Operații / sistem']].map(([v,l])=>auditOption(v,l,f.area)).join('')}</select></label><label><span>Actor</span><select id="scopedAuditActor"><option value="">Toți</option>${(facets.actors||[]).map(v=>auditOption(v,v,f.actor)).join('')}</select></label><label><span>Sursă</span><select id="scopedAuditSource"><option value="">Toate</option>${(facets.sources||[]).map(v=>auditOption(v,v,f.source)).join('')}</select></label><label><span>Acțiune</span><select id="scopedAuditAction"><option value="">Toate</option>${(facets.actions||[]).map(v=>auditOption(v,v,f.action)).join('')}</select></label><label><span>Resursă</span><select id="scopedAuditResourceType"><option value="">Toate</option>${(facets.resource_types||[]).map(v=>auditOption(v,auditResourceTypeLabel(v),f.resourceType)).join('')}</select></label><label><span>Rezultat</span><select id="scopedAuditOutcome"><option value="">Toate</option>${(facets.outcomes||[]).map(v=>auditOption(v,v,f.outcome)).join('')}</select></label><label><span>De la</span><input id="scopedAuditFrom" type="date" value="${e(f.from||'')}"></label><label><span>Până la</span><input id="scopedAuditTo" type="date" value="${e(f.to||'')}"></label><div class="filter-actions"><button type="submit">Aplică</button><button type="button" id="scopedAuditReset" class="secondary">Resetează</button></div></form>`}
async function scopedAuditPage(scope,id){
  const root=document.getElementById('scopedAuditRoot');if(!root)return;const f=scopedAuditState(scope,id),[scopeKey,scopeValue]=scopedAuditQuery(scope,id);
  if(!f.facets){try{f.facets=await api(`/api/v1/audit/facets?${scopeKey}=${scopeValue}`)}catch{f.facets={sources:[],actors:[],actions:[],resource_types:[],outcomes:[]}}}
  root.className='scoped-audit-shell';root.innerHTML=`${panel(scope==='vm'?'Filtre audit VM':'Filtre audit serviciu',scopedAuditFiltersHTML(f,f.facets),'<span class="muted">Audit contextual: include obiectul principal și resursele tehnice care pot fi legate de el.</span>')}${panel('Evenimente','<div id="scopedAuditTableArea" class="loading">Se încarcă evenimentele…</div>')}`;
  document.getElementById('scopedAuditFilters')?.addEventListener('submit',event=>{event.preventDefault();Object.assign(f,{q:document.getElementById('scopedAuditSearch').value.trim(),area:document.getElementById('scopedAuditArea').value,source:document.getElementById('scopedAuditSource').value,actor:document.getElementById('scopedAuditActor').value,action:document.getElementById('scopedAuditAction').value,resourceType:document.getElementById('scopedAuditResourceType').value,outcome:document.getElementById('scopedAuditOutcome').value,from:document.getElementById('scopedAuditFrom').value,to:document.getElementById('scopedAuditTo').value,page:1});loadScopedAudit(scope,id)});
  document.getElementById('scopedAuditReset')?.addEventListener('click',()=>{Object.assign(f,{page:1,q:'',area:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:''});scopedAuditPage(scope,id)});
  await loadScopedAudit(scope,id);
}
async function loadScopedAudit(scope,id){
  const area=document.getElementById('scopedAuditTableArea');if(!area)return;const f=scopedAuditState(scope,id),[scopeKey,scopeValue]=scopedAuditQuery(scope,id),p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize),[scopeKey]:String(scopeValue)});[['q',f.q],['area',f.area],['source',f.source],['actor',f.actor],['action',f.action],['resource_type',f.resourceType],['outcome',f.outcome],['from',f.from],['to',f.to]].forEach(([k,v])=>{if(v)p.set(k,v)});area.className='loading';area.textContent='Se încarcă evenimentele…';
  try{const result=await api(`/api/v1/audit/events?${p}`);f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||10);area.className='';area.innerHTML=renderAuditPage(result);area.querySelectorAll('.audit-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==f.page){f.page=page;loadScopedAudit(scope,id)}}));document.getElementById('auditPageSize')?.addEventListener('change',event=>{f.pageSize=Number(event.target.value);f.page=1;loadScopedAudit(scope,id)});bindAuditToggles(area)}catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}
function auditResourceTypeLabel(value){return ({virtual_machine:'VM',internal_service:'Serviciu',docker_container:'Container Docker',docker_compose_project:'Proiect Compose',database_instance:'Instanță DB',database_catalog:'Catalog DB',web_site:'Site / frontend Web',web_server:'Server Web',software_item:'Software',generated_document:'Document',inventory_change:'Modificare inventar',internal_service_attachment:'Anexă serviciu',agent:'Agent',person:'Persoană'})[value]||value||'Resursă'}
function auditResourceHTML(record){const label=record.resource_label||auditResourceTypeLabel(record.resource_type),main=record.resource_url?`<a href="${e(record.resource_url)}"><strong>${e(label)}</strong></a>`:`<strong>${e(label)}</strong>`,id=record.resource_id?`<span class="muted mono">#${e(record.resource_id)}</span>`:'',vm=record.vm_id&&record.resource_type!=='virtual_machine'?`<div class="muted">VM: <a href="#vms/${record.vm_id}/overview">${e(record.vm_name||`#${record.vm_id}`)}</a></div>`:'',services=(record.service_names||[]).length&&record.resource_type!=='internal_service'?`<div class="muted">Serviciu: ${(record.service_names||[]).map((name,index)=>{const sid=(record.service_ids||[])[index];return sid?`<a href="#services/${sid}/overview">${e(name)}</a>`:e(name)}).join(', ')}</div>`:'';return `<div class="audit-resource-context">${main} ${id}<div class="muted">${e(auditResourceTypeLabel(record.resource_type))}</div>${vm}${services}</div>`}
function bindAuditToggles(area){area?.querySelectorAll('.audit-toggle').forEach(button=>button.addEventListener('click',()=>{const row=area.querySelector(`[data-detail-id="${button.dataset.id}"]`);if(!row)return;row.hidden=!row.hidden;button.textContent=row.hidden?'Detalii':'Închide'}))}

function auditOption(value,label,current){return `<option value="${e(value)}" ${String(current||'')===String(value)?'selected':''}>${e(label||value)}</option>`}
function auditOperationBadge(operation){const labels={created:'Adăugat',updated:'Modificat',deleted:'Șters',operation:'Operație'};return `<span class="audit-operation ${e(operation||'operation')}">${e(labels[operation]||'Operație')}</span>`}
function auditDetailsObject(raw){if(raw==null)return {};if(typeof raw==='object'&&!Array.isArray(raw))return raw;try{return JSON.parse(raw)||{}}catch{return {raw:String(raw)}}}
function auditSimpleValue(value){if(value==null||value==='')return '—';if(typeof value==='boolean')return value?'Da':'Nu';if(typeof value==='object')return JSON.stringify(value);return String(value)}
function auditChangedFields(before,after){before=(before&&typeof before==='object')?before:{};after=(after&&typeof after==='object')?after:{};const keys=[...new Set([...Object.keys(before),...Object.keys(after)])].filter(k=>!['updated_at','created_at','connections'].includes(k)).sort();return keys.filter(k=>JSON.stringify(before[k])!==JSON.stringify(after[k])).map(k=>({key:k,before:before[k],after:after[k]}))}
function auditChangeDetails(record){const details=auditDetailsObject(record.details),operation=record.operation||'operation';if(operation==='updated'&&details.before&&details.after){const changes=auditChangedFields(details.before,details.after);if(!changes.length)return `<p class="muted">Eveniment de modificare fără diferențe de câmp identificabile în payload-ul de audit.</p>`;return `<div class="table-wrap audit-change-table"><table><thead><tr><th>Câmp</th><th>Înainte</th><th>După</th></tr></thead><tbody>${changes.map(c=>`<tr><td class="mono">${e(c.key)}</td><td>${e(auditSimpleValue(c.before))}</td><td>${e(auditSimpleValue(c.after))}</td></tr>`).join('')}</tbody></table></div>`}
  const subject=details.created||details.deleted;if(subject&&typeof subject==='object'){const title=operation==='deleted'?'Date șterse':'Date adăugate';const rows=Object.entries(subject).filter(([k])=>!['created_at','updated_at','connections'].includes(k)).map(([k,v])=>`<tr><td class="mono">${e(k)}</td><td>${e(auditSimpleValue(v))}</td></tr>`).join('');return `<strong>${title}</strong><div class="table-wrap audit-change-table"><table><tbody>${rows}</tbody></table></div>`}
  const entries=Object.entries(details);if(!entries.length)return `<p class="muted">Acest eveniment vechi nu conține detalii suplimentare.</p>`;return `<details class="audit-raw"><summary>Detalii tehnice</summary><pre>${e(JSON.stringify(details,null,2))}</pre></details>`}
async function auditPage(){
  pageMeta('Audit','Cine a schimbat ce, când și cu ce rezultat');
  if(!state.audit.facets){try{state.audit.facets=await api('/api/v1/audit/facets')}catch{state.audit.facets={sources:[],actors:[],actions:[],resource_types:[],outcomes:[]}}}
  const f=state.audit,facets=state.audit.facets||{},filters=`<form id="auditFilters" class="audit-filters"><label class="span-2"><span>Caută</span><input id="auditSearch" type="search" value="${e(f.q)}" placeholder="actor, acțiune, resursă, IP sau detalii"></label><label><span>Actor</span><select id="auditActor"><option value="">Toți</option>${(facets.actors||[]).map(v=>auditOption(v,v,f.actor)).join('')}</select></label><label><span>Sursă</span><select id="auditSource"><option value="">Toate</option>${(facets.sources||[]).map(v=>auditOption(v,v,f.source)).join('')}</select></label><label><span>Acțiune</span><select id="auditAction"><option value="">Toate</option>${(facets.actions||[]).map(v=>auditOption(v,v,f.action)).join('')}</select></label><label><span>Resursă</span><select id="auditResourceType"><option value="">Toate</option>${(facets.resource_types||[]).map(v=>auditOption(v,auditResourceTypeLabel(v),f.resourceType)).join('')}</select></label><label><span>Rezultat</span><select id="auditOutcome"><option value="">Toate</option>${(facets.outcomes||[]).map(v=>auditOption(v,v,f.outcome)).join('')}</select></label><label><span>De la</span><input id="auditFrom" type="date" value="${e(f.from)}"></label><label><span>Până la</span><input id="auditTo" type="date" value="${e(f.to)}"></label><div class="filter-actions"><button type="submit">Aplică</button><button type="button" id="auditReset" class="secondary">Resetează</button></div></form>`;
  content.innerHTML=`${panel('Filtre audit',filters,'<span class="muted">Evenimentele noi de adăugare/modificare/ștergere pot păstra valorile înainte și după. Evenimentele istorice afișează numai datele care au fost salvate la momentul respectiv.</span>')}${panel('Evenimente de audit','<div id="auditTableArea" class="loading">Se încarcă evenimentele…</div>')}`;
  document.getElementById('auditFilters')?.addEventListener('submit',event=>{event.preventDefault();Object.assign(f,{q:document.getElementById('auditSearch').value.trim(),actor:document.getElementById('auditActor').value,source:document.getElementById('auditSource').value,action:document.getElementById('auditAction').value,resourceType:document.getElementById('auditResourceType').value,outcome:document.getElementById('auditOutcome').value,from:document.getElementById('auditFrom').value,to:document.getElementById('auditTo').value,page:1});loadAuditPage()});
  document.getElementById('auditReset')?.addEventListener('click',()=>{state.audit={page:1,pageSize:f.pageSize||10,q:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:state.audit.facets};auditPage()});
  await loadAuditPage()
}
function renderAuditPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există evenimente pentru filtrele selectate.');
  const rows=items.map(record=>`<tr class="audit-row"><td>${dt(record.occurred_at)}</td><td>${e(record.actor_username||'sistem')}<div class="muted mono">${e(record.ip_address||'')}</div></td><td><strong>${e(record.action_label||record.action)}</strong><div class="muted">${e(record.action_description||record.action)}</div><div class="muted mono">${e(record.action)}</div></td><td>${auditOperationBadge(record.operation)}${auditResourceHTML(record)}</td><td>${badge(record.outcome)}</td><td><button class="small secondary audit-toggle" data-id="${record.id}">Detalii</button></td></tr><tr class="audit-detail-row" data-detail-id="${record.id}" hidden><td colspan="6"><div class="audit-detail-card"><div class="detail-grid compact">${detail('Sursă',e(record.source||'—'))}${detail('Acțiune',e(record.action))}${detail('Resursă',auditResourceHTML(record))}${record.request_id?detail('Request ID',e(record.request_id),true):''}${detail('IP',e(record.ip_address||'—'),true)}</div>${auditChangeDetails(record)}</div></td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Data</th><th>Actor</th><th>Acțiune</th><th>Resursă / operație</th><th>Rezultat</th><th></th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="auditPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result.pages||1),'audit-page')}</div></div>`;
}
async function loadAuditPage(){
  const area=document.getElementById('auditTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă evenimentele…';const f=state.audit,p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize)});[['q',f.q],['source',f.source],['actor',f.actor],['action',f.action],['resource_type',f.resourceType],['outcome',f.outcome],['from',f.from],['to',f.to]].forEach(([k,v])=>{if(v)p.set(k,v)});
  try{const result=await api(`/api/v1/audit/events?${p}`);f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||10);area.className='';area.innerHTML=renderAuditPage(result);area.querySelectorAll('.audit-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==f.page){f.page=page;loadAuditPage()}}));document.getElementById('auditPageSize')?.addEventListener('change',event=>{f.pageSize=Number(event.target.value);f.page=1;loadAuditPage()});bindAuditToggles(area)}catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}

async function accessPage(){pageMeta('Acces','Mapări grupuri LDAP/OIDC către roluri');const [roles,maps]=await Promise.all([api('/api/v1/rbac/roles'),api('/api/v1/rbac/group-mappings')]);content.innerHTML=`${panel('Adaugă mapare',`<form id="mappingForm" class="detail-grid"><label>Provider<select id="mapProvider"><option value="ldap">LDAP</option><option value="oidc">OIDC</option><option value="any">Oricare</option></select></label><label>Grup<input id="mapGroup" required placeholder="VM-DOC-Operators"></label><label>Rol<select id="mapRole">${roles.map(r=>`<option value="${e(r.name)}">${e(r.name)}</option>`).join('')}</select></label><label class="form-submit"><button type="submit">Adaugă</button></label></form>`)}${panel('Mapări existente',maps.length?`<div class="table-wrap"><table><thead><tr><th>Provider</th><th>Grup</th><th>Rol</th><th></th></tr></thead><tbody>${maps.map(m=>`<tr><td>${e(m.provider)}</td><td class="mono">${e(m.group_name)}</td><td>${badge(m.role)}</td><td><button class="small danger del-map" data-id="${m.id}">Șterge</button></td></tr>`).join('')}</tbody></table></div>`:empty('Nu există mapări.'))}`;
  document.getElementById('mappingForm').onsubmit=async ev=>{ev.preventDefault();await api('/api/v1/rbac/group-mappings',{method:'POST',body:JSON.stringify({provider:document.getElementById('mapProvider').value,group_name:document.getElementById('mapGroup').value.trim(),role:document.getElementById('mapRole').value})});toast('Mapare creată.');accessPage()};content.querySelectorAll('.del-map').forEach(b=>b.onclick=async()=>{await api(`/api/v1/rbac/group-mappings/${b.dataset.id}`,{method:'DELETE'});toast('Mapare ștearsă.');accessPage()})
}


// 0.20.17 · generic table sorting for rendered UI tables.
const tableSortCollator=new Intl.Collator('ro',{numeric:true,sensitivity:'base'});
const tableSortActionHeaders=new Set(['acțiuni','actiuni','actions']);
function tableSortHeaderLabel(th){return String(th?.textContent||'').replace(/\s+/g,' ').trim()}
function tableSortIsEligible(th){
  if(!th||th.dataset.sortable==='false'||th.closest('table')?.dataset.sortable==='false')return false;
  const label=tableSortHeaderLabel(th);if(!label||tableSortActionHeaders.has(label.toLocaleLowerCase('ro')))return false;
  if(th.classList.contains('vm-select-col')||th.querySelector('input[type="checkbox"],button,select'))return false;
  return true;
}
function tableSortCellText(cell){
  if(!cell)return '';
  if(cell.dataset.sortValue!=null)return String(cell.dataset.sortValue).trim();
  const select=cell.querySelector('select');if(select)return String(select.options[select.selectedIndex]?.text||select.value||'').trim();
  const input=cell.querySelector('input');if(input){if(input.type==='checkbox')return input.checked?'1':'0';return String(input.value||'').trim()}
  return String(cell.textContent||'').replace(/\s+/g,' ').trim();
}
function tableSortComparable(raw){
  const text=String(raw??'').trim();if(!text||text==='—'||text==='-')return {kind:'empty',value:''};
  const dateMatch=text.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})(?:[, ]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if(dateMatch){const [,d,m,y,hh='0',mm='0',ss='0']=dateMatch;return {kind:'number',value:Date.UTC(Number(y),Number(m)-1,Number(d),Number(hh),Number(mm),Number(ss))}}
  if(/^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2})?/.test(text)){const parsed=Date.parse(text);if(Number.isFinite(parsed))return {kind:'number',value:parsed}}
  const sizeMatch=text.match(/^(-?[\d.,]+)\s*(B|KB|MB|GB|TB|KIB|MIB|GIB|TIB)$/i);
  if(sizeMatch){const units={B:1,KB:1e3,MB:1e6,GB:1e9,TB:1e12,KIB:1024,MIB:1048576,GIB:1073741824,TIB:1099511627776},n=Number(sizeMatch[1].replace(/\.(?=\d{3}(?:\D|$))/g,'').replace(',','.'));if(Number.isFinite(n))return {kind:'number',value:n*units[sizeMatch[2].toUpperCase()]}}
  const compact=text.replace(/\s/g,'');
  if(/^-?\d{1,3}(?:\.\d{3})*(?:,\d+)?%?$/.test(compact)){const n=Number(compact.replace('%','').replace(/\./g,'').replace(',','.'));if(Number.isFinite(n))return {kind:'number',value:n}}
  if(/^-?\d+(?:[.,]\d+)?%?$/.test(compact)){const n=Number(compact.replace('%','').replace(',','.'));if(Number.isFinite(n))return {kind:'number',value:n}}
  return {kind:'text',value:text};
}
function tableSortCompare(a,b){
  if(a.kind==='empty'&&b.kind==='empty')return 0;if(a.kind==='empty')return 1;if(b.kind==='empty')return -1;
  if(a.kind==='number'&&b.kind==='number')return a.value-b.value;
  return tableSortCollator.compare(String(a.value),String(b.value));
}
function tableSortGroups(tbody){
  const rows=[...tbody.rows],groups=[];
  for(let i=0;i<rows.length;i++){
    const row=rows[i];if(row.classList.contains('audit-detail-row'))continue;
    const group=[row];while(i+1<rows.length&&rows[i+1].classList.contains('audit-detail-row'))group.push(rows[++i]);groups.push(group);
  }
  return groups;
}
function sortTableByHeader(th){
  const table=th.closest('table'),tbody=table?.tBodies?.[0];if(!table||!tbody)return;
  const headerRow=th.parentElement,index=[...headerRow.children].indexOf(th);if(index<0)return;
  const currentColumn=Number(table.dataset.sortColumn),currentDirection=table.dataset.sortDirection||'';
  const direction=currentColumn===index&&currentDirection==='asc'?'desc':'asc',factor=direction==='asc'?1:-1;
  const groups=tableSortGroups(tbody).map((group,original)=>({group,original,key:tableSortComparable(tableSortCellText(group[0].cells[index]))}));
  groups.sort((a,b)=>{const cmp=tableSortCompare(a.key,b.key);return cmp?cmp*factor:a.original-b.original});
  const fragment=document.createDocumentFragment();groups.forEach(({group})=>group.forEach(row=>fragment.appendChild(row)));tbody.appendChild(fragment);
  table.dataset.sortColumn=String(index);table.dataset.sortDirection=direction;
  [...table.tHead.querySelectorAll('th')].forEach(header=>{header.classList.remove('sort-asc','sort-desc');if(header.classList.contains('sortable-column'))header.setAttribute('aria-sort','none')});
  th.classList.add(direction==='asc'?'sort-asc':'sort-desc');th.setAttribute('aria-sort',direction==='asc'?'ascending':'descending');
  th.title=direction==='asc'?'Sortat crescător · click pentru descrescător':'Sortat descrescător · click pentru crescător';
}
function enhanceSortableTables(root=document){
  const tables=[];if(root?.matches?.('table'))tables.push(root);root?.querySelectorAll?.('table').forEach(table=>tables.push(table));
  tables.forEach(table=>{if(!table.tHead||!table.tBodies.length||table.dataset.sortable==='false')return;const row=table.tHead.rows[table.tHead.rows.length-1];if(!row)return;[...row.cells].forEach(th=>{if(!tableSortIsEligible(th))return;th.classList.add('sortable-column');th.setAttribute('tabindex','0');th.setAttribute('aria-sort',th.getAttribute('aria-sort')||'none');th.title=th.title||'Sortează rândurile afișate'});});
}
function initSortableTables(){
  enhanceSortableTables(document);
  document.addEventListener('click',event=>{const th=event.target.closest?.('th.sortable-column');if(!th)return;if(event.target.closest('button,a,input,select,label')&&event.target!==th)return;sortTableByHeader(th)});
  document.addEventListener('keydown',event=>{const th=event.target.closest?.('th.sortable-column');if(!th||!['Enter',' '].includes(event.key))return;event.preventDefault();sortTableByHeader(th)});
  const observer=new MutationObserver(mutations=>mutations.forEach(mutation=>mutation.addedNodes.forEach(node=>{if(node.nodeType===1)enhanceSortableTables(node)})));observer.observe(document.body,{childList:true,subtree:true});
}
initSortableTables();

document.getElementById('logoutButton').onclick=async()=>{await api('/api/v1/auth/logout',{method:'POST'});location.href='/login'};
document.getElementById('themeButton').onclick=()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;localStorage.setItem('vm-doc-theme',next)};
const savedTheme=localStorage.getItem('vm-doc-theme');if(savedTheme)document.documentElement.dataset.theme=savedTheme;
bindRichTextToolbars();
enhanceSearchableSelects(document);searchableSelectObserver.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['open','disabled','multiple']});
window.addEventListener('hashchange',route);
document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
init();

// --- 0.19.9 UI consistency overrides ---
function queryWithoutPaging(query){const p=new URLSearchParams(query||'');p.delete('page');p.delete('page_size');return p.toString()}
function updateBackupExportLink(){const link=document.getElementById('exportVeeamVMs');if(!link)return;const q=queryWithoutPaging(veeamVMQuery());link.href=`/api/v1/veeam/vms/export${q?`?${q}`:''}`}
function updateMonitoringExportLinks(){const vm=document.getElementById('exportMonitoringVMs'),target=document.getElementById('exportMonitoringTargets');if(vm){const q=queryWithoutPaging(monitoringVMQuery());vm.href=`/api/v1/monitoring/vms/export${q?`?${q}`:''}`}if(target){const q=queryWithoutPaging(monitoringTargetQuery());target.href=`/api/v1/monitoring/targets/export${q?`?${q}`:''}`}}
function backupSectionNavigation(selected){const items=[['backup','Backup','Protecție și stare pe VM'],['sources','Surse & sincronizări','Veeam și istoric sincronizare']];return `<nav class="monitoring-section-tabs backup-section-tabs" aria-label="Secțiuni backup">${items.map(([code,label,help])=>`<a href="#backup/${code}" class="${selected===code?'active':''}"><span>${e(label)}</span><small>${e(help)}</small></a>`).join('')}</nav>`}
async function backupPage(section='backup'){
  section=section==='sources'?'sources':'backup';pageMeta('Backup','Veeam Backup & Replication · protecție, retenție, GFS, storage și sincronizare');
  if((location.hash||'')==='#backup')history.replaceState(null,'','#backup/backup');
  const nav=backupSectionNavigation(section);
  if(section==='sources'){
    const paging=state.veeamRunPaging||{page:1,pageSize:10};const [sources,runs]=await Promise.all([api('/api/v1/veeam/sources'),api(`/api/v1/veeam/sync-runs?page=${paging.page}&page_size=${paging.pageSize}`)]);state.veeamSources=Array.isArray(sources)?sources:[];
    const sourceRows=state.veeamSources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${e(s.username)}</td><td class="mono">${e(s.api_version||'—')}</td><td>${veeamIntervalLabel(s.sync_interval_minutes)}<div class="muted">${s.enabled?'Activ':'Dezactivat'}</div></td><td>${dt(s.last_success_at)}${s.last_sync_at?`<div class="muted">Încercare: ${dt(s.last_sync_at)}</div>`:''}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions">${can('veeam.manage')?`<button class="small secondary veeam-action" data-action="test" data-id="${s.id}">Test</button><button class="small veeam-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary veeam-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger veeam-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
    const tools=can('veeam.manage')?'<button id="syncAllVeeam">Sincronizează toate</button><button id="newVeeam" class="secondary">Adaugă sursă</button>':'';
    const hint=`<div class="baseline-hint"><strong>Corelare:</strong><span>vm-doc corelează după <b>numele exact al VM-ului</b> și citește atât obiectele de backup, cât și VM-urile configurate în <b>virtualMachines.includes</b>. Storage-ul, programarea, retenția și politicile GFS sunt păstrate separat de declarațiile cron administrate manual.</span></div>`;
    content.innerHTML=`<div class="backup-workspace">${nav}${panel('Surse Veeam',`${hint}${sourceRows?`<div class="table-wrap"><table><thead><tr><th>Sursă</th><th>Utilizator</th><th>REST API</th><th>Program</th><th>Ultima sincronizare</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse Veeam configurate.')}`,tools)}${panel('Ultimele sincronizări',renderVeeamRuns(runs))}</div>`;
    document.getElementById('newVeeam')?.addEventListener('click',()=>openVeeam());document.getElementById('syncAllVeeam')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/veeam/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări Veeam introduse în coadă.`);setTimeout(()=>backupPage('sources'),1200)}catch(err){toast(err.message,true)}});content.querySelectorAll('.veeam-action').forEach(b=>b.addEventListener('click',()=>veeamAction(b.dataset.action,Number(b.dataset.id))));content.querySelectorAll('.veeam-run-page').forEach(b=>b.addEventListener('click',()=>{const page=Number(b.dataset.page);if(page>0&&page!==state.veeamRunPaging.page){state.veeamRunPaging.page=page;backupPage('sources')}}));document.getElementById('veeamRunPageSize')?.addEventListener('change',event=>{state.veeamRunPaging.pageSize=Number(event.target.value);state.veeamRunPaging.page=1;backupPage('sources')});return;
  }
  const vmBackups=await api(`/api/v1/veeam/vms?${veeamVMQuery()}`);
  const cards=`<div class="cards backup-summary-cards"><div class="card"><div class="label">Toate VM-urile</div><div id="backupTotal" class="value">${Number(vmBackups.total||0)}</div><div class="muted">Conform filtrelor curente</div></div><div class="card"><div class="label">VM protejate</div><div id="backupProtected" class="value">0</div><div id="backupProtectedPct" class="backup-percent">0%</div></div><div class="card"><div class="label">În job Veeam</div><div id="backupConfigured" class="value">0</div><div id="backupConfiguredPct" class="backup-percent">0%</div></div><div class="card"><div class="label">Așteaptă primul backup</div><div id="backupWaiting" class="value">0</div><div id="backupWaitingPct" class="backup-percent">0%</div></div><div class="card"><div class="label">VM neprotejate</div><div id="backupUnprotected" class="value">0</div><div id="backupUnprotectedPct" class="backup-percent">0%</div></div><div class="card"><div class="label">Backup în afara jobului</div><div id="backupStale" class="value">0</div><div id="backupStalePct" class="backup-percent">0%</div></div><div class="card"><div class="label">Neverificate</div><div id="backupNever" class="value">0</div><div id="backupNeverPct" class="backup-percent">0%</div></div><div class="card"><div class="label">Failed / Warning</div><div id="backupFailedWarning" class="value compact">0 / 0</div></div></div>`;
  content.innerHTML=`<div class="backup-workspace">${nav}${cards}${panel('Backup pe VM-uri',`<div id="veeamVMTableArea">${renderVeeamVMs(vmBackups)}</div>`,`<a id="exportVeeamVMs" class="button secondary" href="/api/v1/veeam/vms/export">Export Excel</a>`)}</div>`;updateVeeamSummaryCards(vmBackups);bindVeeamVMControls();updateBackupExportLink();
}

function serviceExportQuery(){const f=state.serviceFilters,p=new URLSearchParams();if(f.q)p.set('q',f.q);if(f.domain)p.set('domain',f.domain);if(f.category)p.set('category',f.category);if(f.criticality)p.set('criticality',f.criticality);if(f.docStatus)p.set('doc_status',f.docStatus);if(f.common)p.set('common',f.common);return p.toString()}
function renderInternalServicesCatalog(){
  const f=state.serviceFilters;f.page=Number(f.page||1);f.pageSize=Number(f.pageSize||10);const filtered=internalServicesCache.filter(service=>serviceMatchesFilters(service,f)),total=filtered.length,pages=Math.max(1,Math.ceil(total/f.pageSize));if(f.page>pages)f.page=pages;const startIndex=(f.page-1)*f.pageSize,visible=filtered.slice(startIndex,startIndex+f.pageSize);
  const active=internalServicesCache.filter(service=>service.active).length,linkedVMs=internalServicesCache.reduce((sum,service)=>sum+Number(service.vm_count||0),0),configured=internalServicesCache.filter(service=>Number(service.role_mapping_count||0)>0).length;
  const domains=[...new Set(internalServicesCache.flatMap(s=>(s.classifications||[]).map(c=>c.architectural_domain)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro')),categories=[...new Set(internalServicesCache.flatMap(s=>(s.classifications||[]).map(c=>c.itil_category)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro')),option=(v,current)=>`<option value="${e(v)}" ${v===current?'selected':''}>${e(v)}</option>`;
  const rows=visible.map(service=>`<tr><td><a href="#services/${service.id}"><strong>${e(service.name)}</strong></a>${service.is_common?` <span class="common-service-pill ${service.implicit_global?'global':''}">${service.implicit_global?'GLOBAL':'COMUN'}</span>`:''}${service.description?`<div class="muted service-description-crop" title="${e(service.description)}">${e(cropText(service.description))}</div>`:''}</td><td>${serviceClassificationSummary(service.classifications)}</td><td>${serviceSolutionSummary(service.solution_types)}</td><td class="mono">${e(service.service_code||'—')}</td><td>${criticalityBadge(service.criticality)}</td><td>${badge(service.documentation_status||'draft')}</td><td>${service.vm_count||0}</td><td>${service.dependency_count||0}</td><td>${service.active?badge('active'):badge('disabled')}</td></tr>`).join('');
  const filters=`<div class="service-filter-shell ui-filter-shell"><label class="service-search-field"><span>Căutare serviciu</span><input id="serviceSearch" type="search" value="${e(f.q)}" placeholder="Denumire, cod sau descriere"></label><div class="service-filter-grid"><label><span>Domeniu</span><select id="serviceDomainFilter"><option value="">Toate domeniile</option>${domains.map(v=>option(v,f.domain)).join('')}</select></label><label><span>Categorie</span><select id="serviceCategoryFilter"><option value="">Toate categoriile</option>${categories.map(v=>option(v,f.category)).join('')}</select></label><label><span>Criticitate</span><select id="serviceCriticalityFilter"><option value="">Toate</option>${Object.entries(criticalityLabels).map(([v,l])=>`<option value="${v}" ${f.criticality===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label><span>Documentație</span><select id="serviceDocFilter"><option value="">Toate</option>${Object.entries(documentationStatusLabels).map(([v,l])=>`<option value="${v}" ${f.docStatus===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label><span>Tip serviciu</span><select id="serviceCommonFilter"><option value="">Toate serviciile</option><option value="normal" ${f.common==='normal'?'selected':''}>Servicii aplicație</option><option value="common" ${f.common==='common'?'selected':''}>Servicii comune</option><option value="global" ${f.common==='global'?'selected':''}>Globale implicite</option></select></label></div><div class="service-filter-actions"><div id="serviceActiveFilters" class="vm-active-filters">${serviceActiveFilterHTML()}</div><button id="clearServiceFilters" type="button" class="secondary service-clear-filter">Resetează filtrele</button></div></div>`;
  const from=total?startIndex+1:0,to=Math.min(startIndex+f.pageSize,total),pager=`<div class="pagination"><span>Afișate ${from.toLocaleString('ro-RO')}–${to.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="servicePageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'service-page')}</div></div>`;
  const exportQ=serviceExportQuery(),tools=`<a class="button secondary" href="/api/v1/services/export${exportQ?`?${exportQ}`:''}">Export Excel</a>${can('services.manage')?'<button id="newInternalService">Adaugă serviciu</button>':''}`;
  content.innerHTML=`<div class="service-page-workspace"><div class="cards vm-list-summary-cards"><div class="card"><div class="label">Servicii definite</div><div class="value">${internalServicesCache.length}</div></div><div class="card"><div class="label">Servicii active</div><div class="value">${active}</div></div><div class="card"><div class="label">VM-uri asociate</div><div class="value">${linkedVMs}</div></div><div class="card"><div class="label">Cu roluri observate</div><div class="value">${configured}</div></div></div>${panel('Catalog servicii interne',`${filters}<div class="service-filter-summary muted">${filtered.length} din ${internalServicesCache.length} servicii</div>${rows?`<div class="table-wrap service-catalog-table"><table><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie</th><th>Tip soluție</th><th>Cod</th><th>Criticitate</th><th>Documentație</th><th>VM-uri</th><th>Dependențe</th><th>Stare</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există servicii pentru filtrele selectate.')}${pager}`,tools)}${panel('Model de încadrare','<div class="service-flow"><span>Domeniu</span><b>→</b><span>Categorie</span><b>→</b><span>Serviciu intern</span><b>→</b><span>Layer</span><b>→</b><span>Rol tehnic</span><b>→</b><span>Tip soluție</span></div><p class="muted service-flow-note">Serviciile comune (AD, DNS, LDAP, NTP etc.) sunt modelate ca dependențe și pot fi globale implicit sau asociate explicit.</p>')}</div>`;
  document.getElementById('newInternalService')?.addEventListener('click',()=>openInternalService());let timer;document.getElementById('serviceSearch')?.addEventListener('input',event=>{clearTimeout(timer);const input=event.currentTarget,value=input.value,pos=input.selectionStart??value.length;timer=setTimeout(()=>{f.q=value.trim();f.page=1;renderInternalServicesCatalog();const search=document.getElementById('serviceSearch');if(search){search.focus({preventScroll:true});const p=Math.min(pos,search.value.length);search.setSelectionRange(p,p)}},250)});
  [['serviceDomainFilter','domain'],['serviceCategoryFilter','category'],['serviceCriticalityFilter','criticality'],['serviceDocFilter','docStatus'],['serviceCommonFilter','common']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{f[key]=event.target.value;f.page=1;renderInternalServicesCatalog()}));document.getElementById('clearServiceFilters')?.addEventListener('click',()=>{state.serviceFilters={q:'',domain:'',category:'',criticality:'',docStatus:'',common:'',page:1,pageSize:f.pageSize||10};renderInternalServicesCatalog()});document.querySelectorAll('.service-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==f.page){f.page=page;renderInternalServicesCatalog()}}));document.getElementById('servicePageSize')?.addEventListener('change',event=>{f.pageSize=Number(event.target.value);f.page=1;renderInternalServicesCatalog()});
}

function externalCollapsedPanel(title,body,open=false){return `<details class="panel collapsible-panel external-add-panel" ${open?'open':''}><summary class="collapsible-panel-summary"><span>${e(title)}</span><span class="muted">Click pentru ${open?'închidere':'adăugare'}</span></summary><div class="collapsible-panel-body">${body}</div></details>`}
async function renderExternalNetworks(networks){
  const edit=networks.find(x=>Number(x.id)===Number(state.externalNetworkEdit))||null,rows=networks.map(n=>`<tr><td>${externalNetworkBadge(n)}<div class="muted mono">${e(n.code)}</div></td><td>${e(externalZoneTypeLabels[n.zone_type]||n.zone_type)}</td><td>${externalRiskBadge(n.risk_level)}</td><td>${e(externalTrustLabels[n.trust_level]||n.trust_level)}</td><td class="mono">${e(n.cidrs||'—')}</td><td>${n.system_count||0}</td><td>${n.connection_count||0}</td><td>${n.active?badge('active'):badge('disabled')}</td>${can('external.manage')?`<td><div class="actions"><button class="small secondary edit-external-network" data-id="${n.id}">Editează</button><button class="small danger delete-external-network" data-id="${n.id}" ${Number(n.system_count||0)>0?'disabled title="Rețeaua are sisteme asociate"':''}>Șterge</button></div></td>`:''}</tr>`).join('');
  const editor=can('external.manage')?(edit?panel('Editează rețeaua externă',`<div class="external-edit-shell">${externalNetworkForm(edit)}</div>`):externalCollapsedPanel('Adaugă rețea externă',externalNetworkForm(null))):'';content.innerHTML+=`${editor}${panel('Rețele externe',rows?`<div class="table-wrap"><table><thead><tr><th>Rețea / culoare</th><th>Tip</th><th>Risc</th><th>Trust</th><th>CIDR</th><th>Sisteme</th><th>Conexiuni</th><th>Stare</th>${can('external.manage')?'<th></th>':''}</tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există rețele externe definite.'))}`;bindExternalNetworkForm(edit);document.querySelectorAll('.edit-external-network').forEach(b=>b.addEventListener('click',()=>{state.externalNetworkEdit=Number(b.dataset.id);externalSystemsPage('networks')}));document.querySelectorAll('.delete-external-network').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Ștergi această rețea externă?'))return;try{await api(`/api/v1/external-networks/${b.dataset.id}`,{method:'DELETE'});toast('Rețeaua externă a fost ștearsă.');externalSystemsPage('networks')}catch(err){toast(err.message,true)}}));
}
async function renderExternalSystems(systems,networks){
  const f=state.externalFilters,q=f.q.toLocaleLowerCase('ro'),filtered=systems.filter(item=>(!q||`${item.name} ${item.hostname} ${item.ip_addresses} ${item.owner_organization}`.toLocaleLowerCase('ro').includes(q))&&(!f.network||String(item.network_id||'')===String(f.network))&&(f.status==='all'||(f.status==='active'?item.active:!item.active))),internet=systems.filter(x=>x.active&&x.network_zone_type==='internet').length;
  const filters=`<div class="filterbar external-filterbar ui-filter-shell"><label><span>Caută</span><input id="externalSearch" type="search" value="${e(f.q)}" placeholder="Nume, hostname, IP, organizație"></label><label><span>Rețea</span><select id="externalNetworkFilter"><option value="">Toate</option>${networks.map(n=>`<option value="${n.id}" ${String(f.network)===String(n.id)?'selected':''}>${e(n.name)}</option>`).join('')}</select></label><label><span>Stare</span><select id="externalStatusFilter"><option value="active" ${f.status==='active'?'selected':''}>Active</option><option value="inactive" ${f.status==='inactive'?'selected':''}>Inactive</option><option value="all" ${f.status==='all'?'selected':''}>Toate</option></select></label><button id="externalReset" class="secondary" type="button">Resetează</button></div>`,rows=filtered.map(item=>`<tr><td><a href="#external/${item.id}"><strong>${e(item.name)}</strong></a><div class="muted">${e(externalTypeLabels[item.system_type]||item.system_type)}</div></td><td class="mono">${e(item.hostname||item.ip_addresses||'—')}</td><td>${externalNetworkBadge(item)}</td><td>${externalRiskBadge(item.network_risk_level)}</td><td>${e(item.owner_organization||'—')}</td><td>${item.connection_count||0}</td><td>${item.active?badge('active'):badge('disabled')}</td><td><a class="button-link small secondary" href="#external/${item.id}">Deschide</a></td></tr>`).join('');
  content.innerHTML+=`<div class="cards"><div class="card"><div class="label">Sisteme definite</div><div class="value">${systems.length}</div></div><div class="card"><div class="label">Active</div><div class="value">${systems.filter(x=>x.active).length}</div></div><div class="card"><div class="label">În Internet</div><div class="value">${internet}</div></div><div class="card"><div class="label">Conexiuni</div><div class="value">${systems.reduce((n,x)=>n+Number(x.connection_count||0),0)}</div></div></div>${can('external.manage')?externalCollapsedPanel('Adaugă sistem extern',externalSystemForm(null,networks)):''}${panel('Sisteme externe',`${filters}${rows?`<div class="table-wrap"><table><thead><tr><th>Sistem</th><th>Adresă</th><th>Rețea</th><th>Risc</th><th>Organizație</th><th>Conexiuni</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există sisteme pentru filtrele selectate.')}`)}`;bindExternalSystemForm(null);let timer;document.getElementById('externalSearch')?.addEventListener('input',event=>{clearTimeout(timer);const input=event.currentTarget,pos=input.selectionStart??input.value.length,value=input.value;timer=setTimeout(async()=>{f.q=value.trim();await externalSystemsPage('systems');const next=document.getElementById('externalSearch');if(next){next.focus();const p=Math.min(pos,next.value.length);next.setSelectionRange(p,p)}},200)});document.getElementById('externalNetworkFilter')?.addEventListener('change',event=>{f.network=event.target.value;externalSystemsPage('systems')});document.getElementById('externalStatusFilter')?.addEventListener('change',event=>{f.status=event.target.value;externalSystemsPage('systems')});document.getElementById('externalReset')?.addEventListener('click',()=>{state.externalFilters={q:'',network:'',status:'active'};externalSystemsPage('systems')});
}
