package audit

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"
)

type Event struct {
	Source        string
	ActorUserID   *int64
	ActorUsername string
	Action        string
	ResourceType  string
	ResourceID    string
	Outcome       string
	RequestID     string
	IPAddress     string
	UserAgent     string
	Details       any
}

type Service struct{ DB *sql.DB }

func (s Service) Log(ctx context.Context, e Event) error {
	if e.Source == "" {
		e.Source = "server"
	}
	if e.Outcome == "" {
		e.Outcome = "success"
	}
	b, err := json.Marshal(e.Details)
	if err != nil {
		return err
	}
	if string(b) == "null" {
		b = []byte("{}")
	}
	_, err = s.DB.ExecContext(ctx, `INSERT INTO audit_events(occurred_at,source,actor_user_id,actor_username,action,resource_type,resource_id,outcome,request_id,ip_address,user_agent,details_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, time.Now().UTC(), e.Source, e.ActorUserID, e.ActorUsername, e.Action, e.ResourceType, e.ResourceID, e.Outcome, e.RequestID, e.IPAddress, e.UserAgent, b)
	return err
}

type Record struct {
	ID                int64           `json:"id"`
	OccurredAt        time.Time       `json:"occurred_at"`
	Source            string          `json:"source"`
	ActorUsername     string          `json:"actor_username"`
	Action            string          `json:"action"`
	ActionLabel       string          `json:"action_label"`
	ActionDescription string          `json:"action_description"`
	Operation         string          `json:"operation"`
	ResourceType      string          `json:"resource_type"`
	ResourceID        string          `json:"resource_id"`
	Outcome           string          `json:"outcome"`
	IPAddress         string          `json:"ip_address"`
	RequestID         string          `json:"request_id,omitempty"`
	ResourceLabel     string          `json:"resource_label,omitempty"`
	ResourceURL       string          `json:"resource_url,omitempty"`
	ContextVMID       int64           `json:"vm_id,omitempty"`
	ContextVMName     string          `json:"vm_name,omitempty"`
	ContextServiceIDs []int64         `json:"service_ids,omitempty"`
	ContextServices   []string        `json:"service_names,omitempty"`
	Details           json.RawMessage `json:"details"`
}

const (
	defaultPageSize = 10
	maxPageSize     = 200
)

type Page struct {
	Items    []Record `json:"items"`
	Page     int      `json:"page"`
	PageSize int      `json:"page_size"`
	Total    int      `json:"total"`
	Pages    int      `json:"pages"`
}

type Filter struct {
	Page         int
	PageSize     int
	Query        string
	Source       string
	Actor        string
	Action       string
	ResourceType string
	Outcome      string
	Area         string
	VMID         int64
	ServiceID    int64
	From         *time.Time
	To           *time.Time
}

type Facets struct {
	Sources       []string `json:"sources"`
	Actors        []string `json:"actors"`
	Actions       []string `json:"actions"`
	ResourceTypes []string `json:"resource_types"`
	Outcomes      []string `json:"outcomes"`
}

func NormalizePagination(page, pageSize int) (int, int) {
	if page < 1 {
		page = 1
	}
	if pageSize <= 0 {
		pageSize = defaultPageSize
	}
	if pageSize > maxPageSize {
		pageSize = maxPageSize
	}
	return page, pageSize
}

func (s Service) List(ctx context.Context, page, pageSize int) (Page, error) {
	return s.ListFiltered(ctx, Filter{Page: page, PageSize: pageSize})
}

func (s Service) ListFiltered(ctx context.Context, filter Filter) (Page, error) {
	filter.Page, filter.PageSize = NormalizePagination(filter.Page, filter.PageSize)
	where, args := auditScopeWhere(filter)
	if q := strings.TrimSpace(filter.Query); q != "" {
		like := "%" + q + "%"
		where = append(where, `(actor_username LIKE ? OR action LIKE ? OR resource_type LIKE ? OR resource_id LIKE ? OR ip_address LIKE ? OR details_json LIKE ?)`)
		args = append(args, like, like, like, like, like, like)
	}
	addEqual := func(column, value string) {
		if value = strings.TrimSpace(value); value != "" {
			where = append(where, column+"=?")
			args = append(args, value)
		}
	}
	addEqual("source", filter.Source)
	addEqual("actor_username", filter.Actor)
	addEqual("action", filter.Action)
	addEqual("resource_type", filter.ResourceType)
	addEqual("outcome", filter.Outcome)
	if area := strings.TrimSpace(filter.Area); area != "" {
		switch area {
		case "configuration":
			where = append(where, `(action LIKE 'vm.%' OR action LIKE 'internal_service.%' OR action LIKE 'service.dependency.%')`)
		case "docker":
			where = append(where, `(resource_type LIKE 'docker_%' OR action LIKE 'docker.%')`)
		case "database":
			where = append(where, `(resource_type LIKE 'database_%' OR action LIKE 'database.%')`)
		case "web":
			where = append(where, `(resource_type LIKE 'web_%' OR action LIKE 'web.%')`)
		case "documents":
			where = append(where, `(resource_type='generated_document' OR action LIKE '%document%')`)
		case "operations":
			where = append(where, `(action LIKE 'collection.%' OR action LIKE 'monitoring.%' OR action LIKE 'vm.backup.%' OR action LIKE 'software.%')`)
		}
	}
	if filter.From != nil {
		where = append(where, "occurred_at>=?")
		args = append(args, *filter.From)
	}
	if filter.To != nil {
		where = append(where, "occurred_at<?")
		args = append(args, *filter.To)
	}
	clause := ""
	if len(where) > 0 {
		clause = " WHERE " + strings.Join(where, " AND ")
	}
	result := Page{Items: make([]Record, 0), Page: filter.Page, PageSize: filter.PageSize}
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM audit_events`+clause, args...).Scan(&result.Total); err != nil {
		return Page{}, err
	}
	if result.Total == 0 {
		return result, nil
	}
	result.Pages = (result.Total + result.PageSize - 1) / result.PageSize
	if result.Page > result.Pages {
		result.Page = result.Pages
	}
	offset := (result.Page - 1) * result.PageSize
	queryArgs := append(append([]any(nil), args...), result.PageSize, offset)
	rows, err := s.DB.QueryContext(ctx, `SELECT id,occurred_at,source,actor_username,action,resource_type,resource_id,outcome,request_id,ip_address,details_json FROM audit_events`+clause+` ORDER BY id DESC LIMIT ? OFFSET ?`, queryArgs...)
	if err != nil {
		return Page{}, err
	}
	defer rows.Close()
	for rows.Next() {
		var r Record
		if err := rows.Scan(&r.ID, &r.OccurredAt, &r.Source, &r.ActorUsername, &r.Action, &r.ResourceType, &r.ResourceID, &r.Outcome, &r.RequestID, &r.IPAddress, &r.Details); err != nil {
			return Page{}, err
		}
		r.ActionLabel, r.ActionDescription, r.Operation = DescribeAction(r.Action)
		s.enrichRecord(ctx, &r)
		result.Items = append(result.Items, r)
	}
	return result, rows.Err()
}

func (s Service) Facets(ctx context.Context) (Facets, error) {
	return s.FacetsFiltered(ctx, Filter{})
}

func (s Service) FacetsFiltered(ctx context.Context, filter Filter) (Facets, error) {
	var out Facets
	where, args := auditScopeWhere(filter)
	clause := ""
	if len(where) > 0 {
		clause = " WHERE " + strings.Join(where, " AND ")
	}
	queries := []struct {
		column string
		target *[]string
		limit  string
	}{
		{"source", &out.Sources, ""},
		{"actor_username", &out.Actors, " LIMIT 500"},
		{"action", &out.Actions, ""},
		{"resource_type", &out.ResourceTypes, ""},
		{"outcome", &out.Outcomes, ""},
	}
	for _, item := range queries {
		query := `SELECT DISTINCT ` + item.column + ` FROM audit_events` + clause
		if clause == "" {
			query += ` WHERE ` + item.column + `<>''`
		} else {
			query += ` AND ` + item.column + `<>''`
		}
		query += ` ORDER BY ` + item.column + item.limit
		rows, err := s.DB.QueryContext(ctx, query, args...)
		if err != nil {
			return Facets{}, err
		}
		values := make([]string, 0)
		for rows.Next() {
			var value string
			if err := rows.Scan(&value); err != nil {
				rows.Close()
				return Facets{}, err
			}
			values = append(values, value)
		}
		if err := rows.Close(); err != nil {
			return Facets{}, err
		}
		*item.target = values
	}
	return out, nil
}

func auditScopeWhere(filter Filter) ([]string, []any) {
	where := make([]string, 0, 2)
	args := make([]any, 0, 24)
	if filter.VMID > 0 {
		id := strconv.FormatInt(filter.VMID, 10)
		pattern := `"vm_id"[[:space:]]*:[[:space:]]*` + id + `([^0-9]|$)`
		where = append(where, `(
			(resource_type='virtual_machine' AND resource_id=?) OR
			details_json REGEXP ? OR
			(resource_type='docker_container' AND EXISTS (SELECT 1 FROM docker_containers c WHERE c.id=CAST(audit_events.resource_id AS UNSIGNED) AND c.vm_id=?)) OR
			(resource_type='database_instance' AND EXISTS (SELECT 1 FROM database_instances di WHERE di.id=CAST(audit_events.resource_id AS UNSIGNED) AND di.vm_id=?)) OR
			(resource_type='database_catalog' AND EXISTS (SELECT 1 FROM database_catalogs dc WHERE dc.id=CAST(audit_events.resource_id AS UNSIGNED) AND dc.vm_id=?)) OR
			(resource_type='web_site' AND EXISTS (SELECT 1 FROM web_sites ws WHERE ws.id=CAST(audit_events.resource_id AS UNSIGNED) AND ws.vm_id=?)) OR
			(resource_type='web_server' AND EXISTS (SELECT 1 FROM web_servers wsv WHERE wsv.id=CAST(audit_events.resource_id AS UNSIGNED) AND wsv.vm_id=?)) OR
			(resource_type='software_item' AND EXISTS (SELECT 1 FROM software_items si WHERE si.id=CAST(audit_events.resource_id AS UNSIGNED) AND si.vm_id=?)) OR
			(resource_type='inventory_change' AND EXISTS (SELECT 1 FROM inventory_changes ic WHERE ic.id=CAST(audit_events.resource_id AS UNSIGNED) AND ic.vm_id=?)) OR
			(resource_type='generated_document' AND EXISTS (SELECT 1 FROM generated_documents gd WHERE gd.id=CAST(audit_events.resource_id AS UNSIGNED) AND gd.vm_id=?)) OR
			(resource_type='agent' AND EXISTS (SELECT 1 FROM virtual_machines avm WHERE avm.agent_id=CAST(audit_events.resource_id AS UNSIGNED) AND avm.id=?))
		)`)
		args = append(args, id, pattern, filter.VMID, filter.VMID, filter.VMID, filter.VMID, filter.VMID, filter.VMID, filter.VMID, filter.VMID, filter.VMID)
	}
	if filter.ServiceID > 0 {
		id := strconv.FormatInt(filter.ServiceID, 10)
		keyPattern := `"(internal_service_id|service_id|target_service_id|source_service_id)"[[:space:]]*:[[:space:]]*` + id + `([^0-9]|$)`
		arrayFirstPattern := `"(service_ids|before_service_ids|after_service_ids)"[[:space:]]*:[[:space:]]*\[[[:space:]]*` + id + `([^0-9]|$)`
		arrayLaterPattern := `"(service_ids|before_service_ids|after_service_ids)"[[:space:]]*:[[:space:]]*\[[^]]*,[[:space:]]*` + id + `([^0-9]|$)`
		where = append(where, `(
			(resource_type='internal_service' AND resource_id=?) OR
			details_json REGEXP ? OR details_json REGEXP ? OR details_json REGEXP ? OR
			(resource_type='docker_container' AND EXISTS (SELECT 1 FROM docker_container_service_assignments dsa WHERE dsa.docker_container_id=CAST(audit_events.resource_id AS UNSIGNED) AND dsa.internal_service_id=?)) OR
			(resource_type='database_instance' AND EXISTS (SELECT 1 FROM database_instance_service_assignments disa WHERE disa.database_instance_id=CAST(audit_events.resource_id AS UNSIGNED) AND disa.internal_service_id=?)) OR
			(resource_type='database_catalog' AND EXISTS (SELECT 1 FROM database_catalog_service_assignments dcsa WHERE dcsa.database_catalog_id=CAST(audit_events.resource_id AS UNSIGNED) AND dcsa.internal_service_id=?)) OR
			(resource_type='web_site' AND EXISTS (SELECT 1 FROM web_site_service_assignments wssa WHERE wssa.web_site_id=CAST(audit_events.resource_id AS UNSIGNED) AND wssa.internal_service_id=?)) OR
			(resource_type='generated_document' AND EXISTS (SELECT 1 FROM generated_documents gd WHERE gd.id=CAST(audit_events.resource_id AS UNSIGNED) AND gd.internal_service_id=?)) OR
			(resource_type='internal_service_attachment' AND EXISTS (SELECT 1 FROM internal_service_attachments isa WHERE isa.id=CAST(audit_events.resource_id AS UNSIGNED) AND isa.internal_service_id=?))
		)`)
		args = append(args, id, keyPattern, arrayFirstPattern, arrayLaterPattern, filter.ServiceID, filter.ServiceID, filter.ServiceID, filter.ServiceID, filter.ServiceID, filter.ServiceID)
	}
	return where, args
}

func (s Service) enrichRecord(ctx context.Context, r *Record) {
	if r == nil {
		return
	}
	var details map[string]any
	_ = json.Unmarshal(r.Details, &details)
	if id := mapInt64(details, "vm_id"); id > 0 {
		r.ContextVMID = id
	}
	if r.ResourceType == "virtual_machine" {
		if id, _ := strconv.ParseInt(r.ResourceID, 10, 64); id > 0 {
			r.ContextVMID = id
		}
	}
	for _, key := range []string{"internal_service_id", "service_id", "target_service_id", "source_service_id"} {
		if id := mapInt64(details, key); id > 0 {
			r.ContextServiceIDs = appendUniqueInt64(r.ContextServiceIDs, id)
		}
	}
	if values, ok := details["service_ids"].([]any); ok {
		for _, v := range values {
			if id := anyInt64(v); id > 0 {
				r.ContextServiceIDs = appendUniqueInt64(r.ContextServiceIDs, id)
			}
		}
	}
	if assignments, ok := details["assignments"].([]any); ok {
		for _, raw := range assignments {
			if item, ok := raw.(map[string]any); ok {
				for _, key := range []string{"service_id", "internal_service_id"} {
					if id := mapInt64(item, key); id > 0 {
						r.ContextServiceIDs = appendUniqueInt64(r.ContextServiceIDs, id)
					}
				}
			}
		}
	}
	id, _ := strconv.ParseInt(strings.TrimSpace(r.ResourceID), 10, 64)
	switch r.ResourceType {
	case "virtual_machine":
		if id > 0 {
			_ = s.DB.QueryRowContext(ctx, `SELECT name FROM virtual_machines WHERE id=?`, id).Scan(&r.ResourceLabel)
			r.ResourceURL = fmt.Sprintf("#vms/%d/overview", id)
		}
	case "internal_service":
		if id > 0 {
			_ = s.DB.QueryRowContext(ctx, `SELECT name FROM internal_services WHERE id=?`, id).Scan(&r.ResourceLabel)
			r.ResourceURL = fmt.Sprintf("#services/%d/overview", id)
			r.ContextServiceIDs = appendUniqueInt64(r.ContextServiceIDs, id)
		}
	case "docker_container":
		if id > 0 {
			_ = s.DB.QueryRowContext(ctx, `SELECT c.name,c.vm_id,vm.name FROM docker_containers c JOIN virtual_machines vm ON vm.id=c.vm_id WHERE c.id=?`, id).Scan(&r.ResourceLabel, &r.ContextVMID, &r.ContextVMName)
			if r.ContextVMID > 0 {
				r.ResourceURL = fmt.Sprintf("#vms/%d/docker", r.ContextVMID)
			}
			s.addRecordServices(ctx, r, `SELECT internal_service_id FROM docker_container_service_assignments WHERE docker_container_id=?`, id)
		}
	case "database_instance":
		if id > 0 {
			var product, name string
			_ = s.DB.QueryRowContext(ctx, `SELECT product,instance_name,vm_id FROM database_instances WHERE id=?`, id).Scan(&product, &name, &r.ContextVMID)
			r.ResourceLabel = strings.TrimSpace(strings.TrimSpace(product + " " + name))
			if r.ContextVMID > 0 {
				r.ResourceURL = fmt.Sprintf("#vms/%d/databases", r.ContextVMID)
			}
			s.addRecordServices(ctx, r, `SELECT internal_service_id FROM database_instance_service_assignments WHERE database_instance_id=?`, id)
		}
	case "database_catalog":
		if id > 0 {
			_ = s.DB.QueryRowContext(ctx, `SELECT name,vm_id FROM database_catalogs WHERE id=?`, id).Scan(&r.ResourceLabel, &r.ContextVMID)
			if r.ContextVMID > 0 {
				r.ResourceURL = fmt.Sprintf("#vms/%d/databases", r.ContextVMID)
			}
			s.addRecordServices(ctx, r, `SELECT internal_service_id FROM database_catalog_service_assignments WHERE database_catalog_id=?`, id)
		}
	case "web_site":
		if id > 0 {
			var engine, name string
			_ = s.DB.QueryRowContext(ctx, `SELECT engine,name,vm_id FROM web_sites WHERE id=?`, id).Scan(&engine, &name, &r.ContextVMID)
			r.ResourceLabel = strings.TrimSpace(strings.TrimSpace(engine + " " + name))
			if r.ContextVMID > 0 {
				r.ResourceURL = fmt.Sprintf("#vms/%d/web", r.ContextVMID)
			}
			s.addRecordServices(ctx, r, `SELECT internal_service_id FROM web_site_service_assignments WHERE web_site_id=?`, id)
		}
	case "web_server":
		if id > 0 {
			var engine, product string
			_ = s.DB.QueryRowContext(ctx, `SELECT engine,product,vm_id FROM web_servers WHERE id=?`, id).Scan(&engine, &product, &r.ContextVMID)
			r.ResourceLabel = strings.TrimSpace(strings.TrimSpace(product + " " + engine))
			if r.ContextVMID > 0 {
				r.ResourceURL = fmt.Sprintf("#vms/%d/web", r.ContextVMID)
			}
		}
	case "software_item":
		if id > 0 {
			_ = s.DB.QueryRowContext(ctx, `SELECT name,vm_id FROM software_items WHERE id=?`, id).Scan(&r.ResourceLabel, &r.ContextVMID)
			if r.ContextVMID > 0 {
				r.ResourceURL = fmt.Sprintf("#vms/%d/software", r.ContextVMID)
			}
		}
	case "generated_document":
		if id > 0 {
			var objectType, number string
			var vmID, serviceID sql.NullInt64
			if s.DB.QueryRowContext(ctx, `SELECT object_type,document_number,vm_id,internal_service_id FROM generated_documents WHERE id=?`, id).Scan(&objectType, &number, &vmID, &serviceID) == nil {
				r.ResourceLabel = number
				if vmID.Valid {
					r.ContextVMID = vmID.Int64
					r.ResourceURL = fmt.Sprintf("#vms/%d/continuity", vmID.Int64)
				}
				if serviceID.Valid {
					r.ContextServiceIDs = appendUniqueInt64(r.ContextServiceIDs, serviceID.Int64)
					r.ResourceURL = fmt.Sprintf("#services/%d/documents", serviceID.Int64)
				}
			}
		}
	case "inventory_change":
		if id > 0 {
			var category, label string
			_ = s.DB.QueryRowContext(ctx, `SELECT category,object_label,vm_id FROM inventory_changes WHERE id=?`, id).Scan(&category, &label, &r.ContextVMID)
			r.ResourceLabel = strings.TrimSpace(label)
			if r.ResourceLabel == "" {
				r.ResourceLabel = strings.TrimSpace(category)
			}
			if r.ContextVMID > 0 {
				r.ResourceURL = fmt.Sprintf("#vms/%d/changes", r.ContextVMID)
			}
		}
	case "internal_service_attachment":
		if id > 0 {
			var serviceID int64
			_ = s.DB.QueryRowContext(ctx, `SELECT COALESCE(NULLIF(title,''),file_name),internal_service_id FROM internal_service_attachments WHERE id=?`, id).Scan(&r.ResourceLabel, &serviceID)
			if serviceID > 0 {
				r.ContextServiceIDs = appendUniqueInt64(r.ContextServiceIDs, serviceID)
				r.ResourceURL = fmt.Sprintf("#services/%d/documents", serviceID)
			}
		}
	case "agent":
		if id > 0 {
			_ = s.DB.QueryRowContext(ctx, `SELECT name FROM agents WHERE id=?`, id).Scan(&r.ResourceLabel)
			r.ResourceURL = "#agents/list"
		}
	case "person":
		if id > 0 {
			_ = s.DB.QueryRowContext(ctx, `SELECT display_name FROM people WHERE id=?`, id).Scan(&r.ResourceLabel)
			r.ResourceURL = "#nomenclatures/people"
		}
	}
	if r.ContextVMID > 0 && r.ContextVMName == "" {
		_ = s.DB.QueryRowContext(ctx, `SELECT name FROM virtual_machines WHERE id=?`, r.ContextVMID).Scan(&r.ContextVMName)
	}
	if r.ResourceLabel == "" {
		r.ResourceLabel = auditFallbackLabel(r.ResourceType, r.ResourceID, details)
	}
	for _, serviceID := range r.ContextServiceIDs {
		var name string
		if s.DB.QueryRowContext(ctx, `SELECT name FROM internal_services WHERE id=?`, serviceID).Scan(&name) != nil || strings.TrimSpace(name) == "" {
			name = fmt.Sprintf("Serviciu #%d", serviceID)
		}
		r.ContextServices = append(r.ContextServices, name)
	}
}

func (s Service) addRecordServices(ctx context.Context, r *Record, query string, resourceID int64) {
	rows, err := s.DB.QueryContext(ctx, query, resourceID)
	if err != nil {
		return
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		if rows.Scan(&id) == nil {
			r.ContextServiceIDs = appendUniqueInt64(r.ContextServiceIDs, id)
		}
	}
}

func mapInt64(values map[string]any, key string) int64 {
	if values == nil {
		return 0
	}
	return anyInt64(values[key])
}
func anyInt64(value any) int64 {
	switch v := value.(type) {
	case float64:
		return int64(v)
	case int64:
		return v
	case int:
		return int64(v)
	case json.Number:
		n, _ := v.Int64()
		return n
	case string:
		n, _ := strconv.ParseInt(strings.TrimSpace(v), 10, 64)
		return n
	}
	return 0
}
func appendUniqueInt64(values []int64, value int64) []int64 {
	if value <= 0 {
		return values
	}
	for _, existing := range values {
		if existing == value {
			return values
		}
	}
	return append(values, value)
}
func auditFallbackLabel(resourceType, resourceID string, details map[string]any) string {
	for _, container := range []string{"created", "deleted", "after", "before"} {
		if raw, ok := details[container].(map[string]any); ok {
			for _, key := range []string{"name", "display_name", "document_number", "service_name"} {
				if v, ok := raw[key].(string); ok && strings.TrimSpace(v) != "" {
					return strings.TrimSpace(v)
				}
			}
		}
	}
	labels := map[string]string{"virtual_machine": "VM", "internal_service": "Serviciu", "docker_container": "Container", "docker_compose_project": "Compose", "database_instance": "Instanță DB", "database_catalog": "Catalog DB", "web_site": "Site Web", "web_server": "Server Web", "software_item": "Software", "generated_document": "Document", "inventory_change": "Modificare inventar", "internal_service_attachment": "Anexă serviciu"}
	label := labels[resourceType]
	if label == "" {
		label = resourceType
	}
	return label
}

func DescribeAction(action string) (label, description, operation string) {
	known := map[string][3]string{
		"agent.create":                                {"Agent adăugat", "A fost definit un agent nou în aplicație.", "created"},
		"agent.update":                                {"Agent modificat", "Configurația unui agent a fost modificată.", "updated"},
		"agent.delete":                                {"Agent șters", "Un agent a fost eliminat din aplicație.", "deleted"},
		"vm.update":                                   {"VM modificat", "Atributele administrate local ale VM-ului au fost modificate.", "updated"},
		"vm.operational.update":                       {"Date operaționale VM", "Datele operaționale, clasificarea sau responsabilitățile VM-ului au fost modificate.", "updated"},
		"vm.service_assignments.replace":              {"Servicii VM modificate", "Asocierile VM-ului la serviciile interne au fost înlocuite.", "updated"},
		"vm.documentation_inheritance.update":         {"Moștenire documentație VM", "Configurația HA / cluster, sursa documentației comune și opțiunile de moștenire Docker/DB/Web au fost modificate.", "updated"},
		"vm.documentation_inheritance.resources_sync": {"Sincronizare resurse moștenite", "Asocierile și documentarea Docker/DB/Web au fost resincronizate din VM-ul sursă HA / cluster.", "operation"},
		"vm.primary_agent_service.update":             {"Serviciu principal VM", "Marcajul de serviciu software principal al VM-ului a fost modificat.", "updated"},
		"vm.agent_services_review.update":             {"Servicii VM verificate", "Starea de verificare a serviciilor observate pe VM a fost modificată.", "updated"},
		"vm.primary_agent_port.update":                {"Port principal VM", "Marcajul de port principal al VM-ului a fost modificat.", "updated"},
		"vm.backup.cron.update":                       {"Backup cron VM", "Documentarea backupului cron al VM-ului a fost modificată.", "updated"},
		"monitoring.aliases.update":                   {"Aliasuri monitorizare", "Aliasurile folosite pentru corelarea VM-ului cu Prometheus au fost modificate.", "updated"},
		"software.primary.set":                        {"Software principal", "Marcajul de software principal al VM-ului a fost modificat.", "updated"},
		"docker.container.services.replace":           {"Servicii container Docker", "Asocierile containerului Docker la servicii interne au fost modificate.", "updated"},
		"docker.compose.services.assign":              {"Servicii proiect Docker Compose", "Un proiect Docker Compose a fost asociat la unul sau mai multe servicii interne.", "updated"},
		"docker.container.documentation_exempt":       {"Documentare container Docker", "Cerința de documentare a containerului Docker a fost modificată.", "updated"},
		"docker.host.documentation_exempt":            {"Documentare Docker VM", "Cerința de documentare Docker la nivelul VM-ului a fost modificată.", "updated"},
		"database.instance.services.replace":          {"Servicii instanță DB", "Asocierile instanței de bază de date la servicii interne au fost modificate.", "updated"},
		"database.catalog.services.replace":           {"Servicii catalog DB", "Asocierile bazei/catalogului la servicii interne au fost modificate.", "updated"},
		"database.instance.documentation_exempt":      {"Documentare instanță DB", "Cerința de documentare a instanței de bază de date a fost modificată.", "updated"},
		"database.catalog.documentation_exempt":       {"Documentare catalog DB", "Cerința de documentare a bazei/catalogului a fost modificată.", "updated"},
		"web.site.services.replace":                   {"Servicii site Web", "Asocierile site-ului/frontend-ului Web la servicii interne au fost modificate.", "updated"},
		"web.site.documentation_exempt":               {"Documentare site Web", "Cerința de documentare a site-ului/frontend-ului Web a fost modificată.", "updated"},
		"web.server.documentation_exempt":             {"Documentare server Web", "Cerința de documentare a serverului Web a fost modificată.", "updated"},
		"internal_service.create":                     {"Serviciu adăugat", "A fost creat un serviciu intern.", "created"},
		"internal_service.update":                     {"Serviciu modificat", "Datele serviciului intern au fost modificate.", "updated"},
		"internal_service.merge":                      {"Proiecte comasate", "Un serviciu/proiect intern a fost comasat într-un altul, împreună cu asocierile sale.", "updated"},
		"internal_service.delete":                     {"Serviciu șters", "Un serviciu/proiect intern a fost eliminat definitiv.", "deleted"},
		"service.dependency.create":                   {"Dependență serviciu adăugată", "A fost adăugată o dependență între servicii.", "created"},
		"service.dependency.update":                   {"Dependență serviciu modificată", "O dependență între servicii a fost modificată.", "updated"},
		"service.dependency.delete":                   {"Dependență serviciu ștearsă", "O dependență între servicii a fost eliminată.", "deleted"},
		"vm.dependency.create":                        {"Dependență VM adăugată", "A fost adăugată o dependență de infrastructură comună pentru VM.", "created"},
		"vm.dependency.delete":                        {"Dependență VM ștearsă", "O dependență de infrastructură comună pentru VM a fost eliminată.", "deleted"},
		"nomenclature.item.create":                    {"Valoare nomenclator adăugată", "A fost adăugată o valoare într-un nomenclator.", "created"},
		"nomenclature.item.update":                    {"Valoare nomenclator modificată", "O valoare de nomenclator a fost modificată.", "updated"},
		"person.create":                               {"Persoană adăugată", "A fost adăugată o persoană în nomenclatorul de responsabilități.", "created"},
		"person.update":                               {"Persoană modificată", "Datele unei persoane au fost modificate.", "updated"},
		"person.directory.import":                     {"Persoane importate", "Au fost importate persoane din directorul configurat.", "operation"},
		"inventory_change.review":                     {"Modificare inventar analizată", "Starea de analiză/documentare a unei modificări de inventar a fost actualizată.", "updated"},
		"inventory_change.baseline":                   {"Baseline inventar stabilit", "Inventarul curent a fost stabilit ca baseline pentru trierea modificărilor.", "operation"},
		"inventory_change.backfill":                   {"Istoric modificări recalculat", "Au fost reconstruite modificări de inventar din snapshot-urile disponibile.", "operation"},
		"internal_service_attachment.create":          {"Anexă serviciu adăugată", "A fost adăugată o anexă de documentație serviciului.", "created"},
		"internal_service_attachment.delete":          {"Anexă serviciu ștearsă", "O anexă de documentație a serviciului a fost eliminată.", "deleted"},
		"internal_service_attachment.download":        {"Anexă serviciu descărcată", "A fost descărcată o anexă de documentație a serviciului.", "operation"},
		"internal_service_document.markdown":          {"Fișă serviciu exportată Markdown", "A fost generat exportul Markdown pentru serviciul intern.", "operation"},
		"document.download":                           {"Document descărcat", "A fost descărcat un document generat.", "operation"},
		"service_document.package_download":           {"Pachet documentație descărcat", "A fost descărcat pachetul de documentație al serviciului și anexele sale.", "operation"},
		"external_network.create":                     {"Rețea externă adăugată", "A fost definită o rețea externă.", "created"},
		"external_network.update":                     {"Rețea externă modificată", "Datele, culoarea sau clasificarea unei rețele externe au fost modificate.", "updated"},
		"external_network.delete":                     {"Rețea externă ștearsă", "O rețea externă fără sisteme asociate a fost eliminată.", "deleted"},
		"external_system.create":                      {"Sistem extern adăugat", "A fost definit un sistem extern.", "created"},
		"external_system.update":                      {"Sistem extern modificat", "Datele unui sistem extern au fost modificate.", "updated"},
		"external_system.delete":                      {"Sistem extern șters", "Un sistem extern și conexiunile sale au fost eliminate.", "deleted"},
		"external_connection.create":                  {"Conexiune externă adăugată", "A fost definită o conexiune către sau dinspre un sistem extern.", "created"},
		"external_connection.update":                  {"Conexiune externă modificată", "Parametrii unei conexiuni externe au fost modificați.", "updated"},
		"external_connection.delete":                  {"Conexiune externă ștearsă", "O conexiune externă a fost eliminată.", "deleted"},
		"collection.queue":                            {"Colectare solicitată", "A fost introdus un job de test/colectare în coadă.", "operation"},
		"vm_document.generate":                        {"Fișă VM generată", "A fost generată o fișă tehnică pentru un VM.", "operation"},
		"internal_service_document.generate":          {"Fișă tehnică și operațională generată", "A fost generată fișa tehnică și operațională a unui serviciu intern.", "operation"},
	}
	if item, ok := known[action]; ok {
		return item[0], item[1], item[2]
	}
	parts := strings.Split(action, ".")
	operation = "operation"
	if len(parts) > 0 {
		switch parts[len(parts)-1] {
		case "create", "publish", "add":
			operation = "created"
		case "update", "replace", "promote":
			operation = "updated"
		case "delete", "remove":
			operation = "deleted"
		}
	}
	label = strings.ReplaceAll(action, "_", " ")
	description = "Eveniment tehnic de audit: " + action + "."
	return label, description, operation
}
