package server

import (
	"errors"
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/webinventory"
)

type webAssignmentsRequest struct {
	Assignments []webinventory.AssignmentInput `json:"assignments"`
}

func (a *App) getVMWebInventory(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	view, err := a.Web.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) replaceWebSiteServices(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	if err := a.ensureResourceDocumentationWritable(r.Context(), vmID); err != nil {
		badRequest(w, err)
		return
	}
	siteID, err := strconv.ParseInt(r.PathValue("site_id"), 10, 64)
	if err != nil || siteID < 1 {
		badRequest(w, errors.New("invalid site_id"))
		return
	}
	var input webAssignmentsRequest
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	beforeServiceIDs := a.auditServiceIDs(r.Context(), `SELECT internal_service_id FROM web_site_service_assignments WHERE web_site_id=?`, siteID)
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Web.ReplaceSiteAssignments(r.Context(), vmID, siteID, user.ID, input.Assignments); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.propagateInheritedResourceDocumentation(r.Context(), vmID); err != nil {
		respond(w, nil, err)
		return
	}
	afterServiceIDs := make([]int64, 0, len(input.Assignments))
	for _, assignment := range input.Assignments {
		afterServiceIDs = appendAuditServiceID(afterServiceIDs, assignment.ServiceID)
	}
	a.auditRequest(r, "web.site.services.replace", "web_site", strconv.FormatInt(siteID, 10), "success", map[string]any{
		"vm_id": vmID, "assignments": input.Assignments, "service_ids": mergeAuditServiceIDs(beforeServiceIDs, afterServiceIDs),
		"before_service_ids": beforeServiceIDs, "after_service_ids": afterServiceIDs,
	})
	view, err := a.Web.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) setWebServerDocumentationExempt(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	if err := a.ensureResourceDocumentationWritable(r.Context(), vmID); err != nil {
		badRequest(w, err)
		return
	}
	serverID, err := strconv.ParseInt(r.PathValue("server_id"), 10, 64)
	if err != nil || serverID < 1 {
		badRequest(w, errors.New("invalid server_id"))
		return
	}
	var input struct {
		Exempt bool `json:"exempt"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if err := a.Web.SetServerDocumentationExempt(r.Context(), vmID, serverID, input.Exempt); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.propagateInheritedResourceDocumentation(r.Context(), vmID); err != nil {
		respond(w, nil, err)
		return
	}
	serviceIDs := a.auditServiceIDs(r.Context(), `SELECT DISTINCT wssa.internal_service_id FROM web_servers wsv JOIN web_sites ws ON ws.vm_id=wsv.vm_id AND ws.engine=wsv.engine JOIN web_site_service_assignments wssa ON wssa.web_site_id=ws.id WHERE wsv.id=?`, serverID)
	a.auditRequest(r, "web.server.documentation_exempt", "web_server", strconv.FormatInt(serverID, 10), "success", map[string]any{"vm_id": vmID, "exempt": input.Exempt, "service_ids": serviceIDs})
	view, err := a.Web.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) setWebSiteDocumentationExempt(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	if err := a.ensureResourceDocumentationWritable(r.Context(), vmID); err != nil {
		badRequest(w, err)
		return
	}
	siteID, err := strconv.ParseInt(r.PathValue("site_id"), 10, 64)
	if err != nil || siteID < 1 {
		badRequest(w, errors.New("invalid site_id"))
		return
	}
	var input struct {
		Exempt bool `json:"exempt"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if err := a.Web.SetSiteDocumentationExempt(r.Context(), vmID, siteID, input.Exempt); err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.propagateInheritedResourceDocumentation(r.Context(), vmID); err != nil {
		respond(w, nil, err)
		return
	}
	serviceIDs := a.auditServiceIDs(r.Context(), `SELECT internal_service_id FROM web_site_service_assignments WHERE web_site_id=?`, siteID)
	a.auditRequest(r, "web.site.documentation_exempt", "web_site", strconv.FormatInt(siteID, 10), "success", map[string]any{"vm_id": vmID, "exempt": input.Exempt, "service_ids": serviceIDs})
	view, err := a.Web.GetVM(r.Context(), vmID)
	respond(w, view, err)
}
