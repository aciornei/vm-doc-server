package server

import (
	"context"
	"strings"
)

// auditServiceIDs returns the currently related internal-service IDs for an
// audited object. Audit must never make the business operation fail, so a
// lookup error intentionally degrades to an empty context list.
func (a *App) auditServiceIDs(ctx context.Context, query string, args ...any) []int64 {
	if a == nil || a.DB == nil || strings.TrimSpace(query) == "" {
		return nil
	}
	rows, err := a.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil
	}
	defer rows.Close()
	out := make([]int64, 0)
	for rows.Next() {
		var id int64
		if rows.Scan(&id) == nil {
			out = appendAuditServiceID(out, id)
		}
	}
	return out
}

func appendAuditServiceID(values []int64, id int64) []int64 {
	if id <= 0 {
		return values
	}
	for _, current := range values {
		if current == id {
			return values
		}
	}
	return append(values, id)
}

func mergeAuditServiceIDs(groups ...[]int64) []int64 {
	out := make([]int64, 0)
	for _, group := range groups {
		for _, id := range group {
			out = appendAuditServiceID(out, id)
		}
	}
	return out
}
