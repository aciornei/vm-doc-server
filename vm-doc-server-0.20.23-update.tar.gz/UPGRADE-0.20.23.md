# Upgrade vm-doc-server 0.20.22 → 0.20.23

## Ce se schimbă

0.20.23 îmbunătățește auditul și rapoartele fără a modifica schema bazei de date.

### Audit contextual

- fila **Audit** este disponibilă direct în VM și Serviciu pentru utilizatorii cu `audit.read`;
- filtre: text, zonă (Configurare / Docker / DB / Web / Documente / Operații), actor, sursă, acțiune, tip resursă, rezultat și perioadă;
- evenimentele afișează numele resursei și contextul VM/Serviciu, păstrând `#ID` pentru diagnostic;
- evenimentele noi de schimbare a asocierilor VM/Docker/DB/Web memorează serviciile înainte și după pentru ca eliminările să fie regăsite în auditul serviciului.

### Rapoarte

- **Persoane & responsabilități**: persoană, departament, e-mail, tip responsabilitate, VM, mediu și servicii; filtre și export Excel;
- **Lipsuri operaționale**: responsabilitate, serviciu, mediu, agent, inventar, backup, monitorizare, baseline și fișă VM; filtre și export Excel.

## Bază de date și agent

- nu există migrare DB nouă;
- nu este necesar update de `vm-doc-agent`.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.22 /usr/local/src/vm-doc-server-0.20.23
tar -xzf vm-doc-server-0.20.23-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.23
cd /usr/local/src/vm-doc-server-0.20.23
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

## Verificare funcțională

1. Deschide o VM și intră în **Audit**; verifică filtrarea pe Docker/DB/Web și afișarea numelor resurselor.
2. Deschide un Serviciu și intră în **Audit**; verifică o asociere și apoi eliminarea aceleiași asocieri.
3. În **Rapoarte → Persoane & responsabilități**, filtrează după persoană/departament/mediu și exportă Excel.
4. În **Rapoarte → Lipsuri operaționale**, filtrează după o problemă și exportă Excel.
