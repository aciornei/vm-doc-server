# Upgrade vm-doc-server 0.20.24 → 0.20.25

## Ce se schimbă

0.20.25 schimbă semantica dependențelor Serviciu → Serviciu: fiecare rând reprezintă un flux concret de integrare.

- același serviciu țintă poate fi adăugat de mai multe ori cu același tip de relație și aceleași medii;
- `Adaugă dependență` nu mai suprascrie relația existentă;
- folosește `Protocol`, `Port` și `Scop / detalii` pentru a diferenția fluxurile (ex. syslog vs API verificare/update);
- toate fluxurile apar separat în `Depinde de`, `Este utilizat de`, schema serviciului și documentația DOCX/Markdown;
- dependențele comune derivate pe VM păstrează și ele fluxurile distincte;
- auditul de creare include `dependency_id`, protocol, port și detalii.

Nu există migrare DB nouă. Migrarea 052 din 0.20.18 eliminase deja constrângerea unică la nivel de tabel. Nu este necesar update de agent.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.24 /usr/local/src/vm-doc-server-0.20.25
tar -xzf vm-doc-server-0.20.25-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.25
cd /usr/local/src/vm-doc-server-0.20.25
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

## Verificare funcțională

1. Pe un serviciu A adaugă dependență către Antivirus, tip `API / integrare`, protocol HTTPS, port 8443, `Scop / detalii = verificare clienți/update`.
2. Adaugă încă o dată aceeași țintă și același tip, de exemplu port 9443 și alt scop.
3. Verifică faptul că apar două rânduri distincte și pot fi dezactivate/șterse independent.
4. Dacă serviciul este asociat unei VM, verifică dependențele comune din VM și documentația generată.
