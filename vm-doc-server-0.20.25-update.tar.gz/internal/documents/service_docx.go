package documents

import (
	"archive/zip"
	"bytes"
	"fmt"
	"io"
	"sort"
	"strconv"
	"strings"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/richtext"
)

func DefaultServiceTemplate() ([]byte, error) {
	files := map[string]string{
		"[Content_Types].xml":          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`,
		"_rels/.rels":                  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`,
		"word/_rels/document.xml.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
		"word/styles.xml":              stylesXML,
		"word/document.xml":            `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>Fișă tehnică și operațională a serviciului — {{service.name}}</w:t></w:r></w:p><w:p><w:r><w:t>{{SERVICE_DOCUMENT_BODY}}</w:t></w:r></w:p><w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`,
		"docProps/core.xml":            `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Fișă tehnică și operațională a serviciului</dc:title><dc:creator>vm-doc-server</dc:creator><cp:lastModifiedBy>vm-doc-server</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">2026-01-01T00:00:00Z</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">2026-01-01T00:00:00Z</dcterms:modified></cp:coreProperties>`,
		"docProps/app.xml":             `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>vm-doc-server</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>0.13.1</AppVersion></Properties>`,
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	order := []string{"[Content_Types].xml", "_rels/.rels", "word/document.xml", "word/styles.xml", "word/_rels/document.xml.rels", "docProps/core.xml", "docProps/app.xml"}
	for _, name := range order {
		entry, err := writer.Create(name)
		if err != nil {
			return nil, err
		}
		if _, err := io.WriteString(entry, files[name]); err != nil {
			return nil, err
		}
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return output.Bytes(), nil
}

func BuildServicePreview(template Template, data ServiceGenerationData) ServicePreview {
	preview := ServicePreview{
		InternalServiceID:   data.Service.ID,
		InternalServiceName: data.Service.Name,
		TemplateID:          template.ID,
		TemplateName:        template.Name,
		DocumentNumber:      data.DocumentNumber,
		GeneratedAt:         data.GeneratedAt,
		Warnings:            make([]string, 0),
		Sections:            servicePreviewSections(data),
	}
	if len(data.Service.VMs) == 0 {
		preview.Warnings = append(preview.Warnings, "Serviciul nu are VM-uri asociate.")
	}
	if len(data.Service.Classifications) == 0 {
		preview.Warnings = append(preview.Warnings, "Serviciul nu are încă domenii și categorii observate din VM-uri.")
	}
	if len(data.Service.SolutionTypes) == 0 {
		preview.Warnings = append(preview.Warnings, "Nu este definit încă niciun tip de soluție pe asocierile VM ale serviciului.")
	}
	if strings.TrimSpace(data.Service.Purpose) == "" {
		preview.Warnings = append(preview.Warnings, "Câmpul Scop și domeniu nu este completat.")
	}
	if strings.TrimSpace(data.Service.Objectives) == "" {
		preview.Warnings = append(preview.Warnings, "Câmpul Obiective nu este completat.")
	}
	if missing := serviceVMsWithoutEnvironment(data.Service.VMs); missing > 0 {
		preview.Warnings = append(preview.Warnings, fmt.Sprintf("%d VM-uri asociate nu au mediul PROD/TEST/DEV completat.", missing))
	}
	if len(data.Service.VMs) > 0 && len(data.VMDocuments) == 0 {
		preview.Warnings = append(preview.Warnings, "Nu există încă fișe VM generate pentru acest serviciu.")
	}
	return preview
}

func servicePreviewSections(data ServiceGenerationData) []PreviewSection {
	service := data.Service
	documentRows := []PreviewRow{{Label: "Număr electronic document", Value: data.DocumentNumber}, {Label: "Data referință", Value: formatTime(data.GeneratedAt)}}
	if data.IncludeGeneratedBy {
		documentRows = append(documentRows, PreviewRow{Label: "Generat de", Value: firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)})
	}
	sections := []PreviewSection{
		{Title: "Document", Rows: documentRows},
		{Title: "Identificare serviciu", Rows: serviceIdentityRows(data)},
		{Title: "Descriere, scop, domeniu și obiective", Rows: []PreviewRow{{Label: "Descriere detaliată", Value: service.Description}, {Label: "Scop și domeniu", Value: service.Purpose}, {Label: "Obiective", Value: service.Objectives}}},
	}
	if len(data.Attachments) > 0 {
		rows := make([]PreviewRow, 0, len(data.Attachments))
		for _, item := range data.Attachments {
			rows = append(rows, PreviewRow{Label: firstNonEmpty(item.Title, item.FileName), Value: item.FileName})
		}
		sections = append(sections, PreviewSection{Title: "Proceduri operaționale și fluxuri de lucru", Rows: rows})
	}
	if envRows := serviceEnvironmentPreviewRows(service.VMs); len(envRows) > 0 {
		sections = append(sections, PreviewSection{Title: "Încadrare pe medii", Rows: envRows})
	}
	if len(service.Classifications) > 0 {
		rows := make([]PreviewRow, 0, len(service.Classifications))
		for _, item := range service.Classifications {
			rows = append(rows, PreviewRow{Label: item.ArchitecturalDomain + " / " + item.ITILCategory, Value: fmt.Sprintf("%d VM · %d asocieri", item.VMCount, item.AssignmentCount)})
		}
		sections = append(sections, PreviewSection{Title: "Domenii și categorii observate", Rows: rows})
	}
	if len(service.SolutionTypes) > 0 {
		rows := make([]PreviewRow, 0, len(service.SolutionTypes))
		for _, item := range service.SolutionTypes {
			rows = append(rows, PreviewRow{Label: item.SolutionType, Value: fmt.Sprintf("%d VM · %d asocieri", item.VMCount, item.AssignmentCount)})
		}
		sections = append(sections, PreviewSection{Title: "Tipuri de soluție", Rows: rows})
	}
	if dependencies := serviceAllDependencies(service); len(dependencies) > 0 {
		rows := make([]PreviewRow, 0, len(dependencies))
		for _, item := range dependencies {
			character := "Explicită"
			if item.Global {
				character = "Globală implicit"
			}
			details := strings.Join(nonEmpty(character, serviceDependencyEnvironment(item), serviceDependencyCriticality(item.Criticality), serviceDependencyEndpoint(item)), " · ")
			rows = append(rows, PreviewRow{Label: item.TargetServiceName + " — " + item.DependencyType, Value: details})
		}
		sections = append(sections, PreviewSection{Title: "Dependențe între servicii", Rows: rows})
	}
	if len(data.ExternalConnections) > 0 {
		sections = append(sections, PreviewSection{Title: "Conexiuni către sisteme externe", Rows: externalConnectionPreviewRows(data.ExternalConnections)})
	}
	if service.IsCommon || len(service.Dependents) > 0 || len(service.DirectVMDependents) > 0 {
		rows := make([]PreviewRow, 0, len(service.Dependents)+1)
		if service.ImplicitGlobal {
			rows = append(rows, PreviewRow{Label: "Aplicabilitate globală", Value: fmt.Sprintf("%d servicii active pot fi afectate", service.DependentServiceCount)})
		}
		for _, item := range service.Dependents {
			if !item.Active {
				continue
			}
			if !item.Active {
				continue
			}
			rows = append(rows, PreviewRow{Label: item.SourceServiceName, Value: item.DependencyType})
		}
		for _, item := range service.DirectVMDependents {
			rows = append(rows, PreviewRow{Label: "VM direct · " + item.VMName, Value: item.DependencyType})
		}
		if len(rows) > 0 {
			sections = append(sections, PreviewSection{Title: "Impact · servicii dependente", Rows: rows})
		}
	}
	if len(service.RoleMappings) > 0 {
		rows := make([]PreviewRow, 0, len(service.RoleMappings))
		for _, item := range service.RoleMappings {
			rows = append(rows, PreviewRow{Label: item.LayerName + " → " + item.TechnicalRole, Value: fmt.Sprintf("%d VM", item.VMCount)})
		}
		sections = append(sections, PreviewSection{Title: "Layer-e și roluri tehnice", Rows: rows})
	}
	if len(data.PrimaryComponents) > 0 {
		rows := make([]PreviewRow, 0, len(data.PrimaryComponents))
		for _, item := range data.PrimaryComponents {
			software := firstNonEmpty(item.SoftwareName, strings.TrimSuffix(item.ServiceName, ".service"), item.ServiceName)
			version := firstNonEmpty(shortVersion(item.Version), shortVersion(item.PackageVersion), "versiune necunoscută")
			state := strings.Join(nonEmpty(environmentCode(item.Environment), item.ActiveState), " · ")
			if !item.Detected {
				state = strings.TrimSpace(strings.Join(nonEmpty(environmentCode(item.Environment), "nedetectat în inventarul curent"), " · "))
			}
			rows = append(rows, PreviewRow{Label: item.VMName + " — " + software + " " + version, Value: state})
		}
		sections = append(sections, PreviewSection{Title: "Componente software principale", Rows: rows})
	}
	if len(data.DatabaseResources) > 0 {
		rows := make([]PreviewRow, 0, len(data.DatabaseResources))
		for _, item := range data.DatabaseResources {
			label := firstNonEmpty(item.VMHostname, item.VMName) + " · " + firstNonEmpty(item.Product, item.Engine) + " / " + firstNonEmpty(item.InstanceName, "implicit")
			if item.ResourceType == "database" && item.DatabaseName != "" {
				label += " / " + item.DatabaseName
			}
			jobSummary := ""
			if len(item.ScheduledJobs) > 0 {
				jobSummary = fmt.Sprintf("%d joburi DB", len(item.ScheduledJobs))
			}
			rows = append(rows, PreviewRow{Label: label, Value: strings.TrimSpace(strings.Join(nonEmpty(shortVersion(item.Version), item.Status, databaseEndpointSummary(item.Endpoints), jobSummary, databaseAssignmentForService(item.ServiceAssignments, service.ID)), " · "))})
		}
		sections = append(sections, PreviewSection{Title: "Baze de date asociate", Rows: rows})
	}
	if len(data.DockerContainers) > 0 {
		rows := make([]PreviewRow, 0, len(data.DockerContainers))
		for _, item := range data.DockerContainers {
			assignment := dockerAssignmentForService(item.ServiceAssignments, service.ID)
			label := firstNonEmpty(item.VMHostname, item.VMName) + " · " + item.Name
			value := strings.TrimSpace(strings.Join(nonEmpty(item.Image, item.ComposeProject, item.State, assignment), " · "))
			rows = append(rows, PreviewRow{Label: label, Value: value})
		}
		sections = append(sections, PreviewSection{Title: "Containere Docker asociate", Rows: rows})
	}
	if len(data.WebSites) > 0 {
		rows := make([]PreviewRow, 0, len(data.WebSites))
		for _, item := range data.WebSites {
			label := firstNonEmpty(item.VMHostname, item.VMName) + " · " + firstNonEmpty(item.Name, "site")
			value := strings.TrimSpace(strings.Join(nonEmpty(firstNonEmpty(item.Product, item.Engine), strings.Join(item.ServerNames, ", "), webBindingSummary(item.Bindings), webTargetSummary(item), webAssignmentForService(item.ServiceAssignments, service.ID)), " · "))
			rows = append(rows, PreviewRow{Label: label, Value: value})
		}
		sections = append(sections, PreviewSection{Title: "Site-uri web asociate", Rows: rows})
	}
	if len(data.Backups) > 0 {
		sections = append(sections, PreviewSection{Title: "Backup și restaurare", Rows: serviceBackupPreviewRows(data.Backups)})
	}
	if len(data.Monitorings) > 0 {
		sections = append(sections, PreviewSection{Title: "Monitorizare", Rows: serviceMonitoringPreviewRows(data.Monitorings)})
	}
	if len(service.VMs) > 0 {
		sections = append(sections, PreviewSection{Title: "VM-uri asociate", Rows: serviceVMPreviewRows(service.VMs)})
	}
	if len(data.VMDocuments) > 0 {
		rows := make([]PreviewRow, 0, len(data.VMDocuments))
		for _, doc := range data.VMDocuments {
			rows = append(rows, PreviewRow{Label: doc.VMName, Value: doc.DocumentNumber + " · " + firstNonEmpty(environmentCode(doc.Environment), "mediu nespecificat")})
		}
		sections = append(sections, PreviewSection{Title: "Fișe VM / anexe", Rows: rows})
	}
	return sections
}

func serviceEnvironmentPreviewRows(assignments []domain.InternalServiceVM) []PreviewRow {
	byVM := make(map[int64]domain.InternalServiceVM)
	for _, item := range assignments {
		if _, ok := byVM[item.ID]; !ok {
			byVM[item.ID] = item
		}
	}
	counts := make(map[string]int)
	for _, item := range byVM {
		env := environmentCode(item.Environment)
		if env == "" {
			env = "Nespecificat"
		}
		counts[env]++
	}
	keys := make([]string, 0, len(counts))
	for key := range counts {
		keys = append(keys, key)
	}
	sort.SliceStable(keys, func(i, j int) bool {
		ri, rj := serviceEnvironmentRank(keys[i]), serviceEnvironmentRank(keys[j])
		if ri != rj {
			return ri < rj
		}
		return strings.ToLower(keys[i]) < strings.ToLower(keys[j])
	})
	rows := make([]PreviewRow, 0, len(keys))
	for _, key := range keys {
		rows = append(rows, PreviewRow{Label: key, Value: fmt.Sprintf("%d VM", counts[key])})
	}
	return rows
}

func serviceBackupPreviewRows(items []ServiceVMBackup) []PreviewRow {
	rows := make([]PreviewRow, 0, len(items))
	for _, item := range items {
		b := item.Backup
		protection := backupVeeamStateText(b)
		if protection == "" {
			protection = "Neverificat"
		}
		if b.CronBackupEnabled && !b.Protected {
			if b.VeeamState == "never" || b.VeeamState == "unprotected" || b.VeeamState == "" {
				protection = "Protejată · cron"
			} else {
				protection += " · backup cron declarat"
			}
		}
		policy := strings.Join(nonEmpty(backupRetentionText(b), backupGFSWeeklyText(b), backupGFSMonthlyText(b), backupGFSYearlyText(b)), " · ")
		cron := ""
		if b.CronBackupEnabled {
			cron = "cron " + b.CronBackupSchedule
		}
		value := strings.TrimSpace(strings.Join(nonEmpty(protection, b.LastResult, b.ScheduleText, policy, cron, formatTimePtr(b.LastBackupAt)), " · "))
		rows = append(rows, PreviewRow{Label: item.VMName + " · " + firstNonEmpty(environmentCode(item.Environment), "mediu nespecificat"), Value: value})
	}
	return rows
}

func serviceVMPreviewRows(assignments []domain.InternalServiceVM) []PreviewRow {
	byVM := make(map[int64][]domain.InternalServiceVM)
	order := make([]int64, 0)
	for _, item := range assignments {
		if _, ok := byVM[item.ID]; !ok {
			order = append(order, item.ID)
		}
		byVM[item.ID] = append(byVM[item.ID], item)
	}
	rows := make([]PreviewRow, 0, len(order))
	for _, id := range order {
		items := byVM[id]
		first := items[0]
		roles := make([]string, 0, len(items))
		for _, item := range items {
			roles = append(roles, strings.Join(nonEmpty(item.LayerName, item.TechnicalRole), " / "))
		}
		value := strings.Join(nonEmpty(environmentCode(first.Environment), strings.Join(roles, "; ")), " · ")
		rows = append(rows, PreviewRow{Label: firstNonEmpty(first.GuestHostname, first.Name), Value: value})
	}
	return rows
}

func serviceVMsWithoutEnvironment(assignments []domain.InternalServiceVM) int {
	seen := make(map[int64]bool)
	missing := 0
	for _, item := range assignments {
		if seen[item.ID] {
			continue
		}
		seen[item.ID] = true
		if strings.TrimSpace(item.Environment) == "" {
			missing++
		}
	}
	return missing
}

func serviceIdentityRows(data ServiceGenerationData) []PreviewRow {
	service := data.Service
	active := "Nu"
	if service.Active {
		active = "Da"
	}
	typeLabel := "Serviciu aplicație"
	if service.IsCommon {
		typeLabel = "Serviciu comun"
		if service.ImplicitGlobal {
			typeLabel = "Serviciu comun · Global implicit"
		}
	}
	rows := []PreviewRow{
		{Label: "Cod intern", Value: service.ServiceCode},
		{Label: "Descriere scurtă", Value: service.ShortDescription},
		{Label: "Autentificare", Value: service.Authentication},
		{Label: "Link serviciu", Value: service.ServiceURL},
		{Label: "Tehnologii folosite", Value: service.Technologies},
		{Label: "Criticitate", Value: service.Criticality},
		{Label: "Status documentație", Value: service.DocumentationStatus},
		{Label: "Tip serviciu", Value: typeLabel},
		{Label: "Activ", Value: active},
		{Label: "Documentație existentă", Value: service.DocumentationURL},
		{Label: "VM-uri asociate", Value: strconv.Itoa(service.VMCount)},
	}
	if service.IsCommon {
		rows = append(rows, PreviewRow{Label: "Tip dependență comună", Value: service.CommonDependencyType}, PreviewRow{Label: "Servicii potențial afectate", Value: strconv.Itoa(service.DependentServiceCount)})
	}
	return rows
}
func RenderServiceDOCX(template []byte, data ServiceGenerationData) ([]byte, error) {
	if err := ValidateTemplateFor(template, "service"); err != nil {
		return nil, err
	}
	reader, err := zip.NewReader(bytes.NewReader(template), int64(len(template)))
	if err != nil {
		return nil, err
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	tokens := serviceScalarTokens(data)
	body := serviceDocumentBodyXML(data)
	chunks := serviceEmbeddedChunks(data)
	bodyReplaced := false
	for _, source := range reader.File {
		content, err := readZipFile(source, 64<<20)
		if err != nil {
			writer.Close()
			return nil, err
		}
		if strings.HasSuffix(source.Name, ".xml") || strings.HasSuffix(source.Name, ".rels") {
			text := string(content)
			for token, value := range tokens {
				text = strings.ReplaceAll(text, token, xmlText(value))
			}
			switch source.Name {
			case "word/document.xml":
				// Keep existing service templates compatible with the terminology introduced
				// in 0.20.9. The built-in template is stored in DB, so older installations
				// can still contain the legacy title even after the binary is upgraded.
				text = strings.ReplaceAll(text, "Fișă serviciu intern", "Fișă tehnică și operațională a serviciului")
				text = ensureServiceRelationshipNamespace(text)
				if replaced, ok := replaceServiceBodyParagraph(text, body); ok {
					text = replaced
					bodyReplaced = true
				}
			case "word/styles.xml":
				text = enforceArial12StylesXML(text)
			case "word/_rels/document.xml.rels":
				text = addServiceChunkRelationships(text, chunks)
			case "[Content_Types].xml":
				text = addServiceChunkContentTypes(text, chunks)
			case "docProps/core.xml":
				text = updateServiceCoreProperties(text, data)
			}
			content = []byte(text)
		}
		header := source.FileHeader
		header.CRC32 = 0
		header.CompressedSize = 0
		header.CompressedSize64 = 0
		header.UncompressedSize = 0
		header.UncompressedSize64 = 0
		header.SetModTime(data.GeneratedAt)
		destination, err := writer.CreateHeader(&header)
		if err != nil {
			writer.Close()
			return nil, err
		}
		if _, err := destination.Write(content); err != nil {
			writer.Close()
			return nil, err
		}
	}
	if !bodyReplaced {
		writer.Close()
		return nil, fmt.Errorf("template placeholder %s was not found as a complete paragraph", ServiceBodyPlaceholder)
	}
	for _, chunk := range chunks {
		destination, err := writer.Create(chunk.PartName)
		if err != nil {
			writer.Close()
			return nil, err
		}
		if _, err := destination.Write(chunk.Content); err != nil {
			writer.Close()
			return nil, err
		}
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return output.Bytes(), nil
}

type serviceEmbeddedChunk struct {
	RelID    string
	PartName string
	Content  []byte
}

func serviceAttachmentRelID(index int) string { return fmt.Sprintf("rIdSvcAttachment%d", index+1) }
func serviceVMAnnexRelID(index int) string    { return fmt.Sprintf("rIdVMAnnex%d", index+1) }

func serviceEmbeddedChunks(data ServiceGenerationData) []serviceEmbeddedChunk {
	chunks := make([]serviceEmbeddedChunk, 0, len(data.Attachments)+len(data.VMDocuments))
	for index, attachment := range data.Attachments {
		if len(attachment.Content) == 0 {
			continue
		}
		chunks = append(chunks, serviceEmbeddedChunk{
			RelID:    serviceAttachmentRelID(index),
			PartName: fmt.Sprintf("word/afchunk/service_attachment_%d.docx", index+1),
			Content:  attachment.Content,
		})
	}
	if data.EmbedVMAnnexes {
		for index, doc := range data.VMDocuments {
			if len(doc.Content) == 0 {
				continue
			}
			chunks = append(chunks, serviceEmbeddedChunk{
				RelID:    serviceVMAnnexRelID(index),
				PartName: fmt.Sprintf("word/afchunk/vm_annex_%d.docx", index+1),
				Content:  doc.Content,
			})
		}
	}
	return chunks
}

func serviceAltChunkXML(relID string) string {
	return `<w:altChunk r:id="` + xmlText(relID) + `"/>`
}

func servicePageBreakXML() string {
	return `<w:p><w:r><w:br w:type="page"/></w:r></w:p>`
}

func ensureServiceRelationshipNamespace(text string) string {
	if strings.Contains(text, `xmlns:r=`) {
		return text
	}
	const namespace = ` xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"`
	if index := strings.Index(text, `<w:document`); index >= 0 {
		end := index + len(`<w:document`)
		return text[:end] + namespace + text[end:]
	}
	return text
}

func addServiceChunkRelationships(text string, chunks []serviceEmbeddedChunk) string {
	if len(chunks) == 0 {
		return text
	}
	const closing = `</Relationships>`
	index := strings.LastIndex(text, closing)
	if index < 0 {
		return text
	}
	var additions strings.Builder
	for _, chunk := range chunks {
		target := strings.TrimPrefix(chunk.PartName, "word/")
		additions.WriteString(`<Relationship Id="` + xmlText(chunk.RelID) + `" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/aFChunk" Target="` + xmlText(target) + `"/>`)
	}
	return text[:index] + additions.String() + text[index:]
}

func addServiceChunkContentTypes(text string, chunks []serviceEmbeddedChunk) string {
	if len(chunks) == 0 {
		return text
	}
	const closing = `</Types>`
	index := strings.LastIndex(text, closing)
	if index < 0 {
		return text
	}
	var additions strings.Builder
	for _, chunk := range chunks {
		additions.WriteString(`<Override PartName="/` + xmlText(chunk.PartName) + `" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document"/>`)
	}
	return text[:index] + additions.String() + text[index:]
}

func replaceServiceBodyParagraph(documentXML, body string) (string, bool) {
	placeholder := strings.Index(documentXML, ServiceBodyPlaceholder)
	if placeholder < 0 {
		return documentXML, false
	}
	start := paragraphStart(documentXML[:placeholder])
	if start < 0 {
		return documentXML, false
	}
	endOffset := strings.Index(documentXML[placeholder:], "</w:p>")
	if endOffset < 0 {
		return documentXML, false
	}
	end := placeholder + endOffset + len("</w:p>")
	return documentXML[:start] + body + documentXML[end:], true
}

func serviceScalarTokens(data ServiceGenerationData) map[string]string {
	service := data.Service
	return map[string]string{
		"{{document.number}}":       data.DocumentNumber,
		"{{document.generated_at}}": formatTime(data.GeneratedAt),
		"{{document.generated_by}}": func() string {
			if data.IncludeGeneratedBy {
				return firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)
			}
			return ""
		}(),
		"{{service.name}}":              service.Name,
		"{{service.code}}":              service.ServiceCode,
		"{{service.short_description}}": service.ShortDescription,
		"{{service.authentication}}":    service.Authentication,
		"{{service.url}}":               service.ServiceURL,
		"{{service.technologies}}":      service.Technologies,
		"{{service.criticality}}":       service.Criticality,
		"{{service.status}}":            service.DocumentationStatus,
		"{{service.description}}":       service.Description,
		"{{service.purpose}}":           service.Purpose,
		"{{service.scope_domain}}":      service.Purpose,
		"{{service.objectives}}":        service.Objectives,
		"{{service.documentation}}":     service.DocumentationURL,
	}
}

func serviceDocumentBodyXML(data ServiceGenerationData) string {
	service := data.Service
	var out strings.Builder
	out.WriteString(infoParagraph("Număr electronic document", data.DocumentNumber))
	out.WriteString(infoParagraph("Data referință", formatTime(data.GeneratedAt)))
	if data.IncludeGeneratedBy {
		out.WriteString(infoParagraph("Generat de", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)))
	}
	out.WriteString(heading("1. Identificare serviciu", 1))
	out.WriteString(keyValueTable(serviceIdentityRows(data)))

	out.WriteString(heading("2. Descriere, scop, domeniu și obiective", 1))
	out.WriteString(serviceRichNarrativeBox("Descriere", service.DescriptionRichText, service.Description))
	out.WriteString(serviceRichNarrativeBox("Scop și domeniu", service.PurposeRichText, service.Purpose))
	out.WriteString(serviceRichNarrativeBox("Obiective", service.ObjectivesRichText, service.Objectives))
	out.WriteString(heading("3. Încadrare pe medii", 1))
	out.WriteString(serviceEnvironmentXML(service.VMs))

	out.WriteString(heading("4. Schemă logică a serviciului", 1))
	if len(service.VMs) == 0 {
		out.WriteString(paragraph("Schema nu poate fi generată deoarece serviciul nu are VM-uri asociate.", "IntenseQuote"))
	} else {
		out.WriteString(paragraph("Schema este generată automat din asocierile VM. Fiecare VM apare o singură dată; mediul PROD/TEST/DEV este evidențiat împreună cu rolurile tehnice.", "IntenseQuote"))
		out.WriteString(serviceDiagramXML(service.VMs))
	}

	out.WriteString(heading("5. Dependențe între servicii", 1))
	dependencies := serviceAllDependencies(service)
	if len(dependencies) == 0 {
		out.WriteString(paragraph("Nu sunt declarate dependențe active către alte servicii.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(dependencies))
		for _, item := range dependencies {
			character := "Explicită"
			if item.Global {
				character = "Globală implicit"
			}
			rows = append(rows, []string{item.TargetServiceName, item.DependencyType, serviceDependencyEnvironment(item), serviceDependencyCriticality(item.Criticality), serviceDependencyEndpoint(item), character, item.Notes})
		}
		out.WriteString(tableWithWidths([]string{"Serviciu", "Tip", "Medii", "Criticitate", "Protocol / port", "Caracter", "Detalii"}, rows, []int{1700, 1500, 1350, 1050, 1200, 1150, 2050}))
	}

	out.WriteString(heading("5.1 Conexiuni către sisteme externe", 2))
	out.WriteString(externalConnectionsTableXML(data.ExternalConnections, true))

	if service.IsCommon || len(service.Dependents) > 0 || len(service.DirectVMDependents) > 0 {
		out.WriteString(heading("5.2 Este utilizat de", 2))
		if service.ImplicitGlobal {
			out.WriteString(paragraph(fmt.Sprintf("Serviciul este global implicit. Indisponibilitatea lui poate afecta toate celelalte servicii active (%d servicii).", service.DependentServiceCount), "IntenseQuote"))
		}
		if len(service.Dependents) > 0 {
			rows := make([][]string, 0, len(service.Dependents))
			for _, item := range service.Dependents {
				rows = append(rows, []string{item.SourceServiceName, item.DependencyType, item.Notes})
			}
			out.WriteString(tableWithWidths([]string{"Serviciu dependent", "Tip dependență", "Detalii"}, rows, []int{3600, 2500, 2900}))
		} else if !service.ImplicitGlobal && len(service.DirectVMDependents) == 0 {
			out.WriteString(paragraph("Nu sunt declarate servicii sau VM-uri dependente direct de acest serviciu.", "IntenseQuote"))
		}
		if len(service.DirectVMDependents) > 0 {
			rows := make([][]string, 0, len(service.DirectVMDependents))
			for _, item := range service.DirectVMDependents {
				rows = append(rows, []string{item.VMName, item.DependencyType, item.Notes})
			}
			out.WriteString(heading("5.3 VM-uri dependente direct", 2))
			out.WriteString(tableWithWidths([]string{"VM", "Tip dependență", "Detalii"}, rows, []int{3600, 2500, 2900}))
		}
	}

	out.WriteString(heading("6. Domenii și categorii de serviciu", 1))
	if len(service.Classifications) == 0 {
		out.WriteString(paragraph("Nu există clasificări observate din VM-urile asociate.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.Classifications))
		for _, item := range service.Classifications {
			rows = append(rows, []string{item.ArchitecturalDomain, item.ITILCategory, strconv.Itoa(item.VMCount), strconv.Itoa(item.AssignmentCount)})
		}
		out.WriteString(tableWithWidths([]string{"Domeniu", "Categorie de serviciu", "VM-uri", "Asocieri"}, rows, []int{2600, 3600, 1400, 1400}))
	}

	out.WriteString(heading("7. Tipuri de soluție", 1))
	if len(service.SolutionTypes) == 0 {
		out.WriteString(paragraph("Nu există tipuri de soluție definite pe asocierile VM.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.SolutionTypes))
		for _, item := range service.SolutionTypes {
			rows = append(rows, []string{item.SolutionType, strconv.Itoa(item.VMCount), strconv.Itoa(item.AssignmentCount)})
		}
		out.WriteString(tableWithWidths([]string{"Tip soluție", "VM-uri", "Asocieri"}, rows, []int{5400, 1800, 1800}))
	}

	out.WriteString(heading("8. Arhitectură tehnică observată", 1))
	if len(service.RoleMappings) == 0 {
		out.WriteString(paragraph("Nu există layer-e și roluri tehnice observate.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.RoleMappings))
		for _, item := range service.RoleMappings {
			rows = append(rows, []string{item.LayerName, item.TechnicalRole, strconv.Itoa(item.VMCount)})
		}
		out.WriteString(tableWithWidths([]string{"Layer", "Rol tehnic", "VM-uri"}, rows, []int{3000, 4500, 1500}))
	}

	out.WriteString(heading("9. Componente software principale", 1))
	if len(data.PrimaryComponents) == 0 {
		out.WriteString(paragraph("Nu sunt marcate componente software principale pe VM-urile acestui serviciu.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(data.PrimaryComponents))
		for _, item := range data.PrimaryComponents {
			software := firstNonEmpty(item.SoftwareName, strings.TrimSuffix(item.ServiceName, ".service"), item.ServiceName)
			version := firstNonEmpty(shortVersion(item.Version), "—")
			packageVersion := strings.TrimSpace(strings.Join(nonEmpty(item.PackageName, cleanVersionText(item.PackageVersion)), " · "))
			state := strings.TrimSpace(strings.Join(nonEmpty(item.ActiveState, item.EnabledState), " · "))
			if !item.Detected {
				state = "Nedetectat în inventarul curent"
			}
			softwareService := software
			if strings.TrimSpace(item.ServiceName) != "" {
				softwareService = strings.TrimSpace(software + " · " + item.ServiceName)
			}
			rows = append(rows, []string{item.VMName, emptyDash(environmentCode(item.Environment)), softwareService, version, packageVersion, state})
		}
		out.WriteString(tableWithWidths([]string{"VM", "Mediu", "Software / serviciu", "Versiune", "Pachet", "Stare"}, rows, []int{1600, 1000, 2150, 1200, 1750, 1300}))
	}

	sectionNumber := 10
	if len(data.DatabaseResources) > 0 {
		out.WriteString(heading(fmt.Sprintf("%d. Baze de date", sectionNumber), 1))
		out.WriteString(serviceDatabaseXML(data))
		sectionNumber++
	}
	if len(data.DockerContainers) > 0 {
		out.WriteString(heading(fmt.Sprintf("%d. Componente Docker", sectionNumber), 1))
		out.WriteString(serviceDockerXML(data))
		sectionNumber++
	}
	if len(data.WebSites) > 0 {
		out.WriteString(heading(fmt.Sprintf("%d. Site-uri web și frontends", sectionNumber), 1))
		out.WriteString(serviceWebXML(data))
		sectionNumber++
	}

	out.WriteString(heading(fmt.Sprintf("%d. Backup și restaurare", sectionNumber), 1))
	out.WriteString(serviceBackupXML(data.Backups))
	sectionNumber++

	out.WriteString(heading(fmt.Sprintf("%d. Monitorizare", sectionNumber), 1))
	out.WriteString(serviceMonitoringXML(data.Monitorings))
	sectionNumber++

	out.WriteString(heading(fmt.Sprintf("%d. VM-uri asociate", sectionNumber), 1))
	if len(service.VMs) == 0 {
		out.WriteString(paragraph("Nu există VM-uri asociate serviciului.", "IntenseQuote"))
	} else {
		out.WriteString(serviceVMOverviewTable(service.VMs))
	}

	if len(data.VMDocuments) > 0 || data.IncludeVMAnnexes || data.EmbedVMAnnexes {
		sectionNumber++
		out.WriteString(heading(fmt.Sprintf("%d. Anexe — fișe tehnice VM", sectionNumber), 1))
		if len(data.VMDocuments) == 0 {
			out.WriteString(paragraph("Nu au fost disponibile fișe VM pentru anexare.", "IntenseQuote"))
		} else {
			note := "Fișele tehnice VM sunt prezentate ca anexe ale fișei tehnice și operaționale a serviciului."
			if data.EmbedVMAnnexes {
				note += " Anexele A1, A2… sunt integrate în același document DOCX."
			}
			if data.IncludeVMAnnexes {
				note += " Fișierele sunt incluse și în pachetul ZIP al documentului."
			}
			out.WriteString(paragraph(note, "IntenseQuote"))
			out.WriteString(serviceVMAnnexTable(data.VMDocuments))
			out.WriteString(serviceVMDocumentReferencesXML(data))
			if data.EmbedVMAnnexes {
				for index, doc := range data.VMDocuments {
					if len(doc.Content) == 0 {
						continue
					}
					out.WriteString(servicePageBreakXML())
					out.WriteString(heading(fmt.Sprintf("A%d. Fișă tehnică VM — %s", index+1, firstNonEmpty(doc.VMName, "VM")), 1))
					out.WriteString(paragraph(doc.DocumentNumber, "IntenseQuote"))
					out.WriteString(serviceAltChunkXML(serviceVMAnnexRelID(index)))
				}
			}
		}
	}

	// Supplemental service documentation is appended only at the end of the
	// generated service sheet. Keep it out of chapter 2 so an uploaded DOCX
	// cannot interrupt the main service documentation flow. VM sheets keep the
	// A-series annex labels; supplemental documents use B1, B2, ... .
	if len(data.Attachments) > 0 {
		for index, attachment := range data.Attachments {
			out.WriteString(servicePageBreakXML())
			title := firstNonEmpty(attachment.Title, attachment.FileName, "Procedură operațională")
			out.WriteString(heading(fmt.Sprintf("B%d. Procedură operațională și fluxuri de lucru — %s", index+1, title), 1))
			if len(attachment.Content) > 0 {
				out.WriteString(serviceAltChunkXML(serviceAttachmentRelID(index)))
			} else {
				out.WriteString(serviceSupplementalTextXML(attachment.ExtractedText))
			}
		}
	}

	return out.String()
}

func databaseAssignmentForService(values []domain.DatabaseServiceAssignment, serviceID int64) string {
	parts := []string{}
	for _, item := range values {
		if item.ServiceID != serviceID {
			continue
		}
		parts = append(parts, nonEmpty(environmentCode(item.Environment), item.OperationalStatus, item.SolutionType, item.ComponentName, item.RoleName)...)
	}
	return strings.Join(parts, " · ")
}

func serviceBackupXML(items []ServiceVMBackup) string {
	if len(items) == 0 {
		return paragraph("Nu există informații de backup pentru VM-urile serviciului.", "IntenseQuote")
	}
	rows := make([][]string, 0, len(items))
	for _, item := range items {
		b := item.Backup
		protection := "Neverificat"
		if b.CronBackupEnabled {
			protection = "Protejată · cron"
		}
		if b.SyncedAt != nil {
			if b.Protected {
				protection = "Protejată"
			} else if !b.CronBackupEnabled {
				protection = "Neprotejată"
			}
		}
		policy := strings.Join(nonEmpty(backupRetentionText(b), backupGFSWeeklyText(b), backupGFSMonthlyText(b), backupGFSYearlyText(b)), "; ")
		cron := "—"
		if b.CronBackupEnabled {
			cron = firstNonEmpty(b.CronBackupSchedule, "Da")
		}
		rows = append(rows, []string{item.VMName, emptyDash(environmentCode(item.Environment)), protection, emptyDash(b.LastResult), emptyDash(b.ScheduleText), emptyDash(policy), cron, formatTimePtr(b.LastBackupAt), formatIntPtr(b.RestorePoints)})
	}
	return tableWithWidths([]string{"VM", "Mediu", "Protecție", "Rezultat", "Programare", "Retenție / GFS", "Cron", "Ultimul backup", "RP"}, rows, []int{1200, 700, 1100, 850, 1200, 1750, 900, 1200, 500})
}

func serviceDatabaseScheduledJobs(items []domain.DatabaseServiceResource) []struct {
	VMName       string
	InstanceName string
	Job          domain.DatabaseScheduledJob
} {
	out := []struct {
		VMName       string
		InstanceName string
		Job          domain.DatabaseScheduledJob
	}{}
	seen := map[string]bool{}
	for _, item := range items {
		for _, job := range item.ScheduledJobs {
			key := strings.ToLower(strings.Join([]string{strconv.FormatInt(item.VMID, 10), strconv.FormatInt(item.InstanceID, 10), job.Scheduler, job.SourceDatabase, job.JobID, job.Name}, "|"))
			if seen[key] {
				continue
			}
			seen[key] = true
			out = append(out, struct {
				VMName       string
				InstanceName string
				Job          domain.DatabaseScheduledJob
			}{firstNonEmpty(item.VMHostname, item.VMName, fmt.Sprintf("VM #%d", item.VMID)), firstNonEmpty(item.InstanceName, "implicit"), job})
		}
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].VMName != out[j].VMName {
			return strings.ToLower(out[i].VMName) < strings.ToLower(out[j].VMName)
		}
		if out[i].InstanceName != out[j].InstanceName {
			return strings.ToLower(out[i].InstanceName) < strings.ToLower(out[j].InstanceName)
		}
		return strings.ToLower(out[i].Job.Scheduler+out[i].Job.Name+out[i].Job.JobID) < strings.ToLower(out[j].Job.Scheduler+out[j].Job.Name+out[j].Job.JobID)
	})
	return out
}

func serviceDatabaseScheduledJobSummary(values []domain.DatabaseScheduledJob) string {
	if len(values) == 0 {
		return "—"
	}
	schedulers := []string{}
	seen := map[string]bool{}
	for _, job := range values {
		name := firstNonEmpty(job.Scheduler, "PostgreSQL")
		if !seen[name] {
			seen[name] = true
			schedulers = append(schedulers, name)
		}
	}
	sort.Strings(schedulers)
	return fmt.Sprintf("%d · %s", len(values), strings.Join(schedulers, ", "))
}

func serviceDatabaseXML(data ServiceGenerationData) string {
	if len(data.DatabaseResources) == 0 {
		return paragraph("Nu există baze de date sau instanțe asociate direct acestui serviciu.", "IntenseQuote")
	}
	rows := make([][]string, 0, len(data.DatabaseResources))
	for _, item := range data.DatabaseResources {
		resource := "Instanță"
		name := "—"
		if item.ResourceType == "database" {
			resource = "Bază"
			name = item.DatabaseName
		}
		rows = append(rows, []string{firstNonEmpty(item.VMHostname, item.VMName, fmt.Sprintf("VM #%d", item.VMID)), firstNonEmpty(item.Product, item.Engine), firstNonEmpty(item.InstanceName, "implicit"), resource, name, firstNonEmpty(shortVersion(item.Version), "—"), databaseEndpointSummary(item.Endpoints), serviceDatabaseScheduledJobSummary(item.ScheduledJobs), firstNonEmpty(databaseAssignmentForService(item.ServiceAssignments, data.Service.ID), "—")})
	}
	var out strings.Builder
	out.WriteString(tableWithWidths([]string{"VM gazdă", "Engine", "Instanță", "Nivel", "Bază", "Versiune", "Endpoint", "Joburi DB", "Mediu / status / tip soluție / componentă / rol"}, rows, []int{1100, 1000, 950, 650, 1100, 900, 1100, 850, 1500}))
	jobs := serviceDatabaseScheduledJobs(data.DatabaseResources)
	if len(jobs) > 0 {
		out.WriteString(heading("Joburi programate PostgreSQL", 2))
		out.WriteString(paragraph("Sunt incluse numai metadatele schedulerului; SQL-ul, comenzile și scripturile joburilor nu sunt colectate.", "IntenseQuote"))
		jobRows := make([][]string, 0, len(jobs))
		for _, item := range jobs {
			job := item.Job
			dbUser := strings.Join(nonEmpty(job.Database, job.Username), " / ")
			executions := strings.Join(nonEmpty(
				func() string {
					if strings.TrimSpace(job.NextRun) != "" {
						return "următoarea: " + job.NextRun
					}
					return ""
				}(),
				func() string {
					if strings.TrimSpace(job.LastRun) != "" {
						return "ultima: " + job.LastRun
					}
					return ""
				}(),
			), " · ")
			jobRows = append(jobRows, []string{item.VMName, item.InstanceName, firstNonEmpty(job.Scheduler, "PostgreSQL"), firstNonEmpty(job.Name, job.JobID, "—"), firstNonEmpty(job.Schedule, "—"), firstNonEmpty(dbUser, "—"), databaseScheduledJobState(job), firstNonEmpty(executions, "—")})
		}
		out.WriteString(tableWithWidths([]string{"VM", "Instanță", "Scheduler", "Job", "Program", "DB / user", "Stare", "Execuții"}, jobRows, []int{1100, 950, 850, 1300, 1050, 1150, 700, 1600}))
	}
	return out.String()
}

func dockerAssignmentForService(values []domain.DockerServiceAssignment, serviceID int64) string {
	parts := make([]string, 0)
	for _, item := range values {
		if item.ServiceID != serviceID {
			continue
		}
		parts = append(parts, nonEmpty(environmentCode(item.Environment), item.OperationalStatus, item.SolutionType, item.ComponentName, item.RoleName)...)
		if item.Source != "" {
			parts = append(parts, item.Source)
		}
	}
	return strings.Join(parts, " · ")
}

func serviceDockerXML(data ServiceGenerationData) string {
	if len(data.DockerContainers) == 0 {
		return paragraph("Nu există containere Docker asociate direct acestui serviciu.", "IntenseQuote")
	}
	rows := make([][]string, 0, len(data.DockerContainers))
	for _, c := range data.DockerContainers {
		compose := strings.Trim(strings.Join(nonEmpty(c.ComposeProject, c.ComposeService), " / "), " /")
		rows = append(rows, []string{
			firstNonEmpty(c.VMHostname, c.VMName, fmt.Sprintf("VM #%d", c.VMID)),
			c.Name,
			c.Image,
			firstNonEmpty(compose, "—"),
			firstNonEmpty(c.State, c.Status, "—"),
			dockerPortSummary(c.Ports),
			firstNonEmpty(dockerAssignmentForService(c.ServiceAssignments, data.Service.ID), "—"),
		})
	}
	return tableWithWidths([]string{"VM gazdă", "Container", "Imagine", "Compose", "Stare", "Porturi", "Mediu / status / tip soluție / componentă / rol"}, rows, []int{1300, 1400, 1600, 1200, 850, 1400, 2100})
}

func webAssignmentForService(values []domain.WebServiceAssignment, serviceID int64) string {
	parts := make([]string, 0)
	for _, item := range values {
		if item.ServiceID != serviceID {
			continue
		}
		parts = append(parts, nonEmpty(environmentCode(item.Environment), item.OperationalStatus, item.SolutionType, item.ComponentName, item.RoleName)...)
	}
	return strings.Join(parts, " · ")
}

func serviceWebXML(data ServiceGenerationData) string {
	if len(data.WebSites) == 0 {
		return ""
	}
	rows := make([][]string, 0, len(data.WebSites))
	for _, site := range data.WebSites {
		rows = append(rows, []string{
			firstNonEmpty(site.VMHostname, site.VMName, fmt.Sprintf("VM #%d", site.VMID)),
			firstNonEmpty(site.Name, "—"),
			firstNonEmpty(site.Product, site.Engine),
			firstNonEmpty(strings.Join(site.ServerNames, ", "), "—"),
			webBindingSummary(site.Bindings),
			webTargetSummary(site),
			firstNonEmpty(webAssignmentForService(site.ServiceAssignments, data.Service.ID), "—"),
		})
	}
	return tableWithWidths([]string{"VM gazdă", "Site / frontend", "Engine", "Nume publice", "Bind", "Root / backend / proxy", "Mediu / status / tip soluție / componentă / rol"}, rows, []int{1200, 1400, 1100, 1400, 1200, 2050, 2050})
}

func serviceAllDependencies(service domain.InternalService) []domain.ServiceDependency {
	out := make([]domain.ServiceDependency, 0, len(service.Dependencies)+len(service.GlobalDependencies))
	for _, group := range [][]domain.ServiceDependency{service.Dependencies, service.GlobalDependencies} {
		for _, item := range group {
			if !item.Global && !item.Active {
				continue
			}
			// Every explicit row is one integration flow. Keep multiple rows even
			// when they point to the same service with the same relationship type.
			out = append(out, item)
		}
	}
	return out
}

func serviceDependencyEnvironment(item domain.ServiceDependency) string {
	source := firstNonEmpty(item.SourceEnvironment, "Oricare")
	target := firstNonEmpty(item.TargetEnvironment, "Oricare")
	return source + " → " + target
}

func serviceDependencyEndpoint(item domain.ServiceDependency) string {
	parts := make([]string, 0, 2)
	if strings.TrimSpace(item.Protocol) != "" {
		parts = append(parts, strings.TrimSpace(item.Protocol))
	}
	if item.Port != nil && *item.Port > 0 {
		parts = append(parts, strconv.Itoa(*item.Port))
	}
	return firstNonEmpty(strings.Join(parts, "/"), "—")
}

func serviceDependencyCriticality(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "informational":
		return "Informativă"
	case "critical":
		return "Critică"
	default:
		return "Normală"
	}
}

func serviceEnvironmentXML(assignments []domain.InternalServiceVM) string {
	byVM := make(map[int64]domain.InternalServiceVM)
	for _, item := range assignments {
		if _, ok := byVM[item.ID]; !ok {
			byVM[item.ID] = item
		}
	}
	if len(byVM) == 0 {
		return paragraph("Nu există VM-uri asociate serviciului.", "IntenseQuote")
	}
	values := make([]domain.InternalServiceVM, 0, len(byVM))
	for _, item := range byVM {
		values = append(values, item)
	}
	sort.SliceStable(values, func(i, j int) bool {
		ei, ej := strings.TrimSpace(values[i].Environment), strings.TrimSpace(values[j].Environment)
		if ei == "" {
			ei = "Nespecificat"
		}
		if ej == "" {
			ej = "Nespecificat"
		}
		ri, rj := serviceEnvironmentRank(ei), serviceEnvironmentRank(ej)
		if ri != rj {
			return ri < rj
		}
		if !strings.EqualFold(ei, ej) {
			return strings.ToLower(ei) < strings.ToLower(ej)
		}
		return strings.ToLower(firstNonEmpty(values[i].GuestHostname, values[i].Name)) < strings.ToLower(firstNonEmpty(values[j].GuestHostname, values[j].Name))
	})
	rows := make([][]string, 0, len(values))
	for _, item := range values {
		env := environmentCode(item.Environment)
		if env == "" {
			env = "Nespecificat"
		}
		rows = append(rows, []string{env, firstNonEmpty(item.GuestHostname, item.Name), emptyDash(item.PrimaryIP)})
	}
	return tableWithWidths([]string{"Mediu", "Mașină", "IP"}, rows, []int{1900, 4300, 2800})
}
func serviceSupplementalTextXML(value string) string {
	value = strings.ReplaceAll(value, "\r\n", "\n")
	value = strings.ReplaceAll(value, "\r", "\n")
	if strings.TrimSpace(value) == "" {
		return paragraph("Documentul suplimentar nu conține text extractibil.", "IntenseQuote")
	}
	var out strings.Builder
	for _, line := range strings.Split(value, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		out.WriteString(paragraph(line, ""))
	}
	return out.String()
}

func serviceEnvironmentRank(value string) int {
	v := strings.ToLower(strings.TrimSpace(value))
	switch {
	case strings.Contains(v, "prod") || strings.Contains(v, "produc"):
		return 10
	case strings.Contains(v, "test") || strings.Contains(v, "uat") || strings.Contains(v, "qa"):
		return 20
	case strings.Contains(v, "dev") || strings.Contains(v, "dezvolt"):
		return 30
	default:
		return 100
	}
}

func serviceVMDocumentReferencesXML(data ServiceGenerationData) string {
	if len(data.VMDocuments) == 0 {
		return paragraph("Nu există încă fișe VM generate pentru mașinile acestui serviciu.", "IntenseQuote")
	}
	var out strings.Builder
	for _, doc := range data.VMDocuments {
		label := firstNonEmpty(doc.VMName, "VM") + " — " + doc.DocumentNumber
		out.WriteString(`<w:p><w:pPr><w:spacing w:after="60"/></w:pPr><w:r><w:t xml:space="preserve">` + xmlText(label+"  ") + `</w:t></w:r>`)
		if doc.DownloadURL != "" {
			out.WriteString(docxHyperlink(doc.DownloadURL, "Deschide fișa"))
		} else {
			out.WriteString(`<w:r><w:rPr><w:color w:val="666666"/></w:rPr><w:t>link indisponibil</w:t></w:r>`)
		}
		out.WriteString(`</w:p>`)
	}
	return out.String()
}

func serviceVMAnnexTable(documents []ServiceVMDocument) string {
	rows := make([][]string, 0, len(documents))
	for index, doc := range documents {
		rows = append(rows, []string{"A" + strconv.Itoa(index+1), doc.VMName, emptyDash(environmentCode(doc.Environment)), doc.DocumentNumber, formatTime(doc.GeneratedAt)})
	}
	return tableWithWidths([]string{"Anexa", "VM", "Mediu", "Fișă", "Generată"}, rows, []int{1100, 2100, 1300, 2700, 1800})
}

func docxHyperlink(url, label string) string {
	if strings.TrimSpace(url) == "" {
		return ""
	}
	return `<w:fldSimple w:instr="HYPERLINK &quot;` + xmlText(url) + `&quot;"><w:r><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr><w:t>` + xmlText(label) + `</w:t></w:r></w:fldSimple>`
}

type serviceDiagramVM struct {
	ID          int64
	Name        string
	Hostname    string
	PrimaryIP   string
	PowerState  string
	Environment string
	Assignments []domain.InternalServiceVM
}

type serviceDiagramLane struct {
	Name string
	VMs  []serviceDiagramVM
}

func serviceDiagramXML(assignments []domain.InternalServiceVM) string {
	lanes := buildServiceDiagramLanes(assignments)
	var out strings.Builder
	for _, lane := range lanes {
		out.WriteString(serviceDiagramLaneHeader(lane.Name, len(lane.VMs)))
		for _, vm := range lane.VMs {
			out.WriteString(serviceDiagramVMTable(vm))
		}
	}
	return out.String()
}

func buildServiceDiagramLanes(assignments []domain.InternalServiceVM) []serviceDiagramLane {
	byVM := make(map[int64]*serviceDiagramVM)
	order := make([]int64, 0)
	for _, item := range assignments {
		vm := byVM[item.ID]
		if vm == nil {
			vm = &serviceDiagramVM{ID: item.ID, Name: item.Name, Hostname: item.GuestHostname, PrimaryIP: item.PrimaryIP, PowerState: item.PowerState, Environment: item.Environment}
			byVM[item.ID] = vm
			order = append(order, item.ID)
		}
		vm.Assignments = append(vm.Assignments, item)
	}

	laneMap := make(map[string]*serviceDiagramLane)
	for _, id := range order {
		vm := byVM[id]
		layerNames := make(map[string]bool)
		for _, item := range vm.Assignments {
			if name := strings.TrimSpace(item.LayerName); name != "" {
				layerNames[name] = true
			}
		}
		laneName := "Fără layer"
		if len(layerNames) == 1 {
			for name := range layerNames {
				laneName = name
			}
		} else if len(layerNames) > 1 {
			laneName = "Multi-layer"
		}
		lane := laneMap[laneName]
		if lane == nil {
			lane = &serviceDiagramLane{Name: laneName}
			laneMap[laneName] = lane
		}
		lane.VMs = append(lane.VMs, *vm)
	}

	lanes := make([]serviceDiagramLane, 0, len(laneMap))
	for _, lane := range laneMap {
		sort.SliceStable(lane.VMs, func(i, j int) bool {
			return strings.ToLower(firstNonEmpty(lane.VMs[i].Hostname, lane.VMs[i].Name)) < strings.ToLower(firstNonEmpty(lane.VMs[j].Hostname, lane.VMs[j].Name))
		})
		lanes = append(lanes, *lane)
	}
	sort.SliceStable(lanes, func(i, j int) bool {
		if lanes[i].Name == "Multi-layer" {
			return false
		}
		if lanes[j].Name == "Multi-layer" {
			return true
		}
		if lanes[i].Name == "Fără layer" {
			return false
		}
		if lanes[j].Name == "Fără layer" {
			return true
		}
		return strings.ToLower(lanes[i].Name) < strings.ToLower(lanes[j].Name)
	})
	return lanes
}

func serviceRichNarrativeBox(title string, document *domain.RichTextDocument, fallback string) string {
	if document == nil {
		document = richtext.FromPlain(fallback)
	}
	body := serviceRichTextParagraphs(document)
	if strings.TrimSpace(body) == "" {
		body = `<w:p><w:r><w:t>—</w:t></w:r></w:p>`
	}
	return `<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:top w:val="single" w:sz="6" w:color="D8DEE8"/><w:left w:val="single" w:sz="6" w:color="D8DEE8"/><w:bottom w:val="single" w:sz="6" w:color="D8DEE8"/><w:right w:val="single" w:sz="6" w:color="D8DEE8"/></w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="9500"/></w:tblGrid>` +
		`<w:tr><w:tc><w:tcPr><w:tcW w:w="9500" w:type="dxa"/><w:shd w:val="clear" w:fill="F7FAFC"/><w:tcMar><w:top w:w="120" w:type="dxa"/><w:left w:w="130" w:type="dxa"/><w:bottom w:w="120" w:type="dxa"/><w:right w:w="130" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:keepNext/><w:spacing w:after="80"/><w:pBdr><w:bottom w:val="single" w:sz="5" w:color="D8DEE8" w:space="4"/></w:pBdr></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>` + xmlText(title) + `</w:t></w:r></w:p>` + body + `</w:tc></w:tr></w:tbl><w:p/>`
}

func serviceRichTextParagraphs(document *domain.RichTextDocument) string {
	if document == nil || len(document.Blocks) == 0 {
		return ""
	}
	var out strings.Builder
	numberCounters := make([]int, richtext.MaxIndentLevel+1)
	previousType := ""
	previousLevel := 0
	for _, block := range document.Blocks {
		level := block.Level
		if level < 0 {
			level = 0
		}
		if level > richtext.MaxIndentLevel {
			level = richtext.MaxIndentLevel
		}
		leftIndent := 0
		hanging := 0
		prefix := ""
		switch block.Type {
		case "bullet":
			leftIndent = 420 + level*360
			hanging = 260
			prefix = "• "
		case "number":
			if previousType != "number" || level > previousLevel {
				numberCounters[level] = 0
			}
			for i := level + 1; i < len(numberCounters); i++ {
				numberCounters[i] = 0
			}
			numberCounters[level]++
			leftIndent = 500 + level*360
			hanging = 320
			prefix = strconv.Itoa(numberCounters[level]) + ". "
		}
		pPr := `<w:pPr><w:spacing w:after="70"/>`
		if leftIndent > 0 {
			pPr += `<w:ind w:left="` + strconv.Itoa(leftIndent) + `" w:hanging="` + strconv.Itoa(hanging) + `"/>`
		}
		pPr += `</w:pPr>`
		out.WriteString(`<w:p>` + pPr)
		if prefix != "" {
			out.WriteString(`<w:r><w:t xml:space="preserve">` + xmlText(prefix) + `</w:t></w:r>`)
		}
		if len(block.Runs) == 0 {
			out.WriteString(`<w:r><w:t></w:t></w:r>`)
		} else {
			for _, run := range block.Runs {
				out.WriteString(serviceRichTextRunXML(run))
			}
		}
		out.WriteString(`</w:p>`)
		previousType = block.Type
		previousLevel = level
	}
	return out.String()
}

func serviceRichTextRunXML(run domain.RichTextRun) string {
	properties := ""
	if run.Bold || run.Italic || run.Underline {
		var p strings.Builder
		p.WriteString(`<w:rPr>`)
		if run.Bold {
			p.WriteString(`<w:b/>`)
		}
		if run.Italic {
			p.WriteString(`<w:i/>`)
		}
		if run.Underline {
			p.WriteString(`<w:u w:val="single"/>`)
		}
		p.WriteString(`</w:rPr>`)
		properties = p.String()
	}
	parts := strings.Split(strings.ReplaceAll(strings.ToValidUTF8(run.Text, "�"), "\r\n", "\n"), "\n")
	var content strings.Builder
	for index, part := range parts {
		if index > 0 {
			content.WriteString(`<w:br/>`)
		}
		if part != "" {
			content.WriteString(`<w:t xml:space="preserve">` + xmlText(part) + `</w:t>`)
		}
	}
	return `<w:r>` + properties + content.String() + `</w:r>`
}

func serviceNarrativeBox(title, value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		value = "—"
	}
	return `<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:top w:val="single" w:sz="6" w:color="D8DEE8"/><w:left w:val="single" w:sz="6" w:color="D8DEE8"/><w:bottom w:val="single" w:sz="6" w:color="D8DEE8"/><w:right w:val="single" w:sz="6" w:color="D8DEE8"/></w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="9500"/></w:tblGrid>` +
		`<w:tr><w:tc><w:tcPr><w:tcW w:w="9500" w:type="dxa"/><w:shd w:val="clear" w:fill="F7FAFC"/><w:tcMar><w:top w:w="120" w:type="dxa"/><w:left w:w="130" w:type="dxa"/><w:bottom w:w="120" w:type="dxa"/><w:right w:w="130" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:keepNext/><w:spacing w:after="80"/><w:pBdr><w:bottom w:val="single" w:sz="5" w:color="D8DEE8" w:space="4"/></w:pBdr></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>` + xmlText(title) + `</w:t></w:r></w:p>` + serviceNarrativeParagraphs(value) + `</w:tc></w:tr></w:tbl><w:p/>`
}

func serviceNarrativeParagraphs(value string) string {
	lines := strings.Split(strings.ReplaceAll(value, "\r\n", "\n"), "\n")
	var out strings.Builder
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			out.WriteString(`<w:p><w:pPr><w:spacing w:after="60"/></w:pPr></w:p>`)
			continue
		}
		out.WriteString(`<w:p><w:pPr><w:spacing w:after="70"/></w:pPr><w:r><w:t xml:space="preserve">` + xmlText(line) + `</w:t></w:r></w:p>`)
	}
	return out.String()
}

func serviceDiagramLaneHeader(name string, vmCount int) string {
	label := fmt.Sprintf("%s  ·  %d VM", emptyDash(name), vmCount)
	return `<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid><w:gridCol w:w="9500"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="9500" w:type="dxa"/><w:shd w:val="clear" w:fill="DCE6F1"/><w:tcMar><w:top w:w="90" w:type="dxa"/><w:left w:w="120" w:type="dxa"/><w:bottom w:w="90" w:type="dxa"/><w:right w:w="120" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>` + xmlText(label) + `</w:t></w:r></w:p></w:tc></w:tr></w:tbl>`
}

func serviceDiagramVMTable(vm serviceDiagramVM) string {
	name := firstNonEmpty(vm.Hostname, vm.Name, "VM")
	if vm.Name != "" && vm.Name != name {
		name += " (" + vm.Name + ")"
	}
	meta := strings.Join(nonEmpty(environmentCode(vm.Environment), vm.PrimaryIP, vm.PowerState), " · ")
	var associations strings.Builder
	for index, item := range vm.Assignments {
		if index > 0 {
			associations.WriteString(`<w:p><w:pPr><w:spacing w:before="50" w:after="50"/><w:pBdr><w:top w:val="dashed" w:sz="4" w:color="D8DEE8"/></w:pBdr></w:pPr></w:p>`)
		}
		role := firstNonEmpty(item.TechnicalRole, "Rol nespecificat")
		layer := firstNonEmpty(item.LayerName, "Fără layer")
		context := strings.Join(nonEmpty(item.SolutionType, serviceClassificationText(item), serviceUsageLabel(item.UsageType)), " · ")
		if item.Primary {
			context = strings.TrimSpace(context + " · principal")
		}
		associations.WriteString(`<w:p><w:pPr><w:spacing w:after="20"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>` + xmlText(role) + `</w:t></w:r><w:r><w:t xml:space="preserve">` + xmlText("  |  "+layer) + `</w:t></w:r></w:p>`)
		associations.WriteString(`<w:p><w:pPr><w:spacing w:after="20"/></w:pPr><w:r><w:rPr><w:color w:val="666666"/><w:sz w:val="18"/></w:rPr><w:t xml:space="preserve">` + xmlText(emptyDash(context)) + `</w:t></w:r></w:p>`)
	}
	return `<w:tbl><w:tblPr><w:tblW w:w="9500" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:top w:val="single" w:sz="6" w:color="C9D1DC"/><w:left w:val="single" w:sz="6" w:color="C9D1DC"/><w:bottom w:val="single" w:sz="6" w:color="C9D1DC"/><w:right w:val="single" w:sz="6" w:color="C9D1DC"/><w:insideH w:val="single" w:sz="4" w:color="E3E7ED"/><w:insideV w:val="single" w:sz="4" w:color="E3E7ED"/></w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="2850"/><w:gridCol w:w="6650"/></w:tblGrid>` +
		`<w:tr><w:tc><w:tcPr><w:tcW w:w="2850" w:type="dxa"/><w:shd w:val="clear" w:fill="F5F7FA"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="100" w:type="dxa"/><w:left w:w="110" w:type="dxa"/><w:bottom w:w="100" w:type="dxa"/><w:right w:w="110" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>` + xmlText(name) + `</w:t></w:r></w:p><w:p><w:r><w:rPr><w:color w:val="666666"/><w:sz w:val="18"/></w:rPr><w:t>` + xmlText(emptyDash(meta)) + `</w:t></w:r></w:p></w:tc>` +
		`<w:tc><w:tcPr><w:tcW w:w="6650" w:type="dxa"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="90" w:type="dxa"/><w:left w:w="110" w:type="dxa"/><w:bottom w:w="90" w:type="dxa"/><w:right w:w="110" w:type="dxa"/></w:tcMar></w:tcPr>` + associations.String() + `</w:tc></w:tr></w:tbl><w:p/>`
}

func serviceVMOverviewTable(assignments []domain.InternalServiceVM) string {
	byVM := make(map[int64]*serviceDiagramVM)
	order := make([]int64, 0)
	for _, item := range assignments {
		vm := byVM[item.ID]
		if vm == nil {
			vm = &serviceDiagramVM{ID: item.ID, Name: item.Name, Hostname: item.GuestHostname, PrimaryIP: item.PrimaryIP, PowerState: item.PowerState, Environment: item.Environment}
			byVM[item.ID] = vm
			order = append(order, item.ID)
		}
		vm.Assignments = append(vm.Assignments, item)
	}
	sort.SliceStable(order, func(i, j int) bool {
		left := strings.ToLower(firstNonEmpty(byVM[order[i]].Hostname, byVM[order[i]].Name))
		right := strings.ToLower(firstNonEmpty(byVM[order[j]].Hostname, byVM[order[j]].Name))
		return left < right
	})
	rows := make([][]string, 0, len(order))
	for _, id := range order {
		vm := byVM[id]
		name := firstNonEmpty(vm.Hostname, vm.Name)
		identity := name
		if vm.PrimaryIP != "" {
			identity += " · " + vm.PrimaryIP
		}
		associationTexts := make([]string, 0, len(vm.Assignments))
		usageSeen := make(map[string]bool)
		usageTexts := make([]string, 0)
		primary := false
		for _, item := range vm.Assignments {
			associationTexts = append(associationTexts, strings.Join(nonEmpty(firstNonEmpty(item.LayerName, "Fără layer"), firstNonEmpty(item.TechnicalRole, "Rol nespecificat"), item.SolutionType), " / "))
			usage := serviceUsageLabel(item.UsageType)
			if usage != "" && !usageSeen[usage] {
				usageSeen[usage] = true
				usageTexts = append(usageTexts, usage)
			}
			primary = primary || item.Primary
		}
		usage := strings.Join(usageTexts, ", ")
		if primary {
			usage = strings.TrimSpace(usage + " · principal")
		}
		first := vm.Assignments[0]
		rows = append(rows, []string{identity, emptyDash(environmentCode(first.Environment)), strings.Join(associationTexts, "; "), usage})
	}
	return tableWithWidths([]string{"VM / IP", "Mediu", "Asocieri tehnice", "Utilizare"}, rows, []int{2200, 1200, 3900, 1700})
}

func serviceClassificationText(item domain.InternalServiceVM) string {
	domainName := strings.TrimSpace(item.ArchitecturalDomain)
	categoryName := strings.TrimSpace(item.ITILCategory)
	if domainName == "" {
		return categoryName
	}
	if categoryName == "" {
		return domainName
	}
	return domainName + " / " + categoryName
}

func serviceUsageLabel(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "dedicated":
		return "Dedicat"
	case "shared":
		return "Partajat"
	case "dependency":
		return "Dependență"
	default:
		return strings.TrimSpace(value)
	}
}

func updateServiceCoreProperties(text string, data ServiceGenerationData) string {
	text = replaceXMLTag(text, "dc:title", "Fișă tehnică și operațională a serviciului — "+data.Service.Name)
	text = replaceXMLTag(text, "dc:creator", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username, "vm-doc-server"))
	text = replaceXMLTag(text, "cp:lastModifiedBy", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username, "vm-doc-server"))
	text = replaceXMLTag(text, "dcterms:modified", data.GeneratedAt.UTC().Format("2006-01-02T15:04:05Z"))
	return text
}
