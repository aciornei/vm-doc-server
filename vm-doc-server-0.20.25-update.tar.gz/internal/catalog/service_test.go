package catalog

import (
	"testing"

	"vm-doc-server/internal/domain"
)

func TestNormalizeService(t *testing.T) {
	input := InternalServiceInput{Name: "  Metabase ", ServiceCode: " BI.METABASE ", Purpose: "  Raportare internă  ", Objectives: "  Dashboard-uri standardizate  ", Criticality: " HIGH ", DocumentationStatus: " IN_PROGRESS "}
	if err := normalizeService(&input); err != nil {
		t.Fatal(err)
	}
	if input.Name != "Metabase" || input.ServiceCode != "bi.metabase" || input.Purpose != "Raportare internă" || input.Objectives != "Dashboard-uri standardizate" || input.Criticality != "high" || input.DocumentationStatus != "in_progress" {
		t.Fatalf("unexpected normalization: %#v", input)
	}
}

func TestNormalizeServiceRejectsInvalidValues(t *testing.T) {
	tests := []InternalServiceInput{
		{},
		{Name: "X", Criticality: "urgent"},
		{Name: "X", DocumentationStatus: "done"},
		{Name: "X", ServiceCode: "BAD CODE"},
		{Name: "X", DocumentationURL: "file:///tmp/x"},
	}
	for i := range tests {
		if err := normalizeService(&tests[i]); err == nil {
			t.Fatalf("test %d: expected error", i)
		}
	}
}

func TestNormalizeServiceRichTextKeepsPlainCompatibility(t *testing.T) {
	input := InternalServiceInput{
		Name: "Serviciu",
		PurposeRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{
			{Type: "paragraph", Runs: []domain.RichTextRun{{Text: "Arie ", Bold: true}, {Text: "funcțională"}}},
		}},
		ObjectivesRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{
			{Type: "bullet", Runs: []domain.RichTextRun{{Text: "Primul obiectiv", Italic: true}}},
			{Type: "bullet", Level: 1, Runs: []domain.RichTextRun{{Text: "Sub-obiectiv"}}},
		}},
	}
	if err := normalizeService(&input); err != nil {
		t.Fatal(err)
	}
	if input.Purpose != "Arie funcțională" {
		t.Fatalf("unexpected purpose compatibility text: %q", input.Purpose)
	}
	if input.Objectives != "• Primul obiectiv\n  • Sub-obiectiv" {
		t.Fatalf("unexpected objectives compatibility text: %q", input.Objectives)
	}
}

func TestNormalizeServiceRequiresDependencyTypeForCommonService(t *testing.T) {
	common := true
	input := InternalServiceInput{Name: "DNS", IsCommon: &common}
	if err := normalizeService(&input); err == nil {
		t.Fatal("expected common service without dependency type to be rejected")
	}
	dependencyTypeID := int64(10)
	input = InternalServiceInput{Name: "DNS", IsCommon: &common, CommonDependencyTypeID: &dependencyTypeID}
	if err := normalizeService(&input); err != nil {
		t.Fatal(err)
	}
}

func TestNormalizeDependencyInput(t *testing.T) {
	port := 443
	input := DependencyInput{Criticality: " CRITICAL ", Protocol: " HTTPS ", Port: &port, Notes: " OIDC "}
	if err := normalizeDependencyInput(&input); err != nil {
		t.Fatal(err)
	}
	if input.Criticality != "critical" || input.Protocol != "HTTPS" || input.Notes != "OIDC" || input.Port == nil || *input.Port != 443 {
		t.Fatalf("unexpected dependency normalization: %#v", input)
	}
}

func TestNormalizeDependencyInputDefaultsAndRejectsInvalid(t *testing.T) {
	input := DependencyInput{}
	if err := normalizeDependencyInput(&input); err != nil {
		t.Fatal(err)
	}
	if input.Criticality != "normal" {
		t.Fatalf("expected normal default, got %q", input.Criticality)
	}
	badCriticality := DependencyInput{Criticality: "urgent"}
	if err := normalizeDependencyInput(&badCriticality); err == nil {
		t.Fatal("expected invalid dependency criticality to be rejected")
	}
	badPort := 70000
	bad := DependencyInput{Port: &badPort}
	if err := normalizeDependencyInput(&bad); err == nil {
		t.Fatal("expected invalid dependency port to be rejected")
	}
}

func TestVMDependencyMergeKeyKeepsExplicitFlowsSeparate(t *testing.T) {
	left := domain.ServiceDependency{ID: 101, TargetServiceID: 20, DependencyTypeID: 30}
	right := domain.ServiceDependency{ID: 102, TargetServiceID: 20, DependencyTypeID: 30}
	if vmDependencyMergeKey(left) == vmDependencyMergeKey(right) {
		t.Fatal("explicit dependency rows with different ids must remain separate flows")
	}
	globalA := domain.ServiceDependency{TargetServiceID: 20, DependencyTypeID: 30, Global: true}
	globalB := domain.ServiceDependency{TargetServiceID: 20, DependencyTypeID: 30, Global: true}
	if vmDependencyMergeKey(globalA) != vmDependencyMergeKey(globalB) {
		t.Fatal("the same global dependency should still collapse to one row")
	}
}
