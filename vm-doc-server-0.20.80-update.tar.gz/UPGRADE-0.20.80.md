# Upgrade VM-DOC Server 0.20.79 → 0.20.80

0.20.80 este un update de UI pentru Network Map. Nu există migrare DB și nu este necesar un Sync FortiGate după upgrade.

## Pași

```bash
systemctl stop vm-doc-server
cp -a /usr/local/src/vm-doc-server-0.20.79 /usr/local/src/vm-doc-server-0.20.80
tar -xzf vm-doc-server-0.20.80-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.80
cd /usr/local/src/vm-doc-server-0.20.80
# build/deploy conform procedurii locale
systemctl start vm-doc-server
```

## Verificări recomandate

1. Deschide un VM → Securitate → Hartă rețea și verifică o regulă cu VM corelat în sursă: numele VM-DOC trebuie să apară o singură dată, iar IP-urile/obiectele Forti dedesubt.
2. Verifică o policy cu mai multe servicii: toate serviciile trebuie să fie pe linii separate sub `SERVICII / PORTURI PERMISE`.
3. Verifică un VM cu UDP listening ports: acestea nu trebuie să apară în nodul VM din diagramă.
4. Verifică unul dintre serverele DNS: portul 53 nu trebuie să apară în lista de porturi observate din diagramă.
5. Confirmă că detaliile tehnice și datele FortiGate rămân neschimbate; filtrarea este doar pentru diagramă.

Agentul rămâne 1.7.12.
