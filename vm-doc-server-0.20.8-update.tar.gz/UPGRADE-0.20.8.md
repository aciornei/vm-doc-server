# Upgrade vm-doc-server 0.20.7 → 0.20.8

0.20.8 este un hotfix pentru deschiderea fișei Serviciului atunci când există Site-uri Web asociate.

## Upgrade offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.7 vm-doc-server-0.20.8
tar -xzf /cale/vm-doc-server-0.20.8-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.8
cd /usr/local/src/vm-doc-server-0.20.8
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Păstrați `vendor/`, `go.mod` și `go.sum` din arborele 0.20.7 care compilează deja în mediul offline. Update-ul 0.20.8 nu le modifică.

Nu există migrare DB și nu este necesar update de agent.
