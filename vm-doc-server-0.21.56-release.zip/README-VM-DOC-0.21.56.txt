VM-DOC Server 0.21.56 release
Source archive 0.21.56-source.zip; apply patch OR update.tar.gz over exactly 0.21.55 source, not both.
No compiled server binary. Vendor/ dependencies required for full Go build.
Cleanup SQL is cumulative 0.21.50–0.21.56 and MUST only run after backup and preview on staging.
See UPGRADE-0.21.56.md and VERIFICATION-0.21.56.txt.
