# Upgrade VM-DOC Server 0.21.68 → 0.21.69

1. Backup complet binar, configurație, surse și MariaDB. Testează mai întâi în staging.
2. Aplică fie `vm-doc-server-0.21.68-to-0.21.69.patch`, fie arhiva `vm-doc-server-0.21.69-update.tar.gz` peste **sursele 0.21.68**; nu le aplica pe ambele. Alternativ folosește source.zip complet.
3. Compilează cu `vendor/` din mediul offline: `GOPROXY=off GOSUMDB=off go test ./...`, `node --check web/static/js/app.js`, `GOPROXY=off GOSUMDB=off go build -o vm-doc-server ./cmd/vm-doc-server` (adaptează comanda procedurii interne).
4. Înlocuiește binarul Go deoarece JavaScript este `go:embed`; repornește și verifică versiunea `0.21.69` și `app.js?v=0.21.69`.
5. Testează pe o VM Docker: rotația bridge-urilor `br-<12 hex>` nu trebuie să mai genereze evenimente noi pentru regulile automate iptables/ipv4/nat/POSTROUTING `-j MASQUERADE`. Verifică și că NAT explicit, DOCKER-USER și schimbările reale sunt în continuare monitorizate.
6. Pentru istoric: rulează **manual** `scripts/preview-iptables-nat-docker-02169.sql`, inspectează exemplele, fă backup recuperabil, oprește vm-doc-server și **doar dacă ai validat candidaturile în staging**, rulează `scripts/cleanup-iptables-nat-docker-02169.sql`. Niciun SQL de cleanup nu este automat. Protecția rândurilor revizuite, cu decizii sau note rămâne activă.
7. La rollback revino la binarul 0.21.68. Datele nu necesită migrare inversă, însă zgomotul nou poate reapărea. Ștergerile SQL istorice se pot anula **numai prin restaurarea backupului**.

**Fără migrare SQL nouă, fără modificări de API, agentul rămâne 1.7.18.** Testarea completă offline și SQL/MariaDB reală trebuie făcută în staging.
