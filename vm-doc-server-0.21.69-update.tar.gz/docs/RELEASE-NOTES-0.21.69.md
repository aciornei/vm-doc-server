# VM-DOC Server 0.21.69 — iptables Docker NAT

**Defect:** Docker reconstruiește bridge-urile iar în `inventory_changes` se generează perechi adăugat/eliminat pentru reguli de tip `-A POSTROUTING -s 172.18.0.0/16 ! -o br-<12hex> -j MASQUERADE` (iptables, IPv4, NAT).

**Remediere:** evenimentul este suprimat înainte de salvare numai când toate condițiile iptables/ipv4/nat/POSTROUTING, RFC1918 CIDR și `br-<12hex>` sunt îndeplinite. Celelalte reguli rămân vizibile.

**Istoric:** `scripts/preview-iptables-nat-docker-02169.sql` și `scripts/cleanup-iptables-nat-docker-02169.sql` — manual, backup + staging, fără impact pe inventarele brute.

**Agent:** 1.7.18, nemodificat. **Migrare schema:** nu. **API:** neschimbat.
