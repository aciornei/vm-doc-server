-- VM-DOC 0.21.69: zgomot NAT generat de Docker (iptables nat/POSTROUTING).
-- Forma stricta: -A POSTROUTING -s <CIDR privat> ! -o br-<12 hex> -j MASQUERADE
-- Afecteaza numai inventory_changes (added/removed), NU inventory_snapshots, firewall real sau auditul operational.
-- Pastreaza orice eveniment revizuit, cu decizie/observatii sau utilizator care a revizuit.
-- Foloseste backup RESTAURABIL, verifica DB, PREVIEW si test staging inainte de orice stergere.
-- Observatie: SQL filtreaza conservator textual CIDR privat; detectorul Go valideaza suplimentar IP/prefix si alinierea la subretea.

SELECT DATABASE() AS baza_selectata;
-- Candidati eligibili de sters.
SELECT COUNT(*) AS candidati_iptables_nat_masquerade
FROM inventory_changes c
WHERE c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')=''
  AND c.reviewed_by IS NULL
  AND c.category='firewall'
  AND c.object_type='rule'
  AND c.change_type IN ('added','removed')
  AND c.object_key LIKE 'firewall|rule|iptables|ipv4|nat|POSTROUTING|%'
  AND JSON_VALID(COALESCE(c.new_json,c.old_json))=1
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.backend')) ELSE '' END='iptables'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.family')) ELSE '' END='ipv4'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.table')) ELSE '' END='nat'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.chain')) ELSE '' END='POSTROUTING'
  AND (COALESCE(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.action')) ELSE '' END,'') IN ('','MASQUERADE'))
  AND TRIM(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')) ELSE '' END) REGEXP '^-A POSTROUTING -s (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}/(8|9|1[0-9]|2[0-9]|3[0-2])|172[.](1[6-9]|2[0-9]|3[01])[.]([0-9]{1,3}[.])[0-9]{1,3}/(1[2-9]|2[0-9]|3[0-2])|192[.]168[.]([0-9]{1,3}[.])[0-9]{1,3}/(1[6-9]|2[0-9]|3[0-2])) ! -o br-[0-9a-fA-F]{12} -j MASQUERADE$';

-- Pe VM si tip de modificare, ca sa vezi distribuitia.
SELECT c.vm_id,c.change_type,COUNT(*) AS candidate
FROM inventory_changes c
WHERE c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')=''
  AND c.reviewed_by IS NULL
  AND c.category='firewall'
  AND c.object_type='rule'
  AND c.change_type IN ('added','removed')
  AND c.object_key LIKE 'firewall|rule|iptables|ipv4|nat|POSTROUTING|%'
  AND JSON_VALID(COALESCE(c.new_json,c.old_json))=1
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.backend')) ELSE '' END='iptables'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.family')) ELSE '' END='ipv4'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.table')) ELSE '' END='nat'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.chain')) ELSE '' END='POSTROUTING'
  AND (COALESCE(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.action')) ELSE '' END,'') IN ('','MASQUERADE'))
  AND TRIM(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')) ELSE '' END) REGEXP '^-A POSTROUTING -s (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}/(8|9|1[0-9]|2[0-9]|3[0-2])|172[.](1[6-9]|2[0-9]|3[01])[.]([0-9]{1,3}[.])[0-9]{1,3}/(1[2-9]|2[0-9]|3[0-2])|192[.]168[.]([0-9]{1,3}[.])[0-9]{1,3}/(1[6-9]|2[0-9]|3[0-2])) ! -o br-[0-9a-fA-F]{12} -j MASQUERADE$'
GROUP BY c.vm_id,c.change_type ORDER BY candidate DESC LIMIT 60;

-- Exemple de verificat manual inainte de cleanup.
SELECT c.id,c.vm_id,c.occurred_at,c.change_type,c.object_label,
       CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')) ELSE '' END AS regula
FROM inventory_changes c
WHERE c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')=''
  AND c.reviewed_by IS NULL
  AND c.category='firewall'
  AND c.object_type='rule'
  AND c.change_type IN ('added','removed')
  AND c.object_key LIKE 'firewall|rule|iptables|ipv4|nat|POSTROUTING|%'
  AND JSON_VALID(COALESCE(c.new_json,c.old_json))=1
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.backend')) ELSE '' END='iptables'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.family')) ELSE '' END='ipv4'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.table')) ELSE '' END='nat'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.chain')) ELSE '' END='POSTROUTING'
  AND (COALESCE(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.action')) ELSE '' END,'') IN ('','MASQUERADE'))
  AND TRIM(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')) ELSE '' END) REGEXP '^-A POSTROUTING -s (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}/(8|9|1[0-9]|2[0-9]|3[0-2])|172[.](1[6-9]|2[0-9]|3[01])[.]([0-9]{1,3}[.])[0-9]{1,3}/(1[2-9]|2[0-9]|3[0-2])|192[.]168[.]([0-9]{1,3}[.])[0-9]{1,3}/(1[6-9]|2[0-9]|3[0-2])) ! -o br-[0-9a-fA-F]{12} -j MASQUERADE$'
ORDER BY c.occurred_at DESC,c.id DESC LIMIT 50;

-- Total pentru aceasta familie, cu toate starile de review (inclusiv cele protejate).
SELECT c.review_status,c.documentation_requirement,COUNT(*) AS evenimente
FROM inventory_changes c
WHERE c.category='firewall'
  AND c.object_type='rule'
  AND c.change_type IN ('added','removed')
  AND c.object_key LIKE 'firewall|rule|iptables|ipv4|nat|POSTROUTING|%'
  AND JSON_VALID(COALESCE(c.new_json,c.old_json))=1
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.backend')) ELSE '' END='iptables'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.family')) ELSE '' END='ipv4'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.table')) ELSE '' END='nat'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.chain')) ELSE '' END='POSTROUTING'
  AND (COALESCE(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.action')) ELSE '' END,'') IN ('','MASQUERADE'))
  AND TRIM(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))=1 THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')) ELSE '' END) REGEXP '^-A POSTROUTING -s (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}/(8|9|1[0-9]|2[0-9]|3[0-2])|172[.](1[6-9]|2[0-9]|3[01])[.]([0-9]{1,3}[.])[0-9]{1,3}/(1[2-9]|2[0-9]|3[0-2])|192[.]168[.]([0-9]{1,3}[.])[0-9]{1,3}/(1[6-9]|2[0-9]|3[0-2])) ! -o br-[0-9a-fA-F]{12} -j MASQUERADE$'
GROUP BY c.review_status,c.documentation_requirement;
