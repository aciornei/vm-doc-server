package inventorychanges

import (
	"encoding/json"
	"strings"
	"testing"
)

func iptablesDockerNATRule(subnet, bridge string) map[string]any {
	return map[string]any{
		"backend": "iptables", "family": "ipv4", "table": "nat", "chain": "POSTROUTING",
		"action": "MASQUERADE", "rule": "-A POSTROUTING -s " + subnet + " ! -o " + bridge + " -j MASQUERADE",
	}
}

func TestDockerIptablesNATMasqueradeSuppressesExactAutoRules(t *testing.T) {
	for _, cidr := range []string{"172.18.0.0/16", "172.19.0.0/16", "172.20.0.0/16", "10.88.0.0/16", "192.168.33.0/24"} {
		for _, bridge := range []string{"br-f392b3fbdb12", "br-87894e600741", "br-f7410327c933", "br-8214d3580664"} {
			r := iptablesDockerNATRule(cidr, bridge)
			if !isGeneratedFirewallRule(r) {
				t.Fatalf("missed generated Docker NAT rule: %+v", r)
			}
		}
	}
}

func TestDockerIptablesNATMasqueradePreservesOtherRules(t *testing.T) {
	base := iptablesDockerNATRule("172.18.0.0/16", "br-f392b3fbdb12")
	cases := []struct {
		name, key, value string
	}{
		{"action mismatch", "action", "ACCEPT"},
		{"backend nftables", "backend", "nftables"},
		{"backend ip6tables", "backend", "ip6tables"},
		{"family ip", "family", "ip"},
		{"family ipv6", "family", "ipv6"},
		{"table filter", "table", "filter"},
		{"chain input", "chain", "INPUT"},
		{"chain docker-user", "chain", "DOCKER-USER"},
		{"public source", "rule", "-A POSTROUTING -s 8.8.8.0/24 ! -o br-f392b3fbdb12 -j MASQUERADE"},
		{"prefix exceeds RFC1918", "rule", "-A POSTROUTING -s 172.0.0.0/8 ! -o br-f392b3fbdb12 -j MASQUERADE"},
		{"invalid prefix", "rule", "-A POSTROUTING -s 172.18.0.999/16 ! -o br-f392b3fbdb12 -j MASQUERADE"},
		{"unaligned prefix", "rule", "-A POSTROUTING -s 172.18.0.1/16 ! -o br-f392b3fbdb12 -j MASQUERADE"},
		{"stable bridge", "rule", "-A POSTROUTING -s 172.18.0.0/16 ! -o br-production -j MASQUERADE"},
		{"docker0", "rule", "-A POSTROUTING -s 172.18.0.0/16 ! -o docker0 -j MASQUERADE"},
		{"without negation", "rule", "-A POSTROUTING -s 172.18.0.0/16 -o br-f392b3fbdb12 -j MASQUERADE"},
		{"extra condition", "rule", "-A POSTROUTING -s 172.18.0.0/16 ! -o br-f392b3fbdb12 -p tcp -j MASQUERADE"},
		{"SNAT", "rule", "-A POSTROUTING -s 172.18.0.0/16 ! -o br-f392b3fbdb12 -j SNAT"},
		{"unexpected suffix", "rule", "-A POSTROUTING -s 172.18.0.0/16 ! -o br-f392b3fbdb12 -j MASQUERADE --random-fully"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			r := make(map[string]any, len(base))
			for k, v := range base {
				r[k] = v
			}
			r[tc.key] = tc.value
			if isGeneratedFirewallRule(r) {
				t.Fatalf("suppressed unrelated NAT/firewall rule: %+v", r)
			}
		})
	}
}

func TestIptablesNATBridgeRotationDoesNotCreateChangeEvents(t *testing.T) {
	makeSnap := func(bridge string) []byte {
		raw, _ := json.Marshal(map[string]any{"firewall": map[string]any{"rules": []any{
			iptablesDockerNATRule("172.19.0.0/16", bridge),
			iptablesDockerNATRule("172.18.0.0/16", bridge),
			map[string]any{"backend": "iptables", "family": "ipv4", "table": "nat", "chain": "POSTROUTING", "action": "MASQUERADE", "rule": "-A POSTROUTING -o eth0 -j MASQUERADE"},
		}}})
		return raw
	}
	before, err := extractTracked(makeSnap("br-f7410327c933"))
	if err != nil {
		t.Fatal(err)
	}
	after, err := extractTracked(makeSnap("br-8214d3580664"))
	if err != nil {
		t.Fatal(err)
	}
	if len(before) != 2 || len(after) != 2 {
		t.Fatalf("unexpected tracked counts: %d/%d: %+v %+v", len(before), len(after), before, after)
	}
	for key, item := range before {
		if strings.Contains(key, "br-") {
			t.Fatalf("transient NAT bridge still tracked: %q", key)
		}
		next, ok := after[key]
		if !ok || !trackedObjectsEqual(item, next) {
			t.Fatalf("changed unaffected firewall item %q", key)
		}
	}
}
