-- 0.20.39: filtre rapoarte + reparare definitivă nomenclator OS nesuportate.
-- Migrarea este idempotentă și poate rula și pe instalațiile unde nomenclatorul
-- a fost completat manual înainte de upgrade.

INSERT IGNORE INTO nomenclature_categories(code,label,sort_order,active)
VALUES ('unsupported_os','Sisteme de operare nesuportate',90,1);

UPDATE nomenclature_categories
SET label='Sisteme de operare nesuportate',sort_order=90,active=1
WHERE code='unsupported_os';

-- Vechiul index permitea un singur rând pentru aceeași familie OS.
-- Pentru reguli precum Debian 10 + Debian 11 sau Ubuntu 18.04 + 20.04
-- unicitatea corectă este categorie + familie + versiune.
ALTER TABLE nomenclature_items
  DROP INDEX IF EXISTS uq_nomenclature_category_name;

ALTER TABLE nomenclature_items
  ADD UNIQUE KEY IF NOT EXISTS uq_nomenclature_category_name (category_code,name,item_code);

-- Ubuntu: politica implicită VM-DOC consideră suportul standard Canonical,
-- fără Ubuntu Pro/ESM. Instalările care folosesc suport extins pot dezactiva
-- regulile respective din nomenclator.
INSERT INTO nomenclature_items(category_code,name,item_code,description,sort_order,active)
VALUES
 ('unsupported_os','Ubuntu','12.04','Ubuntu 12.04 - ieșit din suport standard',100,1),
 ('unsupported_os','Ubuntu','14.04','Ubuntu 14.04 - ieșit din suport standard',110,1),
 ('unsupported_os','Ubuntu','16.04','Ubuntu 16.04 - ieșit din suport standard; fără Ubuntu Pro/ESM',120,1),
 ('unsupported_os','Ubuntu','18.04','Ubuntu 18.04 - suport standard încheiat; fără Ubuntu Pro/ESM',130,1),
 ('unsupported_os','Ubuntu','20.04','Ubuntu 20.04 - suport standard încheiat în mai 2025; fără Ubuntu Pro/ESM',140,1),
 ('unsupported_os','Ubuntu','20.10','Ubuntu 20.10 - EOL',150,1),
 ('unsupported_os','Ubuntu','21.04','Ubuntu 21.04 - EOL',160,1),
 ('unsupported_os','Ubuntu','21.10','Ubuntu 21.10 - EOL',170,1),
 ('unsupported_os','Ubuntu','22.10','Ubuntu 22.10 - EOL',180,1),
 ('unsupported_os','Ubuntu','23.04','Ubuntu 23.04 - EOL',190,1),
 ('unsupported_os','Ubuntu','23.10','Ubuntu 23.10 - EOL',200,1),
 ('unsupported_os','Ubuntu','24.10','Ubuntu 24.10 - EOL',210,1),
 ('unsupported_os','Ubuntu','25.04','Ubuntu 25.04 - EOL',220,1),
 ('unsupported_os','Ubuntu','25.10','Ubuntu 25.10 - EOL',230,1)
ON DUPLICATE KEY UPDATE
 description=VALUES(description),sort_order=VALUES(sort_order);

-- Debian 12 nu este inclus: rămâne suportat în ciclul Debian LTS.
INSERT INTO nomenclature_items(category_code,name,item_code,description,sort_order,active)
VALUES
 ('unsupported_os','Debian','7','Debian 7 - ieșit din suport',300,1),
 ('unsupported_os','Debian','8','Debian 8 - ieșit din suport',310,1),
 ('unsupported_os','Debian','9','Debian 9 - ieșit din suport',320,1),
 ('unsupported_os','Debian','10','Debian 10 - ieșit din suport',330,1),
 ('unsupported_os','Debian','11','Debian 11 Bullseye - LTS încheiat la 31 august 2026',340,1)
ON DUPLICATE KEY UPDATE
 description=VALUES(description),sort_order=VALUES(sort_order);

INSERT INTO nomenclature_items(category_code,name,item_code,description,sort_order,active)
VALUES
 ('unsupported_os','CentOS Linux','6','CentOS Linux 6 - EOL',400,1),
 ('unsupported_os','CentOS Linux','7','CentOS Linux 7 - EOL',410,1),
 ('unsupported_os','CentOS Linux','8','CentOS Linux 8 - EOL',420,1)
ON DUPLICATE KEY UPDATE
 description=VALUES(description),sort_order=VALUES(sort_order);

-- Windows: numai familii clar ieșite din suport normal și fără ambiguități
-- LTSC/ESU la data acestei versiuni. Windows Server 2012/2012 R2 și SLES 11
-- nu sunt preactivate automat deoarece pot exista contracte extinse încă active.
INSERT INTO nomenclature_items(category_code,name,item_code,description,sort_order,active)
VALUES
 ('unsupported_os','Windows XP','','Microsoft Windows XP - ieșit din suport',500,1),
 ('unsupported_os','Windows Vista','','Microsoft Windows Vista - ieșit din suport',510,1),
 ('unsupported_os','Windows 7','','Microsoft Windows 7 - ieșit din suport',520,1),
 ('unsupported_os','Windows Server 2003','','Microsoft Windows Server 2003 / 2003 R2 - ieșit din suport',530,1),
 ('unsupported_os','Windows Server 2008','','Microsoft Windows Server 2008 / 2008 R2 - ieșit din suport',540,1)
ON DUPLICATE KEY UPDATE
 description=VALUES(description),sort_order=VALUES(sort_order);
