# Upgrade vm-doc-server 0.20.38 -> 0.20.39

Versiunea 0.20.39 separă rapoartele Outline, adaugă filtre/carduri clicabile și exporturi Excel filtrate și repară definitiv nomenclatorul pentru sistemele de operare nesuportate. Nu necesită update de vm-doc-agent.

## Schimbări

- `Rapoarte → Outline · VM-uri`: filtre Publicare, Pornit/Oprit, Mediu, Motiv și Căutare; carduri clicabile; export Excel filtrat.
- `Rapoarte → Outline · Servicii`: filtre Publicare, Activ/Inactiv/Retras, Criticitate, Status documentație, Motiv și Căutare; carduri clicabile; export Excel filtrat.
- `Rapoarte → Suport sisteme de operare`: filtre Stare suport, Pornit/Oprit, Mediu, Outline și Căutare; carduri clicabile; export Excel filtrat.
- Migrarea `062_reports_filters_unsupported_os_seed.up.sql` schimbă cheia unică pentru `nomenclature_items` la `(category_code,name,item_code)` și prepopulează idempotent regulile OS EOL standard.
- Dacă regulile OS au fost introduse manual înainte de upgrade, migrarea nu creează duplicate.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.38 \
      /usr/local/src/vm-doc-server-0.20.39

tar -xzf vm-doc-server-0.20.39-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.39

cd /usr/local/src/vm-doc-server-0.20.39

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

La prima pornire se aplică automat migrarea 062. După restart folosește `Ctrl+F5` pentru `app.js?v=0.20.39`.
