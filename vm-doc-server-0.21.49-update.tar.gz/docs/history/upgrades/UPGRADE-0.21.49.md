# VM-DOC Server 0.21.48 → 0.21.49

**Schimbări:** exclusiv UI/JS/CSS, export SVG și documentație. Fără migrare SQL, API nou sau modificare a agentului (rămâne 1.7.18).

1. Efectuează backup pentru binarul actual, surse și configurații; păstrează `vendor/` existent pentru build offline.
2. Din rădăcina surselor nemodificate 0.21.48, aplică **una** dintre metodele:

   ```sh
   tar -xzf /cale/vm-doc-server-0.21.49-update.tar.gz
   # sau
   git apply /cale/vm-doc-server-0.21.48-to-0.21.49.patch
   ```

3. Confirmă `cat VERSION` → `0.21.49` și `bash scripts/cleanup-source-tree.sh --check`.
4. Pe serverul cu `vendor/` complet: `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build`.
5. Validează Harta rețea la VM și Serviciu: aspect Sursă / Destinație, `VM(IP)`, etichetele de obiect, porturile TCP, click port/flux și export SVG complet cu sute de obiecte, fără controale de UI, cu fundal alb.
6. Instalează binarul recompilat după staging, repornește serviciul și execută hard refresh Chrome.

**Rollback:** revino la binar + surse 0.21.48; nu există migrare SQL de inversat.

**Limitări:** codul este testat cu date simulate în Chromium. Testul end-to-end cu MariaDB/FortiGate real și compilarea serverului cu `vendor/` necesită mediul țintă.
