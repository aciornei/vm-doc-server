package server

import (
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/veeam"
)

func (a *App) veeamSummary(w http.ResponseWriter, r *http.Request) {
	v, err := a.Veeam.GetSummary(r.Context())
	respond(w, v, err)
}

func (a *App) listVeeamVMBackups(w http.ResponseWriter, r *http.Request) {
	page, pageSize, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Veeam.ListVMBackups(r.Context(), r.URL.Query().Get("q"), r.URL.Query().Get("status"), r.URL.Query().Get("power"), r.URL.Query().Get("result"), page, pageSize)
	respond(w, v, err)
}

func (a *App) listVeeamSources(w http.ResponseWriter, r *http.Request) {
	v, err := a.Veeam.ListSources(r.Context())
	respond(w, v, err)
}

func (a *App) getVeeamSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Veeam.GetSource(r.Context(), id)
	respond(w, v, err)
}

func (a *App) createVeeamSource(w http.ResponseWriter, r *http.Request) {
	var in veeam.SourceInput
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.Veeam.CreateSource(r.Context(), in, u.ID)
	if err == nil {
		a.auditRequest(r, "veeam.source.create", "veeam_source", strconv.FormatInt(v.ID, 10), "success", map[string]any{"name": v.Name, "base_url": v.BaseURL})
	}
	respondStatus(w, v, err, http.StatusCreated)
}

func (a *App) updateVeeamSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in veeam.SourceInput
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.Veeam.UpdateSource(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "veeam.source.update", "veeam_source", strconv.FormatInt(id, 10), "success", map[string]any{"name": v.Name, "base_url": v.BaseURL})
	}
	respond(w, v, err)
}

func (a *App) deleteVeeamSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	err = a.Veeam.DeleteSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "veeam.source.delete", "veeam_source", strconv.FormatInt(id, 10), "success", nil)
	}
	respond(w, map[string]any{"deleted": err == nil}, err)
}

func (a *App) testVeeamSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Veeam.TestSource(r.Context(), id)
	if err != nil && a.Logger != nil {
		a.Logger.Error("Veeam connection test failed", "source_id", id, "error", err)
	}
	if err == nil {
		a.auditRequest(r, "veeam.source.test", "veeam_source", strconv.FormatInt(id, 10), "success", v)
	}
	respond(w, v, err)
}

func (a *App) syncVeeamSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	run, err := a.Veeam.StartSync(r.Context(), id, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "veeam.sync.queue", "veeam_source", strconv.FormatInt(id, 10), "success", map[string]any{"run_id": run.ID})
	}
	respondStatus(w, run, err, http.StatusAccepted)
}

func (a *App) syncAllVeeam(w http.ResponseWriter, r *http.Request) {
	u, _ := auth.UserFromContext(r.Context())
	runs, err := a.Veeam.StartAll(r.Context(), &u.ID)
	if err == nil {
		a.auditRequest(r, "veeam.sync.queue_all", "veeam", "all", "success", map[string]any{"runs": len(runs)})
	}
	respondStatus(w, runs, err, http.StatusAccepted)
}

func (a *App) listVeeamRuns(w http.ResponseWriter, r *http.Request) {
	page, pageSize, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Veeam.ListRunsPage(r.Context(), page, pageSize)
	respond(w, v, err)
}

func (a *App) updateVMBackupSettings(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in veeam.CronBackupInput
	if err := decodeJSON(r, &in, 64<<10); err != nil {
		badRequest(w, err)
		return
	}
	err = a.Veeam.UpdateCronBackup(r.Context(), id, in)
	if err == nil {
		a.auditRequest(r, "vm.backup.cron.update", "virtual_machine", strconv.FormatInt(id, 10), "success", map[string]any{"enabled": in.Enabled, "schedule": in.Schedule})
	}
	respond(w, map[string]any{"updated": err == nil}, err)
}
