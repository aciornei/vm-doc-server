package veeam

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/url"
	"sort"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/domain"
)

type Service struct {
	DB     *sql.DB
	Box    *cryptox.Box
	Config config.VeeamConfig
	Logger *slog.Logger
	ctx    context.Context
	wg     sync.WaitGroup
}

type SourceInput struct {
	Name                string `json:"name"`
	BaseURL             string `json:"base_url"`
	Username            string `json:"username"`
	Password            string `json:"password,omitempty"`
	APIVersion          string `json:"api_version,omitempty"`
	Enabled             *bool  `json:"enabled,omitempty"`
	VerifyTLS           *bool  `json:"verify_tls,omitempty"`
	TLSServerName       string `json:"tls_server_name,omitempty"`
	SyncIntervalMinutes int    `json:"sync_interval_minutes,omitempty"`
}

type CronBackupInput struct {
	Enabled  bool   `json:"enabled"`
	Schedule string `json:"schedule,omitempty"`
	Command  string `json:"command,omitempty"`
	Notes    string `json:"notes,omitempty"`
}

type SourceRecord struct {
	domain.VeeamSource
	PasswordCiphertext string
}

type SyncRunPage struct {
	Items    []domain.VeeamSyncRun `json:"items"`
	Page     int                   `json:"page"`
	PageSize int                   `json:"page_size"`
	Total    int                   `json:"total"`
	Pages    int                   `json:"pages"`
}

type Summary struct {
	Sources              int `json:"sources"`
	EnabledSources       int `json:"enabled_sources"`
	TotalVMs             int `json:"total_vms"`
	ProtectedVMs         int `json:"protected_vms"`
	UnprotectedVMs       int `json:"unprotected_vms"`
	NeverSynchronizedVMs int `json:"never_synchronized_vms"`
	FailedVMs            int `json:"failed_vms"`
	WarningVMs           int `json:"warning_vms"`
}

type VMBackupItem struct {
	VMID                     int64      `json:"vm_id"`
	VMName                   string     `json:"vm_name"`
	PowerState               string     `json:"power_state,omitempty"`
	Provider                 string     `json:"provider,omitempty"`
	SourceName               string     `json:"source_name,omitempty"`
	Protected                bool       `json:"protected"`
	EffectiveProtected       bool       `json:"effective_protected"`
	JobName                  string     `json:"job_name,omitempty"`
	RepositoryName           string     `json:"repository_name,omitempty"`
	PrimaryRepositoryName    string     `json:"primary_repository_name,omitempty"`
	SecondaryRepositoryNames string     `json:"secondary_repository_names,omitempty"`
	ScheduleText             string     `json:"schedule_text,omitempty"`
	RetentionType            string     `json:"retention_type,omitempty"`
	RetentionQuantity        *int       `json:"retention_quantity,omitempty"`
	CronBackupEnabled        bool       `json:"cron_backup_enabled"`
	CronBackupSchedule       string     `json:"cron_backup_schedule,omitempty"`
	LastResult               string     `json:"last_result,omitempty"`
	LastBackupAt             *time.Time `json:"last_backup_at,omitempty"`
	NextRunAt                *time.Time `json:"next_run_at,omitempty"`
	RestorePoints            *int       `json:"restore_points,omitempty"`
	SyncedAt                 *time.Time `json:"synced_at,omitempty"`
	ErrorMessage             string     `json:"error_message,omitempty"`
}

type VMBackupPage struct {
	Items                  []VMBackupItem `json:"items"`
	Page                   int            `json:"page"`
	PageSize               int            `json:"page_size"`
	Total                  int            `json:"total"`
	Pages                  int            `json:"pages"`
	ProtectedCount         int            `json:"protected_count"`
	UnprotectedCount       int            `json:"unprotected_count"`
	NeverSynchronizedCount int            `json:"never_synchronized_count"`
	FailedCount            int            `json:"failed_count"`
	WarningCount           int            `json:"warning_count"`
}

type vmRef struct {
	ID   int64
	Name string
}

type candidate struct {
	Object         BackupObject  `json:"object"`
	Backup         Backup        `json:"backup"`
	Job            JobState      `json:"job"`
	Definition     JobDefinition `json:"job_definition"`
	RepositoryName string        `json:"repository_name,omitempty"`
	Latest         *RestorePoint `json:"latest_restore_point,omitempty"`
	Error          string        `json:"restore_point_error,omitempty"`
}

func NewService(ctx context.Context, db *sql.DB, box *cryptox.Box, cfg config.Config, logger *slog.Logger) *Service {
	if logger == nil {
		logger = slog.Default()
	}
	return &Service{DB: db, Box: box, Config: cfg.Veeam, Logger: logger, ctx: ctx}
}

func (s *Service) Wait() { s.wg.Wait() }

func (s *Service) ListSources(ctx context.Context) ([]domain.VeeamSource, error) {
	rows, err := s.DB.QueryContext(ctx, sourceSelect+` ORDER BY s.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.VeeamSource, 0)
	for rows.Next() {
		record, err := scanSource(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, record.VeeamSource)
	}
	return out, rows.Err()
}

func (s *Service) GetSource(ctx context.Context, id int64) (domain.VeeamSource, error) {
	record, err := s.GetSourceRecord(ctx, id)
	return record.VeeamSource, err
}

func (s *Service) GetSourceRecord(ctx context.Context, id int64) (SourceRecord, error) {
	return scanSource(s.DB.QueryRowContext(ctx, sourceSelect+` WHERE s.id=?`, id))
}

func (s *Service) CreateSource(ctx context.Context, in SourceInput, userID int64) (domain.VeeamSource, error) {
	if err := s.normalizeSource(&in, true); err != nil {
		return domain.VeeamSource{}, err
	}
	secretRef, err := cryptox.RandomToken(24)
	if err != nil {
		return domain.VeeamSource{}, err
	}
	ciphertext, err := s.Box.Encrypt([]byte(in.Password), "vm-doc-veeam-password:"+secretRef)
	if err != nil {
		return domain.VeeamSource{}, err
	}
	enabled, verify := true, true
	if in.Enabled != nil {
		enabled = *in.Enabled
	}
	if in.VerifyTLS != nil {
		verify = *in.VerifyTLS
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO veeam_sources(secret_ref,name,base_url,username,password_ciphertext,api_version,enabled,verify_tls,tls_server_name,sync_interval_minutes,last_error,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?, '',?,?)`, secretRef, in.Name, strings.TrimRight(in.BaseURL, "/"), in.Username, ciphertext, in.APIVersion, enabled, verify, in.TLSServerName, in.SyncIntervalMinutes, userID, userID)
	if err != nil {
		return domain.VeeamSource{}, err
	}
	id, _ := res.LastInsertId()
	return s.GetSource(ctx, id)
}

func (s *Service) UpdateSource(ctx context.Context, id int64, in SourceInput, userID int64) (domain.VeeamSource, error) {
	current, err := s.GetSourceRecord(ctx, id)
	if err != nil {
		return domain.VeeamSource{}, err
	}
	if strings.TrimSpace(in.Name) == "" {
		in.Name = current.Name
	}
	if strings.TrimSpace(in.BaseURL) == "" {
		in.BaseURL = current.BaseURL
	}
	if strings.TrimSpace(in.Username) == "" {
		in.Username = current.Username
	}
	if strings.TrimSpace(in.APIVersion) == "" {
		in.APIVersion = current.APIVersion
	}
	if in.SyncIntervalMinutes == 0 {
		in.SyncIntervalMinutes = current.SyncIntervalMinutes
	}
	if in.Enabled == nil {
		v := current.Enabled
		in.Enabled = &v
	}
	if in.VerifyTLS == nil {
		v := current.VerifyTLS
		in.VerifyTLS = &v
	}
	if in.TLSServerName == "" {
		in.TLSServerName = current.TLSServerName
	}
	if err := s.normalizeSource(&in, false); err != nil {
		return domain.VeeamSource{}, err
	}
	ciphertext := current.PasswordCiphertext
	if in.Password != "" {
		ciphertext, err = s.Box.Encrypt([]byte(in.Password), "vm-doc-veeam-password:"+current.SecretRef)
		if err != nil {
			return domain.VeeamSource{}, err
		}
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE veeam_sources SET name=?,base_url=?,username=?,password_ciphertext=?,api_version=?,enabled=?,verify_tls=?,tls_server_name=?,sync_interval_minutes=?,updated_by=? WHERE id=?`, in.Name, strings.TrimRight(in.BaseURL, "/"), in.Username, ciphertext, in.APIVersion, *in.Enabled, *in.VerifyTLS, in.TLSServerName, in.SyncIntervalMinutes, userID, id)
	if err != nil {
		return domain.VeeamSource{}, err
	}
	return s.GetSource(ctx, id)
}

func (s *Service) DeleteSource(ctx context.Context, id int64) error {
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `UPDATE vm_backup_summary SET provider='manual',veeam_source_id=NULL,source_name='',protected=0,job_name='',policy_name='',repository_name='',primary_repository_name='',secondary_repository_names='',schedule_text='',retention_type='',retention_quantity=NULL,gfs_weekly_weeks=NULL,gfs_weekly_day='',gfs_monthly_months=NULL,gfs_monthly_week='',gfs_yearly_years=NULL,gfs_yearly_month='',last_result='',last_backup_at=NULL,next_run_at=NULL,restore_points=NULL,synced_at=NULL,error_message='',raw_json=NULL WHERE veeam_source_id=? AND cron_backup_enabled=1`, id); err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_backup_summary WHERE veeam_source_id=? AND cron_backup_enabled=0`, id); err != nil {
		return err
	}
	res, err := tx.ExecContext(ctx, `DELETE FROM veeam_sources WHERE id=?`, id)
	if err != nil {
		return err
	}
	rows, _ := res.RowsAffected()
	if rows == 0 {
		return sql.ErrNoRows
	}
	return tx.Commit()
}

func (s *Service) TestSource(ctx context.Context, id int64) (map[string]any, error) {
	record, err := s.GetSourceRecord(ctx, id)
	if err != nil {
		return nil, err
	}
	password, err := s.decryptPassword(record)
	if err != nil {
		return nil, err
	}
	client, err := NewClient(record.VeeamSource, password, s.Config.RequestTimeout.Value())
	if err != nil {
		return nil, err
	}
	info, count, err := client.Test(ctx)
	if err != nil {
		return nil, err
	}
	return map[string]any{
		"status": "ok", "server_name": firstNonEmpty(info.Name, record.Name), "build_version": info.BuildVersion,
		"database_vendor": info.DatabaseVendor, "backup_objects": count, "api_version": record.APIVersion,
	}, nil
}

func (s *Service) StartSync(ctx context.Context, sourceID int64, source string, requestedBy *int64) (domain.VeeamSyncRun, error) {
	if source != "manual" && source != "scheduler" {
		return domain.VeeamSyncRun{}, errors.New("invalid sync source")
	}
	record, err := s.GetSource(ctx, sourceID)
	if err != nil {
		return domain.VeeamSyncRun{}, err
	}
	if source == "scheduler" && !record.Enabled {
		return domain.VeeamSyncRun{}, errors.New("Veeam source is disabled")
	}
	var running int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM veeam_sync_runs WHERE veeam_source_id=? AND status IN ('queued','running')`, sourceID).Scan(&running); err != nil {
		return domain.VeeamSyncRun{}, err
	}
	if running > 0 {
		return domain.VeeamSyncRun{}, errors.New("a Veeam synchronization is already running")
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO veeam_sync_runs(veeam_source_id,source,status,requested_by_user_id,error_message) VALUES(?,?,'queued',?,'')`, sourceID, source, requestedBy)
	if err != nil {
		return domain.VeeamSyncRun{}, err
	}
	id, _ := res.LastInsertId()
	run, err := s.GetRun(ctx, id)
	if err != nil {
		return run, err
	}
	s.wg.Add(1)
	go func() { defer s.wg.Done(); s.executeSync(s.ctx, id, sourceID) }()
	return run, nil
}

func (s *Service) StartAll(ctx context.Context, requestedBy *int64) ([]domain.VeeamSyncRun, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id FROM veeam_sources WHERE enabled=1 ORDER BY name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	out := make([]domain.VeeamSyncRun, 0, len(ids))
	for _, id := range ids {
		run, err := s.StartSync(ctx, id, "manual", requestedBy)
		if err != nil {
			if strings.Contains(err.Error(), "already running") {
				continue
			}
			return out, err
		}
		out = append(out, run)
	}
	return out, nil
}

func (s *Service) ListRunsPage(ctx context.Context, page, pageSize int) (SyncRunPage, error) {
	if page < 1 {
		page = 1
	}
	if pageSize <= 0 {
		pageSize = 10
	}
	if pageSize > 200 {
		pageSize = 200
	}
	result := SyncRunPage{Items: make([]domain.VeeamSyncRun, 0), Page: page, PageSize: pageSize}
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM veeam_sync_runs`).Scan(&result.Total); err != nil {
		return result, err
	}
	if result.Total == 0 {
		return result, nil
	}
	result.Pages = (result.Total + pageSize - 1) / pageSize
	if result.Page > result.Pages {
		result.Page = result.Pages
	}
	offset := (result.Page - 1) * pageSize
	rows, err := s.DB.QueryContext(ctx, runSelect+` ORDER BY r.id DESC LIMIT ? OFFSET ?`, pageSize, offset)
	if err != nil {
		return result, err
	}
	defer rows.Close()
	for rows.Next() {
		item, err := scanRun(rows)
		if err != nil {
			return result, err
		}
		result.Items = append(result.Items, item)
	}
	return result, rows.Err()
}

func (s *Service) GetRun(ctx context.Context, id int64) (domain.VeeamSyncRun, error) {
	return scanRun(s.DB.QueryRowContext(ctx, runSelect+` WHERE r.id=?`, id))
}

func (s *Service) GetSummary(ctx context.Context) (Summary, error) {
	var out Summary
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*),COALESCE(SUM(enabled=1),0) FROM veeam_sources`).Scan(&out.Sources, &out.EnabledSources); err != nil {
		return out, err
	}
	err := s.DB.QueryRowContext(ctx, `SELECT
      COUNT(*),
      COALESCE(SUM(CASE WHEN COALESCE(b.protected,0)=1 OR COALESCE(b.cron_backup_enabled,0)=1 THEN 1 ELSE 0 END),0),
      COALESCE(SUM(CASE WHEN b.synced_at IS NOT NULL AND COALESCE(b.protected,0)=0 AND COALESCE(b.cron_backup_enabled,0)=0 THEN 1 ELSE 0 END),0),
      COALESCE(SUM(CASE WHEN b.synced_at IS NULL AND COALESCE(b.cron_backup_enabled,0)=0 THEN 1 ELSE 0 END),0),
      COALESCE(SUM(CASE WHEN LOWER(b.last_result) IN ('failed','error') THEN 1 ELSE 0 END),0),
      COALESCE(SUM(CASE WHEN LOWER(b.last_result)='warning' THEN 1 ELSE 0 END),0)
      FROM virtual_machines vm LEFT JOIN vm_backup_summary b ON b.vm_id=vm.id WHERE vm.retired=0`).Scan(&out.TotalVMs, &out.ProtectedVMs, &out.UnprotectedVMs, &out.NeverSynchronizedVMs, &out.FailedVMs, &out.WarningVMs)
	return out, err
}

func (s *Service) ListVMBackups(ctx context.Context, q, status, power, resultFilter string, page, pageSize int) (VMBackupPage, error) {
	if page < 1 {
		page = 1
	}
	if pageSize <= 0 {
		pageSize = 10
	}
	if pageSize > 200 {
		pageSize = 200
	}
	q = strings.TrimSpace(q)
	status = strings.ToLower(strings.TrimSpace(status))
	power = strings.ToUpper(strings.TrimSpace(power))
	resultFilter = strings.ToLower(strings.TrimSpace(resultFilter))
	clauses := []string{"vm.retired=0"}
	args := make([]any, 0, 8)
	if q != "" {
		like := "%" + q + "%"
		clauses = append(clauses, "(vm.name LIKE ? OR COALESCE(b.job_name,'') LIKE ? OR COALESCE(b.repository_name,'') LIKE ? OR COALESCE(b.primary_repository_name,'') LIKE ? OR COALESCE(b.secondary_repository_names,'') LIKE ? OR COALESCE(b.source_name,'') LIKE ? OR COALESCE(b.cron_backup_schedule,'') LIKE ? OR COALESCE(vm.power_state,'') LIKE ?)")
		args = append(args, like, like, like, like, like, like, like, like)
	}
	effectiveProtected := "(COALESCE(b.protected,0)=1 OR COALESCE(b.cron_backup_enabled,0)=1)"
	switch status {
	case "", "all":
	case "protected":
		clauses = append(clauses, effectiveProtected)
	case "unprotected":
		clauses = append(clauses, "b.synced_at IS NOT NULL AND NOT "+effectiveProtected)
	case "never":
		clauses = append(clauses, "b.synced_at IS NULL AND COALESCE(b.cron_backup_enabled,0)=0")
	default:
		return VMBackupPage{}, errors.New("invalid backup protection filter")
	}
	switch power {
	case "", "ALL":
	case "POWERED_ON", "POWERED_OFF", "SUSPENDED":
		clauses = append(clauses, "UPPER(COALESCE(vm.power_state,''))=?")
		args = append(args, power)
	default:
		return VMBackupPage{}, errors.New("invalid VM power filter")
	}
	switch resultFilter {
	case "", "all":
	case "success":
		clauses = append(clauses, "LOWER(COALESCE(b.last_result,''))='success'")
	case "failed":
		clauses = append(clauses, "LOWER(COALESCE(b.last_result,'')) IN ('failed','error')")
	case "warning":
		clauses = append(clauses, "LOWER(COALESCE(b.last_result,''))='warning'")
	case "none":
		clauses = append(clauses, "LOWER(COALESCE(b.last_result,'')) IN ('','none')")
	default:
		return VMBackupPage{}, errors.New("invalid backup result filter")
	}
	where := " WHERE " + strings.Join(clauses, " AND ")
	base := ` FROM virtual_machines vm LEFT JOIN vm_backup_summary b ON b.vm_id=vm.id`
	result := VMBackupPage{Items: make([]VMBackupItem, 0), Page: page, PageSize: pageSize}
	countSQL := `SELECT COUNT(*),
		COALESCE(SUM(CASE WHEN ` + effectiveProtected + ` THEN 1 ELSE 0 END),0),
		COALESCE(SUM(CASE WHEN b.synced_at IS NOT NULL AND NOT ` + effectiveProtected + ` THEN 1 ELSE 0 END),0),
		COALESCE(SUM(CASE WHEN b.synced_at IS NULL AND COALESCE(b.cron_backup_enabled,0)=0 THEN 1 ELSE 0 END),0),
		COALESCE(SUM(CASE WHEN LOWER(COALESCE(b.last_result,'')) IN ('failed','error') THEN 1 ELSE 0 END),0),
		COALESCE(SUM(CASE WHEN LOWER(COALESCE(b.last_result,''))='warning' THEN 1 ELSE 0 END),0)` + base + where
	if err := s.DB.QueryRowContext(ctx, countSQL, args...).Scan(&result.Total, &result.ProtectedCount, &result.UnprotectedCount, &result.NeverSynchronizedCount, &result.FailedCount, &result.WarningCount); err != nil {
		return result, err
	}
	if result.Total == 0 {
		return result, nil
	}
	result.Pages = (result.Total + pageSize - 1) / pageSize
	if result.Page > result.Pages {
		result.Page = result.Pages
	}
	offset := (result.Page - 1) * pageSize
	queryArgs := append(append([]any{}, args...), pageSize, offset)
	rows, err := s.DB.QueryContext(ctx, `SELECT vm.id,vm.name,COALESCE(vm.power_state,''),COALESCE(b.provider,''),COALESCE(b.source_name,''),COALESCE(b.protected,0),`+effectiveProtected+`,COALESCE(b.job_name,''),COALESCE(b.repository_name,''),COALESCE(b.primary_repository_name,''),COALESCE(b.secondary_repository_names,''),COALESCE(b.schedule_text,''),COALESCE(b.retention_type,''),b.retention_quantity,COALESCE(b.cron_backup_enabled,0),COALESCE(b.cron_backup_schedule,''),COALESCE(b.last_result,''),b.last_backup_at,b.next_run_at,b.restore_points,b.synced_at,COALESCE(b.error_message,'')`+base+where+` ORDER BY vm.name,vm.id LIMIT ? OFFSET ?`, queryArgs...)
	if err != nil {
		return result, err
	}
	defer rows.Close()
	for rows.Next() {
		var item VMBackupItem
		var lastBackup, nextRun, synced sql.NullTime
		var restorePoints, retentionQuantity sql.NullInt64
		if err := rows.Scan(&item.VMID, &item.VMName, &item.PowerState, &item.Provider, &item.SourceName, &item.Protected, &item.EffectiveProtected, &item.JobName, &item.RepositoryName, &item.PrimaryRepositoryName, &item.SecondaryRepositoryNames, &item.ScheduleText, &item.RetentionType, &retentionQuantity, &item.CronBackupEnabled, &item.CronBackupSchedule, &item.LastResult, &lastBackup, &nextRun, &restorePoints, &synced, &item.ErrorMessage); err != nil {
			return result, err
		}
		if lastBackup.Valid {
			t := lastBackup.Time
			item.LastBackupAt = &t
		}
		if nextRun.Valid {
			t := nextRun.Time
			item.NextRunAt = &t
		}
		if synced.Valid {
			t := synced.Time
			item.SyncedAt = &t
		}
		if restorePoints.Valid {
			n := int(restorePoints.Int64)
			item.RestorePoints = &n
		}
		if retentionQuantity.Valid {
			n := int(retentionQuantity.Int64)
			item.RetentionQuantity = &n
		}
		result.Items = append(result.Items, item)
	}
	return result, rows.Err()
}

func (s *Service) UpdateCronBackup(ctx context.Context, vmID int64, in CronBackupInput) error {
	if vmID <= 0 {
		return errors.New("invalid vm id")
	}
	in.Schedule = strings.TrimSpace(in.Schedule)
	in.Command = strings.TrimSpace(in.Command)
	in.Notes = strings.TrimSpace(in.Notes)
	if in.Enabled && in.Schedule == "" {
		return errors.New("cron schedule is required when cron backup is enabled")
	}
	if len(in.Schedule) > 255 || len(in.Command) > 1024 || len(in.Notes) > 8000 {
		return errors.New("cron backup fields are too long")
	}
	var exists int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM virtual_machines WHERE id=? AND retired=0`, vmID).Scan(&exists); err != nil {
		return err
	}
	if exists == 0 {
		return sql.ErrNoRows
	}
	_, err := s.DB.ExecContext(ctx, `INSERT INTO vm_backup_summary(vm_id,provider,protected,cron_backup_enabled,cron_backup_schedule,cron_backup_command,cron_backup_notes,error_message) VALUES(?,'manual',0,?,?,?,'') ON DUPLICATE KEY UPDATE cron_backup_enabled=VALUES(cron_backup_enabled),cron_backup_schedule=VALUES(cron_backup_schedule),cron_backup_command=VALUES(cron_backup_command),cron_backup_notes=VALUES(cron_backup_notes)`, vmID, in.Enabled, in.Schedule, in.Command, in.Notes)
	return err
}

func (s *Service) RunScheduler(ctx context.Context) {
	interval := s.Config.SchedulerInterval.Value()
	if interval <= 0 {
		interval = time.Minute
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		s.scheduleDue(ctx)
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}

func (s *Service) scheduleDue(ctx context.Context) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,sync_interval_minutes,last_sync_at FROM veeam_sources WHERE enabled=1`)
	if err != nil {
		if ctx.Err() == nil {
			s.Logger.Error("load scheduled Veeam sources", "error", err)
		}
		return
	}
	defer rows.Close()
	type item struct {
		id      int64
		minutes int
		last    sql.NullTime
	}
	var due []item
	now := time.Now().UTC()
	for rows.Next() {
		var v item
		if rows.Scan(&v.id, &v.minutes, &v.last) == nil {
			if v.minutes < 1 {
				v.minutes = 1440
			}
			if !v.last.Valid || now.Sub(v.last.Time) >= time.Duration(v.minutes)*time.Minute {
				due = append(due, v)
			}
		}
	}
	for _, v := range due {
		if _, err := s.StartSync(ctx, v.id, "scheduler", nil); err != nil && !strings.Contains(err.Error(), "already running") {
			s.Logger.Error("queue scheduled Veeam sync", "source_id", v.id, "error", err)
		}
	}
}

func (s *Service) executeSync(ctx context.Context, runID, sourceID int64) {
	started := time.Now().UTC()
	_, _ = s.DB.ExecContext(ctx, `UPDATE veeam_sync_runs SET status='running',started_at=? WHERE id=? AND status='queued'`, started, runID)
	record, err := s.GetSourceRecord(ctx, sourceID)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	password, err := s.decryptPassword(record)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	client, err := NewClient(record.VeeamSource, password, s.Config.RequestTimeout.Value())
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	inventory, err := client.Inventory(ctx)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	objects, backups, jobs, token := inventory.Objects, inventory.Backups, inventory.JobStates, inventory.Token
	if len(inventory.Warnings) > 0 {
		s.Logger.Warn("Veeam inventory completed with optional endpoint warnings", "source_id", sourceID, "warnings", strings.Join(inventory.Warnings, "; "))
	}

	vmByName, vmIDs, _, err := s.loadVMNames(ctx)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	grouped := map[int64][]candidate{}
	unmatchedObjects := 0
	for _, object := range objects {
		name := strings.TrimSpace(object.Name)
		if name == "" || !isVMObject(object) {
			continue
		}
		refs := vmByName[name]
		if len(refs) != 1 {
			unmatchedObjects++
			continue
		}
		latest, rpErr := client.LatestRestorePoint(ctx, token, object.ID)
		backupID := object.BackupID
		if normalizeID(backupID) == "" && latest != nil {
			backupID = latest.BackupID
		}
		backup := backups[normalizeID(backupID)]
		job := findJobForBackup(jobs, backup)
		definition := findJobDefinition(inventory.Jobs, backup, job)
		repositoryName := resolveRepositoryName(backup, job, definition, inventory.Repositories)
		c := candidate{Object: object, Backup: backup, Job: job, Definition: definition, RepositoryName: repositoryName, Latest: latest}
		if rpErr != nil {
			c.Error = truncate(rpErr.Error(), 600)
		}
		grouped[refs[0].ID] = append(grouped[refs[0].ID], c)
	}

	conn, err := s.DB.Conn(ctx)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	defer conn.Close()
	lockName := fmt.Sprintf("vm-doc-veeam-sync-%d", sourceID)
	var locked int
	if err := conn.QueryRowContext(ctx, `SELECT GET_LOCK(?,0)`, lockName).Scan(&locked); err != nil || locked != 1 {
		if err == nil {
			err = errors.New("another Veeam synchronization holds the database lock")
		}
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	defer conn.ExecContext(context.Background(), `SELECT RELEASE_LOCK(?)`, lockName)
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	defer tx.Rollback()

	now := time.Now().UTC()
	protected := 0
	unprotected := 0
	matched := 0
	for vmID, candidates := range grouped {
		matched++
		summary := summarizeCandidates(candidates)
		if summary.protected {
			protected++
		} else {
			unprotected++
		}
		raw, _ := json.Marshal(map[string]any{"source_id": sourceID, "source_name": record.Name, "inventory_warnings": inventory.Warnings, "candidates": candidates})
		_, err = tx.ExecContext(ctx, `INSERT INTO vm_backup_summary(vm_id,provider,veeam_source_id,source_name,protected,job_name,policy_name,repository_name,primary_repository_name,secondary_repository_names,schedule_text,retention_type,retention_quantity,gfs_weekly_weeks,gfs_weekly_day,gfs_monthly_months,gfs_monthly_week,gfs_yearly_years,gfs_yearly_month,last_result,last_backup_at,next_run_at,restore_points,synced_at,error_message,raw_json)
          VALUES(?,'veeam',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
          ON DUPLICATE KEY UPDATE provider='veeam',veeam_source_id=VALUES(veeam_source_id),source_name=VALUES(source_name),protected=VALUES(protected),job_name=VALUES(job_name),policy_name=VALUES(policy_name),repository_name=VALUES(repository_name),primary_repository_name=VALUES(primary_repository_name),secondary_repository_names=VALUES(secondary_repository_names),schedule_text=VALUES(schedule_text),retention_type=VALUES(retention_type),retention_quantity=VALUES(retention_quantity),gfs_weekly_weeks=VALUES(gfs_weekly_weeks),gfs_weekly_day=VALUES(gfs_weekly_day),gfs_monthly_months=VALUES(gfs_monthly_months),gfs_monthly_week=VALUES(gfs_monthly_week),gfs_yearly_years=VALUES(gfs_yearly_years),gfs_yearly_month=VALUES(gfs_yearly_month),last_result=VALUES(last_result),last_backup_at=VALUES(last_backup_at),next_run_at=VALUES(next_run_at),restore_points=VALUES(restore_points),synced_at=VALUES(synced_at),error_message=VALUES(error_message),raw_json=VALUES(raw_json)`,
			vmID, sourceID, record.Name, summary.protected, summary.jobNames, summary.policyName, summary.repositories, summary.primaryRepository, summary.secondaryRepositories, summary.scheduleText, summary.retentionType, nullableInt(summary.retentionQuantity), nullableInt(summary.gfsWeeklyWeeks), summary.gfsWeeklyDay, nullableInt(summary.gfsMonthlyMonths), summary.gfsMonthlyWeek, nullableInt(summary.gfsYearlyYears), summary.gfsYearlyMonth, summary.lastResult, nullableTime(summary.lastBackup), nullableTime(summary.nextRun), summary.restorePoints, now, summary.errorMessage, raw)
		if err != nil {
			s.failRun(ctx, runID, sourceID, err)
			return
		}
	}

	for _, vmID := range vmIDs {
		if _, ok := grouped[vmID]; ok {
			continue
		}
		// A Veeam source may coexist with another source. Never let an
		// "unprotected" result from this source erase a protected summary
		// currently owned by another Veeam source.
		_, err := tx.ExecContext(ctx, `INSERT IGNORE INTO vm_backup_summary(vm_id,provider,veeam_source_id,source_name,protected,job_name,policy_name,repository_name,last_result,restore_points,synced_at,error_message)
          VALUES(?,'veeam',?,?,0,'','','','',0,?,'')`, vmID, sourceID, record.Name, now)
		if err != nil {
			s.failRun(ctx, runID, sourceID, err)
			return
		}
		result, err := tx.ExecContext(ctx, `UPDATE vm_backup_summary
             SET provider='veeam',veeam_source_id=?,source_name=?,protected=0,job_name='',policy_name='',repository_name='',primary_repository_name='',secondary_repository_names='',schedule_text='',retention_type='',retention_quantity=NULL,gfs_weekly_weeks=NULL,gfs_weekly_day='',gfs_monthly_months=NULL,gfs_monthly_week='',gfs_yearly_years=NULL,gfs_yearly_month='',last_result='',last_backup_at=NULL,next_run_at=NULL,restore_points=0,synced_at=?,error_message='',raw_json=NULL
           WHERE vm_id=? AND (veeam_source_id IS NULL OR veeam_source_id=?)`, sourceID, record.Name, now, vmID, sourceID)
		if err != nil {
			s.failRun(ctx, runID, sourceID, err)
			return
		}
		if n, _ := result.RowsAffected(); n > 0 {
			unprotected++
		}
	}

	finished := time.Now().UTC()
	if _, err := tx.ExecContext(ctx, `UPDATE veeam_sources SET last_sync_at=?,last_success_at=?,last_error='' WHERE id=?`, finished, finished, sourceID); err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	if _, err := tx.ExecContext(ctx, `UPDATE veeam_sync_runs SET status='succeeded',finished_at=?,backup_object_count=?,matched_vm_count=?,protected_vm_count=?,unprotected_vm_count=?,ambiguous_count=?,error_message='' WHERE id=?`, finished, len(objects), matched, protected, unprotected, unmatchedObjects, runID); err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	if err := tx.Commit(); err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	s.Logger.Info("Veeam synchronization completed", "source_id", sourceID, "run_id", runID, "backup_objects", len(objects), "matched_vms", matched, "protected_vms", protected, "unprotected_vms", unprotected)
}

func (s *Service) loadVMNames(ctx context.Context) (map[string][]vmRef, []int64, int, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,name FROM virtual_machines WHERE retired=0 ORDER BY id`)
	if err != nil {
		return nil, nil, 0, err
	}
	defer rows.Close()
	byName := map[string][]vmRef{}
	var ids []int64
	for rows.Next() {
		var item vmRef
		if err := rows.Scan(&item.ID, &item.Name); err != nil {
			return nil, nil, 0, err
		}
		item.Name = strings.TrimSpace(item.Name)
		byName[item.Name] = append(byName[item.Name], item)
		ids = append(ids, item.ID)
	}
	ambiguous := 0
	for _, refs := range byName {
		if len(refs) > 1 {
			ambiguous += len(refs)
		}
	}
	return byName, ids, ambiguous, rows.Err()
}

type aggregate struct {
	protected             bool
	jobNames              string
	policyName            string
	repositories          string
	primaryRepository     string
	secondaryRepositories string
	scheduleText          string
	retentionType         string
	retentionQuantity     int
	gfsWeeklyWeeks        int
	gfsWeeklyDay          string
	gfsMonthlyMonths      int
	gfsMonthlyWeek        string
	gfsYearlyYears        int
	gfsYearlyMonth        string
	lastResult            string
	lastBackup            *time.Time
	nextRun               *time.Time
	restorePoints         int
	errorMessage          string
}

func findJobForBackup(jobs map[string]JobState, backup Backup) JobState {
	for _, id := range []string{backup.JobID, backup.PolicyUniqueID} {
		if job, ok := jobs[normalizeID(id)]; ok && job.ID != "" {
			return job
		}
	}
	if name := normalizeName(backup.Name); name != "" {
		if job, ok := jobs["name:"+name]; ok {
			return job
		}
	}
	return JobState{}
}

func findJobDefinition(jobs map[string]JobDefinition, backup Backup, state JobState) JobDefinition {
	for _, id := range []string{backup.JobID, backup.PolicyUniqueID, state.ID} {
		if job, ok := jobs[normalizeID(id)]; ok && job.ID != "" {
			return job
		}
	}
	for _, name := range []string{state.Name, backup.Name} {
		if key := normalizeName(name); key != "" {
			if job, ok := jobs["name:"+key]; ok {
				return job
			}
		}
	}
	return JobDefinition{}
}

func resolveRepositoryName(backup Backup, state JobState, definition JobDefinition, repositories map[string]string) string {
	if v := firstNonEmpty(backup.RepositoryName, state.RepositoryName); v != "" {
		return v
	}
	for _, id := range []string{backup.RepositoryID, state.RepositoryID, definition.Storage.BackupRepositoryID, definition.Storage.TargetRepositoryID} {
		if name := repositories[normalizeID(id)]; name != "" {
			return name
		}
	}
	return ""
}

func summarizeCandidates(items []candidate) aggregate {
	var out aggregate
	var jobs, repos, primaryRepos, secondaryRepos, errorsList []string
	var selected, policySelected *candidate
	for i := range items {
		item := &items[i]
		out.restorePoints += maxInt(item.Object.RestorePointsCount, 0)
		if item.Object.RestorePointsCount > 0 || item.Latest != nil {
			out.protected = true
		}
		jobs = appendUnique(jobs, firstNonEmpty(item.Job.Name, item.Definition.Name, item.Backup.Name))
		repo := firstNonEmpty(item.RepositoryName, item.Backup.RepositoryName, item.Job.RepositoryName)
		repos = appendUnique(repos, repo)
		if isCopyCandidate(item) {
			secondaryRepos = appendUnique(secondaryRepos, repo)
		} else {
			primaryRepos = appendUnique(primaryRepos, repo)
			if policySelected == nil || newerCandidate(item, policySelected) {
				policySelected = item
			}
		}
		if item.Error != "" {
			errorsList = appendUnique(errorsList, item.Error)
		}
		if selected == nil || newerCandidate(item, selected) {
			selected = item
		}
		out.lastResult = worstResult(out.lastResult, item.Job.LastResult)
		if item.Job.NextRun != nil && !item.Job.NextRun.Time.IsZero() && (out.nextRun == nil || item.Job.NextRun.Time.Before(*out.nextRun)) {
			t := item.Job.NextRun.Time.UTC()
			out.nextRun = &t
		}
	}
	if len(primaryRepos) == 0 && len(repos) > 0 {
		primaryRepos = append(primaryRepos, repos[0])
		for _, r := range repos[1:] {
			secondaryRepos = appendUnique(secondaryRepos, r)
		}
	}
	if selected != nil {
		if selected.Latest != nil && selected.Latest.CreationTime != nil {
			t := selected.Latest.CreationTime.Time.UTC()
			out.lastBackup = &t
		}
		if out.lastBackup == nil && selected.Backup.CreationTime != nil {
			t := selected.Backup.CreationTime.Time.UTC()
			out.lastBackup = &t
		}
	}
	if policySelected == nil {
		policySelected = selected
	}
	if policySelected != nil && policySelected.Definition.ID != "" {
		def := policySelected.Definition
		out.policyName = firstNonEmpty(def.Name, policySelected.Job.Name)
		out.scheduleText = scheduleText(def.Schedule)
		out.retentionType = def.Storage.RetentionPolicy.Type
		out.retentionQuantity = maxInt(def.Storage.RetentionPolicy.Quantity.Int(), 0)
		if def.Storage.GFSPolicy.IsEnabled {
			if def.Storage.GFSPolicy.Weekly.IsEnabled {
				out.gfsWeeklyWeeks = maxInt(def.Storage.GFSPolicy.Weekly.KeepForNumberOfWeeks.Int(), 0)
				out.gfsWeeklyDay = def.Storage.GFSPolicy.Weekly.DesiredTime
			}
			if def.Storage.GFSPolicy.Monthly.IsEnabled {
				out.gfsMonthlyMonths = maxInt(def.Storage.GFSPolicy.Monthly.KeepForNumberOfMonths.Int(), 0)
				out.gfsMonthlyWeek = def.Storage.GFSPolicy.Monthly.DesiredTime
			}
			if def.Storage.GFSPolicy.Yearly.IsEnabled {
				out.gfsYearlyYears = maxInt(def.Storage.GFSPolicy.Yearly.KeepForNumberOfYears.Int(), 0)
				out.gfsYearlyMonth = def.Storage.GFSPolicy.Yearly.DesiredTime
			}
		}
	}
	sort.Strings(jobs)
	sort.Strings(repos)
	sort.Strings(primaryRepos)
	sort.Strings(secondaryRepos)
	out.jobNames = truncate(strings.Join(jobs, ", "), 255)
	out.repositories = truncate(strings.Join(repos, ", "), 255)
	out.primaryRepository = truncate(strings.Join(primaryRepos, ", "), 255)
	out.secondaryRepositories = truncate(strings.Join(secondaryRepos, ", "), 512)
	out.policyName = truncate(out.policyName, 255)
	out.scheduleText = truncate(out.scheduleText, 512)
	out.errorMessage = truncate(strings.Join(errorsList, "; "), 4000)
	return out
}

func isCopyCandidate(item *candidate) bool {
	v := strings.ToLower(firstNonEmpty(item.Definition.Type, item.Backup.JobType, item.Job.Type))
	return strings.Contains(v, "copy")
}

func scheduleText(v JobSchedule) string {
	if !v.RunAutomatically {
		return "Manual / programare dezactivată"
	}
	parts := make([]string, 0, 3)
	if v.Daily.IsEnabled {
		when := strings.TrimSpace(v.Daily.LocalTime)
		days := romanianDays(v.Daily.Days)
		kind := strings.TrimSpace(v.Daily.DailyKind)
		if days == "" {
			days = kind
		}
		parts = append(parts, strings.TrimSpace("Zilnic "+days+" "+when))
	}
	if v.Monthly.IsEnabled {
		when := strings.TrimSpace(v.Monthly.LocalTime)
		rule := strings.TrimSpace(strings.Join(nonEmptyStrings(v.Monthly.DayNumberInMonth, v.Monthly.DayOfWeek), " "))
		if v.Monthly.DayOfMonth.Int() > 0 {
			rule = fmt.Sprintf("ziua %d", v.Monthly.DayOfMonth.Int())
		}
		parts = append(parts, strings.TrimSpace("Lunar "+rule+" "+when))
	}
	if v.Periodically.IsEnabled {
		unit := strings.ToLower(strings.TrimSpace(v.Periodically.PeriodicallyKind))
		if unit == "" {
			unit = "interval"
		}
		parts = append(parts, fmt.Sprintf("Periodic: %d %s", v.Periodically.Frequency.Int(), unit))
	}
	if len(parts) == 0 {
		return "Automat"
	}
	return strings.Join(parts, " · ")
}

func romanianDays(days []string) string {
	if len(days) == 0 {
		return ""
	}
	m := map[string]string{"monday": "Lu", "tuesday": "Ma", "wednesday": "Mi", "thursday": "Jo", "friday": "Vi", "saturday": "Sâ", "sunday": "Du"}
	out := make([]string, 0, len(days))
	for _, d := range days {
		key := strings.ToLower(strings.TrimSpace(d))
		if v := m[key]; v != "" {
			out = append(out, v)
		} else if d != "" {
			out = append(out, d)
		}
	}
	return strings.Join(out, ",")
}
func nonEmptyStrings(values ...string) []string {
	out := make([]string, 0, len(values))
	for _, v := range values {
		if strings.TrimSpace(v) != "" {
			out = append(out, strings.TrimSpace(v))
		}
	}
	return out
}

func newerCandidate(a, b *candidate) bool {
	at, bt := candidateTime(a), candidateTime(b)
	if at.IsZero() {
		return false
	}
	if bt.IsZero() {
		return true
	}
	return at.After(bt)
}
func candidateTime(c *candidate) time.Time {
	if c.Latest != nil && c.Latest.CreationTime != nil {
		return c.Latest.CreationTime.Time
	}
	if c.Backup.CreationTime != nil {
		return c.Backup.CreationTime.Time
	}
	return time.Time{}
}
func worstResult(current, next string) string {
	rank := func(v string) int {
		switch strings.ToLower(v) {
		case "failed", "error":
			return 4
		case "warning":
			return 3
		case "success":
			return 2
		case "none", "":
			return 0
		default:
			return 1
		}
	}
	if rank(next) > rank(current) {
		return next
	}
	return current
}
func appendUnique(items []string, value string) []string {
	value = strings.TrimSpace(value)
	if value == "" {
		return items
	}
	for _, v := range items {
		if v == value {
			return items
		}
	}
	return append(items, value)
}
func firstNonEmpty(values ...string) string {
	for _, v := range values {
		if strings.TrimSpace(v) != "" {
			return strings.TrimSpace(v)
		}
	}
	return ""
}
func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func nullableInt(v int) any {
	if v <= 0 {
		return nil
	}
	return v
}
func nullableTime(v *time.Time) any {
	if v == nil || v.IsZero() {
		return nil
	}
	return v.UTC()
}
func isVMObject(v BackupObject) bool {
	t := strings.ToLower(strings.TrimSpace(v.Type))
	vi := strings.ToLower(strings.TrimSpace(v.VIType))
	// VBR reports backed-up virtual machines as type=VM. VMware templates
	// may have viType=VirtualMachine too, so viType alone must not turn a
	// template into a VM match. The viType fallback only covers older/partial
	// responses where type is absent.
	if t == "vm" {
		return true
	}
	return t == "" && vi == "virtualmachine"
}

func (s *Service) failRun(ctx context.Context, runID, sourceID int64, err error) {
	message := truncate(err.Error(), 4000)
	now := time.Now().UTC()
	_, _ = s.DB.ExecContext(ctx, `UPDATE veeam_sync_runs SET status='failed',finished_at=?,error_message=? WHERE id=?`, now, message, runID)
	_, _ = s.DB.ExecContext(ctx, `UPDATE veeam_sources SET last_sync_at=?,last_error=? WHERE id=?`, now, message, sourceID)
	s.Logger.Error("Veeam synchronization failed", "source_id", sourceID, "run_id", runID, "error", err)
}

func (s *Service) decryptPassword(record SourceRecord) (string, error) {
	plain, err := s.Box.Decrypt(record.PasswordCiphertext, "vm-doc-veeam-password:"+record.SecretRef)
	if err != nil {
		return "", err
	}
	return string(plain), nil
}

func (s *Service) normalizeSource(in *SourceInput, create bool) error {
	in.Name = strings.TrimSpace(in.Name)
	in.BaseURL = strings.TrimSpace(in.BaseURL)
	in.Username = strings.TrimSpace(in.Username)
	in.APIVersion = strings.TrimSpace(in.APIVersion)
	in.TLSServerName = strings.TrimSpace(in.TLSServerName)
	if in.APIVersion == "" {
		in.APIVersion = "1.1-rev1"
	}
	if in.SyncIntervalMinutes == 0 {
		in.SyncIntervalMinutes = 1440
	}
	if in.Name == "" || in.BaseURL == "" || in.Username == "" {
		return errors.New("name, base_url and username are required")
	}
	if create && in.Password == "" {
		return errors.New("password is required")
	}
	u, err := url.Parse(in.BaseURL)
	if err != nil || u.Host == "" || u.Scheme == "" {
		return errors.New("invalid base_url")
	}
	if u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return errors.New("base_url must contain only scheme, host and optional port")
	}
	if u.Scheme != "https" && !(s.Config.AllowHTTP && u.Scheme == "http") {
		return errors.New("base_url must use HTTPS")
	}
	if in.SyncIntervalMinutes < 15 || in.SyncIntervalMinutes > 10080 {
		return errors.New("sync_interval_minutes must be between 15 and 10080")
	}
	if !validAPIVersion(in.APIVersion) {
		return errors.New("api_version must look like 1.1-rev1")
	}
	return nil
}
func validAPIVersion(v string) bool {
	parts := strings.Split(v, "-rev")
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return false
	}
	for _, r := range strings.Split(parts[0], ".") {
		if r == "" {
			return false
		}
		for _, c := range r {
			if c < '0' || c > '9' {
				return false
			}
		}
	}
	for _, c := range parts[1] {
		if c < '0' || c > '9' {
			return false
		}
	}
	return true
}
func truncate(v string, n int) string {
	if len(v) > n {
		return v[:n]
	}
	return v
}

const sourceSelect = `SELECT s.id,s.secret_ref,s.name,s.base_url,s.username,s.password_ciphertext,s.api_version,s.enabled,s.verify_tls,s.tls_server_name,s.sync_interval_minutes,s.last_sync_at,s.last_success_at,s.last_error,s.created_at,s.updated_at FROM veeam_sources s`

func scanSource(scanner interface{ Scan(...any) error }) (SourceRecord, error) {
	var record SourceRecord
	var lastSync, lastSuccess sql.NullTime
	err := scanner.Scan(&record.ID, &record.SecretRef, &record.Name, &record.BaseURL, &record.Username, &record.PasswordCiphertext, &record.APIVersion, &record.Enabled, &record.VerifyTLS, &record.TLSServerName, &record.SyncIntervalMinutes, &lastSync, &lastSuccess, &record.LastError, &record.CreatedAt, &record.UpdatedAt)
	if err != nil {
		return record, err
	}
	record.PasswordConfigured = record.PasswordCiphertext != ""
	if lastSync.Valid {
		record.LastSyncAt = &lastSync.Time
	}
	if lastSuccess.Valid {
		record.LastSuccessAt = &lastSuccess.Time
	}
	return record, nil
}

const runSelect = `SELECT r.id,r.veeam_source_id,s.name,r.source,r.status,r.requested_by_user_id,r.started_at,r.finished_at,r.backup_object_count,r.matched_vm_count,r.protected_vm_count,r.unprotected_vm_count,r.ambiguous_count,r.error_message,r.created_at FROM veeam_sync_runs r JOIN veeam_sources s ON s.id=r.veeam_source_id`

func scanRun(scanner interface{ Scan(...any) error }) (domain.VeeamSyncRun, error) {
	var run domain.VeeamSyncRun
	var requested sql.NullInt64
	var started, finished sql.NullTime
	err := scanner.Scan(&run.ID, &run.VeeamSourceID, &run.VeeamSourceName, &run.Source, &run.Status, &requested, &started, &finished, &run.BackupObjectCount, &run.MatchedVMCount, &run.ProtectedVMCount, &run.UnprotectedVMCount, &run.AmbiguousCount, &run.ErrorMessage, &run.CreatedAt)
	if err != nil {
		return run, err
	}
	if requested.Valid {
		v := requested.Int64
		run.RequestedByUserID = &v
	}
	if started.Valid {
		t := started.Time
		run.StartedAt = &t
	}
	if finished.Valid {
		t := finished.Time
		run.FinishedAt = &t
	}
	return run, nil
}
