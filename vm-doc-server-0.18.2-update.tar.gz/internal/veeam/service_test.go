package veeam

import (
	"encoding/json"
	"testing"
	"time"
)

func TestFlexIntAcceptsStringAndNumber(t *testing.T) {
	for _, raw := range []string{`7`, `"7"`} {
		var v FlexInt
		if err := json.Unmarshal([]byte(raw), &v); err != nil {
			t.Fatalf("unmarshal %s: %v", raw, err)
		}
		if v.Int() != 7 {
			t.Fatalf("got %d for %s", v.Int(), raw)
		}
	}
}

func TestSummarizeCandidatesPolicyAndSecondaryStorage(t *testing.T) {
	now := time.Date(2026, 9, 7, 2, 0, 0, 0, time.UTC)
	primary := candidate{
		Object:         BackupObject{RestorePointsCount: 7},
		Job:            JobState{Name: "JOB-PROD", LastResult: "Success", NextRun: &VTime{Time: now.Add(24 * time.Hour)}},
		Definition:     JobDefinition{ID: "job-1", Name: "JOB-PROD", Type: "Backup"},
		RepositoryName: "Repo-Primary",
		Latest:         &RestorePoint{CreationTime: &VTime{Time: now}},
	}
	primary.Definition.Storage.RetentionPolicy.Type = "RestorePoints"
	primary.Definition.Storage.RetentionPolicy.Quantity = FlexInt(14)
	primary.Definition.Storage.GFSPolicy.IsEnabled = true
	primary.Definition.Storage.GFSPolicy.Weekly.IsEnabled = true
	primary.Definition.Storage.GFSPolicy.Weekly.KeepForNumberOfWeeks = FlexInt(4)
	primary.Definition.Storage.GFSPolicy.Weekly.DesiredTime = "Sunday"
	primary.Definition.Schedule.RunAutomatically = true
	primary.Definition.Schedule.Daily.IsEnabled = true
	primary.Definition.Schedule.Daily.LocalTime = "22:00"
	primary.Definition.Schedule.Daily.Days = []string{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"}

	copyJob := candidate{
		Object:         BackupObject{RestorePointsCount: 3},
		Job:            JobState{Name: "COPY-PROD", LastResult: "Success"},
		Definition:     JobDefinition{ID: "job-2", Name: "COPY-PROD", Type: "BackupCopy"},
		RepositoryName: "Repo-Secondary",
	}

	got := summarizeCandidates([]candidate{primary, copyJob})
	if !got.protected || got.primaryRepository != "Repo-Primary" || got.secondaryRepositories != "Repo-Secondary" {
		t.Fatalf("unexpected storage summary: %+v", got)
	}
	if got.retentionType != "RestorePoints" || got.retentionQuantity != 14 || got.gfsWeeklyWeeks != 4 {
		t.Fatalf("unexpected retention summary: %+v", got)
	}
	if got.scheduleText == "" {
		t.Fatal("expected schedule text")
	}
}
