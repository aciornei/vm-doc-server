package buildinfo

var (
	Version = "0.18.2-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
