-- 0.18.2: detalii retenție/GFS, repository primar/secundar și backup cron declarat manual.

ALTER TABLE vm_backup_summary
  ADD COLUMN IF NOT EXISTS primary_repository_name VARCHAR(255) NOT NULL DEFAULT '' AFTER repository_name,
  ADD COLUMN IF NOT EXISTS secondary_repository_names VARCHAR(512) NOT NULL DEFAULT '' AFTER primary_repository_name,
  ADD COLUMN IF NOT EXISTS schedule_text VARCHAR(512) NOT NULL DEFAULT '' AFTER secondary_repository_names,
  ADD COLUMN IF NOT EXISTS retention_type VARCHAR(32) NOT NULL DEFAULT '' AFTER schedule_text,
  ADD COLUMN IF NOT EXISTS retention_quantity INT UNSIGNED NULL AFTER retention_type,
  ADD COLUMN IF NOT EXISTS gfs_weekly_weeks INT UNSIGNED NULL AFTER retention_quantity,
  ADD COLUMN IF NOT EXISTS gfs_weekly_day VARCHAR(32) NOT NULL DEFAULT '' AFTER gfs_weekly_weeks,
  ADD COLUMN IF NOT EXISTS gfs_monthly_months INT UNSIGNED NULL AFTER gfs_weekly_day,
  ADD COLUMN IF NOT EXISTS gfs_monthly_week VARCHAR(32) NOT NULL DEFAULT '' AFTER gfs_monthly_months,
  ADD COLUMN IF NOT EXISTS gfs_yearly_years INT UNSIGNED NULL AFTER gfs_monthly_week,
  ADD COLUMN IF NOT EXISTS gfs_yearly_month VARCHAR(32) NOT NULL DEFAULT '' AFTER gfs_yearly_years,
  ADD COLUMN IF NOT EXISTS cron_backup_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER gfs_yearly_month,
  ADD COLUMN IF NOT EXISTS cron_backup_schedule VARCHAR(255) NOT NULL DEFAULT '' AFTER cron_backup_enabled,
  ADD COLUMN IF NOT EXISTS cron_backup_command VARCHAR(1024) NOT NULL DEFAULT '' AFTER cron_backup_schedule,
  ADD COLUMN IF NOT EXISTS cron_backup_notes TEXT NOT NULL AFTER cron_backup_command;
