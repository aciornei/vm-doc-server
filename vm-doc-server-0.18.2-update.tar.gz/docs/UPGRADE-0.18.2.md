# Upgrade vm-doc-server 0.18.1 → 0.18.2

0.18.2 extinde integrarea Backup/Veeam și corectează tratarea fusului orar. Agentul rămâne 1.6.2.

## Pași

1. Opriți `vm-doc-server`.
2. Aplicați `vm-doc-server-0.18.2-update.tar.gz` peste o copie a sursei 0.18.1.
3. Verificați `/etc/vm-doc-server/config.yaml`: `app.timezone` trebuie să fie `Europe/Bucharest`.
4. Rulați testele/buildul offline cu `vendor/`.
5. Instalați ambele binare (`vm-doc-server` și `vm-doc-collector`) și reporniți ambele servicii; conexiunea DB comună a fost normalizată la UTC.
6. Verificați aplicarea migrației `035_backup_policy_cron_timezone.up.sql`.
7. Executați o sincronizare Veeam pentru popularea programării, retenției, GFS și storage-urilor.
   În fila Backup a VM-ului pot fi selectate și cron-uri deja raportate de agent pentru a le marca drept backup local.
8. Faceți `Ctrl+F5` în browser.

## Timezone

Conexiunea MariaDB setează sesiunea la UTC. UI afișează datele în `app.timezone`, implicit `Europe/Bucharest`. Acest lucru evită decalajul de +3 ore observat la sincronizările vCenter/Veeam.
