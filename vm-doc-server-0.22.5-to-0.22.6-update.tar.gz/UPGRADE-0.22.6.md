# Upgrade VM-DOC 0.22.5 → 0.22.6

1. Backup MariaDB și binare; testați într-un staging; verificați că sursele 0.22.5 și `vendor/` sunt disponibile.
2. Extrageți arhiva update în arborele de surse (nu în `/opt/vm-doc-server`, care conține doar binarele).
3. Din directorul sursă, `GOPROXY=off GOSUMDB=off go test -mod=vendor ./...`; apoi compilați explicit din surse cu `CGO_ENABLED=0 GOPROXY=off GOSUMDB=off go build -mod=vendor -trimpath -ldflags "-X vm-doc-server/internal/buildinfo.Version=0.22.6" -o bin/vm-doc-server ./cmd/vm-doc-server`. Nu rulați `make build` până când scriptul de organizare a surselor nu confirmă un arbore curat.
4. Opriți `vm-doc-server` (NU este necesară oprirea collectorului), înlocuiți binarul (backup înainte), porniți și verificați migrarea 088 în `schema_migrations`.
5. În Documente → Configurare Outline salvați `Arhivă VM · Document / URL` — copil existent sub Virtualizare; serverul rezolvă UUID/slug/URL.
6. Testați o VM necritică: conținut în Outline mutat sub Arhivă păstrând ID-ul; asocierile ei dispar din serviciile active; istoric în `vm_retirement_service_assignments`; `Arhivează` păstrează aprobator și retenție.

**IMPORTANT**: Nu extrageți source ZIP peste arbori cu `vendor/` fără backup. Binarul `vm-doc-collector` și agenții nu trebuie modificați. Înainte de producție validați MariaDB și Outline API. Dacă upgrade-ul e rollbackat, nu ștergeți tabelul `vm_retirement_service_assignments`.

**Reactivare VM:** reatașarea serviciilor se face numai după verificare manuală; publicați din nou fișa în Outline după reactivare pentru a o muta înapoi sub Virtualizare și a elimina mesajul Retrasă.
