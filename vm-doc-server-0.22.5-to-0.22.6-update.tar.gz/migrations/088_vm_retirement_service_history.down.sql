-- Data-retaining downgrade: historical relationships are preserved for audit.
SELECT 1;
