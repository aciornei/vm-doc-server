-- 0.22.6. Full snapshot of service assignments before a retired VM is detached
-- from LIVE service composition. Historical data is never deleted by retirement.
CREATE TABLE IF NOT EXISTS vm_retirement_service_assignments (
  assignment_id BIGINT UNSIGNED NOT NULL,
  vm_id BIGINT UNSIGNED NOT NULL,
  internal_service_id BIGINT UNSIGNED NOT NULL,
  architectural_domain_id BIGINT UNSIGNED NOT NULL,
  itil_category_id BIGINT UNSIGNED NOT NULL,
  layer_id BIGINT UNSIGNED NULL,
  technical_role_id BIGINT UNSIGNED NULL,
  solution_type_id BIGINT UNSIGNED NULL,
  usage_type VARCHAR(32) NOT NULL DEFAULT 'dedicated',
  is_primary TINYINT(1) NOT NULL DEFAULT 0,
  notes VARCHAR(1000) NOT NULL DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0,
  updated_by BIGINT UNSIGNED NULL,
  original_created_at DATETIME(6) NOT NULL,
  original_updated_at DATETIME(6) NOT NULL,
  detached_at DATETIME(6) NOT NULL,
  PRIMARY KEY (assignment_id),
  INDEX idx_vm_retirement_service_vm (vm_id,detached_at),
  INDEX idx_vm_retirement_service_service (internal_service_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
