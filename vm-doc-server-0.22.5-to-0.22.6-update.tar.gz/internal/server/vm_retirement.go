package server

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/documents"
	outlineapi "vm-doc-server/internal/outline"
	"vm-doc-server/internal/rbac"
)

// Retirement is an explicit, ordered, retryable workflow. The Outline operation
// happens BEFORE the single SQL transaction that marks the VM retired. In case
// the remote API fails, the operational/technical state is left unchanged.
// The job is asynchronous so reverse-proxy request timeouts do not interrupt it.
func (a *App) startVMRetirement(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var change lifecycleChange
	if err = decodeJSON(r, &change, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if change.Status != "retired" {
		badRequest(w, errors.New("status must be retired"))
		return
	}
	if err = validLifecycleChange(change); err != nil {
		badRequest(w, err)
		return
	}
	if strings.TrimSpace(change.Reason) == "" {
		badRequest(w, errors.New("motivul retragerii este obligatoriu"))
		return
	}
	var retired bool
	if err = a.DB.QueryRowContext(r.Context(), `SELECT retired FROM virtual_machines WHERE id=?`, id).Scan(&retired); err != nil {
		respond(w, nil, err)
		return
	}
	if retired {
		badRequest(w, errors.New("VM este deja retrasă tehnic; folosește Arhivă pentru următoarea etapă"))
		return
	}
	if err = a.ensureNotArchived(r.Context(), "vm", id); err != nil {
		badRequest(w, err)
		return
	}
	now := time.Now().UTC()
	outlineBulkJobs.Lock()
	for key, existing := range outlineBulkJobs.values {
		if existing.Kind == "vm_retirement" && existing.VMID == id && existing.Status != "success" && existing.Status != "failed" && existing.Status != "partial" {
			result := *existing
			outlineBulkJobs.Unlock()
			jsonResponse(w, http.StatusAccepted, result)
			return
		}
		if !existing.FinishedAt.IsZero() && now.Sub(existing.FinishedAt) > 24*time.Hour {
			delete(outlineBulkJobs.values, key)
		}
	}
	job := &outlineBulkJob{ID: fmt.Sprintf("vm-retire-%d-%d", id, now.UnixNano()), VMID: id, Kind: "vm_retirement", Status: "queued", StartedAt: now, TotalVMs: 1, RetirementStatus: "pending"}
	outlineBulkJobs.values[job.ID] = job
	outlineBulkJobs.Unlock()
	bgRequest := r.Clone(context.WithoutCancel(r.Context()))
	go a.runVMRetirement(bgRequest, job, change)
	jsonResponse(w, http.StatusAccepted, job)
}

func (a *App) getVMRetirementJob(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	key := strings.TrimSpace(r.PathValue("job_id"))
	outlineBulkJobs.RLock()
	job := outlineBulkJobs.values[key]
	if job == nil || job.Kind != "vm_retirement" || job.VMID != id {
		outlineBulkJobs.RUnlock()
		respond(w, nil, sql.ErrNoRows)
		return
	}
	result := *job
	result.Errors = append([]string(nil), job.Errors...)
	outlineBulkJobs.RUnlock()
	jsonResponse(w, http.StatusOK, result)
}

func retirementText(value string) string {
	return strings.Join(strings.Fields(strings.TrimSpace(value)), " ")
}

func retirementOperationalNotes(original, reason, approvedBy, notes string, day time.Time) (string, error) {
	entry := "Retragere VM (" + day.Format("2006-01-02") + "): " + retirementText(reason)
	if strings.TrimSpace(approvedBy) != "" {
		entry += "\nAprobat de: " + retirementText(approvedBy)
	}
	if strings.TrimSpace(notes) != "" {
		entry += "\nDetalii retragere: " + retirementText(notes)
	}
	original = strings.TrimSpace(original)
	if !strings.Contains(original, entry) {
		if original != "" {
			original += "\n\n"
		}
		original += entry
	}
	if len([]byte(original)) > 60000 {
		return "", errors.New("observațiile operaționale depășesc limita; scurtează motivul și detaliile")
	}
	return original, nil
}

func safeRetirementMarkdown(value string) string {
	value = retirementText(value)
	return strings.NewReplacer("\\", "\\\\", "<", "&lt;", ">", "&gt;", "*", "\\*", "_", "\\_", "`", "\\`", "[", "\\[", "]", "\\]", "|", "\\|", "&", "&amp;").Replace(value)
}

func retirementOutlineMarkdown(data documents.GenerationData, reason, approvedBy, notes string, day time.Time) []byte {
	content := string(documents.RenderVMMarkdown(data))
	var b strings.Builder
	b.WriteString("> **VM RETRASĂ DIN EXPLOATARE** · Data retragerii: **")
	b.WriteString(day.Format("02.01.2006"))
	b.WriteString("**\n")
	b.WriteString("> Motiv: ")
	b.WriteString(safeRetirementMarkdown(reason))
	b.WriteString("\n")
	if strings.TrimSpace(approvedBy) != "" {
		b.WriteString("> Aprobat de: ")
		b.WriteString(safeRetirementMarkdown(approvedBy))
		b.WriteString("\n")
	}
	if strings.TrimSpace(notes) != "" {
		b.WriteString("> Detalii: ")
		b.WriteString(safeRetirementMarkdown(notes))
		b.WriteString("\n")
	}
	b.WriteString("\n")
	// Keep the original heading and all technical documentation, adding only
	// a visible lifecycle notice. Do not modify Vault/export policies.
	split := strings.Index(content, "\n\n")
	if split < 0 {
		return []byte(b.String() + content)
	}
	return []byte(content[:split+2] + b.String() + content[split+2:])
}

func (a *App) runVMRetirement(r *http.Request, job *outlineBulkJob, change lifecycleChange) {
	ctx, cancel := context.WithTimeout(r.Context(), 5*time.Minute)
	defer cancel()
	r = r.Clone(ctx)
	set := func(fn func(*outlineBulkJob)) { outlineBulkJobs.Lock(); fn(job); outlineBulkJobs.Unlock() }
	set(func(j *outlineBulkJob) {
		j.Status = "running"
		j.RetirementStatus = "preparing"
		j.LastObject = "Pregătire ultima fișă VM"
	})
	published := false
	var detached int64
	var result outlineapi.PublishResult
	err := a.performVMRetirement(r, job.VMID, change, &published, &detached, &result, set)
	set(func(j *outlineBulkJob) {
		j.FinishedAt = time.Now().UTC()
		j.LastObject = ""
		j.ProcessedVMs = 1
		if published {
			j.PublishedVMs = 1
			j.ResultURL = result.URL
			j.ResultDocumentID = result.DocumentID
			j.ResultCreated = result.Created
		}
		if err != nil {
			j.Status = "failed"
			j.RetirementStatus = "not_retired"
			j.Errors = append(j.Errors, err.Error())
		} else {
			j.Status = "success"
			j.DetachedServiceAssignments = detached
			j.RetirementStatus = "retired"
			if !published {
				j.SkippedVMs = 1
			}
		}
	})
	if err != nil {
		a.auditRequest(r, "lifecycle.vm.retire", "virtual_machine", strconv.FormatInt(job.VMID, 10), "failed", map[string]any{"reason": change.Reason, "approved_by": change.ApprovedBy, "stage": "outline_or_database", "error": err.Error(), "outline_published": published})
		if a.Logger != nil {
			a.Logger.Error("VM retirement failed", "vm_id", job.VMID, "error", err)
		}
	} else {
		a.auditRequest(r, "lifecycle.retired", "virtual_machine", strconv.FormatInt(job.VMID, 10), "success", map[string]any{"reason": change.Reason, "approved_by": change.ApprovedBy, "outline_published": published, "outline_url": result.URL, "service_assignments_detached": detached})
	}
}

func (a *App) performVMRetirement(r *http.Request, vmID int64, change lifecycleChange, published *bool, detached *int64, result *outlineapi.PublishResult, set func(func(*outlineBulkJob))) error {
	ctx := r.Context()
	// Resolve the canonical operational nomenclature, not a hardcoded display name.
	var statusID int64
	var statusName string
	if err := a.DB.QueryRowContext(ctx, `SELECT id,name FROM nomenclature_items WHERE category_code='operational_status' AND (LOWER(TRIM(item_code))='retired' OR LOWER(TRIM(name)) IN ('retras','retired')) ORDER BY CASE WHEN LOWER(TRIM(item_code))='retired' THEN 0 ELSE 1 END,active DESC,id LIMIT 1`).Scan(&statusID, &statusName); err != nil {
		return fmt.Errorf("statusul operațional Retras nu există în nomenclator: %w", err)
	}
	if statusID <= 0 {
		return errors.New("nomenclatorul Retras este invalid")
	}
	operational, err := a.VCenter.GetOperationalMetadata(ctx, vmID)
	if err != nil {
		return fmt.Errorf("citește statusul VM: %w", err)
	}
	date := time.Now().UTC()
	reason := strings.TrimSpace(change.Reason)
	notes, err := retirementOperationalNotes(operational.Notes, reason, change.ApprovedBy, change.Notes, date)
	if err != nil {
		return err
	}
	env := operational.Environment
	disabled, err := a.vmOutlinePublicationDisabled(ctx, vmID)
	if err != nil {
		return err
	}
	needsOutline := outlineBulkProductionEnvironment(env) && !disabled
	if needsOutline {
		user, _ := auth.UserFromContext(ctx)
		if !rbac.Allowed(user.Roles, "documents.manage") {
			return errors.New("publicarea finală în Outline necesită și dreptul documents.manage")
		}
		if a.Outline == nil {
			return errors.New("publicarea finală este obligatorie pentru VM PROD, dar integrarea Outline lipsește")
		}
		settings, settingsErr := a.Outline.GetSettings(ctx)
		if settingsErr != nil {
			return fmt.Errorf("verifică integrarea Outline: %w", settingsErr)
		}
		if !settings.Enabled {
			return errors.New("Outline este dezactivat: VM PROD nu poate fi retrasă fără publicarea finală; activează Outline sau marchează explicit Nu se publică în Outline")
		}
		set(func(j *outlineBulkJob) {
			j.LastObject = "Publicare și mutare fișă în Outline / Arhivă VM"
			j.RetirementStatus = "publishing_outline"
		})
		// This is the ONLY caller allowed to bypass the pool check for documentation.
		// It reads existing VM data without un-excluding the VM for normal exports.
		data, loadErr := a.buildVMGenerationDataForRetirement(r, vmID, true)
		if loadErr != nil {
			return fmt.Errorf("pregătire fișă istorică: %w", loadErr)
		}
		data.Operational.OperationalStatus = statusName
		data.Operational.OperationalStatusID = &statusID
		data.Operational.Notes = notes
		data.VM.Retired = true
		data.IncludeGeneratedBy = false
		data.OutlineMode = true
		if generated, listErr := a.Documents.ListGeneratedVM(ctx, vmID); listErr == nil && len(generated) > 0 {
			data.DocumentNumber = generated[0].DocumentNumber
			data.GeneratedAt = generated[0].GeneratedAt
		}
		serviceIDs := make([]int64, 0, len(data.Operational.ServiceAssignments))
		seen := map[int64]bool{}
		for _, item := range data.Operational.ServiceAssignments {
			if item.InternalServiceID > 0 && !seen[item.InternalServiceID] {
				seen[item.InternalServiceID] = true
				serviceIDs = append(serviceIDs, item.InternalServiceID)
			}
		}
		data.OutlineServiceURLs, err = a.Outline.ServiceOutlineURLs(ctx, serviceIDs)
		if err != nil {
			return fmt.Errorf("linkuri Outline servicii: %w", err)
		}
		title := outlineVMTitle(firstServerNonEmpty(data.VM.Name, data.VM.GuestHostname, fmt.Sprintf("VM %d", vmID)))
		markdown := retirementOutlineMarkdown(data, reason, change.ApprovedBy, change.Notes, date)
		*result, err = a.Outline.UpsertVMArchiveDocument(ctx, vmID, title, markdown)
		if err != nil {
			return fmt.Errorf("publicarea fișei istorice în Outline a eșuat; retragerea nu a fost aplicată: %w", err)
		}
		*published = true
	}
	set(func(j *outlineBulkJob) {
		j.LastObject = "Salvare status operațional Retras și retragere tehnică"
		j.RetirementStatus = "committing"
	})
	// A single DB transaction commits both statuses together; unrelated VM
	// metadata, service associations and history remain unchanged.
	tx, err := a.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	var retired bool
	if err = tx.QueryRowContext(ctx, `SELECT retired FROM virtual_machines WHERE id=? FOR UPDATE`, vmID).Scan(&retired); err != nil {
		return err
	}
	if retired {
		return errors.New("VM a fost retrasă de o altă operațiune; verifică pagina Outline și registrul de arhivă")
	}
	var archived int
	if err = tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM lifecycle_archives WHERE resource_type='vm' AND resource_id=?`, vmID).Scan(&archived); err != nil {
		return err
	}
	if archived > 0 {
		return errors.New("VM este deja arhivată")
	}
	user, _ := auth.UserFromContext(ctx)
	_, err = tx.ExecContext(ctx, `INSERT INTO vm_operational_metadata(vm_id,purpose,operational_status,notes,updated_by) VALUES(?,'',?,?,?) ON DUPLICATE KEY UPDATE operational_status=VALUES(operational_status),notes=VALUES(notes),updated_by=VALUES(updated_by)`, vmID, statusName, notes, user.ID)
	if err != nil {
		return fmt.Errorf("salvează statusul operațional: %w", err)
	}
	_, err = tx.ExecContext(ctx, `INSERT INTO vm_operational_nomenclatures(vm_id,category_code,item_id) VALUES(?,'operational_status',?) ON DUPLICATE KEY UPDATE item_id=VALUES(item_id)`, vmID, statusID)
	if err != nil {
		return fmt.Errorf("salvează nomenclatorul operațional: %w", err)
	}
	_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET retired=1,retired_at=COALESCE(retired_at,?),retired_by=?,retired_note=? WHERE id=?`, date, user.ID, reason, vmID)
	if err != nil {
		return fmt.Errorf("salvează retragerea tehnică: %w", err)
	}
	// Remove VM from the LIVE composition of its services. Preserve all the original
	// assignment fields in vm_retirement_service_assignments and names in the
	// lifecycle archive before deleting live links, in this same transaction.
	detachedCount, detachErr := detachVMServiceAssignments(ctx, tx, vmID)
	if detachErr != nil {
		err = detachErr
		return fmt.Errorf("arhivarea legăturilor VM–servicii: %w", err)
	}
	if err = tx.Commit(); err != nil {
		return fmt.Errorf("finalizează retragerea tehnică (fișa Outline a fost deja publicată): %w", err)
	}
	*detached = detachedCount
	return nil
}
