package catalog

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/url"
	"regexp"
	"sort"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/richtext"
)

var codePattern = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,127}$`)

var criticalities = map[string]bool{"low": true, "normal": true, "high": true, "critical": true}
var documentationStatuses = map[string]bool{"draft": true, "in_progress": true, "review": true, "approved": true, "obsolete": true}

type Service struct{ DB *sql.DB }

type InternalServiceInput struct {
	// Păstrat numai pentru compatibilitatea cu file de browser mai vechi.
	// Începând cu 0.4.0, categoria se salvează pe asocierea VM–serviciu.
	ITILCategoryID               int64                    `json:"itil_category_id,omitempty"`
	Name                         string                   `json:"name"`
	ServiceCode                  string                   `json:"service_code"`
	ShortDescription             string                   `json:"short_description"`
	Description                  string                   `json:"description"`
	DescriptionRichText          *domain.RichTextDocument `json:"description_richtext,omitempty"`
	Purpose                      string                   `json:"purpose"` // compatibilitate: reprezintă „Scop și domeniu”
	PurposeRichText              *domain.RichTextDocument `json:"purpose_richtext,omitempty"`
	Objectives                   string                   `json:"objectives"`
	ObjectivesRichText           *domain.RichTextDocument `json:"objectives_richtext,omitempty"`
	Authentication               string                   `json:"authentication"`
	ServiceURL                   string                   `json:"service_url"`
	Technologies                 string                   `json:"technologies"`
	Criticality                  string                   `json:"criticality"`
	DocumentationStatus          string                   `json:"documentation_status"`
	DocumentationURL             string                   `json:"documentation_url"`
	VaultURL                     *string                  `json:"vault_url,omitempty"`
	Active                       *bool                    `json:"active,omitempty"`
	Retired                      *bool                    `json:"retired,omitempty"`
	RetirementReasonID           *int64                   `json:"retirement_reason_id,omitempty"`
	RetiredAt                    string                   `json:"retired_at,omitempty"`
	OutlineDocumentationDisabled *bool                    `json:"outline_documentation_disabled,omitempty"`
	IsCommon                     *bool                    `json:"is_common,omitempty"`
	ImplicitGlobal               *bool                    `json:"implicit_global,omitempty"`
	CommonDependencyTypeID       *int64                   `json:"common_dependency_type_id,omitempty"`
}

func (s Service) List(ctx context.Context, includeInactive bool) ([]domain.InternalService, error) {
	query := serviceSelect()
	query += ` WHERE NOT EXISTS (SELECT 1 FROM lifecycle_archives lar WHERE lar.resource_type='service' AND lar.resource_id=service.id)`
	if !includeInactive {
		query += ` AND service.active=1`
	}
	query += ` ORDER BY service.name,service.id`
	rows, err := s.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	values := make([]domain.InternalService, 0)
	for rows.Next() {
		value, err := scanService(rows)
		if err != nil {
			return nil, err
		}
		values = append(values, value)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	classifications, err := s.listAllClassifications(ctx)
	if err != nil {
		return nil, err
	}
	mappings, err := s.listAllMappings(ctx)
	if err != nil {
		return nil, err
	}
	solutionTypes, err := s.listAllSolutionTypes(ctx)
	if err != nil {
		return nil, err
	}
	for i := range values {
		values[i].Classifications = classifications[values[i].ID]
		values[i].ClassificationCount = len(values[i].Classifications)
		values[i].RoleMappings = mappings[values[i].ID]
		values[i].SolutionTypes = solutionTypes[values[i].ID]
		values[i].SolutionTypeCount = len(values[i].SolutionTypes)
		applyClassificationCompatibility(&values[i])
	}
	sort.SliceStable(values, func(i, j int) bool {
		leftDomain, leftCategory := firstClassificationNames(values[i].Classifications)
		rightDomain, rightCategory := firstClassificationNames(values[j].Classifications)
		if leftDomain != rightDomain {
			if leftDomain == "" {
				return false
			}
			if rightDomain == "" {
				return true
			}
			return leftDomain < rightDomain
		}
		if leftCategory != rightCategory {
			return leftCategory < rightCategory
		}
		if values[i].Name != values[j].Name {
			return values[i].Name < values[j].Name
		}
		return values[i].ID < values[j].ID
	})
	return values, nil
}

func (s Service) Get(ctx context.Context, id int64) (domain.InternalService, error) {
	row := s.DB.QueryRowContext(ctx, serviceSelect()+` WHERE service.id=?`, id)
	value, err := scanService(row)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.Classifications, err = s.ListClassifications(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.ClassificationCount = len(value.Classifications)
	applyClassificationCompatibility(&value)
	value.RoleMappings, err = s.ListRoleMappings(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.SolutionTypes, err = s.ListSolutionTypes(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.SolutionTypeCount = len(value.SolutionTypes)
	value.Dependencies, err = s.ListDependencies(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.GlobalDependencies, err = s.ListGlobalDependencies(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.Dependents, err = s.ListDependents(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.DirectVMDependents, err = s.ListDirectVMDependents(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.VMs, err = s.ListVMs(ctx, id)
	return value, err
}

func (s Service) Create(ctx context.Context, userID int64, input InternalServiceInput) (domain.InternalService, error) {
	if err := normalizeService(&input); err != nil {
		return domain.InternalService{}, err
	}
	legacyCategoryID, err := s.defaultCategoryID(ctx)
	if err != nil {
		return domain.InternalService{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	retired := false
	if input.Retired != nil {
		retired = *input.Retired
	}
	if retired {
		active = false
	}
	outlineDisabled := false
	if input.OutlineDocumentationDisabled != nil {
		outlineDisabled = *input.OutlineDocumentationDisabled
	}
	if !retired {
		input.RetirementReasonID = nil
		input.RetiredAt = ""
	}
	isCommon := false
	if input.IsCommon != nil {
		isCommon = *input.IsCommon
	}
	implicitGlobal := false
	if input.ImplicitGlobal != nil {
		implicitGlobal = *input.ImplicitGlobal
	}
	if implicitGlobal {
		isCommon = true
	}
	if !isCommon {
		implicitGlobal = false
		input.CommonDependencyTypeID = nil
	}
	input.IsCommon = &isCommon
	input.ImplicitGlobal = &implicitGlobal
	if err := s.validateCommonServiceInput(ctx, input); err != nil {
		return domain.InternalService{}, err
	}
	if err := s.validateLifecycleInput(ctx, input); err != nil {
		return domain.InternalService{}, err
	}
	descriptionRichText, err := richtext.Encode(input.DescriptionRichText)
	if err != nil {
		return domain.InternalService{}, err
	}
	purposeRichText, err := richtext.Encode(input.PurposeRichText)
	if err != nil {
		return domain.InternalService{}, err
	}
	objectivesRichText, err := richtext.Encode(input.ObjectivesRichText)
	if err != nil {
		return domain.InternalService{}, err
	}
	result, err := s.DB.ExecContext(ctx, `INSERT INTO internal_services(itil_category_id,name,service_code,short_description,description,description_richtext,purpose,purpose_richtext,objectives,objectives_richtext,authentication,service_url,technologies,criticality,documentation_status,documentation_url,vault_url,active,retired,retirement_reason_id,retired_at,outline_documentation_disabled,is_common,implicit_global,common_dependency_type_id,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, legacyCategoryID, input.Name, nullableCode(input.ServiceCode), input.ShortDescription, input.Description, nullableRichText(descriptionRichText), input.Purpose, nullableRichText(purposeRichText), input.Objectives, nullableRichText(objectivesRichText), input.Authentication, input.ServiceURL, input.Technologies, input.Criticality, input.DocumentationStatus, input.DocumentationURL, nullableStringPtr(input.VaultURL), active, retired, nullableInt64Ptr(input.RetirementReasonID), nullableDate(input.RetiredAt), outlineDisabled, isCommon, implicitGlobal, nullableInt64Ptr(input.CommonDependencyTypeID), userID, userID)
	if err != nil {
		return domain.InternalService{}, err
	}
	id, _ := result.LastInsertId()
	return s.Get(ctx, id)
}

func (s Service) Update(ctx context.Context, id, userID int64, input InternalServiceInput) (domain.InternalService, error) {
	current, err := s.Get(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	if strings.TrimSpace(input.Name) == "" {
		input.Name = current.Name
	}
	if input.Active == nil {
		active := current.Active
		input.Active = &active
	}
	if input.Retired == nil {
		value := current.Retired
		input.Retired = &value
		input.RetirementReasonID = current.RetirementReasonID
		if current.RetiredAt != nil {
			input.RetiredAt = current.RetiredAt.Format("2006-01-02")
		}
	}
	if input.OutlineDocumentationDisabled == nil {
		value := current.OutlineDocumentationDisabled
		input.OutlineDocumentationDisabled = &value
	}
	if input.VaultURL == nil {
		value := current.VaultURL
		input.VaultURL = &value
	}
	if input.Retired != nil && *input.Retired {
		value := false
		input.Active = &value
	} else if input.Retired != nil && !*input.Retired {
		input.RetirementReasonID = nil
		input.RetiredAt = ""
	}
	if input.IsCommon == nil {
		value := current.IsCommon
		input.IsCommon = &value
	}
	if input.ImplicitGlobal == nil {
		value := current.ImplicitGlobal
		input.ImplicitGlobal = &value
	}
	if input.CommonDependencyTypeID == nil {
		input.CommonDependencyTypeID = current.CommonDependencyTypeID
	}
	if *input.ImplicitGlobal {
		value := true
		input.IsCommon = &value
	}
	if input.IsCommon != nil && !*input.IsCommon {
		value := false
		input.ImplicitGlobal = &value
		input.CommonDependencyTypeID = nil
		if current.IsCommon {
			if err := s.ensureCanDisableCommon(ctx, id); err != nil {
				return domain.InternalService{}, err
			}
		}
	}
	if err := normalizeService(&input); err != nil {
		return domain.InternalService{}, err
	}
	if err := s.validateCommonServiceInput(ctx, input); err != nil {
		return domain.InternalService{}, err
	}
	if err := s.validateLifecycleInput(ctx, input); err != nil {
		return domain.InternalService{}, err
	}
	descriptionRichText, err := richtext.Encode(input.DescriptionRichText)
	if err != nil {
		return domain.InternalService{}, err
	}
	purposeRichText, err := richtext.Encode(input.PurposeRichText)
	if err != nil {
		return domain.InternalService{}, err
	}
	objectivesRichText, err := richtext.Encode(input.ObjectivesRichText)
	if err != nil {
		return domain.InternalService{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE internal_services SET name=?,service_code=?,short_description=?,description=?,description_richtext=?,purpose=?,purpose_richtext=?,objectives=?,objectives_richtext=?,authentication=?,service_url=?,technologies=?,criticality=?,documentation_status=?,documentation_url=?,vault_url=?,active=?,retired=?,retirement_reason_id=?,retired_at=?,outline_documentation_disabled=?,is_common=?,implicit_global=?,common_dependency_type_id=?,updated_by=? WHERE id=?`, input.Name, nullableCode(input.ServiceCode), input.ShortDescription, input.Description, nullableRichText(descriptionRichText), input.Purpose, nullableRichText(purposeRichText), input.Objectives, nullableRichText(objectivesRichText), input.Authentication, input.ServiceURL, input.Technologies, input.Criticality, input.DocumentationStatus, input.DocumentationURL, nullableStringPtr(input.VaultURL), *input.Active, *input.Retired, nullableInt64Ptr(input.RetirementReasonID), nullableDate(input.RetiredAt), *input.OutlineDocumentationDisabled, *input.IsCommon, *input.ImplicitGlobal, nullableInt64Ptr(input.CommonDependencyTypeID), userID, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	return s.Get(ctx, id)
}

func (s Service) ListClassifications(ctx context.Context, serviceID int64) ([]domain.InternalServiceClassification, error) {
	rows, err := s.DB.QueryContext(ctx, classificationSelect()+` WHERE assignment.internal_service_id=? GROUP BY assignment.architectural_domain_id,domain_item.name,domain_item.sort_order,assignment.itil_category_id,category_item.name,category_item.sort_order ORDER BY domain_item.sort_order,domain_item.name,category_item.sort_order,category_item.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.InternalServiceClassification, 0)
	for rows.Next() {
		var value domain.InternalServiceClassification
		if err := rows.Scan(&value.ArchitecturalDomainID, &value.ArchitecturalDomain, &value.ITILCategoryID, &value.ITILCategory, &value.VMCount, &value.AssignmentCount); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) listAllClassifications(ctx context.Context) (map[int64][]domain.InternalServiceClassification, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.internal_service_id,`+classificationSelectColumns()+`
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items domain_item ON domain_item.id=assignment.architectural_domain_id AND domain_item.category_code='architectural_domain'
		JOIN nomenclature_items category_item ON category_item.id=assignment.itil_category_id AND category_item.category_code='itil_category'
		GROUP BY assignment.internal_service_id,assignment.architectural_domain_id,domain_item.name,domain_item.sort_order,assignment.itil_category_id,category_item.name,category_item.sort_order
		ORDER BY assignment.internal_service_id,domain_item.sort_order,domain_item.name,category_item.sort_order,category_item.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make(map[int64][]domain.InternalServiceClassification)
	for rows.Next() {
		var serviceID int64
		var value domain.InternalServiceClassification
		if err := rows.Scan(&serviceID, &value.ArchitecturalDomainID, &value.ArchitecturalDomain, &value.ITILCategoryID, &value.ITILCategory, &value.VMCount, &value.AssignmentCount); err != nil {
			return nil, err
		}
		out[serviceID] = append(out[serviceID], value)
	}
	return out, rows.Err()
}

func classificationSelect() string {
	return `SELECT ` + classificationSelectColumns() + `
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items domain_item ON domain_item.id=assignment.architectural_domain_id AND domain_item.category_code='architectural_domain'
		JOIN nomenclature_items category_item ON category_item.id=assignment.itil_category_id AND category_item.category_code='itil_category'`
}

func classificationSelectColumns() string {
	return `assignment.architectural_domain_id,domain_item.name,assignment.itil_category_id,category_item.name,COUNT(DISTINCT assignment.vm_id),COUNT(*)`
}

func (s Service) ListRoleMappings(ctx context.Context, serviceID int64) ([]domain.ServiceRoleMapping, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT 0,assignment.layer_id,layer_item.name,assignment.technical_role_id,role_item.name,role_item.sort_order,
		CASE WHEN layer_item.active=1 AND role_item.active=1 THEN 1 ELSE 0 END,COUNT(DISTINCT assignment.vm_id)
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id AND layer_item.category_code='layer'
		JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id AND role_item.category_code='technical_role'
		WHERE assignment.internal_service_id=?
		GROUP BY assignment.layer_id,layer_item.name,layer_item.sort_order,layer_item.active,assignment.technical_role_id,role_item.name,role_item.sort_order,role_item.active
		ORDER BY layer_item.sort_order,layer_item.name,role_item.sort_order,role_item.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.ServiceRoleMapping, 0)
	for rows.Next() {
		var value domain.ServiceRoleMapping
		if err := rows.Scan(&value.ID, &value.LayerID, &value.LayerName, &value.TechnicalRoleID, &value.TechnicalRole, &value.SortOrder, &value.Active, &value.VMCount); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) listAllMappings(ctx context.Context) (map[int64][]domain.ServiceRoleMapping, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.internal_service_id,0,assignment.layer_id,layer_item.name,assignment.technical_role_id,role_item.name,role_item.sort_order,
		CASE WHEN layer_item.active=1 AND role_item.active=1 THEN 1 ELSE 0 END,COUNT(DISTINCT assignment.vm_id)
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id AND layer_item.category_code='layer'
		JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id AND role_item.category_code='technical_role'
		GROUP BY assignment.internal_service_id,assignment.layer_id,layer_item.name,layer_item.sort_order,layer_item.active,assignment.technical_role_id,role_item.name,role_item.sort_order,role_item.active
		ORDER BY assignment.internal_service_id,layer_item.sort_order,layer_item.name,role_item.sort_order,role_item.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make(map[int64][]domain.ServiceRoleMapping)
	for rows.Next() {
		var serviceID int64
		var value domain.ServiceRoleMapping
		if err := rows.Scan(&serviceID, &value.ID, &value.LayerID, &value.LayerName, &value.TechnicalRoleID, &value.TechnicalRole, &value.SortOrder, &value.Active, &value.VMCount); err != nil {
			return nil, err
		}
		out[serviceID] = append(out[serviceID], value)
	}
	return out, rows.Err()
}

func (s Service) ListSolutionTypes(ctx context.Context, serviceID int64) ([]domain.InternalServiceSolutionType, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.solution_type_id,solution_item.name,COUNT(DISTINCT assignment.vm_id),COUNT(*)
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items solution_item ON solution_item.id=assignment.solution_type_id AND solution_item.category_code='solution_type'
		WHERE assignment.internal_service_id=?
		GROUP BY assignment.solution_type_id,solution_item.name,solution_item.sort_order
		ORDER BY solution_item.sort_order,solution_item.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.InternalServiceSolutionType, 0)
	for rows.Next() {
		var value domain.InternalServiceSolutionType
		if err := rows.Scan(&value.SolutionTypeID, &value.SolutionType, &value.VMCount, &value.AssignmentCount); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) listAllSolutionTypes(ctx context.Context) (map[int64][]domain.InternalServiceSolutionType, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.internal_service_id,assignment.solution_type_id,solution_item.name,COUNT(DISTINCT assignment.vm_id),COUNT(*)
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items solution_item ON solution_item.id=assignment.solution_type_id AND solution_item.category_code='solution_type'
		GROUP BY assignment.internal_service_id,assignment.solution_type_id,solution_item.name,solution_item.sort_order
		ORDER BY assignment.internal_service_id,solution_item.sort_order,solution_item.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make(map[int64][]domain.InternalServiceSolutionType)
	for rows.Next() {
		var serviceID int64
		var value domain.InternalServiceSolutionType
		if err := rows.Scan(&serviceID, &value.SolutionTypeID, &value.SolutionType, &value.VMCount, &value.AssignmentCount); err != nil {
			return nil, err
		}
		out[serviceID] = append(out[serviceID], value)
	}
	return out, rows.Err()
}

func (s Service) ListVMs(ctx context.Context, serviceID int64) ([]domain.InternalServiceVM, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.id,vm.id,vm.name,vm.power_state,COALESCE(NULLIF(inventory.hostname,''),vm.guest_hostname),COALESCE(NULLIF(metadata.preferred_ip,''),NULLIF(inventory.primary_ip,''),vm.primary_ip),COALESCE(metadata.environment,''),latest_doc.id,COALESCE(latest_doc.document_number,''),latest_doc.generated_at,assignment.architectural_domain_id,domain_item.name,assignment.itil_category_id,category_item.name,assignment.layer_id,COALESCE(layer_item.name,''),assignment.technical_role_id,COALESCE(role_item.name,''),assignment.solution_type_id,COALESCE(solution_item.name,''),assignment.usage_type,assignment.is_primary,assignment.notes
		FROM vm_internal_service_assignments assignment
		JOIN virtual_machines vm ON vm.id=assignment.vm_id
		LEFT JOIN inventory_snapshots inventory ON inventory.id=vm.current_inventory_id
		LEFT JOIN vm_operational_metadata metadata ON metadata.vm_id=vm.id
		LEFT JOIN generated_documents latest_doc ON latest_doc.id=(SELECT doc.id FROM generated_documents doc WHERE doc.object_type='vm' AND doc.vm_id=vm.id ORDER BY doc.generated_at DESC,doc.id DESC LIMIT 1)
		JOIN nomenclature_items domain_item ON domain_item.id=assignment.architectural_domain_id AND domain_item.category_code='architectural_domain'
		JOIN nomenclature_items category_item ON category_item.id=assignment.itil_category_id AND category_item.category_code='itil_category'
		LEFT JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id
		LEFT JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id
		LEFT JOIN nomenclature_items solution_item ON solution_item.id=assignment.solution_type_id AND solution_item.category_code='solution_type'
		WHERE assignment.internal_service_id=? AND vm.excluded_by_vcenter_pool=0
		ORDER BY domain_item.sort_order,domain_item.name,category_item.sort_order,category_item.name,vm.name,assignment.is_primary DESC,assignment.sort_order,layer_item.name,role_item.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.InternalServiceVM, 0)
	for rows.Next() {
		var value domain.InternalServiceVM
		var layerID, roleID, solutionTypeID, latestDocumentID sql.NullInt64
		var latestDocumentAt sql.NullTime
		if err := rows.Scan(&value.AssignmentID, &value.ID, &value.Name, &value.PowerState, &value.GuestHostname, &value.PrimaryIP, &value.Environment, &latestDocumentID, &value.LatestDocumentNumber, &latestDocumentAt, &value.ArchitecturalDomainID, &value.ArchitecturalDomain, &value.ITILCategoryID, &value.ITILCategory, &layerID, &value.LayerName, &roleID, &value.TechnicalRole, &solutionTypeID, &value.SolutionType, &value.UsageType, &value.Primary, &value.Notes); err != nil {
			return nil, err
		}
		if latestDocumentID.Valid {
			id := latestDocumentID.Int64
			value.LatestDocumentID = &id
		}
		if latestDocumentAt.Valid {
			at := latestDocumentAt.Time
			value.LatestDocumentAt = &at
		}
		if layerID.Valid {
			id := layerID.Int64
			value.LayerID = &id
		}
		if roleID.Valid {
			id := roleID.Int64
			value.TechnicalRoleID = &id
		}
		if solutionTypeID.Valid {
			id := solutionTypeID.Int64
			value.SolutionTypeID = &id
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

type DependencyInput struct {
	TargetServiceID     int64  `json:"target_service_id"`
	DependencyTypeID    int64  `json:"dependency_type_id"`
	SourceEnvironmentID *int64 `json:"source_environment_id,omitempty"`
	TargetEnvironmentID *int64 `json:"target_environment_id,omitempty"`
	Criticality         string `json:"criticality,omitempty"`
	Protocol            string `json:"protocol,omitempty"`
	Port                *int   `json:"port,omitempty"`
	Notes               string `json:"notes"`
	Active              *bool  `json:"active,omitempty"`
}

type DependencyUpdateInput struct {
	Active *bool `json:"active,omitempty"`
}

type VMDependencyInput struct {
	TargetServiceID  int64  `json:"target_service_id"`
	DependencyTypeID int64  `json:"dependency_type_id"`
	Notes            string `json:"notes"`
}

func (s Service) ListDependencies(ctx context.Context, serviceID int64) ([]domain.ServiceDependency, error) {
	return s.listDependenciesQuery(ctx, `SELECT dep.id,dep.source_service_id,source.name,dep.target_service_id,target.name,dep.dependency_type_id,dtype.name,COALESCE(dtype.icon_key,''),
		dep.source_environment_id,COALESCE(source_env.name,''),dep.target_environment_id,COALESCE(target_env.name,''),dep.criticality,dep.protocol,dep.port,dep.notes,dep.active,target.implicit_global,
		(SELECT COUNT(DISTINCT a.vm_id) FROM vm_internal_service_assignments a WHERE a.internal_service_id=target.id),
		COALESCE((SELECT GROUP_CONCAT(DISTINCT vm2.name ORDER BY vm2.name SEPARATOR ', ') FROM vm_internal_service_assignments a2 JOIN virtual_machines vm2 ON vm2.id=a2.vm_id WHERE a2.internal_service_id=target.id),'')
		FROM internal_service_dependencies dep
		JOIN internal_services source ON source.id=dep.source_service_id
		JOIN internal_services target ON target.id=dep.target_service_id
		JOIN nomenclature_items dtype ON dtype.id=dep.dependency_type_id AND dtype.category_code='dependency_type'
		LEFT JOIN nomenclature_items source_env ON source_env.id=dep.source_environment_id AND source_env.category_code='environment'
		LEFT JOIN nomenclature_items target_env ON target_env.id=dep.target_environment_id AND target_env.category_code='environment'
		WHERE dep.source_service_id=? ORDER BY dep.active DESC,target.implicit_global DESC,dtype.sort_order,dtype.name,target.name,source_env.name,target_env.name`, serviceID, false, false)
}

func (s Service) ListDependents(ctx context.Context, serviceID int64) ([]domain.ServiceDependency, error) {
	return s.listDependenciesQuery(ctx, `SELECT dep.id,dep.source_service_id,source.name,dep.target_service_id,target.name,dep.dependency_type_id,dtype.name,COALESCE(dtype.icon_key,''),
		dep.source_environment_id,COALESCE(source_env.name,''),dep.target_environment_id,COALESCE(target_env.name,''),dep.criticality,dep.protocol,dep.port,dep.notes,dep.active,target.implicit_global,
		(SELECT COUNT(DISTINCT a.vm_id) FROM vm_internal_service_assignments a WHERE a.internal_service_id=target.id),
		COALESCE((SELECT GROUP_CONCAT(DISTINCT vm2.name ORDER BY vm2.name SEPARATOR ', ') FROM vm_internal_service_assignments a2 JOIN virtual_machines vm2 ON vm2.id=a2.vm_id WHERE a2.internal_service_id=target.id),'')
		FROM internal_service_dependencies dep
		JOIN internal_services source ON source.id=dep.source_service_id
		JOIN internal_services target ON target.id=dep.target_service_id
		JOIN nomenclature_items dtype ON dtype.id=dep.dependency_type_id AND dtype.category_code='dependency_type'
		LEFT JOIN nomenclature_items source_env ON source_env.id=dep.source_environment_id AND source_env.category_code='environment'
		LEFT JOIN nomenclature_items target_env ON target_env.id=dep.target_environment_id AND target_env.category_code='environment'
		WHERE dep.target_service_id=? ORDER BY dep.active DESC,dtype.sort_order,dtype.name,source.name,source_env.name,target_env.name`, serviceID, false, false)
}

func (s Service) ListDirectVMDependents(ctx context.Context, serviceID int64) ([]domain.VMDependencyImpact, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT direct.vm_id,vm.name,direct.dependency_type_id,dtype.name,direct.notes
		FROM vm_common_service_dependencies direct
		JOIN virtual_machines vm ON vm.id=direct.vm_id
		JOIN nomenclature_items dtype ON dtype.id=direct.dependency_type_id AND dtype.category_code='dependency_type'
		WHERE direct.target_service_id=? AND direct.active=1
		ORDER BY vm.name,dtype.sort_order,dtype.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.VMDependencyImpact, 0)
	for rows.Next() {
		var value domain.VMDependencyImpact
		if err := rows.Scan(&value.VMID, &value.VMName, &value.DependencyTypeID, &value.DependencyType, &value.Notes); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) ListGlobalDependencies(ctx context.Context, serviceID int64) ([]domain.ServiceDependency, error) {
	return s.listDependenciesQuery(ctx, `SELECT 0,?,source.name,target.id,target.name,dtype.id,dtype.name,COALESCE(dtype.icon_key,''),
		NULL,'',NULL,'','normal','',NULL,'',1,target.implicit_global,
		(SELECT COUNT(DISTINCT a.vm_id) FROM vm_internal_service_assignments a WHERE a.internal_service_id=target.id),
		COALESCE((SELECT GROUP_CONCAT(DISTINCT vm2.name ORDER BY vm2.name SEPARATOR ', ') FROM vm_internal_service_assignments a2 JOIN virtual_machines vm2 ON vm2.id=a2.vm_id WHERE a2.internal_service_id=target.id),'')
		FROM internal_services target
		JOIN nomenclature_items dtype ON dtype.id=target.common_dependency_type_id AND dtype.category_code='dependency_type' AND dtype.active=1
		JOIN internal_services source ON source.id=?
		WHERE target.active=1 AND target.is_common=1 AND target.implicit_global=1 AND target.id<>?
		AND NOT EXISTS (SELECT 1 FROM internal_service_dependencies dep WHERE dep.source_service_id=? AND dep.target_service_id=target.id AND dep.active=1)
		ORDER BY target.name`, serviceID, true, false, serviceID, serviceID, serviceID, serviceID)
}

func (s Service) listDependenciesQuery(ctx context.Context, query string, sourceServiceID int64, inherited, direct bool, args ...any) ([]domain.ServiceDependency, error) {
	if len(args) == 0 {
		args = []any{sourceServiceID}
	}
	rows, err := s.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.ServiceDependency, 0)
	for rows.Next() {
		var value domain.ServiceDependency
		var sourceEnvironmentID, targetEnvironmentID, port sql.NullInt64
		if err := rows.Scan(&value.ID, &value.SourceServiceID, &value.SourceServiceName, &value.TargetServiceID, &value.TargetServiceName, &value.DependencyTypeID, &value.DependencyType, &value.DependencyTypeIcon,
			&sourceEnvironmentID, &value.SourceEnvironment, &targetEnvironmentID, &value.TargetEnvironment, &value.Criticality, &value.Protocol, &port, &value.Notes, &value.Active, &value.Global, &value.TargetVMCount, &value.TargetVMNames); err != nil {
			return nil, err
		}
		if sourceEnvironmentID.Valid {
			id := sourceEnvironmentID.Int64
			value.SourceEnvironmentID = &id
		}
		if targetEnvironmentID.Valid {
			id := targetEnvironmentID.Int64
			value.TargetEnvironmentID = &id
		}
		if port.Valid {
			p := int(port.Int64)
			value.Port = &p
		}
		value.Inherited = inherited
		value.Direct = direct
		out = append(out, value)
	}
	return out, rows.Err()
}

func normalizeDependencyInput(input *DependencyInput) error {
	input.Notes = strings.TrimSpace(input.Notes)
	input.Criticality = strings.ToLower(strings.TrimSpace(input.Criticality))
	input.Protocol = strings.TrimSpace(input.Protocol)
	if input.Criticality == "" {
		input.Criticality = "normal"
	}
	if input.Criticality != "informational" && input.Criticality != "normal" && input.Criticality != "critical" {
		return errors.New("dependency criticality must be informational, normal or critical")
	}
	if len([]rune(input.Notes)) > 1000 {
		return errors.New("dependency notes are too long")
	}
	if len([]rune(input.Protocol)) > 64 {
		return errors.New("dependency protocol is too long")
	}
	if input.Port != nil && (*input.Port < 1 || *input.Port > 65535) {
		return errors.New("dependency port must be between 1 and 65535")
	}
	if input.SourceEnvironmentID != nil && *input.SourceEnvironmentID <= 0 {
		input.SourceEnvironmentID = nil
	}
	if input.TargetEnvironmentID != nil && *input.TargetEnvironmentID <= 0 {
		input.TargetEnvironmentID = nil
	}
	return nil
}

func (s Service) validateDependencyEnvironment(ctx context.Context, id *int64) error {
	if id == nil {
		return nil
	}
	var count int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM nomenclature_items WHERE id=? AND category_code='environment' AND active=1`, *id).Scan(&count); err != nil {
		return err
	}
	if count == 0 {
		return errors.New("dependency environment must reference an active environment item")
	}
	return nil
}

func (s Service) AddDependency(ctx context.Context, sourceServiceID, userID int64, input DependencyInput) (domain.ServiceDependency, error) {
	if err := normalizeDependencyInput(&input); err != nil {
		return domain.ServiceDependency{}, err
	}
	if sourceServiceID <= 0 || input.TargetServiceID <= 0 || input.DependencyTypeID <= 0 {
		return domain.ServiceDependency{}, errors.New("source_service_id, target_service_id and dependency_type_id are required")
	}
	if sourceServiceID == input.TargetServiceID {
		return domain.ServiceDependency{}, errors.New("a service cannot depend on itself")
	}
	if err := s.validateDependencyEnvironment(ctx, input.SourceEnvironmentID); err != nil {
		return domain.ServiceDependency{}, err
	}
	if err := s.validateDependencyEnvironment(ctx, input.TargetEnvironmentID); err != nil {
		return domain.ServiceDependency{}, err
	}
	var validCount int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM internal_services target JOIN nomenclature_items dtype ON dtype.id=? AND dtype.category_code='dependency_type' AND dtype.active=1 WHERE target.id=? AND target.active=1`, input.DependencyTypeID, input.TargetServiceID).Scan(&validCount); err != nil {
		return domain.ServiceDependency{}, err
	}
	if validCount == 0 {
		return domain.ServiceDependency{}, errors.New("target service must be active and dependency type must be valid")
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	// Each row represents one concrete integration flow. Do not upsert by
	// service/type/environment: the same pair of services may legitimately use
	// the same relationship type more than once (different ports, protocols,
	// endpoints or purposes).
	result, err := s.DB.ExecContext(ctx, `INSERT INTO internal_service_dependencies(source_service_id,target_service_id,dependency_type_id,source_environment_id,target_environment_id,criticality,protocol,port,notes,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, sourceServiceID, input.TargetServiceID, input.DependencyTypeID, nullableInt64Ptr(input.SourceEnvironmentID), nullableInt64Ptr(input.TargetEnvironmentID), input.Criticality, input.Protocol, nullableIntPtr(input.Port), input.Notes, active, userID, userID)
	if err != nil {
		return domain.ServiceDependency{}, err
	}
	dependencyID, err := result.LastInsertId()
	if err != nil {
		return domain.ServiceDependency{}, err
	}
	values, err := s.ListDependencies(ctx, sourceServiceID)
	if err != nil {
		return domain.ServiceDependency{}, err
	}
	for _, value := range values {
		if value.ID == dependencyID {
			return value, nil
		}
	}
	return domain.ServiceDependency{}, sql.ErrNoRows
}

func (s Service) UpdateDependency(ctx context.Context, sourceServiceID, dependencyID, userID int64, input DependencyUpdateInput) (domain.ServiceDependency, error) {
	if sourceServiceID <= 0 || dependencyID <= 0 {
		return domain.ServiceDependency{}, errors.New("invalid dependency id")
	}
	if input.Active == nil {
		return domain.ServiceDependency{}, errors.New("active is required")
	}
	result, err := s.DB.ExecContext(ctx, `UPDATE internal_service_dependencies SET active=?,updated_by=? WHERE id=? AND source_service_id=?`, *input.Active, userID, dependencyID, sourceServiceID)
	if err != nil {
		return domain.ServiceDependency{}, err
	}
	count, _ := result.RowsAffected()
	if count == 0 {
		var exists int
		if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM internal_service_dependencies WHERE id=? AND source_service_id=?`, dependencyID, sourceServiceID).Scan(&exists); err != nil {
			return domain.ServiceDependency{}, err
		}
		if exists == 0 {
			return domain.ServiceDependency{}, sql.ErrNoRows
		}
	}
	values, err := s.ListDependencies(ctx, sourceServiceID)
	if err != nil {
		return domain.ServiceDependency{}, err
	}
	for _, value := range values {
		if value.ID == dependencyID {
			return value, nil
		}
	}
	return domain.ServiceDependency{}, sql.ErrNoRows
}

func (s Service) DeleteDependency(ctx context.Context, sourceServiceID, dependencyID int64) error {
	result, err := s.DB.ExecContext(ctx, `DELETE FROM internal_service_dependencies WHERE id=? AND source_service_id=?`, dependencyID, sourceServiceID)
	if err != nil {
		return err
	}
	count, _ := result.RowsAffected()
	if count == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) ListVMDependencies(ctx context.Context, vmID int64) ([]domain.ServiceDependency, error) {
	if vmID <= 0 {
		return nil, errors.New("invalid vm id")
	}

	// Keep the three dependency sources as separate queries. 0.9.0 used one
	// UNION ALL here; MariaDB may coerce UNION columns differently when the
	// direct-VM branch starts returning rows. Reading each source independently
	// avoids that type-coercion edge case and also makes failures attributable to
	// one source instead of making the whole VM detail opaque.
	queries := []struct {
		query string
		args  []any
	}{
		{
			query: `SELECT dep.id,dep.source_service_id,source.name,dep.target_service_id,target.name,dep.dependency_type_id,dtype.name,COALESCE(dtype.icon_key,''),dep.source_environment_id,COALESCE(source_env.name,''),dep.target_environment_id,COALESCE(target_env.name,''),dep.criticality,dep.protocol,dep.port,dep.notes,target.implicit_global,
				(SELECT COUNT(DISTINCT a2.vm_id) FROM vm_internal_service_assignments a2 WHERE a2.internal_service_id=target.id),
				COALESCE((SELECT GROUP_CONCAT(DISTINCT vm3.name ORDER BY vm3.name SEPARATOR ', ') FROM vm_internal_service_assignments a3 JOIN virtual_machines vm3 ON vm3.id=a3.vm_id WHERE a3.internal_service_id=target.id),''),
				0,1,source.name
				FROM vm_internal_service_assignments assignment
				JOIN internal_service_dependencies dep ON dep.source_service_id=assignment.internal_service_id AND dep.active=1
				JOIN internal_services source ON source.id=dep.source_service_id
				JOIN internal_services target ON target.id=dep.target_service_id AND target.active=1 AND target.is_common=1
				JOIN nomenclature_items dtype ON dtype.id=dep.dependency_type_id AND dtype.category_code='dependency_type'
				LEFT JOIN nomenclature_items source_env ON source_env.id=dep.source_environment_id AND source_env.category_code='environment'
				LEFT JOIN nomenclature_items target_env ON target_env.id=dep.target_environment_id AND target_env.category_code='environment'
				WHERE assignment.vm_id=?`,
			args: []any{vmID},
		},
		{
			query: `SELECT 0,assignment.internal_service_id,source.name,target.id,target.name,dtype.id,dtype.name,COALESCE(dtype.icon_key,''),NULL,'',NULL,'','normal','',NULL,'',1,
				(SELECT COUNT(DISTINCT a2.vm_id) FROM vm_internal_service_assignments a2 WHERE a2.internal_service_id=target.id),
				COALESCE((SELECT GROUP_CONCAT(DISTINCT vm3.name ORDER BY vm3.name SEPARATOR ', ') FROM vm_internal_service_assignments a3 JOIN virtual_machines vm3 ON vm3.id=a3.vm_id WHERE a3.internal_service_id=target.id),''),
				0,1,'Global'
				FROM vm_internal_service_assignments assignment
				JOIN internal_services source ON source.id=assignment.internal_service_id
				JOIN internal_services target ON target.is_common=1 AND target.implicit_global=1 AND target.active=1 AND target.id<>assignment.internal_service_id
				JOIN nomenclature_items dtype ON dtype.id=target.common_dependency_type_id AND dtype.category_code='dependency_type' AND dtype.active=1
				WHERE assignment.vm_id=? AND NOT EXISTS (
					SELECT 1 FROM internal_service_dependencies dep
					WHERE dep.source_service_id=assignment.internal_service_id AND dep.target_service_id=target.id AND dep.active=1
				)`,
			args: []any{vmID},
		},
		{
			query: `SELECT direct.id,0,'',direct.target_service_id,target.name,direct.dependency_type_id,dtype.name,COALESCE(dtype.icon_key,''),NULL,'',NULL,'','normal','',NULL,direct.notes,target.implicit_global,
				(SELECT COUNT(DISTINCT a2.vm_id) FROM vm_internal_service_assignments a2 WHERE a2.internal_service_id=target.id),
				COALESCE((SELECT GROUP_CONCAT(DISTINCT vm3.name ORDER BY vm3.name SEPARATOR ', ') FROM vm_internal_service_assignments a3 JOIN virtual_machines vm3 ON vm3.id=a3.vm_id WHERE a3.internal_service_id=target.id),''),
				1,0,'Direct VM'
				FROM vm_common_service_dependencies direct
				JOIN internal_services target ON target.id=direct.target_service_id AND target.active=1 AND target.is_common=1
				JOIN nomenclature_items dtype ON dtype.id=direct.dependency_type_id AND dtype.category_code='dependency_type'
				WHERE direct.vm_id=? AND direct.active=1`,
			args: []any{vmID},
		},
	}

	out := make([]domain.ServiceDependency, 0)
	indexes := make(map[string]int)
	for _, item := range queries {
		values, err := s.listVMDependencyRows(ctx, item.query, item.args...)
		if err != nil {
			return nil, err
		}
		for _, value := range values {
			key := vmDependencyMergeKey(value)
			if index, ok := indexes[key]; ok {
				existing := &out[index]
				existing.SourceLabel = mergeDependencyLabels(existing.SourceLabel, value.SourceLabel)
				existing.Global = existing.Global || value.Global
				existing.Inherited = existing.Inherited || value.Inherited
				if value.Direct {
					existing.Direct = true
					existing.ID = value.ID
					if value.Notes != "" {
						existing.Notes = value.Notes
					}
				}
				continue
			}
			indexes[key] = len(out)
			out = append(out, value)
		}
	}

	sort.SliceStable(out, func(i, j int) bool {
		if out[i].Global != out[j].Global {
			return out[i].Global
		}
		if out[i].TargetServiceName != out[j].TargetServiceName {
			return strings.ToLower(out[i].TargetServiceName) < strings.ToLower(out[j].TargetServiceName)
		}
		return strings.ToLower(out[i].DependencyType) < strings.ToLower(out[j].DependencyType)
	})
	return out, nil
}

func vmDependencyMergeKey(value domain.ServiceDependency) string {
	// Explicit service dependencies are concrete flows and must remain separate,
	// even when target/type/environment are identical. The same row can be seen
	// more than once through VM assignments, so use its database id as identity.
	if value.ID > 0 && !value.Direct {
		return "service:" + fmtInt64(value.ID)
	}
	if value.Direct {
		return strings.Join([]string{"direct", fmtInt64(value.TargetServiceID), fmtInt64(value.DependencyTypeID)}, ":")
	}
	return strings.Join([]string{"global", fmtInt64(value.TargetServiceID), fmtInt64(value.DependencyTypeID)}, ":")
}

func (s Service) listVMDependencyRows(ctx context.Context, query string, args ...any) ([]domain.ServiceDependency, error) {
	rows, err := s.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	out := make([]domain.ServiceDependency, 0)
	for rows.Next() {
		var value domain.ServiceDependency
		var sourceEnvironmentID, targetEnvironmentID, port sql.NullInt64
		if err := rows.Scan(&value.ID, &value.SourceServiceID, &value.SourceServiceName, &value.TargetServiceID, &value.TargetServiceName, &value.DependencyTypeID, &value.DependencyType, &value.DependencyTypeIcon,
			&sourceEnvironmentID, &value.SourceEnvironment, &targetEnvironmentID, &value.TargetEnvironment, &value.Criticality, &value.Protocol, &port, &value.Notes,
			&value.Global, &value.TargetVMCount, &value.TargetVMNames, &value.Direct, &value.Inherited, &value.SourceLabel); err != nil {
			return nil, err
		}
		if sourceEnvironmentID.Valid {
			id := sourceEnvironmentID.Int64
			value.SourceEnvironmentID = &id
		}
		if targetEnvironmentID.Valid {
			id := targetEnvironmentID.Int64
			value.TargetEnvironmentID = &id
		}
		if port.Valid {
			p := int(port.Int64)
			value.Port = &p
		}
		value.Active = true
		out = append(out, value)
	}
	return out, rows.Err()
}

func mergeDependencyLabels(left, right string) string {
	left = strings.TrimSpace(left)
	right = strings.TrimSpace(right)
	if left == "" {
		return right
	}
	if right == "" || left == right {
		return left
	}
	for _, part := range strings.Split(left, ", ") {
		if part == right {
			return left
		}
	}
	return left + ", " + right
}

func (s Service) AddVMDependency(ctx context.Context, vmID, userID int64, input VMDependencyInput) (domain.ServiceDependency, error) {
	var retired bool
	if err := s.DB.QueryRowContext(ctx, `SELECT retired FROM virtual_machines WHERE id=?`, vmID).Scan(&retired); err != nil {
		return domain.ServiceDependency{}, err
	}
	if retired {
		return domain.ServiceDependency{}, errors.New("VM retrasă: nu se pot crea dependențe active către servicii")
	}

	input.Notes = strings.TrimSpace(input.Notes)
	if vmID <= 0 || input.TargetServiceID <= 0 || input.DependencyTypeID <= 0 {
		return domain.ServiceDependency{}, errors.New("vm_id, target_service_id and dependency_type_id are required")
	}
	if len([]rune(input.Notes)) > 1000 {
		return domain.ServiceDependency{}, errors.New("dependency notes are too long")
	}
	var commonCount int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM internal_services target JOIN nomenclature_items dtype ON dtype.id=? AND dtype.category_code='dependency_type' AND dtype.active=1 WHERE target.id=? AND target.active=1 AND target.is_common=1`, input.DependencyTypeID, input.TargetServiceID).Scan(&commonCount); err != nil {
		return domain.ServiceDependency{}, err
	}
	if commonCount == 0 {
		return domain.ServiceDependency{}, errors.New("target service must be an active common service and dependency type must be valid")
	}
	_, err := s.DB.ExecContext(ctx, `INSERT INTO vm_common_service_dependencies(vm_id,target_service_id,dependency_type_id,notes,active,created_by,updated_by) VALUES(?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE notes=VALUES(notes),active=1,updated_by=VALUES(updated_by)`, vmID, input.TargetServiceID, input.DependencyTypeID, input.Notes, userID, userID)
	if err != nil {
		return domain.ServiceDependency{}, err
	}
	values, err := s.ListVMDependencies(ctx, vmID)
	if err != nil {
		return domain.ServiceDependency{}, err
	}
	for _, value := range values {
		if value.Direct && value.TargetServiceID == input.TargetServiceID && value.DependencyTypeID == input.DependencyTypeID {
			return value, nil
		}
	}
	return domain.ServiceDependency{}, sql.ErrNoRows
}

func (s Service) DeleteVMDependency(ctx context.Context, vmID, dependencyID int64) error {
	result, err := s.DB.ExecContext(ctx, `DELETE FROM vm_common_service_dependencies WHERE id=? AND vm_id=?`, dependencyID, vmID)
	if err != nil {
		return err
	}
	count, _ := result.RowsAffected()
	if count == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func fmtInt64(value int64) string {
	return fmt.Sprintf("%d", value)
}

func (s Service) defaultCategoryID(ctx context.Context) (int64, error) {
	var id int64
	err := s.DB.QueryRowContext(ctx, `SELECT id FROM nomenclature_items WHERE category_code='itil_category' AND name='Necategorizat' ORDER BY id LIMIT 1`).Scan(&id)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, errors.New("missing uncategorized service category")
	}
	return id, err
}

func serviceSelect() string {
	return `SELECT service.id,service.itil_category_id,COALESCE(legacy_category.name,''),service.name,service.service_code,service.short_description,service.description,service.description_richtext,service.purpose,service.purpose_richtext,service.objectives,service.objectives_richtext,service.authentication,service.service_url,service.technologies,service.criticality,service.documentation_status,service.documentation_url,service.vault_url,service.active,service.retired,service.retirement_reason_id,COALESCE(retirement_reason.name,''),service.retired_at,service.outline_documentation_disabled,service.is_common,service.implicit_global,service.common_dependency_type_id,COALESCE(common_dtype.name,''),
		(SELECT COUNT(*) FROM internal_service_dependencies dep WHERE dep.source_service_id=service.id AND dep.active=1),
		CASE WHEN service.implicit_global=1 THEN GREATEST((SELECT COUNT(*) FROM internal_services other WHERE other.active=1)-1,0) ELSE (SELECT COUNT(DISTINCT dep.source_service_id) FROM internal_service_dependencies dep WHERE dep.target_service_id=service.id AND dep.active=1) END,
		(SELECT COUNT(DISTINCT assignment.vm_id) FROM vm_internal_service_assignments assignment WHERE assignment.internal_service_id=service.id),
		(SELECT COUNT(DISTINCT assignment.architectural_domain_id,assignment.itil_category_id) FROM vm_internal_service_assignments assignment WHERE assignment.internal_service_id=service.id),
		(SELECT COUNT(DISTINCT assignment.layer_id,assignment.technical_role_id) FROM vm_internal_service_assignments assignment WHERE assignment.internal_service_id=service.id AND assignment.layer_id IS NOT NULL AND assignment.technical_role_id IS NOT NULL),
		(SELECT COUNT(DISTINCT assignment.solution_type_id) FROM vm_internal_service_assignments assignment WHERE assignment.internal_service_id=service.id AND assignment.solution_type_id IS NOT NULL),
		service.created_at,service.updated_at
		FROM internal_services service
		LEFT JOIN nomenclature_items legacy_category ON legacy_category.id=service.itil_category_id
		LEFT JOIN nomenclature_items common_dtype ON common_dtype.id=service.common_dependency_type_id AND common_dtype.category_code='dependency_type'
		LEFT JOIN nomenclature_items retirement_reason ON retirement_reason.id=service.retirement_reason_id AND retirement_reason.category_code='service_retirement_reason'`
}

type rowScanner interface{ Scan(dest ...any) error }

func scanService(row rowScanner) (domain.InternalService, error) {
	var value domain.InternalService
	var serviceCode, descriptionRichText, purposeRichText, objectivesRichText sql.NullString
	var commonDependencyTypeID, retirementReasonID sql.NullInt64
	var retiredAt sql.NullTime
	err := row.Scan(&value.ID, &value.ITILCategoryID, &value.ITILCategory, &value.Name, &serviceCode, &value.ShortDescription, &value.Description, &descriptionRichText, &value.Purpose, &purposeRichText, &value.Objectives, &objectivesRichText, &value.Authentication, &value.ServiceURL, &value.Technologies, &value.Criticality, &value.DocumentationStatus, &value.DocumentationURL, &value.VaultURL, &value.Active, &value.Retired, &retirementReasonID, &value.RetirementReason, &retiredAt, &value.OutlineDocumentationDisabled, &value.IsCommon, &value.ImplicitGlobal, &commonDependencyTypeID, &value.CommonDependencyType, &value.DependencyCount, &value.DependentServiceCount, &value.VMCount, &value.ClassificationCount, &value.RoleMappingCount, &value.SolutionTypeCount, &value.CreatedAt, &value.UpdatedAt)
	if serviceCode.Valid {
		value.ServiceCode = serviceCode.String
	}
	if commonDependencyTypeID.Valid {
		id := commonDependencyTypeID.Int64
		value.CommonDependencyTypeID = &id
	}
	if retirementReasonID.Valid {
		id := retirementReasonID.Int64
		value.RetirementReasonID = &id
	}
	if retiredAt.Valid {
		value.RetiredAt = &retiredAt.Time
	}
	if err == nil {
		value.DescriptionRichText = richtext.Decode(nullStringValue(descriptionRichText), value.Description)
		value.PurposeRichText = richtext.Decode(nullStringValue(purposeRichText), value.Purpose)
		value.ObjectivesRichText = richtext.Decode(nullStringValue(objectivesRichText), value.Objectives)
	}
	return value, err
}

func applyClassificationCompatibility(value *domain.InternalService) {
	value.ArchitecturalDomainID = nil
	value.ArchitecturalDomain = ""
	value.ITILCategoryID = 0
	value.ITILCategory = ""
	if len(value.Classifications) != 1 {
		return
	}
	classification := value.Classifications[0]
	domainID := classification.ArchitecturalDomainID
	value.ArchitecturalDomainID = &domainID
	value.ArchitecturalDomain = classification.ArchitecturalDomain
	value.ITILCategoryID = classification.ITILCategoryID
	value.ITILCategory = classification.ITILCategory
}

func firstClassificationNames(values []domain.InternalServiceClassification) (string, string) {
	if len(values) == 0 {
		return "", ""
	}
	return strings.ToLower(values[0].ArchitecturalDomain), strings.ToLower(values[0].ITILCategory)
}

func normalizeService(input *InternalServiceInput) error {
	input.Name = strings.TrimSpace(input.Name)
	input.ServiceCode = strings.ToLower(strings.TrimSpace(input.ServiceCode))
	input.ShortDescription = strings.TrimSpace(input.ShortDescription)
	input.Description = strings.TrimSpace(input.Description)
	input.Purpose = strings.TrimSpace(input.Purpose)
	input.Objectives = strings.TrimSpace(input.Objectives)
	var err error
	if input.DescriptionRichText == nil {
		input.DescriptionRichText = richtext.FromPlain(input.Description)
	} else {
		input.DescriptionRichText, err = richtext.Normalize(input.DescriptionRichText)
		if err != nil {
			return errors.New("invalid description_richtext: " + err.Error())
		}
	}
	if input.PurposeRichText == nil {
		input.PurposeRichText = richtext.FromPlain(input.Purpose)
	} else {
		input.PurposeRichText, err = richtext.Normalize(input.PurposeRichText)
		if err != nil {
			return errors.New("invalid purpose_richtext: " + err.Error())
		}
	}
	if input.ObjectivesRichText == nil {
		input.ObjectivesRichText = richtext.FromPlain(input.Objectives)
	} else {
		input.ObjectivesRichText, err = richtext.Normalize(input.ObjectivesRichText)
		if err != nil {
			return errors.New("invalid objectives_richtext: " + err.Error())
		}
	}
	input.Description = richtext.PlainText(input.DescriptionRichText)
	input.Purpose = richtext.PlainText(input.PurposeRichText)
	input.Objectives = richtext.PlainText(input.ObjectivesRichText)
	input.Criticality = strings.ToLower(strings.TrimSpace(input.Criticality))
	input.DocumentationStatus = strings.ToLower(strings.TrimSpace(input.DocumentationStatus))
	input.Authentication = strings.TrimSpace(input.Authentication)
	input.ServiceURL = strings.TrimSpace(input.ServiceURL)
	input.Technologies = strings.TrimSpace(input.Technologies)
	input.DocumentationURL = strings.TrimSpace(input.DocumentationURL)
	if input.VaultURL != nil {
		value := strings.TrimSpace(*input.VaultURL)
		input.VaultURL = &value
	}
	input.RetiredAt = strings.TrimSpace(input.RetiredAt)
	if input.RetiredAt != "" {
		if _, err := time.Parse("2006-01-02", input.RetiredAt); err != nil {
			return errors.New("retired_at must use YYYY-MM-DD")
		}
	}
	if input.Name == "" {
		return errors.New("name is required")
	}
	if input.IsCommon != nil && *input.IsCommon && (input.CommonDependencyTypeID == nil || *input.CommonDependencyTypeID <= 0) {
		return errors.New("common_dependency_type_id is required for a common service")
	}
	if input.ImplicitGlobal != nil && *input.ImplicitGlobal && (input.IsCommon == nil || !*input.IsCommon) {
		return errors.New("an implicit global service must also be common")
	}
	if input.Criticality == "" {
		input.Criticality = "normal"
	}
	if input.DocumentationStatus == "" {
		input.DocumentationStatus = "draft"
	}
	if !criticalities[input.Criticality] {
		return errors.New("invalid criticality")
	}
	if !documentationStatuses[input.DocumentationStatus] {
		return errors.New("invalid documentation_status")
	}
	if input.ServiceCode != "" && !codePattern.MatchString(input.ServiceCode) {
		return errors.New("service_code is invalid")
	}
	if len([]rune(input.Name)) > 255 || len([]rune(input.ServiceCode)) > 128 || len([]rune(input.ShortDescription)) > 2000 || len([]rune(input.Description)) > 10000 || len([]rune(input.Purpose)) > 10000 || len([]rune(input.Objectives)) > 10000 || len([]rune(input.Authentication)) > 4000 || len([]rune(input.ServiceURL)) > 2048 || len([]rune(input.Technologies)) > 10000 || len([]rune(input.DocumentationURL)) > 1024 || (input.VaultURL != nil && len([]rune(*input.VaultURL)) > 2048) {
		return errors.New("internal service values must not exceed the allowed length")
	}
	if input.ServiceURL != "" {
		parsed, err := url.ParseRequestURI(input.ServiceURL)
		if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
			return errors.New("service_url must be an absolute HTTP or HTTPS URL")
		}
	}
	if input.DocumentationURL != "" {
		parsed, err := url.ParseRequestURI(input.DocumentationURL)
		if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
			return errors.New("documentation_url must be an absolute HTTP or HTTPS URL")
		}
	}
	if input.VaultURL != nil && *input.VaultURL != "" {
		parsed, err := url.ParseRequestURI(*input.VaultURL)
		if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
			return errors.New("vault_url must be an absolute HTTP or HTTPS URL")
		}
	}
	return nil
}

func (s Service) validateLifecycleInput(ctx context.Context, input InternalServiceInput) error {
	if input.Retired == nil || !*input.Retired || input.RetirementReasonID == nil {
		return nil
	}
	if *input.RetirementReasonID <= 0 {
		return errors.New("retirement_reason_id must be positive")
	}
	var count int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM nomenclature_items WHERE id=? AND category_code='service_retirement_reason' AND active=1`, *input.RetirementReasonID).Scan(&count); err != nil {
		return err
	}
	if count == 0 {
		return errors.New("retirement_reason_id must reference an active service_retirement_reason item")
	}
	return nil
}

func nullableDate(value string) any {
	value = strings.TrimSpace(value)
	if value == "" {
		return nil
	}
	return value
}

func (s Service) validateCommonServiceInput(ctx context.Context, input InternalServiceInput) error {
	if input.IsCommon == nil || !*input.IsCommon {
		return nil
	}
	if input.CommonDependencyTypeID == nil || *input.CommonDependencyTypeID <= 0 {
		return errors.New("common_dependency_type_id is required for a common service")
	}
	var count int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM nomenclature_items WHERE id=? AND category_code='dependency_type' AND active=1`, *input.CommonDependencyTypeID).Scan(&count); err != nil {
		return err
	}
	if count == 0 {
		return errors.New("common_dependency_type_id must reference an active dependency_type item")
	}
	return nil
}

func (s Service) ensureCanDisableCommon(ctx context.Context, serviceID int64) error {
	var references int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM vm_common_service_dependencies WHERE target_service_id=? AND active=1`, serviceID).Scan(&references); err != nil {
		return err
	}
	if references > 0 {
		return errors.New("remove direct VM dependencies before disabling common service")
	}
	return nil
}

func nullableInt64Ptr(value *int64) any {
	if value == nil || *value <= 0 {
		return nil
	}
	return *value
}

func nullableIntPtr(value *int) any {
	if value == nil || *value <= 0 {
		return nil
	}
	return *value
}

func nullableStringPtr(value *string) any {
	if value == nil {
		return ""
	}
	return strings.TrimSpace(*value)
}

func nullableCode(value string) any {
	if value == "" {
		return nil
	}
	return value
}

func nullableRichText(value string) any {
	if strings.TrimSpace(value) == "" {
		return nil
	}
	return value
}

func nullStringValue(value sql.NullString) string {
	if !value.Valid {
		return ""
	}
	return value.String
}
