# VM-DOC Server 0.22.6 — Arhivare Outline și servicii active

Bază: 0.22.5. Agent 1.7.18 neschimbat. **Migrare MariaDB 088** aditivă.

1. Documente → Configurare Outline: `Arhivă VM · Document / URL` (document părinte existent, distinct de Virtualizare).
2. Retrage VM: pentru PROD eligibil, publică ultima fișă la părintele Arhivă VM, păstrând document ID și link; apoi salvează statusul Retras, copiază complet asocierile VM–servicii în `vm_retirement_service_assignments`, le păstrează și în `lifecycle_archive_relations` (numele) și le elimină din tabela asocierilor active (și dezactivează dependențele directe către serviciile comune), toate în aceeași tranzacție.
3. Pentru VM-urile retrase deja în 0.22.5, `Arhivează` mută documentul Outline existent (dacă există) și desprinde asocierile încă active. Arhivarea înregistrează aprobatorul, data și retenția; nu șterge inventarul/documentele.
4. Reactivarea **nu reasociază automat** serviciile istorice: administratorul verifică și reconstruiește doar relațiile încă valide.
5. Catalogul activ al unui serviciu omite resursele Docker/DB/Web ale VM-urilor retrase, fără a modifica inventarele istorice și asocierile acelor resurse. Pagina Outline a serviciului nu este republicată automat: se revalidează/republică serviciile afectate manual, conform politicii PROD.

Dacă Outline PROD nu are părintele Arhivă configurat, retragerea eșuează înainte de tranzacția SQL. Dacă DB eșuează după publicarea/mutarea Outline, operatorul verifică starea și reia; aceeași mapare este reutilizată. Rollback pentru MariaDB: migrarea 088 conține snapshoturi, nu trebuie eliminată la downgrade.

Limite validare: fără server Outline și MariaDB real în această sesiune; compilare cu vendor necesară în staging.

**Moștenire configurație:** sincronizarea din surse HA nu reintroduce asocieri sau observații operaționale pe VM-uri retrase; dependențele explicite VM→serviciu comun sunt dezactivate, nu șterse.
