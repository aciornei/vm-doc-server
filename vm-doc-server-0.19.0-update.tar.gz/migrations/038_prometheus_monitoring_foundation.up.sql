-- 0.19.0: fundația de monitorizare Prometheus / Blackbox.

CREATE TABLE IF NOT EXISTS prometheus_sources (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  secret_ref VARCHAR(96) NOT NULL,
  name VARCHAR(255) NOT NULL,
  base_url VARCHAR(1024) NOT NULL,
  source_type VARCHAR(24) NOT NULL DEFAULT 'metrics',
  username VARCHAR(255) NOT NULL DEFAULT '',
  auth_mode VARCHAR(24) NOT NULL DEFAULT 'none',
  secret_ciphertext TEXT NOT NULL,
  vm_label VARCHAR(128) NOT NULL DEFAULT 'vm_fqdn',
  target_label VARCHAR(128) NOT NULL DEFAULT 'instance',
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  verify_tls TINYINT(1) NOT NULL DEFAULT 1,
  tls_server_name VARCHAR(255) NOT NULL DEFAULT '',
  sync_interval_minutes INT UNSIGNED NOT NULL DEFAULT 15,
  last_sync_at DATETIME(6) NULL,
  last_success_at DATETIME(6) NULL,
  last_error TEXT NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_prometheus_sources_secret_ref (secret_ref),
  UNIQUE KEY uq_prometheus_sources_name (name),
  CONSTRAINT fk_prometheus_sources_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_prometheus_sources_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS prometheus_sync_runs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  prometheus_source_id BIGINT UNSIGNED NOT NULL,
  source VARCHAR(24) NOT NULL DEFAULT 'manual',
  status VARCHAR(24) NOT NULL DEFAULT 'queued',
  requested_by_user_id BIGINT UNSIGNED NULL,
  started_at DATETIME(6) NULL,
  finished_at DATETIME(6) NULL,
  target_count INT UNSIGNED NOT NULL DEFAULT 0,
  matched_vm_count INT UNSIGNED NOT NULL DEFAULT 0,
  up_count INT UNSIGNED NOT NULL DEFAULT 0,
  down_count INT UNSIGNED NOT NULL DEFAULT 0,
  unmatched_count INT UNSIGNED NOT NULL DEFAULT 0,
  ambiguous_count INT UNSIGNED NOT NULL DEFAULT 0,
  error_message TEXT NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  KEY idx_prometheus_sync_runs_source_created (prometheus_source_id, created_at DESC),
  KEY idx_prometheus_sync_runs_status (status, created_at DESC),
  CONSTRAINT fk_prometheus_sync_runs_source FOREIGN KEY (prometheus_source_id) REFERENCES prometheus_sources(id) ON DELETE CASCADE,
  CONSTRAINT fk_prometheus_sync_runs_requested_by FOREIGN KEY (requested_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS monitoring_targets (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  prometheus_source_id BIGINT UNSIGNED NOT NULL,
  fingerprint CHAR(64) NOT NULL,
  source_type VARCHAR(24) NOT NULL DEFAULT 'metrics',
  job_name VARCHAR(255) NOT NULL DEFAULT '',
  instance_value VARCHAR(1024) NOT NULL DEFAULT '',
  scrape_url VARCHAR(2048) NOT NULL DEFAULT '',
  target_url VARCHAR(2048) NOT NULL DEFAULT '',
  health VARCHAR(32) NOT NULL DEFAULT '',
  last_error TEXT NOT NULL,
  last_scrape_at DATETIME(6) NULL,
  scrape_duration_seconds DOUBLE NULL,
  probe_success TINYINT(1) NULL,
  http_status_code INT NULL,
  probe_duration_seconds DOUBLE NULL,
  tls_expiry_at DATETIME(6) NULL,
  labels_json LONGTEXT NULL,
  discovered_labels_json LONGTEXT NULL,
  matched_vm_id BIGINT UNSIGNED NULL,
  match_method VARCHAR(32) NOT NULL DEFAULT '',
  match_value VARCHAR(1024) NOT NULL DEFAULT '',
  match_confidence VARCHAR(24) NOT NULL DEFAULT '',
  present TINYINT(1) NOT NULL DEFAULT 1,
  synced_at DATETIME(6) NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_monitoring_targets_source_fingerprint (prometheus_source_id, fingerprint),
  KEY idx_monitoring_targets_vm (matched_vm_id, source_type, present),
  KEY idx_monitoring_targets_health (source_type, health, present),
  CONSTRAINT fk_monitoring_targets_source FOREIGN KEY (prometheus_source_id) REFERENCES prometheus_sources(id) ON DELETE CASCADE,
  CONSTRAINT fk_monitoring_targets_vm FOREIGN KEY (matched_vm_id) REFERENCES virtual_machines(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS monitoring_vm_aliases (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  alias_value VARCHAR(512) NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_monitoring_vm_alias (vm_id, alias_value),
  KEY idx_monitoring_alias_value (alias_value),
  CONSTRAINT fk_monitoring_alias_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_monitoring_alias_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO permissions(name, description) VALUES
 ('monitoring.read', 'Vizualizare surse Prometheus, targeturi și stare monitorizare'),
 ('monitoring.manage', 'Administrare surse Prometheus, sincronizare și aliasuri de corelare');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name='admin' AND p.name IN ('monitoring.read','monitoring.manage');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name='operator' AND p.name IN ('monitoring.read','monitoring.manage');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name IN ('viewer','auditor') AND p.name='monitoring.read';
