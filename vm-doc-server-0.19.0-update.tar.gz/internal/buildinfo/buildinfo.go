package buildinfo

var (
	Version = "0.19.0-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
