package monitoring

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

const maxPrometheusResponseSize = 32 << 20

type Client struct {
	baseURL *url.URL
	source  domain.PrometheusSource
	secret  string
	http    *http.Client
}

type apiEnvelope struct {
	Status    string          `json:"status"`
	Data      json.RawMessage `json:"data"`
	ErrorType string          `json:"errorType"`
	Error     string          `json:"error"`
}

type ActiveTarget struct {
	DiscoveredLabels   map[string]string `json:"discoveredLabels"`
	Labels             map[string]string `json:"labels"`
	ScrapePool         string            `json:"scrapePool"`
	ScrapeURL          string            `json:"scrapeUrl"`
	GlobalURL          string            `json:"globalUrl"`
	LastError          string            `json:"lastError"`
	LastScrape         *PromTime         `json:"lastScrape"`
	LastScrapeDuration float64           `json:"lastScrapeDuration"`
	Health             string            `json:"health"`
}

type PromTime struct{ time.Time }

func (t *PromTime) UnmarshalJSON(data []byte) error {
	if string(data) == "null" || string(data) == `""` {
		return nil
	}
	var value string
	if err := json.Unmarshal(data, &value); err != nil {
		return err
	}
	parsed, err := time.Parse(time.RFC3339Nano, value)
	if err != nil {
		return err
	}
	t.Time = parsed
	return nil
}

type targetsData struct {
	ActiveTargets []ActiveTarget `json:"activeTargets"`
}

type BuildInfo struct {
	Version   string `json:"version"`
	Revision  string `json:"revision"`
	BuildUser string `json:"buildUser"`
	GoVersion string `json:"goVersion"`
}

type queryData struct {
	ResultType string        `json:"resultType"`
	Result     []queryResult `json:"result"`
}

type queryResult struct {
	Metric map[string]string `json:"metric"`
	Value  []json.RawMessage `json:"value"`
}

type ProbeMetrics struct {
	Success       map[string]bool
	HTTPStatus    map[string]int
	Duration      map[string]float64
	TLSExpiryUnix map[string]float64
}

func NewClient(source domain.PrometheusSource, secret string, timeout time.Duration) (*Client, error) {
	base, err := url.Parse(strings.TrimRight(source.BaseURL, "/"))
	if err != nil || base.Scheme == "" || base.Host == "" {
		return nil, errors.New("invalid Prometheus base URL")
	}
	transport := &http.Transport{
		Proxy: http.ProxyFromEnvironment,
		TLSClientConfig: &tls.Config{
			MinVersion:         tls.VersionTLS12,
			InsecureSkipVerify: !source.VerifyTLS, // #nosec G402 - explicit source setting for internal/self-signed deployments.
			ServerName:         source.TLSServerName,
		},
	}
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	return &Client{baseURL: base, source: source, secret: secret, http: &http.Client{Timeout: timeout, Transport: transport}}, nil
}

func (c *Client) Test(ctx context.Context) (BuildInfo, int, error) {
	var build BuildInfo
	if err := c.get(ctx, "/api/v1/status/buildinfo", nil, &build); err != nil {
		return build, 0, err
	}
	targets, err := c.Targets(ctx)
	if err != nil {
		return build, 0, err
	}
	return build, len(targets), nil
}

func (c *Client) Targets(ctx context.Context) ([]ActiveTarget, error) {
	var data targetsData
	if err := c.get(ctx, "/api/v1/targets", url.Values{"state": {"active"}}, &data); err != nil {
		return nil, err
	}
	return data.ActiveTargets, nil
}

func (c *Client) ProbeMetrics(ctx context.Context, keyLabel string) (ProbeMetrics, []string) {
	if strings.TrimSpace(keyLabel) == "" {
		keyLabel = "instance"
	}
	out := ProbeMetrics{Success: map[string]bool{}, HTTPStatus: map[string]int{}, Duration: map[string]float64{}, TLSExpiryUnix: map[string]float64{}}
	var warnings []string
	queries := []struct {
		metric string
		apply  func(string, float64)
	}{
		{"probe_success", func(k string, v float64) { out.Success[k] = v >= 0.5 }},
		{"probe_http_status_code", func(k string, v float64) { out.HTTPStatus[k] = int(v) }},
		{"probe_duration_seconds", func(k string, v float64) { out.Duration[k] = v }},
		{"probe_ssl_earliest_cert_expiry", func(k string, v float64) { out.TLSExpiryUnix[k] = v }},
	}
	for _, q := range queries {
		vector, err := c.Query(ctx, q.metric)
		if err != nil {
			warnings = append(warnings, q.metric+": "+err.Error())
			continue
		}
		for _, item := range vector {
			key := strings.TrimSpace(item.Metric[keyLabel])
			if key == "" {
				key = strings.TrimSpace(item.Metric["instance"])
			}
			if key == "" {
				continue
			}
			value, ok := vectorValue(item.Value)
			if ok {
				q.apply(key, value)
			}
		}
	}
	return out, warnings
}

func (c *Client) Query(ctx context.Context, query string) ([]queryResult, error) {
	var data queryData
	if err := c.get(ctx, "/api/v1/query", url.Values{"query": {query}}, &data); err != nil {
		return nil, err
	}
	if data.ResultType != "vector" && data.ResultType != "" {
		return nil, fmt.Errorf("unexpected Prometheus result type %q", data.ResultType)
	}
	return data.Result, nil
}

func vectorValue(raw []json.RawMessage) (float64, bool) {
	if len(raw) < 2 {
		return 0, false
	}
	var text string
	if err := json.Unmarshal(raw[1], &text); err == nil {
		v, err := strconv.ParseFloat(text, 64)
		return v, err == nil
	}
	var v float64
	if err := json.Unmarshal(raw[1], &v); err == nil {
		return v, true
	}
	return 0, false
}

func (c *Client) get(ctx context.Context, path string, values url.Values, out any) error {
	u := *c.baseURL
	u.Path = strings.TrimRight(c.baseURL.Path, "/") + path
	u.RawQuery = values.Encode()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return err
	}
	req.Header.Set("Accept", "application/json")
	switch c.source.AuthMode {
	case "basic":
		req.SetBasicAuth(c.source.Username, c.secret)
	case "bearer":
		req.Header.Set("Authorization", "Bearer "+c.secret)
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	reader := io.LimitReader(resp.Body, maxPrometheusResponseSize+1)
	body, err := io.ReadAll(reader)
	if err != nil {
		return err
	}
	if len(body) > maxPrometheusResponseSize {
		return errors.New("Prometheus response too large")
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("Prometheus API %s: HTTP %d: %s", path, resp.StatusCode, strings.TrimSpace(string(body)))
	}
	var env apiEnvelope
	if err := json.Unmarshal(body, &env); err != nil {
		return fmt.Errorf("decode Prometheus response: %w", err)
	}
	if env.Status != "success" {
		if env.Error != "" {
			return fmt.Errorf("Prometheus API %s: %s", env.ErrorType, env.Error)
		}
		return fmt.Errorf("Prometheus API returned status %q", env.Status)
	}
	if out == nil {
		return nil
	}
	if len(env.Data) == 0 || string(env.Data) == "null" {
		return nil
	}
	if err := json.Unmarshal(env.Data, out); err != nil {
		return fmt.Errorf("decode Prometheus data: %w", err)
	}
	return nil
}
