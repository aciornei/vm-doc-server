package monitoring

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/domain"
)

type Service struct {
	DB     *sql.DB
	Box    *cryptox.Box
	Config config.MonitoringConfig
	Logger *slog.Logger
	ctx    context.Context
	wg     sync.WaitGroup
}

type SourceInput struct {
	Name                string `json:"name"`
	BaseURL             string `json:"base_url"`
	SourceType          string `json:"source_type"`
	Username            string `json:"username,omitempty"`
	AuthMode            string `json:"auth_mode,omitempty"`
	Secret              string `json:"secret,omitempty"`
	VMLabel             string `json:"vm_label,omitempty"`
	TargetLabel         string `json:"target_label,omitempty"`
	Enabled             *bool  `json:"enabled,omitempty"`
	VerifyTLS           *bool  `json:"verify_tls,omitempty"`
	TLSServerName       string `json:"tls_server_name,omitempty"`
	SyncIntervalMinutes int    `json:"sync_interval_minutes,omitempty"`
}

type SourceRecord struct {
	domain.PrometheusSource
	SecretCiphertext string
}

type TestResult struct {
	Status      string `json:"status"`
	Version     string `json:"version,omitempty"`
	Revision    string `json:"revision,omitempty"`
	TargetCount int    `json:"target_count"`
}

type SyncRunPage struct {
	Items    []domain.PrometheusSyncRun `json:"items"`
	Page     int                        `json:"page"`
	PageSize int                        `json:"page_size"`
	Total    int                        `json:"total"`
	Pages    int                        `json:"pages"`
}

type VMListItem struct {
	VMID              int64  `json:"vm_id"`
	VMName            string `json:"vm_name"`
	PowerState        string `json:"power_state,omitempty"`
	ExporterInstalled bool   `json:"exporter_installed"`
	ExporterRunning   bool   `json:"exporter_running"`
	ExporterVersion   string `json:"exporter_version,omitempty"`
	ExporterEndpoint  string `json:"exporter_endpoint,omitempty"`
	MetricsMonitored  bool   `json:"metrics_monitored"`
	MetricsUp         bool   `json:"metrics_up"`
	MetricsTarget     string `json:"metrics_target,omitempty"`
	MetricsJob        string `json:"metrics_job,omitempty"`
	MetricsSource     string `json:"metrics_source,omitempty"`
	MetricsMatch      string `json:"metrics_match,omitempty"`
	BlackboxMonitored bool   `json:"blackbox_monitored"`
	BlackboxUp        bool   `json:"blackbox_up"`
	BlackboxTargets   int    `json:"blackbox_targets"`
	MonitoringState   string `json:"monitoring_state"`
}

type VMPage struct {
	Items                  []VMListItem `json:"items"`
	Page                   int          `json:"page"`
	PageSize               int          `json:"page_size"`
	Total                  int          `json:"total"`
	Pages                  int          `json:"pages"`
	ExporterInstalledCount int          `json:"exporter_installed_count"`
	ExporterRunningCount   int          `json:"exporter_running_count"`
	MetricsMonitoredCount  int          `json:"metrics_monitored_count"`
	MetricsUpCount         int          `json:"metrics_up_count"`
	MetricsDownCount       int          `json:"metrics_down_count"`
	BlackboxMonitoredCount int          `json:"blackbox_monitored_count"`
	BlackboxUpCount        int          `json:"blackbox_up_count"`
	BlackboxDownCount      int          `json:"blackbox_down_count"`
}

type TargetPage struct {
	Items          []domain.MonitoringTarget `json:"items"`
	Page           int                       `json:"page"`
	PageSize       int                       `json:"page_size"`
	Total          int                       `json:"total"`
	Pages          int                       `json:"pages"`
	UpCount        int                       `json:"up_count"`
	DownCount      int                       `json:"down_count"`
	MatchedCount   int                       `json:"matched_count"`
	UnmatchedCount int                       `json:"unmatched_count"`
}

type AliasInput struct {
	Aliases []string `json:"aliases"`
}

type exporterInfo struct {
	Installed bool
	Running   bool
	Version   string
	Endpoint  string
}

type vmIdentity struct {
	ID         int64
	Name       string
	PowerState string
	FQDNs      map[string]struct{}
	Hostnames  map[string]struct{}
	IPs        map[string]struct{}
	Aliases    map[string]struct{}
	Exporter   exporterInfo
}

func NewService(ctx context.Context, db *sql.DB, box *cryptox.Box, cfg config.Config, logger *slog.Logger) *Service {
	if logger == nil {
		logger = slog.Default()
	}
	return &Service{DB: db, Box: box, Config: cfg.Monitoring, Logger: logger, ctx: ctx}
}

func (s *Service) Wait() { s.wg.Wait() }

func (s *Service) ListSources(ctx context.Context) ([]domain.PrometheusSource, error) {
	rows, err := s.DB.QueryContext(ctx, sourceSelect+` ORDER BY s.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.PrometheusSource, 0)
	for rows.Next() {
		r, err := scanSource(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, r.PrometheusSource)
	}
	return out, rows.Err()
}

func (s *Service) GetSource(ctx context.Context, id int64) (domain.PrometheusSource, error) {
	r, err := s.GetSourceRecord(ctx, id)
	return r.PrometheusSource, err
}

func (s *Service) GetSourceRecord(ctx context.Context, id int64) (SourceRecord, error) {
	return scanSource(s.DB.QueryRowContext(ctx, sourceSelect+` WHERE s.id=?`, id))
}

func (s *Service) CreateSource(ctx context.Context, in SourceInput, userID int64) (domain.PrometheusSource, error) {
	if err := s.normalizeSource(&in, true); err != nil {
		return domain.PrometheusSource{}, err
	}
	ref, err := cryptox.RandomToken(24)
	if err != nil {
		return domain.PrometheusSource{}, err
	}
	cipher := ""
	if in.Secret != "" {
		cipher, err = s.Box.Encrypt([]byte(in.Secret), "vm-doc-prometheus-secret:"+ref)
		if err != nil {
			return domain.PrometheusSource{}, err
		}
	}
	enabled, verify := true, true
	if in.Enabled != nil {
		enabled = *in.Enabled
	}
	if in.VerifyTLS != nil {
		verify = *in.VerifyTLS
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO prometheus_sources(secret_ref,name,base_url,source_type,username,auth_mode,secret_ciphertext,vm_label,target_label,enabled,verify_tls,tls_server_name,sync_interval_minutes,last_error,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'',?,?)`, ref, in.Name, strings.TrimRight(in.BaseURL, "/"), in.SourceType, in.Username, in.AuthMode, cipher, in.VMLabel, in.TargetLabel, enabled, verify, in.TLSServerName, in.SyncIntervalMinutes, userID, userID)
	if err != nil {
		return domain.PrometheusSource{}, err
	}
	id, _ := res.LastInsertId()
	return s.GetSource(ctx, id)
}

func (s *Service) UpdateSource(ctx context.Context, id int64, in SourceInput, userID int64) (domain.PrometheusSource, error) {
	current, err := s.GetSourceRecord(ctx, id)
	if err != nil {
		return domain.PrometheusSource{}, err
	}
	if strings.TrimSpace(in.Name) == "" {
		in.Name = current.Name
	}
	if strings.TrimSpace(in.BaseURL) == "" {
		in.BaseURL = current.BaseURL
	}
	if strings.TrimSpace(in.SourceType) == "" {
		in.SourceType = current.SourceType
	}
	if strings.TrimSpace(in.AuthMode) == "" {
		in.AuthMode = current.AuthMode
	}
	if strings.TrimSpace(in.Username) == "" && in.AuthMode == "basic" {
		in.Username = current.Username
	}
	if strings.TrimSpace(in.VMLabel) == "" {
		in.VMLabel = current.VMLabel
	}
	if strings.TrimSpace(in.TargetLabel) == "" {
		in.TargetLabel = current.TargetLabel
	}
	if in.SyncIntervalMinutes == 0 {
		in.SyncIntervalMinutes = current.SyncIntervalMinutes
	}
	if in.Enabled == nil {
		v := current.Enabled
		in.Enabled = &v
	}
	if in.VerifyTLS == nil {
		v := current.VerifyTLS
		in.VerifyTLS = &v
	}
	if in.TLSServerName == "" {
		in.TLSServerName = current.TLSServerName
	}
	if err := s.normalizeSource(&in, false); err != nil {
		return domain.PrometheusSource{}, err
	}
	cipher := current.SecretCiphertext
	if in.Secret != "" {
		cipher, err = s.Box.Encrypt([]byte(in.Secret), "vm-doc-prometheus-secret:"+current.SecretRef)
		if err != nil {
			return domain.PrometheusSource{}, err
		}
	} else if in.AuthMode == "none" {
		cipher = ""
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE prometheus_sources SET name=?,base_url=?,source_type=?,username=?,auth_mode=?,secret_ciphertext=?,vm_label=?,target_label=?,enabled=?,verify_tls=?,tls_server_name=?,sync_interval_minutes=?,updated_by=? WHERE id=?`, in.Name, strings.TrimRight(in.BaseURL, "/"), in.SourceType, in.Username, in.AuthMode, cipher, in.VMLabel, in.TargetLabel, *in.Enabled, *in.VerifyTLS, in.TLSServerName, in.SyncIntervalMinutes, userID, id)
	if err != nil {
		return domain.PrometheusSource{}, err
	}
	return s.GetSource(ctx, id)
}

func (s *Service) DeleteSource(ctx context.Context, id int64) error {
	res, err := s.DB.ExecContext(ctx, `DELETE FROM prometheus_sources WHERE id=?`, id)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s *Service) TestSource(ctx context.Context, id int64) (TestResult, error) {
	record, err := s.GetSourceRecord(ctx, id)
	if err != nil {
		return TestResult{}, err
	}
	secret, err := s.decryptSecret(record)
	if err != nil {
		return TestResult{}, err
	}
	client, err := NewClient(record.PrometheusSource, secret, s.Config.RequestTimeout.Value())
	if err != nil {
		return TestResult{}, err
	}
	build, count, err := client.Test(ctx)
	if err != nil {
		return TestResult{}, err
	}
	return TestResult{Status: "ok", Version: build.Version, Revision: build.Revision, TargetCount: count}, nil
}

func (s *Service) StartSync(ctx context.Context, sourceID int64, source string, requestedBy *int64) (domain.PrometheusSyncRun, error) {
	if source != "manual" && source != "scheduler" {
		return domain.PrometheusSyncRun{}, errors.New("invalid sync source")
	}
	src, err := s.GetSource(ctx, sourceID)
	if err != nil {
		return domain.PrometheusSyncRun{}, err
	}
	if source == "scheduler" && !src.Enabled {
		return domain.PrometheusSyncRun{}, errors.New("Prometheus source is disabled")
	}
	var running int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM prometheus_sync_runs WHERE prometheus_source_id=? AND status IN ('queued','running')`, sourceID).Scan(&running); err != nil {
		return domain.PrometheusSyncRun{}, err
	}
	if running > 0 {
		return domain.PrometheusSyncRun{}, errors.New("a Prometheus synchronization is already running")
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO prometheus_sync_runs(prometheus_source_id,source,status,requested_by_user_id,error_message) VALUES(?,?,'queued',?,'')`, sourceID, source, requestedBy)
	if err != nil {
		return domain.PrometheusSyncRun{}, err
	}
	id, _ := res.LastInsertId()
	run, err := s.GetRun(ctx, id)
	if err != nil {
		return run, err
	}
	s.wg.Add(1)
	go func() { defer s.wg.Done(); s.executeSync(s.ctx, id, sourceID) }()
	return run, nil
}

func (s *Service) StartAll(ctx context.Context, requestedBy *int64) ([]domain.PrometheusSyncRun, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id FROM prometheus_sources WHERE enabled=1 ORDER BY name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	out := make([]domain.PrometheusSyncRun, 0, len(ids))
	for _, id := range ids {
		run, err := s.StartSync(ctx, id, "manual", requestedBy)
		if err != nil {
			if strings.Contains(err.Error(), "already running") {
				continue
			}
			return out, err
		}
		out = append(out, run)
	}
	return out, nil
}

func (s *Service) GetRun(ctx context.Context, id int64) (domain.PrometheusSyncRun, error) {
	return scanRun(s.DB.QueryRowContext(ctx, runSelect+` WHERE r.id=?`, id))
}

func (s *Service) ListRunsPage(ctx context.Context, page, pageSize int) (SyncRunPage, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 10
	}
	if pageSize > 200 {
		pageSize = 200
	}
	var total int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM prometheus_sync_runs`).Scan(&total); err != nil {
		return SyncRunPage{}, err
	}
	rows, err := s.DB.QueryContext(ctx, runSelect+` ORDER BY r.id DESC LIMIT ? OFFSET ?`, pageSize, (page-1)*pageSize)
	if err != nil {
		return SyncRunPage{}, err
	}
	defer rows.Close()
	out := SyncRunPage{Items: []domain.PrometheusSyncRun{}, Page: page, PageSize: pageSize, Total: total}
	if total > 0 {
		out.Pages = (total + pageSize - 1) / pageSize
	}
	for rows.Next() {
		v, err := scanRun(rows)
		if err != nil {
			return out, err
		}
		out.Items = append(out.Items, v)
	}
	return out, rows.Err()
}

func (s *Service) RunScheduler(ctx context.Context) {
	interval := s.Config.SchedulerInterval.Value()
	if interval <= 0 {
		interval = time.Minute
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		s.scheduleDue(ctx)
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}

func (s *Service) scheduleDue(ctx context.Context) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,sync_interval_minutes,last_sync_at FROM prometheus_sources WHERE enabled=1`)
	if err != nil {
		if ctx.Err() == nil {
			s.Logger.Error("load scheduled Prometheus sources", "error", err)
		}
		return
	}
	defer rows.Close()
	type item struct {
		id      int64
		minutes int
		last    sql.NullTime
	}
	var due []item
	now := time.Now().UTC()
	for rows.Next() {
		var v item
		if rows.Scan(&v.id, &v.minutes, &v.last) == nil {
			if v.minutes < 1 {
				v.minutes = 15
			}
			if !v.last.Valid || now.Sub(v.last.Time) >= time.Duration(v.minutes)*time.Minute {
				due = append(due, v)
			}
		}
	}
	for _, v := range due {
		if _, err := s.StartSync(ctx, v.id, "scheduler", nil); err != nil && !strings.Contains(err.Error(), "already running") {
			s.Logger.Error("queue scheduled Prometheus sync", "source_id", v.id, "error", err)
		}
	}
}

func (s *Service) executeSync(ctx context.Context, runID, sourceID int64) {
	started := time.Now().UTC()
	_, _ = s.DB.ExecContext(ctx, `UPDATE prometheus_sync_runs SET status='running',started_at=? WHERE id=? AND status='queued'`, started, runID)
	record, err := s.GetSourceRecord(ctx, sourceID)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	secret, err := s.decryptSecret(record)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	client, err := NewClient(record.PrometheusSource, secret, s.Config.RequestTimeout.Value())
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	targets, err := client.Targets(ctx)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	identities, err := s.loadVMIdentities(ctx)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	var probes ProbeMetrics
	var warnings []string
	if record.SourceType == "blackbox" {
		probes, warnings = client.ProbeMetrics(ctx, record.TargetLabel)
		if len(warnings) > 0 {
			s.Logger.Warn("Prometheus blackbox metric query warnings", "source_id", sourceID, "warnings", strings.Join(warnings, "; "))
		}
	}
	now := time.Now().UTC()
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	defer tx.Rollback()
	if _, err = tx.ExecContext(ctx, `UPDATE monitoring_targets SET present=0 WHERE prometheus_source_id=?`, sourceID); err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	matchedVM := map[int64]struct{}{}
	up, down, unmatched, ambiguous := 0, 0, 0, 0
	for _, target := range targets {
		labels := target.Labels
		if labels == nil {
			labels = map[string]string{}
		}
		discovered := target.DiscoveredLabels
		if discovered == nil {
			discovered = map[string]string{}
		}
		instance := strings.TrimSpace(labels["instance"])
		if instance == "" {
			instance = strings.TrimSpace(discovered["__address__"])
		}
		targetValue := strings.TrimSpace(labels[record.TargetLabel])
		if targetValue == "" {
			targetValue = instance
		}
		if record.SourceType == "blackbox" && strings.TrimSpace(discovered["__param_target"]) != "" {
			targetValue = strings.TrimSpace(discovered["__param_target"])
		}
		vm, method, value, isAmbiguous := matchTarget(record.PrometheusSource, target, identities, targetValue)
		if isAmbiguous {
			ambiguous++
		}
		var vmID any = nil
		confidence := ""
		if vm != nil {
			vmID = vm.ID
			matchedVM[vm.ID] = struct{}{}
			confidence = "exact"
		} else if !isAmbiguous {
			unmatched++
		}
		health := strings.ToLower(strings.TrimSpace(target.Health))
		if health == "up" {
			up++
		} else {
			down++
		}
		labelsJSON, _ := json.Marshal(labels)
		discJSON, _ := json.Marshal(discovered)
		fp := fingerprint(record.SourceType, target.ScrapePool, instance, target.ScrapeURL, targetValue)
		var lastScrape any = nil
		if target.LastScrape != nil && !target.LastScrape.IsZero() {
			lastScrape = target.LastScrape.UTC()
		}
		var probeSuccess, httpStatus, probeDuration, tlsExpiry any = nil, nil, nil, nil
		if record.SourceType == "blackbox" {
			key := targetValue
			if v, ok := probes.Success[key]; ok {
				probeSuccess = v
			}
			if v, ok := probes.HTTPStatus[key]; ok {
				httpStatus = v
			}
			if v, ok := probes.Duration[key]; ok {
				probeDuration = v
			}
			if v, ok := probes.TLSExpiryUnix[key]; ok && v > 0 {
				tlsExpiry = time.Unix(int64(v), 0).UTC()
			}
		}
		_, err = tx.ExecContext(ctx, `INSERT INTO monitoring_targets(prometheus_source_id,fingerprint,source_type,job_name,instance_value,scrape_url,target_url,health,last_error,last_scrape_at,scrape_duration_seconds,probe_success,http_status_code,probe_duration_seconds,tls_expiry_at,labels_json,discovered_labels_json,matched_vm_id,match_method,match_value,match_confidence,present,synced_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?) ON DUPLICATE KEY UPDATE source_type=VALUES(source_type),job_name=VALUES(job_name),instance_value=VALUES(instance_value),scrape_url=VALUES(scrape_url),target_url=VALUES(target_url),health=VALUES(health),last_error=VALUES(last_error),last_scrape_at=VALUES(last_scrape_at),scrape_duration_seconds=VALUES(scrape_duration_seconds),probe_success=VALUES(probe_success),http_status_code=VALUES(http_status_code),probe_duration_seconds=VALUES(probe_duration_seconds),tls_expiry_at=VALUES(tls_expiry_at),labels_json=VALUES(labels_json),discovered_labels_json=VALUES(discovered_labels_json),matched_vm_id=VALUES(matched_vm_id),match_method=VALUES(match_method),match_value=VALUES(match_value),match_confidence=VALUES(match_confidence),present=1,synced_at=VALUES(synced_at)`, sourceID, fp, record.SourceType, target.ScrapePool, instance, target.ScrapeURL, targetValue, health, target.LastError, lastScrape, target.LastScrapeDuration, probeSuccess, httpStatus, probeDuration, tlsExpiry, string(labelsJSON), string(discJSON), vmID, method, value, confidence, now)
		if err != nil {
			s.failRun(ctx, runID, sourceID, err)
			return
		}
	}
	if err = tx.Commit(); err != nil {
		s.failRun(ctx, runID, sourceID, err)
		return
	}
	_, _ = s.DB.ExecContext(ctx, `UPDATE prometheus_sync_runs SET status='success',finished_at=?,target_count=?,matched_vm_count=?,up_count=?,down_count=?,unmatched_count=?,ambiguous_count=?,error_message='' WHERE id=?`, now, len(targets), len(matchedVM), up, down, unmatched, ambiguous, runID)
	_, _ = s.DB.ExecContext(ctx, `UPDATE prometheus_sources SET last_sync_at=?,last_success_at=?,last_error='' WHERE id=?`, now, now, sourceID)
	s.Logger.Info("Prometheus synchronization completed", "source_id", sourceID, "run_id", runID, "targets", len(targets), "matched_vms", len(matchedVM), "up", up, "down", down, "unmatched", unmatched, "ambiguous", ambiguous)
}

func (s *Service) ListVMs(ctx context.Context, q, state, power string, page, pageSize int) (VMPage, error) {
	identities, err := s.loadVMIdentities(ctx)
	if err != nil {
		return VMPage{}, err
	}
	targets, err := s.loadPresentTargets(ctx, 0)
	if err != nil {
		return VMPage{}, err
	}
	byVM := map[int64][]domain.MonitoringTarget{}
	for _, t := range targets {
		if t.MatchedVMID != nil {
			byVM[*t.MatchedVMID] = append(byVM[*t.MatchedVMID], t)
		}
	}
	q = strings.ToLower(strings.TrimSpace(q))
	state = strings.ToLower(strings.TrimSpace(state))
	power = strings.TrimSpace(power)
	items := make([]VMListItem, 0, len(identities))
	for _, vm := range identities {
		item := vmListItem(vm, byVM[vm.ID])
		hay := strings.ToLower(strings.Join([]string{item.VMName, item.PowerState, item.ExporterVersion, item.ExporterEndpoint, item.MetricsTarget, item.MetricsJob, item.MetricsSource, item.MetricsMatch}, " "))
		if q != "" && !strings.Contains(hay, q) {
			continue
		}
		if power != "" && item.PowerState != power {
			continue
		}
		if !monitoringStateMatches(item, state) {
			continue
		}
		items = append(items, item)
	}
	sort.Slice(items, func(i, j int) bool { return strings.ToLower(items[i].VMName) < strings.ToLower(items[j].VMName) })
	out := VMPage{}
	for _, item := range items {
		if item.ExporterInstalled {
			out.ExporterInstalledCount++
		}
		if item.ExporterRunning {
			out.ExporterRunningCount++
		}
		if item.MetricsMonitored {
			out.MetricsMonitoredCount++
			if item.MetricsUp {
				out.MetricsUpCount++
			} else {
				out.MetricsDownCount++
			}
		}
		if item.BlackboxMonitored {
			out.BlackboxMonitoredCount++
			if item.BlackboxUp {
				out.BlackboxUpCount++
			} else {
				out.BlackboxDownCount++
			}
		}
	}
	out.Total = len(items)
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 10
	}
	if pageSize > 200 {
		pageSize = 200
	}
	out.Page = page
	out.PageSize = pageSize
	if out.Total > 0 {
		out.Pages = (out.Total + pageSize - 1) / pageSize
	}
	start := (page - 1) * pageSize
	if start > out.Total {
		start = out.Total
	}
	end := start + pageSize
	if end > out.Total {
		end = out.Total
	}
	out.Items = items[start:end]
	return out, nil
}

func (s *Service) GetVM(ctx context.Context, vmID int64) (domain.VMMonitoringSummary, error) {
	identities, err := s.loadVMIdentities(ctx)
	if err != nil {
		return domain.VMMonitoringSummary{}, err
	}
	var vm *vmIdentity
	for i := range identities {
		if identities[i].ID == vmID {
			vm = &identities[i]
			break
		}
	}
	if vm == nil {
		return domain.VMMonitoringSummary{}, sql.ErrNoRows
	}
	targets, err := s.loadPresentTargets(ctx, vmID)
	if err != nil {
		return domain.VMMonitoringSummary{}, err
	}
	aliases, err := s.ListAliases(ctx, vmID)
	if err != nil {
		return domain.VMMonitoringSummary{}, err
	}
	out := domain.VMMonitoringSummary{VMID: vm.ID, VMName: vm.Name, PowerState: vm.PowerState, ExporterInstalled: vm.Exporter.Installed, ExporterRunning: vm.Exporter.Running, ExporterVersion: vm.Exporter.Version, ExporterEndpoint: vm.Exporter.Endpoint, Aliases: aliases}
	for _, t := range targets {
		if t.SourceType == "blackbox" {
			out.BlackboxTargets = append(out.BlackboxTargets, t)
		} else {
			out.MetricsTargets = append(out.MetricsTargets, t)
		}
	}
	out.MetricsMonitored = len(out.MetricsTargets) > 0
	out.MetricsUp = out.MetricsMonitored
	for _, t := range out.MetricsTargets {
		if strings.ToLower(t.Health) != "up" {
			out.MetricsUp = false
		}
	}
	out.BlackboxMonitored = len(out.BlackboxTargets) > 0
	out.BlackboxUp = out.BlackboxMonitored
	for _, t := range out.BlackboxTargets {
		if !targetUp(t) {
			out.BlackboxUp = false
		}
	}
	out.MonitoringState = monitoringState(vmListItem(*vm, targets))
	return out, nil
}

func (s *Service) ListTargets(ctx context.Context, q, sourceType, health, matched string, page, pageSize int) (TargetPage, error) {
	targets, err := s.loadPresentTargets(ctx, 0)
	if err != nil {
		return TargetPage{}, err
	}
	q = strings.ToLower(strings.TrimSpace(q))
	sourceType = strings.ToLower(strings.TrimSpace(sourceType))
	health = strings.ToLower(strings.TrimSpace(health))
	matched = strings.ToLower(strings.TrimSpace(matched))
	filtered := make([]domain.MonitoringTarget, 0, len(targets))
	out := TargetPage{}
	for _, t := range targets {
		hay := strings.ToLower(strings.Join([]string{t.PrometheusSourceName, t.JobName, t.Instance, t.TargetURL, t.ScrapeURL, t.MatchedVMName, t.MatchMethod, t.LastError}, " "))
		if q != "" && !strings.Contains(hay, q) {
			continue
		}
		if sourceType != "" && t.SourceType != sourceType {
			continue
		}
		if health != "" && strings.ToLower(t.Health) != health {
			continue
		}
		if matched == "yes" && t.MatchedVMID == nil {
			continue
		}
		if matched == "no" && t.MatchedVMID != nil {
			continue
		}
		filtered = append(filtered, t)
		if targetUp(t) {
			out.UpCount++
		} else {
			out.DownCount++
		}
		if t.MatchedVMID != nil {
			out.MatchedCount++
		} else {
			out.UnmatchedCount++
		}
	}
	sort.Slice(filtered, func(i, j int) bool {
		if filtered[i].SourceType != filtered[j].SourceType {
			return filtered[i].SourceType < filtered[j].SourceType
		}
		return strings.ToLower(filtered[i].Instance) < strings.ToLower(filtered[j].Instance)
	})
	out.Total = len(filtered)
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 10
	}
	if pageSize > 200 {
		pageSize = 200
	}
	out.Page = page
	out.PageSize = pageSize
	if out.Total > 0 {
		out.Pages = (out.Total + pageSize - 1) / pageSize
	}
	start := (page - 1) * pageSize
	if start > out.Total {
		start = out.Total
	}
	end := start + pageSize
	if end > out.Total {
		end = out.Total
	}
	out.Items = filtered[start:end]
	return out, nil
}

func (s *Service) ListAliases(ctx context.Context, vmID int64) ([]domain.MonitoringAlias, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,vm_id,alias_value,created_at FROM monitoring_vm_aliases WHERE vm_id=? ORDER BY alias_value`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.MonitoringAlias{}
	for rows.Next() {
		var a domain.MonitoringAlias
		if err := rows.Scan(&a.ID, &a.VMID, &a.Alias, &a.CreatedAt); err != nil {
			return nil, err
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

func (s *Service) UpdateAliases(ctx context.Context, vmID int64, in AliasInput, userID int64) error {
	var exists int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM virtual_machines WHERE id=? AND retired=0`, vmID).Scan(&exists); err != nil {
		return err
	}
	if exists == 0 {
		return sql.ErrNoRows
	}
	cleaned := []string{}
	seen := map[string]struct{}{}
	for _, raw := range in.Aliases {
		v := normalizeIdentity(raw)
		if v == "" {
			continue
		}
		if len(v) > 512 {
			return errors.New("monitoring alias is too long")
		}
		if _, ok := seen[v]; ok {
			continue
		}
		seen[v] = struct{}{}
		cleaned = append(cleaned, v)
	}
	sort.Strings(cleaned)
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err = tx.ExecContext(ctx, `DELETE FROM monitoring_vm_aliases WHERE vm_id=?`, vmID); err != nil {
		return err
	}
	for _, v := range cleaned {
		if _, err = tx.ExecContext(ctx, `INSERT INTO monitoring_vm_aliases(vm_id,alias_value,created_by) VALUES(?,?,?)`, vmID, v, userID); err != nil {
			return err
		}
	}
	if err = tx.Commit(); err != nil {
		return err
	}
	// Re-run matching at the next Prometheus sync; keeping this explicit avoids changing historical target rows silently.
	return nil
}

func (s *Service) loadPresentTargets(ctx context.Context, vmID int64) ([]domain.MonitoringTarget, error) {
	q := targetSelect + ` WHERE t.present=1`
	args := []any{}
	if vmID > 0 {
		q += ` AND t.matched_vm_id=?`
		args = append(args, vmID)
	}
	q += ` ORDER BY s.name,t.source_type,t.job_name,t.instance_value`
	rows, err := s.DB.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.MonitoringTarget{}
	for rows.Next() {
		t, err := scanTarget(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, t)
	}
	return out, rows.Err()
}

func (s *Service) loadVMIdentities(ctx context.Context) ([]vmIdentity, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT vm.id,vm.name,vm.power_state,vm.guest_hostname,vm.primary_ip,COALESCE(i.hostname,''),COALESCE(i.fqdn,''),COALESCE(i.primary_ip,''),COALESCE(i.raw_json,'{}') FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0 ORDER BY vm.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []vmIdentity{}
	for rows.Next() {
		var v vmIdentity
		var guest, vmIP, ihost, ifqdn, iip, raw string
		if err := rows.Scan(&v.ID, &v.Name, &v.PowerState, &guest, &vmIP, &ihost, &ifqdn, &iip, &raw); err != nil {
			return nil, err
		}
		v.FQDNs = map[string]struct{}{}
		v.Hostnames = map[string]struct{}{}
		v.IPs = map[string]struct{}{}
		v.Aliases = map[string]struct{}{}
		addIdentity(v.FQDNs, v.Hostnames, v.IPs, v.Name)
		addIdentity(v.FQDNs, v.Hostnames, v.IPs, guest)
		addIdentity(v.FQDNs, v.Hostnames, v.IPs, ihost)
		addIdentity(v.FQDNs, v.Hostnames, v.IPs, ifqdn)
		addIdentity(v.FQDNs, v.Hostnames, v.IPs, vmIP)
		addIdentity(v.FQDNs, v.Hostnames, v.IPs, iip)
		v.Exporter = parseInventory(&v, []byte(raw))
		out = append(out, v)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	aliasRows, err := s.DB.QueryContext(ctx, `SELECT vm_id,alias_value FROM monitoring_vm_aliases`)
	if err != nil {
		return nil, err
	}
	defer aliasRows.Close()
	byID := map[int64]*vmIdentity{}
	for i := range out {
		byID[out[i].ID] = &out[i]
	}
	for aliasRows.Next() {
		var id int64
		var a string
		if aliasRows.Scan(&id, &a) == nil {
			if v := byID[id]; v != nil {
				v.Aliases[normalizeIdentity(a)] = struct{}{}
			}
		}
	}
	return out, aliasRows.Err()
}

func parseInventory(v *vmIdentity, raw []byte) exporterInfo {
	var root map[string]any
	if json.Unmarshal(raw, &root) != nil {
		return exporterInfo{}
	}
	collectLocalIdentities(v, root)
	ints, ok := asMap(root["integrations"])
	if !ok {
		return exporterInfo{}
	}
	node, ok := asMap(ints["node_exporter"])
	if !ok {
		return exporterInfo{}
	}
	info := exporterInfo{Installed: asBool(node["installed"]), Version: asString(node["version"])}
	active := strings.ToLower(asString(node["service_active"]))
	reachable := asBool(node["metrics_reachable"])
	info.Running = reachable || active == "active" || active == "running"
	for _, key := range []string{"listen_addresses", "metrics_endpoints"} {
		if arr, ok := node[key].([]any); ok && len(arr) > 0 {
			if s := asString(arr[0]); s != "" {
				info.Endpoint = s
				break
			}
		}
	}
	return info
}

func collectLocalIdentities(v *vmIdentity, root map[string]any) {
	// Corelarea trebuie să folosească numai identitatea locală a VM-ului.
	// Nu parcurgem recursiv tot inventarul: DNS, gateway, proxy, syslog,
	// backends etc. conțin IP-uri remote și ar produce corelări false.
	if host, ok := asMap(root["host"]); ok {
		for _, key := range []string{"hostname", "fqdn", "canonical_dns_name"} {
			if value := asString(host[key]); value != "" {
				addIdentity(v.FQDNs, v.Hostnames, v.IPs, value)
			}
		}
	}
	network, ok := asMap(root["network"])
	if !ok {
		return
	}
	interfaces, _ := network["interfaces"].([]any)
	for _, rawInterface := range interfaces {
		iface, ok := asMap(rawInterface)
		if !ok || asBool(iface["loopback"]) {
			continue
		}
		addresses, _ := iface["addresses"].([]any)
		for _, rawAddress := range addresses {
			address, ok := asMap(rawAddress)
			if !ok {
				continue
			}
			if value := asString(address["address"]); value != "" {
				addIdentity(v.FQDNs, v.Hostnames, v.IPs, value)
			}
		}
	}
}

func matchTarget(source domain.PrometheusSource, target ActiveTarget, vms []vmIdentity, targetValue string) (*vmIdentity, string, string, bool) {
	if label := strings.TrimSpace(source.VMLabel); label != "" {
		if value := strings.TrimSpace(target.Labels[label]); value != "" {
			if vm, amb := matchExplicit(value, vms); vm != nil || amb {
				return vm, "label:" + label, normalizeIdentity(value), amb
			}
		}
	}
	raw := targetValue
	if raw == "" {
		raw = target.Labels["instance"]
	}
	host := extractTargetHost(raw)
	norm := normalizeIdentity(host)
	if norm != "" {
		if ip := net.ParseIP(norm); ip != nil {
			ipn := ip.String()
			if vm, amb := matchSet(ipn, vms, func(v vmIdentity) map[string]struct{} { return v.IPs }); vm != nil || amb {
				return vm, "ip", ipn, amb
			}
		} else {
			if strings.Contains(norm, ".") {
				if vm, amb := matchSet(norm, vms, func(v vmIdentity) map[string]struct{} { return v.FQDNs }); vm != nil || amb {
					return vm, "fqdn", norm, amb
				}
			}
			short := norm
			if i := strings.IndexByte(short, '.'); i > 0 {
				short = short[:i]
			}
			if vm, amb := matchSet(short, vms, func(v vmIdentity) map[string]struct{} { return v.Hostnames }); vm != nil || amb {
				return vm, "hostname", short, amb
			}
		}
		if vm, amb := matchSet(norm, vms, func(v vmIdentity) map[string]struct{} { return v.Aliases }); vm != nil || amb {
			return vm, "alias", norm, amb
		}
		if normalizeIdentity(raw) != norm {
			if vm, amb := matchSet(normalizeIdentity(raw), vms, func(v vmIdentity) map[string]struct{} { return v.Aliases }); vm != nil || amb {
				return vm, "alias", normalizeIdentity(raw), amb
			}
		}
	}
	return nil, "", "", false
}

func matchExplicit(value string, vms []vmIdentity) (*vmIdentity, bool) {
	n := normalizeIdentity(value)
	if n == "" {
		return nil, false
	}
	sets := []func(vmIdentity) map[string]struct{}{func(v vmIdentity) map[string]struct{} { return v.FQDNs }, func(v vmIdentity) map[string]struct{} { return v.Hostnames }, func(v vmIdentity) map[string]struct{} { return v.IPs }, func(v vmIdentity) map[string]struct{} { return v.Aliases }}
	for _, set := range sets {
		if vm, amb := matchSet(n, vms, set); vm != nil || amb {
			return vm, amb
		}
	}
	return nil, false
}
func matchSet(value string, vms []vmIdentity, set func(vmIdentity) map[string]struct{}) (*vmIdentity, bool) {
	var found *vmIdentity
	for i := range vms {
		if _, ok := set(vms[i])[value]; ok {
			if found != nil {
				return nil, true
			}
			found = &vms[i]
		}
	}
	return found, false
}

func vmListItem(vm vmIdentity, targets []domain.MonitoringTarget) VMListItem {
	item := VMListItem{VMID: vm.ID, VMName: vm.Name, PowerState: vm.PowerState, ExporterInstalled: vm.Exporter.Installed, ExporterRunning: vm.Exporter.Running, ExporterVersion: vm.Exporter.Version, ExporterEndpoint: vm.Exporter.Endpoint}
	for _, t := range targets {
		if t.SourceType == "blackbox" {
			item.BlackboxMonitored = true
			item.BlackboxTargets++
			if targetUp(t) {
				item.BlackboxUp = true
			}
		} else {
			item.MetricsMonitored = true
			if strings.ToLower(t.Health) == "up" {
				item.MetricsUp = true
			}
			if item.MetricsTarget == "" {
				item.MetricsTarget = t.Instance
				item.MetricsJob = t.JobName
				item.MetricsSource = t.PrometheusSourceName
				item.MetricsMatch = t.MatchMethod
			}
		}
	}
	if item.MetricsMonitored {
		item.MetricsUp = true
		for _, t := range targets {
			if t.SourceType != "blackbox" && strings.ToLower(t.Health) != "up" {
				item.MetricsUp = false
			}
		}
	}
	if item.BlackboxMonitored {
		item.BlackboxUp = true
		for _, t := range targets {
			if t.SourceType == "blackbox" && !targetUp(t) {
				item.BlackboxUp = false
			}
		}
	}
	item.MonitoringState = monitoringState(item)
	return item
}
func monitoringState(item VMListItem) string {
	if item.MetricsMonitored && !item.MetricsUp {
		return "down"
	}
	if item.MetricsMonitored && item.MetricsUp {
		return "monitored"
	}
	if item.ExporterRunning {
		return "exporter_only"
	}
	if item.ExporterInstalled {
		return "exporter_stopped"
	}
	return "unmonitored"
}
func monitoringStateMatches(item VMListItem, state string) bool {
	switch state {
	case "":
		return true
	case "monitored":
		return item.MetricsMonitored
	case "up":
		return item.MetricsMonitored && item.MetricsUp
	case "down":
		return item.MetricsMonitored && !item.MetricsUp
	case "exporter_only":
		return item.ExporterRunning && !item.MetricsMonitored
	case "no_exporter":
		return !item.ExporterInstalled
	case "unmonitored":
		return !item.MetricsMonitored
	default:
		return true
	}
}
func targetUp(t domain.MonitoringTarget) bool {
	if t.ProbeSuccess != nil {
		return *t.ProbeSuccess
	}
	return strings.ToLower(t.Health) == "up"
}

func addIdentity(fqdns, hosts, ips map[string]struct{}, raw string) {
	v := extractTargetHost(raw)
	v = normalizeIdentity(v)
	if v == "" {
		return
	}
	if ip := net.ParseIP(v); ip != nil {
		ips[ip.String()] = struct{}{}
		return
	}
	if strings.Contains(v, ".") {
		fqdns[v] = struct{}{}
		short := strings.Split(v, ".")[0]
		if short != "" {
			hosts[short] = struct{}{}
		}
	} else {
		hosts[v] = struct{}{}
	}
}
func extractTargetHost(raw string) string {
	v := strings.TrimSpace(raw)
	if v == "" {
		return ""
	}
	if u, err := url.Parse(v); err == nil && u.Host != "" {
		return u.Hostname()
	}
	if h, _, err := net.SplitHostPort(v); err == nil {
		return strings.Trim(h, "[]")
	}
	if strings.Count(v, ":") == 1 {
		if i := strings.LastIndex(v, ":"); i > 0 {
			if _, err := strconv.Atoi(v[i+1:]); err == nil {
				return v[:i]
			}
		}
	}
	return strings.Trim(v, "[]")
}
func normalizeIdentity(v string) string {
	return strings.ToLower(strings.TrimSpace(strings.TrimSuffix(v, ".")))
}
func fingerprint(parts ...string) string {
	h := sha256.New()
	for _, p := range parts {
		h.Write([]byte(p))
		h.Write([]byte{0})
	}
	return hex.EncodeToString(h.Sum(nil))
}
func asMap(v any) (map[string]any, bool) { m, ok := v.(map[string]any); return m, ok }
func asString(v any) string {
	switch x := v.(type) {
	case string:
		return strings.TrimSpace(x)
	case fmt.Stringer:
		return strings.TrimSpace(x.String())
	default:
		return ""
	}
}
func asBool(v any) bool {
	switch x := v.(type) {
	case bool:
		return x
	case string:
		return strings.EqualFold(x, "true") || x == "1"
	case float64:
		return x != 0
	}
	return false
}

func (s *Service) failRun(ctx context.Context, runID, sourceID int64, err error) {
	message := truncate(err.Error(), 4000)
	now := time.Now().UTC()
	_, _ = s.DB.ExecContext(ctx, `UPDATE prometheus_sync_runs SET status='failed',finished_at=?,error_message=? WHERE id=?`, now, message, runID)
	_, _ = s.DB.ExecContext(ctx, `UPDATE prometheus_sources SET last_sync_at=?,last_error=? WHERE id=?`, now, message, sourceID)
	s.Logger.Error("Prometheus synchronization failed", "source_id", sourceID, "run_id", runID, "error", err)
}
func (s *Service) decryptSecret(r SourceRecord) (string, error) {
	if r.AuthMode == "none" || r.SecretCiphertext == "" {
		return "", nil
	}
	plain, err := s.Box.Decrypt(r.SecretCiphertext, "vm-doc-prometheus-secret:"+r.SecretRef)
	if err != nil {
		return "", err
	}
	return string(plain), nil
}
func (s *Service) normalizeSource(in *SourceInput, create bool) error {
	in.Name = strings.TrimSpace(in.Name)
	in.BaseURL = strings.TrimSpace(in.BaseURL)
	in.SourceType = strings.ToLower(strings.TrimSpace(in.SourceType))
	in.Username = strings.TrimSpace(in.Username)
	in.AuthMode = strings.ToLower(strings.TrimSpace(in.AuthMode))
	in.VMLabel = strings.TrimSpace(in.VMLabel)
	in.TargetLabel = strings.TrimSpace(in.TargetLabel)
	in.TLSServerName = strings.TrimSpace(in.TLSServerName)
	if in.SourceType == "" {
		in.SourceType = "metrics"
	}
	if in.AuthMode == "" {
		in.AuthMode = "none"
	}
	if in.VMLabel == "" {
		in.VMLabel = "vm_fqdn"
	}
	if in.TargetLabel == "" {
		in.TargetLabel = "instance"
	}
	if in.SyncIntervalMinutes == 0 {
		in.SyncIntervalMinutes = 15
	}
	if in.Name == "" || in.BaseURL == "" {
		return errors.New("name and base_url are required")
	}
	if in.SourceType != "metrics" && in.SourceType != "blackbox" {
		return errors.New("source_type must be metrics or blackbox")
	}
	if in.AuthMode != "none" && in.AuthMode != "basic" && in.AuthMode != "bearer" {
		return errors.New("auth_mode must be none, basic or bearer")
	}
	if in.AuthMode == "basic" && in.Username == "" {
		return errors.New("username is required for basic authentication")
	}
	if create && in.AuthMode != "none" && in.Secret == "" {
		return errors.New("secret is required for authenticated Prometheus source")
	}
	u, err := url.Parse(in.BaseURL)
	if err != nil || u.Host == "" || u.Scheme == "" {
		return errors.New("invalid base_url")
	}
	if u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return errors.New("base_url must not contain credentials, query or fragment")
	}
	if u.Scheme != "https" && !(s.Config.AllowHTTP && u.Scheme == "http") {
		return errors.New("base_url must use HTTPS unless monitoring.allow_http=true")
	}
	if in.SyncIntervalMinutes < 1 || in.SyncIntervalMinutes > 10080 {
		return errors.New("sync_interval_minutes must be between 1 and 10080")
	}
	return nil
}
func truncate(v string, n int) string {
	if len(v) > n {
		return v[:n]
	}
	return v
}

const sourceSelect = `SELECT s.id,s.secret_ref,s.name,s.base_url,s.source_type,s.username,s.auth_mode,s.secret_ciphertext,s.vm_label,s.target_label,s.enabled,s.verify_tls,s.tls_server_name,s.sync_interval_minutes,s.last_sync_at,s.last_success_at,s.last_error,s.created_at,s.updated_at FROM prometheus_sources s`

func scanSource(scanner interface{ Scan(...any) error }) (SourceRecord, error) {
	var r SourceRecord
	var lastSync, lastSuccess sql.NullTime
	err := scanner.Scan(&r.ID, &r.SecretRef, &r.Name, &r.BaseURL, &r.SourceType, &r.Username, &r.AuthMode, &r.SecretCiphertext, &r.VMLabel, &r.TargetLabel, &r.Enabled, &r.VerifyTLS, &r.TLSServerName, &r.SyncIntervalMinutes, &lastSync, &lastSuccess, &r.LastError, &r.CreatedAt, &r.UpdatedAt)
	if err != nil {
		return r, err
	}
	r.SecretConfigured = r.SecretCiphertext != ""
	if lastSync.Valid {
		t := lastSync.Time
		r.LastSyncAt = &t
	}
	if lastSuccess.Valid {
		t := lastSuccess.Time
		r.LastSuccessAt = &t
	}
	return r, nil
}

const runSelect = `SELECT r.id,r.prometheus_source_id,s.name,r.source,r.status,r.requested_by_user_id,r.started_at,r.finished_at,r.target_count,r.matched_vm_count,r.up_count,r.down_count,r.unmatched_count,r.ambiguous_count,r.error_message,r.created_at FROM prometheus_sync_runs r JOIN prometheus_sources s ON s.id=r.prometheus_source_id`

func scanRun(scanner interface{ Scan(...any) error }) (domain.PrometheusSyncRun, error) {
	var r domain.PrometheusSyncRun
	var requested sql.NullInt64
	var started, finished sql.NullTime
	err := scanner.Scan(&r.ID, &r.PrometheusSourceID, &r.PrometheusSourceName, &r.Source, &r.Status, &requested, &started, &finished, &r.TargetCount, &r.MatchedVMCount, &r.UpCount, &r.DownCount, &r.UnmatchedCount, &r.AmbiguousCount, &r.ErrorMessage, &r.CreatedAt)
	if err != nil {
		return r, err
	}
	if requested.Valid {
		v := requested.Int64
		r.RequestedByUserID = &v
	}
	if started.Valid {
		t := started.Time
		r.StartedAt = &t
	}
	if finished.Valid {
		t := finished.Time
		r.FinishedAt = &t
	}
	return r, nil
}

const targetSelect = `SELECT t.id,t.prometheus_source_id,s.name,t.source_type,t.fingerprint,t.job_name,t.instance_value,t.scrape_url,t.target_url,t.health,t.last_error,t.last_scrape_at,t.scrape_duration_seconds,t.probe_success,t.http_status_code,t.probe_duration_seconds,t.tls_expiry_at,t.labels_json,t.discovered_labels_json,t.matched_vm_id,COALESCE(vm.name,''),t.match_method,t.match_value,t.match_confidence,t.synced_at FROM monitoring_targets t JOIN prometheus_sources s ON s.id=t.prometheus_source_id LEFT JOIN virtual_machines vm ON vm.id=t.matched_vm_id`

func scanTarget(scanner interface{ Scan(...any) error }) (domain.MonitoringTarget, error) {
	var t domain.MonitoringTarget
	var lastScrape, tlsExpiry sql.NullTime
	var scrapeDur, probeDur sql.NullFloat64
	var probeSuccess sql.NullBool
	var status sql.NullInt64
	var labels, disc sql.NullString
	var vmID sql.NullInt64
	err := scanner.Scan(&t.ID, &t.PrometheusSourceID, &t.PrometheusSourceName, &t.SourceType, &t.Fingerprint, &t.JobName, &t.Instance, &t.ScrapeURL, &t.TargetURL, &t.Health, &t.LastError, &lastScrape, &scrapeDur, &probeSuccess, &status, &probeDur, &tlsExpiry, &labels, &disc, &vmID, &t.MatchedVMName, &t.MatchMethod, &t.MatchValue, &t.MatchConfidence, &t.SyncedAt)
	if err != nil {
		return t, err
	}
	if lastScrape.Valid {
		v := lastScrape.Time
		t.LastScrapeAt = &v
	}
	if scrapeDur.Valid {
		v := scrapeDur.Float64
		t.ScrapeDurationSeconds = &v
	}
	if probeSuccess.Valid {
		v := probeSuccess.Bool
		t.ProbeSuccess = &v
	}
	if status.Valid {
		v := int(status.Int64)
		t.HTTPStatusCode = &v
	}
	if probeDur.Valid {
		v := probeDur.Float64
		t.ProbeDurationSeconds = &v
	}
	if tlsExpiry.Valid {
		v := tlsExpiry.Time
		t.TLSExpiryAt = &v
	}
	if labels.Valid {
		t.LabelsJSON = json.RawMessage(labels.String)
	}
	if disc.Valid {
		t.DiscoveredLabelsJSON = json.RawMessage(disc.String)
	}
	if vmID.Valid {
		v := vmID.Int64
		t.MatchedVMID = &v
	}
	return t, nil
}
