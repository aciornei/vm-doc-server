# Upgrade vm-doc-server 0.18.3 → 0.19.0

0.19.0 adaugă fundația de monitorizare Prometheus/Blackbox. Agentul rămâne 1.6.2.

## Pași

1. Opriți `vm-doc-server`.
2. Aplicați `vm-doc-server-0.19.0-update.tar.gz` peste o copie a sursei 0.18.3.
3. În `/etc/vm-doc-server/config.yaml` adăugați secțiunea `monitoring` dacă nu există:

```yaml
monitoring:
  allow_http: true
  request_timeout: 30s
  scheduler_interval: 1m
```

`allow_http: true` este necesar numai dacă sursele Prometheus interne folosesc HTTP. Pentru HTTPS poate rămâne `false`.

4. Rulați testele/buildul offline cu `vendor/`.
5. Instalați binarul `vm-doc-server` și porniți serviciul. Collectorul și agentul nu necesită upgrade.
6. Verificați aplicarea migrației `038_prometheus_monitoring_foundation.up.sql`.
7. Faceți `Ctrl+F5` și deschideți meniul **Monitorizare**.
8. Adăugați mai întâi sursa Prometheus `metrics`, rulați **Test**, apoi **Sync**. Adăugați separat sursa `blackbox` și repetați.

## Corelare

Corelarea targeturilor este: label explicit → FQDN → hostname → IP → alias manual. Nu este necesară copierea `/etc/hosts` de pe Prometheus în vm-doc.
