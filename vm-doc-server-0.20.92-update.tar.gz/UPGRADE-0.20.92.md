# Upgrade VM-DOC Server 0.20.91 → 0.20.92

Hotfix exclusiv frontend.

1. Oprește `vm-doc-server`.
2. Aplică update-ul peste sursa/instalarea 0.20.91.
3. Recompilează/repornește serverul conform procedurii curente.
4. În browser fă `Ctrl+F5` pentru a elimina `app.js` 0.20.91 din cache.

Nu există migrare DB și nu este necesar update de agent.
