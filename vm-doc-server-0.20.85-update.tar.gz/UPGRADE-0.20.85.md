# Upgrade VM-DOC Server 0.20.84 → 0.20.85

0.20.85 repară filtrarea regulilor firewall locale în fișa VM. Nu există migrare DB și nu este necesar update de agent.

## Upgrade offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.84 vm-doc-server-0.20.85
tar -xzf /cale/vm-doc-server-0.20.85-update.tar.gz -C vm-doc-server-0.20.85
cd vm-doc-server-0.20.85
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

După upgrade: `Ctrl+F5`.

## Verificare

1. Deschide o VM care anterior afișa multe reguli UFW/nftables.
2. În Firewall nu trebuie să mai apară lanțurile tehnice `ufw-before-*`, `ufw-after-*`, logging/jump.
3. Reguli explicite din `ufw-user-*` trebuie să rămână vizibile.
4. Generează din nou fișa VM; aceeași filtrare trebuie să se aplice în DOCX și Markdown/Outline.
5. Pe un host cu nftables/iptables configurat direct, fără UFW/firewalld/SuSEfirewall2, regulile directe trebuie să rămână documentate.
