package server

import (
	"context"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/xlsx"
)

type securityReviewReportRow struct {
	VMID            int64      `json:"vm_id"`
	VMName          string     `json:"vm_name"`
	AgentName       string     `json:"agent_name,omitempty"`
	AgentVersion    string     `json:"agent_version,omitempty"`
	ResourceType    string     `json:"resource_type"`
	ResourceName    string     `json:"resource_name"`
	ResourceKey     string     `json:"resource_key"`
	Indicators      []string   `json:"indicators,omitempty"`
	Risk            string     `json:"risk"`
	ReviewedAt      *time.Time `json:"reviewed_at,omitempty"`
	NextReviewAt    *time.Time `json:"next_review_at,omitempty"`
	DaysUntilReview *int       `json:"days_until_review,omitempty"`
	IntervalMonths  int        `json:"interval_months"`
	Justified       *bool      `json:"justified,omitempty"`
	ReviewedBy      string     `json:"reviewed_by,omitempty"`
	Notes           string     `json:"notes,omitempty"`
	Status          string     `json:"status"`
}

type securityReviewReportVMFacet struct {
	ID   int64  `json:"id"`
	Name string `json:"name"`
}

type securityReviewReportFacets struct {
	VMs           []securityReviewReportVMFacet `json:"vms"`
	AgentVersions []string                      `json:"agent_versions"`
	Reviewers     []string                      `json:"reviewers"`
}

type securityReviewReportSummary struct {
	Total       int `json:"total"`
	Unreviewed  int `json:"unreviewed"`
	Overdue     int `json:"overdue"`
	DueToday    int `json:"due_today"`
	ThisWeek    int `json:"this_week"`
	NextWeek    int `json:"next_week"`
	ThisMonth   int `json:"this_month"`
	NextMonth   int `json:"next_month"`
	NextThirty  int `json:"next_30_days"`
	HighRisk    int `json:"high_risk"`
	Unjustified int `json:"unjustified"`
}

type securityReviewReportResponse struct {
	GeneratedAt time.Time                   `json:"generated_at"`
	Timezone    string                      `json:"timezone"`
	Summary     securityReviewReportSummary `json:"summary"`
	Facets      securityReviewReportFacets  `json:"facets"`
	Items       []securityReviewReportRow   `json:"items"`
	Page        int                         `json:"page"`
	PageSize    int                         `json:"page_size"`
	Total       int                         `json:"total"`
	Pages       int                         `json:"pages"`
}

type securityReviewReportAgent struct {
	Name    string
	Version string
}

type securityReviewReportFilter struct {
	Q            string
	VMID         int64
	AgentVersion string
	Category     string
	Status       string
	Period       string
	Reviewer     string
	Justified    string
	Risk         string
	LastFrom     string
	LastTo       string
	NextFrom     string
	NextTo       string
	DaysMin      *int
	DaysMax      *int
}

func (a *App) securityReviewReportLocation() *time.Location {
	zone := strings.TrimSpace(a.Config.App.Timezone)
	if zone == "" {
		zone = "Europe/Bucharest"
	}
	loc, err := time.LoadLocation(zone)
	if err != nil {
		return time.UTC
	}
	return loc
}

func securityReviewCalendarDayDiff(now, target time.Time, loc *time.Location) int {
	n := now.In(loc)
	t := target.In(loc)
	nDay := time.Date(n.Year(), n.Month(), n.Day(), 0, 0, 0, 0, time.UTC)
	tDay := time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, time.UTC)
	return int(tDay.Sub(nDay) / (24 * time.Hour))
}

func securityReviewWeekStart(value time.Time, loc *time.Location) time.Time {
	v := value.In(loc)
	day := time.Date(v.Year(), v.Month(), v.Day(), 0, 0, 0, 0, loc)
	offset := (int(day.Weekday()) + 6) % 7 // Monday=0
	return day.AddDate(0, 0, -offset)
}

func securityReviewReportPeriodMatch(row securityReviewReportRow, period string, now time.Time, loc *time.Location) bool {
	period = strings.ToLower(strings.TrimSpace(period))
	if period == "" {
		return true
	}
	if period == "unreviewed" {
		return row.ReviewedAt == nil
	}
	if row.NextReviewAt == nil {
		return false
	}
	target := row.NextReviewAt.In(loc)
	today := now.In(loc)
	todayStart := time.Date(today.Year(), today.Month(), today.Day(), 0, 0, 0, 0, loc)
	targetDay := time.Date(target.Year(), target.Month(), target.Day(), 0, 0, 0, 0, loc)
	weekStart := securityReviewWeekStart(now, loc)
	nextWeek := weekStart.AddDate(0, 0, 7)
	afterNextWeek := nextWeek.AddDate(0, 0, 7)
	monthStart := time.Date(today.Year(), today.Month(), 1, 0, 0, 0, 0, loc)
	nextMonth := monthStart.AddDate(0, 1, 0)
	afterNextMonth := monthStart.AddDate(0, 2, 0)
	switch period {
	case "overdue":
		return row.ReviewedAt != nil && row.NextReviewAt.Before(now)
	case "today":
		return targetDay.Equal(todayStart)
	case "this_week":
		return !targetDay.Before(todayStart) && targetDay.Before(nextWeek)
	case "next_week":
		return !targetDay.Before(nextWeek) && targetDay.Before(afterNextWeek)
	case "this_month":
		return !targetDay.Before(todayStart) && targetDay.Before(nextMonth)
	case "next_month":
		return !targetDay.Before(nextMonth) && targetDay.Before(afterNextMonth)
	case "next_30_days":
		days := securityReviewCalendarDayDiff(now, *row.NextReviewAt, loc)
		return days >= 0 && days <= 30
	}
	return true
}

func securityReviewReportStatus(row securityReviewReportRow, now time.Time, loc *time.Location) string {
	if row.ReviewedAt == nil {
		return "unreviewed"
	}
	if row.NextReviewAt == nil {
		return "unreviewed"
	}
	if row.NextReviewAt.Before(now) {
		return "overdue"
	}
	days := securityReviewCalendarDayDiff(now, *row.NextReviewAt, loc)
	if days == 0 {
		return "today"
	}
	if days <= 30 {
		return "due_30"
	}
	return "current"
}

func (a *App) securityReviewReportAgentMap(ctx context.Context) (map[int64]securityReviewReportAgent, error) {
	rows, err := a.DB.QueryContext(ctx, `SELECT vm.id,COALESCE(a.name,''),COALESCE(NULLIF(a.agent_version,''),NULLIF(i.agent_version,''),'') FROM virtual_machines vm LEFT JOIN agents a ON a.id=vm.agent_id LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := map[int64]securityReviewReportAgent{}
	for rows.Next() {
		var id int64
		var item securityReviewReportAgent
		if err := rows.Scan(&id, &item.Name, &item.Version); err != nil {
			return nil, err
		}
		out[id] = item
	}
	return out, rows.Err()
}

func securityReviewReportAccountIndicators(item securityAccount, now time.Time) ([]string, string) {
	indicators := make([]string, 0, 5)
	risk := "normal"
	if item.Privileged {
		indicators = append(indicators, "Privilegiat")
		risk = "high"
	}
	if item.LoginCapable {
		indicators = append(indicators, "Login")
		if risk == "normal" {
			risk = "attention"
		}
	}
	if strings.EqualFold(item.PasswordStatus, "empty") {
		indicators = append(indicators, "Parolă goală")
		risk = "high"
	}
	if item.PasswordExpiresAt != nil && item.PasswordExpiresAt.Before(now) {
		indicators = append(indicators, "Parolă expirată")
		risk = "high"
	}
	if item.AccountExpiresAt != nil && item.AccountExpiresAt.Before(now) {
		indicators = append(indicators, "Cont expirat")
		if risk == "normal" {
			risk = "attention"
		}
	}
	if item.SystemAccount && !strings.EqualFold(item.Username, "root") {
		indicators = append(indicators, "System")
	}
	return indicators, risk
}

func securityReviewReportDatabaseIndicators(item securityDatabase) ([]string, string) {
	indicators := make([]string, 0, 6)
	risk := "normal"
	hbaWarnings := 0
	for _, rule := range item.HBARules {
		if rule.Warning {
			hbaWarnings++
		}
	}
	if hbaWarnings > 0 {
		indicators = append(indicators, fmt.Sprintf("HBA warning ×%d", hbaWarnings))
		risk = "high"
	}
	privileged := 0
	for _, p := range item.Principals {
		isPrivileged := p.Superuser || p.CreateRole || p.CreateDB || p.Replication
		for _, role := range p.Roles {
			switch strings.ToLower(strings.TrimSpace(role)) {
			case "sysadmin", "securityadmin", "serveradmin", "db_owner", "db_securityadmin":
				isPrivileged = true
			}
		}
		if isPrivileged {
			privileged++
		}
	}
	if privileged > 0 {
		indicators = append(indicators, fmt.Sprintf("Privilegiate ×%d", privileged))
		risk = "high"
	}
	grantable := 0
	deny := 0
	for _, privilege := range item.Privileges {
		if privilege.Grantable {
			grantable++
		}
		if strings.EqualFold(strings.TrimSpace(privilege.State), "deny") {
			deny++
		}
	}
	if grantable > 0 {
		indicators = append(indicators, fmt.Sprintf("GRANT OPTION ×%d", grantable))
		if risk == "normal" {
			risk = "attention"
		}
	}
	if deny > 0 {
		indicators = append(indicators, fmt.Sprintf("DENY ×%d", deny))
	}
	if len(indicators) == 0 {
		indicators = append(indicators, "Fără indicator")
	}
	return indicators, risk
}

func securityReviewReportWebIndicators(item securityWebSite) ([]string, string) {
	indicators := make([]string, 0, 3)
	risk := "normal"
	allowAll := 0
	for _, rule := range item.Rules {
		if rule.Warning {
			allowAll++
		}
	}
	if allowAll > 0 {
		indicators = append(indicators, fmt.Sprintf("ALLOW ALL ×%d", allowAll))
		risk = "high"
	}
	if len(item.Rules) == 0 {
		indicators = append(indicators, "Fără ACL explicit")
		if risk == "normal" {
			risk = "attention"
		}
	} else {
		indicators = append(indicators, fmt.Sprintf("ACL ×%d", len(item.Rules)))
	}
	return indicators, risk
}

func securityReviewReportResourceNameDatabase(item securityDatabase) string {
	product := strings.TrimSpace(item.Product)
	if product == "" {
		product = strings.TrimSpace(item.Engine)
	}
	instance := strings.TrimSpace(item.InstanceName)
	if instance == "" {
		instance = "default"
	}
	return product + " · " + instance
}

func securityReviewReportResourceNameWeb(item securityWebSite) string {
	name := strings.TrimSpace(item.Name)
	if name == "" && len(item.ServerNames) > 0 {
		name = strings.TrimSpace(item.ServerNames[0])
	}
	if name == "" {
		name = "vhost"
	}
	if engine := strings.TrimSpace(item.Engine); engine != "" {
		return engine + " · " + name
	}
	return name
}

func securityReviewReportApplyReview(row *securityReviewReportRow, review securityReview, now time.Time, loc *time.Location) {
	row.IntervalMonths = review.IntervalMonths
	row.ReviewedAt = review.ReviewedAt
	row.NextReviewAt = review.NextReviewAt
	row.ReviewedBy = review.ReviewedBy
	row.Notes = review.Notes
	if review.ReviewedAt != nil {
		value := review.Justified
		row.Justified = &value
	}
	if review.NextReviewAt != nil {
		days := securityReviewCalendarDayDiff(now, *review.NextReviewAt, loc)
		row.DaysUntilReview = &days
	}
	row.Status = securityReviewReportStatus(*row, now, loc)
}

func (a *App) securityReviewReportRows(ctx context.Context) ([]securityReviewReportRow, securityReviewReportSummary, securityReviewReportFacets, error) {
	reviews, err := a.loadSecurityReviews(ctx)
	if err != nil {
		return nil, securityReviewReportSummary{}, securityReviewReportFacets{}, err
	}
	security := securityResponse{GeneratedAt: time.Now().UTC(), Accounts: []securityAccount{}, Databases: []securityDatabase{}, WebSites: []securityWebSite{}}
	if err := a.loadSecurityAccounts(ctx, reviews, &security, 0); err != nil {
		return nil, securityReviewReportSummary{}, securityReviewReportFacets{}, err
	}
	if err := a.loadSecurityDatabases(ctx, reviews, &security, 0); err != nil {
		return nil, securityReviewReportSummary{}, securityReviewReportFacets{}, err
	}
	if err := a.loadSecurityWeb(ctx, reviews, &security, 0); err != nil {
		return nil, securityReviewReportSummary{}, securityReviewReportFacets{}, err
	}
	agents, err := a.securityReviewReportAgentMap(ctx)
	if err != nil {
		return nil, securityReviewReportSummary{}, securityReviewReportFacets{}, err
	}
	now := time.Now().UTC()
	loc := a.securityReviewReportLocation()
	items := make([]securityReviewReportRow, 0, len(security.Accounts)+len(security.Databases)+len(security.WebSites))
	appendBase := func(row securityReviewReportRow, review securityReview) {
		agent := agents[row.VMID]
		row.AgentName = agent.Name
		row.AgentVersion = agent.Version
		securityReviewReportApplyReview(&row, review, now, loc)
		items = append(items, row)
	}
	for _, account := range security.Accounts {
		if !securityAccountRelevant(account) && account.Review.ReviewedAt == nil {
			continue
		}
		indicators, risk := securityReviewReportAccountIndicators(account, now)
		appendBase(securityReviewReportRow{VMID: account.VMID, VMName: account.VMName, ResourceType: "vm_account", ResourceName: account.Username, ResourceKey: account.Username, Indicators: indicators, Risk: risk}, account.Review)
	}
	for _, db := range security.Databases {
		indicators, risk := securityReviewReportDatabaseIndicators(db)
		appendBase(securityReviewReportRow{VMID: db.VMID, VMName: db.VMName, ResourceType: "database", ResourceName: securityReviewReportResourceNameDatabase(db), ResourceKey: strconv.FormatInt(db.ID, 10), Indicators: indicators, Risk: risk}, db.Review)
	}
	for _, site := range security.WebSites {
		indicators, risk := securityReviewReportWebIndicators(site)
		appendBase(securityReviewReportRow{VMID: site.VMID, VMName: site.VMName, ResourceType: "web", ResourceName: securityReviewReportResourceNameWeb(site), ResourceKey: strconv.FormatInt(site.ID, 10), Indicators: indicators, Risk: risk}, site.Review)
	}

	summary := securityReviewReportSummary{Total: len(items)}
	vmMap := map[int64]string{}
	versionSet := map[string]struct{}{}
	reviewerSet := map[string]struct{}{}
	for _, item := range items {
		vmMap[item.VMID] = item.VMName
		if strings.TrimSpace(item.AgentVersion) != "" {
			versionSet[item.AgentVersion] = struct{}{}
		}
		if strings.TrimSpace(item.ReviewedBy) != "" {
			reviewerSet[item.ReviewedBy] = struct{}{}
		}
		if item.ReviewedAt == nil {
			summary.Unreviewed++
		}
		if item.ReviewedAt != nil && item.NextReviewAt != nil && item.NextReviewAt.Before(now) {
			summary.Overdue++
		}
		if item.Risk == "high" {
			summary.HighRisk++
		}
		if item.Justified != nil && !*item.Justified {
			summary.Unjustified++
		}
		if securityReviewReportPeriodMatch(item, "today", now, loc) {
			summary.DueToday++
		}
		if securityReviewReportPeriodMatch(item, "this_week", now, loc) {
			summary.ThisWeek++
		}
		if securityReviewReportPeriodMatch(item, "next_week", now, loc) {
			summary.NextWeek++
		}
		if securityReviewReportPeriodMatch(item, "this_month", now, loc) {
			summary.ThisMonth++
		}
		if securityReviewReportPeriodMatch(item, "next_month", now, loc) {
			summary.NextMonth++
		}
		if securityReviewReportPeriodMatch(item, "next_30_days", now, loc) {
			summary.NextThirty++
		}
	}
	facets := securityReviewReportFacets{VMs: make([]securityReviewReportVMFacet, 0, len(vmMap)), AgentVersions: make([]string, 0, len(versionSet)), Reviewers: make([]string, 0, len(reviewerSet))}
	for id, name := range vmMap {
		facets.VMs = append(facets.VMs, securityReviewReportVMFacet{ID: id, Name: name})
	}
	sort.Slice(facets.VMs, func(i, j int) bool { return strings.ToLower(facets.VMs[i].Name) < strings.ToLower(facets.VMs[j].Name) })
	for value := range versionSet {
		facets.AgentVersions = append(facets.AgentVersions, value)
	}
	sort.Strings(facets.AgentVersions)
	for value := range reviewerSet {
		facets.Reviewers = append(facets.Reviewers, value)
	}
	sort.Strings(facets.Reviewers)
	return items, summary, facets, nil
}

func parseSecurityReviewReportFilter(r *http.Request) securityReviewReportFilter {
	var vmID int64
	if raw := strings.TrimSpace(r.URL.Query().Get("vm_id")); raw != "" {
		vmID, _ = strconv.ParseInt(raw, 10, 64)
	}
	parseOptionalInt := func(name string) *int {
		raw := strings.TrimSpace(r.URL.Query().Get(name))
		if raw == "" {
			return nil
		}
		value, err := strconv.Atoi(raw)
		if err != nil {
			return nil
		}
		return &value
	}
	return securityReviewReportFilter{
		Q:            strings.ToLower(strings.TrimSpace(r.URL.Query().Get("q"))),
		VMID:         vmID,
		AgentVersion: strings.TrimSpace(r.URL.Query().Get("agent_version")),
		Category:     strings.ToLower(strings.TrimSpace(r.URL.Query().Get("category"))),
		Status:       strings.ToLower(strings.TrimSpace(r.URL.Query().Get("status"))),
		Period:       strings.ToLower(strings.TrimSpace(r.URL.Query().Get("period"))),
		Reviewer:     strings.TrimSpace(r.URL.Query().Get("reviewer")),
		Justified:    strings.ToLower(strings.TrimSpace(r.URL.Query().Get("justified"))),
		Risk:         strings.ToLower(strings.TrimSpace(r.URL.Query().Get("risk"))),
		LastFrom:     strings.TrimSpace(r.URL.Query().Get("last_from")),
		LastTo:       strings.TrimSpace(r.URL.Query().Get("last_to")),
		NextFrom:     strings.TrimSpace(r.URL.Query().Get("next_from")),
		NextTo:       strings.TrimSpace(r.URL.Query().Get("next_to")),
		DaysMin:      parseOptionalInt("days_min"),
		DaysMax:      parseOptionalInt("days_max"),
	}
}

func securityReviewReportDateRangeMatch(value *time.Time, from, to string, loc *time.Location) bool {
	if strings.TrimSpace(from) == "" && strings.TrimSpace(to) == "" {
		return true
	}
	if value == nil {
		return false
	}
	v := value.In(loc)
	day := time.Date(v.Year(), v.Month(), v.Day(), 0, 0, 0, 0, loc)
	if from != "" {
		if parsed, err := time.ParseInLocation("2006-01-02", from, loc); err == nil && day.Before(parsed) {
			return false
		}
	}
	if to != "" {
		if parsed, err := time.ParseInLocation("2006-01-02", to, loc); err == nil && day.After(parsed) {
			return false
		}
	}
	return true
}

func securityReviewReportMatches(item securityReviewReportRow, f securityReviewReportFilter, now time.Time, loc *time.Location) bool {
	if f.Q != "" {
		haystack := strings.ToLower(strings.Join([]string{item.VMName, item.AgentName, item.AgentVersion, item.ResourceType, item.ResourceName, strings.Join(item.Indicators, " "), item.ReviewedBy, item.Notes}, " "))
		if !strings.Contains(haystack, f.Q) {
			return false
		}
	}
	if f.VMID > 0 && item.VMID != f.VMID {
		return false
	}
	if f.AgentVersion != "" {
		if f.AgentVersion == "__none__" {
			if strings.TrimSpace(item.AgentVersion) != "" {
				return false
			}
		} else if item.AgentVersion != f.AgentVersion {
			return false
		}
	}
	if f.Category != "" && item.ResourceType != f.Category {
		return false
	}
	if f.Status != "" {
		switch f.Status {
		case "unreviewed", "overdue", "today", "due_30", "current":
			if item.Status != f.Status {
				return false
			}
		case "due":
			if item.Status != "unreviewed" && item.Status != "overdue" && item.Status != "today" && item.Status != "due_30" {
				return false
			}
		}
	}
	if !securityReviewReportPeriodMatch(item, f.Period, now, loc) {
		return false
	}
	if f.Reviewer != "" && item.ReviewedBy != f.Reviewer {
		return false
	}
	if f.Justified != "" {
		switch f.Justified {
		case "yes":
			if item.Justified == nil || !*item.Justified {
				return false
			}
		case "no":
			if item.Justified == nil || *item.Justified {
				return false
			}
		case "unknown":
			if item.Justified != nil {
				return false
			}
		}
	}
	if f.Risk != "" && item.Risk != f.Risk {
		return false
	}
	if !securityReviewReportDateRangeMatch(item.ReviewedAt, f.LastFrom, f.LastTo, loc) {
		return false
	}
	if !securityReviewReportDateRangeMatch(item.NextReviewAt, f.NextFrom, f.NextTo, loc) {
		return false
	}
	if f.DaysMin != nil {
		if item.DaysUntilReview == nil || *item.DaysUntilReview < *f.DaysMin {
			return false
		}
	}
	if f.DaysMax != nil {
		if item.DaysUntilReview == nil || *item.DaysUntilReview > *f.DaysMax {
			return false
		}
	}
	return true
}

func securityReviewReportSort(items []securityReviewReportRow) {
	statusPriority := func(item securityReviewReportRow) int {
		switch item.Status {
		case "unreviewed":
			return 0
		case "overdue":
			return 1
		case "today":
			return 2
		case "due_30":
			return 3
		default:
			return 4
		}
	}
	sort.SliceStable(items, func(i, j int) bool {
		pi, pj := statusPriority(items[i]), statusPriority(items[j])
		if pi != pj {
			return pi < pj
		}
		if items[i].DaysUntilReview != nil && items[j].DaysUntilReview != nil && *items[i].DaysUntilReview != *items[j].DaysUntilReview {
			return *items[i].DaysUntilReview < *items[j].DaysUntilReview
		}
		if items[i].DaysUntilReview == nil && items[j].DaysUntilReview != nil {
			return true
		}
		if items[i].DaysUntilReview != nil && items[j].DaysUntilReview == nil {
			return false
		}
		if !strings.EqualFold(items[i].VMName, items[j].VMName) {
			return strings.ToLower(items[i].VMName) < strings.ToLower(items[j].VMName)
		}
		if items[i].ResourceType != items[j].ResourceType {
			return items[i].ResourceType < items[j].ResourceType
		}
		return strings.ToLower(items[i].ResourceName) < strings.ToLower(items[j].ResourceName)
	})
}

func (a *App) reportsSecurityReviews(w http.ResponseWriter, r *http.Request) {
	items, summary, facets, err := a.securityReviewReportRows(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	filter := parseSecurityReviewReportFilter(r)
	now := time.Now().UTC()
	loc := a.securityReviewReportLocation()
	filtered := make([]securityReviewReportRow, 0, len(items))
	for _, item := range items {
		if securityReviewReportMatches(item, filter, now, loc) {
			filtered = append(filtered, item)
		}
	}
	securityReviewReportSort(filtered)
	page := 1
	if raw := strings.TrimSpace(r.URL.Query().Get("page")); raw != "" {
		if parsed, err := strconv.Atoi(raw); err == nil {
			page = parsed
		}
	}
	pageSize := 50
	if raw := strings.TrimSpace(r.URL.Query().Get("page_size")); raw != "" {
		if parsed, err := strconv.Atoi(raw); err == nil {
			pageSize = parsed
		}
	}
	if page < 1 {
		page = 1
	}
	if pageSize != 25 && pageSize != 50 && pageSize != 100 && pageSize != 200 {
		pageSize = 50
	}
	total := len(filtered)
	pages := (total + pageSize - 1) / pageSize
	if pages < 1 {
		pages = 1
	}
	if page > pages {
		page = pages
	}
	start := (page - 1) * pageSize
	end := start + pageSize
	if start > total {
		start = total
	}
	if end > total {
		end = total
	}
	jsonResponse(w, http.StatusOK, securityReviewReportResponse{
		GeneratedAt: time.Now().UTC(),
		Timezone:    loc.String(),
		Summary:     summary,
		Facets:      facets,
		Items:       filtered[start:end],
		Page:        page,
		PageSize:    pageSize,
		Total:       total,
		Pages:       pages,
	})
}

func securityReviewReportCategoryLabel(value string) string {
	switch value {
	case "vm_account":
		return "Cont VM"
	case "database":
		return "Bază de date"
	case "web":
		return "Web ACL"
	default:
		return value
	}
}

func securityReviewReportStatusLabel(value string) string {
	switch value {
	case "unreviewed":
		return "Nerevizuit"
	case "overdue":
		return "Expirat"
	case "today":
		return "Astăzi"
	case "due_30":
		return "În 30 zile"
	case "current":
		return "La zi"
	default:
		return value
	}
}

func securityReviewReportBoolText(value *bool) string {
	if value == nil {
		return "Nerevizuit"
	}
	if *value {
		return "Da"
	}
	return "Nu"
}

func securityReviewReportTimeText(value *time.Time, loc *time.Location) string {
	if value == nil {
		return ""
	}
	return value.In(loc).Format("2006-01-02 15:04")
}

func securityReviewReportDaysText(value *int) string {
	if value == nil {
		return "Necesită review inițial"
	}
	if *value < 0 {
		return fmt.Sprintf("Depășit cu %d zile", -*value)
	}
	if *value == 0 {
		return "Astăzi"
	}
	return fmt.Sprintf("În %d zile", *value)
}

func (a *App) exportReportSecurityReviews(w http.ResponseWriter, r *http.Request) {
	items, _, _, err := a.securityReviewReportRows(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	filter := parseSecurityReviewReportFilter(r)
	now := time.Now().UTC()
	loc := a.securityReviewReportLocation()
	filtered := make([]securityReviewReportRow, 0, len(items))
	for _, item := range items {
		if securityReviewReportMatches(item, filter, now, loc) {
			filtered = append(filtered, item)
		}
	}
	securityReviewReportSort(filtered)
	rows := [][]xlsx.Cell{{
		xlsx.Text("VM"), xlsx.Text("Agent"), xlsx.Text("Versiune agent"), xlsx.Text("Categorie"), xlsx.Text("Resursă"), xlsx.Text("Indicatori"), xlsx.Text("Risc"), xlsx.Text("Ultimul review"), xlsx.Text("Următorul review"), xlsx.Text("Peste / de câte zile"), xlsx.Text("Interval luni"), xlsx.Text("Justificat"), xlsx.Text("Revizuit de"), xlsx.Text("Status"), xlsx.Text("Observații"),
	}}
	for _, item := range filtered {
		daysValue := ""
		if item.DaysUntilReview != nil {
			daysValue = strconv.Itoa(*item.DaysUntilReview)
		}
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(item.VMName), xlsx.Text(item.AgentName), xlsx.Text(item.AgentVersion), xlsx.Text(securityReviewReportCategoryLabel(item.ResourceType)), xlsx.Text(item.ResourceName), xlsx.Text(strings.Join(item.Indicators, ", ")), xlsx.Text(item.Risk), xlsx.Text(securityReviewReportTimeText(item.ReviewedAt, loc)), xlsx.Text(securityReviewReportTimeText(item.NextReviewAt, loc)), xlsx.Text(daysValue), xlsx.Number(float64(item.IntervalMonths)), xlsx.Text(securityReviewReportBoolText(item.Justified)), xlsx.Text(item.ReviewedBy), xlsx.Text(securityReviewReportStatusLabel(item.Status)), xlsx.Text(item.Notes),
		})
	}
	if err := writeXLSXResponse(w, "Revizii securitate", "revizii-securitate", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write security review report XLSX", "error", err)
	}
}
