package server

import (
	"testing"
	"time"
)

func TestSecurityReviewCalendarDayDiffAcrossDST(t *testing.T) {
	loc, err := time.LoadLocation("Europe/Bucharest")
	if err != nil {
		t.Fatal(err)
	}
	now := time.Date(2026, 3, 28, 12, 0, 0, 0, loc)
	target := time.Date(2026, 3, 30, 12, 0, 0, 0, loc)
	if got := securityReviewCalendarDayDiff(now, target, loc); got != 2 {
		t.Fatalf("expected 2 calendar days, got %d", got)
	}
}

func TestSecurityReviewReportPeriods(t *testing.T) {
	loc, err := time.LoadLocation("Europe/Bucharest")
	if err != nil {
		t.Fatal(err)
	}
	// Monday, 5 October 2026.
	now := time.Date(2026, 10, 5, 9, 0, 0, 0, loc)
	thisFriday := time.Date(2026, 10, 9, 10, 0, 0, 0, loc)
	nextMonday := time.Date(2026, 10, 12, 10, 0, 0, 0, loc)
	nextMonth := time.Date(2026, 11, 3, 10, 0, 0, 0, loc)
	reviewed := now.AddDate(0, -6, 0)

	row := securityReviewReportRow{ReviewedAt: &reviewed, NextReviewAt: &thisFriday}
	if !securityReviewReportPeriodMatch(row, "this_week", now, loc) {
		t.Fatal("expected this Friday to match this_week")
	}
	if securityReviewReportPeriodMatch(row, "next_week", now, loc) {
		t.Fatal("did not expect this Friday to match next_week")
	}

	row.NextReviewAt = &nextMonday
	if !securityReviewReportPeriodMatch(row, "next_week", now, loc) {
		t.Fatal("expected next Monday to match next_week")
	}

	row.NextReviewAt = &nextMonth
	if !securityReviewReportPeriodMatch(row, "next_month", now, loc) {
		t.Fatal("expected 3 November to match next_month")
	}
	if !securityReviewReportPeriodMatch(row, "next_30_days", now, loc) {
		t.Fatal("expected 3 November to be in next 30 days")
	}
}

func TestSecurityReviewReportUnreviewed(t *testing.T) {
	loc := time.UTC
	now := time.Date(2026, 10, 5, 9, 0, 0, 0, loc)
	row := securityReviewReportRow{}
	if got := securityReviewReportStatus(row, now, loc); got != "unreviewed" {
		t.Fatalf("expected unreviewed, got %s", got)
	}
	if !securityReviewReportPeriodMatch(row, "unreviewed", now, loc) {
		t.Fatal("expected unreviewed period match")
	}
}
