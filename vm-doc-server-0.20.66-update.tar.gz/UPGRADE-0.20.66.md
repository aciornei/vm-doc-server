# Upgrade VM-DOC Server 0.20.65 → 0.20.66

0.20.66 adaugă raportul **Rapoarte → Revizii securitate** și exportul Excel pentru planificarea Access Review.

Nu există migrare DB nouă și nu este necesar agent nou. `vm-doc-agent 1.7.12` rămâne recomandat.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.65 /usr/local/src/vm-doc-server-0.20.66
tar -xzf vm-doc-server-0.20.66-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.66
cd /usr/local/src/vm-doc-server-0.20.66
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server` și fă `Ctrl+F5` în browser.
