# VM-DOC Server 0.21.100 — Corecție RAR Anexa 6 (2026-11-16)

Bază: **0.21.99**. Agent: **1.7.18** (nemodificat). SQL: **fără migrare nouă**.

## Problemă și cauză
În RAR Anexa 6 → Produse software · Inventar agregat, filtrul `Mediu=PROD` putea returna zero VM-uri, inclusiv când era combinat cu `Power=Pornite`. Citirea mediului se făcea exclusiv din câmpul legacy `vm_operational_metadata.environment`; mediul ales prin nomenclator era ignorat. De asemenea, comparația mediului nu trata drept echivalente etichetele `PROD`, `Production`, `Productie`, `Producție` și `Producţie`.

## Corecție
- La citirea VM-urilor se folosește cu prioritate `vm_operational_nomenclatures` și `nomenclature_items` pentru categoria `environment`, cu fallback pe `vm_operational_metadata.environment`.
- Filtrarea normalizează denumirile uzuale PROD/TEST/DEV; Power continuă să folosească `POWERED_ON` din vCenter. VM-uri retrase sau absente din VCSA nu devin eligibile.
- Interfața a fost reorganizată în căutare separată, Filtre VM (vCenter, Mediu, Power), Filtre inventar (OS, categorie, componentă), versiuni și resetare; un rezumat arată filtrele active, cu mesaj când nu există VM-uri eligibile.
- Exportul Word reutilizează interogarea filtrată; celelalte două rapoarte RAR și detectarea componentelor software rămân neschimbate.

## Fișiere modificate
`internal/server/rar_software_catalog_report.go`, `internal/server/rar_software_catalog_report_test.go`, `web/static/js/app.js`, `web/static/css/app.css`, `web/static/index.html`, `web/static/releases.json`, `VERSION`, `openapi/openapi.yaml` (doar versiune), `CHANGELOG.md`, `CONTEXT.md`, `docs/TODO.md`, `VM-DOC-TODO.md`, instrucțiuni și note release.

## Validare
- `node --check web/static/js/app.js`: trecut.
- Teste izolate cu funcțiile reale din sursa Go: agregare, denumiri OS și regresie **PROD + Pornite** cu etichete `Producție`/`Production`, plus **PROD + Oprite** și **TEST + Pornite`: trecute.
- Interogarea SQL revizuită static; codul este compatibil cu schema nomenclatoarelor existentă (cheie unică VM + categorie).
- **Netratate:** build complet Go și test MariaDB/VCSA pe date reale (mediul de generare nu are `vendor/` și modulele necesare). Testați în staging înainte de producție.
