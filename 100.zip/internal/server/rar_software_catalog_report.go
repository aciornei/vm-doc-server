package server

import (
	"context"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/documents"
)

// RAR Anexa 6: technology inventory. This is an aggregated report, not a list
// of packages installed on every VM. It reuses the curated component detector.
type rarCatalogEntry struct {
	Name     string   `json:"name"`
	VMCount  int      `json:"vm_count"`
	Versions []string `json:"versions,omitempty"`
}
type rarCatalogCategory struct {
	Name       string            `json:"name"`
	Components []rarCatalogEntry `json:"components"`
}
type rarCatalogOption struct {
	Value string `json:"value"`
	Label string `json:"label"`
}
type rarCatalogOptions struct {
	Sources          []rarCatalogOption `json:"sources"`
	OperatingSystems []rarCatalogOption `json:"operating_systems"`
	Categories       []rarCatalogOption `json:"categories"`
	Components       []rarCatalogOption `json:"components"`
}
type rarCatalogResponse struct {
	GeneratedAt      time.Time            `json:"generated_at"`
	OperatingSystems []rarCatalogEntry    `json:"operating_systems"`
	Categories       []rarCatalogCategory `json:"categories"`
	Options          rarCatalogOptions    `json:"options"`
	Summary          struct {
		VMs        int `json:"vms"`
		OS         int `json:"operating_systems"`
		Categories int `json:"categories"`
		Components int `json:"components"`
	} `json:"summary"`
}
type rarCatalogFilters struct {
	Query, Source, OS, Category, Component, Power, Environment string
	Versions                                                   bool
}

func rarCatalogParseFilters(r *http.Request) (rarCatalogFilters, error) {
	q := r.URL.Query()
	f := rarCatalogFilters{Query: strings.TrimSpace(q.Get("q")), Source: strings.TrimSpace(q.Get("source")), OS: strings.TrimSpace(q.Get("os")), Category: strings.TrimSpace(q.Get("category")), Component: strings.TrimSpace(q.Get("component")), Power: strings.TrimSpace(q.Get("power")), Environment: strings.TrimSpace(q.Get("environment")), Versions: q.Get("versions") != "0"}
	if len(f.Query) > 200 || len(f.OS) > 255 || len(f.Category) > 190 || len(f.Component) > 190 || len(f.Environment) > 64 {
		return f, fmt.Errorf("filtru prea lung")
	}
	if f.Source != "" {
		if _, err := strconv.ParseInt(f.Source, 10, 64); err != nil {
			return f, fmt.Errorf("vCenter invalid")
		}
	}
	if f.Power != "" && f.Power != "on" && f.Power != "off" {
		return f, fmt.Errorf("filtru Power invalid")
	}
	return f, nil
}

type rarCatalogVM struct {
	ID, SourceID           int64
	OS, Environment, Power string
}

func rarCatalogOSName(name, version string) string {
	name, version = strings.TrimSpace(name), strings.TrimSpace(version)
	if name == "" {
		return ""
	}
	// The agent sometimes returns the full release as os_name already.
	if version != "" && !strings.Contains(strings.ToLower(name), strings.ToLower(version)) {
		return name + " " + version
	}
	return name
}

// Match the canonical operational environment shown in the VM detail page,
// including legacy metadata labels (PROD / Production / Producție).
func rarCatalogEnvironmentCode(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	switch value {
	case "prod", "production", "productie", "producție", "producţie":
		return "PROD"
	case "test", "testing", "teste":
		return "TEST"
	case "dev", "development", "dezvoltare":
		return "DEV"
	default:
		return strings.ToUpper(value)
	}
}

func rarCatalogAcceptVM(vm rarCatalogVM, f rarCatalogFilters) bool {
	if f.Source != "" && strconv.FormatInt(vm.SourceID, 10) != f.Source {
		return false
	}
	if f.Environment != "" && rarCatalogEnvironmentCode(vm.Environment) != rarCatalogEnvironmentCode(f.Environment) {
		return false
	}
	if f.OS != "" && !strings.EqualFold(strings.TrimSpace(vm.OS), f.OS) {
		return false
	}
	if f.Power == "on" && strings.ToUpper(vm.Power) != "POWERED_ON" {
		return false
	}
	if f.Power == "off" && strings.ToUpper(vm.Power) == "POWERED_ON" {
		return false
	}
	return true
}
func rarCatalogEntriesSorted(names map[string]map[int64]bool, versions map[string]map[string]bool, includeVersions bool) []rarCatalogEntry {
	entries := make([]rarCatalogEntry, 0, len(names))
	for name, ids := range names {
		e := rarCatalogEntry{Name: name, VMCount: len(ids)}
		if includeVersions {
			for v := range versions[name] {
				e.Versions = append(e.Versions, v)
			}
			sort.Slice(e.Versions, func(i, j int) bool { return naturalComponentLess(e.Versions[i], e.Versions[j]) })
		}
		entries = append(entries, e)
	}
	sort.Slice(entries, func(i, j int) bool { return strings.ToLower(entries[i].Name) < strings.ToLower(entries[j].Name) })
	return entries
}

// Pure report builder for regression tests, independent of MariaDB.
func buildRARCatalogReport(vms []rarCatalogVM, rows []softwareComponentReportRow, sources []rarCatalogOption, f rarCatalogFilters) rarCatalogResponse {
	resp := rarCatalogResponse{GeneratedAt: time.Now().UTC(), OperatingSystems: []rarCatalogEntry{}, Categories: []rarCatalogCategory{}}
	resp.Options.Sources = sources
	eligible := map[int64]rarCatalogVM{}
	available := map[int64]bool{}
	allOS := map[string]bool{}
	osGroup := map[string]map[int64]bool{}
	categoryGroups := map[string]map[string]map[int64]bool{}
	categoryVersions := map[string]map[string]map[string]bool{}
	categoryOptions := map[string]bool{}
	componentOptions := map[string]string{}
	for _, vm := range vms {
		available[vm.ID] = true
		if vm.OS != "" {
			allOS[vm.OS] = true
		}
		if !rarCatalogAcceptVM(vm, f) {
			continue
		}
		eligible[vm.ID] = vm
		if vm.OS != "" && (f.Query == "" || strings.Contains(strings.ToLower(vm.OS), strings.ToLower(f.Query))) {
			if osGroup[vm.OS] == nil {
				osGroup[vm.OS] = map[int64]bool{}
			}
			osGroup[vm.OS][vm.ID] = true
		}
	}
	for _, row := range rows {
		if !available[row.VMID] {
			continue
		}
		category := strings.TrimSpace(row.Category)
		component := strings.TrimSpace(row.ComponentName)
		if category == "" || component == "" {
			continue
		}
		categoryOptions[category] = true
		componentOptions[row.ComponentKey] = component
		if _, ok := eligible[row.VMID]; !ok {
			continue
		}
		if f.Category != "" && !strings.EqualFold(f.Category, category) {
			continue
		}
		if f.Component != "" && !strings.EqualFold(f.Component, row.ComponentKey) && !strings.EqualFold(f.Component, component) {
			continue
		}
		if f.Query != "" && !strings.Contains(strings.ToLower(category+" "+component+" "+strings.Join(row.Versions, " ")), strings.ToLower(f.Query)) {
			continue
		}
		if categoryGroups[category] == nil {
			categoryGroups[category] = map[string]map[int64]bool{}
		}
		if categoryGroups[category][component] == nil {
			categoryGroups[category][component] = map[int64]bool{}
		}
		categoryGroups[category][component][row.VMID] = true
		if categoryVersions[category] == nil {
			categoryVersions[category] = map[string]map[string]bool{}
		}
		if categoryVersions[category][component] == nil {
			categoryVersions[category][component] = map[string]bool{}
		}
		for _, version := range row.Versions {
			if v := cleanComponentVersion(version); v != "" {
				categoryVersions[category][component][v] = true
			}
		}
	}
	for os := range allOS {
		resp.Options.OperatingSystems = append(resp.Options.OperatingSystems, rarCatalogOption{Value: os, Label: os})
	}
	sort.Slice(resp.Options.OperatingSystems, func(i, j int) bool {
		return strings.ToLower(resp.Options.OperatingSystems[i].Value) < strings.ToLower(resp.Options.OperatingSystems[j].Value)
	})
	for cat := range categoryOptions {
		resp.Options.Categories = append(resp.Options.Categories, rarCatalogOption{Value: cat, Label: cat})
	}
	sort.Slice(resp.Options.Categories, func(i, j int) bool {
		return strings.ToLower(resp.Options.Categories[i].Value) < strings.ToLower(resp.Options.Categories[j].Value)
	})
	for key, name := range componentOptions {
		resp.Options.Components = append(resp.Options.Components, rarCatalogOption{Value: key, Label: name})
	}
	sort.Slice(resp.Options.Components, func(i, j int) bool {
		return strings.ToLower(resp.Options.Components[i].Label) < strings.ToLower(resp.Options.Components[j].Label)
	})
	resp.OperatingSystems = rarCatalogEntriesSorted(osGroup, nil, false)
	categories := make([]string, 0, len(categoryGroups))
	for c := range categoryGroups {
		categories = append(categories, c)
	}
	sort.Slice(categories, func(i, j int) bool { return strings.ToLower(categories[i]) < strings.ToLower(categories[j]) })
	for _, cat := range categories {
		entries := rarCatalogEntriesSorted(categoryGroups[cat], categoryVersions[cat], f.Versions)
		resp.Categories = append(resp.Categories, rarCatalogCategory{Name: cat, Components: entries})
		resp.Summary.Components += len(entries)
	}
	resp.Summary.VMs = len(eligible)
	resp.Summary.OS = len(resp.OperatingSystems)
	resp.Summary.Categories = len(resp.Categories)
	return resp
}
func (a *App) rarCatalogReport(ctx context.Context, f rarCatalogFilters) (rarCatalogResponse, error) {
	rows, err := a.DB.QueryContext(ctx, `SELECT vm.id,vm.vcenter_source_id,COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),''),COALESCE(i.os_version,''),COALESCE(NULLIF(env.item_code,''),NULLIF(env.name,''),NULLIF(m.environment,''),''),COALESCE(vm.power_state,''),vc.name
 FROM virtual_machines vm JOIN vcenter_sources vc ON vc.id=vm.vcenter_source_id
 LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id
 LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id
 LEFT JOIN vm_operational_nomenclatures ven ON ven.vm_id=vm.id AND ven.category_code='environment'
 LEFT JOIN nomenclature_items env ON env.id=ven.item_id AND env.category_code='environment'
 WHERE vm.retired=0 AND vm.present_in_vcenter=1
 ORDER BY vm.id`)
	if err != nil {
		return rarCatalogResponse{}, err
	}
	vms := []rarCatalogVM{}
	options := map[int64]rarCatalogOption{}
	for rows.Next() {
		var vm rarCatalogVM
		var name, version, sourceName string
		if err = rows.Scan(&vm.ID, &vm.SourceID, &name, &version, &vm.Environment, &vm.Power, &sourceName); err != nil {
			break
		}
		vm.OS = rarCatalogOSName(name, version)
		vms = append(vms, vm)
		options[vm.SourceID] = rarCatalogOption{Value: strconv.FormatInt(vm.SourceID, 10), Label: sourceName}
	}
	if err == nil {
		err = rows.Err()
	}
	rows.Close()
	if err != nil {
		return rarCatalogResponse{}, err
	}
	// Use precisely the same curated inventory as Rapoarte -> Componente software.
	components, err := a.softwareComponentReport(ctx)
	if err != nil {
		return rarCatalogResponse{}, err
	}
	sourceOptions := make([]rarCatalogOption, 0, len(options))
	for _, opt := range options {
		sourceOptions = append(sourceOptions, opt)
	}
	sort.Slice(sourceOptions, func(i, j int) bool {
		return strings.ToLower(sourceOptions[i].Label) < strings.ToLower(sourceOptions[j].Label)
	})
	return buildRARCatalogReport(vms, components.Rows, sourceOptions, f), nil
}
func (a *App) reportsRARCatalog(w http.ResponseWriter, r *http.Request) {
	f, err := rarCatalogParseFilters(r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	report, err := a.rarCatalogReport(r.Context(), f)
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, report)
}
func (a *App) exportRARCatalogDOCX(w http.ResponseWriter, r *http.Request) {
	f, err := rarCatalogParseFilters(r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	report, err := a.rarCatalogReport(r.Context(), f)
	if err != nil {
		respond(w, nil, err)
		return
	}
	data, err := documents.BuildRARCatalogDOCX(rarCatalogToDocx(report), time.Now().UTC())
	if err != nil {
		respond(w, nil, err)
		return
	}
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="RAR-Anexa-6-Produse-software-%s.docx"`, time.Now().UTC().Format("20060102-150405")))
	w.Header().Set("Content-Length", strconv.Itoa(len(data)))
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(data)
}
func rarCatalogToDocx(v rarCatalogResponse) documents.RARCatalogContent {
	out := documents.RARCatalogContent{}
	for _, item := range v.OperatingSystems {
		out.OperatingSystems = append(out.OperatingSystems, documents.RARCatalogItem{Name: item.Name})
	}
	for _, cat := range v.Categories {
		c := documents.RARCatalogGroup{Name: cat.Name}
		for _, item := range cat.Components {
			c.Items = append(c.Items, documents.RARCatalogItem{Name: item.Name, Versions: item.Versions})
		}
		out.Categories = append(out.Categories, c)
	}
	return out
}
