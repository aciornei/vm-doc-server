# Upgrade VM-DOC 0.21.99 → 0.21.100

**Acesta este un update incremental direct pentru sursele 0.21.99.** Fișierul `VM-DOC-UPDATE-099-100.zip` se extrage direct în directorul *surselor*; nu conține o arhivă TAR.GZ în interior. Nu extrage în `/opt/vm-doc-server/bin` și nu suprascrie configurația de producție.

1. Faceți backup MariaDB, configurație și binar înainte de modificare. Verificați că în directorul de surse `cat VERSION` afișează `0.21.99`.
2. În directorul surselor existente, rulați:

   ```bash
   unzip -o /cale/VM-DOC-UPDATE-099-100.zip -d .
   cat VERSION  # 0.21.100
   ```

3. Rulați testele și build-ul în mediul cu `vendor/`:

   ```bash
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
   ```

4. Verificați locația executabilului cu `systemctl cat vm-doc-server` (`ExecStart`). Opriți serviciul, salvați binarul precedent, instalați **binarul nou `bin/vm-doc-server`** în locația reală și reporniți serviciul.
5. Verificați `/version` → `0.21.100`; faceți `Ctrl+F5`, deschideți **Rapoarte → RAR Anexa 6 → Produse software · Inventar agregat** și testați `PROD` + `Pornite`. Comparați cu VM-urile afișate în **Inventar VM**, pentru aceleași condiții (și starea prezent/neretras).
6. Verificați exportul DOCX după filtrare. Nu este necesară resincronizare VCSA doar pentru fix, dacă datele de inventar și nomenclator sunt deja salvate.

**Nu există migrare SQL nouă, actualizare agent sau schimbare de structură a inventarului.**

**Rollback:** restaurați binarul 0.21.99, fără rollback SQL. Dacă este necesar rollback-ul surselor, folosiți backup-ul surselor 0.21.99 sau arhiva completă originală.

**Limitare:** build-ul complet cu `vendor/` și interogarea pe MariaDB reală nu au fost executate în mediul de pregătire a release-ului.
