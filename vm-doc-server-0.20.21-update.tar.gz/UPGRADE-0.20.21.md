# Upgrade vm-doc-server 0.20.20 → 0.20.21

## Ce se schimbă

0.20.21 adaugă butonul **Sincronizează acum Docker / DB / Web** pentru membrii HA/cluster cu moștenirea resurselor activă și corectează spațierea mesajului de moștenire din VM → Configurare.

Sincronizarea manuală operează numai pe resursele tehnice deja cunoscute în inventarul normalizat. Dacă o resursă apare pentru prima dată după un nou Colect, fluxul automat de inventar aplică moștenirea ca și în 0.20.20.

## Bază de date

Nu există migrare nouă.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.20 /usr/local/src/vm-doc-server-0.20.21
tar -xzf vm-doc-server-0.20.21-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.21
cd /usr/local/src/vm-doc-server-0.20.21
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Nu este necesar update de agent.
