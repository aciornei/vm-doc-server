package vcenter

import (
	"context"
	"database/sql"
	"errors"
	"strings"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/vminheritance"
)

var documentationGroupTypes = map[string]bool{
	"active_active":  true,
	"active_standby": true,
	"cluster":        true,
}

type DocumentationInheritanceInput struct {
	SourceVMID                 *int64 `json:"source_vm_id"`
	GroupName                  string `json:"group_name"`
	GroupType                  string `json:"group_type"`
	InheritServiceAssignments  bool   `json:"inherit_service_assignments"`
	InheritOperationalMetadata bool   `json:"inherit_operational_metadata"`
	InheritResourceAssignments bool   `json:"inherit_resource_assignments"`
}

func (s *Service) GetVMDocumentationInheritance(ctx context.Context, vmID int64) (domain.VMDocumentationInheritance, error) {
	out := domain.VMDocumentationInheritance{VMID: vmID, Members: make([]domain.VMDocumentationMember, 0)}
	if vmID <= 0 {
		return out, errors.New("invalid VM id")
	}
	var sourceID int64
	var sourceName, groupName, groupType string
	var inheritServices, inheritOperational, inheritResources bool
	err := s.DB.QueryRowContext(ctx, `SELECT i.source_vm_id,src.name,i.group_name,i.group_type,i.inherit_service_assignments,i.inherit_operational_metadata,i.inherit_resource_assignments
		FROM vm_documentation_inheritance i
		JOIN virtual_machines src ON src.id=i.source_vm_id
		WHERE i.vm_id=?`, vmID).Scan(&sourceID, &sourceName, &groupName, &groupType, &inheritServices, &inheritOperational, &inheritResources)
	if err == nil {
		out.SourceVMID = int64Ptr(sourceID)
		out.SourceVMName = sourceName
		out.GroupName = groupName
		out.GroupType = groupType
		out.InheritServiceAssignments = inheritServices
		out.InheritOperationalMetadata = inheritOperational
		out.InheritResourceAssignments = inheritResources
		return out, nil
	}
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return out, err
	}

	rows, err := s.DB.QueryContext(ctx, `SELECT i.vm_id,vm.name,COALESCE(vm.guest_hostname,''),COALESCE(vm.primary_ip,''),i.group_name,i.group_type
		FROM vm_documentation_inheritance i
		JOIN virtual_machines vm ON vm.id=i.vm_id
		WHERE i.source_vm_id=?
		ORDER BY vm.name,vm.id`, vmID)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var member domain.VMDocumentationMember
		var name, kind string
		if err := rows.Scan(&member.VMID, &member.VMName, &member.Hostname, &member.PrimaryIP, &name, &kind); err != nil {
			return out, err
		}
		if !out.IsSource {
			out.GroupName = name
			out.GroupType = kind
		}
		out.IsSource = true
		out.Members = append(out.Members, member)
	}
	return out, rows.Err()
}

func (s *Service) SetVMDocumentationInheritance(ctx context.Context, vmID, userID int64, input DocumentationInheritanceInput) (domain.VMDocumentationInheritance, error) {
	if vmID <= 0 {
		return domain.VMDocumentationInheritance{}, errors.New("invalid VM id")
	}
	if input.SourceVMID == nil || *input.SourceVMID == 0 {
		if _, err := s.DB.ExecContext(ctx, `DELETE FROM vm_documentation_inheritance WHERE vm_id=?`, vmID); err != nil {
			return domain.VMDocumentationInheritance{}, err
		}
		return s.GetVMDocumentationInheritance(ctx, vmID)
	}
	sourceID := *input.SourceVMID
	if sourceID <= 0 || sourceID == vmID {
		return domain.VMDocumentationInheritance{}, errors.New("source_vm_id must reference another VM")
	}
	input.GroupName = strings.TrimSpace(input.GroupName)
	input.GroupType = strings.ToLower(strings.TrimSpace(input.GroupType))
	if input.GroupName == "" {
		return domain.VMDocumentationInheritance{}, errors.New("group_name is required")
	}
	if len([]rune(input.GroupName)) > 255 {
		return domain.VMDocumentationInheritance{}, errors.New("group_name is too long")
	}
	if !documentationGroupTypes[input.GroupType] {
		return domain.VMDocumentationInheritance{}, errors.New("group_type must be active_active, active_standby or cluster")
	}

	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.VMDocumentationInheritance{}, err
	}
	defer tx.Rollback()
	for _, id := range []int64{vmID, sourceID} {
		var exists int
		if err := tx.QueryRowContext(ctx, `SELECT 1 FROM virtual_machines WHERE id=? FOR UPDATE`, id).Scan(&exists); err != nil {
			return domain.VMDocumentationInheritance{}, err
		}
	}
	var count int
	if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM vm_documentation_inheritance WHERE vm_id=?`, sourceID).Scan(&count); err != nil {
		return domain.VMDocumentationInheritance{}, err
	}
	if count > 0 {
		return domain.VMDocumentationInheritance{}, errors.New("selected source VM must not inherit documentation from another VM")
	}
	if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM vm_documentation_inheritance WHERE source_vm_id=?`, vmID).Scan(&count); err != nil {
		return domain.VMDocumentationInheritance{}, err
	}
	if count > 0 {
		return domain.VMDocumentationInheritance{}, errors.New("this VM must stop being a documentation source before it can become a member")
	}

	_, err = tx.ExecContext(ctx, `INSERT INTO vm_documentation_inheritance(vm_id,source_vm_id,group_name,group_type,inherit_service_assignments,inherit_operational_metadata,inherit_resource_assignments,created_by,updated_by)
		VALUES(?,?,?,?,?,?,?,?,?)
		ON DUPLICATE KEY UPDATE source_vm_id=VALUES(source_vm_id),group_name=VALUES(group_name),group_type=VALUES(group_type),inherit_service_assignments=VALUES(inherit_service_assignments),inherit_operational_metadata=VALUES(inherit_operational_metadata),inherit_resource_assignments=VALUES(inherit_resource_assignments),updated_by=VALUES(updated_by)`,
		vmID, sourceID, input.GroupName, input.GroupType, input.InheritServiceAssignments, input.InheritOperationalMetadata, input.InheritResourceAssignments, userID, userID)
	if err != nil {
		return domain.VMDocumentationInheritance{}, err
	}
	// Group metadata belongs to the source cluster, not to one particular member.
	if _, err := tx.ExecContext(ctx, `UPDATE vm_documentation_inheritance SET group_name=?,group_type=?,updated_by=? WHERE source_vm_id=?`, input.GroupName, input.GroupType, userID, sourceID); err != nil {
		return domain.VMDocumentationInheritance{}, err
	}
	if input.InheritServiceAssignments {
		if err := syncServiceAssignmentsFromSourceTx(ctx, tx, sourceID, vmID, userID); err != nil {
			return domain.VMDocumentationInheritance{}, err
		}
	}
	if input.InheritOperationalMetadata {
		if err := syncOperationalDocumentationFromSourceTx(ctx, tx, sourceID, vmID, userID); err != nil {
			return domain.VMDocumentationInheritance{}, err
		}
	}
	if input.InheritResourceAssignments {
		if _, err := vminheritance.SyncResourcesFromSourceTx(ctx, tx, sourceID, vmID); err != nil {
			return domain.VMDocumentationInheritance{}, err
		}
	}
	if err := tx.Commit(); err != nil {
		return domain.VMDocumentationInheritance{}, err
	}
	return s.GetVMDocumentationInheritance(ctx, vmID)
}

func documentationChildrenTx(ctx context.Context, tx *sql.Tx, sourceVMID int64, flag string) ([]int64, error) {
	query := `SELECT vm_id FROM vm_documentation_inheritance WHERE source_vm_id=?`
	switch flag {
	case "services":
		query += ` AND inherit_service_assignments=1`
	case "operational":
		query += ` AND inherit_operational_metadata=1`
	}
	query += ` ORDER BY vm_id`
	rows, err := tx.QueryContext(ctx, query, sourceVMID)
	if err != nil {
		return nil, err
	}
	out := make([]int64, 0)
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			rows.Close()
			return nil, err
		}
		out = append(out, id)
	}
	err = rows.Err()
	rows.Close()
	return out, err
}

func syncServiceAssignmentsFromSourceTx(ctx context.Context, tx *sql.Tx, sourceVMID, targetVMID, userID int64) error {
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_internal_service_assignments WHERE vm_id=?`, targetVMID); err != nil {
		return err
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO vm_internal_service_assignments(vm_id,internal_service_id,architectural_domain_id,itil_category_id,layer_id,technical_role_id,solution_type_id,usage_type,is_primary,notes,sort_order,updated_by)
		SELECT ?,internal_service_id,architectural_domain_id,itil_category_id,layer_id,technical_role_id,solution_type_id,usage_type,is_primary,notes,sort_order,?
		FROM vm_internal_service_assignments WHERE vm_id=? ORDER BY sort_order,id`, targetVMID, userID, sourceVMID)
	return err
}

func syncServiceAssignmentsToChildrenTx(ctx context.Context, tx *sql.Tx, sourceVMID, userID int64) error {
	children, err := documentationChildrenTx(ctx, tx, sourceVMID, "services")
	if err != nil {
		return err
	}
	for _, childID := range children {
		if err := syncServiceAssignmentsFromSourceTx(ctx, tx, sourceVMID, childID, userID); err != nil {
			return err
		}
	}
	return nil
}

func syncOperationalDocumentationFromSourceTx(ctx context.Context, tx *sql.Tx, sourceVMID, targetVMID, userID int64) error {
	var exists int
	err := tx.QueryRowContext(ctx, `SELECT 1 FROM vm_operational_metadata WHERE vm_id=?`, sourceVMID).Scan(&exists)
	if errors.Is(err, sql.ErrNoRows) {
		if _, err := tx.ExecContext(ctx, `UPDATE vm_operational_metadata SET purpose='',technical_admin='',business_owner='',owner_email='',rpo_minutes=NULL,rto_minutes=NULL,classification='',documentation_url='',notes='',updated_by=? WHERE vm_id=?`, userID, targetVMID); err != nil {
			return err
		}
		if _, err := tx.ExecContext(ctx, `DELETE FROM vm_operational_nomenclatures WHERE vm_id=? AND category_code='classification'`, targetVMID); err != nil {
			return err
		}
		_, err = tx.ExecContext(ctx, `DELETE FROM vm_responsibilities WHERE vm_id=?`, targetVMID)
		return err
	}
	if err != nil {
		return err
	}

	_, err = tx.ExecContext(ctx, `INSERT INTO vm_operational_metadata(vm_id,purpose,technical_admin,business_owner,owner_email,rpo_minutes,rto_minutes,classification,documentation_url,notes,updated_by)
		SELECT ?,purpose,technical_admin,business_owner,owner_email,rpo_minutes,rto_minutes,classification,documentation_url,notes,? FROM vm_operational_metadata WHERE vm_id=?
		ON DUPLICATE KEY UPDATE purpose=VALUES(purpose),technical_admin=VALUES(technical_admin),business_owner=VALUES(business_owner),owner_email=VALUES(owner_email),rpo_minutes=VALUES(rpo_minutes),rto_minutes=VALUES(rto_minutes),classification=VALUES(classification),documentation_url=VALUES(documentation_url),notes=VALUES(notes),updated_by=VALUES(updated_by)`, targetVMID, userID, sourceVMID)
	if err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_operational_nomenclatures WHERE vm_id=? AND category_code='classification'`, targetVMID); err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `INSERT INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
		SELECT ?,'classification',item_id FROM vm_operational_nomenclatures WHERE vm_id=? AND category_code='classification'`, targetVMID, sourceVMID); err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_responsibilities WHERE vm_id=?`, targetVMID); err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `INSERT INTO vm_responsibilities(vm_id,person_id,responsibility_type,notes,sort_order,created_by)
		SELECT ?,person_id,responsibility_type,notes,sort_order,? FROM vm_responsibilities WHERE vm_id=? ORDER BY sort_order,id`, targetVMID, userID, sourceVMID)
	return err
}

func syncOperationalDocumentationToChildrenTx(ctx context.Context, tx *sql.Tx, sourceVMID, userID int64) error {
	children, err := documentationChildrenTx(ctx, tx, sourceVMID, "operational")
	if err != nil {
		return err
	}
	for _, childID := range children {
		if err := syncOperationalDocumentationFromSourceTx(ctx, tx, sourceVMID, childID, userID); err != nil {
			return err
		}
	}
	return nil
}

// SyncVMInheritedResources reapplies Docker/DB/Web documentation inheritance
// immediately using the technical resources already known for this VM. Fresh
// inventory collection remains authoritative for discovering new resources.
func (s *Service) SyncVMInheritedResources(ctx context.Context, vmID int64) (vminheritance.ResourceSyncResult, error) {
	var result vminheritance.ResourceSyncResult
	if s == nil || s.DB == nil || vmID <= 0 {
		return result, errors.New("invalid VM id")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return result, err
	}
	defer tx.Rollback()
	var sourceID int64
	if err := tx.QueryRowContext(ctx, `SELECT source_vm_id FROM vm_documentation_inheritance WHERE vm_id=? AND inherit_resource_assignments=1`, vmID).Scan(&sourceID); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return result, errors.New("Docker/DB/Web resource inheritance is not enabled for this VM")
		}
		return result, err
	}
	result, err = vminheritance.SyncResourcesFromSourceTx(ctx, tx, sourceID, vmID)
	if err != nil {
		return result, err
	}
	if err := tx.Commit(); err != nil {
		return result, err
	}
	return result, nil
}

// SyncInheritedResourceAssignments propagates Docker/DB/Web documentation mappings
// from a source VM to all HA/cluster members that opted into resource inheritance.
func (s *Service) SyncInheritedResourceAssignments(ctx context.Context, sourceVMID int64) error {
	if s == nil || s.DB == nil || sourceVMID <= 0 {
		return nil
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if err := vminheritance.SyncResourcesToChildrenTx(ctx, tx, sourceVMID); err != nil {
		return err
	}
	return tx.Commit()
}
