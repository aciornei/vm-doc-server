# Upgrade 0.21.82 → 0.21.83

1. Fă backup complet MariaDB și salvează binarul/configurația 0.21.82.
2. Oprește serviciul VM-DOC și aplică sursele sau update-ul 0.21.83.
3. Compilează cu dependențele offline `vendor/`: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
4. Instalează noul **binar**; HTML, JS și CSS sunt servite din `go:embed`.
5. Pornește serverul, verifică jurnalul pentru migrarea 084 și permisiunile endpointurilor:
   - `GET /api/v1/changes/documentation/notifications`
   - `GET /api/v1/changes/documentation/tasks?status=pending`
   - `POST /api/v1/changes/documentation/tasks/{id}/complete` (CSRF și `vms.manage`).
6. Testează pe un eveniment clasificat `Necesită documentație`: apare obligația VM și, dacă există asociere directă, obligația serviciului. Revizuiește, apoi documentează doar VM-ul: serviciul trebuie să rămână restant.
7. Verifică fișa VM: Timeline (implicit), Modificări, Ghid și clopoțelul din antet. Validează completitudinea VM după închiderea ultimei obligații.

Migrarea 084 este aditivă și nu șterge inventare, modificări, baseline sau fișe.
**Rollback:** readu binarul 0.21.82 și configurația originală. Migrarea 084 poate rămâne în DB fără a fi folosită de binarul anterior; ștergerea tabelei prin scriptul down elimină confirmările „Documentat”, deci nu o executa fără decizie explicită și backup.
