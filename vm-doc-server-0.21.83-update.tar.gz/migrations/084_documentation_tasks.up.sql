-- Documentarea VM si documentarea serviciului sunt obligatii distincte.
-- Nu modifica baseline-ul, statusul de revizie sau snapshoturile.
CREATE TABLE IF NOT EXISTS inventory_change_documentation_tasks (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  change_id BIGINT UNSIGNED NOT NULL,
  target_type VARCHAR(16) NOT NULL,
  target_id BIGINT UNSIGNED NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'pending',
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  documented_at DATETIME(6) NULL,
  documented_by BIGINT UNSIGNED NULL,
  UNIQUE KEY uq_change_documentation_target(change_id,target_type,target_id),
  KEY idx_change_documentation_pending(status,target_type,target_id,id),
  KEY idx_change_documentation_change(change_id,status),
  CONSTRAINT fk_change_documentation_change FOREIGN KEY(change_id) REFERENCES inventory_changes(id) ON DELETE CASCADE,
  CONSTRAINT fk_change_documentation_user FOREIGN KEY(documented_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datoriile existente sunt importate, fara sa le marcam automat documentate.
INSERT IGNORE INTO inventory_change_documentation_tasks(change_id,target_type,target_id)
SELECT c.id,'vm',c.vm_id
FROM inventory_changes c WHERE c.documentation_requirement='required' AND c.review_status IN ('new','reviewed');
INSERT IGNORE INTO inventory_change_documentation_tasks(change_id,target_type,target_id)
SELECT c.id,'service',a.internal_service_id
FROM inventory_changes c JOIN vm_internal_service_assignments a ON a.vm_id=c.vm_id
WHERE c.documentation_requirement='required' AND c.review_status IN ('new','reviewed');
