-- ROLLBACK: elimina sarcinile de documentare si istoricul confirmarilor lor.
DROP TABLE IF EXISTS inventory_change_documentation_tasks;
