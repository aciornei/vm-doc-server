package inventorychanges

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"
)

// DocumentationTask is an independent action item; reviewing the detected
// configuration and acknowledging its baseline never completes this task.
type DocumentationTask struct {
	ID               int64      `json:"id"`
	ChangeID         int64      `json:"change_id"`
	VMID             int64      `json:"vm_id"`
	VMName           string     `json:"vm_name"`
	TargetType       string     `json:"target_type"`
	TargetID         int64      `json:"target_id"`
	TargetName       string     `json:"target_name"`
	ObjectLabel      string     `json:"object_label"`
	Category         string     `json:"category"`
	Summary          string     `json:"summary"`
	ReviewStatus     string     `json:"review_status"`
	Status           string     `json:"status"`
	CreatedAt        time.Time  `json:"created_at"`
	DocumentedAt     *time.Time `json:"documented_at,omitempty"`
	DocumentedByName string     `json:"documented_by_name,omitempty"`
}
type DocumentationTaskPage struct {
	Items    []DocumentationTask `json:"items"`
	Total    int64               `json:"total"`
	Page     int                 `json:"page"`
	PageSize int                 `json:"page_size"`
	Pages    int64               `json:"pages"`
}
type DocumentationNotification struct {
	TargetType string    `json:"target_type"`
	TargetID   int64     `json:"target_id"`
	TargetName string    `json:"target_name"`
	Pending    int64     `json:"pending"`
	LastAt     time.Time `json:"last_at"`
}
type DocumentationNotifications struct {
	Count        int64                       `json:"count"`
	VMCount      int64                       `json:"vm_count"`
	ServiceCount int64                       `json:"service_count"`
	Items        []DocumentationNotification `json:"items"`
}

// syncDocumentationTasks is called from the same transaction as the review.
// Suppressed and reverted changes cannot create new documentation obligations.
func syncDocumentationTasks(ctx context.Context, tx *sql.Tx, changeID, vmID int64, requirement, review string) error {
	if requirement != "required" || review == "ignored" || review == "reverted" {
		_, err := tx.ExecContext(ctx, `DELETE FROM inventory_change_documentation_tasks WHERE change_id=? AND status='pending'`, changeID)
		return err
	}
	if _, err := tx.ExecContext(ctx, `INSERT IGNORE INTO inventory_change_documentation_tasks(change_id,target_type,target_id) VALUES(?,'vm',?)`, changeID, vmID); err != nil {
		return err
	}
	// Only the VM's directly assigned service receives an automatic obligation.
	// A host can run many unrelated containers/DBs/sites belonging to different
	// services; broadcasting every host change to all those services creates
	// false documentation alerts. Resource-level matching will be added after
	// per-object ownership can be established reliably.
	_, err := tx.ExecContext(ctx, `INSERT IGNORE INTO inventory_change_documentation_tasks(change_id,target_type,target_id)
 SELECT ?, 'service', internal_service_id FROM vm_internal_service_assignments WHERE vm_id=?`, changeID, vmID)
	return err
}

func documentationTaskFrom() string {
	return ` FROM inventory_change_documentation_tasks t
 JOIN inventory_changes c ON c.id=t.change_id
 JOIN virtual_machines vm ON vm.id=c.vm_id
 LEFT JOIN internal_services svc ON t.target_type='service' AND svc.id=t.target_id
 LEFT JOIN users u ON u.id=t.documented_by `
}

func (s Service) ListDocumentationTasks(ctx context.Context, status, targetType string, vmID, targetID int64, page, pageSize int) (DocumentationTaskPage, error) {
	out := DocumentationTaskPage{Items: []DocumentationTask{}, Page: page, PageSize: pageSize}
	if out.Page < 1 {
		out.Page = 1
	}
	if out.PageSize < 1 {
		out.PageSize = 20
	}
	if out.PageSize > 100 {
		out.PageSize = 100
	}
	if status == "" {
		status = "pending"
	}
	if status != "pending" && status != "documented" && status != "all" {
		return out, errors.New("invalid task status")
	}
	if targetType != "" && targetType != "vm" && targetType != "service" {
		return out, errors.New("invalid target type")
	}
	where := []string{}
	args := []any{}
	if status != "all" {
		where = append(where, "t.status=?")
		args = append(args, status)
	}
	if targetType != "" {
		where = append(where, "t.target_type=?")
		args = append(args, targetType)
	}
	if vmID > 0 {
		where = append(where, "c.vm_id=?")
		args = append(args, vmID)
	}
	if targetID > 0 {
		where = append(where, "t.target_id=?")
		args = append(args, targetID)
	}
	clause := ""
	if len(where) > 0 {
		clause = " WHERE " + strings.Join(where, " AND ")
	}
	if err := s.DB.QueryRowContext(ctx, "SELECT COUNT(*)"+documentationTaskFrom()+clause, args...).Scan(&out.Total); err != nil {
		return out, err
	}
	out.Pages = (out.Total + int64(out.PageSize) - 1) / int64(out.PageSize)
	if out.Pages > 0 && int64(out.Page) > out.Pages {
		out.Page = int(out.Pages)
	}
	query := `SELECT t.id,t.change_id,c.vm_id,vm.name,t.target_type,t.target_id,
 CASE WHEN t.target_type='vm' THEN vm.name ELSE COALESCE(svc.name,'Serviciu indisponibil') END,
 c.object_label,c.category,c.summary,c.review_status,t.status,t.created_at,t.documented_at,
 COALESCE(NULLIF(u.display_name,''),u.username,'')` + documentationTaskFrom() + clause + ` ORDER BY t.created_at DESC,t.id DESC LIMIT ? OFFSET ?`
	queryArgs := append(append([]any{}, args...), out.PageSize, (out.Page-1)*out.PageSize)
	rows, err := s.DB.QueryContext(ctx, query, queryArgs...)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var t DocumentationTask
		var completed sql.NullTime
		if err = rows.Scan(&t.ID, &t.ChangeID, &t.VMID, &t.VMName, &t.TargetType, &t.TargetID, &t.TargetName, &t.ObjectLabel, &t.Category, &t.Summary, &t.ReviewStatus, &t.Status, &t.CreatedAt, &completed, &t.DocumentedByName); err != nil {
			return out, err
		}
		if completed.Valid {
			v := completed.Time
			t.DocumentedAt = &v
		}
		out.Items = append(out.Items, t)
	}
	return out, rows.Err()
}

// Notifications count distinct resources (VMs / services), not every change.
func (s Service) DocumentationNotifications(ctx context.Context) (DocumentationNotifications, error) {
	out := DocumentationNotifications{Items: []DocumentationNotification{}}
	q := `SELECT t.target_type,t.target_id,
 CASE WHEN t.target_type='vm' THEN vm.name ELSE COALESCE(svc.name,'Serviciu indisponibil') END,
 COUNT(*),MAX(t.created_at)
 ` + documentationTaskFrom() + ` WHERE t.status='pending' GROUP BY t.target_type,t.target_id,CASE WHEN t.target_type='vm' THEN vm.name ELSE COALESCE(svc.name,'Serviciu indisponibil') END ORDER BY MAX(t.created_at) DESC,t.target_type,t.target_id`
	rows, err := s.DB.QueryContext(ctx, q)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var item DocumentationNotification
		if err = rows.Scan(&item.TargetType, &item.TargetID, &item.TargetName, &item.Pending, &item.LastAt); err != nil {
			return out, err
		}
		out.Count++
		if item.TargetType == "vm" {
			out.VMCount++
		} else {
			out.ServiceCount++
		}
		if len(out.Items) < 30 {
			out.Items = append(out.Items, item)
		}
	}
	return out, rows.Err()
}

func (s Service) CompleteDocumentationTask(ctx context.Context, id, userID int64) (DocumentationTask, error) {
	if id <= 0 {
		return DocumentationTask{}, errors.New("invalid documentation task id")
	}
	// Updates are idempotent; an already completed action is not re-attributed.
	res, err := s.DB.ExecContext(ctx, `UPDATE inventory_change_documentation_tasks t JOIN inventory_changes c ON c.id=t.change_id SET t.status='documented',t.documented_at=UTC_TIMESTAMP(6),t.documented_by=? WHERE t.id=? AND t.status='pending' AND c.review_status='reviewed' AND c.documentation_requirement='required'`, nullableUserID(userID), id)
	if err != nil {
		return DocumentationTask{}, err
	}
	n, err := res.RowsAffected()
	if err != nil {
		return DocumentationTask{}, err
	}
	if n == 0 {
		return DocumentationTask{}, fmt.Errorf("documentation task %d not pending, not reviewed or not found", id)
	}
	var result DocumentationTask
	var at sql.NullTime
	err = s.DB.QueryRowContext(ctx, `SELECT t.id,t.change_id,c.vm_id,vm.name,t.target_type,t.target_id,CASE WHEN t.target_type='vm' THEN vm.name ELSE COALESCE(svc.name,'Serviciu indisponibil') END,c.object_label,c.category,c.summary,c.review_status,t.status,t.created_at,t.documented_at,COALESCE(NULLIF(u.display_name,''),u.username,'')`+documentationTaskFrom()+` WHERE t.id=?`, id).Scan(&result.ID, &result.ChangeID, &result.VMID, &result.VMName, &result.TargetType, &result.TargetID, &result.TargetName, &result.ObjectLabel, &result.Category, &result.Summary, &result.ReviewStatus, &result.Status, &result.CreatedAt, &at, &result.DocumentedByName)
	if at.Valid {
		v := at.Time
		result.DocumentedAt = &v
	}
	return result, err
}
func nullableUserID(id int64) any {
	if id > 0 {
		return id
	}
	return nil
}
