# VM-DOC 0.21.83 — Documentație de actualizat și notificări interne

## Scop
Separă acceptarea unei schimbări (Stare = Revizuit, avansare baseline) de actualizarea efectivă a fișelor (Documentat), fără a amesteca obligațiile VM cu cele ale serviciilor.

## Interfață
- VM → Modificări: trei subpagini: **Timeline** (prima/implicită), **Modificări** și **Ghid**.
- Timeline VM: afișează schimbările revizuite și obligațiile VM restante; marcarea **Documentat** este disponibilă abia după revizie.
- Modificări global → **De documentat**: listă paginată, filtre VM/Serviciu, confirmare independentă per obligație.
- Clopoțel sus, lângă utilizator: numărul distinct de VM-uri și servicii cu obligații restante, primele 30 afișate, fiecare cu link către VM sau serviciu; actualizare la navigare, după acțiuni și la 60 secunde.
- Serviciu → Rezumat: avertizare pentru obligațiile de documentare asociate direct serviciului.

## Persistență și calcul completitudine
- Migrarea **084_documentation_tasks** adaugă `inventory_change_documentation_tasks` (țintă, status, dată, utilizator); populează obligațiile pentru evenimentele existente marcate `required` și cu starea `new` sau `reviewed`.
- Documentarea VM și a serviciului este independentă; confirmarea unuia nu închide și cealaltă obligație.
- Criteriul „Modificări ce necesită documentație” din procentul VM rămâne neîndeplinit până la confirmarea **Documentat** pentru toate obligațiile VM.
- La **Ignorat**, revenire automată la baseline sau reset de baseline, obligațiile restante ale modificărilor închise nu mai generează notificări. Evenimentele și snapshoturile nu se șterg prin migrare.
- Servicii notificate automat: numai servicii asociate **direct** la VM. Nu propagăm generic schimbări ale gazdei către toate serviciile mapate prin containere, DB sau web, pentru a evita fals pozitive. Corelarea exactă per resursă rămâne o etapă viitoare.

## Limitări / protecții
- Clopoțelul este o notificare internă, nu trimite e-mail/push și nu modifică permisiunile utilizatorului.
- A spune „Documentat” este o confirmare explicită a operatorului, nu verificarea automată a unui fișier DOCX/Outline.
- MariaDB reală, migrarea și compilarea completă cu `vendor/` nu pot fi testate în acest mediu. Se recomandă backup și staging.
- Nicio schimbare la agent; rămâne 1.7.18.
