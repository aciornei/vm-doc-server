# vm-doc-server 0.13.3

Platformă centrală pentru documentarea VM-urilor, cu **vCenter drept punctul 0 al inventarului** și `vm-doc-agent` drept sursă pentru detaliile din sistemul de operare.

```text
vCenter API ──> virtual_machines ──┐
                                  ├──> vm-doc-server ──> browser / API
vm-doc-agent ─> collector ─> JSON ┘
```




## Ce aduce versiunea 0.13.3

- repară panic-ul `invalid memory address or nil pointer dereference` observat la refresh-ul statusului de update al agentului;
- `vm-doc-server` construiește acum `agentclient.Client` la pornire și îl transmite serviciului de colectare folosit de API/heartbeat;
- protecție suplimentară: apelurile printr-un client neinițializat întorc eroare controlată, fără oprirea serverului;
- păstrează `collector.allowed_networks`, verificarea TLS și limita de răspuns existente;
- fără migrare de bază de date; agenții existenți rămân compatibili.

Vezi `docs/UPGRADE-0.13.3.md`.

## Ce aduce versiunea 0.13.2

- în **Agenți → Listare agenți** apare butonul **Update**, care forțează imediat verificarea și instalarea unei versiuni mai noi fără a aștepta `updates.check_interval`;
- update-ul forțat folosește canalul configurat pe agent (`stable` sau `testing`);
- lista afișează canalul auto-update raportat de fiecare agent și permite filtrare/căutare după canal;
- starea auto-update este memorată în server pentru ca pagina cu sute de agenți să nu interogheze toate VM-urile la fiecare afișare;
- statusul este actualizat la Test/Colect/Update și, pentru agenții auto-înregistrați, periodic prin heartbeat;
- exportul Excel Agenți include canalul, `enabled`, `auto_install`, starea update-ului și versiunea disponibilă;
- migrarea `027_agent_update_status.up.sql`;
- funcția este compatibilă cu `vm-doc-agent 1.3.3`; nu este necesară o versiune nouă de agent.

Vezi `docs/UPGRADE-0.13.2.md` și `docs/AGENT-UPDATES.md`.

## Ce aduce versiunea 0.13.1

- modulul **Agenți** folosește navigare orizontală pentru a păstra lățimea utilă a tabelului;
- lista agenților afișează **OS-ul și versiunea OS raportate de inventarul curent**;
- căutarea agenților include numele/versiunea OS și nu mai reconstruiește formularul de căutare;
- acțiuni compacte `Test`, `Colect`, `Edit`, `Del`;
- export Excel al listei de agenți, respectând filtrele active;
- formularul **Adaugă release** este colapsat implicit;
- release-urile publicate au căutare, filtre, paginare și export Excel;
- valoarea implicită pentru toate paginările este **10**;
- fără migrare de bază de date; agentul 1.3.3 rămâne compatibil.

Vezi `docs/UPGRADE-0.13.1.md`.

## Ce aduce versiunea 0.13.0

- retenție automată pentru `inventory_snapshots`: implicit maximum 30 snapshot-uri/agent și maximum 90 zile, cu protejarea inventarului curent și a snapshot-urilor folosite de documente generate;
- rapoarte pentru volumul inventarului, dimensiunea tabelului/indexurilor și top agenți după spațiul consumat;
- pagina **Audit** are paginare, căutare, filtre și explicații umane; pentru operațiile instrumentate se afișează valorile create, șterse sau diferențele before/after;
- model nou **Rețea externă → Sistem extern → Conexiune externă**;
- rețelele externe au culoare configurabilă, tip zonă, risc, trust, CIDR-uri, proprietar, descriere și observații de securitate;
- sistemele externe (VM/server/endpoint/serviciu de rețea) se asociază rețelelor externe și moștenesc clasificarea acestora;
- conexiunile externe păstrează sensul, serviciul, protocolul/portul, TLS, autentificarea și scopul și apar în VM, Serviciu intern, rapoarte și DOCX;
- migrarea `026_inventory_retention_audit_external_systems.up.sql`.

Vezi `docs/UPGRADE-0.13.0.md` și `docs/EXTERNAL-CONNECTIVITY.md`.

## Ce aduce versiunea 0.12.0

- pagina VM este împărțită în tab-uri sticky: **Rezumat, Servicii, Operațional, Inventar agent, Continuitate, Infrastructură și Istoric**; URL-ul păstrează secțiunea curentă;
- lista VM afișează procentul de **Completare fișă**, calculat din 11 criterii tehnice și operaționale esențiale; procentul este inclus și în exportul Excel;
- Rezumatul VM arată criteriile care mai trebuie completate;
- Nomenclatoarele au selectorul **Pe pagină** în zona de filtre, cu 10/20/50/100/200 și memorarea preferinței separat pentru fiecare nomenclator;
- pagina Agenți este împărțită în **Listare agenți** și **Release-uri agent**; publicarea unui release are propria secțiune;
- căutarea din lista Agenți actualizează numai tabelul, fără rerandarea întregii pagini, eliminând pierderea focusului la tastare;
- fără migrare MariaDB nouă.

Vezi `docs/UPGRADE-0.12.0.md`.

## Ce aduce versiunea 0.11.1

- publicare de release-uri `vm-doc-agent` direct din pagina **Agenți → Auto-update agent**;
- upload separat pentru binarul agent și `vm-doc-updater`, cu SHA-256 și actualizare atomică a manifestului;
- promovare `testing → stable` direct din UI;
- ștergere controlată a release-urilor; artifactele comune altui canal nu sunt șterse;
- pregătit pentru `vm-doc-agent 1.3.2`, care repară și întărește detecția versiunilor serviciilor.

Vezi `docs/UPGRADE-0.11.1.md` și `docs/AGENT-UPDATES.md`.

## Ce aduce versiunea 0.11.0

- filtrare după nume și stare în lista serviciilor systemd/Windows din pagina VM; implicit sunt afișate serviciile active;
- rutele de rețea sunt afișate tabelar;
- firewall-ul separă regulile explicite de regulile tehnice generate de backend-uri și ascunde implicit zgomotul iptables/nftables;
- pagina Rapoarte este împărțită în subcategorii;
- repository central de auto-update pentru `vm-doc-agent 1.3.0+`, cu `stable/testing`, SHA256 și rollback prin `vm-doc-updater`;
- pagina Agenți afișează versiunea raportată și release-urile publicate.

Vezi `docs/UPGRADE-0.11.0.md` și `docs/AGENT-UPDATES.md`.

## Ce aduce versiunea 0.10.0

- serviciile raportate de agent pot fi marcate persistent ca **Principale** direct din fișa VM;
- selecția rămâne valabilă între snapshoturi și semnalează explicit un serviciu principal care nu mai este detectat;
- fișa DOCX a VM-ului evidențiază separat componentele software principale și versiunile raportate de agent;
- fișa DOCX a Serviciului intern agregă automat componentele software principale ale tuturor VM-urilor sale;
- interfața inventarului agentului folosește etichete utile pentru liste: mount point, port, username, comandă și nume serviciu în loc de `Element 1`, `Element 2` etc.;
- uptime-ul este prezentat în ani/luni/zile/ore în loc de secunde;
- suport pentru metadatele opționale `software_name`, `version`, `package_name`, `package_version` și `version_source` furnizate de `vm-doc-agent 1.3.1+`;
- migrarea `025_vm_primary_agent_services.up.sql` adaugă selecțiile persistente ale serviciilor principale.

Vezi `docs/UPGRADE-0.10.0.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.9.1

- hotfix pentru dependențele directe VM → Serviciu comun;
- citire robustă a dependențelor VM pe MariaDB;
- logging explicit pentru erorile endpointului de dependențe VM;
- fără migrare de bază de date.

Vezi `docs/UPGRADE-0.9.1.md`.

## Ce aduce versiunea 0.9.0

- pagina **Agenți** are căutare după nume/URL/UUID/eroare, filtru de status și paginare configurabilă;
- pagina **Servicii interne** are filtre după domeniu, categorie, criticitate, status documentație și tip serviciu, iar descrierile lungi sunt scurtate în tabel;
- cardurile de sumar din pagina serviciului sunt compacte, iar **PROD / TEST-UAT / DEV** apar numai dacă există VM-uri în mediul respectiv;
- concept nou **Serviciu comun / infrastructură partajată**, pentru AD, DNS, OpenLDAP, NTP, PKI, SMTP relay, proxy, logging, monitoring, backup, storage și alte servicii comune;
- un serviciu comun poate fi **global implicit** pentru toate serviciile sau poate fi asociat explicit numai serviciilor care îl folosesc;
- nomenclator nou **Tip dependență** și relații `Serviciu → Serviciu comun`;
- sunt suportate și **dependențe directe pe VM** pentru excepțiile tehnice care nu trebuie moștenite de tot serviciul;
- pagina VM afișează dependențele comune moștenite, globale și directe, inclusiv VM-urile care furnizează serviciul comun;
- pagina și schema Serviciului intern afișează infrastructura comună separat de VM-urile proprii, fără duplicarea acestora;
- fișele DOCX VM și Serviciu includ dependențele comune, furnizorii și proveniența relației; fișa unui serviciu comun include și analiza de impact asupra serviciilor dependente;
- modulul **Rapoarte** include servicii comune/globale, tipuri de dependență și analize de impact pe servicii și VM-uri.

Vezi `docs/UPGRADE-0.9.0.md`, `docs/SERVICE-CATALOG.md`, `docs/SERVICE-DIAGRAM.md`, `docs/DOCUMENT-GENERATION.md` și `docs/REPORTS.md`.


## Ce aduce versiunea 0.8.0

- mediul fiecărui VM este evidențiat în Serviciul intern și în fișa DOCX, cu grupare **PROD / TEST-UAT / DEV / alte medii**;
- fiecare VM asociat afișează ultima fișă tehnică generată, cu link direct către document;
- la generarea fișei serviciului se poate activa **Include fișele VM ca anexe**; aplicația reutilizează ultima fișă sau generează automat una dacă lipsește;
- opțiunea **Regenerează fișele VM înainte de anexare** produce un snapshot complet nou al documentației;
- pachetul ZIP al serviciului conține DOCX-ul principal și anexele VM exacte fixate la momentul generării;
- meniul **Rapoarte** oferă indicatori și grafice fără dependențe JavaScript externe: donut/pie, bare și timeline;
- rapoartele acoperă infrastructura VM, mediile, resursele, inventarul, agenții, backup-ul, serviciile, clasificarea, rolurile și gradul de documentare.

Vezi `docs/UPGRADE-0.8.0.md`, `docs/REPORTS.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.7.3

- corectează focusul editorului rich-text pentru **Scop și domeniu** și **Obiective**;
- zona `contenteditable` nu mai este învelită într-un element `<label>`, astfel încât clickul în editor nu mai selectează butonul **Bold**;
- adaugă etichete accesibile prin `aria-labelledby` și focus explicit prin `tabindex=0`;
- nu introduce migrare MariaDB și nu modifică datele existente.

## Ce aduce versiunea 0.7.2

- **Scop și domeniu** și **Obiective** folosesc acum editor rich-text direct în aplicație;
- editorul suportă paragrafe, rânduri noi, **bold**, *italic*, underline, liste cu bullets, liste numerotate și indentare;
- formatarea este stocată într-un format JSON restricționat, fără HTML executabil;
- câmpurile plain-text `purpose` și `objectives` sunt păstrate și sincronizate automat pentru compatibilitate API și placeholdere;
- fișa DOCX reproduce formatarea rich-text: stilurile de text, bullets, numerotarea și nivelurile de indentare;
- datele vechi plain-text sunt convertite automat în editor la citire, fără pierderea conținutului;
- migrarea `022_service_rich_text.up.sql` adaugă numai coloanele de formatare, fără să modifice valorile existente.

Vezi `docs/UPGRADE-0.7.2.md`, `docs/SERVICE-CATALOG.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.7.1

- serviciul intern are acum câmpurile narative **Scop și domeniu** și **Obiective**, afișate în carduri aerisite în pagina serviciului;
- valoarea tehnică `purpose` este păstrată pentru compatibilitate, dar în UI și documentație reprezintă **Scop și domeniu**;
- fișa DOCX a serviciului include automat Scop și domeniu, Obiective și **Schema logică a serviciului**;
- schema DOCX este construită din aceleași asocieri VM ca schema din interfață; un VM apare o singură dată chiar dacă are mai multe roluri;
- VM-urile multi-role / multi-layer păstrează toate asocierile în același nod, grupate într-o zonă **Multi-layer**;
- placeholdere noi pentru șabloane: `{{service.scope_domain}}` și `{{service.objectives}}`;
- migrarea `021_service_scope_objectives_docx_diagram.up.sql` adaugă numai coloana `objectives`; câmpul `purpose` existent este reutilizat fără pierdere de date.

Vezi `docs/UPGRADE-0.7.1.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.7.0

- schemă logică automată pe pagina fiecărui **Serviciu intern**, construită exclusiv din asocierile VM;
- fiecare VM apare **o singură dată** în schemă, chiar dacă are două sau mai multe asocieri pentru același serviciu;
- VM-urile cu un singur layer sunt grupate pe layer, iar cele cu roluri în mai multe layere apar în zona **Multi-layer**;
- fiecare nod VM afișează toate rolurile tehnice, layer-ele, tipurile de soluție și încadrarea Domeniu/Categorie;
- câmp nou `icon_key` pe valorile nomenclatoarelor, editabil din interfață și exportat în Excel;
- pictograme implicite pentru Domeniu, Categorie, Layer, Rol tehnic și Tip soluție, cu mapări mai expresive pentru aplicație, baze de date, web/proxy, integrare, monitorizare și securitate;
- migrarea `020_service_diagram_icons.up.sql` extinde nomenclatoarele fără a modifica asocierile existente.

Vezi `docs/UPGRADE-0.7.0.md` și `docs/SERVICE-DIAGRAM.md`.

## Ce aduce versiunea 0.6.0

- nomenclator nou **Tip soluție**, cu valorile inițiale **Open source**, **Dezvoltată intern** și **Comercială**;
- tipul soluției se salvează pe fiecare asociere `VM → Serviciu intern → Layer → Rol tehnic`;
- fișa VM afișează asocierile cu serviciile în carduri separate și mai aerisite: Clasificare serviciu, Arhitectură tehnică și Context;
- pagina Serviciului intern agregă automat domeniile/categoriile, tipurile de soluție, layer-ele/rolurile și VM-urile;
- generare DOCX și pentru **Serviciu intern**, cu previzualizare, număr `FSI-*`, SHA-256 și istoric;
- șabloanele DOCX sunt tipizate `vm` sau `service`, cu câte un șablon implicit pentru fiecare tip;
- migrarea `019_service_documents_solution_type.up.sql` extinde asocierile, șabloanele și istoricul documentelor.

Vezi `docs/UPGRADE-0.6.0.md`, `docs/SERVICE-CATALOG.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.5.1

- fișa DOCX folosește un inventar agent compact, cu tabele dedicate în locul listării brute a JSON-ului;
- secțiunile Agent și Proxy sunt eliminate din document, iar `uptime_seconds` nu mai este afișat;
- stocarea este afișată pe partiție, filesystem și capacitate umanizată în GB/TB;
- rețeaua, serviciile active, porturile, regulile UFW, conturile importante, SSSD, integrările, cron și NTP au tabele minimaliste;
- serviciile inactive, conturile de sistem neimportante și regulile firewall care nu provin din `ufw status numbered` sunt omise;
- tabelele DOCX au acum `w:tblGrid`, lățimi fixe și rânduri care nu se rup, pentru randare stabilă în Word și LibreOffice;
- actualizarea nu introduce migrare MariaDB.

Vezi `docs/UPGRADE-0.5.1.md` și `docs/DOCUMENT-GENERATION.md`.

## Ce aduce versiunea 0.5.0

- generează fișa tehnică a unui VM în format DOCX, direct din pagina VM-ului;
- include datele vCenter, încadrarea operațională, servicii și roluri, responsabilități, backup și inventarul curent al agentului;
- previzualizare înainte de generare, cu avertismente pentru datele lipsă;
- șabloane DOCX administrabile din meniul **Documente**;
- șablon implicit creat automat la prima pornire după migrare;
- șabloanele personalizate folosesc placeholderul obligatoriu `{{VM_DOCUMENT_BODY}}` și placeholdere scalare pentru antet;
- istoric per VM, număr unic de document, autor, dată, snapshot sursă, SHA-256 și descărcare ulterioară;
- permisiuni RBAC separate: `documents.read` și `documents.manage`;
- migrarea `018_document_generation.up.sql` creează tabelele pentru șabloane și documentele generate.

Vezi `docs/UPGRADE-0.5.0.md` și `docs/DOCUMENT-GENERATION.md`.


## Ce aduce versiunea 0.4.4

- toate nomenclatoarele sunt afișate în ordinea ierarhică: ordinea părintelui, apoi ordinea proprie și denumirea;
- categoriile de serviciu urmează ordinea domeniilor, iar rolurile tehnice urmează ordinea layer-elor;
- fiecare pagină de nomenclator are căutare text și filtru de stare;
- categoriile de serviciu pot fi filtrate după domeniu, iar rolurile tehnice după layer;
- Persoanele pot fi filtrate după departament, sursă și stare;
- paginarea lucrează pe rezultatele filtrate, iar exportul Excel rămâne complet și folosește aceeași ordine;
- versiunea nu necesită migrare MariaDB.

Vezi `docs/UPGRADE-0.4.4.md`.

## Ce aduce versiunea 0.4.3

- toate listele din **Nomenclatoare**, inclusiv **Persoane**, au paginare cu 10, 20, 50 sau 100 de rânduri pe pagină;
- fiecare nomenclator are export Excel `.xlsx`, cu toate valorile active și inactive, indiferent de pagina afișată;
- exportul păstrează relațiile specifice: domeniul părinte pentru categoriile de serviciu și layer-ele permise pentru rolurile tehnice;
- exportul Persoane include departamentul, datele de contact, sursa și utilizatorul AD;
- actualizarea nu introduce migrare MariaDB.

Vezi `docs/UPGRADE-0.4.3.md`.

## Ce aduce versiunea 0.4.2

- corectează încărcarea inventarului curent din fișa VM; interogarea după `current_inventory_id` transmite acum identificatorul către MariaDB;
- elimină eroarea SQL `Error 1064 ... near '?' at line 1` și avertismentul „Fișa a fost încărcată parțial”;
- JSON-ul agentului nu este modificat și nu este necesară recollectarea inventarului;
- actualizarea nu introduce migrare MariaDB.

Vezi `docs/UPGRADE-0.4.2.md`.

## Ce aduce versiunea 0.4.1

- denumirea din interfață este **Categorie de serviciu**; identificatorul intern `itil_category` este păstrat pentru compatibilitate cu baza și API-ul;
- pagina **Nomenclatoare → Persoane** poate interoga Active Directory folosind configurația LDAP existentă;
- utilizatorii sunt citiți recursiv dintr-un OU rădăcină configurabil și sunt afișați arborescent după sub-OU-uri;
- lista este filtrată după atributul AD `department`; implicit este ales primul departament în ordine alfabetică, dacă `default_department` nu este configurat;
- utilizatorii selectați sunt importați sau actualizați în registrul local de persoane și devin disponibili în responsabilitățile VM;
- migrarea `016` include corecția ordinii indexurilor, iar migrarea `017` adaugă identitatea de director pentru persoane.

Vezi `docs/UPGRADE-0.4.1.md` și `docs/CONFIGURATION.md`.

## Ce aduce versiunea 0.4.0

- domeniul arhitectural și categoria de serviciu se selectează pe fiecare asociere din fișa VM;
- serviciul intern nu mai are domeniu sau categorie configurate manual;
- pagina Servicii agregă automat toate combinațiile `Domeniu → Categorie de serviciu` observate pe VM-urile asociate;
- un serviciu poate apărea în mai multe domenii sau categorii, fără duplicarea serviciului în catalog;
- fișa VM folosește cascada `Domeniu → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- backendul validează relația categorie–domeniu și relația rol–layer;
- migrarea `016_vm_service_classification.up.sql` copiază încadrarea existentă pe asocierile VM, fără pierderea datelor.

Vezi `docs/UPGRADE-0.4.0.md` și `docs/SERVICE-CATALOG.md`.

## Ce aduce versiunea 0.3.9

- pagina **Nomenclatoare** folosește un submeniu lateral și afișează o singură listă la un moment dat;
- opțiunile sunt grupate în **Catalog servicii**, **Arhitectură tehnică**, **Operare VM** și **Responsabilități**;
- fiecare opțiune afișează numărul de valori și are o rută proprie, păstrată la reîncărcarea paginii;
- pe ecrane mici, submeniul se transformă într-o grilă adaptivă;
- nu există modificări de bază de date.

Vezi `docs/UPGRADE-0.3.9.md`.

## Ce aduce versiunea 0.3.8

- selecția funcțională se face exclusiv pe fișa VM în cascada `Domeniu arhitectural → Serviciu intern → Layer → Rol tehnic`;
- domeniul filtrează serviciile, iar layer-ul filtrează rolurile tehnice permise global;
- serviciul intern nu mai configurează combinații layer–rol; pagina serviciului le agregă automat din VM-urile asociate;
- backendul validează numai existența serviciului și relația globală `Layer → Rol tehnic`;
- la adăugarea sau editarea unui rol tehnic, layer-ele se aleg dintr-un selector multiplu cu căutare, complet offline;
- rolurile tehnice sunt afișate după ordinea layer-ului, apoi după ordinea rolului în layer;
- versiunea nu introduce o migrare de schemă; tabelul vechi de configurare pe serviciu rămâne doar pentru compatibilitatea revenirii la 0.3.7 și nu mai este utilizat.

Vezi `docs/UPGRADE-0.3.8.md`.

## Ce aduce versiunea 0.3.7

- fiecare rol tehnic este legat de unul sau mai multe layer-e arhitecturale;
- în Nomenclatoare, rolul tehnic se editează împreună cu layer-ele permise;
- în pagina Serviciului intern, lista de roluri este filtrată după layer;
- backendul respinge orice combinație layer–rol care nu este definită global;
- perechile deja folosite sunt migrate automat și nu pot fi eliminate cât timp sunt utilizate.

Vezi `docs/UPGRADE-0.3.7.md`.

## Ce aduce versiunea 0.3.6

- un VM poate avea mai multe servicii interne asociate;
- același serviciu poate avea pe același VM mai multe combinații `Layer arhitectural → Rol tehnic`;
- fiecare asociere poate fi dedicată, partajată sau dependență și poate fi marcată drept principală;
- serviciul, layer-ul și rolul nu mai sunt câmpuri unice în formularul operațional;
- profilul și data provisionării sunt eliminate din modelul funcțional și din nomenclatoare;
- lifecycle-ul local `Retired` nu mai este expus în interfață/API; valorile existente sunt migrate la `Status operațional: Retras`;
- cardul redundant „Rezumat ultimul inventar” este eliminat; rămân ultimul inventar, datele agentului și istoricul paginat.

Vezi `docs/SERVICE-CATALOG.md` și `docs/UPGRADE-0.3.6.md`.

## Ce aduce versiunea 0.3.5

- corectează încărcarea fișei VM: erorile din datele operaționale sau backup nu mai blochează întreaga pagină;
- jurnalizează explicit toate etapele endpointului `GET /api/v1/vms/{id}` (`vm`, `operational`, `backup`, `agent`, `inventory`, `inventory_document`);
- afișează dinamic versiunea reală raportată de endpointul `/version`, eliminând eticheta hard-codată `0.3.2`.

## Ce aduce versiunea 0.3.4

- fișa VM nu mai cade complet dacă agentul sau inventarul curent au date inconsistente;
- erorile opționale sunt jurnalizate și afișate ca avertismente în interfață.

## Ce aduce versiunea 0.3.3

- datele detaliate colectate de agent sunt restrânse implicit;
- istoricul inventarelor și evenimentele de audit sunt paginate;

- meniu principal **Servicii**, separat de nomenclatoare;
- `Serviciu` ITIL este redenumit **Categorie de serviciu**, iar vechea `Componentă` devine **Serviciu intern**;
- încadrare strictă și selecție în cascadă: `Domeniu arhitectural → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- fiecare categorie de serviciu este legată de un domeniu arhitectural;
- fiecare serviciu intern definește combinațiile layer–rol permise;
- pagina serviciului centralizează informațiile serviciului, VM-urile asociate și pregătește unitatea viitoare de documentare DOCX/PDF;
- validare identică în browser și în API, astfel încât combinațiile incompatibile nu pot fi salvate;
- migrarea `013_internal_service_catalog.up.sql` păstrează și convertește datele existente.

Vezi `docs/SERVICE-CATALOG.md` și `docs/UPGRADE-0.3.3.md`.

## Ce aduce versiunea 0.3.1

- meniu administrativ **Nomenclatoare** cu liste controlate pentru încadrarea VM-urilor;
- serviciu, componentă, domeniu arhitectural, layer, mediu, status operațional, profil de provisionare și clasificare sunt selectate din list-box-uri;
- registru de persoane și responsabilități multiple pe VM;
- politica de backup este scoasă din formularul operațional și afișată într-o secțiune separată, pregătită pentru datele Veeam API;
- valorile text și responsabilitățile existente sunt migrate automat la prima pornire.

## Ce aduce versiunea 0.3.0

- fișa tehnică a VM-ului este afișată pe carduri și secțiuni, nu doar ca JSON brut;
- inventarul agentului este transformat într-o vedere structurată și ordonată pentru sistem, rețea, stocare, servicii, porturi, firewall, SSSD, integrări, politici și NTP;
- câmpurile care pot conține parole, tokenuri, secrete sau chei private sunt mascate în vederea structurată;
- date operaționale editabile, păstrate separat de snapshoturile agentului: serviciu, componentă, domeniu arhitectural, layer, mediu, status, scop, responsabili, profil/data provisionării, RPO/RTO, backup, clasificare, documentație, tichet și observații;
- migrarea `011_vm_operational_metadata.up.sql` și audit pentru modificarea datelor operaționale;
- endpoint nou `PUT /api/v1/vms/{id}/operational` și OpenAPI actualizat;
- interfață adaptivă, cu secțiuni pliabile și afișare ierarhică a listelor și obiectelor colectate.

## Ce aduce versiunea 0.2.2

- căutare VM în nume, hostname, power state, sistem de operare, IP, agent și sursă vCenter;
- filtre distincte pentru power, stare agent, `Retired` și sursă;
- paginare server-side cu 25, 50, 100 sau 200 de înregistrări pe pagină;
- statistici calculate pentru rezultatul filtrat;
- export Excel real `.xlsx`, cu aceleași filtre, antet fix, auto-filter și lățimi de coloane;
- corectarea antetului tabelului VM, care nu mai acoperă primul rând;
- răspunsuri `[]` pentru listele vCenter goale și corecția conflictului rutelor Swagger din Go 1.23.

## Ce aduce versiunea 0.2.0

- surse vCenter multiple, cu credențiale criptate individual;
- importul tuturor VM-urilor vizibile prin API-ul vCenter;
- buton de sincronizare manuală și sincronizare automată zilnică;
- istoric pentru fiecare rulare vCenter: găsite, adăugate, actualizate, lipsă și agenți asociați;
- câmp local `Retired`, notă și audit, păstrate la sincronizările ulterioare;
- VM-urile care dispar din vCenter sunt marcate `missing`, nu șterse automat;
- asociere automată VM–agent după BIOS/DMI UUID și asociere manuală din interfață;
- stare agent, ultimul contact, ultima colectare și butoane **Testează** / **Sincronizează acum** în fișa VM;
- parser corect pentru schema agentului 2.0: `agent.id`, `agent.version`, `collection.collectors` și câmpurile de corelare VMware;
- API/OpenAPI și interfață actualizate.

## Componente

- `vm-doc-server`: API, frontend, autentificare, RBAC, audit și scheduler vCenter;
- `vm-doc-collector`: coadă persistentă și interogarea agenților;
- MariaDB: surse vCenter, VM-uri, status operațional, asocieri multiple cu servicii, joburi și snapshoturi JSON.

Serverul web contactează vCenter. Numai `vm-doc-collector` contactează agenții.

## Compilare

Necesită Go 1.23 sau mai nou și modulele declarate în `go.mod`.

```bash
make test
make build
```

Binarele sunt generate în `bin/`.

Pentru un server fără internet, pregătiți pe o stație conectată un pachet cu `vendor/`:

```bash
go mod download
go mod vendor
go test -mod=vendor ./...
```

Apoi transferați întregul director al proiectului și compilați cu:

```bash
CGO_ENABLED=0 go build -mod=vendor -trimpath -o bin/vm-doc-server ./cmd/vm-doc-server
CGO_ENABLED=0 go build -mod=vendor -trimpath -o bin/vm-doc-collector ./cmd/vm-doc-collector
```

## Instalare și upgrade

Instalarea inițială rămâne aceeași ca în 0.1.0. La prima pornire, migrațiile sunt aplicate automat. Versiunea 0.4.1 aplică migrarea `017_service_category_ad_directory.up.sql`, păstrează compatibilitatea cu identificatorul `itil_category` și corectează reluarea sigură a migrării `016_vm_service_classification.up.sql`.

Pentru upgrade:

1. faceți backup la baza MariaDB și la configurație;
2. opriți `vm-doc-server` și `vm-doc-collector`;
3. înlocuiți binarele și fișierele web incluse în binar;
4. păstrați `version: 1` în `config.yaml` și adăugați secțiunea opțională `vcenter`;
5. porniți mai întâi serverul, apoi collectorul;
6. adăugați sursa vCenter din pagina **VM-uri** și porniți prima sincronizare.

Pentru actualizarea curentă consultați `docs/UPGRADE-0.4.1.md`. Pentru instalarea vCenter consultați și `docs/UPGRADE-0.2.0.md` și `docs/VCENTER.md`.

## API

- document OpenAPI: `/api/openapi.yaml`;
- Swagger UI: `/docs/`;
- health: `/healthz`;
- readiness: `/readyz`;
- versiune: `/version`.

## Securitate

- parolele vCenter și tokenurile agenților sunt criptate AES-256-GCM înainte de salvarea în MariaDB;
- API-ul nu returnează secretele;
- `verify_tls` trebuie menținut activ în producție;
- contul vCenter trebuie să fie dedicat și limitat la operațiile de inventariere necesare;
- modificările datelor operaționale, asocierilor multiple și sincronizările manuale sunt auditate.

## Limitări cunoscute

- custom attributes generale din vCenter nu sunt încă importate; statusul operațional este administrat local din nomenclator;
- operația REST `GET /api/vcenter/vm` returnează maximum 4.000 de VM-uri per sursă; pentru inventare mai mari este necesară împărțirea sursei sau o sincronizare filtrată într-o versiune ulterioară;
- exportul DOCX/PDF și retenția automată vor fi dezvoltate ulterior; exportul Excel este disponibil din 0.2.2;
- arhiva sursă standard nu conține dependențe vendorizate.

## Autoînregistrarea agenților

Versiunea 0.2.2 lucrează cu `vm-doc-agent 1.1.0` și creează automat agenții, primește heartbeat și inventarul push. Vezi `docs/AGENT-REGISTRATION.md`.
