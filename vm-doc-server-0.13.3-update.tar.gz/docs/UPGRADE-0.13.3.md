# Upgrade vm-doc-server 0.13.2 → 0.13.3

## Scop

0.13.3 este un hotfix pentru crash-ul serverului apărut după 0.13.2 la refresh-ul statusului de update al agenților. Stack trace-ul tipic conține:

```text
agentclient.(*Client).dialContext(0x0, ...)
agentclient.(*Client).ipAllowed(...)
panic: runtime error: invalid memory address or nil pointer dereference
```

În 0.13.2, `vm-doc-collector` inițializa clientul către agenți, dar procesul `vm-doc-server` transmitea `nil` către `collection.Service`. Heartbeat-ul și endpoint-ul de update au început să folosească acel client și puteau opri procesul.

## Ce repară

- inițializează `agentclient.Client` și în `cmd/vm-doc-server`;
- folosește `collector.allowed_networks` și `collector.max_inventory_size` existente;
- transmite clientul valid către `collection.New(...)`;
- adaugă protecție anti-panic în `agentclient`;
- adaugă test pentru cazul client nil.

Nu există migrare MariaDB nouă. Nu este necesară schimbarea configurației și nu este necesar un agent nou.

## Upgrade din sursa 0.13.2

```bash
cp -a /usr/local/src/vm-doc-server-0.13.2 /usr/local/src/vm-doc-server-0.13.3
tar -xzf vm-doc-server-0.13.3-update.tar.gz -C /usr/local/src/vm-doc-server-0.13.3
cd /usr/local/src/vm-doc-server-0.13.3

GOPROXY=off GOFLAGS=-mod=vendor go test ./...
make build

systemctl stop vm-doc-server vm-doc-collector
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
install -m 0755 bin/vm-doc-collector /opt/vm-doc-server/bin/vm-doc-collector
install -m 0755 bin/vm-doc-agent-release /opt/vm-doc-server/bin/vm-doc-agent-release
systemctl start vm-doc-server vm-doc-collector
```

## Verificare

```bash
curl -s http://127.0.0.1:9080/version
journalctl -u vm-doc-server -n 100 --no-pager
journalctl -u vm-doc-collector -n 100 --no-pager
```

În UI:

1. deschide **Agenți → Listare agenți**;
2. testează **Test** și **Colect** pe un agent;
3. apasă **Update** pe un VM pilot;
4. confirmă că serverul rămâne activ și că nu mai apare `dialContext(0x0, ...)`.
