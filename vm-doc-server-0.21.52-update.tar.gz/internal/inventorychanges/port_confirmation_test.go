package inventorychanges

import "testing"

func portObject(name string) trackedObject {
	return trackedObject{Category: "ports", Type: "listening_port", Key: "tcp/80/apache2", Value: map[string]any{"protocol": "tcp", "port": 80, "process_names": []any{"apache2"}, "executables": []any{name}}}
}

func TestConfirmedPortTransitionSuppressesOneCollectionFlap(t *testing.T) {
	port := portObject("/usr/sbin/apache2")
	empty := trackedObject{}
	if confirmedPortTransition(port, empty, port, true, false, true) {
		t.Fatal("a vanished-then-returned TCP/80 must not emit a removal/addition")
	}
	if confirmedPortTransition(empty, port, empty, false, true, false) {
		t.Fatal("a one-snapshot TCP/80 listener must not emit a transient addition")
	}
	if confirmedPortTransition(port, port, empty, true, true, false) {
		t.Fatal("first missing sample is unconfirmed")
	}
	if confirmedPortTransition(empty, port, port, false, true, true) == false {
		t.Fatal("two observed samples must confirm actual addition")
	}
	if confirmedPortTransition(port, empty, empty, true, false, false) == false {
		t.Fatal("two absent samples must confirm actual removal")
	}
}

func TestConfirmedPortTransitionKeepsStableChanges(t *testing.T) {
	a := portObject("/usr/sbin/apache2")
	b := portObject("/opt/apache/bin/httpd")
	if !confirmedPortTransition(a, b, b, true, true, true) {
		t.Fatal("persistent executable change must be logged")
	}
	if confirmedPortTransition(a, b, a, true, true, true) {
		t.Fatal("temporary executable change must not be logged")
	}
	if confirmedPortTransition(a, a, a, true, true, true) {
		t.Fatal("unchanged port must not generate event")
	}
	if confirmedPortTransition(trackedObject{}, trackedObject{}, trackedObject{}, false, false, false) {
		t.Fatal("missing throughout")
	}
}
