# Upgrade VM-DOC Server 0.21.51 → 0.21.52

1. Faceți backup de surse, binar, config și MariaDB; verificați restore-ul într-un mediu izolat.
2. Opriți VM-DOC, aplicați doar peste sursele **0.21.51** `vm-doc-server-0.21.52-update.tar.gz` sau patch-ul. Sursele complete sunt în source.zip.
3. Pe serverul offline, păstrați `vendor/` și setările locale. Executați `GOPROXY=off go test ./internal/inventorychanges`, `GOPROXY=off go test ./...`, apoi build-ul conform `Makefile`; instalați numai dacă verificările cerute intern reușesc.
4. Porniți serverul; testați un port HTTP stabil (`TCP/80`, `apache2`) în colectări consecutive și verificați că evenimentele de fluctuație nu mai apar. Schimbările permanente sunt confirmate la a doua colectare după schimbare.
5. Curățare istoric **opțională, explicită**: opriți iar serverul, faceți dump MariaDB, rulați `scripts/preview-inventory-changes-cleanup.sql` și examinați `fluctuatii_porturi_confirmate` și regulile anterioare. Dacă sunteți de acord, rulați `scripts/cleanup-inventory-changes.sql` și verificați rândurile șterse. Scriptul este cumulativ 0.21.50/51/52 și repară identificarea regulilor firewall generate din `object_key`: nu executați separat scripturile anterioare.
6. Verificați evenimentele revizuite, legăturile VM/servicii și inventarele brute, apoi reporniți.

Nu există migrare SQL automată și nu este necesar update Agent 1.7.18. Ștergerea este ireversibilă fără backup; scriptul nu a fost testat aici cu baza MariaDB reală.

Rollback: restaurați binarul/sursele 0.21.51. Dacă ați rulat curățarea, doar backupul MariaDB reface evenimentele șterse.
