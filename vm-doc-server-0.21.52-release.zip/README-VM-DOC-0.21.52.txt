VM-DOC Server 0.21.52 — port history confirmation hotfix peste 0.21.51.
Pachetul include: surse complete, update incremental, patch, CONTEXT, CHANGELOG, TODO, release notes, upgrade/rollback, test logs si SQL PREVIEW/CLEANUP cumulativ.
NU aplicati incremental peste 0.21.49/0.21.50. Agent 1.7.18 nemodificat.
SQL-ul se ruleaza NUMAI manual, dupa backup si preview; nu se sterg inventarele brute. MariaDB staging trebuie testata.
