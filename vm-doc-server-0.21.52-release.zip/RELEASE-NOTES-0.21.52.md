# VM-DOC Server 0.21.52 — inventory port-flap noise reduction

Base version 0.21.51. No schema/API/agent changes; Agent 1.7.18 remains compatible.

- Stable port history: two consecutive snapshots are required to confirm a new port state, while other change categories remain immediate.
- Preserve important TCP/80 apache2 changes when they persist, with no blanket filtering for low ports or Principal ports.
- Manual preview/cleanup supports removal of pairs of opposite events with identical object/value on one VM, timestamp distance <= 10 minutes; decisions, reviews and notes are protected.
- Fix historical cleanup detection of generated firewall rules by using the actual object_key backend|family|table|chain|rule layout.
- Raw snapshots stay complete. No automatic DELETE at upgrade. Staging MariaDB validation before production is mandatory.
