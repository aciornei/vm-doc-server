# Upgrade vm-doc-server 0.16.0 → 0.16.1

0.16.1 este un release de UI/documentare și nu adaugă migrare SQL.

## Pași

1. Backup aplicație și bază de date.
2. Aplică `vm-doc-server-0.16.1-update.tar.gz` peste sursa 0.16.0 sau patch-ul 0.16.0 → 0.16.1.
3. Compilează: `go build -o vm-doc-server ./cmd/vm-doc-server`.
4. Înlocuiește binarul folosit de systemd și repornește `vm-doc-server`.
5. Fă refresh complet în browser (CSS/JS au cache-bust 0.16.1).

Nu există migrare SQL nouă. Pentru detecția Nginx din `/opt` este recomandat `vm-doc-agent 1.6.1`.
