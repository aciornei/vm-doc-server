package documents

import "testing"

func TestShortVersionDropsWarnings(t *testing.T) {
	cases := map[string]string{
		"mysql: [Warning] Using a password on the command line interface can be insecure.\nmysql  Ver 14.14 Distrib 5.5.37, for Linux (x86_64)": "5.5.37",
		"Warning: World-writable config file '/etc/my.cnf' is ignored\nmysqld  Ver 5.5.37 for Linux on x86_64":                                  "5.5.37",
		"mariadb  Ver 15.1 Distrib 10.11.13-MariaDB, for debian-linux-gnu":                                                                      "10.11.13",
		"nginx version: nginx/1.26.3": "1.26.3",
	}
	for input, want := range cases {
		if got := shortVersion(input); got != want {
			t.Fatalf("shortVersion(%q) = %q, want %q", input, got, want)
		}
	}
}

func TestCleanVersionTextRemovesOnlyWarningLines(t *testing.T) {
	input := "mysql: [Warning] ignored config\nmysql Ver 14.14 Distrib 5.5.37, for Linux"
	want := "mysql Ver 14.14 Distrib 5.5.37, for Linux"
	if got := cleanVersionText(input); got != want {
		t.Fatalf("cleanVersionText() = %q, want %q", got, want)
	}
}
