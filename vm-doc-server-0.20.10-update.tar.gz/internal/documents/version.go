package documents

import (
	"regexp"
	"strings"
)

var (
	shortVersionPattern   = regexp.MustCompile(`(?i)(?:^|[^0-9])v?([0-9]+(?:\.[0-9]+){1,3})`)
	distribVersionPattern = regexp.MustCompile(`(?i)\bDistrib\s+v?([0-9]+(?:\.[0-9]+){1,3})`)
	warningPrefixPattern  = regexp.MustCompile(`(?i)(?:^|:\s*)\[warning\]`)
)

func cleanVersionText(value string) string {
	value = strings.ReplaceAll(value, "\r\n", "\n")
	value = strings.ReplaceAll(value, "\r", "\n")
	lines := make([]string, 0, 4)
	for _, raw := range strings.Split(value, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" {
			continue
		}
		lower := strings.ToLower(line)
		if strings.HasPrefix(lower, "warning:") || strings.HasPrefix(lower, "warning ") || warningPrefixPattern.MatchString(line) {
			continue
		}
		lines = append(lines, line)
	}
	return strings.TrimSpace(strings.Join(lines, " "))
}

func shortVersion(value string) string {
	value = cleanVersionText(value)
	if value == "" {
		return ""
	}
	// mysql/mariadb client output starts with a client protocol version, e.g.
	// "mysql Ver 14.14 Distrib 5.5.37". The Distrib value is the useful product
	// version, so prefer it over the first dotted number.
	if m := distribVersionPattern.FindStringSubmatch(value); len(m) > 1 {
		return m[1]
	}
	if m := shortVersionPattern.FindStringSubmatch(value); len(m) > 1 {
		return m[1]
	}
	if i := strings.Index(value, " ("); i > 0 {
		value = value[:i]
	}
	if i := strings.Index(value, ","); i > 0 {
		value = value[:i]
	}
	return strings.TrimSpace(value)
}
