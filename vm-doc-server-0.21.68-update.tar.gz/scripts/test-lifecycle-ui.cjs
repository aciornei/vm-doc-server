'use strict';
// VM-DOC 0.21.68: isolated UI regression without MariaDB/vCenter or a browser.
const fs=require('node:fs'), vm=require('node:vm'), assert=require('node:assert/strict');
const source=fs.readFileSync('web/static/js/app.js','utf8');
const begin=source.indexOf('const lifecycleFilters=');
const end=source.indexOf('function lifecycleDialogNode()',begin);
assert.ok(begin>=0 && end>begin,'lifecycle UI functions must be present');
const records=[
 {type:'vm',id:1,name:'vm-retras',status:'retired',present_in_vcenter:true,power_state:'POWERED_OFF',reason:'Proiect închis'},
 {type:'vm',id:2,name:'vm-absent',status:'active',present_in_vcenter:false,power_state:'POWERED_OFF',reason:''},
 {type:'service',id:3,name:'Serviciu vechi',status:'archived',reason:'Dezafectat',approved_by:'Sysadmin',notes:'<script>alert(1)</script>',retention_until:'2028-10-21'}
];
const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const elements=new Map();
function element(id){if(!elements.has(id))elements.set(id,{id,value:'',innerHTML:'',textContent:'',listeners:{},addEventListener(name,fn){this.listeners[name]=fn},querySelectorAll(){return []},querySelector(){return {addEventListener(){}}}});return elements.get(id)}
const cards=[['vm','all'],['service','all'],['all','archived'],['vm','missing']].map(([type,status])=>({dataset:{type,status},attrs:{},listeners:{},setAttribute(k,v){this.attrs[k]=v},addEventListener(name,fn){this.listeners[name]=fn}}));
const document={getElementById:element,querySelectorAll(sel){return sel==='.lifecycle-stat-card'?cards:[]},querySelector(){return {scrollIntoView(){}}}};
const context={document,content:{innerHTML:''},pageMeta(){},api:async()=>records,e,badge:s=>`[${e(s)}]`,dt:s=>s||'—',empty:s=>e(s),can:()=>true,setTimeout:fn=>fn(),clearTimeout(){},location:{hash:'#archive'}};
vm.createContext(context);
vm.runInContext(source.slice(begin,end),context);
(async()=>{
 await vm.runInContext('lifecycleArchivePage()',context);
 assert.match(context.content.innerHTML,/class="lifecycle-workspace hardening-beta-host"/);
 assert.match(context.content.innerHTML,/class="hardening-beta"[^>]*>BETA<\/span>/);
 assert.match(context.content.innerHTML,/lifecycle-stat-card/);
 assert.match(context.content.innerHTML,/lifecycleReset/);
 assert.match(context.content.innerHTML,/lifecyclePageSize/);
 assert.match(element('lifecycleArchiveList').innerHTML,/vm-retras/);
 assert.match(element('lifecycleArchiveList').innerHTML,/Serviciu vechi/);
 assert.match(element('lifecycleArchiveList').innerHTML,/&lt;script&gt;/,'notes must remain escaped');
 assert.doesNotMatch(element('lifecycleArchiveList').innerHTML,/<script>/);
 cards[3].listeners.click();
 assert.equal(element('lifecycleStatus').value,'missing');
 assert.equal(element('lifecycleType').value,'vm');
 assert.match(element('lifecycleArchiveList').innerHTML,/vm-absent/);
 assert.doesNotMatch(element('lifecycleArchiveList').innerHTML,/vm-retras/);
 assert.equal(cards[3].attrs['aria-pressed'],'true');
 element('lifecycleReset').listeners.click();
 assert.equal(element('lifecycleStatus').value,'all');
 assert.equal(element('lifecycleType').value,'all');
 assert.match(element('lifecycleArchiveList').innerHTML,/vm-retras/);
 element('lifecyclePageSize').listeners.change({target:{value:'10'}});
 assert.equal(element('lifecyclePageSize').value,'25','select is controlled by UI when reset, but change event sets state only');
 assert.equal(vm.runInContext('lifecycleFilters.pageSize',context),10);
 if(process.env.VMDOC_SCREENSHOT_PREVIEW==='1'){
   const markup=context.content.innerHTML.replace('<div id="lifecycleArchiveList"></div>',`<div id="lifecycleArchiveList">${element('lifecycleArchiveList').innerHTML}</div>`);
   fs.writeFileSync('/mnt/data/vmdoc-0.21.68-work/preview-arhiva-0.21.68.html',`<!doctype html><html lang="ro" data-theme="dark"><head><meta charset="utf-8"><link rel="stylesheet" href="file://${process.cwd()}/web/static/css/app.css"><link rel="stylesheet" href="file://${process.cwd()}/web/static/css/ui-refresh.css"><style>body{min-width:0}.main{margin-left:0!important}.topbar{position:relative}.content{max-width:1600px;margin:auto}</style></head><body><main class="main"><header class="topbar"><div><h1>Arhivă VM & servicii</h1><p>Retragere, dezafectare și documentație istorică · BETA</p></div></header><section class="content">${markup}</section></main></body></html>`);
 }
 const css=fs.readFileSync('web/static/css/ui-refresh.css','utf8');
 assert.match(css,/\.lifecycle-workspace\.hardening-beta-host>\.hardening-beta/);
 console.log('PASS: archive BETA ribbon, summary filters, reset, safe rows and page size');
})().catch(err=>{console.error(err);process.exitCode=1});
