# VM-DOC 0.21.68 — Arhivă BETA / UI refresh

Modificare limitată la interfața Arhivă VM & servicii. Folosește panglica **BETA** roșie din Hardening, cu atenționare de validare. Pagina include KPI clicabile pentru navigarea în registru, etape compacte, filtrare/search, reset, page size și tabel cu observații expandabile și derulare orizontală. Funcțiile de retragere, arhivare, reactivare și audit rămân cele din 0.21.67.

**Fără backend/API/migrare/agent nou.** Este necesară recompilarea binarului Go pentru asseturile `go:embed` și validarea browser în staging. Scriptul de test independent: `node scripts/test-lifecycle-ui.cjs`.
