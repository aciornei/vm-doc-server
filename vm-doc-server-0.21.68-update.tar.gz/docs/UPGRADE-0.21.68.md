# Upgrade VM-DOC Server 0.21.67 → 0.21.68

1. Efectuează backup binar, configurație, surse și bază MariaDB pe staging.
2. Aplică **update.tar.gz** peste sursele 0.21.67 sau patch-ul incremental, **nu ambele**. Alternativ folosește sursele complete.
3. Cu `vendor/` din mediul offline: `GOPROXY=off GOSUMDB=off go test ./...`, `node --check web/static/js/app.js` și `node scripts/test-lifecycle-ui.cjs`.
4. Reconstruiește serverul Go prin procedura de build existentă — `web/static` este inclus în binar prin `go:embed`. Nu este suficientă copierea JS/CSS.
5. Înlocuiește binarul și repornește serviciul; verifică `/version`, `app.js?v=0.21.68`, `ui-refresh.css?v=0.21.68`.
6. Deschide **Arhivă VM & servicii**, verifică panglica BETA identică cu Hardening, cardurile clicabile și filtrele. Testează Light/Dark și ecran îngust cu tabelul derulabil orizontal.
7. Testează regresia Retrage / Arhivează / Reactivează, motive/aprobatori și protecțiile din 0.21.67. Această versiune schimbă numai UI.

**Nu există migrare SQL nouă, cleanup SQL sau schimbare de agent (1.7.18).** Migrarea 081 din 0.21.67 rămâne activă. Pentru rollback revino la binarul 0.21.67, păstrând toate datele.
