# VM-DOC Server 0.21.94 — Hotfix migrarea 085

0.21.93 nu a pornit în mediul utilizatorului, cu `Error 1005: Can't create table` la migrarea `085_vcenter_import_changes.up.sql`.

## Cauza identificată în surse

Migrarea 085 încerca să elimine/recreeze **două** FK într-un singur ALTER, inclusiv cel pentru `inventory_id`. Dar migrarea 082 făcuse deja `inventory_id` nullable şi setase `ON DELETE SET NULL` tocmai pentru a păstra istoricul la eliminarea snapshoturilor. 085 restaura accidental `ON DELETE CASCADE`. Detaliul `errno` din log nu este vizibil în captura furnizată; eroarea FK trebuie verificată pe MariaDB reală.

## Remediere

- Migrarea 085 operează **doar** asupra `agent_id`, care era încă `NOT NULL`.
- FK `fk_inventory_changes_agent` este eliminat (cu `IF EXISTS`), coloana devine `NULL`, apoi FK este restaurat într-un ALTER separat.
- Coloana `inventory_id` rămâne nemodificată, cu FK `ON DELETE SET NULL`.
- Migrarea 085 este reluată automat la prima pornire; nu se aplică 086. Scriptul down nu face DELETE automat.
- Funcţionalitatea din 0.21.93 pentru evenimentele importurilor noi de VM din VCSA rămâne identică.

## Testare şi limite

Verificări structurale efectuate pe arhiva de surse; integrarea cu MariaDB/VCSA şi build-ul complet necesită mediul local cu `vendor/`. Nu rulaţi scripturile SQL manual înainte de backup şi verificare.
