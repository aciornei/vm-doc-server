# VM-DOC 0.21.94 — Pachete

- `vm-doc-server-0.21.94-release.zip`: source + update + patch + documentaţie + SHA256.
- `vm-doc-server-0.21.94-source.zip`: surse complete; nu conține executabilul sau vendor.
- `vm-doc-server-0.21.93-to-0.21.94-update.tar.gz`: modificări pentru rădăcina surselor 0.21.93.
- `vm-doc-server-0.21.93-to-0.21.94.patch`: patch text din rădăcina surselor (`patch -p1`).
- `CONTEXT-0.21.94.md`, `CHANGELOG-0.21.94.md`, `VM-DOC-TODO-0.21.94.md`, note şi upgrade.
