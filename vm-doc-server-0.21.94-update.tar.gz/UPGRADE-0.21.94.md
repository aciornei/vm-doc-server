# Upgrade VM-DOC Server 0.21.93 → 0.21.94 (hotfix startup)

1. Opriţi bucla de repornire dacă este cazul: `sudo systemctl stop vm-doc-server`.
2. Faceţi un **backup restaurabil** al MariaDB (structură şi date) şi salvaţi binarul/configul actual. Nu rulaţi `.down.sql` şi nu ştergeţi tabele.
3. Aplicaţi incrementalul peste sursele existente 0.21.93 sau extrageţi `vm-doc-server-0.21.94-source.zip`. Fișierele de distribuţie NU conţin `vendor/`/binar şi nu înlocuiesc configuraţia locală.
4. Din rădăcina surselor, cu `vendor/` disponibil, recompilaţi:

   ```bash
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
   ```

5. Identificaţi cu `systemctl cat vm-doc-server` calea executabilului din `ExecStart`; copiaţi **noul** `bin/vm-doc-server` peste executabilul instalat, păstrând copia anterioară; porniţi serviciul.
6. Migrarea **085** este reluată automat. Verificaţi:

   ```bash
   sudo journalctl -u vm-doc-server -n 100 --no-pager -l
   ```

   Apoi `/version` trebuie să afişeze 0.21.94 şi browserul trebuie reîmprospătat forţat.

7. Din MariaDB (SELECT read-only):

   ```sql
   SELECT COLUMN_NAME, IS_NULLABLE FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'inventory_changes'
     AND COLUMN_NAME IN ('agent_id', 'inventory_id');
   SELECT CONSTRAINT_NAME, DELETE_RULE FROM information_schema.REFERENTIAL_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME='inventory_changes'
     AND CONSTRAINT_NAME IN ('fk_inventory_changes_agent','fk_inventory_changes_inventory');
   SELECT version FROM schema_migrations WHERE version LIKE '085_%';
   ```

   Aşteptat: ambele coloane `YES`, agent = `CASCADE`, inventar = `SET NULL`, migrarea 085 înregistrată.

**Dacă serverul nu porneşte**: nu repetaţi manual ALTER şi nu dezactivaţi verificarea FK. Extrageţi eroarea completă `journalctl ... -l` şi `SHOW ENGINE INNODB STATUS\G` (latest foreign key error) pentru diagnostic. Alternativ, reveniţi temporar la **binarul 0.21.92 salvat**, fără rollback SQL.
