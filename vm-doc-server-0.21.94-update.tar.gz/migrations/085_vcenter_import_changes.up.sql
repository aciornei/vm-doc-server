-- VM-DOC 0.21.94 HOTFIX: repară migrarea 085 eşuată în 0.21.93.
-- Nu modifica inventory_id: migrarea 082 l-a făcut deja NULL cu ON DELETE SET NULL
-- pentru păstrarea istoricului la expirarea snapshoturilor.
-- Pe MariaDB, nu elimina şi recrea acelaşi FK în aceeaşi instrucţiune ALTER.
-- Se folosesc operaţii distincte, reluabile după un DDL parţial.
-- NOTĂ: fiecare ALTER poate efectua autocommit; aplicaţia rămâne oprită la migrare.
ALTER TABLE inventory_changes
  DROP FOREIGN KEY IF EXISTS fk_inventory_changes_agent;

ALTER TABLE inventory_changes
  MODIFY COLUMN agent_id BIGINT UNSIGNED NULL;

ALTER TABLE inventory_changes
  ADD CONSTRAINT fk_inventory_changes_agent
  FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE;
