-- Nu executaţi automat rollback 085.
-- Revenirea la NOT NULL pe agent_id ar impune eliminarea evenimentelor VCSA fără agent,
-- iar o revenire a inventory_id ar anula protecţiile migrării 082.
-- Pentru revenirea la binarul 0.21.92 nu este nevoie de rollback SQL.
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Rollback 085 necesită procedură manuală şi backup; niciun rând nu a fost şters';
