package inventorychanges

import (
	"testing"
)

func TestEphemeralVethInterfaceNames(t *testing.T) {
	names := []string{"veth8a3f7c2", "veth00ffAabb", "VETH4A8B19@if123", " vethac09e9f "}
	for _, name := range names {
		if !isEphemeralVethInterface(name) {
			t.Fatalf("transient veth interface not recognized: %q", name)
		}
	}
	kept := []string{"eth0", "ens192", "bond0", "br-8a3f7c2", "docker0", "vlan100", "veth-management", "veth0", "veth-prod", "tun0", "cali9ac3e"}
	for _, name := range kept {
		if isEphemeralVethInterface(name) {
			t.Fatalf("persistent/non-hex interface suppressed: %q", name)
		}
	}
}

func TestEphemeralVethOmittedOnlyFromChangeTracking(t *testing.T) {
	raw := []byte(`{"network":{"interfaces":[{"name":"veth0f13bca","mac":"aa:00:00:00:00:01","addresses":["169.254.1.1"]},{"name":"vethA1B2C3@if8","mtu":1500},{"name":"ens192","mtu":1500,"addresses":["192.168.0.10"]},{"name":"docker0","mtu":1500},{"name":"br-cafe1234","mtu":1500},{"name":"veth-management","mtu":1400}],"dns_servers":["192.168.0.1"],"default_gateways":["192.168.0.254"]}}`)
	objects, err := extractTracked(raw)
	if err != nil {
		t.Fatal(err)
	}
	for _, key := range []string{"network|interface|veth0f13bca", "network|interface|vethA1B2C3@if8"} {
		if _, present := objects[key]; present {
			t.Fatalf("transient interface in tracked objects: %s", key)
		}
	}
	for _, key := range []string{"network|interface|ens192", "network|interface|docker0", "network|interface|br-cafe1234", "network|interface|veth-management", "network|resolver|resolver"} {
		if _, present := objects[key]; !present {
			t.Fatalf("important interface/DNS omitted: %s", key)
		}
	}
	changed := []byte(`{"network":{"interfaces":[{"name":"vethd012345"},{"name":"ens192","mtu":9000,"addresses":["192.168.0.11"]},{"name":"docker0","mtu":1500},{"name":"br-cafe1234","mtu":1500},{"name":"veth-management","mtu":1400}],"dns_servers":["192.168.0.2"]}}`)
	next, err := extractTracked(changed)
	if err != nil {
		t.Fatal(err)
	}
	if _, ok := next["network|interface|vethd012345"]; ok {
		t.Fatal("new transient peer tracked")
	}
	if canonicalEqual(objects["network|interface|ens192"].Value, next["network|interface|ens192"].Value) {
		t.Fatal("permanent NIC change suppressed")
	}
	if canonicalEqual(objects["network|resolver|resolver"].Value, next["network|resolver|resolver"].Value) {
		t.Fatal("DNS change suppressed")
	}
}
