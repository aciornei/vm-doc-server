package agentclient

import (
	"context"
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"

	"vm-doc-server/internal/domain"
)

func TestValidateTargetRejectsCredentialsAndPath(t *testing.T) {
	client, err := New([]string{"10.0.0.0/8"}, 1024)
	if err != nil {
		t.Fatal(err)
	}
	for _, raw := range []string{
		"https://user:password@vm1:9078",
		"https://vm1:9078/api",
		"file:///tmp/inventory.json",
	} {
		if err := client.validateTarget(context.Background(), raw); err == nil {
			t.Fatalf("target %q unexpectedly accepted", raw)
		}
	}
}

func TestUpdateStatusAndForceUpdate(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer secret" {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/v1/update":
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{"enabled":true,"auto_install":true,"channel":"testing","current_version":"1.3.3","state":"idle"}`))
		case r.Method == http.MethodPost && r.URL.Path == "/v1/update/check":
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{"enabled":true,"auto_install":true,"channel":"testing","current_version":"1.3.3","state":"installing","available_version":"1.3.4"}`))
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()

	client, err := New(nil, 1<<20)
	if err != nil {
		t.Fatal(err)
	}
	agent := domain.Agent{BaseURL: server.URL, RequestTimeoutSeconds: 5}
	status, err := client.UpdateStatus(context.Background(), agent, "secret")
	if err != nil {
		t.Fatal(err)
	}
	if status.Channel != "testing" || status.CurrentVersion != "1.3.3" || status.State != "idle" {
		t.Fatalf("unexpected status: %+v", status)
	}
	status, err = client.ForceUpdate(context.Background(), agent, "secret")
	if err != nil {
		t.Fatal(err)
	}
	if status.State != "installing" || status.AvailableVersion != "1.3.4" {
		t.Fatalf("unexpected forced update status: %+v", status)
	}
}

func TestNilClientReturnsErrorInsteadOfPanicking(t *testing.T) {
	var client *Client
	agent := domain.Agent{BaseURL: "http://127.0.0.1:9078", RequestTimeoutSeconds: 1}

	if _, err := client.Test(context.Background(), agent, "secret"); err == nil {
		t.Fatal("nil client unexpectedly succeeded")
	}
	if _, err := client.UpdateStatus(context.Background(), agent, "secret"); err == nil {
		t.Fatal("nil client update status unexpectedly succeeded")
	}
	if _, err := client.ForceUpdate(context.Background(), agent, "secret"); err == nil {
		t.Fatal("nil client force update unexpectedly succeeded")
	}
}

func TestEffectiveManagementURLReplacesLiteralVIP(t *testing.T) {
	got := effectiveManagementURL("http://10.20.30.20:9078", "10.20.30.40")
	if got != "http://10.20.30.40:9078" {
		t.Fatalf("effective URL = %q", got)
	}
	got = effectiveManagementURL("https://agent01.example.test:9078", "10.20.30.40")
	if got != "https://agent01.example.test:9078" {
		t.Fatalf("DNS endpoint should remain authoritative, got %q", got)
	}
}

func TestRequestUsesManagementIPInsteadOfLiteralVIP(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/v1/status" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"status":"ok"}`))
	}))
	defer server.Close()

	// Keep the test server port, but deliberately store a different loopback
	// address as the stale/VIP endpoint. The request can only succeed when the
	// management IP replaces the stale literal host.
	u, err := url.Parse(server.URL)
	if err != nil {
		t.Fatal(err)
	}
	vipURL := "http://127.0.0.2:" + u.Port()
	client, err := New(nil, 1<<20)
	if err != nil {
		t.Fatal(err)
	}
	agent := domain.Agent{BaseURL: vipURL, ManagementIP: "127.0.0.1", RequestTimeoutSeconds: 5}
	if _, err := client.Test(context.Background(), agent, "secret"); err != nil {
		t.Fatalf("request did not use management IP: %v", err)
	}
}
