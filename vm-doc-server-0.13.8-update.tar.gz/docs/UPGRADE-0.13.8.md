# Upgrade vm-doc-server 0.13.7 -> 0.13.8

0.13.8 corectează utilizarea VIP-urilor ca endpoint de agent.

## Schimbări

- Test / Colect / Update folosesc IP-ul de management (`last_advertised_ip`) când `base_url` conține un alt IP literal (de ex. VIP Keepalived/VRRP).
- La următoarea auto-înregistrare, `base_url` este normalizat automat la IP-ul de management, păstrând schema și portul.
- DNS-urile configurate explicit nu sunt rescrise, pentru a nu afecta TLS/SNI.
- Coloana „IP-uri raportate VM” a fost eliminată din lista Agenți și din exportul Excel; IP-urile rămân în inventarul tehnic al VM-ului.
- Nu există migrare de bază de date.
- Agentul 1.3.7 nu trebuie actualizat.

## Upgrade

Opriți serviciile, suprascrieți fișierele din pachetul update peste instalarea 0.13.7, recompilați/instalați binarele dacă folosiți sursele și reporniți serviciile.

După restart, un agent care are `base_url=http://VIP:9078` și `management_ip=IP_NOD` va fi contactat la `http://IP_NOD:9078`.
