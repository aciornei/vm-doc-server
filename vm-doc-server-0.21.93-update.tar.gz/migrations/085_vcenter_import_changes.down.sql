-- ROLLBACK MANUAL, POTENŢIAL DISTRUCTIV: evenimentele fără agent/snapshot
-- trebuie exportate înainte şi vor fi pierdute dacă se execută acest script.
DELETE FROM inventory_changes WHERE category='vcenter' AND object_type='vm_import';
ALTER TABLE inventory_changes
  DROP FOREIGN KEY fk_inventory_changes_agent,
  DROP FOREIGN KEY fk_inventory_changes_inventory,
  MODIFY COLUMN agent_id BIGINT UNSIGNED NOT NULL,
  MODIFY COLUMN inventory_id BIGINT UNSIGNED NOT NULL,
  ADD CONSTRAINT fk_inventory_changes_agent FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE,
  ADD CONSTRAINT fk_inventory_changes_inventory FOREIGN KEY (inventory_id) REFERENCES inventory_snapshots(id) ON DELETE CASCADE;
