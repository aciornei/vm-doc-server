-- Import VCSA independent de agent/snapshot; acele două FK rămân valide pentru valori nenule.
-- MariaDB poate respinge MODIFY pe coloane referite de FK, de aceea se reconstruiesc
-- ambele constrângeri în același ALTER TABLE. Testați pe o copie a bazei de date.
ALTER TABLE inventory_changes
  DROP FOREIGN KEY fk_inventory_changes_agent,
  DROP FOREIGN KEY fk_inventory_changes_inventory,
  MODIFY COLUMN agent_id BIGINT UNSIGNED NULL,
  MODIFY COLUMN inventory_id BIGINT UNSIGNED NULL,
  ADD CONSTRAINT fk_inventory_changes_agent FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE,
  ADD CONSTRAINT fk_inventory_changes_inventory FOREIGN KEY (inventory_id) REFERENCES inventory_snapshots(id) ON DELETE CASCADE;
