package vcenter

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestMakeVCenterImportChangeStableAcrossSyncs(t *testing.T) {
	first := RemoteVM{MoID: "vm-97", Name: "server-prod", PowerState: "POWERED_ON", ResourcePoolID: "vm-doc:unassigned"}
	later := RemoteVM{MoID: "vm-97", Name: "server-prod-renamed", PowerState: "POWERED_OFF", ResourcePoolID: "resgroup-32"}
	a, err := makeVCenterImportChange(11, first)
	if err != nil {
		t.Fatal(err)
	}
	b, err := makeVCenterImportChange(11, later)
	if err != nil {
		t.Fatal(err)
	}
	if a.Hash != b.Hash || a.ObjectKey != b.ObjectKey {
		t.Fatalf("import identity changed: %+v %+v", a, b)
	}
	if !strings.Contains(a.Summary, "importată pentru prima dată din VCSA") {
		t.Fatal(a.Summary)
	}
	var payload map[string]any
	if err := json.Unmarshal([]byte(a.Details), &payload); err != nil {
		t.Fatal(err)
	}
	if payload["source"] != "VCSA" || payload["vcenter_moid"] != first.MoID {
		t.Fatal(payload)
	}
	c, err := makeVCenterImportChange(12, first)
	if err != nil {
		t.Fatal(err)
	}
	if c.Hash == a.Hash {
		t.Fatal("same VM MoID in different sources must not collide")
	}
}

func TestMakeVCenterImportChangeRejectsMissingIdentity(t *testing.T) {
	if _, err := makeVCenterImportChange(0, RemoteVM{MoID: "vm-1"}); err == nil {
		t.Fatal("missing source accepted")
	}
	if _, err := makeVCenterImportChange(1, RemoteVM{}); err == nil {
		t.Fatal("missing MoID accepted")
	}
}
