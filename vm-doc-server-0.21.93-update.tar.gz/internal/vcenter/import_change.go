package vcenter

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

// vcenterImportChange has a stable identity across repeated scheduler/manual syncs.
// The uniqueness is enforced again by inventory_changes.change_hash in MariaDB.
type vcenterImportChange struct {
	ObjectKey   string
	ObjectLabel string
	Summary     string
	Details     string
	Hash        string
}

func makeVCenterImportChange(sourceID int64, vm RemoteVM) (vcenterImportChange, error) {
	if sourceID <= 0 || strings.TrimSpace(vm.MoID) == "" {
		return vcenterImportChange{}, fmt.Errorf("missing vCenter import source or VM MoID")
	}
	// Key by source+MoID rather than mutable name/host/IP/pool/agent identity.
	key := fmt.Sprintf("vcenter|vm_import|%d|%s", sourceID, vm.MoID)
	hash := sha256.Sum256([]byte(fmt.Sprintf("vcenter.vm.imported\x00%d\x00%s", sourceID, vm.MoID)))
	label := "VM " + strings.TrimSpace(vm.Name)
	details, err := json.Marshal(map[string]any{
		"source": "VCSA", "vcenter_source_id": sourceID,
		"vcenter_moid": vm.MoID, "name": vm.Name,
		"power_state": vm.PowerState, "resource_pool_moid": vm.ResourcePoolID,
		"guest_hostname": vm.GuestHostname,
	})
	if err != nil {
		return vcenterImportChange{}, err
	}
	return vcenterImportChange{
		ObjectKey: key, ObjectLabel: label,
		Summary: label + " a fost importată pentru prima dată din VCSA",
		Details: string(details), Hash: hex.EncodeToString(hash[:]),
	}, nil
}

// writeVCenterImportChange runs in the same transaction as the VM INSERT.
// 'not_required' avoids generating spurious VM/service documentation obligations.
func writeVCenterImportChange(ctx context.Context, tx *sql.Tx, sourceID, vmID int64, vm RemoteVM, at time.Time) error {
	if vmID <= 0 {
		return fmt.Errorf("missing imported VM ID")
	}
	change, err := makeVCenterImportChange(sourceID, vm)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `INSERT IGNORE INTO inventory_changes
      (vm_id,agent_id,previous_inventory_id,inventory_id,occurred_at,
       category,object_type,object_key,object_label,change_type,summary,
       old_json,new_json,documentation_requirement,review_status,change_hash)
       VALUES (?,NULL,NULL,NULL,?,'vcenter','vm_import',?,?,'added',?,NULL,?,'not_required','new',?)`,
		vmID, at, change.ObjectKey, change.ObjectLabel, change.Summary, change.Details, change.Hash)
	if err != nil {
		return fmt.Errorf("store VCSA VM import change: %w", err)
	}
	return nil
}
