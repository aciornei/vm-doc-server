package inventorychanges

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type Service struct{ DB *sql.DB }

type Change struct {
	ID                       int64           `json:"id"`
	VMID                     int64           `json:"vm_id"`
	VMName                   string          `json:"vm_name"`
	VMHostname               string          `json:"vm_hostname,omitempty"`
	AgentID                  int64           `json:"agent_id"`
	PreviousInventoryID      *int64          `json:"previous_inventory_id,omitempty"`
	InventoryID              int64           `json:"inventory_id"`
	OccurredAt               time.Time       `json:"occurred_at"`
	Category                 string          `json:"category"`
	ObjectType               string          `json:"object_type"`
	ObjectKey                string          `json:"object_key"`
	ObjectLabel              string          `json:"object_label"`
	ChangeType               string          `json:"change_type"`
	Summary                  string          `json:"summary"`
	OldJSON                  json.RawMessage `json:"old_json,omitempty"`
	NewJSON                  json.RawMessage `json:"new_json,omitempty"`
	DocumentationRequirement string          `json:"documentation_requirement"`
	ReviewStatus             string          `json:"review_status"`
	DocumentationPending     int64           `json:"documentation_pending"`
	DocumentationDone        int64           `json:"documentation_documented"`
	Notes                    string          `json:"notes,omitempty"`
	ReviewedBy               *int64          `json:"reviewed_by,omitempty"`
	ReviewedByName           string          `json:"reviewed_by_name,omitempty"`
	ReviewedAt               *time.Time      `json:"reviewed_at,omitempty"`
}

type Filter struct {
	VMID                     int64
	Query                    string
	SearchScope              string
	Category                 string
	ChangeType               string
	DocumentationRequirement string
	ReviewStatus             string
	Mode                     string
	Page                     int
	PageSize                 int
}

type Page struct {
	Items         []Change `json:"items"`
	Page          int      `json:"page"`
	PageSize      int      `json:"page_size"`
	Total         int      `json:"total"`
	Pages         int      `json:"pages"`
	NewCount      int      `json:"new_count"`
	UnsetCount    int      `json:"unset_count"`
	RequiredCount int      `json:"required_count"`
}

type UpdateInput struct {
	DocumentationRequirement string  `json:"documentation_requirement"`
	ReviewStatus             string  `json:"review_status"`
	Notes                    *string `json:"notes,omitempty"`
}

type BaselineInput struct {
	VMID int64 `json:"vm_id,omitempty"`
}

type trackedObject struct {
	Category string
	Type     string
	Key      string
	Label    string
	Value    any
}

func (s Service) Capture(ctx context.Context, tx *sql.Tx, agentID, previousInventoryID, inventoryID int64, previousRaw, currentRaw []byte) (int64, error) {
	if previousInventoryID <= 0 || inventoryID <= 0 || len(previousRaw) == 0 || len(currentRaw) == 0 {
		return 0, nil
	}
	var vmID int64
	err := tx.QueryRowContext(ctx, `SELECT id FROM virtual_machines WHERE agent_id=? ORDER BY id LIMIT 1`, agentID).Scan(&vmID)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, nil
	}
	if err != nil {
		return 0, err
	}

	// The first inventory pair of a VM establishes a baseline automatically.
	// Existing installations are seeded by migration 033 with the current
	// snapshot, while new VMs use their first snapshot as the baseline.
	if _, err := tx.ExecContext(ctx, `INSERT IGNORE INTO inventory_change_baselines(vm_id,inventory_id,established_at,established_by,source) VALUES(?,?,UTC_TIMESTAMP(6),NULL,'automatic')`, vmID, previousInventoryID); err != nil {
		return 0, err
	}

	// Principal ports remain eligible even in the otherwise noisy dynamic range.
	// Read within the same transaction as the inventory comparison.
	primaryPorts, err := loadPrimaryPortSelections(ctx, tx, vmID)
	if err != nil {
		return 0, fmt.Errorf("load primary port selections: %w", err)
	}

	// Semantic configuration history: all meaningful domains, rather than only
	// operator-selected services or all runtime details. Raw snapshots are intact.

	// The accepted baseline is anchored to the user's last review per object,
	// not to the immediately preceding snapshot (which can change while away).
	oldObjects, err := acceptedObjects(ctx, tx, vmID, previousRaw, primaryPorts)
	if err != nil {
		return 0, err
	}
	newObjects, err := extractTracked(currentRaw)
	if err != nil {
		return 0, fmt.Errorf("extract current inventory changes: %w", err)
	}
	newObjects = semanticHistoryObjects(newObjects, primaryPorts)
	pending, err := pendingEvents(ctx, tx, vmID)
	if err != nil {
		return 0, err
	}
	keys := make([]string, 0, len(oldObjects)+len(newObjects)+len(pending))
	seen := map[string]bool{}
	for k := range oldObjects {
		seen[k] = true
		keys = append(keys, k)
	}
	for k := range newObjects {
		if !seen[k] {
			seen[k] = true
			keys = append(keys, k)
		}
	}
	for k := range pending {
		if !seen[k] {
			seen[k] = true
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	var inserted int64
	now := time.Now().UTC()
	_ = tx.QueryRowContext(ctx, `SELECT received_at FROM inventory_snapshots WHERE id=?`, inventoryID).Scan(&now)
	for _, k := range keys {
		oldObj, hadOld := oldObjects[k]
		newObj, hasNew := newObjects[k]
		if !healthyForObject(previousRaw, currentRaw, objectForPair(oldObj, newObj, hadOld, hasNew)) {
			continue
		}
		active, hasPending := pending[k]
		if !changedBetweenSnapshots(oldObj, newObj, hadOld, hasNew) {
			if hasPending {
				// The configuration reverted to the accepted baseline without review.
				_, err = tx.ExecContext(ctx, `UPDATE inventory_changes SET review_status='reverted',notes=CONCAT_WS('\n',NULLIF(notes,''),'Revenire automată la baseline'),reviewed_at=UTC_TIMESTAMP(6) WHERE id=? AND review_status='new'`, active.ID)
				if err == nil {
					_, err = tx.ExecContext(ctx, `DELETE FROM inventory_change_documentation_tasks WHERE change_id=? AND status='pending'`, active.ID)
				}
				if err != nil {
					return inserted, err
				}
			}
			continue
		}
		var typ, label, category, objectType string
		var oldJSON, newJSON []byte
		switch {
		case !hadOld && hasNew:
			typ, label, category, objectType = "added", newObj.Label, newObj.Category, newObj.Type
			newJSON, _ = json.Marshal(newObj.Value)
		case hadOld && !hasNew:
			typ, label, category, objectType = "removed", oldObj.Label, oldObj.Category, oldObj.Type
			oldJSON, _ = json.Marshal(oldObj.Value)
		default:
			typ, label, category, objectType = "modified", newObj.Label, newObj.Category, newObj.Type
			oldJSON, _ = json.Marshal(oldObj.Value)
			newJSON, _ = json.Marshal(newObj.Value)
		}
		summary := changeSummary(typ, label)
		if hasPending {
			// Keep the first detection time, update only the pending observed state.
			if active.Kind == typ && string(active.Old) == string(oldJSON) && string(active.New) == string(newJSON) {
				continue
			}
			_, err = tx.ExecContext(ctx, `UPDATE inventory_changes SET previous_inventory_id=?,inventory_id=?,category=?,object_type=?,object_label=?,change_type=?,summary=?,old_json=?,new_json=? WHERE id=? AND review_status='new'`, previousInventoryID, inventoryID, category, objectType, label, typ, summary, nullableJSON(oldJSON), nullableJSON(newJSON), active.ID)
			if err != nil {
				return inserted, err
			}
			continue
		}
		hashInput := strings.Join([]string{strconv.FormatInt(vmID, 10), strconv.FormatInt(previousInventoryID, 10), strconv.FormatInt(inventoryID, 10), category, objectType, k, typ}, "\x00")
		h := sha256.Sum256([]byte(hashInput))
		changeHash := hex.EncodeToString(h[:])
		res, execErr := tx.ExecContext(ctx, `INSERT IGNORE INTO inventory_changes(vm_id,agent_id,previous_inventory_id,inventory_id,occurred_at,category,object_type,object_key,object_label,change_type,summary,old_json,new_json,change_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, vmID, agentID, previousInventoryID, inventoryID, now, category, objectType, k, label, typ, summary, nullableJSON(oldJSON), nullableJSON(newJSON), changeHash)
		if execErr != nil {
			return inserted, execErr
		}
		n, _ := res.RowsAffected()
		inserted += n
	}

	return inserted, nil
}

// changedBetweenSnapshots reports semantic changes between the previous and
// current successful snapshots. No third sample is required.
func changedBetweenSnapshots(old, current trackedObject, hadOld, hadCurrent bool) bool {
	if hadOld != hadCurrent {
		return true
	}
	return hadOld && !trackedObjectsEqual(old, current)
}

func nullableJSON(v []byte) any {
	if len(v) == 0 {
		return nil
	}
	return string(v)
}

func changeSummary(changeType, label string) string {
	switch changeType {
	case "added":
		return label + " a apărut în inventar"
	case "removed":
		return label + " nu mai apare în inventar"
	default:
		return label + " s-a modificat"
	}
}

func canonicalEqual(a, b any) bool {
	aa, _ := json.Marshal(a)
	bb, _ := json.Marshal(b)
	return string(aa) == string(bb)
}

func extractTracked(raw []byte) (map[string]trackedObject, error) {
	dec := json.NewDecoder(strings.NewReader(string(raw)))
	dec.UseNumber()
	var root map[string]any
	if err := dec.Decode(&root); err != nil {
		return nil, err
	}
	out := map[string]trackedObject{}
	add := func(o trackedObject) {
		if strings.TrimSpace(o.Key) == "" {
			return
		}
		out[o.Category+"|"+o.Type+"|"+o.Key] = o
	}

	// Host and OS: useful documentation fields; volatile uptime/collection metadata are deliberately ignored.
	if h := asMap(root["host"]); h != nil {
		add(trackedObject{"system", "host", "host", "Identitate / hardware VM", pick(h, "hostname", "fqdn", "product_name", "product_vendor", "serial_number", "virtualization")})
	}
	if os := asMap(root["os"]); os != nil {
		add(trackedObject{"system", "os", "os", "Sistem de operare", pick(os, "family", "name", "pretty_name", "version", "version_id", "kernel", "architecture", "init_system")})
	}
	if st := asMap(root["storage"]); st != nil {
		for _, v := range asSlice(st["partitions"]) {
			p := asMap(v)
			key := first(p, "mount_point", "device")
			if key == "" {
				continue
			}
			add(trackedObject{"storage", "partition", key, "Partiție " + key, pick(p, "device", "mount_point", "filesystem", "total_bytes", "read_only", "remote")})
		}
	}
	if nw := asMap(root["network"]); nw != nil {
		for _, v := range asSlice(nw["interfaces"]) {
			n := asMap(v)
			name := first(n, "name")
			if name == "" || isEphemeralVethInterface(name) || isEphemeralDockerBridgeInterface(name) {
				continue
			}
			add(trackedObject{"network", "interface", name, "Interfață " + name, pick(n, "name", "mac", "mtu", "addresses")})
		}
		add(trackedObject{"network", "resolver", "resolver", "DNS / gateway", pick(nw, "default_gateways", "dns_servers", "search_domains")})
	}
	for _, v := range asSlice(root["services"]) {
		svc := asMap(v)
		name := first(svc, "name")
		if name == "" || isEphemeralService(name) || isSystemdFsckNoiseService(name) {
			continue
		}
		// Runtime active/sub states belong in operational monitoring, not in
		// documentation-change history. Enabled state and versions remain tracked.
		add(trackedObject{"services", "service", name, "Serviciu " + name, trackedServiceFields(svc)})
	}
	for _, v := range asSlice(root["listening_ports"]) {
		p := asMap(v)
		proto := first(p, "protocol")
		port := numberText(p["port"])
		procs := asSlice(p["processes"])
		procNames := []string{}
		procExec := []string{}
		for _, pv := range procs {
			pm := asMap(pv)
			if x := first(pm, "name"); x != "" {
				procNames = append(procNames, x)
			}
			if x := first(pm, "executable"); x != "" {
				procExec = append(procExec, x)
			}
		}
		// Count of workers (Apache/PHP-FPM/etc.) is not a new listener.
		// Deduplicate BEFORE building the identity, not only its JSON value;
		// otherwise a worker-count change emits false added+removed pairs.
		procNames = unique(procNames)
		procExec = unique(procExec)
		key := strings.ToLower(strings.TrimSpace(proto)) + "/" + port
		if port == "" {
			continue
		}
		add(trackedObject{"ports", "listening_port", key, "Port " + strings.ToUpper(proto) + "/" + port, map[string]any{"protocol": proto, "port": p["port"], "process_names": procNames, "executables": procExec}})
	}
	if fw := asMap(root["firewall"]); fw != nil {
		add(trackedObject{"firewall", "firewall", "firewall", "Firewall", pick(fw, "detected", "active", "backends", "default_policies", "zones", "config_files")})
		for _, v := range asSlice(fw["rules"]) {
			r := asMap(v)
			rule := normalizeFirewallRule(first(r, "rule"))
			if rule == "" || isGeneratedFirewallRule(r) {
				continue
			}
			key := strings.Join([]string{first(r, "backend"), first(r, "family"), first(r, "table"), first(r, "chain"), rule}, "|")
			value := pick(r, "backend", "family", "table", "chain", "action")
			value["rule"] = rule
			add(trackedObject{"firewall", "rule", key, "Regulă firewall " + short(rule, 90), value})
		}
	}
	if acc := asMap(root["accounts"]); acc != nil {
		for _, v := range asSlice(acc["local_users"]) {
			u := asMap(v)
			username := first(u, "username")
			uid := numberText(u["uid"])
			key := uid
			if key == "" {
				key = username
			}
			if key == "" {
				continue
			}
			label := "Utilizator local " + username
			if uid != "" {
				label += " (UID " + uid + ")"
			}
			add(trackedObject{"accounts", "local_user", key, label, pick(u, "username", "uid", "gid", "gecos", "home", "shell", "system_account", "password_status", "password_locked", "account_expires_at")})
		}
	}
	if sssd := asMap(root["sssd"]); sssd != nil {
		add(trackedObject{"identity", "sssd", "sssd", "Integrare SSSD", pick(sssd, "installed", "version", "service_active", "service_enabled", "config_present", "config_valid", "services", "domains")})
	}
	if ints := asMap(root["integrations"]); ints != nil {
		for _, name := range []string{"glpi_agent", "node_exporter", "auditbeat", "filebeat", "syslog"} {
			if v := asMap(ints[name]); v != nil {
				if name == "node_exporter" {
					// Metrics probe results are runtime observations, not configuration changes.
					add(trackedObject{"integrations", "integration", name, "Integrare " + name, pick(v,
						"installed", "name", "version", "binary_path", "package_name", "package_version",
						"service_names", "service_enabled", "config_files",
						"listen_addresses", "metrics_endpoints")})
					continue
				}
				// Connectivity probes and transient service state are not a
				// lasting change to integration configuration.
				value := pickAllWithout(v, map[string]bool{
					"last_error": true, "service_active": true,
					"config_valid": true, "config_check_output": true,
					"output_test_ok": true, "output_test_output": true,
				})
				if version, ok := value["version"].(string); ok {
					value["version"] = normalizeBeatVersion(name, version)
				}
				add(trackedObject{"integrations", "integration", name, "Integrare " + name, value})
			}
		}
	}
	if ntp := asMap(root["ntp"]); ntp != nil {
		value := pick(ntp, "installed", "implementation", "version", "service_name", "service_enabled", "config_files")
		if servers, ok := ntp["servers"]; ok {
			value["servers"] = normalizeNTPServers(asSlice(servers))
		}
		// tracking_summary contains chrony offsets, dispersion and timestamps that change on every collect.
		add(trackedObject{"time", "ntp", "ntp", "Sincronizare timp", value})
	}

	if db := asMap(root["databases"]); db != nil {
		for _, v := range asSlice(db["instances"]) {
			inst := asMap(v)
			engine := first(inst, "engine")
			name := first(inst, "instance_name")
			dataDir := first(inst, "data_dir")
			ep := endpointKey(asSlice(inst["endpoints"]))
			key := strings.Join([]string{engine, name, dataDir, ep}, "|")
			if key == "|||" {
				continue
			}
			label := "Instanță DB " + strings.TrimSpace(strings.Join([]string{first(inst, "product"), name}, " "))
			value := pick(inst, "engine", "product", "instance_name", "version", "edition", "status", "service_name", "executable", "data_dir", "config_files", "endpoints", "socket_paths", "catalog_discovery_status", "catalog_discovery_reason")
			// Database probes sometimes emit a dated MySQL/MariaDB [Warning]
			// into version. Never treat that diagnostic as a software upgrade.
			normalizeTrackedVersionField(value, "version")
			add(trackedObject{"databases", "database_instance", key, label, value})
			// Catalog absence is meaningful only after a successful catalog discovery.
			// Avoid creating removals when authentication or a DB probe fails.
			if strings.EqualFold(first(inst, "catalog_discovery_status"), "discovered") ||
				(first(inst, "catalog_discovery_status") == "" && len(asSlice(inst["catalogs"])) > 0) {
				for _, cv := range asSlice(inst["catalogs"]) {
					c := asMap(cv)
					cn := first(c, "name")
					if cn == "" {
						continue
					}
					ck := key + "|" + cn
					add(trackedObject{"databases", "database", ck, "Bază de date " + cn, map[string]any{"engine": engine, "instance": name, "name": cn, "kind": c["kind"], "system": c["system"]}})
				}
			}
			// DB access enumeration is best-effort: incomplete probes must not
			// report that users/privileges/HBA entries were deleted.
			if access := asMap(inst["access"]); access != nil && strings.EqualFold(first(access, "status"), "discovered") {
				for _, pv := range asSlice(access["principals"]) {
					principal := asMap(pv)
					username := first(principal, "name")
					if username == "" {
						continue
					}
					objKey := key + "|" + username + "|" + first(principal, "host") + "|" + first(principal, "database")
					add(trackedObject{"db_security", "db_user", objKey, "Utilizator DB " + username, normalizeUnorderedStrictFields(pick(principal, "name", "host", "database", "login", "superuser", "create_db", "create_role", "replication", "roles"), "roles")})
				}
				for _, gv := range asSlice(access["privileges"]) {
					grant := asMap(gv)
					if first(grant, "principal") == "" || first(grant, "privilege") == "" {
						continue
					}
					objKey := strings.Join([]string{key, first(grant, "principal"), first(grant, "host"), first(grant, "scope"), first(grant, "database"), first(grant, "schema"), first(grant, "object_type"), first(grant, "object_name"), first(grant, "privilege")}, "|")
					add(trackedObject{"db_security", "db_privilege", objKey, "Privilegiu DB " + first(grant, "principal") + " / " + first(grant, "privilege"), pick(grant, "principal", "host", "scope", "database", "schema", "object_type", "object_name", "privilege", "state", "grantable")})
				}
				for _, hv := range asSlice(access["hba_rules"]) {
					hba := asMap(hv)
					if first(hba, "type") == "" {
						continue
					}
					value := normalizeUnorderedStrictFields(pick(hba, "type", "databases", "users", "address", "method", "options", "source_file"), "databases", "users", "options")
					objKey := key + "|" + stableMapKey(pick(value, "type", "databases", "users", "address", "source_file"))
					add(trackedObject{"db_security", "hba_rule", objKey, "Regulă PostgreSQL HBA " + first(hba, "address"), value})
				}
			}
		}
	}
	if docker := asMap(root["docker"]); docker != nil {
		for _, v := range asSlice(docker["containers"]) {
			c := asMap(v)
			name := first(c, "name")
			if name == "" {
				continue
			}
			// Documentation history tracks ONLY a container name and its image
			// reference/tag (the useful version). Compose metadata, digest, MAC,
			// IP, networks, mounts, runtime state and ports remain in raw inventory
			// and the specialized Docker views, but not in change events.
			// Container names are unique per Docker host, even across projects.
			image := trackedDockerImage(first(c, "image"))
			value := map[string]any{"name": name, "image": image}
			add(trackedObject{"docker", "container", name, "Container Docker " + name, value})
		}
	}
	if web := asMap(root["web"]); web != nil {
		for _, v := range asSlice(web["sites"]) {
			site := asMap(v)
			engine := first(site, "engine")
			name := first(site, "name")
			cfg := first(site, "config_file")
			binds := endpointKey(asSlice(site["bindings"]))
			key := strings.Join([]string{engine, cfg, name, binds}, "|")
			if name == "" {
				continue
			}
			add(trackedObject{"web", "web_site", key, "Site / frontend " + name, pick(site, "engine", "product", "site_type", "name", "server_names", "bindings", "document_root", "proxy_targets", "backends", "mode", "config_file", "enabled", "default")})
			for _, av := range asSlice(site["access_control"]) {
				acl := asMap(av)
				if first(acl, "action") == "" {
					continue
				}
				value := pick(acl, "action", "source", "scope", "directive", "source_file")
				// Fingerprint the rule, not its row order. No hit-counters/runtime probes.
				aclKey := key + "|" + stableMapKey(value)
				add(trackedObject{"web_acl", "web_acl", aclKey, "Web ACL " + name + " / " + first(acl, "action") + " " + first(acl, "source"), value})
			}
		}
	}
	if cron := asMap(root["cron"]); cron != nil {
		for _, v := range asSlice(cron["entries"]) {
			job := asMap(v)
			cmd := first(job, "command")
			if cmd == "" {
				continue
			}
			value := pick(job, "source", "owner", "user", "schedule", "command", "special")
			key := stableMapKey(pick(job, "source", "owner", "user", "command"))
			add(trackedObject{"cron", "cron_entry", key, "Cron " + short(cmd, 65), value})
		}
		for _, v := range asSlice(cron["periodic_scripts"]) {
			script := asMap(v)
			path := first(script, "path")
			if path == "" {
				continue
			}
			add(trackedObject{"cron", "cron_script", path, "Script periodic " + path, pick(script, "path", "period", "executable", "owner")})
		}
	}
	if sw := asMap(root["software"]); sw != nil {
		for _, v := range asSlice(sw["items"]) {
			item := asMap(v)
			name := first(item, "name")
			if name == "" || strings.EqualFold(first(item, "kind"), "appx") {
				continue
			}
			key := stableMapKey(pick(item, "name", "publisher", "architecture", "scope", "kind"))
			add(trackedObject{"software", "software_package", key, "Program instalat " + name, pick(item, "name", "version", "publisher", "architecture", "scope", "kind", "state")})
		}
	}
	return out, nil
}

func stableMapKey(value map[string]any) string {
	data, _ := json.Marshal(value)
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:12])
}

var (
	nftCounterRE = regexp.MustCompile(`(?i)\bcounter\s+packets\s+\d+\s+bytes\s+\d+\b`)
	nftHandleRE  = regexp.MustCompile(`(?i)\s*#\s*handle\s+\d+\b`)
	spaceRE      = regexp.MustCompile(`\s+`)
)

func normalizeFirewallRule(rule string) string {
	rule = strings.TrimSpace(rule)
	if rule == "" {
		return ""
	}
	// nftables counters and handles are runtime/generated metadata. Keep the semantic
	// counter expression itself, but ignore the packet/byte values and rule handle.
	rule = nftCounterRE.ReplaceAllString(rule, "counter")
	rule = nftHandleRE.ReplaceAllString(rule, "")
	return strings.TrimSpace(spaceRE.ReplaceAllString(rule, " "))
}

func normalizeNTPServers(values []any) []any {
	out := make([]any, 0, len(values))
	for _, value := range values {
		m := asMap(value)
		address := first(m, "address")
		if address == "" {
			continue
		}
		item := pick(m, "address", "type", "source")
		out = append(out, item)
	}
	sort.Slice(out, func(i, j int) bool {
		a, _ := json.Marshal(out[i])
		b, _ := json.Marshal(out[j])
		return string(a) < string(b)
	})
	return out
}

func asMap(v any) map[string]any { m, _ := v.(map[string]any); return m }
func asSlice(v any) []any        { a, _ := v.([]any); return a }
func first(m map[string]any, keys ...string) string {
	for _, k := range keys {
		if s, ok := m[k].(string); ok && strings.TrimSpace(s) != "" {
			return strings.TrimSpace(s)
		}
	}
	return ""
}
func numberText(v any) string {
	switch x := v.(type) {
	case json.Number:
		return x.String()
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	case int:
		return strconv.Itoa(x)
	case int64:
		return strconv.FormatInt(x, 10)
	case string:
		return strings.TrimSpace(x)
	}
	return ""
}
func pick(m map[string]any, keys ...string) map[string]any {
	out := map[string]any{}
	for _, k := range keys {
		if v, ok := m[k]; ok {
			out[k] = v
		}
	}
	return out
}
func pickAllWithout(m map[string]any, excluded map[string]bool) map[string]any {
	out := map[string]any{}
	for k, v := range m {
		if excluded != nil && excluded[k] {
			continue
		}
		out[k] = v
	}
	return out
}
func endpointKey(values []any) string {
	parts := []string{}
	for _, v := range values {
		m := asMap(v)
		a := first(m, "address")
		p := numberText(m["port"])
		proto := first(m, "protocol")
		if a != "" || p != "" {
			parts = append(parts, proto+":"+a+":"+p)
		}
	}
	sort.Strings(parts)
	return strings.Join(parts, ",")
}
func unique(values []string) []string {
	if len(values) == 0 {
		return nil
	}
	sort.Strings(values)
	out := values[:0]
	last := ""
	for _, v := range values {
		if v != "" && v != last {
			out = append(out, v)
			last = v
		}
	}
	return out
}
func short(s string, n int) string {
	s = strings.TrimSpace(s)
	if len([]rune(s)) <= n {
		return s
	}
	r := []rune(s)
	return string(r[:n-1]) + "…"
}

func normalizeFilter(in Filter) Filter {
	in.Query = strings.TrimSpace(in.Query)
	in.SearchScope = strings.ToLower(strings.TrimSpace(in.SearchScope))
	switch in.SearchScope {
	case "", "all", "vm", "service", "object":
	default:
		in.SearchScope = "all"
	}
	in.Category = strings.TrimSpace(in.Category)
	in.ChangeType = strings.TrimSpace(in.ChangeType)
	in.DocumentationRequirement = strings.TrimSpace(in.DocumentationRequirement)
	in.ReviewStatus = strings.TrimSpace(in.ReviewStatus)
	in.Mode = strings.TrimSpace(in.Mode)
	switch in.Mode {
	case "", "all", "timeline", "timeline_all":
	default:
		in.Mode = ""
	}
	if in.Page < 1 {
		in.Page = 1
	}
	if in.PageSize <= 0 {
		in.PageSize = 10
	}
	if in.PageSize > 200 {
		in.PageSize = 200
	}
	return in
}

// buildChangeSearchSQL limits search scopes to fixed, parameterized SQL fragments.
// Associated services include direct assignments and Docker/DB/Web resources.
func buildChangeSearchSQL(query, scope string) (string, []any) {
	args := []any{}
	parts := []string{}
	pattern := "%" + query + "%"
	vmClause := "(vm.name LIKE ? OR COALESCE(NULLIF(i.hostname,''),vm.guest_hostname,'') LIKE ?)"
	objectClause := "(c.object_label LIKE ? OR c.summary LIKE ? OR c.notes LIKE ? OR c.object_key LIKE ? OR c.object_type LIKE ? OR c.category LIKE ?)"
	// Search service names/codes through direct VM assignments and resource-level
	// assignments, without multiplying inventory_changes rows or their counts.
	serviceClause := `EXISTS (
            SELECT 1 FROM internal_services svc
            WHERE (svc.name LIKE ? OR COALESCE(svc.service_code,'') LIKE ?)
              AND (
                EXISTS(SELECT 1 FROM vm_internal_service_assignments a WHERE a.vm_id=c.vm_id AND a.internal_service_id=svc.id)
                OR EXISTS(SELECT 1 FROM docker_container_service_assignments a JOIN docker_containers d ON d.id=a.docker_container_id WHERE d.vm_id=c.vm_id AND a.internal_service_id=svc.id)
                OR EXISTS(SELECT 1 FROM database_instance_service_assignments a JOIN database_instances d ON d.id=a.database_instance_id WHERE d.vm_id=c.vm_id AND a.internal_service_id=svc.id)
                OR EXISTS(SELECT 1 FROM database_catalog_service_assignments a JOIN database_catalogs d ON d.id=a.database_catalog_id WHERE d.vm_id=c.vm_id AND a.internal_service_id=svc.id)
                OR EXISTS(SELECT 1 FROM web_site_service_assignments a JOIN web_sites w ON w.id=a.web_site_id WHERE w.vm_id=c.vm_id AND a.internal_service_id=svc.id)
              )
        )`
	switch scope {
	case "vm":
		parts = append(parts, vmClause)
		args = append(args, pattern, pattern)
	case "service":
		parts = append(parts, serviceClause)
		args = append(args, pattern, pattern)
	case "object":
		parts = append(parts, objectClause)
		for range 6 {
			args = append(args, pattern)
		}
	default:
		parts = append(parts, "("+vmClause+" OR "+serviceClause+" OR "+objectClause+")")
		for range 10 {
			args = append(args, pattern)
		}
	}
	return strings.Join(parts, " AND "), args
}

// reviewStatusFilter keeps the work queue and the chronological VM timeline
// logically separate; ignored changes are available only when requested.
func reviewStatusFilter(f Filter) (string, []any) {
	switch f.Mode {
	case "timeline":
		return "c.review_status IN ('reviewed','reverted')", nil
	case "timeline_all":
		return "c.review_status IN ('reviewed','reverted','ignored')", nil
	}
	if f.ReviewStatus != "" {
		return "c.review_status=?", []any{f.ReviewStatus}
	}
	if f.Mode == "all" {
		return "", nil
	}
	return "c.review_status='new'", nil
}

func (s Service) List(ctx context.Context, filter Filter) (Page, error) {
	f := normalizeFilter(filter)
	clauses := []string{}
	args := []any{}
	if f.VMID > 0 {
		clauses = append(clauses, "c.vm_id=?")
		args = append(args, f.VMID)
	}
	if f.Query != "" {
		clause, values := buildChangeSearchSQL(f.Query, f.SearchScope)
		clauses = append(clauses, clause)
		args = append(args, values...)
	}
	if f.Category != "" {
		clauses = append(clauses, "c.category=?")
		args = append(args, f.Category)
	}
	if f.ChangeType != "" {
		clauses = append(clauses, "c.change_type=?")
		args = append(args, f.ChangeType)
	}
	if f.DocumentationRequirement != "" {
		clauses = append(clauses, "c.documentation_requirement=?")
		args = append(args, f.DocumentationRequirement)
	}
	if reviewClause, reviewArgs := reviewStatusFilter(f); reviewClause != "" {
		clauses = append(clauses, reviewClause)
		args = append(args, reviewArgs...)
	}
	// Changes at or before the current baseline remain stored for audit but are
	// hidden from normal triage and from documentation-completion calculations.
	if f.Mode != "timeline" && f.Mode != "timeline_all" {
		clauses = append(clauses, "(c.category='vcenter' OR b.inventory_id IS NULL OR (c.inventory_id IS NOT NULL AND c.inventory_id>b.inventory_id) OR (c.inventory_id IS NULL AND c.occurred_at>b.established_at))")
	}
	where := " WHERE " + strings.Join(clauses, " AND ")
	base := ` FROM inventory_changes c JOIN virtual_machines vm ON vm.id=c.vm_id LEFT JOIN inventory_snapshots i ON i.id=c.inventory_id LEFT JOIN inventory_change_baselines b ON b.vm_id=c.vm_id LEFT JOIN users reviewer ON reviewer.id=c.reviewed_by`
	var out Page
	out.Page = f.Page
	out.PageSize = f.PageSize
	out.Items = []Change{}
	summarySQL := `SELECT COUNT(*),COALESCE(SUM(c.review_status='new'),0),COALESCE(SUM(c.documentation_requirement='unset'),0),COALESCE(SUM(c.documentation_requirement='required'),0)` + base + where
	if err := s.DB.QueryRowContext(ctx, summarySQL, args...).Scan(&out.Total, &out.NewCount, &out.UnsetCount, &out.RequiredCount); err != nil {
		return out, err
	}
	if out.Total == 0 {
		return out, nil
	}
	out.Pages = (out.Total + out.PageSize - 1) / out.PageSize
	if out.Page > out.Pages {
		out.Page = out.Pages
	}
	offset := (out.Page - 1) * out.PageSize
	sortOrder := "c.occurred_at DESC,c.id DESC"
	if f.Mode == "timeline" || f.Mode == "timeline_all" {
		// Momentul reviziei este cel care stabilește poziția în timeline.
		sortOrder = "c.reviewed_at DESC,c.id DESC"
	}
	q := `SELECT c.id,c.vm_id,vm.name,COALESCE(NULLIF(i.hostname,''),vm.guest_hostname,''),COALESCE(c.agent_id,0),c.previous_inventory_id,c.inventory_id,c.occurred_at,c.category,c.object_type,c.object_key,c.object_label,c.change_type,c.summary,c.old_json,c.new_json,c.documentation_requirement,c.review_status,
 (SELECT COUNT(*) FROM inventory_change_documentation_tasks dt WHERE dt.change_id=c.id AND dt.status='pending'),
 (SELECT COUNT(*) FROM inventory_change_documentation_tasks dt WHERE dt.change_id=c.id AND dt.status='documented'),
 COALESCE(c.notes,''),c.reviewed_by,c.reviewed_at,COALESCE(NULLIF(reviewer.display_name,''),reviewer.username,'')` + base + where + ` ORDER BY ` + sortOrder + ` LIMIT ? OFFSET ?`
	qargs := append(append([]any{}, args...), out.PageSize, offset)
	rows, err := s.DB.QueryContext(ctx, q, qargs...)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var c Change
		var prev, inventory, reviewedBy sql.NullInt64
		var oldS, newS sql.NullString
		var reviewedAt sql.NullTime
		if err := rows.Scan(&c.ID, &c.VMID, &c.VMName, &c.VMHostname, &c.AgentID, &prev, &inventory, &c.OccurredAt, &c.Category, &c.ObjectType, &c.ObjectKey, &c.ObjectLabel, &c.ChangeType, &c.Summary, &oldS, &newS, &c.DocumentationRequirement, &c.ReviewStatus, &c.DocumentationPending, &c.DocumentationDone, &c.Notes, &reviewedBy, &reviewedAt, &c.ReviewedByName); err != nil {
			return out, err
		}
		if inventory.Valid {
			c.InventoryID = inventory.Int64
		}
		if prev.Valid {
			v := prev.Int64
			c.PreviousInventoryID = &v
		}
		if reviewedBy.Valid {
			v := reviewedBy.Int64
			c.ReviewedBy = &v
		}
		if reviewedAt.Valid {
			v := reviewedAt.Time
			c.ReviewedAt = &v
		}
		if oldS.Valid {
			c.OldJSON = json.RawMessage(oldS.String)
		}
		if newS.Valid {
			c.NewJSON = json.RawMessage(newS.String)
		}
		out.Items = append(out.Items, c)
	}
	return out, rows.Err()
}

func (s Service) Update(ctx context.Context, id, userID int64, in UpdateInput) (Change, error) {
	req := strings.TrimSpace(in.DocumentationRequirement)
	if req == "" {
		req = "unset"
	}
	if req != "unset" && req != "required" && req != "not_required" {
		return Change{}, errors.New("invalid documentation_requirement")
	}
	status := strings.TrimSpace(in.ReviewStatus)
	if status == "" {
		status = "new"
	}
	if status != "new" && status != "reviewed" && status != "ignored" {
		return Change{}, errors.New("invalid review_status")
	}
	var notes any
	if in.Notes != nil {
		notes = strings.TrimSpace(*in.Notes)
	}
	var reviewer any = nil
	var reviewedAt any = nil
	if status != "new" {
		if userID > 0 {
			reviewer = userID
		}
		reviewedAt = time.Now().UTC()
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return Change{}, err
	}
	defer tx.Rollback()
	var vmID int64
	var category, objectType, objectKey, objectLabel, oldStatus string
	var accepted sql.NullString
	err = tx.QueryRowContext(ctx, `SELECT vm_id,category,object_type,object_key,object_label,review_status,new_json FROM inventory_changes WHERE id=? FOR UPDATE`, id).Scan(&vmID, &category, &objectType, &objectKey, &objectLabel, &oldStatus, &accepted)
	if err != nil {
		return Change{}, err
	}
	if oldStatus != "new" && status == "new" {
		return Change{}, errors.New("an already reviewed change cannot be reopened; a new difference will be detected automatically")
	}
	if status != "new" && oldStatus == "new" {
		if category != "vcenter" {
			if err = acceptChange(ctx, tx, vmID, userID, category, objectType, objectKey, objectLabel, []byte(accepted.String)); err != nil {
				return Change{}, err
			}
		}
		// Older versions could have multiple unreviewed rows for one object.
		// One accepted review closes those duplicates, but does not touch
		// other objects or other VMs.
		_, err = tx.ExecContext(ctx, `UPDATE inventory_changes SET review_status='ignored',reviewed_by=?,reviewed_at=UTC_TIMESTAMP(6),notes=CONCAT_WS('\n',NULLIF(notes,''),'Închis odată cu revizia acestui obiect') WHERE vm_id=? AND object_key=? AND review_status='new' AND id<>?`, reviewer, vmID, objectKey, id)
		if err != nil {
			return Change{}, err
		}
		// Duplicate, now ignored differences must not keep open documentation alerts.
		if _, err = tx.ExecContext(ctx, `DELETE t FROM inventory_change_documentation_tasks t JOIN inventory_changes c ON c.id=t.change_id WHERE c.vm_id=? AND c.object_key=? AND c.review_status='ignored' AND t.status='pending'`, vmID, objectKey); err != nil {
			return Change{}, err
		}
	}
	_, err = tx.ExecContext(ctx, `UPDATE inventory_changes SET documentation_requirement=?,review_status=?,notes=COALESCE(?,notes),reviewed_by=?,reviewed_at=? WHERE id=?`, req, status, notes, reviewer, reviewedAt, id)
	if err != nil {
		return Change{}, err
	}
	// A reviewed change can still require separate VM and service documentation.
	if err = syncDocumentationTasks(ctx, tx, id, vmID, req, status); err != nil {
		return Change{}, fmt.Errorf("sync documentation tasks: %w", err)
	}
	if err = tx.Commit(); err != nil {
		return Change{}, err
	}

	return s.Get(ctx, id)
}

func (s Service) Get(ctx context.Context, id int64) (Change, error) {
	var c Change
	var prev, inventory, reviewedBy sql.NullInt64
	var oldS, newS sql.NullString
	var reviewedAt sql.NullTime
	err := s.DB.QueryRowContext(ctx, `SELECT c.id,c.vm_id,vm.name,COALESCE(NULLIF(i.hostname,''),vm.guest_hostname,''),COALESCE(c.agent_id,0),c.previous_inventory_id,c.inventory_id,c.occurred_at,c.category,c.object_type,c.object_key,c.object_label,c.change_type,c.summary,c.old_json,c.new_json,c.documentation_requirement,c.review_status,
 (SELECT COUNT(*) FROM inventory_change_documentation_tasks dt WHERE dt.change_id=c.id AND dt.status='pending'),
 (SELECT COUNT(*) FROM inventory_change_documentation_tasks dt WHERE dt.change_id=c.id AND dt.status='documented'),
 COALESCE(c.notes,''),c.reviewed_by,c.reviewed_at,COALESCE(NULLIF(reviewer.display_name,''),reviewer.username,'') FROM inventory_changes c JOIN virtual_machines vm ON vm.id=c.vm_id LEFT JOIN inventory_snapshots i ON i.id=c.inventory_id LEFT JOIN users reviewer ON reviewer.id=c.reviewed_by WHERE c.id=?`, id).Scan(&c.ID, &c.VMID, &c.VMName, &c.VMHostname, &c.AgentID, &prev, &inventory, &c.OccurredAt, &c.Category, &c.ObjectType, &c.ObjectKey, &c.ObjectLabel, &c.ChangeType, &c.Summary, &oldS, &newS, &c.DocumentationRequirement, &c.ReviewStatus, &c.DocumentationPending, &c.DocumentationDone, &c.Notes, &reviewedBy, &reviewedAt, &c.ReviewedByName)
	if err != nil {
		return c, err
	}
	if inventory.Valid {
		c.InventoryID = inventory.Int64
	}
	if prev.Valid {
		v := prev.Int64
		c.PreviousInventoryID = &v
	}
	if reviewedBy.Valid {
		v := reviewedBy.Int64
		c.ReviewedBy = &v
	}
	if reviewedAt.Valid {
		v := reviewedAt.Time
		c.ReviewedAt = &v
	}
	if oldS.Valid {
		c.OldJSON = json.RawMessage(oldS.String)
	}
	if newS.Valid {
		c.NewJSON = json.RawMessage(newS.String)
	}
	return c, nil
}

// SetBaseline makes the current inventory snapshot the accepted starting
// point. Older changes are not deleted; normal listings simply hide them.
// vmID=0 applies the operation to every active VM that has an inventory.
func (s Service) SetBaseline(ctx context.Context, vmID, userID int64) (int64, error) {
	where := `vm.retired=0 AND vm.current_inventory_id IS NOT NULL`
	args := []any{}
	if vmID > 0 {
		where += ` AND vm.id=?`
		args = append(args, vmID)
	}
	var count int64
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM virtual_machines vm WHERE `+where, args...).Scan(&count); err != nil {
		return 0, err
	}
	if count == 0 {
		if vmID > 0 {
			return 0, sql.ErrNoRows
		}
		return 0, nil
	}
	reviewer := any(nil)
	if userID > 0 {
		reviewer = userID
	}
	query := `INSERT INTO inventory_change_baselines(vm_id,inventory_id,established_at,established_by,source)
SELECT vm.id,vm.current_inventory_id,UTC_TIMESTAMP(6),?,'manual' FROM virtual_machines vm WHERE ` + where + `
ON DUPLICATE KEY UPDATE inventory_id=VALUES(inventory_id),established_at=VALUES(established_at),established_by=VALUES(established_by),source='manual'`
	qargs := append([]any{reviewer}, args...)
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, query, qargs...); err != nil {
		return 0, err
	}
	// Explicit full reset only: replace the accepted VM snapshot and clear
	// per-object overrides, without deleting reviewed timeline events.
	store := `INSERT INTO inventory_change_baseline_values(vm_id,raw_json)
        SELECT vm.id,i.raw_json FROM virtual_machines vm
        JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE ` + where + `
        ON DUPLICATE KEY UPDATE raw_json=VALUES(raw_json),initialized_at=UTC_TIMESTAMP(6)`
	if _, err = tx.ExecContext(ctx, store, args...); err != nil {
		return 0, err
	}
	clean := `DELETE o FROM inventory_change_baseline_overrides o JOIN virtual_machines vm ON vm.id=o.vm_id WHERE ` + where
	if _, err = tx.ExecContext(ctx, clean, args...); err != nil {
		return 0, err
	}
	// An explicit full baseline reset also clears outstanding changes for the
	// selected VMs; it is NOT the same as reviewing one object.
	closeSQL := `UPDATE inventory_changes c JOIN virtual_machines vm ON vm.id=c.vm_id
       SET c.review_status='ignored',c.reviewed_by=?,c.reviewed_at=UTC_TIMESTAMP(6),
       c.notes=CONCAT_WS('\n',NULLIF(c.notes,''),'Acceptare explicită a întregului inventar ca baseline')
       WHERE c.review_status='new' AND ` + where
	if _, err = tx.ExecContext(ctx, closeSQL, append([]any{reviewer}, args...)...); err != nil {
		return 0, err
	}
	// Resetul explicit al baseline-ului închide și obligațiile rămase
	// pentru modificările nou-ignorate; nu atinge sarcinile deja documentate.
	if _, err = tx.ExecContext(ctx, `DELETE t FROM inventory_change_documentation_tasks t JOIN inventory_changes c ON c.id=t.change_id WHERE c.review_status='ignored' AND t.status='pending' AND c.notes LIKE '%Acceptare explicită a întregului inventar ca baseline%'`); err != nil {
		return 0, err
	}
	if err = tx.Commit(); err != nil {
		return 0, err
	}
	return count, nil
}

func (s Service) BackfillLatest(ctx context.Context) (int64, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT vm.id,vm.agent_id FROM virtual_machines vm WHERE vm.agent_id IS NOT NULL AND vm.retired=0 ORDER BY vm.id`)
	if err != nil {
		return 0, err
	}
	defer rows.Close()
	type pair struct{ vm, agent int64 }
	values := []pair{}
	for rows.Next() {
		var p pair
		if err := rows.Scan(&p.vm, &p.agent); err != nil {
			return 0, err
		}
		values = append(values, p)
	}
	if err := rows.Err(); err != nil {
		return 0, err
	}
	var total int64
	for _, p := range values {
		var currentID, prevID int64
		var currentRaw, prevRaw []byte
		err := s.DB.QueryRowContext(ctx, `SELECT id,raw_json FROM inventory_snapshots WHERE agent_id=? ORDER BY id DESC LIMIT 1`, p.agent).Scan(&currentID, &currentRaw)
		if err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				continue
			}
			return total, err
		}
		err = s.DB.QueryRowContext(ctx, `SELECT id,raw_json FROM inventory_snapshots WHERE agent_id=? AND id<? ORDER BY id DESC LIMIT 1`, p.agent, currentID).Scan(&prevID, &prevRaw)
		if err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				continue
			}
			return total, err
		}
		tx, err := s.DB.BeginTx(ctx, nil)
		if err != nil {
			return total, err
		}
		n, capErr := s.Capture(ctx, tx, p.agent, prevID, currentID, prevRaw, currentRaw)
		if capErr != nil {
			tx.Rollback()
			return total, capErr
		}
		if err := tx.Commit(); err != nil {
			return total, err
		}
		total += n
	}
	return total, nil
}
