# VM-DOC Server 0.21.93 — VM nouă importată din VCSA în Modificări

## Funcționalitate
O VM care apare în VM-DOC pentru prima dată prin import vCenter apare în **Modificări → Modificări** (global și fișa VM), cu:
- categorie **vCenter / VCSA**, tip **Adăugat**;
- text **VM NUME a fost importată pentru prima dată din VCSA**;
- data sincronizării, link către VM, sursă VCSA, MoID, stare power și pool;
- stare implicită **Nou**; documentație **Nu necesită** (poate fi modificată de administrator).

Un import identic nu generează a doua notificare, nici după mutarea între pool-uri, redenumire sau asociere agent. Este înregistrat și în Audit.

## Compatibilitate
- Upgrade din **0.21.92**. Agentul rămâne **1.7.18**, API existent.
- **Migrare SQL 085**: permiterea valorilor NULL în `inventory_changes.agent_id` și `.inventory_id`, necesară pentru VM-uri fără agent/snapshot. FK-urile se păstrează; migrarea ALTER poate bloca tabela pe MariaDB.
- Istoricul deja existent nu este reconstituit retroactiv: doar importurile noi de după actualizare generează eveniment.
- Recompilare necesară deoarece resursele statice sunt în binarul Go.

## Testare
- Funcția deterministă de creare a evenimentelor: teste unitare izolate reușite.
- Validări `node --check` pentru UI și parse JSON release-uri reușite.
- `go test ./...`, build complet cu vendor și integrare MariaDB/VCSA reale: **nevalidate în mediul de generare**; obligatorii pe staging.
