# Upgrade VM-DOC Server 0.21.92 → 0.21.93

1. **Backup** verificat: MariaDB (structură + date), configurație, binar și surse `0.21.92`. Noua migrare 085 schimbă tipul de NULL al coloanelor unui tabel istoric; testați migrarea pe copie de staging și estimați timpul/blocajele `ALTER TABLE`.
2. Aplicați `vm-doc-server-0.21.92-to-0.21.93-update.tar.gz` **din rădăcina surselor 0.21.92**, sau folosiți arhiva completă `vm-doc-server-0.21.93-source.zip`. Nu suprascrieți configul local; release-ul nu are vendor/ și nu include binare.
3. Pe serverul offline, cu vendor local disponibil:

   ```bash
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./internal/vcenter ./internal/inventorychanges
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
   ```

4. Înlocuiți binarul utilizat efectiv de `ExecStart` și reporniți serviciul. Migrările sunt rulate la startup de aplicație. Verificați logurile pentru migrarea 085; la o eroare DDL **nu continuați sincronizarea** înainte de remediere. Atenție: un `ALTER TABLE` pe istoric mare poate bloca scrieri și necesita fereastră de mentenanță.
5. Verificați `/version` = `0.21.93`, `app.js?v=0.21.93`, Ctrl+F5. După importul unei VM **care nu se afla deja în inventar**, verificați **Modificări → Modificări** (filtre: `Nou`, categorie `vCenter / VCSA`) și `Audit`; apoi sincronizați încă o dată și confirmați că evenimentul nu se dublează.

**Important:** VM-urile deja importate înainte de update, inclusiv cele descoperite în 0.21.92, nu generează un eveniment retrospectiv. Dacă este necesar backfill pentru ele, se proiectează separat, cu data reală de import, fără evenimente false.

**Rollback:** readuceți binarul 0.21.92; schema nullable este compatibilă în continuare cu vechiul binar, dar acesta nu afișează evenimentele fără agent în endpointurile lui. **Nu rulați automat migrarea `.down.sql`**: aceasta ar șterge evenimentele de import deoarece schema veche impunea `NOT NULL`. Înainte de orice rollback al schemei, exportați evenimentele VCSA și decideți explicit asupra pierderii istoricului.
