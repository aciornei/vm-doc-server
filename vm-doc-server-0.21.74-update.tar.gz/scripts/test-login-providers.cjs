#!/usr/bin/env node
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, '../web/static/js/login.js'), 'utf8');

async function runCase(providers, expected) {
  const nodes = Object.fromEntries(['loginForm','username','password','loginError','oidcLogin','loginIntro','loginSeparator','passwordLoginButton'].map(id=>[id,{id,hidden:id==='loginForm'||id==='oidcLogin'||id==='loginSeparator',textContent:'',value:'',addEventListener(){}}]));
  const fetch = async path => path.includes('providers') ? {ok:true,json:async()=>providers} : {ok:false};
  vm.runInNewContext(source, {document:{getElementById:id=>nodes[id]},fetch,location:{href:''}});
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(nodes.loginForm.hidden, expected.passwordHidden, JSON.stringify(providers));
  assert.equal(nodes.oidcLogin.hidden, expected.oidcHidden, JSON.stringify(providers));
  assert.equal(nodes.loginSeparator.hidden, expected.separatorHidden, JSON.stringify(providers));
  assert.match(nodes.loginIntro.textContent, expected.message);
}
(async()=>{
 await runCase({ldap:false,oidc:true,dev:false},{passwordHidden:true,oidcHidden:false,separatorHidden:true,message:/Keycloak/});
 await runCase({ldap:true,oidc:true,dev:false},{passwordHidden:false,oidcHidden:false,separatorHidden:false,message:/LDAP.*Keycloak/});
 await runCase({ldap:true,oidc:false,dev:false},{passwordHidden:false,oidcHidden:true,separatorHidden:true,message:/contul LDAP/});
 await runCase({ldap:false,oidc:false,dev:true},{passwordHidden:false,oidcHidden:true,separatorHidden:true,message:/dezvoltare/});
 await runCase({ldap:false,oidc:true,dev:true},{passwordHidden:false,oidcHidden:false,separatorHidden:false,message:/Keycloak.*dezvoltare/});
 console.log('PASS: login provider UI combinations');
})().catch(err=>{console.error(err);process.exitCode=1});
