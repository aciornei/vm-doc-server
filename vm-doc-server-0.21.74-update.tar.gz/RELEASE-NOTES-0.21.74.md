# VM-DOC Server 0.21.74 — Autentificare OIDC și director AD independent

**Data:** 22 octombrie 2026  
**Bază:** 0.21.73  
**Agent:** 1.7.18, fără schimbări  
**Migrare DB:** niciuna

## Comportament

- `auth.ldap.enabled` activează **numai** autentificarea directă prin utilizator și parolă LDAP.
- `auth.ldap.directory.enabled` activează independent **citirea** AD: importul responsabililor și persoanelor, beneficiarii și OU-urile din LDAP.
- Citirea AD reutilizează hosturile LDAP, TLS/CA și secretele `ldap_bind_dn` / `ldap_bind_password`. Păstrați contul tehnic de citire și drepturile sale. Setările secrete nu sunt afișate în Login.
- `GET /api/v1/auth/providers`: câmpurile independente `ldap`, `oidc`, `dev` (toate booleene). Nu raportează directorul LDAP ca metodă de autentificare.
- Login cu numai OIDC activ: doar buton „Autentificare prin Keycloak”, fără formular LDAP și fără separator „sau”. Dacă sunt mai multe metode, mesajul și separatorul reflectă strict metodele disponibile.
- Refuz explicit la `POST /api/v1/auth/ldap/login` când `ldap=false` și `dev=false`.

## Securitate / limite

Importul AD rămâne supus permisiunilor existente pe endpointurile protejate; conectarea LDAPS folosește config/secretele existente. OIDC poate necesita conectivitate cu issuer-ul Keycloak la pornire. Dezactivarea autentificării LDAP nu elimină conturile deja create și nu revocă sesiunile deja deschise; pentru revocare imediată trebuie administrate explicit sesiunile existente.

**Nu este implementat** un nou provider de citire AD și nu se modifică schema bazei. Pentru aplicare este obligatoriu build nou al serverului (`go:embed` include `login.js`).

## Verificări

JS: sintaxă și test pentru OIDC-only, LDAP-only, ambele, dev-only și OIDC+dev — trecute. Go: pachetele fără dependențe externe — trecute. Testele Go LDAP/auth adăugate în surse, dar imposibil de executat aici fără `vendor/`. Testele cu Keycloak real, LDAPS și MariaDB sunt necesare în staging.
