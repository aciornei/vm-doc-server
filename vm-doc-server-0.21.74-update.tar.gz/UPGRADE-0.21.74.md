# Upgrade VM-DOC 0.21.73 → 0.21.74

## Exemplu de configurație recomandată

Păstrați restul parametrilor LDAP existenți și credențialele tehnice din secretele criptate. Modificați doar activarea loginului și a directorului:

```yaml
auth:
  ldap:
    enabled: false            # Fără autentificare directă LDAP
    hosts: ["dc01.example.ro:636", "dc02.example.ro:636"]
    mode: "ldaps"
    ca_file: "/etc/vm-doc-server/ca/ldap-ca.pem"
    directory:
      enabled: true           # Responsabili, persoane, beneficiari, OU-uri AD
      base_dn: "OU=Users,DC=example,DC=ro"
      # Restul atributelor rămân din configurația actuală
  oidc:
    enabled: true             # Keycloak
    # issuer_url / client_id / scopes ... rămân cele existente
  dev:
    enabled: false
```

`directory.enabled=true` **nu** pornește loginul LDAP și **nu** apare ca metodă de login. Hosturile LDAP sunt obligatorii când citirea AD este activă, chiar dacă loginul LDAP este dezactivat.

## Instalare offline

1. Backup pentru `config.yaml`, fișierul criptat de secrete, vechiul binar și baza MariaDB conform politicii tale. Verifică sincronizarea AD și OIDC în staging.
2. Aplică `vm-doc-server-0.21.73-to-0.21.74.patch` sau `vm-doc-server-0.21.74-update.tar.gz` peste **sursele 0.21.73**, niciodată ambele, ori folosește ZIP-ul cu surse complete.
3. Rulează în mediul cu dependențele `vendor/`: `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off go build -o vm-doc-server ./cmd/vm-doc-server`.
4. Înlocuiește binarul (resursele Login sunt compilate cu `go:embed`); configurează `auth.ldap.enabled=false`, `auth.ldap.directory.enabled=true`, `auth.oidc.enabled=true`, `auth.dev.enabled=false`. Repornește serviciul.
5. Verifică `systemctl status vm-doc-server` și `journalctl -u vm-doc-server -n 80 --no-pager`.
6. Confirmă răspunsul `curl -sS http://127.0.0.1:9080/api/v1/auth/providers`: **`ldap:false`, `oidc:true`, `dev:false`** (ordinea JSON nu este relevantă).
7. Deschide `/login`: trebuie să existe un singur buton Keycloak, textul „Autentificați-vă folosind Keycloak.”, fără formular LDAP și fără separator „sau”. Verifică că loginul Keycloak funcționează.
8. Cu permisiunea `nomenclatures.read/manage`, testează importul responsabililor/persoanelor/OU/beneficiarilor din AD. Verifică și că `POST /api/v1/auth/ldap/login` returnează `404` când LDAP/dev sunt dezactivate.

### Diagnostic la 502

`502 Bad Gateway` în Nginx este de regulă consecința procesului backend oprit. Verifică jurnalul VM-DOC. Din 0.21.74, configurația LDAP directory-only nu mai este respinsă de validator. Dacă OIDC issuer-ul Keycloak nu este disponibil, inițializarea OIDC poate încă împiedica pornirea.

### Rollback

Revino la binarul 0.21.73 **și** restaurează configurația compatibilă cu acesta: versiunea 0.21.73 nu acceptă `ldap.enabled=false` împreună cu `directory.enabled=true`. Fie activezi temporar ambele, fie oprești importul LDAP, cu limitările aferente. Nu există migrare SQL de reversat.

Testarea completă LDAP/Keycloak/MariaDB nu a fost posibilă în acest mediu offline.
