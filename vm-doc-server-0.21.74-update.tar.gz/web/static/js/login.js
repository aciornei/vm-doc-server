const form = document.getElementById('loginForm');
const username = document.getElementById('username');
const password = document.getElementById('password');
const errorBox = document.getElementById('loginError');
const oidcLogin = document.getElementById('oidcLogin');
const loginIntro = document.getElementById('loginIntro');
const loginSeparator = document.getElementById('loginSeparator');
const passwordLoginButton = document.getElementById('passwordLoginButton');

// Display only methods permitted by the server; never infer LDAP login from AD directory access.
function showLoginProviders(providers) {
  const ldap = providers?.ldap === true;
  const oidc = providers?.oidc === true;
  const dev = providers?.dev === true;
  const passwordLogin = ldap || dev;
  form.hidden = !passwordLogin;
  oidcLogin.hidden = !oidc;
  loginSeparator.hidden = !(passwordLogin && oidc);
  passwordLoginButton.textContent = ldap ? 'Autentificare LDAP' : 'Autentificare dezvoltare';
  if (ldap && oidc) {
    loginIntro.textContent = 'Alegeți autentificarea LDAP sau autentificarea prin Keycloak.';
  } else if (oidc && dev) {
    loginIntro.textContent = 'Autentificați-vă prin Keycloak sau folosind contul de dezvoltare.';
  } else if (oidc) {
    loginIntro.textContent = 'Autentificați-vă folosind Keycloak.';
  } else if (ldap) {
    loginIntro.textContent = 'Autentificați-vă folosind contul LDAP.';
  } else if (dev) {
    loginIntro.textContent = 'Autentificare de dezvoltare.';
  } else {
    loginIntro.textContent = 'Nu este disponibilă nicio metodă de autentificare.';
  }
}

(async () => {
  try {
    const response = await fetch('/api/v1/auth/providers', {cache: 'no-store'});
    if (!response.ok) throw new Error('providers unavailable');
    showLoginProviders(await response.json());
  } catch (_) {
    form.hidden = true;
    oidcLogin.hidden = true;
    loginSeparator.hidden = true;
    loginIntro.textContent = 'Nu se pot verifica metodele de autentificare. Reîncărcați pagina.';
  }
})();

(async () => {
  try {
    const response = await fetch('/api/v1/auth/me');
    if (response.ok) location.href = '/';
  } catch (_) {}
})();

form.addEventListener('submit', async event => {
  event.preventDefault();
  errorBox.textContent = '';
  try {
    const response = await fetch('/api/v1/auth/ldap/login', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({username: username.value, password: password.value})
    });
    if (response.ok) {
      location.href = '/';
      return;
    }
    const body = await response.json().catch(() => ({}));
    errorBox.textContent = body.message || 'Autentificare eșuată.';
  } catch (_) {
    errorBox.textContent = 'Serverul nu este disponibil.';
  }
});
