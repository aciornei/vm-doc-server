package config

import (
	"strings"
	"testing"
	"time"
)

func validConfigForTest() Config {
	cfg := Config{
		Version:           1,
		App:               AppConfig{Environment: "test", Timezone: "Europe/Bucharest"},
		Database:          DatabaseConfig{Host: "db", Name: "vm_doc", User: "vm_doc"},
		Secrets:           SecretsConfig{EncryptedFile: "/tmp/secrets", MasterKeyEnv: "TEST_KEY"},
		Session:           SessionConfig{IdleTimeout: Duration(time.Minute), AbsoluteTimeout: Duration(time.Hour)},
		Auth:              AuthConfig{Dev: DevConfig{Enabled: true}},
		Collector:         CollectorConfig{Workers: 1},
		VCenter:           VCenterConfig{RequestTimeout: Duration(time.Minute), DetailWorkers: 4, SchedulerInterval: Duration(time.Minute)},
		Veeam:             VeeamConfig{RequestTimeout: Duration(time.Minute), SchedulerInterval: Duration(time.Minute)},
		AgentRegistration: AgentRegistrationConfig{MaxRequestBody: 25 << 20},
		OpenAPI:           OpenAPIConfig{SwaggerPath: "/docs/"},
	}
	applyDefaults(&cfg)
	return cfg
}

func TestValidateVCenterSchedulerAndTimezone(t *testing.T) {
	cfg := validConfigForTest()
	if err := cfg.Validate(); err != nil {
		t.Fatalf("valid config: %v", err)
	}
	cfg.App.Timezone = "Invalid/Timezone"
	cfg.VCenter.SchedulerInterval = Duration(-time.Second)
	err := cfg.Validate()
	if err == nil || !strings.Contains(err.Error(), "invalid app.timezone") || !strings.Contains(err.Error(), "scheduler_interval") {
		t.Fatalf("unexpected validation error: %v", err)
	}
}

func TestLDAPDirectoryDefaults(t *testing.T) {
	cfg := validConfigForTest()
	cfg.Auth.Dev.Enabled = false
	cfg.Auth.LDAP = LDAPConfig{
		Enabled:           true,
		Hosts:             []string{"ldap.example.test:636"},
		UserBaseDN:        "OU=Users,DC=example,DC=test",
		UsernameAttribute: "sAMAccountName",
		Directory:         LDAPDirectoryConfig{Enabled: true},
	}
	applyDefaults(&cfg)
	if cfg.Auth.LDAP.Directory.BaseDN != cfg.Auth.LDAP.UserBaseDN {
		t.Fatalf("unexpected directory base DN: %q", cfg.Auth.LDAP.Directory.BaseDN)
	}
	if cfg.Auth.LDAP.Directory.IdentityAttribute != "objectGUID" || cfg.Auth.LDAP.Directory.DepartmentAttribute != "department" || cfg.Auth.LDAP.Directory.PageSize != 500 {
		t.Fatalf("unexpected directory defaults: %#v", cfg.Auth.LDAP.Directory)
	}
	if err := cfg.Validate(); err != nil {
		t.Fatalf("valid LDAP directory config: %v", err)
	}
}

func TestLDAPDirectoryIndependentOfPasswordLogin(t *testing.T) {
	cfg := validConfigForTest()
	cfg.Auth.Dev.Enabled = false
	cfg.Auth.OIDC = OIDCConfig{Enabled: true, IssuerURL: "https://keycloak.example.test/realms/AD", ClientID: "vm-doc"}
	cfg.App.BaseURL = "https://vm-doc.example.test"
	cfg.Auth.LDAP = LDAPConfig{
		Enabled:    false,
		Hosts:      []string{"dc01.example.test:636"},
		UserBaseDN: "OU=Users,DC=example,DC=test",
		Directory:  LDAPDirectoryConfig{Enabled: true},
	}
	applyDefaults(&cfg)
	if err := cfg.Validate(); err != nil {
		t.Fatalf("OIDC-only login with LDAP directory must be valid: %v", err)
	}
	cfg.Auth.LDAP.Hosts = nil
	if err := cfg.Validate(); err == nil || !strings.Contains(err.Error(), "no hosts are configured") {
		t.Fatalf("enabled directory without LDAP hosts must fail: %v", err)
	}
}

func TestDisabledLDAPDirectoryNeedsNoLDAPHosts(t *testing.T) {
	cfg := validConfigForTest()
	cfg.Auth.LDAP.Enabled = false
	cfg.Auth.LDAP.Directory.Enabled = false
	cfg.Auth.LDAP.Hosts = nil
	if err := cfg.Validate(); err != nil {
		t.Fatalf("fully disabled LDAP must be valid: %v", err)
	}
}

func TestLDAPDirectoryRejectsInvalidAttribute(t *testing.T) {
	cfg := validConfigForTest()
	cfg.Auth.Dev.Enabled = false
	cfg.Auth.LDAP = LDAPConfig{
		Enabled: true,
		Hosts:   []string{"ldap.example.test:636"},
		Directory: LDAPDirectoryConfig{
			Enabled:             true,
			BaseDN:              "OU=Users,DC=example,DC=test",
			IdentityAttribute:   "objectGUID",
			DepartmentAttribute: "department)(cn=*",
			PhoneAttribute:      "telephoneNumber",
			PageSize:            500,
		},
	}
	err := cfg.Validate()
	if err == nil || !strings.Contains(err.Error(), "department_attribute is invalid") {
		t.Fatalf("unexpected validation error: %v", err)
	}
}
