package auth

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"vm-doc-server/internal/config"
)

func TestProvidersExcludeDirectoryOnlyLDAPLogin(t *testing.T) {
	svc := &Service{Config: config.Config{Auth: config.AuthConfig{
		LDAP: config.LDAPConfig{Enabled: false, Directory: config.LDAPDirectoryConfig{Enabled: true}},
		OIDC: config.OIDCConfig{Enabled: true},
	}}}
	rec := httptest.NewRecorder()
	svc.Providers(rec, httptest.NewRequest(http.MethodGet, "/api/v1/auth/providers", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("provider status: %d", rec.Code)
	}
	var got map[string]bool
	if err := json.Unmarshal(rec.Body.Bytes(), &got); err != nil {
		t.Fatal(err)
	}
	if got["ldap"] || !got["oidc"] || got["dev"] {
		t.Fatalf("directory-only unexpectedly enables LDAP login: %#v", got)
	}
}

func TestLDAPLoginRejectsDisabledPasswordAuthentication(t *testing.T) {
	svc := &Service{Config: config.Config{Auth: config.AuthConfig{
		LDAP: config.LDAPConfig{Enabled: false, Directory: config.LDAPDirectoryConfig{Enabled: true}},
		OIDC: config.OIDCConfig{Enabled: true},
	}}}
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/api/v1/auth/ldap/login", strings.NewReader(`{"username":"sample","password":"secret"}`))
	svc.LDAPLogin(rec, req)
	if rec.Code != http.StatusNotFound {
		t.Fatalf("expected disabled login rejection, got %d body %s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), "password_login_disabled") {
		t.Fatalf("unexpected response: %s", rec.Body.String())
	}
}

func TestProvidersSeparateDevFromLDAP(t *testing.T) {
	svc := &Service{Config: config.Config{Auth: config.AuthConfig{Dev: config.DevConfig{Enabled: true}}}}
	rec := httptest.NewRecorder()
	svc.Providers(rec, httptest.NewRequest(http.MethodGet, "/api/v1/auth/providers", nil))
	var got map[string]bool
	if err := json.Unmarshal(rec.Body.Bytes(), &got); err != nil {
		t.Fatal(err)
	}
	if got["ldap"] || got["oidc"] || !got["dev"] {
		t.Fatalf("unexpected dev provider flags: %#v", got)
	}
}
