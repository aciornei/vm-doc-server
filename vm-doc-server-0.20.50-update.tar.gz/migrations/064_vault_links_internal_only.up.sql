-- 0.20.50: linkuri Vault strict interne aplicației pentru VM-uri și servicii.
-- Aceste câmpuri nu sunt folosite de generatoarele DOCX/MD/PDF și nu sunt publicate în Outline.

ALTER TABLE virtual_machines
  ADD COLUMN IF NOT EXISTS vault_url VARCHAR(2048) NOT NULL DEFAULT '' AFTER outline_documentation_disabled;

ALTER TABLE internal_services
  ADD COLUMN IF NOT EXISTS vault_url VARCHAR(2048) NOT NULL DEFAULT '' AFTER outline_documentation_disabled;
