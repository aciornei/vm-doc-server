# Upgrade vm-doc-server 0.20.49 -> 0.20.50

0.20.50 compactează secțiunea **Publicare Outline** din fișa VM și adaugă linkuri **Vault** strict interne aplicației pentru VM-uri și servicii.

Include migrarea `064_vault_links_internal_only.up.sql`, care adaugă `vault_url` în `virtual_machines` și `internal_services`. Linkurile Vault nu sunt incluse în fișe DOCX/Markdown/PDF, exporturile de documentație sau publicările Outline. Nu este necesar update de vm-doc-agent.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.49 \
      /usr/local/src/vm-doc-server-0.20.50

tar -xzf vm-doc-server-0.20.50-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.50

cd /usr/local/src/vm-doc-server-0.20.50

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

La prima pornire, vm-doc-server aplică automat migrarea 064. Înlocuiți binarul conform procedurii curente și reporniți serviciul.

După restart faceți **Ctrl+F5** pentru a încărca resursele `v=0.20.50`.
