package vcenter

import (
	"strings"
	"testing"
)

func TestNormalizeVMFilter(t *testing.T) {
	got := NormalizeVMFilter(VMFilter{Page: -1, PageSize: 1000, Agent: " ONLINE ", Retired: " FALSE ", Presence: " MISSING ", Baseline: " YES "})
	if got.Page != 1 || got.PageSize != maxVMPageSize || got.Agent != "online" || got.Retired != "false" || got.Presence != "missing" || got.Baseline != "yes" {
		t.Fatalf("unexpected normalized filter: %+v", got)
	}
}

func TestBuildVMWhere(t *testing.T) {
	where, args, err := buildVMWhere(NormalizeVMFilter(VMFilter{
		Query: "ubuntu", Power: "POWERED_ON", Agent: "configured", Retired: "false", Presence: "missing", Baseline: "yes", SourceID: 4, ServiceID: 7,
	}))
	if err != nil {
		t.Fatal(err)
	}
	for _, part := range []string{"vm.name LIKE ?", "vm.power_state=?", "vm.vcenter_source_id=?", "FIND_IN_SET(?,COALESCE(svcmap.service_ids,''))>0", "vm.retired=0", "vm.present_in_vcenter=0", "vmbl.vm_id IS NOT NULL", "vm.agent_id IS NOT NULL"} {
		if !strings.Contains(where, part) {
			t.Errorf("where clause missing %q: %s", part, where)
		}
	}
	if len(args) != 17 {
		t.Fatalf("got %d args, want 17", len(args))
	}
}

func TestBuildVMWhereRejectsUnknownAgent(t *testing.T) {
	_, _, err := buildVMWhere(NormalizeVMFilter(VMFilter{Agent: "broken"}))
	if err == nil {
		t.Fatal("expected error")
	}
}

func TestBuildVMWhereRejectsUnknownPresence(t *testing.T) {
	_, _, err := buildVMWhere(NormalizeVMFilter(VMFilter{Presence: "ghost"}))
	if err == nil {
		t.Fatal("expected error")
	}
}

func TestBuildVMWhereRejectsUnknownBaseline(t *testing.T) {
	_, _, err := buildVMWhere(NormalizeVMFilter(VMFilter{Baseline: "maybe"}))
	if err == nil {
		t.Fatal("expected error")
	}
}

func TestBuildVMWhereOutlineAndOSSupportFilters(t *testing.T) {
	where, _, err := buildVMWhere(NormalizeVMFilter(VMFilter{Outline: "yes", OSSupport: "no"}))
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(where, "vm.outline_documentation_disabled=0") {
		t.Fatalf("outline filter missing: %s", where)
	}
	if !strings.Contains(where, "unsupported_os") || !strings.Contains(where, "='unsupported'") {
		t.Fatalf("OS support filter missing: %s", where)
	}
}

func TestBuildVMWhereRejectsUnknownOutlineAndOSSupport(t *testing.T) {
	if _, _, err := buildVMWhere(NormalizeVMFilter(VMFilter{Outline: "maybe"})); err == nil {
		t.Fatal("expected outline filter error")
	}
	if _, _, err := buildVMWhere(NormalizeVMFilter(VMFilter{OSSupport: "maybe"})); err == nil {
		t.Fatal("expected os_support filter error")
	}
}

func TestNormalizeDeleteIDs(t *testing.T) {
	ids, err := normalizeDeleteIDs([]int64{9, 2, 9, 4})
	if err != nil {
		t.Fatal(err)
	}
	want := []int64{2, 4, 9}
	if len(ids) != len(want) {
		t.Fatalf("got %v, want %v", ids, want)
	}
	for i := range want {
		if ids[i] != want[i] {
			t.Fatalf("got %v, want %v", ids, want)
		}
	}
}

func TestVMListIncludesOutlinePublicationMetadata(t *testing.T) {
	for _, part := range []string{
		"vm.outline_documentation_disabled",
		"ovmoutline.last_synced_at",
		"outline_vm_documents_global ovmoutline",
		"ovmoutline.target_code='virtualization'",
	} {
		if !strings.Contains(vmSelect, part) && !strings.Contains(vmFrom, part) {
			t.Errorf("VM query missing Outline metadata %q", part)
		}
	}
}

func TestVMListIncludesVaultURL(t *testing.T) {
	if !strings.Contains(vmSelect, "vm.vault_url") {
		t.Fatalf("VM query missing internal Vault URL metadata: %s", vmSelect)
	}
}

func TestVMCompletionRequiresResourceServiceConfiguration(t *testing.T) {
	for _, part := range []string{
		"resourcecfg.configured_count",
		"resourcecfg.required_count",
		"docker_container_service_assignments",
		"database_instance_service_assignments",
		"database_catalog_service_assignments",
		"web_site_service_assignments",
		"direct_assignment.technical_role_id IS NOT NULL",
		"direct_assignment.solution_type_id IS NOT NULL",
	} {
		if !strings.Contains(vmSelect, part) {
			t.Errorf("vm completion query missing %q", part)
		}
	}
}
