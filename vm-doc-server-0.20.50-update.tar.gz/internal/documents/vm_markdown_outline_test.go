package documents

import (
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
)

func TestRenderVMMarkdownStandalone(t *testing.T) {
	data := GenerationData{
		VM:                 domain.VirtualMachine{ID: 7, Name: "vm-prod-01", GuestHostname: "vm-prod-01.example", VaultURL: "https://vault.internal/secret/vm-prod-01"},
		GeneratedAt:        time.Date(2026, 9, 28, 10, 0, 0, 0, time.UTC),
		DocumentNumber:     "FVM-TEST",
		GeneratedBy:        domain.User{Username: "admin", DisplayName: "Admin User"},
		IncludeGeneratedBy: false,
	}
	text := string(RenderVMMarkdown(data))
	for _, want := range []string{"# Fișă tehnică VM", "FVM-TEST", "Identificare și resurse"} {
		if !strings.Contains(text, want) {
			t.Fatalf("markdown missing %q:\n%s", want, text)
		}
	}
	if strings.Contains(text, "Generat de") {
		t.Fatalf("markdown unexpectedly contains generated-by row: %s", text)
	}
	if strings.Contains(text, "vault.internal") {
		t.Fatalf("Vault URL leaked into VM Markdown: %s", text)
	}
}
