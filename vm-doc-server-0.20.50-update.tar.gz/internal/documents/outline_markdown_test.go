package documents

import (
	"strings"
	"testing"

	"vm-doc-server/internal/domain"
)

func TestRenderVMMarkdownOutlineUsesVCenterNameAndServiceOutlineLink(t *testing.T) {
	data := GenerationData{
		VM: domain.VirtualMachine{Name: "vcenter-app-01", GuestHostname: "guest-app-01", VaultURL: "https://vault.internal/secret/vcenter-app-01"},
		Operational: domain.VMOperationalMetadata{ServiceAssignments: []domain.VMServiceAssignment{{
			InternalServiceID: 42, InternalServiceName: "LIS", ArchitecturalDomain: "Aplicații", ITILCategory: "Medical", UsageType: "dedicated",
		}}},
		OutlineMode:        true,
		OutlineServiceURLs: map[int64]string{42: "https://outline.example/doc/lis-abc"},
	}
	got := string(RenderVMMarkdown(data))
	if !strings.Contains(got, "Fișă tehnică VM — vcenter-app-01") {
		t.Fatalf("expected vCenter name in heading, got:\n%s", got)
	}
	if strings.Contains(got, "Fișă tehnică VM — guest-app-01") {
		t.Fatalf("guest hostname unexpectedly used as Outline VM title: %s", got)
	}
	if !strings.Contains(got, "[LIS](https://outline.example/doc/lis-abc)") {
		t.Fatalf("expected Outline service link, got:\n%s", got)
	}
	if strings.Contains(got, "vault.internal") {
		t.Fatalf("Vault URL leaked into VM Outline Markdown:\n%s", got)
	}
}

func TestRenderServiceMarkdownOutlineUsesVMOutlineLinksOnly(t *testing.T) {
	data := ServiceGenerationData{
		Service: domain.InternalService{
			Name:     "LIS",
			VaultURL: "https://vault.internal/secret/lis",
			VMs:      []domain.InternalServiceVM{{ID: 7, Name: "vcenter-lis-01", GuestHostname: "guest-lis-01", Environment: "Prod"}},
		},
		OutlineMode:   true,
		OutlineVMURLs: map[int64]string{7: "https://outline.example/doc/vcenter-lis-01-xyz"},
		VMDocuments:   []ServiceVMDocument{{VMID: 7, VMName: "vcenter-lis-01", DocumentNumber: "VM-7", DownloadURL: "https://vm-doc.example/api/v1/documents/99/download"}},
	}
	got := string(RenderServiceMarkdown(data))
	if !strings.Contains(got, "[vcenter-lis-01](https://outline.example/doc/vcenter-lis-01-xyz)") {
		t.Fatalf("expected Outline VM link, got:\n%s", got)
	}
	if strings.Contains(got, "vm-doc.example") {
		t.Fatalf("VM-DOC link leaked into Outline Markdown:\n%s", got)
	}
	if strings.Contains(got, "vault.internal") {
		t.Fatalf("Vault URL leaked into service Outline Markdown:\n%s", got)
	}
}
