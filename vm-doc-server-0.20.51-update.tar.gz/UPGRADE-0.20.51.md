# Upgrade vm-doc-server 0.20.50 -> 0.20.51

0.20.51 mută **Publicare Outline** și **Vault** exclusiv pe prima pagină a VM-ului, în **Rezumat**, afișate compact pe același rând. Din `Configurare → Infrastructură` cele două panouri sunt eliminate complet.

Nu există migrare DB și agentul nu se modifică.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.50 \
      /usr/local/src/vm-doc-server-0.20.51

tar -xzf vm-doc-server-0.20.51-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.51

cd /usr/local/src/vm-doc-server-0.20.51

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După restart faceți **Ctrl+F5** pentru a încărca resursele `v=0.20.51`.
