# Upgrade VM-DOC Server 0.21.18 → 0.21.19

Hotfix exclusiv de contract OpenAPI/Swagger. `openapi/openapi.yaml` conținea dublate rutele `/api/v1/people` și `/api/v1/people/{id}`; parserul strict raporta `duplicated mapping key` la linia ~2253. Sunt păstrate definițiile complete ale rutelor, cu parametrii și schemele lor. `info.version` este actualizat; `openapi/openapi_test.go` împiedică reapariția dublurilor.

1. Fă backup la directorul surselor și la binarul aflat în funcțiune.
2. `cp -a /usr/local/src/vm-doc-server-0.21.18 /usr/local/src/vm-doc-server-0.21.19` (păstrează `vendor/`).
3. În directorul nou extrage `vm-doc-server-0.21.19-update.tar.gz` la rădăcină.
4. Verifică: `GOPROXY=off GOFLAGS=-mod=vendor go test ./openapi`, apoi `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și `GOPROXY=off GOFLAGS=-mod=vendor make build`.
5. Actualizează binarul conform procedurii existente doar după build; verifică pagina Swagger după repornire și Ctrl+F5.

Fișierul YAML este **încorporat în binarul Go** prin `go:embed`; simpla înlocuire a fișierului YAML pe serverul de producție nu actualizează documentația servită până la recompilare și repornire.

Nu există migrare SQL nouă și nu se schimbă Agentul 1.7.18. Verificarea întregului server cu `vendor/` și instalarea reală rămân de făcut în mediul utilizatorului.
