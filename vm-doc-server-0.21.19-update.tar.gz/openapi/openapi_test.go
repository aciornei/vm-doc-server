package openapi

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
)

// The paths collection uses block-style YAML with two-space indentation.
// Check every route, so accidental repeated route keys cannot reach Swagger.
func TestOpenAPIPathsAreUnique(t *testing.T) {
	raw, err := Files.ReadFile("openapi.yaml")
	if err != nil {
		t.Fatal(err)
	}
	section := false
	paths := make(map[string]int)
	pattern := regexp.MustCompile(`^  (/[^:]+):(?:\s*#.*)?$`)
	scanner := bufio.NewScanner(strings.NewReader(string(raw)))
	for n := 1; scanner.Scan(); n++ {
		line := scanner.Text()
		if line == "paths:" {
			section = true
			continue
		}
		if section && line != "" && !strings.HasPrefix(line, " ") && !strings.HasPrefix(line, "#") {
			section = false
		}
		if !section {
			continue
		}
		if match := pattern.FindStringSubmatch(line); match != nil {
			if old, found := paths[match[1]]; found {
				t.Errorf("duplicate OpenAPI path %s at lines %d and %d", match[1], old, n)
			}
			paths[match[1]] = n
		}
	}
	if err := scanner.Err(); err != nil {
		t.Fatal(err)
	}
	if len(paths) == 0 {
		t.Fatal("no OpenAPI paths found")
	}
	for _, path := range []string{"/api/v1/people", "/api/v1/people/{id}"} {
		if _, found := paths[path]; !found {
			t.Error(fmt.Sprintf("missing OpenAPI path %s", path))
		}
	}
}

func TestOpenAPIVersionMatchesRelease(t *testing.T) {
	raw, err := Files.ReadFile("openapi.yaml")
	if err != nil {
		t.Fatal(err)
	}
	version, err := os.ReadFile(filepath.Join("..", "VERSION"))
	if err != nil {
		t.Fatal(err)
	}
	pattern := regexp.MustCompile(`(?m)^  version: (.+)$`)
	match := pattern.FindStringSubmatch(string(raw))
	if match == nil || strings.TrimSpace(match[1]) != strings.TrimSpace(string(version)) {
		t.Fatalf("OpenAPI version %q differs from VERSION %q", match, strings.TrimSpace(string(version)))
	}
}
