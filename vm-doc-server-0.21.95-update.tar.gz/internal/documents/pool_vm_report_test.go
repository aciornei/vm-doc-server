package documents

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"io"
	"strings"
	"testing"
	"time"
)

func TestPoolVMReportThreeColumnsAndEscapedNotes(t *testing.T) {
	data, err := BuildPoolVMReportDOCX([]PoolVMReportEntry{{Pool: "VCSA / A&B", VM: "VM <prod>", Observation: "Note & data\nA doua linie"}, {Pool: "Fără pool identificat (VCSA)", VM: "", Observation: ""}}, []string{"Toate pool-urile"}, time.Date(2026, 11, 16, 8, 0, 0, 0, time.UTC))
	if err != nil {
		t.Fatal(err)
	}
	z, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		t.Fatal(err)
	}
	var found bool
	for _, f := range z.File {
		if f.Name != "word/document.xml" {
			continue
		}
		found = true
		rd, _ := f.Open()
		content, _ := io.ReadAll(rd)
		rd.Close()
		if err := xml.Unmarshal(content, new(any)); err != nil {
			t.Fatalf("invalid document.xml: %v", err)
		}
		s := string(content)
		for _, value := range []string{"Nume Pool", "Denumire VM", "Obs.", "A&amp;B", "VM &lt;prod&gt;", "Note &amp; data", "<w:tblHeader"} {
			if !strings.Contains(s, value) {
				t.Errorf("missing %q", value)
			}
		}
		if strings.Count(s, "<w:tr>") != 3 {
			t.Errorf("expected header and 2 rows")
		}
	}
	if !found {
		t.Fatal("missing Word body")
	}
}
