# VM-DOC Server 0.21.95 — Raport VM-uri pe resource pool-uri

Data: 2026-11-16 · Bază: server 0.21.94 · Agent: 1.7.18 (neschimbat)

## Funcționalitate

- Meniu **Rapoarte → VM-uri pe resource pool-uri** cu EXACT 3 coloane: **Nume Pool**, **Denumire VM**, **Obs.**
- Afișează toate pool-urile prezente în ultimele descoperiri VCSA, inclusiv pool-uri excluse de la import, categoria virtuală „Fără pool identificat (VCSA)” și pool-uri goale.
- Pentru un VM neimportat din pool exclus, folosește `vcenter_pool_vm_audit_state` (ultima observație a sincronizării) pentru nume; nu presupune că VM-ul există în `virtual_machines`. Observațiile sunt completate doar pentru VM-uri cu note operaționale în VM-DOC.
- Ierarhie pool în denumire (`părinte / copil`) pentru a evita confuziile între pool-uri omonime.
- Filtre combinate: căutare după pool/VM/sursă/observații, sursa VCSA, resource pool, politica de includere, power pornit/nepornit, mediu, stare import (inclusiv retrase), cu/fără observații, pool-uri cu/fără VM-uri; paginare 10/25/50/100/200.
- Export Word `.docx` cu exact trei coloane, titlu/filtre/data generării, format A4 landscape, antet repetat pe fiecare pagină; toate rândurile filtrate, independent de paginare. Maximum 25.000 de rânduri per export, cu eroare explicită dacă este depășit.
- Pool-uri cu număr de VM-uri raportat dar fără detalii de sincronizare sunt marcate „sincronizare VCSA necesară”, nu declarate incorect goale.

## Detalii tehnice

- Noi endpointuri `GET /api/v1/reports/pool-vms` și `GET /api/v1/reports/pool-vms/export/docx` sub aceeași permisiune `reports.read`; documentație Swagger actualizată.
- Citire numai din tabelele existente: `vcenter_resource_pools`, `vcenter_pool_vm_audit_state`, `virtual_machines`, `vm_operational_metadata` și nomenclatoare. Nicio migrare SQL și nicio schimbare în sincronizare, import, agenți, documentația VM/Outline/Vault.
- Șabloanele Word și exportul sunt generate server-side prin librăria DOCX existentă, fără instalarea vreunei biblioteci externe.
- Nu sunt incluse în Word identificatori tehnici, tokenuri, secrete sau linkuri Vault stocate în câmpul dedicat.

## Validări în acest mediu

- `node --check web/static/js/app.js` — OK.
- `GOPROXY=off GOSUMDB=off go test ./internal/documents -run TestPool -count=1` — OK.
- Compile/test izolat pentru noul handler Go, cu definițiile de server și dependințele externe substituite prin stub-uri — OK.
- DOCX de probă cu 28 de VM-uri randat în trei pagini și inspectat vizual — OK.
- **Nevalidate aici:** `go test ./...`, build-ul serverului complet cu `vendor/`, integrarea MariaDB/VCSA reală și UX real în browser cu autentificare.
