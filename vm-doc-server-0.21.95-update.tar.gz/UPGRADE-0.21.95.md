# Actualizare VM-DOC 0.21.94 → 0.21.95

1. Fă backup binar/config și un snapshot/backup MariaDB înainte de orice schimbare. Actualizarea nu execută migrații SQL.
2. Folosește `vm-doc-server-0.21.94-to-0.21.95-update.tar.gz` **peste directorul de surse 0.21.94**, din rădăcina proiectului (cea cu `Makefile` și `VERSION`):
   ```bash
   tar -xzf /cale/vm-doc-server-0.21.94-to-0.21.95-update.tar.gz
   cat VERSION # 0.21.95
   ```
   Alternativ, folosește arhiva de surse complete 0.21.95, fără a suprascrie configurația reală ori directorul `vendor/` local.
3. În directorul proiectului (cu `vendor/` existent):
   ```bash
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
   ```
4. Identifică binarul folosit de systemd înainte să îl înlocuiești:
   ```bash
   systemctl cat vm-doc-server | grep ExecStart
   ```
   Oprește serviciul, salvează binarul vechi și instalează noul `bin/vm-doc-server` **exact** la calea din `ExecStart`. Pornește apoi serviciul și verifică `/version` = `0.21.95`. Fă Ctrl+F5 în browser.
5. În **Surse & sincronizări → VCSA**, rulează sincronizările pentru sursele relevante. **Scan/Descoperă pool-uri** singur actualizează structura și numărul de VM-uri, nu garantează numele fiecărui VM din pool-urile excluse; raportul se bazează pe sincronizarea reușită.
6. Deschide **Rapoarte → VM-uri pe resource pool-uri**; cu filtrele resetate verifică pool-urile incluse/excluse, neimportatele, pool-urile goale și `Fără pool identificat`. Aplică filtre și descarcă Word pentru verificarea celor trei coloane.

## Rollback

- Înlocuiește executabilul cu copia 0.21.94 și repornește. Fără rollback SQL sau agent; datele nu sunt schimbate de raport.

## Limite de validare

- Pachetul conține surse, nu binare Go compilate și nici `vendor/`.
- Build complet Go, integrarea MariaDB/VCSA și testul real de autentificare trebuie efectuate în staging/server.
