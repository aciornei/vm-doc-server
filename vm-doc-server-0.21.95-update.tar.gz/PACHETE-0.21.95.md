# VM-DOC Server 0.21.95 — pachete

- `vm-doc-server-0.21.95-release.zip`: colecția tuturor artefactelor de livrare.
- `vm-doc-server-0.21.95-source.zip`: surse complete (fără `vendor/` sau binare compilate).
- `vm-doc-server-0.21.94-to-0.21.95-update.tar.gz`: doar fișierele schimbate; se extrage în **rădăcina surselor 0.21.94**.
- `vm-doc-server-0.21.94-to-0.21.95.patch`: diff text pentru verificare/revizie, aplicabil cu `patch -p1`.
- `UPGRADE-0.21.95.md`, `RELEASE-NOTES-0.21.95.md`, `CHANGELOG.md`, `CONTEXT.md`, `VM-DOC-TODO.md`.

Nu există migrare SQL nouă. Agentul VM-DOC rămâne 1.7.18. Verificarea completă cu MariaDB/VCSA necesită staging și `vendor/` local.
