-- 0.20.38: repară idempotent schema pentru controalele Outline.
-- Această migrare este intenționat redundantă cu 058 pentru instalațiile
-- în care 058 a fost înregistrată ca aplicată, dar coloanele nu au rămas în schemă.

ALTER TABLE virtual_machines
  ADD COLUMN IF NOT EXISTS outline_documentation_disabled TINYINT(1) NOT NULL DEFAULT 0 AFTER retired_note;

ALTER TABLE virtual_machines
  ADD INDEX IF NOT EXISTS idx_vm_outline_disabled (outline_documentation_disabled);

ALTER TABLE internal_services
  ADD COLUMN IF NOT EXISTS retired TINYINT(1) NOT NULL DEFAULT 0 AFTER active,
  ADD COLUMN IF NOT EXISTS retirement_reason_id BIGINT UNSIGNED NULL AFTER retired,
  ADD COLUMN IF NOT EXISTS retired_at DATE NULL AFTER retirement_reason_id,
  ADD COLUMN IF NOT EXISTS outline_documentation_disabled TINYINT(1) NOT NULL DEFAULT 0 AFTER retired_at;

ALTER TABLE internal_services
  ADD INDEX IF NOT EXISTS idx_internal_service_retired (retired,retired_at),
  ADD INDEX IF NOT EXISTS idx_internal_service_outline_disabled (outline_documentation_disabled);

INSERT IGNORE INTO nomenclature_categories(code,label,sort_order,active)
VALUES ('unsupported_os','Sisteme de operare nesuportate',90,1);

UPDATE nomenclature_categories
SET label='Sisteme de operare nesuportate',sort_order=90,active=1
WHERE code='unsupported_os';
