# Upgrade vm-doc-server 0.20.37 -> 0.20.38

Versiunea 0.20.38 este o versiune de corecție pentru publicarea Outline și rapoartele introduse în 0.20.37. Nu necesită update de vm-doc-agent.

## Corecții

- Repară `bad_request: unknown field ...outline_documentation_disabled` la salvarea bifei VM.
- Acceptă temporar și aliasul vechi/greșit `outlin_documentation_disabled`, pentru compatibilitate cu un JS rămas în cache.
- Repară HTTP 500 în **Rapoarte → Publicare Outline**.
- Repară HTTP 500 în **Rapoarte → Suport sisteme de operare**.
- Migrarea `061_outline_schema_repair.up.sql` verifică/recreează idempotent coloanele și indexurile Outline care trebuiau introduse de 058.
- Rapoartele verifică existența coloanelor înainte de interogare, astfel încât o schemă istorică incompletă nu mai produce 500.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.37 \
      /usr/local/src/vm-doc-server-0.20.38

tar -xzf vm-doc-server-0.20.38-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.38

cd /usr/local/src/vm-doc-server-0.20.38
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

La prima pornire se aplică automat migrarea 061. După restart folosește `Ctrl+F5`.

## Verificare rapidă

1. Pe un VM, bifează/debifează **Nu se publică în Outline** și salvează.
2. Deschide **Rapoarte → Publicare Outline**.
3. Deschide **Rapoarte → Suport sisteme de operare**.
4. Verifică în DB că `virtual_machines.outline_documentation_disabled` și `internal_services.outline_documentation_disabled` există.
