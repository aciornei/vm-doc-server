package server

import "testing"

func boolPtr(v bool) *bool { return &v }

func TestVMUpdateRequestOutlineCanonical(t *testing.T) {
	in := vmUpdateRequest{OutlineDocumentationDisabled: boolPtr(true)}.vcenterInput()
	if in.OutlineDocumentationDisabled == nil || !*in.OutlineDocumentationDisabled {
		t.Fatal("canonical Outline field was not propagated")
	}
}

func TestVMUpdateRequestOutlineLegacyAlias(t *testing.T) {
	in := vmUpdateRequest{OutlineDocumentationDisabledLegacy: boolPtr(true)}.vcenterInput()
	if in.OutlineDocumentationDisabled == nil || !*in.OutlineDocumentationDisabled {
		t.Fatal("legacy Outline field alias was not propagated")
	}
}

func TestVMUpdateRequestCanonicalWins(t *testing.T) {
	in := vmUpdateRequest{OutlineDocumentationDisabled: boolPtr(false), OutlineDocumentationDisabledLegacy: boolPtr(true)}.vcenterInput()
	if in.OutlineDocumentationDisabled == nil || *in.OutlineDocumentationDisabled {
		t.Fatal("canonical Outline field must win over legacy alias")
	}
}
