package server

import (
	"context"
	"net/http"
	"strings"
	"time"

	"vm-doc-server/internal/xlsx"
)

type outlinePublishVMRow struct {
	ID          int64  `json:"id"`
	Name        string `json:"name"`
	Hostname    string `json:"hostname"`
	Environment string `json:"environment"`
	Publish     bool   `json:"publish"`
	Reason      string `json:"reason"`
}

type outlinePublishServiceRow struct {
	ID               int64  `json:"id"`
	Name             string `json:"name"`
	Active           bool   `json:"active"`
	Retired          bool   `json:"retired"`
	DocumentationURL string `json:"documentation_url"`
	Publish          bool   `json:"publish"`
	Reason           string `json:"reason"`
}

type outlinePublishReport struct {
	GeneratedAt        time.Time                  `json:"generated_at"`
	IntegrationEnabled bool                       `json:"integration_enabled"`
	VMChart            []reportPoint              `json:"vm_chart"`
	ServiceChart       []reportPoint              `json:"service_chart"`
	VMs                []outlinePublishVMRow      `json:"vms"`
	Services           []outlinePublishServiceRow `json:"services"`
}

func (a *App) outlinePublishabilityReport(ctx context.Context) (outlinePublishReport, error) {
	out := outlinePublishReport{GeneratedAt: time.Now().UTC(), VMs: []outlinePublishVMRow{}, Services: []outlinePublishServiceRow{}}
	if a.Outline != nil {
		if settings, err := a.Outline.GetSettings(ctx); err == nil {
			out.IntegrationEnabled = settings.Enabled
		}
	}
	vmOutlineExpr := "0"
	if a.tableColumnExists(ctx, "virtual_machines", "outline_documentation_disabled") {
		vmOutlineExpr = "vm.outline_documentation_disabled"
	}
	rows, err := a.DB.QueryContext(ctx, `SELECT vm.id,vm.name,COALESCE(NULLIF(i.hostname,''),NULLIF(vm.guest_hostname,''),''),COALESCE(m.environment,''),`+vmOutlineExpr+` FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id WHERE vm.retired=0 ORDER BY LOWER(vm.name),vm.id`)
	if err != nil {
		return out, err
	}
	var vmYes, vmNo int64
	for rows.Next() {
		var row outlinePublishVMRow
		var disabled bool
		if err := rows.Scan(&row.ID, &row.Name, &row.Hostname, &row.Environment, &disabled); err != nil {
			rows.Close()
			return out, err
		}
		row.Publish = out.IntegrationEnabled && !disabled
		if !out.IntegrationEnabled {
			row.Reason = "Integrarea Outline este dezactivată global"
		} else if disabled {
			row.Reason = "Marcat «Nu se publică în Outline»"
		} else {
			row.Reason = "Configurat pentru publicare"
		}
		if row.Publish {
			vmYes++
		} else {
			vmNo++
		}
		out.VMs = append(out.VMs, row)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return out, err
	}
	rows.Close()
	serviceRetiredExpr := "0"
	if a.tableColumnExists(ctx, "internal_services", "retired") {
		serviceRetiredExpr = "retired"
	}
	serviceOutlineExpr := "0"
	if a.tableColumnExists(ctx, "internal_services", "outline_documentation_disabled") {
		serviceOutlineExpr = "outline_documentation_disabled"
	}
	srows, err := a.DB.QueryContext(ctx, `SELECT id,name,active,`+serviceRetiredExpr+`,COALESCE(documentation_url,''),`+serviceOutlineExpr+` FROM internal_services ORDER BY LOWER(name),id`)
	if err != nil {
		return out, err
	}
	defer srows.Close()
	var svcYes, svcNo int64
	for srows.Next() {
		var row outlinePublishServiceRow
		var disabled bool
		if err := srows.Scan(&row.ID, &row.Name, &row.Active, &row.Retired, &row.DocumentationURL, &disabled); err != nil {
			return out, err
		}
		switch {
		case !out.IntegrationEnabled:
			row.Reason = "Integrarea Outline este dezactivată global"
		case row.Retired:
			row.Reason = "Serviciu retras"
		case !row.Active:
			row.Reason = "Serviciu inactiv"
		case disabled:
			row.Reason = "Marcat «Nu se documentează în Outline»"
		case strings.TrimSpace(row.DocumentationURL) == "":
			row.Reason = "Fără Link documentație"
		default:
			row.Publish = true
			row.Reason = "Configurat pentru publicare"
		}
		if row.Publish {
			svcYes++
		} else {
			svcNo++
		}
		out.Services = append(out.Services, row)
	}
	if err := srows.Err(); err != nil {
		return out, err
	}
	out.VMChart = []reportPoint{{Label: "Se publică", Value: vmYes}, {Label: "Nu se publică", Value: vmNo}}
	out.ServiceChart = []reportPoint{{Label: "Se publică", Value: svcYes}, {Label: "Nu se publică", Value: svcNo}}
	return out, nil
}

func (a *App) reportsOutlinePublishability(w http.ResponseWriter, r *http.Request) {
	value, err := a.outlinePublishabilityReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, value)
}

func (a *App) exportReportOutlinePublishability(w http.ResponseWriter, r *http.Request) {
	value, err := a.outlinePublishabilityReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := [][]xlsx.Cell{{xlsx.Text("Tip"), xlsx.Text("Nume"), xlsx.Text("Hostname / Link"), xlsx.Text("Mediu / Stare"), xlsx.Text("Se publică în Outline"), xlsx.Text("Motiv")}}
	for _, v := range value.VMs {
		rows = append(rows, []xlsx.Cell{xlsx.Text("VM"), xlsx.Text(v.Name), xlsx.Text(v.Hostname), xlsx.Text(v.Environment), xlsx.Text(yesNo(v.Publish)), xlsx.Text(v.Reason)})
	}
	for _, s := range value.Services {
		state := "Activ"
		if s.Retired {
			state = "Retras"
		} else if !s.Active {
			state = "Inactiv"
		}
		rows = append(rows, []xlsx.Cell{xlsx.Text("Serviciu"), xlsx.Text(s.Name), xlsx.Text(s.DocumentationURL), xlsx.Text(state), xlsx.Text(yesNo(s.Publish)), xlsx.Text(s.Reason)})
	}
	if err := writeXLSXResponse(w, "Publicare Outline", "publicare-outline", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write Outline publishability XLSX", "error", err)
	}
}
