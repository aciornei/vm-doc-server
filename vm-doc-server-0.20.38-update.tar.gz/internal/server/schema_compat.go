package server

import "context"

func (a *App) tableColumnExists(ctx context.Context, tableName, columnName string) bool {
	var count int
	err := a.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?`, tableName, columnName).Scan(&count)
	return err == nil && count > 0
}
