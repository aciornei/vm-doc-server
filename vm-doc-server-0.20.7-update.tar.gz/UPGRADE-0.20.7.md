# Upgrade vm-doc-server 0.20.6 → 0.20.7

0.20.7 corectează paginarea tabelelor DOCX și mută documentația suplimentară a serviciului la final, ca anexă.

## Modificări

- rândurile lungi din tabelele fișelor VM și Serviciu se pot împărți între pagini;
- header-ele tabelelor rămân repetabile;
- documentația DOCX suplimentară a serviciului este anexată la final ca B1/B2/etc., după anexele A* ale fișelor VM;
- Markdown păstrează documentația suplimentară la final;
- fără migrare DB;
- fără modificări de agent sau collector.

## Upgrade offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.6 vm-doc-server-0.20.7
tar -xzf /cale/vm-doc-server-0.20.7-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.7
cd /usr/local/src/vm-doc-server-0.20.7
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Păstrați `vendor/`, `go.mod` și `go.sum` din arborele 0.20.6 care compilează deja în mediul offline; update-ul 0.20.7 nu le modifică.

După instalarea binarului nou, nu există migrare de bază de date.
