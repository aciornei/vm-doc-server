-- 0.19.16 · inventar software Windows și selecție aplicații principale

CREATE TABLE IF NOT EXISTS software_hosts (
  vm_id BIGINT UNSIGNED NOT NULL,
  current_inventory_id BIGINT UNSIGNED NULL,
  item_count INT UNSIGNED NOT NULL DEFAULT 0,
  observed_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (vm_id),
  KEY idx_software_hosts_inventory (current_inventory_id),
  CONSTRAINT fk_software_hosts_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_software_hosts_inventory FOREIGN KEY (current_inventory_id) REFERENCES inventory_snapshots(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS software_items (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  identity_hash CHAR(64) NOT NULL,
  name VARCHAR(512) NOT NULL,
  version VARCHAR(255) NOT NULL DEFAULT '',
  publisher VARCHAR(512) NOT NULL DEFAULT '',
  architecture VARCHAR(32) NOT NULL DEFAULT '',
  scope_name VARCHAR(255) NOT NULL DEFAULT '',
  kind VARCHAR(64) NOT NULL DEFAULT '',
  source VARCHAR(64) NOT NULL DEFAULT '',
  install_date VARCHAR(64) NOT NULL DEFAULT '',
  install_location VARCHAR(2048) NOT NULL DEFAULT '',
  state VARCHAR(64) NOT NULL DEFAULT '',
  system_component TINYINT(1) NOT NULL DEFAULT 0,
  present TINYINT(1) NOT NULL DEFAULT 1,
  is_primary TINYINT(1) NOT NULL DEFAULT 0,
  primary_selected_by BIGINT UNSIGNED NULL,
  current_inventory_id BIGINT UNSIGNED NULL,
  last_seen_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_software_item_identity (vm_id, identity_hash),
  KEY idx_software_items_vm_present (vm_id,present),
  KEY idx_software_items_vm_primary (vm_id,is_primary),
  KEY idx_software_items_inventory (current_inventory_id),
  CONSTRAINT fk_software_items_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_software_items_user FOREIGN KEY (primary_selected_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_software_items_inventory FOREIGN KEY (current_inventory_id) REFERENCES inventory_snapshots(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
