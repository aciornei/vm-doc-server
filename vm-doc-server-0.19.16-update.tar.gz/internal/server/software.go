package server

import (
	"errors"
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/xlsx"
)

type softwarePrimaryRequest struct {
	Primary bool `json:"primary"`
}

func (a *App) getVMSoftwareInventory(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	view, err := a.Software.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) setVMSoftwarePrimary(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	itemID, err := strconv.ParseInt(r.PathValue("software_id"), 10, 64)
	if err != nil || itemID < 1 {
		badRequest(w, errors.New("invalid software_id"))
		return
	}
	var input softwarePrimaryRequest
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Software.SetPrimary(r.Context(), vmID, itemID, user.ID, input.Primary); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "software.primary.set", "software_item", strconv.FormatInt(itemID, 10), "success", map[string]any{"vm_id": vmID, "primary": input.Primary})
	view, err := a.Software.GetVM(r.Context(), vmID)
	respond(w, view, err)
}

func (a *App) exportVMSoftware(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	view, err := a.Software.GetVM(r.Context(), vmID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := [][]xlsx.Cell{{xlsx.Text("Principal"), xlsx.Text("Prezent"), xlsx.Text("Nume"), xlsx.Text("Versiune"), xlsx.Text("Publisher"), xlsx.Text("Arhitectură"), xlsx.Text("Scope"), xlsx.Text("Tip"), xlsx.Text("Sursă"), xlsx.Text("Data instalării"), xlsx.Text("Locație"), xlsx.Text("Stare"), xlsx.Text("Componentă sistem")}}
	for _, v := range view.Items {
		rows = append(rows, []xlsx.Cell{xlsx.Text(yesNo(v.Primary)), xlsx.Text(yesNo(v.Present)), xlsx.Text(v.Name), xlsx.Text(v.Version), xlsx.Text(v.Publisher), xlsx.Text(v.Architecture), xlsx.Text(v.Scope), xlsx.Text(v.Kind), xlsx.Text(v.Source), xlsx.Text(v.InstallDate), xlsx.Text(v.InstallLocation), xlsx.Text(v.State), xlsx.Text(yesNo(v.System))})
	}
	if err := writeXLSXResponse(w, "Software instalat", "software-vm", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write software XLSX", "error", err)
	}
}
