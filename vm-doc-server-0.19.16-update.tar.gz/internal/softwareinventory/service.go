package softwareinventory

import (
	"bytes"
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

type Service struct{ DB *sql.DB }

type agentSoftwareInfo struct {
	Items []agentSoftwareItem `json:"items"`
}
type agentSoftwareItem struct {
	Name            string `json:"name"`
	Version         string `json:"version"`
	Publisher       string `json:"publisher"`
	Architecture    string `json:"architecture"`
	Scope           string `json:"scope"`
	Kind            string `json:"kind"`
	Source          string `json:"source"`
	InstallDate     string `json:"install_date"`
	InstallLocation string `json:"install_location"`
	State           string `json:"state"`
	System          bool   `json:"system"`
}

func (s Service) Sync(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, raw []byte) error {
	if tx == nil || vmID < 1 || inventoryID < 1 {
		return nil
	}
	var root struct {
		Software   json.RawMessage `json:"software"`
		Collection struct {
			Collectors map[string]struct {
				Status string `json:"status"`
			} `json:"collectors"`
		} `json:"collection"`
	}
	if err := json.NewDecoder(bytes.NewReader(raw)).Decode(&root); err != nil {
		return fmt.Errorf("decode software inventory envelope: %w", err)
	}
	if status, ok := root.Collection.Collectors["software"]; ok && !collectorStatusUsable(status.Status) {
		return nil
	}
	payloadRaw := bytes.TrimSpace(root.Software)
	if len(payloadRaw) == 0 || bytes.Equal(payloadRaw, []byte("null")) {
		return nil
	}
	var payload agentSoftwareInfo
	if err := json.Unmarshal(payloadRaw, &payload); err != nil {
		return fmt.Errorf("decode software inventory: %w", err)
	}
	now := time.Now().UTC()
	if _, err := tx.ExecContext(ctx, `INSERT INTO software_hosts(vm_id,current_inventory_id,item_count,observed_at) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE current_inventory_id=VALUES(current_inventory_id),item_count=VALUES(item_count),observed_at=VALUES(observed_at)`, vmID, inventoryID, len(payload.Items), now); err != nil {
		return fmt.Errorf("upsert software host: %w", err)
	}
	if _, err := tx.ExecContext(ctx, `UPDATE software_items SET present=0 WHERE vm_id=?`, vmID); err != nil {
		return err
	}
	for _, v := range payload.Items {
		if strings.TrimSpace(v.Name) == "" {
			continue
		}
		if err := upsertItem(ctx, tx, vmID, inventoryID, v, now); err != nil {
			return err
		}
	}
	return nil
}

func collectorStatusUsable(status string) bool {
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "success", "partial":
		return true
	default:
		return false
	}
}

func itemIdentity(v agentSoftwareItem) string {
	return strings.ToLower(strings.Join([]string{strings.TrimSpace(v.Name), strings.TrimSpace(v.Publisher), strings.TrimSpace(v.Architecture), strings.TrimSpace(v.Scope), strings.TrimSpace(v.Kind), strings.TrimSpace(v.Source)}, "|"))
}
func itemIdentityHash(v agentSoftwareItem) string {
	h := sha256.Sum256([]byte(itemIdentity(v)))
	return hex.EncodeToString(h[:])
}
func clean(v string, n int) string {
	v = strings.TrimSpace(v)
	if len(v) > n {
		return v[:n]
	}
	return v
}
func upsertItem(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, v agentSoftwareItem, now time.Time) error {
	_, err := tx.ExecContext(ctx, `INSERT INTO software_items(vm_id,identity_hash,name,version,publisher,architecture,scope_name,kind,source,install_date,install_location,state,system_component,present,current_inventory_id,last_seen_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),version=VALUES(version),publisher=VALUES(publisher),architecture=VALUES(architecture),scope_name=VALUES(scope_name),kind=VALUES(kind),source=VALUES(source),install_date=VALUES(install_date),install_location=VALUES(install_location),state=VALUES(state),system_component=VALUES(system_component),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`, vmID, itemIdentityHash(v), clean(v.Name, 512), clean(v.Version, 255), clean(v.Publisher, 512), clean(v.Architecture, 32), clean(v.Scope, 255), clean(v.Kind, 64), clean(v.Source, 64), clean(v.InstallDate, 64), clean(v.InstallLocation, 2048), clean(v.State, 64), v.System, inventoryID, now)
	return err
}

func (s Service) ensureCurrentSnapshot(ctx context.Context, vmID int64) error {
	if s.DB == nil || vmID < 1 {
		return nil
	}
	var inventoryID int64
	var raw []byte
	var normalized sql.NullInt64
	err := s.DB.QueryRowContext(ctx, `SELECT vm.current_inventory_id,i.raw_json,sh.current_inventory_id FROM virtual_machines vm JOIN inventory_snapshots i ON i.id=vm.current_inventory_id LEFT JOIN software_hosts sh ON sh.vm_id=vm.id WHERE vm.id=? AND vm.current_inventory_id IS NOT NULL`, vmID).Scan(&inventoryID, &raw, &normalized)
	if errors.Is(err, sql.ErrNoRows) {
		return nil
	}
	if err != nil {
		return err
	}
	if normalized.Valid && normalized.Int64 == inventoryID {
		return nil
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if err := s.Sync(ctx, tx, vmID, inventoryID, raw); err != nil {
		return err
	}
	return tx.Commit()
}

func (s Service) GetVM(ctx context.Context, vmID int64) (domain.SoftwareVMView, error) {
	out := domain.SoftwareVMView{Items: []domain.SoftwareItem{}}
	if s.DB == nil {
		return out, nil
	}
	if err := s.ensureCurrentSnapshot(ctx, vmID); err != nil {
		return out, err
	}
	var h domain.SoftwareHostSummary
	var inv sql.NullInt64
	var observed sql.NullTime
	err := s.DB.QueryRowContext(ctx, `SELECT vm_id,current_inventory_id,item_count,observed_at FROM software_hosts WHERE vm_id=?`, vmID).Scan(&h.VMID, &inv, &h.ItemCount, &observed)
	if err == nil {
		if inv.Valid {
			x := inv.Int64
			h.CurrentInventoryID = &x
		}
		if observed.Valid {
			x := observed.Time
			h.ObservedAt = &x
		}
		out.Host = &h
	} else if !errors.Is(err, sql.ErrNoRows) {
		return out, err
	}
	rows, err := s.DB.QueryContext(ctx, `SELECT id,vm_id,name,version,publisher,architecture,scope_name,kind,source,install_date,install_location,state,system_component,present,is_primary FROM software_items WHERE vm_id=? AND (present=1 OR is_primary=1) ORDER BY is_primary DESC,system_component,LOWER(name),architecture,scope_name`, vmID)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var v domain.SoftwareItem
		if err := rows.Scan(&v.ID, &v.VMID, &v.Name, &v.Version, &v.Publisher, &v.Architecture, &v.Scope, &v.Kind, &v.Source, &v.InstallDate, &v.InstallLocation, &v.State, &v.System, &v.Present, &v.Primary); err != nil {
			return out, err
		}
		out.Items = append(out.Items, v)
	}
	return out, rows.Err()
}

func (s Service) SetPrimary(ctx context.Context, vmID, itemID, userID int64, primary bool) error {
	if s.DB == nil {
		return errors.New("software inventory is unavailable")
	}
	result, err := s.DB.ExecContext(ctx, `UPDATE software_items SET is_primary=?,primary_selected_by=CASE WHEN ?=1 THEN ? ELSE NULL END WHERE id=? AND vm_id=?`, primary, primary, userID, itemID, vmID)
	if err != nil {
		return err
	}
	n, _ := result.RowsAffected()
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}
