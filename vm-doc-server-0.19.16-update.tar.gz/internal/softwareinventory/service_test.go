package softwareinventory

import "testing"

func TestItemIdentityIgnoresVersion(t *testing.T) {
	a := agentSoftwareItem{Name: "Example", Version: "1", Publisher: "Vendor", Architecture: "x64", Scope: "machine", Kind: "desktop", Source: "registry"}
	b := a
	b.Version = "2"
	if itemIdentity(a) != itemIdentity(b) {
		t.Fatal("identity must survive upgrades")
	}
}
func TestCollectorStatusUsable(t *testing.T) {
	if !collectorStatusUsable(" partial ") {
		t.Fatal("partial should be usable")
	}
	if collectorStatusUsable("unsupported") {
		t.Fatal("unsupported should not sync")
	}
}
