package domain

import "time"

type SoftwareHostSummary struct {
	VMID               int64      `json:"vm_id"`
	CurrentInventoryID *int64     `json:"current_inventory_id,omitempty"`
	ItemCount          int        `json:"item_count"`
	ObservedAt         *time.Time `json:"observed_at,omitempty"`
}

type SoftwareItem struct {
	ID              int64  `json:"id"`
	VMID            int64  `json:"vm_id"`
	Name            string `json:"name"`
	Version         string `json:"version,omitempty"`
	Publisher       string `json:"publisher,omitempty"`
	Architecture    string `json:"architecture,omitempty"`
	Scope           string `json:"scope,omitempty"`
	Kind            string `json:"kind,omitempty"`
	Source          string `json:"source,omitempty"`
	InstallDate     string `json:"install_date,omitempty"`
	InstallLocation string `json:"install_location,omitempty"`
	State           string `json:"state,omitempty"`
	System          bool   `json:"system"`
	Present         bool   `json:"present"`
	Primary         bool   `json:"primary"`
}

type SoftwareVMView struct {
	Host  *SoftwareHostSummary `json:"host,omitempty"`
	Items []SoftwareItem       `json:"items"`
}
