# Upgrade vm-doc-server 0.19.15 → 0.19.16

0.19.16 adaugă inventarul structurat de software instalat raportat de vm-doc-agent 1.7.2 și selecția persistentă a aplicațiilor principale pentru documentație.

## Noutăți

- VM → Inventar → **Software instalat** apare numai când agentul raportează date `software`;
- căutare și filtre după tip, arhitectură, publisher, prezență și marcaj Principal;
- export Excel al inventarului software;
- marcaj persistent **Principal** per aplicație;
- aplicațiile principale rămân vizibile chiar dacă ulterior nu mai sunt detectate;
- fișa VM include numai aplicațiile marcate Principal;
- migrare nouă `046_software_inventory.up.sql`;
- recomandat cu vm-doc-agent 1.7.2, schema 2.9.

## Upgrade

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.15 vm-doc-server-0.19.16
tar -xzf /cale/vm-doc-server-0.19.16-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.16
cd /usr/local/src/vm-doc-server-0.19.16
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

Migrarea 046 se aplică la pornirea serverului. După upgrade folosiți `Ctrl+F5`.

## Verificare

1. `/version` trebuie să raporteze `0.19.16`.
2. Actualizați un Windows la vm-doc-agent 1.7.2 și rulați **Colectează**.
3. În VM → Inventar trebuie să apară subfila **Software instalat**.
4. Marcați una sau mai multe aplicații ca **Principal**.
5. Regenerați fișa VM: trebuie să apară numai aplicațiile principale.
