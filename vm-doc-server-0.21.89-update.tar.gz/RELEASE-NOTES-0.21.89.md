# VM-DOC Server 0.21.89 — Remediere tabel Modificări / Release-uri

**Bază:** 0.21.88 · **Data:** 2026-10-23 · **Agent:** 1.7.18, neschimbat.

## Defecte confirmate
- Containerul rezultatelor păstra `class="loading"` după ce primea tabelul; `.loading` impunea padding suplimentar de 38–40px. Clasa este eliminată numai după încărcare, inclusiv pe caz de eroare.
- CSS-ul pentru VM modifica explicit fontul celulelor, selectoarelor și controalelor la 12px, iar lățimile coloanelor erau adesea prea mari. O politică comună stabilește 14px și width 100% fără minim artificial, inclusiv pentru De documentat.
- Unele containere încă puteau afișa scrollbar orizontal; stilurile finale folosesc tabel adaptiv și overflow controlat, inclusiv în interiorul detaliilor.
- Datele cronologice din Timeline au fost aliniate în dreapta coloanei stângi, aproape de axa verticală.
- `web/static/releases.json` omitea complet 0.21.85 și 0.21.86. Au fost reinserate cu informații bazate pe release notes reale; URL-ul JSON era încă `?v=0.21.23` și este acum `?v=0.21.89`.

## Compatibilitate
- Fără migrare SQL. Nu sunt afectate inventare, modificări istorice, baseline, revizii, documentări, bulk sau integrările externe.
- Frontend-ul și CSS sunt înglobate prin `go:embed`; trebuie recompilat serverul cu vendor local.

## Testare / limite
- Sintaxa JavaScript, JSON și Go independente verificate; test UI în Chromium cu ambele CSS ale aplicației, simulând răspunsuri de tabel și containerul `loading` inițial.
- Nu a fost testat build-ul complet cu vendor, nici execuția pe MariaDB/instalarea de producție.
