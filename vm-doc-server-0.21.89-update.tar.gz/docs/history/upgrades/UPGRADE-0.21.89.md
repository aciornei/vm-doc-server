# Upgrade 0.21.88 → 0.21.89

1. Backup pentru binar, config și MariaDB.
2. Oprește serviciul; aplică tar-ul incremental din rădăcina surselor 0.21.88 sau folosește sursele complete.
3. Verifică `bash scripts/cleanup-source-tree.sh --check`.
4. Compilează offline: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
5. Instalează binarul nou în locația reală `ExecStart` și repornește serviciul.
6. Verifică în browser `app.js?v=0.21.89`, `app.css?v=0.21.89` și lista Release-uri cu 0.21.85/86.
7. Modificări (global și VM), De documentat (global și VM): padding 0 după încărcare, 14px peste tot, fără scroll orizontal al tabelului.
8. Timeline: data și ora rămân în stânga axei, aliniate către ea.

**Rollback:** reinstalează binarul 0.21.88; fără rollback SQL. Agentul rămâne 1.7.18.
