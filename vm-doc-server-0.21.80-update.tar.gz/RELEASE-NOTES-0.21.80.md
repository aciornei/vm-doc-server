# VM-DOC Server 0.21.80 — Help Modificări și geometrie UI

## Schimbări
- Help la finalul paginii Modificări globale și fila VM: matrice 3×3 cu Documentație (Nesetat/Necesită/Nu necesită) și Stare (Nou/Revizuit/Documentat — ultima încă neimplementată). Explicită starea disponibilă „Ignorat”, criteriul de completitudine, efectele asupra VM și absența actualizărilor automate de fișe/Outline.
- Informațiile sunt derivate din codul actual: `inventorychanges.Service.Review` acceptă doar `new`, `reviewed`, `ignored`, iar criteriul de completitudine ia în calcul numai `required` cu `reviewed` pentru toate evenimentele necesare.
- Spațierea de sub căutare redusă; linia de feedback nu mai rezervă înălțime când este goală.
- Lupa din butonul de căutare este un SVG centrat geometric în mijlocul butonului, nu un caracter Unicode asimetric.
- Aceleași modificări de UX în pagina globală și fila VM.

## Ce NU se schimbă
- Nu se introduce încă starea `Documentat`. Implementarea viitoare va necesita definirea probelor, datei, persoanei și referinței documentare; etichetarea acum ca documentat ar fi înșelătoare.
- Nu se modifică filtrele, SQL-ul detectorului, baseline-urile, statuturile existente, API-ul, procentul VM sau permisiunile. Nicio migrare. Agentul rămâne 1.7.18.
- Testarea completă Go și integrarea pe MariaDB rămân pentru mediul cu `vendor/`.
