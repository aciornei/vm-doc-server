# Upgrade 0.21.79 → 0.21.80

1. Salvează configurația și sursele existente; upgrade-ul modifică numai UI și documentația.
2. Aplică pachetul incremental din rădăcina surselor 0.21.79 sau folosește arhiva source completă.
3. Verifică `bash scripts/cleanup-source-tree.sh --check` și compilează pe serverul offline cu `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
4. Salvează binarul instalat, oprește serviciul, copiază binarul nou conform `ExecStart` și repornește serviciul.
5. Verifică în browser `/static/js/app.js?v=0.21.80` și pagina Modificări: lupa centrată, help-ul cu matrice și spațierea.

**Rollback:** restaurează binarul 0.21.79; fără migrare SQL. **Nu există ștergere de evenimente.**
