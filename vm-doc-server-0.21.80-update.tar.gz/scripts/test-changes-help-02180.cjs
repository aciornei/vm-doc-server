const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const src=fs.readFileSync('web/static/js/app.js','utf8');
const start=src.indexOf('function changeWorkflowHelpHTML(){'),end=src.indexOf('function changesFilterHTML(',start);
assert(start>0 && end>start);
const cx=vm.createContext({});vm.runInContext(src.slice(start,end),cx);
const html=cx.changeWorkflowHelpHTML();
assert.equal((html.match(/<tr>/g)||[]).length,4); // header + 3 rows
assert.equal((html.match(/<td\b/g)||[]).length,9);
for(const doc of ['Nesetat','Necesită documentație','Nu necesită'])assert(html.includes(doc));
for(const state of ['Nou','Revizuit','Documentat (viitor)','Ignorat'])assert(html.includes(state));
for(const marker of ['baseline','Completitudine','revizuirea tuturor','rămâne salvat','Outline','nu o opțiune implementată','procentului VM'])assert(html.toLowerCase().includes(marker.toLowerCase()),marker);
assert(!src.includes('const changeReviewLabels={new:\'Nou\',reviewed:\'Revizuit\',documented:'));
assert(src.includes('function vmChangesSection(vmID)') && (src.match(/\$\{changeWorkflowHelpHTML\(\)\}/g)||[]).length===2);
assert(src.includes('id="changeSearchSubmit"')&&src.includes('aria-hidden="true" viewBox="0 0 24 24"'));
const css=fs.readFileSync('web/static/css/app.css','utf8');
assert(css.includes('.changes-search-feedback:empty{display:none!important'));
assert(css.includes('.changes-search-submit svg{display:block!important'));
console.log('PASS 0.21.80: nine help combinations, correct pending effects, no fake documented option, search icon');
