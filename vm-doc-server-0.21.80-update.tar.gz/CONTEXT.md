## VM-DOC 0.21.80 (2026-10-22)
- UI Modificări: help global/VM cu toate nouă combinații Nou/Revizuit/Documentat (ultima doar planificată), plus Ignorat. Efectele asupra completitudinii sunt descrise conform `internal/vcenter/vms.go`: doar `required`, toate `reviewed`. Nicio modificare de stare în DB.
- Căutare: spațiu vertical redus și lupă SVG centrată. Agent 1.7.18.

## VM-DOC Server 0.21.79 (2026-10-22)

Hotfix exclusiv pentru UI Modificări. Selector căutare compact, input lat, buton Caută, export Excel și toggle „⌄” la dreapta pentru filtrele avansate. Ajutor „i” interactiv la Documentație/Stare. Explicațiile detectorului și baseline-ului mutate sub registru, colapsate și distanțate. Rândul Detalii este edge-to-edge în tabel, fără border radius sus. Server 0.21.78 → 0.21.79, agent 1.7.18, nicio migrare sau API nou.

## VM-DOC Server 0.21.78 (2026-10-22)
- Cauză exactă rezolvată: callback-ul căutării returna referința loadGlobalChanges în loc să execute loadGlobalChanges(); Chrome confirmă acum apelul API la tastare.
- Căutarea globală pornește pe domeniul VM (nume sau hostname), dar permite Peste tot, Serviciu, Obiect. Confirmare la Enter/buton și debounce.
- Detector semantic și Baseline sunt colapsate implicit; Categorie, Tip, Documentație și Stare sunt grupate în Filtre avansate.
- Detalii păstrează rândul complet și folosește grilă ca la Securitate Firewall, cu rezumatul câmpurilor și diferențele anterior/nou.
- Export Excel pentru toate rândurile filtrate (maximum 20.000), nu doar pagina curentă; fără JSON brut sau referințe interne confidențiale.
- Nicio migrare SQL, nicio schimbare de agent și nicio modificare a comparației 1:1.

## 0.21.77 (2026-10-22) — UI Modificări și căutare servicii
- Detalii într-un rând pe toată lățimea; Documentație/Stare/Salvează rămân vizibile.
- Îndepărtare coloana Observații din UI; păstrare note vechi în PATCH.
- Căutare cu selector de domeniu VM/Serviciu/Obiect, buton Caută → și feedback; serviciile se caută și prin asocieri indirecte.
- Fără migrare SQL sau schimbări de agent; testat offline fără MariaDB reală.

## Actualizare 0.21.74 — Directory LDAP + OIDC-only UI

- Server **0.21.74** (22.10.2026). Auth LDAP separat de director: `auth.ldap.enabled=false` dezactivează loginul LDAP; `auth.ldap.directory.enabled=true` continuă importul responsabililor, persoanelor, OU/beneficiari folosind hosturi LDAP și cont tehnic.
- Login OIDC-only: text „Autentificați-vă folosind Keycloak.”, fără formular LDAP și fără separator. `GET /api/v1/auth/providers` expune `ldap`, `oidc`, `dev` distinct.
- Protecție directă în POST LDAP login dacă nici LDAP nici dev nu sunt disponibile. Fără migrare DB/agent.

## 0.21.73 — 2026-10-21 — Detector semantic pe domenii (Faza 1)

- Înlăturată restricția globală 0.21.72 pentru porturi TCP stabile, servicii OS nemarcate și reguli firewall explicite; păstrată normalizarea PID/workeri și regula confirmării.
- UDP, TCP/53/5353/5355, TCP 49152–65535 numai dacă portul este marcat Principal. Docker firewall rules generate rămân excluse.
- Guard `collection.collectors`: evenimente numai pentru colectări complete `success` (și fără truncation) în toate cele 3 snapshoturi; DB catalog/HBA/privilegii au protecții suplimentare pentru probe parțiale.
- Noi domenii în inventar de modificări: web ACL, DB utilizatori/privilegii/HBA, cron și software Win32/Windows features.
- **Etapa 2** FortiGate/Veeam/Prometheus central și **Etapa 3** „Documentat”/timeline încă neimplementate. Agent 1.7.18 neschimbat, fără migrare.
- Upgrade cumulativ **direct 0.21.71 → 0.21.73**; vechiul CLEANUP 0.21.72 dezactivat ca nesigur în noua politică. Instrucțiuni în `docs/UPGRADE-0.21.73.md`.

## 0.21.72 — 2026-10-21 — Politică STRICT globală pentru Modificări

- Porturi: numai Principal, cheie stabilă `protocol/port`; fluctuațiile de procese Postfix master/smtpd nu mai produc removed/added.
- Servicii: numai Componente suport; versiune / package_version / enabled_state.
- Firewall: în istoricul Modificări rămâne doar default_policies, nu fiecare regulă (toate regulile rămân în inventar).
- DB, Docker, Web, rețea, integrare: comparație strict semantică, nu runtime/detectare instabilă.
- **Confirmare de două colectări pentru toate categoriile**; nu doar pentru porturi. SQL manual PREVIEW/CLEANUP pentru zgomot istoric nerevizuit (firewall rules/servicii nemarcate/porturi nemarcate).
- Fără migrare, API sau agent nou; compilare offline și test MariaDB staging obligatorii. `docs/RELEASE-NOTES-0.21.72.md` explică compromisurile și regulile de siguranță.

## VM-DOC Server 0.21.71 (2026-10-21) — Noise systemd-fsck

- În `internal/inventorychanges/noise.go` se ignoră strict familia systemd-fsck (inclusiv `systemd-fsck@dev-disk-by\x2duuid-...service`, `systemd-fsckd.service`) la extragerea obiectelor de istoric, înainte de INSERT. Snapshoturile brute rămân complete.
- Motiv: la upgrade-ul pachetului systemd `255.4-1ubuntu8.17 → 255.4-1ubuntu8.18` se genera câte o modificare de `version`/`package_version` pentru fiecare disc.
- Alte servicii, inclusiv journald, pot semnala în continuare actualizări systemd. Istoricul fsck vechi se curăță numai manual cu scripturile SQL 0.21.71, după PREVIEW, backup și staging.
- Versiune server 0.21.71, agent 1.7.18, fără modificări API/migrare.

### 0.21.70 — Diagnostic MySQL/MariaDB [Note] din versiunea instanței (2026-10-21)

- Instanță MySQL din captura utilizatorului: `version` în formatul `261021 14:04:10 [Note] /usr/libexec/mysqld (mysqld 5.5.56-MariaDB) starting as process 59985 ...`. Patchul din 0.21.60 elimina `[Warning]` și `[Error]`, **nu** și mesajul datat `[Note]`; de aceea pe 0.21.69 persistau evenimente `database_instance modified`.
- 0.21.70 extrage `5.5.56-MariaDB` din forma exactă de startup datat, doar pentru instanțe `engine=mysql/mariadb`. Timestamp/PID diferit este ignorat înainte de INSERT; un upgrade adevărat la `5.5.57-MariaDB` este raportat.
- `scripts/preview-mysql-note-version-02170.sql` și `scripts/cleanup-mysql-note-version-02170.sql` șterg doar evenimente istorice `modified` unde old/new conțin loguri `[Note]` de startup cu aceeași versiune, celelalte câmpuri coincid, fără review/decizii/note. Backup + staging, nu automat; nu ating snapshots.
- Server 0.21.70; agent 1.7.18, fără migrare și schimbare de API. Full Go build + SQL MariaDB staging nevalidate în mediul curent.

### 0.21.69 — Docker iptables NAT MASQUERADE (2026-10-21)

- Versiunea 0.21.69 extinde detectorul din 0.21.68 pentru regulile automate Docker **iptables/ipv4/nat/POSTROUTING**, de forma `-A POSTROUTING -s 172.18.0.0/16 ! -o br-<12 hex> -j MASQUERADE`; ignoră numai aceste fluctuații în `inventory_changes` înainte de INSERT, menținând intact inventarul brut.
- SQL manual PREVIEW/CLEANUP din `scripts/*iptables-nat-docker-02169.sql` pentru zgomotul istoric deja salvat, fără atingere a evenimentelor revizuite, cu observații ori decizii. Fără migrare nouă, fără agent nou. Build offline cu `vendor/`, MariaDB și smoke test real trebuie validate în staging.

## Status curent 0.21.69 — iptables NAT Docker fără zgomot (2026-10-21)

Captura din interfața Modificări a arătat perechi added/removed pentru reguli `iptables` `nat/POSTROUTING`, ex. `-A POSTROUTING -s 172.19.0.0/16 ! -o br-f7410327c933 -j MASQUERADE`. Acestea NU sunt sintaxa nftables corectată în 0.21.60. Detectorul 0.21.69 ignoră exact acest șablon când sursa este CIDR complet RFC1918, bridge este `br-` + 12 hex și backend/family/table/chain sunt iptables/ipv4/nat/POSTROUTING. Documentația brută rămâne; schimbările NAT reale sunt urmărite. SQL targetat PREVIEW/CLEANUP este manual, doar `inventory_changes` cu `review_status=new`, `documentation_requirement=unset`, fără review-uri sau note. Build offline `vendor/` + staging MariaDB obligatorii. Server 0.21.69, agent 1.7.18.

## Status curent 0.21.68 — Arhivă VM & servicii BETA (2026-10-21)

Pe baza 0.21.67: UI Arhivă refăcut compact și responsive; marcaj BETA ca Hardening (panglică roșie), KPI clicabile, filtru Tip/Etapă, căutare, paginare cu page size și reset, tabel cu scroll orizontal și detalii expandabile. Semantica retragere/arhivare/reactivare, Audit și migrarea 081 rămân neschimbate. Rebuild Go obligatoriu pentru JS embed; agent 1.7.18.

## Status curent 0.21.67 — Arhivare VM și servicii (2026-10-21)

Migrare 081: `lifecycle_archives` și `lifecycle_archive_relations`; Arhivă separată de inventarul activ, tranziții controlate și audit la `vcenter.vm.unexpected_missing`. Agentul rămâne 1.7.18. Arhivarea este logică și manuală; `retention_until` nu execută purge. Snapshoturile directe VM–serviciu se păstrează la arhivare. Consultă `docs/RELEASE-NOTES-0.21.67.md`.

## 0.21.66 — 2026-10-21 — Corecție certă Docker / DB / Web
- Versiunea de bază: server 0.21.65, agent 1.7.18.
- Captura Chrome Console pe instalarea 0.21.65 a identificat clar `ReferenceError: vmResourceContexts is not defined` la `registerResourceEditor` în `web/static/js/app.js:4742`, apel din `vmDetail` pentru VM → Docker (și aceeași cale pentru DB/Web).
- Cauza: `vmResourceContexts.set` și `.get` existau dar variabila lipsea complet. Fix: `const vmResourceContexts=new Map();` definit la nivel de modul înaintea tuturor apelurilor.
- Smoke test Node pe funcțiile reale de registru pentru Docker, Databases, Web + izolare context VM. Nu se schimbă date sau API; singurul efect urmărit este deblocarea celor trei pagini și a configurării resurselor.
- Browser end-to-end și compilare full Go în staging offline cu vendor/ de verificat. Fără migrare SQL.

## Update 0.21.65 — 2026-10-21
## 0.21.65 — 2026-10-21 — Mediu din nomenclator și diagnostic `vmContext`
- Cele șase filtre de mediu de lângă Power (Agenți, Inventar VM, Backup, Monitorizare, raport OS suportat, raport publicare Outline VM) folosesc toate valorile nomenclatorului `environment`, inclusiv cele inactive marcate ca atare; la navigare, catalogul este încărcat din API și se invalidează după editarea nomenclatoarelor.
- Valoarea implicită rămâne Power ON + PROD (gruparea existentă), iar opțiunile custom filtrează exact numele din nomenclator prin `name:<label>` în API, inclusiv SQL parametrizat pentru liste și exporturi.
- `vmenv.Matches`, `vmenv.Predicate` și `vmenv.Normalize` suportă nume custom; raportul OS și Outline folosesc aceeași semantică în tabel și Excel. Teste de regresie pentru medii custom.
- `vmContext is not defined`: mesajul este raportat în UI cu sursa/linia/stack trace și markerul aplicației 0.21.65 pe VM → Docker/DB/Web. Simbolul nu există în sursele JS 0.21.64 și cauza exactă NU poate fi declarată rezolvată înainte de analiza stack trace-ului real.
- Fără migrare SQL, fără schimbări de agent; necesar build pe server cu `vendor/` și test MariaDB/browser.


## 0.21.63 (2026-10-21) — Arbore resource pool și Audit

- Peste 0.21.62, pool-urile din VCSA sunt afișate ierarhic după relația reală părinte/copil, cu popup aerisit, indentare, expand/collapse, selecție pe ramură și KPI de VM-uri excluse/pornite.
- Audit: pool selectat/deselectat cu numere VM; modificări de număr în pool-uri excluse; `vcenter.pool.vm_powered_on` pentru VM pornite, inclusiv neimportate, cu deduplicare între sincronizări.
- Migrare 080 aditivă: parent_moid și vcenter_pool_vm_audit_state; snapshoturi/fișe/Outline/Vault neatinse. Agent 1.7.18 neschimbat.
- Build integral vendor, MariaDB și VCSA 8.0.3 reale rămân de validat în staging.


## 0.21.62 (2026-10-21) — Filtru resource pool vCenter

- Sursa vCenter descoperă pool-uri prin `/api/vcenter/resource-pool`, asociază VM-urile prin `/api/vcenter/vm?resource_pools=...`; default toate selectate.
- Configurație per sursă (`vcenter_source_id`, MoRef), dashboard avertizare pentru `POWERED_ON` excluse.
- Noua migrare `079_vcenter_resource_pools.up.sql` adaugă tabela `vcenter_resource_pools` și două coloane în `virtual_machines`.
- VM-urile existente în pool-uri excluse nu sunt șterse, retrase sau marcate lipsă; sunt ascunse din lista normală, exportul VM și generarea/publicarea fișei VM. VM-urile noi excluse nu sunt create.
- Full Go build cu `vendor/` și integration testing VCSA/MariaDB rămân necesare. Agentul 1.7.18 neschimbat.

## Actualizare 2026-10-20 — VM-DOC Server 0.21.61 (livrare, instalare neverificată)

- Bază 0.21.60; normalizare versiuni Beats (`auditbeat`, `filebeat`, `metricbeat` și familie) în `inventory_changes` pentru banner lung vs numeric, cu verificare nume produs și `libbeat` identic. Integrare Auditbeat/Filebeat comparată identic.
- `package_version`, raw snapshots, configurații, documente, securitate și API neschimbate. Diferențele reale de versiune rămân evenimente.
- SQL PREVIEW/CLEANUP țintit, manual pentru evenimente istorice modificate exclusiv prin reprezentarea `version`, protecție review-uri/decizii/notițe.
- Agent 1.7.18 neschimbat, fără migrare SQL automată; build complet cu vendor și SQL staging de validat înainte de PROD.

## Actualizare 2026-10-20 — VM-DOC Server 0.21.60 (încă neinstalat/nevalidat PROD)

Optimizare `inventory_changes`: urmărește containere Docker numai după `name` și `image`/tag (digest/ports/networks/MAC/IP/Compose ignorate numai la compararea modificărilor), UDP numai Principal, diagnosticile MySQL `version` cu timestamp `[Warning]` ignorate și versiuni valide comparate, plus guard nftables nat POSTROUTING MASQUERADE limitat la source RFC1918 și bridge Docker br-12hex. SQL manual PREVIEW/CLEANUP țintit; protecție review-uri/decizii/notițe. Raw inventory și restul aplicației nemodificate. Bază 0.21.59; server 0.21.60 trebuie construit/testat cu vendor/ și pe MariaDB staging; agent 1.7.18 neschimbat.

# VM-DOC — Context de proiect

> **Scop:** document de continuitate între conversații ChatGPT și între release-uri ale proiectului VM-DOC.  
> **Actualizat:** 2026-10-21 (Europe/Bucharest), după pregătirea Server 0.21.64 și Agent 1.7.18.
> **Sursa informațiilor:** deciziile și livrările descrise în conversațiile despre VM-DOC. **Nu** reprezintă validare completă în mediul de producție; serverul 0.21.12 a fost raportat ca funcțional de utilizator; reorganizarea 0.21.13 necesită încă verificarea finală pe serverul cu vendor/.  
> **Fișier asociat:** `CHANGELOG.md` (istoric selectiv al modificărilor).

### 0.21.59 — iptables Docker raw/PREROUTING (2026-10-20)

- Continuare peste 0.21.58: captura din producție arată evenimente persistente în `inventory_changes` pentru reguli `iptables`, `family=ipv4`, `table=raw`, `chain=PREROUTING`, de exemplu `-A PREROUTING -d 172.18.0.7/32 ! -i br-f392b3fbdb12 -j DROP`; la recrearea rețelei, bridge-ul trece la `br-87894e600741`, rezultând `removed/added`. Filtrul vechi acoperea `nftables`, nu această sintaxă iptables.
- Server 0.21.59 filtrează strict și noua formă: doar destinație IPv4 privată /32, br-12hex, lanț/tabel/raw/backend exacte, DROP fără condiții suplimentare. Nu modifică raw agent JSON, regulile generale, DOCKER-USER, alte politici ori documentația. Agent 1.7.18 rămâne.
- SQL PREVIEW/CLEANUP **țintit** pentru `firewall|rule|iptables|ipv4|raw|PREROUTING|...`, cu protecție a rândurilor revizuite, a deciziilor și a notelor; nu rulează automat, nu reprezintă auditul operațional, rollback numai din backup.
- Teste Go locale pentru detector trecute; build-ul complet offline cu `vendor/` și testele SQL pe MariaDB reală rămân necesare. Distinge release pregătit de instalarea efectivă.

### 0.21.56 — Porturi Apache + nftables Docker (2026-10-20)

- Bază de pornire efectivă: **0.21.55 source.zip**. Server 0.21.56 filtrează înainte de INSERT în `inventory_changes` două fenomene confirmate de capturi: (1) `TCP/443 apache2` adăugat/eliminat simultan deoarece cheia folosea numele fiecărui proces/worker; acum lista este deduplicată înainte de cheia portului; (2) reguli `nftables` `ip daddr 172.18.0.x iifname != "br-<12hex>" counter drop` regenerate la refacerea bridge-ului Docker, filtrate strict doar când IP este RFC1918, bridge-ul este hex, rule este exact această gardă, iar chain nu e DOCKER-USER.
- **SQL opțional cumulativ** 0.21.50–0.21.56: previzualizare și ștergere manuală cu review/decii/notițe protejate; perechi false port cu același `vm_id/inventory_id/object_label/JSON` și chei diferite; guard-uri Docker nftables. Nu eliminăm regula explicită `DOCKER-USER`, nici întreg nftables; nu atingem `inventory_snapshots`.
- Teste unitare Go pentru listener key stabil și firewall selective; compilarea integrală cu vendor și testarea SQL pe MariaDB reală NU sunt încă confirmate. Agent 1.7.18 neschimbat, API, migrarea, Outline/Vault neschimbate. Fișierele de release nu confirmă instalarea pe server.

### 0.21.50 — Politica de zgomot pentru `inventory_changes` (2026-10-20)

- Serverul se bazează pe sursele complete **0.21.49**, furnizate la 20.10.2026. Modulul `internal/inventorychanges` a fost extins cu `noise.go` (filtrare înainte de INSERT) și teste noi.
- Porturi TCP/UDP 49152–65535: evenimente omise **dacă portul VM nu este marcat Principal** (`vm_primary_agent_ports`); porturile rămân în snapshotul brut. Excepția de protecție este la nivel de protocol+port indiferent de numele procesului.
- Pentru firewall se ignoră numai lanțurile generate UFW non-user, DOCKER non-USER, CNI, kube, libvirt în nftables/iptables; `ufw-user`, `DOCKER-USER` și reguli direct administrate sunt păstrate. Acest set conservator poate necesita rafinare după observarea evenimentelor din PROD.
- În istoria schimbărilor, nu în inventarul brut, ignoră serviciile efemere `user@`, `user-runtime-dir@`, `lxd-installer@`; exclude `active_state`/`sub_state`, sonde runtime NTP și teste/transiențe Beat; păstrează schimbări de versiune, enabled-state și config relevant.
- Curățarea istorică se face **manual** după backup, cu `scripts/preview-inventory-changes-cleanup.sql`, apoi `scripts/cleanup-inventory-changes.sql`; SQL protejează rândurile revizuite/cu note și nu atinge `inventory_snapshots`. **Nicio curățare nu a fost executată pe DB de producție** în acest chat.
- Agentul **1.7.18** este compatibil, fără refacerea sa; fără schema migration automată sau API schimbat. Full Go test/build cu vendor și verificare SQL MariaDB reală rămân de executat pe staging/producție. Versiunea artefactului livrat nu confirmă instalarea.

### 0.21.51 — Rafinare zgomot de servicii (2026-10-20)

- Peste server 0.21.50: filtre în `internal/inventorychanges/noise.go` pentru instanțele **Windows per-user** cunoscute cu `_hex` (listă explicită), și `lxd-installer@N-N-N.service`; fără excludere generică a serviciilor terțe.
- Mesajele diagnostice `[Warning]` și `[Error]` din versiunile colectate ale serviciilor sunt îndepărtate exclusiv din semnătura folosită la calculul schimbărilor; păstrăm versiunile reale și snapshotul brut.
- Preview/cleanup SQL manual 0.21.51 cumulează filtrele 0.21.50 și noile familii; protejează evenimentele cu review/decizii/notes; nu a fost executat pe MariaDB-ul utilizatorului.
- Release 0.21.51 bazat pe **sursele 0.21.50 efectiv disponibile**; Agent 1.7.18 fără update; fără migrare automată/API nou. Full Go build cu vendor și SQL real rămân de verificat.

### 0.21.52 — Porturi fără fluctuații false (2026-10-20)

- Peste 0.21.51, `internal/inventorychanges/service.go`: compară trei inventare consecutive pentru evenimentele de port și emite numai tranzițiile prezente în două colectări succesive; pentru celelalte categorii comparația rămâne imediată. Fără migrare/API nou.
- Probleme observate: `TCP/80 apache2` apare adăugat și eliminat în aceeași secundă în istoric; snapshoturile brute rămân intacte. Filtrarea nu exclude TCP/80, ci doar schimbările neconfirmate.
- Scripturile preview/cleanup SQL manuale 0.21.52 repară identificarea cheilor firewall generate și extind regulile 0.21.51 cu eliminarea perechilor opuse identice per VM/obiect/JSON în 10 minute, excluzând evenimente cu review, decizii sau observații. Necesită backup și staging; nu executăm DELETE automat.
- Testele unitare Go `internal/inventorychanges` trec; build integral cu vendor/MariaDB reală necesită verificare. Agent 1.7.18 compatibil și nemodificat.

### 0.21.53 — Filtru pentru interfețe Linux veth efemere (2026-10-20)

- Versiune incrementală peste **server 0.21.52**, bazată pe sursele reale; **Agent 1.7.18** neschimbat. În `internal/inventorychanges/noise.go` este un matcher strict `^veth[0-9a-f]{5,}(@if[0-9]+)?$`; `extractTracked` omite interfețele potrivite numai din istoricul schimbărilor, nu din snapshoturile brute.
- NIC-urile persistente (`eth/ens`, `bond`, `vlan`, `docker0`, `br-*`, nume veth explicite) și schimbările MAC/IP/MTU/DNS rămân urmărite. Interfețele configurate manual cu nume `veth...` care seamănă exact cu numele generate aleator pot fi excluse, de verificat înainte de rollout.
- `scripts/preview-inventory-changes-cleanup.sql` și `scripts/cleanup-inventory-changes.sql` sunt **cumulative 0.21.50–0.21.53**, au grupul `interfete_veth_efemere` și păstrează review-urile, deciziile de documentare și notele. Necesită backup, server oprit și probă în staging. Nu rulează automat.
- Build complet Go cu `vendor/` și integrare MariaDB reală de verificat pe serverul offline. Nu afirma instalare în producție fără confirmare.

### 0.21.55 — Nume descriptiv Windows SCM (2026-10-20)

- Release incremental **Server 0.21.54 → 0.21.55**, agent 1.7.18 neschimbat. `Win32_Service.Name` este identitatea stabilă; agentul raportează `Win32_Service.DisplayName` ca `software_name` și `manager=windows_scm`.
- Pentru `windows_scm` detectorul nu mai compară `software_name`: exemple `wuauserv`/`Windows Update` și `workfolderssvc`/`Work Folders`. Se păstrează comparația `name`, `manager`, `enabled_state`, `version`, `package_name`, `package_version`; adăugările/eliminările reale rămân. Nu se aplică pentru Linux/systemd/sysv sau manager neidentificat.
- **Numai istoric de modificări**, nu inventar brut `inventory_snapshots`, serviciile afișate, export/documentare, API. PREVIEW/CLEANUP cumulativ 0.21.50–0.21.55 extinde curățarea pentru modificări `software_name`-only Windows SCM. Protejează `review_status != new`, `documentation_requirement != unset`, `reviewed_at` și observațiile manuale. SQL manual după backup și preview complet; niciun DELETE automat/migrare SQL nouă.
- Teste Go pentru oscilații, schimbări reale și scope manager; Full Go test/build cu vendor și SQL MariaDB staging rămân obligatorii pentru PROD.

### 0.21.54 — Completare filtru Windows per-user services (2026-10-20)

- Release incremental **server 0.21.53 → 0.21.54**, agent **1.7.18** fără schimbare. Capturi reale arată zgomot `P9RdrService_b6809/_31c5b23`, `NPSMSvc_*`, `DeviceAssociationBrokerSvc_*` (added/removed la schimbarea sufixului). Cele trei nume sunt adăugate pe allowlist-ul `windowsPerUserFamilies` din `internal/inventorychanges/noise.go`. Patternul de sufix hexadecimal de 5–12 caractere rămâne neschimbat.
- Normalizarea afectează **exclusiv detectorul de modificări** (nu inventarul brut, nu lista serviciilor, nu monitorizarea). Serviciile omonime fără sufix și alte nume necunoscute nu sunt filtrate.
- PREVIEW/CLEANUP cumulativ 0.21.50–0.21.54 extind regula pentru Windows per-user; review-urile, deciziile de documentare și observațiile rămân protejate. Backup obligatoriu, SQL manual, staging înainte de PROD. Nu există migrare automată.
- Build complet Go cu vendor și MariaDB reală rămân de verificat înainte de rollout. Verifică în 2–3 zile dacă alte familii noi de servicii Windows apar în zgomot; nu extinde generic regexul la orice `*_hex`.

## 1. Rezumat operațional pentru următorul chat

VM-DOC este o aplicație internă pentru inventarierea, documentarea și analiza mașinilor virtuale și serviciilor IT. Are **server central Go**, **agenți multiplatformă**, aplicație web și integrări cu surse de infrastructură. Generează documentație **DOCX / PDF / Markdown** și publică selectiv în **Outline**.

### Versiuni și statut cunoscut

| Componentă | Versiune / reper | Stare și observații |
|---|---|---|
| Server VM-DOC | **0.21.50** | Filtru zgomot inventar + curățare SQL explicită după backup; porturi dinamice ne-Principale, instanțe efemere, runtime NTP/servicii/integrări și lanțuri firewall generate. Fără update agent, API sau migrare automată; validare MariaDB în staging necesară. |
| Server VM-DOC | **0.21.49** | Hartă rețea: în Sursă/Destinație se afișează `VM(IP)` apoi `Obiecte FortiGate:` separat; antete laterale explicite, porturi VM mai aerisite, padding nota Interpretare. SVG exportat este construit separat, cu toate obiectele și VM-urile, fără Extinde/Restrânge, casete albe și denumiri complete pe linii; UI rămâne compactă și paginată. Fără SQL/API/agent; Chromium mock și Node OK; build complet cu vendor/MariaDB/FortiGate real de confirmat. |
| Server VM-DOC | **0.21.48** | Hartă rețea: policy cu servicii/porturi verticale sub #număr; obiectele/IP-urile revin în nodurile Sursă/Destinație fără titluri redundante, cu Extinde/Restrânge și paginare bounded pentru sute de obiecte; eticheta generică Port ascultat eliminată din VM; spațiu lateral îmbunătățit, săgeți mai mici. Păstrează selectarea interactivă și exportul SVG. Exclusiv UI și metadate; Agent 1.7.18, fără SQL/API nou; Chromium mock, build complet offline/staging neconfirmat. |
| Server VM-DOC | **0.21.47** | Hartă rețea: opt KPI într-un rând compact desktop, VM central 274px, policy afișează numai numărul, noduri sursă/destinație fără repetarea numelor, săgeți mici și highlight bidirecțional port ↔ flux ↔ policy/sursă/destinație. Fără SQL/API/agent; staging obligatoriu. |
| Server VM-DOC | **0.21.46** | Hartă rețea: scroll în diagramă, fără lățirea paginii sub meniul stâng; VM central de 180 px, distanțe reduse; fluxuri FortiGate cu valori verticale și expandare; secțiuni tehnice DECLARAT/OBSERVAT/PERMIS și Fluxuri corelate colapsabile independent. Fără SQL/API/agent, testarea integrală în staging necesară. |
| Server VM-DOC | **0.21.45** | Hardening: profil aplicat + Salvează în al treilea card de lângă Profil de evaluare / Scor; Export Excel în dreapta antetului Controale evaluate; marcaj BETA roșu în colțul din dreapta sus pentru VM, raport și nomenclator, explicații detaliate la finalul conținutului. Strict UI/metadate, fără SQL/API/agent; Chromium mock 1595/1024/390/350, JS și Go independent OK; compilare completă cu vendor și MariaDB în staging. |
| Server VM-DOC | **0.21.44** | UI Hardening/Securitate reorganizat: BETA vizibil, 4 indicatori compacți, filtre exclusiv pe pagina curentă după VM/OS/profil și stare, tabele de rezultate expandabile, acțiuni în antet. VM/Nomenclatoare Hardening marcate BETA. Firewall: sortarea generică dezactivată în tabele FortiGate/Local pentru a elimina săgeata rătăcită. Exclusiv UI/docs/versiune; Agent 1.7.18, fără SQL/API nou. Sintaxă JS, teste Go independente și browser mock 1595/1024/390/350 OK; vendor build/MariaDB reale neconfirmate. |
| Server VM-DOC | **0.21.43** | Hotfix exclusiv UI Firewall: FortiGate/Local în stânga pe același rând cu KPI-urile din dreapta; progresul Revizuite X din Y aliniat la dreapta cu padding; Policy # aliniat vertical în celulă. Responsive 1595/1366/1024/390/350 verificat cu date simulate. Fără schimbări SQL/API/agent; build complet offline și staging MariaDB de verificat. |
| Server VM-DOC | **0.21.42** | UI Firewall: două carduri FortiGate/Local; Export și Revizuiește în antet; Policy # expandabil cu detalii sub rând, fără coloană Detalii; 3 coloane Revizuit/De/Next review pentru reguli Forti/Local; progres revizuite x din y în Firewall, DB Users/Grants/HBA și Web ACL. Fără SQL/API/agent; testare Chromium simulată, build complet offline și MariaDB reală de verificat. |
| Server VM-DOC | **0.21.41** | Firewall: FortiGate/Local și Filtre unificate, Export Excel și Revizuiește secțiunea permanent disponibile pe VM, policy # scurt, interfețe/servicii pe rânduri, detalii corelare expandabile, cards max-width și scroll doar în tabel fără coliziune cu meniul. API aditiv pentru citirea/exportul regulilor locale și revizii individuale/colective Forti/local. Fără SQL sau agent nou (1.7.18). Chromium mock 1595/1024/390/350, Go module independente; build complet/vendor, MariaDB, export și review real în staging necesare. |
| Server VM-DOC | **0.21.40** | Web Access Control: Filtre unic în loc de export/revizie separate, ambele butoane permanent vizibile, chevron dreapta-sus, căutare generală și bifă Doar cele cu ACL în zona colapsată. Global revizia colectivă impune VM ales, VM detail filtrează cardurile local. Numai JS/CSS + metadata; fără DB/API/agent; Agent 1.7.18. Chromium mock 1595/1024/390/350 OK; build complet cu vendor/staging necesare. |
| Server VM-DOC | **0.21.39** | Web Access Control: site-urile cu ACL pe primul loc, extinse; fără ACL colapsate și un singur indicator; review individual în summary. Export XLSX server-side global/per VM cu Site-uri și Reguli ACL; endpoint GET /api/v1/security/web/export. Fără migrare SQL, agent 1.7.18 neschimbat. Teste JS/Chromium simulate și Go independente OK; build complet vendor/MariaDB real de confirmat. |
| Server VM-DOC | **0.21.38** | UI: dialog bulk cu footer fix / confirmare vizibilă și checkbox compact; Grants pe principal, numai grupurile tehnice la expandare, cu Revizuiește în antet. Exclusiv JS/CSS și metadate; fără migrare/API/agent. Teste browser cu date simulate, build complet vendor/MariaDB de verificat. |
| Server VM-DOC | **0.21.37** | Optimizare memorie Chrome/Securitate: `GET /api/v1/security?section=` selectează overview/accounts/databases/web, cu sumar global dar fără inventarele celorlalte categorii; endpoint vechi fără `section` și `vm_id` compatibile. Grants DB randat doar la activarea filei, subgrupurile granturilor sunt eliminate la restrângere, cache-ul DB curățat între pagini, cache VM limitat la 16 intrări și expirat la fiecare acces; căutare granturi fără concat temporar masiv. Nu schimbă inventarul/reviziile/API implicit/Excel, nu are migrare SQL ori update Agent 1.7.18. Mock Chromium 20k/40 users 1595/1024/390 și teste Go independente OK; profilare Chrome real, build complet cu vendor, MariaDB necesare. |
| Server VM-DOC | **0.21.36** | Database Access: Revizuiește secțiunea separat în Users, Grants (per principal+host), HBA (per regulă), cu păstrarea reviziei individuale; MySQL fără tab HBA. Grants grupate pe user + detalii secundare randate progresiv în loturi de 200 la extindere, pentru 20.000+ granturi. Export Excel global sau per VM cu Users/Grants/HBA (1–3 sheets) și toate granturile. Tipuri noi `database_grants`/`database_hba`, chei validate pe inventarul curent, bulk cu instance_id obligatoriu, calendar revizii actualizat. Fără SQL nou, agent 1.7.18. Teste Chromium simulate și Go independente OK; `vendor/` + MariaDB/test E2E neconfirmate. |
| Server VM-DOC | **0.21.35** | UI Database Access: header instanță, 3 zone (Users/Roles, Grants, Conectare/HBA), roluri/privilegii afișate câte 4 + expand, granturi grupate fără pragul 500 (toate detaliile disponibile), ascundere roluri interne `pg_*` NOLOGIN doar din Securitate/rapoarte, păstrate raw. Revizuire colectivă VM/instanță pentru Conturi, DB principals, Web ACL cu endpoint atomic, confirmare, audit și RBAC; review individual păstrat. Nu există migrare SQL; Agent 1.7.18. Teste browser/mock și Go independente OK; build complet/vendor și MariaDB neconfirmate. |
| Server VM-DOC | **0.21.34** | Review de securitate compact: trei coloane reale Revizuit / De / Next review în tabele, date/ore pe un singur rând și data reviziei verde; nerevizuite = doar buton Revizuiește într-o celulă colspan=3; popup cu numele VM și contul/resursa. Doar JS/CSS/metadate, fără SQL/API/Agent; teste Chromium simulate 1595/1024/390 și Go independente OK, build complet offline/vendor și staging neverificate. |
| Server VM-DOC | **0.21.33** | Revizii securitate: în coloana Review apar pe rând Revizuit, De către, Next review și buton; dialog unic fără prompt/confirm pentru Conturi/DB/Web ACL/Firewall/rapoarte, cu 6/12 luni, justificare și observații; numele revizorului este salvat server-side. La deschiderea panoului Conturi system apare imediat tabelul, fără checkbox. Doar UI; fără SQL/API/agent; testare Chromium simulată și Go module independente, build complet cu vendor de confirmat. |
| Server VM-DOC | **0.21.32** | Securitate VM: Politica parolelor colapsabilă, indicatori verticali compactați lângă tabel; Conturi relevante permanent vizibile; Conturi system colapsabile, fără Review; padding nota Rezumat. Database Access cu review per principal, cheie stabilă instanță+nume+host+database și raport central actualizat. API/Swagger nou `database_principal`; fără migrare SQL sau agent nou; build server complet/vendor și MariaDB reală neverificate. |
| Server VM-DOC | **0.21.31** | UI Securitate: layout comun de 16px desktop / 14px mobil în Dashboard, Conturi VM, Database Access, Web Access Control, Firewall (Caută/Surse/Analiză) și Hardening. Filtrele paginilor Conturi/DB/Web/Firewall/Analiză sunt colapsabile cu selecțiile active + resetare vizibile și căutare permanent accesibilă, folosind ID-urile/controlerele existente. Fără API/SQL/agent nou; validare Chromium cu date simulate, build complet `vendor/` neconfirmat. |
| Server VM-DOC | **0.21.30** | Uniformizare geometrie Docker/DB/Web: container comun `.vm-resource-layout`, gap 16px între blocuri desktop (14px mobil), padding lateral panouri/filtre 20px (16px mobil). Eliminat cumulul de margini din CSS vechi. Exclusiv UI; fără SQL/API/agent nou. Teste browser cu markup reprezentativ și teste Go independente; staging cu date reale rămâne necesar. |
| Server VM-DOC | **0.21.29** | Beneficiarii instanțelor DB agregați din bazele logice fără duplicare și fără mesaj permanent de încărcare; dată/oră două rânduri numai în tabele, altfel un rând; Web cu filtre colapsabile 8 controale + rezumat/resetare și servere detectate extensibile. Fără migrare SQL/API/agent. Chromium 1595/1024/390 și teste Go module independente OK; `vendor/` și MariaDB reală neverificate. |
| Server VM-DOC | **0.21.28** | Baze de date UI în stil Docker: filtre colapsabile, opt opțiuni, rezumat selecții, resetare, stare/engine și păstrare opțiuni; Engine-uri detectate extensibil, joburi PG (inclusiv KPI și coloana) afișate numai când există. Fără SQL/API/agent; teste Go module disponibile și Chromium simulat 1595/1024/390; build complet/vendor neconfirmat. |
| Server VM-DOC | **0.21.27** | Docker Compose: căi director/fișiere YAML cu copiere; beneficiari multipli prin popup la nivel VM+proiect (migrarea `078`), propagare calculată către containere, VM, servicii, componente; filtre Docker colapsate 4/linie, stare container și selecții vizibile; liste Images/Networks/Volumes una sub alta. Agent 1.7.18 neschimbat. Teste JS, API simulat Chromium și pachete Go independente; build complet/vendor și MariaDB reală neverificate. |
| Server VM-DOC | **0.21.26** | Infrastructură: eliminat blocajul de randare pentru listă agenți, conexiuni externe și inventarul software; panourile neactive nu se mai construiesc inutil. Beneficiari: numele evidențiate distinct în Operațional. Fără SQL nou / modificări agent. |
| Server VM-DOC | **0.21.25** | Hotfix eroare `.length` la Infrastructură; RPO 1440 / RTO 240 în UI/API și SQL migrarea 077 numai pentru NULL/înregistrări lipsă (valori configurate inclusiv zero păstrate); Beneficiari evidențiați, titlu Observații nedublat. Agent 1.7.18 neschimbat; build complet/vendor și MariaDB reală neverificate local. |
| Server VM-DOC | **0.21.24** | Configurare → Operațional: doar Observații, valorile URL/tichet vechi sunt păstrate intern; Rezumat trimite doar spre Outline; Inventar VM: sortare SQL globală pe coloanele tabelului și export; Infrastructură: navigare imediată și încărcare amânată a dovezilor de completare. Fără SQL nou sau agent. |
| Server VM-DOC | **0.21.23** | Aliniere panouri Configurare VM la lățimea navigării; formular HA cu margini interne și acțiuni aerisite; butoane Servicii/Încadrare despărțite de Observații. Numai UI CSS, fără SQL/API/agent. |
| Server VM-DOC | **0.21.22** | Rezumat VM reorganizat 4×2 cu Beneficiari și responsabilități separate; linkurile Outline/Vault aliniate; KPI 174px pentru viewport 1595; eliminare falsă dublare MySQL/MariaDB cu dovadă și fără instanță MySQL reală. Fără migrare/agent nou. |
| Server VM-DOC | **0.21.20** | UI: toate cele 7 carduri de rezumat VM (listă și fișă) folosesc clasa comună `ui-kpi-seven`, dimensiuni compacte constante și breakpoints; chevron filtre centrat. Fix regresie 0.21.18, fără migrare/API/agent. |
| Server VM-DOC | **0.21.19** | Hotfix OpenAPI/Swagger peste 0.21.18: eliminate rutele dublate `/api/v1/people` și `/api/v1/people/{id}`; păstrate definițiile complete. Test Go pentru unicitatea rutelor în paths și versiune și versiune. Fără migrare sau agent nou; rebuild necesar pentru `go:embed`; build server complet neverificat local. |
| Server VM-DOC | **0.21.18** | Inventar VM: maximum 4 servicii pe celulă + Extinde/Restrânge, bară de filtre cu selecții vizibile/reset/săgeată, 3 carduri noi (Pornite, Publicare Outline, medie completare) și toate cardurile clickabile. API vms cu numere și medie pe toate rezultatele filtrate; `published` și `sort`. Fără migrare; agent 1.7.18 neschimbat. |
| Server VM-DOC | **0.21.17** | Corecții UI VM-uri: doar Căutare/Power vizibile, 8 filtre pliabile cu 4/linie desktop, carduri compacte, dată/oră pe două rânduri, coloanele Publicare/Outline clarificate, meniuri sticky lipite de topbar. Fără migrare SQL/API/agent; validare staging necesară. |
| Server VM-DOC | **0.21.16** | Uniformizare UI transversală cu navigare grupată, meniu mobil, spațiere și formulare/tabele/dialoguri; fără migrare SQL, API sau agent. Backlog Wazuh/Shell în `docs/TODO.md`; validare cu date reale necesară. |
| Server VM-DOC | **0.21.15** | Pachet cu migrarea 076 și motor Hardening configurabil: benchmarkuri, reguli, profiluri Draft/Publicat/Arhivat, clonare, import/export JSON, API/Swagger; testare staging necesară, build server complet neverificat local. Agent 1.7.18 neschimbat. |
| Server VM-DOC | **0.21.14** | Curățare structură peste 0.21.12: UPGRADE/RELEASE-NOTES/VERIFICATION în `docs/history/`, script `scripts/cleanup-source-tree.sh` cu dry-run/--apply/--check, arhivare copii vechi imbricate în afara arborelui Go, verificare pre-build în Makefile. Fără migrare SQL, API/Swagger, agent sau schimbare a logicii de inventar. Build complet cu vendor/ de confirmat. |
| Server VM-DOC | **0.21.12** | **Hotfix Go peste 0.21.11:** `internal/server/hardening.go` `updateHardeningProfile` folosește `_, err =` deoarece `err` era deja definit; în 0.21.11 compilarea eșua cu `no new variables on left side of :=`. Fără migrare, schimbare API sau agent. Testul integral cu `vendor/` trebuie confirmat pe server. |
| Server VM-DOC | **0.21.11** | **Hotfix compilare peste 0.21.10.** În `internal/server/hardening.go` au fost eliminate trei rezultate `sql.Result` neutilizate; modificarea nu schimbă logica Hardening, schema DB, Swagger sau agentul. `go test ./internal/... ./cmd/...` și `make build` trebuie confirmate offline cu `vendor/` pe serverul utilizatorului. |
| Server VM-DOC | **0.21.10** | Nomenclator 25 reguli interne hardening, 6 profiluri OS (Ubuntu 20/22/24, Debian 12, Windows Server 2019/2022), asociere CIS versionată/pending până la validare, motor read-only, raport Excel și Swagger, migrarea `075`. Teste `internal/hardening`, JS/OpenAPI trecute; build server complet/MariaDB reale **neverificate**. Instalare neconfirmată. |
| Server VM-DOC | **0.21.9** | **Pachet de actualizare și surse pregătite în această sesiune** peste 0.21.8. Migrarea `074` adaugă originea Docker/nativ și metadatele MongoDB Replica Set per instanță; UI/API/Swagger/XLSX actualizate. Testele Go limitate la `databaseinventory`, `domain`, `xlsx`, JS și OpenAPI; compilarea completă și MariaDB reală rămân neverificate. **Nu este confirmată instalarea în producție.** |
| Server VM-DOC | **0.21.8** | Bază de upgrade, cu excluderea centralizată Db2 configurabilă și migrarea `073`. |
| Agent modern | **1.7.18** | Schema inventar `2.13`, probe read-only Linux SSH/sysctl/permisiuni și Windows UAC/SMBv1/NLA; binare Linux/Windows amd64/386 compilate, teste Go offline trecute; legacy neschimbate. Test pe OS real neconfirmat. |
| Agent modern | **1.7.17** | Pachet unic modern+legacy+surse, 13.10.2026. Linux/Windows amd64/386 compilate, teste Go offline trecute. MongoDB 4.4 SECONDARY: `setSecondaryOk()` și `getDBs()`; PostgreSQL Docker: `POSTGRES_USER`/`POSTGRES_DB` din mediul containerului (fără parole); timeout Docker DB 15 s (5–60 configurabil); MariaDB/MySQL: diagnostic client/autentificare. Testare reală post-upgrade încă necesară. |
| Agent modern | **1.7.16** | Arhiva `vm-doc-agents-all-2026-10-13-v1.7.16-with-source.zip` există și include Linux amd64/386, Windows amd64/386, sursele Go și patch 1.7.15→1.7.16. Teste și build offline raportate; **instalarea pe VM-uri nu este confirmată**. |
| Agent modern | **1.7.15** | Pachet anterior, sursele Go reconstruite din 1.7.12 + patch-uri 1.7.13/14/15; compatibil cu serverul 0.21.9 (fără metadate Docker/Replica Set noi). |
| Agent SLES9 legacy | **1.0.1** | Variantă separată pentru SLES9, schema inventar menționată `2.9`; binarul legacy nu trebuie presupus recompilat odată cu 1.7.16. |
| Agent Windows legacy | **1.0.2** | Ramură legacy separată; verifică exact ce build-uri suportă XP/Windows vechi și existența surselor. |
| Agent Windows XP | **reper 1.0.1** | Menționat în istoricul legacy; versiunea pachetului efectiv folosit trebuie verificată în arhive. |

**Regulă de lucru:** distinge mereu între **cerință**, **implementare raportată**, **arhivă livrată**, **build/test executat**, **instalare efectivă** și **validare în producție**. Nu crește versiunea doar din discuție.

### UI Securitate — 0.21.35

- În Securitate → Database Access, fiecare instanță are titlu VM / produs / instanță și trei panouri comutabile: Users/Roles, Grants, Conectare/HBA. Până la 4 roluri/privilegii server sunt pe linii separate cu expand pentru restul; granturile sunt grupate fără eliminarea/limitarea obiectelor originale.
- Rolurile PostgreSQL predefinite `pg_*` cu `NOLOGIN` nu se afișează în Securitate și calendarul reviziilor; `access_json`/colectarea agentului păstrează toate valorile. Rolurile NOLOGIN custom rămân vizibile și revizuibile.
- Revizia colectivă este explicit per VM (sau per instanță DB) pentru **conturile relevante, principalii DB, vhost-urile Web**. Endpoint `PUT /api/v1/security/review/bulk` cu RBAC `vms.manage` și CSRF; serverul enumeră obiectele din inventarul curent și salvează atomic aceeași decizie. Necesită observații 10–2000 caractere și confirmarea suprascrierii reviziilor existente. Butonul individual rămâne independent. Alte VM-uri și conturile system neeligibile nu sunt revizuite implicit.
- Validări locale: Chromium date simulate la 1595/1024/390 cu 2.000 grants, modal bulk cu payload verificat; node --check și Go pe pachete fără dependențe externe. `internal/server` complet nu a putut fi compilat fără dependențele `vendor/`; validare MariaDB + staging obligatorie.

### UI Securitate — 0.21.34

- În tabelele Conturi VM, Database Access, Web ACL, Firewall și alte ecrane care refolosesc componenta `securityReviewCell`, „Review” este înlocuit de 3 coloane separate: **Revizuit**, **De**, **Next review**. Data și ora apar pe aceeași linie, ultima revizie verde; butonul rămâne în zona ultimei coloane.
- Pentru un element încă nerevizuit și un operator autorizat apare numai **Revizuiește**, cu celulă `colspan=3`. Pentru rândurile fără review aplicabil, `—` ocupă aceleași trei coloane. Panourile fără tabel folosesc un grid compact, nu noi coloane HTML.
- Dialogul afișează VM-ul după nume și contul/resursa selectată, fără a expune date secrete; dacă numele lipsește în context, folosește endpointul existent de VM. Salvarea, RBAC și auditul rămân server-side, nemodificate.
- Nu se adaugă un nou MutationObserver global; împărțirea coloanelor rulează după fiecare randare care atașează acțiunile de revizie. `CONTEXT.md` documentează un release **generat**, nu instalarea sa.
- Pachete de livrare: `vm-doc-server-0.21.34-release.zip`, `-source.zip`, `-update.tar.gz`, `0.21.33-to-0.21.34.patch`, plus notes/context/changelog/TODO/SHA256. Nu includ dependențele `vendor/` sau binare server Go; se recompilă cu vendor-ul local.
- Validare efectuată: JavaScript sintactic; Playwright/Chromium 1595/1024/390 cu scenarii revizuit/nerevizuit/fără review, popup VM+cont; Go: OpenAPI/Web/Buildinfo/Domain/XLSX/Migrations. **De confirmat:** build complet cu vendor/, MariaDB și staging real.

### UI Securitate — 0.21.31

- Layout comun `.security-workspace` pentru Dashboard, Conturi VM, Database Access, Web ACL, Firewall/Caută, Firewall/Surse & Sync, Firewall/Analiză și Hardening: blocuri aliniate și distanțate unitar (16 px desktop, 14 px mobil), filtre/panouri cu padding lateral uniform.
- Filtrele Conturi, DB Access, Web Access, Firewall/Caută și Analiză Forti folosesc helperii `securityFilterShell()` / `bindSecurityFilterShell()`: căutare afișată permanent, panou secundar colapsabil, selecții active vizibile în rezumat, resetare; max. 4 controale/rând desktop, 2 tabletă, 1 mobil. Starea deschis/închis rezistă reafișării filtrării.
- ID-urile elementelor și handler-ele de paginare, review, resetare, căutare și filtre rămân neschimbate. Fără modificări ale drepturilor RBAC, ale sincronizării FortiGate, ale datelor, API-ului și bazei de date. OpenAPI are doar versiunea schimbată.
- Verificat local: `node --check`, teste Go module independente (OpenAPI/Web/Buildinfo/Domain/XLSX/Migrations), Chromium 1595/1024/390 cu date simulate, extindere și închidere filtre, geometrie și lipsa overflow-ului. Build complet offline cu `vendor/` și test pe server real rămân de verificat.

### Performanță Infrastructură și UI beneficiari — 0.21.26

- `vmDetail` / Infrastructură desenează panourile principale după răspunsul VM, fără a aștepta `/api/v1/agents`, inventarul software sau sursele/conexiunile externe. Selectul agentului este dezactivat până la încărcarea listei, păstrând agentul deja asociat; conexiunile externe sunt introduse asincron doar în panoul aferent. Răspunsurile întârziate sunt ignorate dacă utilizatorul a trecut în alt tab/VM.
- `vmDetail` construiește doar panoul tabului activ pentru zonele costisitoare. Inventarele Docker/DB/Web și beneficiarii rămân în fetch-ul asincron de completare atunci când se deschide Infrastructură; procentul afișat nu este aproximat.
- Operațional → Beneficiari: numele departamentelor/persoanelor sunt vizibil îngroșate și subliniate, iar sursa AD/manual are contrast redus; restul paginilor nu sunt modificate.
- Fără migrare sau modificare a API-ului; Agent 1.7.18. Teste browser cu răspunsuri simulate; performanța reală a endpointului VM se măsoară după instalare.

### Corecții VM — 0.21.25

- Infrastructură: bugul `Cannot read properties of undefined (reading 'length')` venea din `vmCompletionHTML` invocat pentru un obiect de completare incomplet când `infrastructureFast=true`. `overview` este construit doar la secțiunea Rezumat, iar cardul Completare din Infrastructură se actualizează asincron numai după obținerea dovezilor Docker/DB/Web și a beneficiarilor.
- RPO/RTO: 1440/240 minute implicit; migrarea `077_vm_operational_defaults.up.sql` modifică DEFAULT-urile SQL, înlocuiește strict valorile NULL și adaugă exclusiv rândurile lipsă în `vm_operational_metadata` pentru VM-uri. Orice valoare nenulă, inclusiv 0, este păstrată. API-ul de citire și salvarea operational folosesc aceleași valori în absența unor setări; formularul afișează defaulturile.
- Operațional: cardul Beneficiari are fundal discret și titlu subliniat; Observații are un singur titlu vizibil și etichetă accesibilă invizibilă.
- Test browser Chromium 1595, 1024, 390 px cu date simulate trece pentru deschiderea Infrastructură fără excepție, valorile RPO/RTO și elementele Operațional. `go test` pentru pachetele fără dependențe externe reușește; build complet și migrare pe MariaDB sunt de confirmat. Agentul rămâne 1.7.18.

### Ajustări UI / API — 0.21.24

- **Operațional**: secțiunea finală conține doar Observații; URL-ul documentației și referința tichet nu mai sunt editabile în interfață. Valorile istorice sunt retransmise la salvare pentru a nu fi golite accidental. În Rezumat, URL-ul Documentație este exclusiv cel al paginii Outline asociate (dacă există). Vault rămâne doar în VM-DOC.
- **Inventar VM**: `sort=key:asc|desc` pentru VM, vCenter, Power, CPU/RAM, OS, IP, Agent, Servicii, Publicare, data Outline, Completare și data ultimului inventar; whitelist de expresii SQL cu criteriu secundar stabil. Sortarea se aplică pe tot setul filtrat înainte de paginare și este preluată de exportul Excel; `completion_asc` rămâne acceptat.
- **Infrastructură VM**: navigarea și starea de încărcare sunt afișate imediat. Pentru secțiune nu mai blocăm afișarea pe cele trei inventare separate Docker/DB/Web și beneficiari: ele se încarcă asincron pentru calculul completării. Procentul temporar nu este prezentat ca 0%; este afișat după finalizarea datelor. Nu modifică modelul VM sau datele inventarului.
- **Teste locale**: `node --check`, Go OpenAPI/Web/Buildinfo, teste SQL sortare izolate și Chromium 1595/1024/390 pentru antete (sortare asc/desc, revenire pagina 1) trecute. **Build complet cu vendor și măsurare timp real pe server neconfirmate.**

### Ajustări UI specifice — 0.21.20

- Regula de design: **șapte carduri KPI de aceeași dimensiune**, într-un singur rând când lățimea o permite. Clasele reutilizabile `ui-kpi-seven` și setul de dimensiuni sunt aplicate în lista VM și în fișa unui VM. Pentru paginile noi cu șapte carduri se folosește aceeași clasă. Nu se lățesc la 4 carduri pe un rând.
- În bara VM filtre, săgeata chevron este centrată geometric în rând, iar `Resetează` rămâne în dreapta; mobilul folosește două rânduri.
- 0.21.20 este corecție exclusiv UI peste 0.21.19; TODO Wazuh/SSH nemodificat.

### Ajustări UI specifice — 0.21.18

- Tabel VM / Servicii: primele patru nume vizibile; `+N · Extinde` / `Restrânge` prezintă lista întreagă fără a ascunde datele din server.
- Bara filtre secundare: text „Filtre:” cu selecții vizibile sau „Niciun filtru activ”, buton Resetează și chevron pentru cele 8 filtre; Căutare și Power rămân deasupra.
- 7 carduri sumar clickabile: Rezultate (resetează), Pornite, Publicare Outline (publicate efectiv, `ovmoutline.last_synced_at IS NOT NULL`), Completare generală (media gradului de completare, click pentru ordonare crescătoare), Prezente în vCenter, Lipsă din vCenter, Cu agent asociat.
- Cardurile folosesc aceleași filtre cu tabelul. API `GET /api/v1/vms`: agregate `powered_on_count`, `outline_published_count`, `completion_average_percent` calculate în SQL înainte de `LIMIT/OFFSET`; `published=yes|no`, `sort=completion_asc`; documentație OpenAPI actualizată.
- Procentele de completare individuale și media utilizează aceeași expresie SQL, nealterată semantic. Nu s-a introdus migrare SQL/agent; testele complete Go cu vendor și MariaDB rămân necesare în staging.
- Wazuh și Shell SSH prin Vault rămân **amânate** în `docs/TODO.md`.

### Ajustări UI specifice — 0.21.17

- Lista VM: Căutare VM + Power vizibile, restul de 8 filtre în `<details>`; patru controale pe rând la desktop, responsive la ecrane mici.
- Cardurile sumar din lista VM au dimensiune redusă, ca în rezumat VM.
- Formatterul de dată `dt()` generează markup cu data și ora pe două rânduri în UI, în fusul `state.timezone`; elementele lipsite de timestamp arată `—`.
- În tabelul VM, coloana de eligibilitate Outline a devenit „Publicare”; cea cu ultima sincronizare/publicare a devenit „Outline”.
- Topbar-ul este măsurat dinamic pentru navigarea sticky; nu mai are `top: 78px` sau `82px` fix pe aceste componente.
- Wazuh și Shell prin Vault rămân în `docs/TODO.md` ca funcții amânate, fără schimbări.

### Direcția curentă — UI și funcții amânate (0.21.16)

- S-a decis **pauzarea** extinderii Hardening/CIS proprii; modulul actual rămâne un baseline pentru mașinile fără Wazuh. Nu se implementează colectori CIS compleți în această etapă.
- **TODO Wazuh:** integrare viitoare read-only API pentru agenți, SCA/CIS și ulterior vulnerabilități; corelare cu VM/servicii/beneficiari, scor Wazuh separat de baseline VM-DOC.
- **TODO Shell SSH:** acces interactiv din fișa VM prin backend, chei gestionate în Vault, RBAC, audit sesiune, fără expunerea secretelor browserului; proiect amânat pentru review de securitate.
- Plan activ: uniformizare vizuală toate paginile, urmată de ajustări punctuale. `docs/TODO.md` păstrează criteriile de reluare; `docs/UI-REVIEW-0.21.16.md` acoperă inventarul paginilor.
- Server 0.21.16 schimbă doar HTML, JS navigare, CSS, documentație, VERSION și releases.json; fără migrare/Go/agent.
- Teste Chromium simulate pe 1440/1024/390 px, sintaxă JS/JSON, pachet embed Go; **fără testare end-to-end cu backend MariaDB real și fără build complet Go cu vendor**.

### Hardening extensibil — 0.21.15

- Nomenclatoare → Securitate → Hardening: benchmarkuri metadata, bibliotecă de reguli și profiluri OS sau componentă; utilizatorul poate crea profiluri noi fără release Go dacă dovada/check_key există deja.
- Profil nou Draft; se atașează reguli, publică și se salvează snapshotul de revizie; profilul publicat este structural imuabil (clonează pentru schimbări). Excepție: administratorul poate actualiza separat referințele CIS validate intern.
- Operatori configurați din allowlist, fără comenzi arbitrare; dovezile lipsă sunt unknown, nu conforme.
- Profilurile Apache, Nginx, MariaDB, MySQL, PostgreSQL, MongoDB și Docker sunt șabloane **Draft**. Evaluarea per instanță tehnică necesită colectori ulteriori; nu declara conformitate pentru acestea.
- Migrare aditivă `076`; referințe CIS individuale pending până la verificare; fișiere istorice în `docs/history/`.
- Testat: `internal/hardening`, `internal/domain`, `internal/xlsx`, JS, OpenAPI și smoke Chromium cu API simulat; **build complet Go cu vendor și MariaDB reală lipsesc**. Serverul 0.21.15 nu este confirmat instalat.

### Hardening intern — 0.21.12 (bază) / 1.7.18; 0.21.13 curățare structură

- Decizie: **numai controale proprii VM-DOC**, fără rulare/import CIS-CAT și fără a pretinde certificare CIS.
- Nomenclator: 25 reguli interne (`LIN-*`, `WIN-*`), 6 profiluri L1 interne; profilele rețin numele și versiunea benchmarkului CIS relevant și linkul oficial.
- Mapările exact numerotate `recommendation_id` și `control_id` sunt **pending** până la verificare de administrator pentru versiunea exactă; status `reviewed` înseamnă *verificat intern*, nu oficial. **Nu inventa ID-uri CIS.**
- Rezultate: `pass`, `fail`, `unknown`; un `unknown` nu este conform și reduce scorul intern. Reguli cu metodă manuală rămân `unknown` până la extindere.
- Agent 1.7.18 colectează exclusiv evidențe read-only în `hardening.evidence` (schema 2.13). Linux: `sshd -T`, sysctl IPv4, drepturi `/etc/shadow`; Windows: chei registry UAC/SMB1/RDP NLA. Nu colectează valori secrete, nu modifică setările și nu execută remedieri.
- Server 0.21.10: migrare SQL `075`, meniuri Nomenclatoare/Securitate/fișă VM, raport și export Excel, API/Swagger cu drepturi separate. Scorurile sunt derivate din ultima colectare; agenții legacy pot avea multe valori necunoscute.
- Validare: unit teste agent/server engine, build-uri agent și sintaxă UI/OpenAPI; **lipsesc încă build complet server cu `vendor`, teste MariaDB și teste e2e**.
- Nu modifica linkurile Vault sau politica de publicare Outline în această versiune. Înainte de rollout: backup MariaDB și test staging.

**Incident hotfix 0.21.12:** în 0.21.11 la linia 176, `_, err :=` producea `no new variables on left side of :=` deoarece err fusese declarat înainte. Corectat la `_, err =` în 0.21.12; celelalte două instrucțiuni pot păstra `:=`. Compilarea finală cu `vendor/` rămâne de verificat pe server.

**Incident hotfix 0.21.11:** compilarea 0.21.10 a eșuat cu trei variabile `res/result` declarate și nefolosite în `internal/server/hardening.go`, confirmat de utilizator prin `go test`. Codul 0.21.11 folosește `_` pentru rezultatele SQL neutilizate; nu se presupune că orice altă eroare Go este rezolvată fără compilare completă pe server cu `vendor/`. Evită surse vechi imbricate în proiect când rulezi `go test ./...`.


### Organizarea surselor (0.21.13)

- Fișierele UPGRADE/RELEASE-NOTES (și verificările istorice) au fost mutate din rădăcina serverului în `docs/history/{upgrades,release-notes,verification}/`. Index: `docs/history/INDEX.md`.
- La extragerea arhivei update TAR peste 0.21.12 trebuie rulat `bash scripts/cleanup-source-tree.sh --dry-run`, apoi explicit `--apply`; TAR nu șterge automat vechile fișiere de la rădăcină.
- Scriptul arhivează proiecte Go vechi imbricate în **afara** folderului curent, nu le șterge. Nu atinge `vendor/`, `migrations/`, configurațiile sau datele runtime.
- Înainte de `make test`/`make build`, `Makefile` verifică structura și explică remedierea dacă există surse vechi imbricate.
- Nu se schimbă funcțiile serverului, migrarea 075, Swagger sau Agent 1.7.18. `go test ./...` și build cu vendor pe server trebuie reconfirmate.

### Revizii de securitate la nivel de principal DB — 0.21.32

- În VM → Securitate → Baze de date, review-ul se face individual pe principal (utilizator/rol), nu se mai aplică implicit întregii instanțe.
- Identitatea review-ului `database_principal` conține ID instanță DB și hash SHA-256 după nume, host și context DB; schimbarea privilegiilor nu schimbă cheia. API-ul verifică prezența principalului în snapshotul curent înainte de salvare.
- Review-urile istorice `resource_type=database` nu sunt șterse, dar nu sunt interpretate ca review pentru fiecare utilizator din instanță. În raportul central fiecare principal este reper separat; când inventarul nu conține principali, fallback-ul vechi pe instanță rămâne vizibil.
- Conturile system fără login/privilegii/parolă relevantă nu solicită review; conturile relevante păstrează review-ul individual. `CONTEXT.md` rămâne stare curentă, iar istoricul versiunilor este în `CHANGELOG.md`.
- Verificările browser au fost efectuate cu date simulate; `GOPROXY=off go test ./...` și `make build` necesită `vendor/` pe serverul offline; verificarea cu MariaDB reală este obligatorie înainte de producție.

### Database Access 0.21.36 — decizie de granularitate

- **Users** = principal DB individual; **Grants** = grup de granturi pe principal+host dintr-o instanță; **HBA** = regulă specifică de conexiune (fișier/linie/condiții). Cele trei revizii sunt independente și operația bulk cere confirmare/observații și poate suprascrie valorile individuale vizate.
- Granturile nu trebuie randate toate simultan: se grupează per utilizator, apoi privilegii/scope/schema, obiectele se încarcă lazy câte 200. Exportul XLSX păstrează toate 20.000+ înregistrări, nu doar cele încărcate în browser. Workbook poate avea 1–3 sheet-uri Users/Grants/HBA, HBA doar PostgreSQL.
- Cheile persistente sunt hash-uite și validate contra inventarului curent, după VM + instanță + principal/host (Grants) sau după regula HBA completă inclusiv fișier/linie. Schimbarea regulii poate cere o nouă revizie; re-colectarea unui grant nou într-un grup deja revizuit NU expiră automat review-ul — de verificat procedural.
- Fără migrare SQL, agent nou ori efect asupra Vault/Outline. Staging obligatoriu pentru API bulk/export și 20.000+ granturi reale; build offline cu vendor/ încă neconfirmat.

### Hardening — stare BETA și UI (0.21.44)

- Ecranul **Securitate → Hardening** păstrează calculul read-only din ultimul snapshot și paginarea backend; afișează explicit **BETA · în validare**. Afișarea „Neverificat” nu înseamnă conform, iar referințele CIS au caracter intern, nu certificare.
- Layout comun Securitate: patru KPI compacte (**total VM**, **VM pe pagină**, **reguli neconforme pe pagină**, **neverificate pe pagină**), acțiuni în antetul tabelului și detalii per VM în panou extensibil. Search/stare filtrează numai VM-urile deja încărcate **pe pagina curentă**; nu se confundă cu filtrarea pe întregul inventar.
- BETA este afișat și în fișa VM/Hardening și în nomenclatorul de profiluri; profilurile Draft/Publicat/Arhivat, motorul de calcul, datele istorice și exportul rămân neschimbate.
- În Firewall, tabelele FortiGate/Local cu rânduri expandabile au `data-sortable=false` pentru a elimina iconița de sortare izolată; sortările explicite din alte pagini nu sunt modificate.
- Validare locală: Node syntax, Go OpenAPI/Web/Buildinfo/Domain/XLSX/Migrations și scenarii Chromium 1595/1024/390/350 cu API simulat. În staging rămân obligatorii Go complet cu `vendor/`, MariaDB și ecranul pe date reale.

## 2. Scop și arhitectură

- **Server central:** aplicație Go, acces web/API; stochează inventarul, configurațiile, relațiile VM–serviciu–componentă și datele din integrări.
- **Agent instalat pe VM:** colectează informații locale, inclusiv versiuni software și componente, fără dependență obligatorie de internet.
- **Infrastructură:** import și corelare cu vCenter; integrare cu Veeam, Prometheus și FortiGate; autentificare enterprise LDAP/AD și OIDC/Keycloak; integrare cu Outline.
- **Documentare:** fișă individuală VM, fișă de serviciu, componente suport; documentele rezultate pot fi publicate în Outline în limitele politicii PROD.
- **Operare offline:** pachetele de release trebuie să poată fi transferate și instalate în rețele fără acces la internet, cu surse, instrucțiuni și hash-uri.

Flux conceptual:

```text
VM-uri (Linux / Windows / legacy)
          |
       Agenți  -----> Inventar sistem, servicii, rețea, Web/DB/Docker,
          |           porturi, conturi, politici, integrare
          v
   Server central VM-DOC <---- vCenter / Veeam / Prometheus / FortiGate
          |
          +-- UI / filtre / rapoarte / API / export Excel
          +-- DOCX / PDF / MD
          +-- Outline (numai resurse eligibile, fără date Vault)
          +-- Securitate / Conturi VM / dependențe / beneficiari
```

### Configurație server exemplificată anterior

Aceste valori sunt **repere istorice**, nu configurație verificată curentă:

```yaml
listen: "0.0.0.0:9080"
trusted_proxies: ["127.0.0.1"]
allowed_networks: ["172.20.0.0/16"]
vcenter:
  allow_http: false
  request_timeout: "60s"
  detail_workers: 8
  scheduler_interval: "1m"
```

Nu transforma valorile exemplificative în instrucțiuni de producție fără verificarea configurației reale. **Nu introduce parole, tokenuri, secrete sau linkuri Vault în acest fișier.**

## 3. Agenți: platforme, colectori, actualizare

### Platforme avute în vedere

- Linux `amd64` și `386` — distribuții curente și vechi: Ubuntu, Debian, CentOS, RHEL, SUSE/SLES.
- Windows `amd64` și, în funcție de build, `386`; Windows XP/legacy necesită ramuri/toolchain distincte.
- **SLES9** — agent legacy separat, deoarece mediul este foarte vechi.
- Compatibilitatea fiecărui binar trebuie verificată cu release manifest; nu echivala lista de platforme cerute cu o matrice de binare finalizate.

### Colectori și arii de inventariere

`system`, `storage`, `network`, `services`, `listening_ports`, `firewall`, `accounts`, `sssd`, `integrations`, `policies`, `cron`, `ntp`, precum și inventarierea Web/DB/Docker și a componentelor software, potrivit suportului pe platformă.

### Reguli importante

- Identificarea agenților trebuie să evite coliziunile `agent_id` după clonarea VM-urilor.
- La agentul modern 1.7.15, mecanismul de refresh a fost schimbat: **POST refresh → ACK**, urmat de **GET** server-side pentru inventarul unic.
- Pentru Linux vechi (ex. CentOS 7/systemd 219), ține cont de compatibilitatea instalării/systemd și de faptul că un bootstrap manual poate fi necesar.
- **Releases:** diferențiază agent modern de `sles9-legacy`, XP și `windows-legacy`; nu distribui un executabil modern ca înlocuitor presupus compatibil pentru legacy.
- **Pachete cerute:** arhivă unică cu toate variantele de agent și **sursele complete**, nu doar patch-uri; alături de binare, manifest platformă/versiune, instrucțiuni de build offline, checksum SHA256.

## 4. Model de inventar și pagini aplicație

### VM-uri

- Import/corelare vCenter: nume, stări power **ON/OFF/SUSP/UNKNOWN**, status operațional **Active/Retired**, mediu **PROD/TEST/DEV**; VM fără potrivire trebuie tratate distinct.
- Identitate: hostname/FQDN/IP principal, sistem de operare, status agent, versiune agent, ultimă colectare, grad de completare, administrare și date tehnice.
- Liste paginate, căutare, filtre și export; cardurile de sumar sunt interactive.
- Rețea în structura de securitate; afișarea tabelelor late trebuie să permită un **scroll orizontal utilizabil al paginii**, fără scroll-uri imbricate inutile.
- Secțiunile goale pot fi ascunse, fără a ascunde erori autentice de colectare.

### Servicii

- Legături la VM-urile componente; clasificare, mediu, status operațional, tip soluție, beneficiari; fișe DOCX/PDF/MD și publicare Outline pentru resurse eligibile.
- Asociere cu baze de date, site-uri/aplicații web, Docker/Compose, backup și relații de infrastructură; listări paginate, export Excel.
- Documentația serviciului conține doar datele permise de politica de publicare.

### Componente suport / software

- Răspunsuri la întrebări: „Pe ce VM-uri există PostgreSQL?”, „Unde rulează MongoDB?”, „Care VM-uri au versiunea X de componentă?”.
- Inventar automat agregat din DB, Web, Docker, servicii și software; deduplicare în raportul transversal, fără a pierde identitatea **instanțelor** DB.
- Raport cu filtre, carduri, paginare, export Excel; publicare în Outline per componentă sau în bloc; linkuri spre documentațiile VM și serviciilor, dacă sunt disponibile.
- Separație între „Componente software” (inventarul observat) și „Componente suport” (vedere/raport/documentare).

## 5. Inventarierea bazelor de date — atenție la instanțe

### Cerințe ferme

- O singură VM poate găzdui **mai multe instanțe ale aceluiași motor** (PostgreSQL, MongoDB, MySQL/MariaDB etc.).
- Instanțele **native** și cele din **Docker** trebuie enumerate separat și identificate stabil; corelează containerul/ID-ul de container, endpoint-ul/portul și motorul/versiunea.
- Nu dubla detecția Docker și detecția procesului nativ pentru aceeași instanță.
- Enumerarea bazelor de date și obiectelor relevante se face **per instanță**, nu doar per motor sau per VM.
- Pentru MongoDB 4.4.11 poate exista utilitarul **`mongo`**, nu `mongosh`; fallback `mongosh` → `mongo` este necesar. Verifică suportul de autentificare și rolurile înainte de a declara colectarea completă.
- **IBM Db2:** serverul 0.21.8 introduce **ignorare implicită/configurabilă central**, prin migrarea `073` și API/Swagger. Datele brute colectate se păstrează; afișarea/folosirea lor poate fi exclusă prin configurare. Nu presupune că agentul nu-l mai detectează.
- **Redis:** nu se dezvoltă enumerarea separată a bazelor logice (`db0`, `db1` etc.) în acest proiect; dacă nu interesează inventarul DB, se poate bifa în **Nomenclatoare → Inventar tehnic → Motoare DB ignorate**. Redis rămâne detectabil ca Docker și Componentă software; păstrează informațiile despre serviciile dependente.
- **MongoDB SECONDARY:** pe MongoDB 4.4.11 cu clientul vechi `mongo`, citirea bazelor a reușit după activarea preferinței de citire secundară. Agent 1.7.16 folosește `secondaryPreferred`; testarea end-to-end pe serverul real rămâne necesară.
- **Autentificare DB:** în prima etapă inventarierea se încearcă numai cu acces local existent, cu motiv explicit pentru enumerare incompletă. Ulterior: credențiale per instanță, minime și păstrate securizat/Vault. Agentul **nu extrage parole** din Compose, `.env`, variabile de mediu sau configurații ale aplicațiilor.
- **Server 0.21.9:** `origin`, `container_id`, `container_name`, `container_image`, `compose_project`, `replica_set`, `replica_role`, `replica_primary` sunt păstrate în `database_instances` (migrarea `074`) și returnate în fișa VM; instanțele Docker folosesc `engine + container_id` pentru a evita coliziunea pe același port intern. Păstrează vechea identitate nativă. Adoptă înregistrări istorice doar dacă potrivirea este neambiguă.


### Corecții Agent 1.7.17 (2026-10-13)

- Pentru `mongo` clasic pe MongoDB 4.4 SECONDARY, `getDBs()` funcționează după `db.getMongo().setSecondaryOk()`. Test confirmat pe VM reală de utilizator; agentul 1.7.17 implementează metoda și fallback pentru clienți diferiți.
- Pentru PostgreSQL în Docker cu rol SQL diferit de `postgres`, interogarea a funcționat cu `POSTGRES_USER`/`POSTGRES_DB` deja prezente în container; agentul **nu citește POSTGRES_PASSWORD**. O execuție a durat 2,691 s. Timeout implicit pentru comenzi Docker DB: **15 s**, configurabil prin `VM_DOC_DB_QUERY_TIMEOUT_SECONDS` (5–60).
- Pentru MariaDB `ilias_mysql_1`, clientul prezent este `mariadb` (nu `mysql`) și accesul fără credențiale returnează `Access denied`: agentul păstrează `authentication_required` și nu încearcă să recupereze parole din Compose/env.
- Arhiva `vm-doc-agents-all-2026-10-13-v1.7.17-with-source.zip` conține toate build-urile moderne, pachetele legacy **nemodificate** (XP 1.0.1, Windows legacy 1.0.2, SLES9 1.0.1), sursele Go 1.7.16 și 1.7.17 și patch verificat. Schema inventar **2.12**, serverul **0.21.9** rămâne compatibil fără migrare.
- Teste raportate la generare: `go test ./...` reușit, 4 platforme moderne compilate, mock Docker, ZIP/TAR, SHA256 și patch aplicat. **Nu** au fost efectuate teste reale pe VM-uri cu noul binar 1.7.17 sau pe OS legacy.

### Stadiu

- 0.21.8: filtrare centralizată Db2 raportată ca implementată; agent nemodificat pentru această funcție.
- 1.7.16: pachetul complet cu variante moderne + legacy și surse a fost generat; variantele XP/SLES9 sunt **binare legacy păstrate**, nu compilări 1.7.16.
- 0.21.9: integrare server pentru schema agentului, migrare `074`, afișare origine/cluster și export XLSX/API.
- **De verificat:** instalarea reală a agentului și serverului, MongoDB 4.4 (`mongo`/SECONDARY), accesul cu autentificare, identitățile Docker la recrearea containerelor și migrația MariaDB.


## 6. Securitate, conturi și politici

- Meniu **Securitate → Conturi VM**: situația controalelor de politică parole; câmpuri/concepte `enforcement_status`, `effective`, `checks` și cardul Politică parole în fișa VM.
- Linux: utilizatorii cu UID sub 1000 pot fi clasificați ca „system” și excluși din evaluarea obișnuită a conturilor, **cu excepția root**, care trebuie păstrat.
- Pentru SLES9, determinarea politicilor folosește `login.defs`, PAM și shadow; compatibilitate cu familiile linuxlike (`suse/sles/debian/redhat`).
- Rapoarte/revizii pentru conturi, acces web, baze de date și reguli FortiGate.
- Autentificare server: LDAP/AD, maparea grupurilor/rolurilor și OIDC cu Keycloak, unde configurat.
- **Confidențialitate obligatorie:** linkurile Vault asociate VM/servicii rămân **strict interne aplicației**. **Nu** apar în DOCX, PDF, Markdown, Outline, exporturi sau în alte artefacte publicate/generate.
- Nu propaga secretele colectate în loguri sau în documentele rezultate.

## 7. Publicarea în Outline — reguli stricte

1. **Numai PROD** poate fi publicat: VM-uri, servicii și componente suport eligibile. Resursele TEST/DEV/nespecificate se sar și se explică de ce.
2. Dacă VM are opțiunea **„Nu se publică în Outline”**, aceasta se aplică atât în UI, cât și în API/server; nu doar ascundere de buton.
3. Pentru VM, titlul paginii Outline are prefixul **`vm-`**; pentru paginile componentelor suport se folosește **`comp-`**.
4. Publicare individuală și bulk, cu procesare asincronă pentru a evita gateway timeout la volume mari; listări paginate.
5. Linkurile Outline ale VM-urilor și serviciilor trebuie folosite în rapoartele/componentele suport; la redenumire verifică rezolvarea backlink-urilor.
6. Nu publica date non-PROD printr-un serviciu/componentă PROD și **niciodată linkuri Vault**.
7. Părinții/colecțiile Outline sunt configurabile (inclusiv „Componente suport”); rezultatele publicării trebuie să permită identificarea erorilor/săriturilor.

## 8. FortiGate — politici, corelare, diagramă

- Căutare după IP de VM ca **sursă** și ca **destinație**; corelare și cu obiecte subnet/CIDR care conțin acel IP (ex.: `10.20.10.25` intră în `10.20.10.0/24`).
- Se ține cont de policy status; regulile **disabled** nu trebuie să polueze rezultatele.
- Corelările cu reguli FortiGate au necesitat profil/API și optimizare pentru a elimina sute de mii de false match-uri.
- Tabel cu sursă, destinație, servicii/porturi permise (fiecare pe rând), politica și **VDOM / NAT / No NAT**; IP-urile trebuie vizibile.
- În diagrama tip Visio: VM-ul central o singură dată, fluxuri către porturile afișate vertical, adresele grupate (3–4 vizibile + expand), fără suprapuneri, padding între numărul regulii și VDOM/NAT.
- UDP se poate ignora în vederea cerută; ascunde porturile DNS (ex. 53) pe VM-uri AD/DNS conform regulilor aplicației.
- Fără limitare arbitrară la 24 fluxuri dacă astfel se pierd informații; performanța și lizibilitatea trebuie gestionate explicit.
- Secțiunea Forti include surse/sincronizare, căutare și analiză; datele filtrabile/exportabile Excel.

## 9. Monitorizare, backup și infrastructură

### Prometheus / Monitorizare

- Mai multe surse Prometheus; test/sync/scheduler, inventar de targets.
- Corelare target ↔ VM pe label, FQDN, hostname și IP, inclusiv IPv4 guest din vCenter.
- Carduri și taburi de Monitorizare; UI Agenți reutilizează stilul `monitoring-section-tabs`.

### Veeam

- Test/sync, situație VM **protejate/neprotejate**, job, repository, next run, retenții GFS/copy, backup în fișa VM și a serviciului.
- Există cerințe pentru politica de backup primară și copii, dar configurația reală Veeam trebuie verificată din sursa conectată.

### vCenter și alte dependențe

- Import/sincronizare VM, power, sistem de operare, IP-uri și stare administrativă.
- Dependențe infrastructură: DNS, AD/OpenLDAP, conectivitate, rute, firewall.
- **GLPI/SCCM/LibreNMS** pot exista în peisajul operațional, dar nu trebuie declarate drept integrare directă VM-DOC fără confirmare în cod/config.

## 10. Beneficiari (AD și manual)

- Beneficiarii pot fi OU-uri din Active Directory sub un base DN configurat și entități adăugate manual; păstrează proveniența **AD/manual**.
- Nomenclator **Beneficiari** cu contor; import persoane AD pentru selecții când se cere.
- Asociere **unul sau mai mulți beneficiari** la VM, serviciu, baze de date, web, Docker și Docker Compose; propagare/corelare în rapoartele Servicii/Componente suport.
- Raportarea trebuie să răspundă: „Ce servicii, componente, baze, web, containere și VM-uri are departamentul X?”. Export Excel și API/Swagger.
- 0.21.0 a fost raportat ca livrând baza acestor funcții; 0.21.7 a adăugat contor și rafinări UI Compose, fără migrare nouă sau agent nou.
- În Docker Compose: păstrează selecțiile **Serviciu**, **Mediu**, **Status operațional**, **Tip soluție**; nu adăuga rânduri suplimentare separate pentru Servicii/Beneficiari; valorile diferite trebuie afișate coerent și persistate.

## 11. UX, rapoarte și performanță

- Listări mari: paginare reală SQL acolo unde este posibil; nu încărca toate rândurile în browser doar pentru a pagina.
- Pagina Agenți 0.20.99: încărcare separată pentru navigație/filtre și date; fast path cu `COUNT(*)`, `LIMIT/OFFSET` fără filtre; căutare cu debounce **350 ms**; filtre avansate păstrează traseul complet.
- Cardurile de sumar sunt **clicabile** și filtrează tabela asociată, acolo unde există această convenție.
- Tabelele late trebuie să permită accesul real la coloanele din dreapta prin scroll orizontal vizibil; evită scroll-ul în scroll.
- Rapoarte: OS suportat, componente suport, securitate/revizii, Veeam, Forti, beneficiari; filtre, paginare, export Excel, vizualizări după mediu/power.
- În inventarul Docker, un container nu necesită automat documentație separată; documentarea se concentrează pe serviciu, integrare și relații.
- Secțiunea Web trebuie să considere fișierele `location` și `*.conf` relevante; bazele de sistem ale motoarelor SQL se ascund din inventarul de business.

## 12. Istoric selectiv al release-urilor

Vezi `CHANGELOG.md` pentru date, modificări și limitele validării. Repere majore:

- `0.20.53–0.20.60`: documentare/publicare Outline asincronă, inventar componente software, Componente suport și mapări părinte.
- `0.20.74–0.20.81`: FortiGate și diagrama de rețea/interdependențe, reguli de afișare.
- `0.20.91–0.20.99`: politici parole, SLES9 legacy, filtre VM, pagină Agenți și optimizări.
- `0.21.0–0.21.7`: beneficiari, AD/OU, asocieri și rafinări Compose/UI.
- `0.21.8`: filtrare centrală Db2 configurabilă, migrare `073`.
- `0.21.9`: integrarea multi-instanță DB a agentului 1.7.16, originea Docker/nativ, Replica Set MongoDB, migrare `074`, UI/XLSX/OpenAPI; testele server complete și MariaDB reală încă necesare.
- `1.7.15 → 1.7.16`: colectare multi-instanță DB și metadate Docker/Replica Set.
- `1.7.17`: MongoDB classic SECONDARY, PostgreSQL Docker POSTGRES_USER/DB, timeout 15 s și diagnostic MariaDB. Arhivă unică binare+surse+legacy.

## 13. Probleme deschise / verificări obligatorii

### Prioritate imediată

- [ ] **Validează Server 0.21.9 pe staging:** build complet folosind `vendor/` existent, migrarea MariaDB `074`, UI și endpointuri; release-ul livrat nu echivalează cu instalare reușită.
- [ ] **Instalează și validează Agent 1.7.17** pe MongoDB SECONDARY și pe VM-urile cu PostgreSQL/MariaDB Docker; build-urile legacy XP/SLES9 nu au fost recompilate.
- [x] Arhiva cumulată a agenților 1.7.16 cu sursele Go, patch, binare moderne și pachete legacy este disponibilă; nu presupune că toate au fost testate pe OS real.
- [ ] Testează complet inventarierea DB native vs Docker, mai multe instanțe din același motor, porturi și identitate stabilă.
- [ ] Testează MongoDB 4.4.11 cu clientul clasic `mongo`, credențiale, drepturi și rol SECONDARY.
- [ ] Compilează/testează release-urile recente server cu dependențe complete și testează migrațiile/operarea pe MariaDB reală; nu presupune că validarea patch/JS/OpenAPI este suficientă.

### Alte verificări/regresii

- [ ] Coliziuni `agent_id` după clonarea VM.
- [ ] Deduplicarea istoriei colectărilor server-side.
- [ ] Redenumiri și backlink-uri Outline (Componente suport ↔ VM/servicii).
- [ ] Publicări mari Outline fără `504 Gateway Timeout` și fără scurgeri de date non-PROD/Vault.
- [ ] Corelarea FortiGate: subnet, disabled, NAT/VDOM, porturi, excluderi UDP/DNS, performanță.
- [ ] Comportament UI pentru liste lungi și tabele late; evitarea suprapunerilor în diagrame.
- [ ] Instalare/upgrade pe platforme legacy: SLES9, XP, Linux `386`, Windows `386` unde suportate.

## 14. Reguli de implementare pentru orice conversație viitoare

1. **Nu elimina funcționalități existente** când rezolvi un bug punctual; preferă patch-uri incrementale.
2. Când propui un release, precizează exact **versiunea de pornire**, fișierele schimbate, migrațiile, compatibilitatea cu agenții și efectele asupra documentelor/API/UI.
3. Dacă sunt disponibile arhivele reale, **inspectează sursa înainte de editare**. Nu reconstrui arbitrar aplicația din acest rezumat.
4. Nu pretinde că un ZIP/binăr/sursă a fost generat, compilat sau verificat fără dovadă și linkul către un fișier existent.
5. Pentru release-uri offline include: **pachet complet**, **surse**, **patch**, **instrucțiuni upgrade/rollback**, **release notes**, **SHA256**, matrice de compatibilitate și eventual `vendor/`/dependințe necesare.
6. Nu introduce linkuri Vault, secrete sau date de producție în materialele exportate/publicate.
7. Publicare Outline **numai PROD** și control aplicat pe server/API, nu doar în UI.
8. Fă diferența între **componentă instalată** și **instanță concretă** (în special baze de date și containere).
9. Menține acest `CONTEXT.md` ca **stare curentă** și `CHANGELOG.md` ca **istoric**; nu transforma documentele în jurnal de discuții.
10. La sfârșitul unei sesiuni de dezvoltare actualizează explicit: versiune livrată, fișiere construite, teste, migrații, probleme deschise și următorul pas.

## 15. Model de rezumat de transfer după un nou release

Copiază și completează la finalul chatului, apoi actualizează cele două fișiere:

```text
Data:
Versiune server inițială -> finală:
Versiuni agent afectate:
Scopul modificării:
Fișiere / module schimbate:
Migrații DB:
Schimbări API / Swagger:
Schimbări UI:
Compatibilitate / upgrade:
Teste rulate (și rezultate):
Arhive efectiv generate (nume exacte + SHA256):
Probleme rămase:
Următorul pas:
```

---

**Notă de precizie:** Informațiile sunt un rezumat al discuțiilor și al livrărilor raportate, nu o substituție pentru arhivele originale, codul sursă, migrațiile SQL, manifestele release sau configurarea curentă din mediu. Dacă există contradicții, prioritatea o au artefactele verificate și rezultatele testelor.


## Actualizare 2026-10-13 — Server 0.21.14
- Hotfix pentru `scripts/cleanup-source-tree.sh`: conflictele între documentele UPGRADE/RELEASE-NOTES din rădăcină și `docs/history/` sunt păstrate ca variante distincte în `docs/history/variants/`, nu mai blochează `--apply`.
- Copiile diferite nu sunt suprascrise; variantele folosesc hash SHA-256; scriptul este idempotent.
- Nu afectează aplicația în execuție, agentul, migrarea 075 sau schema API.

### 0.21.22 — UI VM (2026-10-14)
- Inventar VM și rezumat VM folosesc 7 KPI egale distribuite pe întreaga lățime desktop la 1595px; responsive la rezoluții mai mici.
- Rezumat Responsabilități arată toate persoanele distincte separate prin virgulă, inclusiv persoanele cu rol technical_admin, dar fără numele rolurilor.
- Reperele De completat sunt linkuri la secțiunile VM relevante, cu focus scroll pe câmpuri acolo unde există.
- Fără SQL nou, fără agent nou; agentul curent rămâne 1.7.18.


## Actualizare 2026-10-20 — VM-DOC Server 0.21.57 (livrare surse, validare staging în așteptare)

- Punct de plecare 0.21.56. Modificări exclusive în istoricul semantic: `docker.containers[].networks[].mac_address` nu mai produce `modified` când doar MAC-ul s-a schimbat. Alte câmpuri Docker, inclusiv IP/gateway/network_id și imaginea, rămân urmărite. Datele brute, normalizate, exporturile și funcțiile de documentare nu sunt alterate.
- Filtru nftables Docker guard extins conservator la `meta iifname` sau nume bridge fără ghilimele; nu se șterg automat evenimente. `scripts/diagnose-nftables-docker-02157.sql` permite să distingem evenimente vechi de eventuale variante viitoare care scapă filtrului.
- Scripturi cumulative PREVIEW/CLEANUP cu categoria `docker_doar_mac_retea` și categorie nftables extinsă; delete manual numai după backup și verificare MariaDB staging.
- Agent 1.7.18 neschimbat; nu există migrare SQL/endpoint nou. Testele Go `internal/inventorychanges` au trecut local; full build + MariaDB de verificat în mediu offline.


## Actualizare 2026-10-20 — 0.21.58 · remediere cleanup Docker bridge

- Eroare confirmată din sursele 0.21.57: `inventory_changes.object_key` este `category|object_type|key`, dar scripturile cumulative selectau `nftables|...` drept prefix și comparau `veth...` cu cheia întreagă. Aceasta făcea PREVIEW/CLEANUP să rateze evenimente reale.
- În 0.21.58, SQL parsează backend la tokenul 3, chain la tokenul 6 și interfața la ultimul token. Au fost adăugate scripturi țintite pentru bridge-uri Docker `br-<12 hex>` și reguli nftables `ip daddr private iifname != br-<12 hex> counter drop`; se păstrează review/decizii/observații.
- Serverul nu mai generează istoricul de apariție/dispariție pentru numele automat `br-<12 hex>`. `docker0`, interfețe stabile, informațiile brute și reguli explicite sunt păstrate.
- Nu șterge automat la pornire; backup + MariaDB staging + cleanup manual, apoi verifică evenimente noi după upgrade.
- Agent 1.7.18 nemodificat; full build cu vendor/ offline și test MariaDB reală încă necesare.

## 0.21.64 — Reguli Power + Mediu și Docker UI cache

- Filtru Mediu lângă Power în Agenți/VM-uri/Backup Veeam/Monitorizare și în rapoarte OS/Outline, implicit Pornite + PROD; resetările revin la aceste valori. Opțiunile includ Toate/PROD/TEST/DEV și Power ON/OFF/SUSPEND.
- Clasificare mediu unificată backend (`internal/vmenv`): nomenclatoare VM cu fallback la metadata; listele/totalurile/exporturile Excel sunt filtrate la sursă; default Agenți folosește SQL paginat.
- `vmContext is not defined` la Docker: textul exact nu apare în sursele client 0.21.63; se actualizează cache-bustingul app.js + antetele no-store pentru JS și HTML. Cauza precisă nu poate fi confirmată fără stack trace din browser; dacă persistă este necesar screenshot Console cu fișier și linie.
- Upgrade 0.21.63→0.21.64, fără migrare DB, agent 1.7.18 neschimbat; validare reală pe VCSA/MariaDB/browser rămâne necesară.

## 0.21.75 — Uniformizare nume Keycloak
- În header, OIDC construiește `display_name` la login din claimuri standard `family_name`, `given_name`, plus claim configurabil `department` → `Nume Prenume (Departament)`.
- LDAP continuă să utilizeze `displayName` existent; configurația Keycloak trebuie să expună departamentul în ID token prin mapper.
- Fără migrare și fără schimbare agent.

## 0.21.76 — Căutare Modificări și comparație 1:1 (2026-10-22)

- Bază: 0.21.75; `inventorychanges.Service.Capture` compară numai `previousRaw`/`currentRaw`, cu `healthyForObject(previous,current)` și `changedBetweenSnapshots`. Nu mai citește al treilea snapshot din DB.
- Filtrele semantice din 0.21.73 rămân; doar confirmarea la al doilea nou snapshot este eliminată.
- Web global și VM: `bindChangeFilters` răspunde la input/Enter/search/change, are debounce, paginare resetată, respinge răspunsuri HTTP stale.
- SQL `List` include și cheia/tipul/categoria; istoric existent neatins. Nicio migrare, agent 1.7.18.
