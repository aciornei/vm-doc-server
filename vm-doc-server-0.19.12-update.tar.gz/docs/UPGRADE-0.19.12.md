# Upgrade vm-doc-server 0.19.11 → 0.19.12

0.19.12 introduce filtrarea serviciilor OS pe baza clasificării furnizate de vm-doc-agent 1.6.7. Nu există migrare DB.

## Noutăți

- VM → Inventar → Servicii afișează implicit `Active` + `Aplicație + necunoscut`;
- filtrul `Tip serviciu` permite Aplicație, Necunoscut, Sistem OS sau Toate;
- serviciile marcate Principal rămân vizibile chiar dacă sunt clasificate ca sistem sau sunt nedetectate;
- fișa VM omite doar serviciile clasificate explicit `system` din lista generală `Servicii active`;
- snapshoturile de la agenți mai vechi, fără clasificare, sunt tratate `unknown` și nu sunt ascunse.

## Upgrade server

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.11 vm-doc-server-0.19.12
tar -xzf /cale/vm-doc-server-0.19.12-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.12
cd /usr/local/src/vm-doc-server-0.19.12
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

## Agent

Publicați vm-doc-agent 1.6.7 și actualizați VM-urile pentru care doriți clasificarea. Serverul 0.19.12 acceptă în continuare snapshoturi mai vechi.

## Verificări

1. `/version` trebuie să raporteze `0.19.12`.
2. După colectare cu agent 1.6.7, un `systemd-logind.service` trebuie să fie clasificat `system`, iar `tomcat`/`postgresql`/`nginx` ca `application`.
3. În VM → Inventar → Servicii, filtrul implicit nu trebuie să afișeze serviciile OS.
4. Selectarea `Sistem OS` trebuie să le facă vizibile.
5. Un serviciu marcat Principal trebuie să rămână vizibil.
6. DOCX-ul VM nu trebuie să enumere serviciile clasificate explicit ca `system` în `Servicii active`.
