package main

import (
	"flag"
	"fmt"
	"os"

	"vm-doc-server/internal/cryptox"
)

func main() {
	in := flag.String("in", "configs/secrets.example.yaml", "plaintext YAML input")
	out := flag.String("out", "secrets.enc", "encrypted output")
	keyFile := flag.String("key", "master.key", "master key file")
	flag.Parse()
	plain, err := os.ReadFile(*in)
	check(err)
	master, err := os.ReadFile(*keyFile)
	check(err)
	box, err := cryptox.New(master)
	check(err)
	ciphertext, err := box.Encrypt(plain, "vm-doc-secrets")
	check(err)
	check(os.WriteFile(*out, []byte(ciphertext+"\n"), 0600))
	fmt.Println(*out)
}
func check(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
