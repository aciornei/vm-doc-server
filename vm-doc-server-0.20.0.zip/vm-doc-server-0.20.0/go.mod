module vm-doc-server

go 1.23.0

require (
	github.com/coreos/go-oidc/v3 v3.14.1
	github.com/go-ldap/ldap/v3 v3.4.8
	github.com/go-sql-driver/mysql v1.8.1
	github.com/swaggest/swgui v1.8.1
	golang.org/x/oauth2 v0.28.0
	gopkg.in/yaml.v3 v3.0.1
)
