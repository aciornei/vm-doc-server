package server

import (
	"bytes"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/xlsx"
)

var exportableNomenclatureCategories = map[string]bool{
	"architectural_domain": true,
	"itil_category":        true,
	"layer":                true,
	"technical_role":       true,
	"solution_type":        true,
	"environment":          true,
	"operational_status":   true,
	"classification":       true,
}

func (a *App) exportNomenclatures(w http.ResponseWriter, r *http.Request) {
	categoryCode := strings.TrimSpace(r.URL.Query().Get("category"))
	includeInactiveValues := !strings.EqualFold(strings.TrimSpace(r.URL.Query().Get("include_inactive")), "false")
	if categoryCode == "" {
		badRequest(w, errors.New("category is required"))
		return
	}

	var (
		rows      [][]xlsx.Cell
		sheetName string
		fileCode  string
		err       error
	)

	if categoryCode == "people" {
		var values []domain.Person
		values, err = a.Nomenclatures.ListPeople(r.Context(), includeInactiveValues)
		if err == nil {
			rows = peopleExportRows(values)
			sheetName = "Persoane"
			fileCode = "persoane"
		}
	} else {
		if !exportableNomenclatureCategories[categoryCode] {
			badRequest(w, errors.New("invalid nomenclature category"))
			return
		}
		var categories []domain.NomenclatureCategory
		categories, err = a.Nomenclatures.ListCategories(r.Context(), includeInactiveValues)
		if err == nil {
			var selected *domain.NomenclatureCategory
			for index := range categories {
				if categories[index].Code == categoryCode {
					selected = &categories[index]
					break
				}
			}
			if selected == nil {
				err = errors.New("nomenclature category not found")
			} else {
				rows = nomenclatureExportRows(*selected)
				sheetName = selected.Label
				fileCode = selected.Code
			}
		}
	}
	if err != nil {
		respond(w, nil, err)
		return
	}

	var output bytes.Buffer
	if err := xlsx.Write(&output, sheetName, rows); err != nil {
		respond(w, nil, err)
		return
	}
	filename := "nomenclator-" + fileCode + "-" + time.Now().Format("20060102-150405") + ".xlsx"
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
	w.Header().Set("Content-Length", strconv.Itoa(output.Len()))
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(output.Bytes())
}

func nomenclatureExportRows(category domain.NomenclatureCategory) [][]xlsx.Cell {
	headers := []string{"ID", "Denumire"}
	switch category.Code {
	case "itil_category":
		headers = append(headers, "Domeniu arhitectural")
	case "technical_role":
		headers = append(headers, "Layer-e permise")
	}
	headers = append(headers, "Cod", "Pictogramă", "Descriere", "Ordine", "Activ")

	rows := make([][]xlsx.Cell, 0, len(category.Items)+1)
	headerRow := make([]xlsx.Cell, 0, len(headers))
	for _, header := range headers {
		headerRow = append(headerRow, xlsx.Text(header))
	}
	rows = append(rows, headerRow)

	for _, item := range category.Items {
		row := []xlsx.Cell{xlsx.Number(float64(item.ID)), xlsx.Text(item.Name)}
		switch category.Code {
		case "itil_category":
			row = append(row, xlsx.Text(item.ParentName))
		case "technical_role":
			row = append(row, xlsx.Text(strings.Join(item.LayerNames, ", ")))
		}
		row = append(row,
			xlsx.Text(item.ItemCode),
			xlsx.Text(item.IconKey),
			xlsx.Text(item.Description),
			xlsx.Number(float64(item.SortOrder)),
			xlsx.Text(yesNo(item.Active)),
		)
		rows = append(rows, row)
	}
	return rows
}

func peopleExportRows(values []domain.Person) [][]xlsx.Cell {
	headers := []string{"ID", "Nume", "Departament", "Email", "Telefon", "Sursă", "Utilizator AD", "Activ", "Creat", "Actualizat"}
	rows := make([][]xlsx.Cell, 0, len(values)+1)
	headerRow := make([]xlsx.Cell, 0, len(headers))
	for _, header := range headers {
		headerRow = append(headerRow, xlsx.Text(header))
	}
	rows = append(rows, headerRow)
	for _, value := range values {
		rows = append(rows, []xlsx.Cell{
			xlsx.Number(float64(value.ID)), xlsx.Text(value.DisplayName), xlsx.Text(value.Department), xlsx.Text(value.Email),
			xlsx.Text(value.Phone), xlsx.Text(value.Source), xlsx.Text(value.DirectoryUsername), xlsx.Text(yesNo(value.Active)),
			xlsx.Text(value.CreatedAt.Format(time.RFC3339)), xlsx.Text(value.UpdatedAt.Format(time.RFC3339)),
		})
	}
	return rows
}
