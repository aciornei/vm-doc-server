package vcenter

import "testing"

func TestNormalizeOperationalMetadata(t *testing.T) {
	input := OperationalMetadataInput{
		Purpose:          "  VM shared  ",
		DocumentationURL: "https://docs.example.test/vm/1",
		TicketReference:  "  INC-123  ",
		Classification:   "  Uz intern  ",
	}
	if err := normalizeOperationalMetadata(&input); err != nil {
		t.Fatal(err)
	}
	if input.Purpose != "VM shared" || input.TicketReference != "INC-123" || input.Classification != "Uz intern" {
		t.Fatalf("values were not normalized: %#v", input)
	}
}

func TestNormalizeOperationalMetadataRejectsInvalidValues(t *testing.T) {
	cases := []OperationalMetadataInput{
		{OwnerEmail: "not-an-email"},
		{DocumentationURL: "file:///tmp/doc"},
	}
	for index := range cases {
		if err := normalizeOperationalMetadata(&cases[index]); err == nil {
			t.Fatalf("case %d should fail", index)
		}
	}
}

func TestAllowedServiceUsageTypes(t *testing.T) {
	for _, value := range []string{"dedicated", "shared", "dependency"} {
		if !allowedServiceUsageTypes[value] {
			t.Fatalf("usage type %q should be allowed", value)
		}
	}
	if allowedServiceUsageTypes["invalid"] {
		t.Fatal("invalid usage type should not be allowed")
	}
}
