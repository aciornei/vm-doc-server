package richtext

import (
	"strings"
	"testing"

	"vm-doc-server/internal/domain"
)

func TestFromPlainAndPlainText(t *testing.T) {
	doc := FromPlain("Scop general\n• Primul obiectiv\n2. Al doilea obiectiv")
	if len(doc.Blocks) != 3 || doc.Blocks[1].Type != "bullet" || doc.Blocks[2].Type != "number" {
		t.Fatalf("unexpected document: %#v", doc)
	}
	plain := PlainText(doc)
	if !strings.Contains(plain, "• Primul obiectiv") || !strings.Contains(plain, "1. Al doilea obiectiv") {
		t.Fatalf("unexpected plain text: %q", plain)
	}
}

func TestNormalizeMergesRunsAndRejectsUnsupportedBlocks(t *testing.T) {
	doc := &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{{Type: "bullet", Runs: []domain.RichTextRun{{Text: "A", Bold: true}, {Text: "B", Bold: true}}}}}
	normalized, err := Normalize(doc)
	if err != nil {
		t.Fatal(err)
	}
	if len(normalized.Blocks[0].Runs) != 1 || normalized.Blocks[0].Runs[0].Text != "AB" {
		t.Fatalf("runs were not merged: %#v", normalized)
	}
	_, err = Normalize(&domain.RichTextDocument{Blocks: []domain.RichTextBlock{{Type: "html"}}})
	if err == nil {
		t.Fatal("expected validation error")
	}
}

func TestEncodeDecode(t *testing.T) {
	doc := &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{{Type: "paragraph", Runs: []domain.RichTextRun{{Text: "Important", Bold: true, Underline: true}}}}}
	encoded, err := Encode(doc)
	if err != nil {
		t.Fatal(err)
	}
	decoded := Decode(encoded, "fallback")
	if len(decoded.Blocks) != 1 || len(decoded.Blocks[0].Runs) != 1 || !decoded.Blocks[0].Runs[0].Bold || !decoded.Blocks[0].Runs[0].Underline {
		t.Fatalf("unexpected decoded document: %#v", decoded)
	}
}
