package secrets

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"

	"gopkg.in/yaml.v3"
	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
)

func Load(cfg config.SecretsConfig, box *cryptox.Box) (config.Secrets, error) {
	var out config.Secrets
	b, err := os.ReadFile(cfg.EncryptedFile)
	if err != nil {
		return out, fmt.Errorf("read secrets file: %w", err)
	}
	content := strings.TrimSpace(string(b))
	var plain []byte
	if strings.HasPrefix(content, "v1:") {
		plain, err = box.Decrypt(content, "vm-doc-secrets")
		if err != nil {
			return out, fmt.Errorf("decrypt secrets file: %w", err)
		}
	} else {
		if !cfg.AllowPlaintextFile {
			return out, fmt.Errorf("secrets file is not encrypted")
		}
		plain = b
	}
	decoder := yaml.NewDecoder(bytes.NewReader(plain))
	decoder.KnownFields(true)
	if err := decoder.Decode(&out); err != nil {
		return out, fmt.Errorf("parse secrets: %w", err)
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return out, errors.New("secrets file contains multiple YAML documents")
	}
	if strings.TrimSpace(out.DatabasePassword) == "" {
		return out, errors.New("database_password is required")
	}
	return out, nil
}
