package cryptox

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"
)

type Box struct{ key [32]byte }

func New(master []byte) (*Box, error) {
	master = []byte(strings.TrimSpace(string(master)))
	if len(master) < 32 {
		return nil, errors.New("master key must contain at least 32 bytes")
	}
	return &Box{key: sha256.Sum256(master)}, nil
}

func LoadMasterKey(filePath, envName string) ([]byte, error) {
	if envName != "" {
		if v := os.Getenv(envName); v != "" {
			return []byte(v), nil
		}
	}
	if filePath == "" {
		return nil, errors.New("master key file or environment variable is required")
	}
	filePath = os.ExpandEnv(filePath)
	b, err := os.ReadFile(filePath)
	if err != nil {
		return nil, fmt.Errorf("read master key: %w", err)
	}
	return b, nil
}

func (b *Box) Encrypt(plaintext []byte, aad string) (string, error) {
	block, err := aes.NewCipher(b.key[:])
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	sealed := gcm.Seal(nonce, nonce, plaintext, []byte(aad))
	return "v1:" + base64.RawStdEncoding.EncodeToString(sealed), nil
}

func (b *Box) Decrypt(value, aad string) ([]byte, error) {
	if !strings.HasPrefix(value, "v1:") {
		return nil, errors.New("unsupported ciphertext version")
	}
	raw, err := base64.RawStdEncoding.DecodeString(strings.TrimPrefix(value, "v1:"))
	if err != nil {
		return nil, err
	}
	block, err := aes.NewCipher(b.key[:])
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	if len(raw) < gcm.NonceSize() {
		return nil, errors.New("ciphertext is too short")
	}
	nonce, ciphertext := raw[:gcm.NonceSize()], raw[gcm.NonceSize():]
	return gcm.Open(nil, nonce, ciphertext, []byte(aad))
}

func RandomToken(bytes int) (string, error) {
	b := make([]byte, bytes)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}
