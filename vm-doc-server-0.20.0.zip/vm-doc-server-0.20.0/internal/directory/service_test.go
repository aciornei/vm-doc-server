package directory

import (
	"encoding/hex"
	"reflect"
	"strings"

	"github.com/go-ldap/ldap/v3"
	"testing"
)

func TestRelativeOUPath(t *testing.T) {
	got, err := relativeOUPath(
		"CN=Ion Popescu,OU=Linux,OU=Administrare,OU=Utilizatori,DC=example,DC=ro",
		"OU=Utilizatori,DC=example,DC=ro",
	)
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"Administrare", "Linux"}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("unexpected OU path: got %#v want %#v", got, want)
	}
}

func TestRelativeOUPathRejectsOutsideBase(t *testing.T) {
	if _, err := relativeOUPath("CN=Ion,OU=Other,DC=example,DC=ro", "OU=Users,DC=example,DC=ro"); err == nil {
		t.Fatal("expected outside-base error")
	}
}

func TestWithinBaseIsCaseInsensitive(t *testing.T) {
	if !withinBase("CN=Ion,OU=Users,DC=EXAMPLE,DC=RO", "ou=users,dc=example,dc=ro") {
		t.Fatal("expected DN to be inside base")
	}
}

func TestAndFilter(t *testing.T) {
	got := andFilter("(&(objectClass=user))", "(department=IT)")
	if got != "(&(&(objectClass=user))(department=IT))" {
		t.Fatalf("unexpected filter: %s", got)
	}
}

func TestStableDirectoryKeyUsesIdentityAttribute(t *testing.T) {
	rawGUID, _ := hex.DecodeString("00112233445566778899aabbccddeeff")
	entryA := &ldap.Entry{DN: "CN=Ion,OU=One,DC=example,DC=ro", Attributes: []*ldap.EntryAttribute{{Name: "objectGUID", ByteValues: [][]byte{rawGUID}}}}
	entryB := &ldap.Entry{DN: "CN=Ion,OU=Two,DC=example,DC=ro", Attributes: []*ldap.EntryAttribute{{Name: "objectGUID", ByteValues: [][]byte{rawGUID}}}}
	keyA := stableDirectoryKey(entryA, "objectGUID")
	keyB := stableDirectoryKey(entryB, "objectGUID")
	if keyA != keyB || len(keyA) != 64 {
		t.Fatalf("expected stable 64-character key, got %q and %q", keyA, keyB)
	}
}

func TestStableDirectoryKeyFallsBackToDN(t *testing.T) {
	entry := &ldap.Entry{DN: "CN=Ion,OU=Users,DC=example,DC=ro"}
	key := stableDirectoryKey(entry, "objectGUID")
	if len(key) != 64 || strings.TrimSpace(key) == "" {
		t.Fatalf("unexpected fallback key: %q", key)
	}
}
