package nomenclature

import (
	"testing"

	"vm-doc-server/internal/domain"
)

func TestNormalizeItem(t *testing.T) {
	parentID := int64(7)
	input := ItemInput{CategoryCode: " ITIL_CATEGORY ", Name: "  Mail  ", ItemCode: " MAIL.PROD ", Description: " test ", ParentID: &parentID}
	if err := normalizeItem(&input); err != nil {
		t.Fatal(err)
	}
	if input.CategoryCode != "itil_category" || input.Name != "Mail" || input.ItemCode != "mail.prod" {
		t.Fatalf("unexpected normalized input: %#v", input)
	}
}

func TestNormalizeItemRejectsLegacyAndUnknownCategories(t *testing.T) {
	for _, category := range []string{"service", "component", "unknown"} {
		if err := normalizeItem(&ItemInput{CategoryCode: category, Name: "X"}); err == nil {
			t.Fatalf("expected invalid category for %q", category)
		}
	}
}

func TestNormalizePerson(t *testing.T) {
	input := PersonInput{DisplayName: "  Ion Popescu ", Email: "ION@EXAMPLE.TEST"}
	if err := normalizePerson(&input); err != nil {
		t.Fatal(err)
	}
	if input.DisplayName != "Ion Popescu" || input.Email != "ion@example.test" {
		t.Fatalf("unexpected normalized person: %#v", input)
	}
}

func TestNormalizeItemTechnicalRoleLayers(t *testing.T) {
	input := ItemInput{CategoryCode: "technical_role", Name: " PostgreSQL ", LayerIDs: []int64{9, 3, 9}}
	if err := normalizeItem(&input); err != nil {
		t.Fatal(err)
	}
	if len(input.LayerIDs) != 2 || input.LayerIDs[0] != 3 || input.LayerIDs[1] != 9 {
		t.Fatalf("unexpected layer ids: %#v", input.LayerIDs)
	}
}

func TestNormalizeLayerIDsRejectsInvalidValue(t *testing.T) {
	if _, err := normalizeLayerIDs([]int64{1, 0}); err == nil {
		t.Fatal("expected invalid layer identifier")
	}
}

func TestSortTechnicalRolesByLayerThenRoleOrder(t *testing.T) {
	categories := []domain.NomenclatureCategory{
		{Code: "layer", Items: []domain.NomenclatureValue{{ID: 10, Name: "Acces", SortOrder: 10}, {ID: 20, Name: "Aplicație", SortOrder: 20}}},
		{Code: "technical_role", Items: []domain.NomenclatureValue{
			{ID: 3, Name: "Server aplicație", SortOrder: 20, LayerIDs: []int64{20}},
			{ID: 2, Name: "Load balancer", SortOrder: 20, LayerIDs: []int64{10}},
			{ID: 1, Name: "Reverse proxy", SortOrder: 10, LayerIDs: []int64{10}},
		}},
	}
	byID := map[int64]domain.NomenclatureValue{
		10: categories[0].Items[0],
		20: categories[0].Items[1],
	}
	sortTechnicalRoles(categories, 1, byID)
	got := categories[1].Items
	if len(got) != 3 || got[0].ID != 1 || got[1].ID != 2 || got[2].ID != 3 {
		t.Fatalf("unexpected role order: %#v", got)
	}
}

func TestSortNomenclatureCategoriesByParentThenOwnOrder(t *testing.T) {
	domainAID := int64(10)
	domainBID := int64(20)
	categories := []domain.NomenclatureCategory{
		{Code: "architectural_domain", Items: []domain.NomenclatureValue{
			{ID: domainBID, Name: "Domeniu B", SortOrder: 20},
			{ID: domainAID, Name: "Domeniu A", SortOrder: 10},
		}},
		{Code: "itil_category", Items: []domain.NomenclatureValue{
			{ID: 3, Name: "B2", SortOrder: 20, ParentID: &domainBID},
			{ID: 2, Name: "A2", SortOrder: 20, ParentID: &domainAID},
			{ID: 1, Name: "A1", SortOrder: 10, ParentID: &domainAID},
			{ID: 4, Name: "B1", SortOrder: 10, ParentID: &domainBID},
		}},
	}

	sortNomenclatureCategories(categories)

	domains := categories[0].Items
	if len(domains) != 2 || domains[0].ID != domainAID || domains[1].ID != domainBID {
		t.Fatalf("unexpected domain order: %#v", domains)
	}
	values := categories[1].Items
	if len(values) != 4 || values[0].ID != 1 || values[1].ID != 2 || values[2].ID != 4 || values[3].ID != 3 {
		t.Fatalf("unexpected child order: %#v", values)
	}
}

func TestSortNomenclatureCategoriesPlacesOrphansLast(t *testing.T) {
	parentID := int64(10)
	missingParentID := int64(999)
	categories := []domain.NomenclatureCategory{
		{Code: "architectural_domain", Items: []domain.NomenclatureValue{{ID: parentID, Name: "Domeniu", SortOrder: 10}}},
		{Code: "itil_category", Items: []domain.NomenclatureValue{
			{ID: 2, Name: "Fără părinte", SortOrder: 1, ParentID: &missingParentID},
			{ID: 1, Name: "Validă", SortOrder: 50, ParentID: &parentID},
		}},
	}

	sortNomenclatureCategories(categories)
	values := categories[1].Items
	if len(values) != 2 || values[0].ID != 1 || values[1].ID != 2 {
		t.Fatalf("unexpected orphan order: %#v", values)
	}
}
