package catalog

import (
	"testing"

	"vm-doc-server/internal/domain"
)

func TestNormalizeService(t *testing.T) {
	input := InternalServiceInput{Name: "  Metabase ", ServiceCode: " BI.METABASE ", Purpose: "  Raportare internă  ", Objectives: "  Dashboard-uri standardizate  ", Criticality: " HIGH ", DocumentationStatus: " IN_PROGRESS "}
	if err := normalizeService(&input); err != nil {
		t.Fatal(err)
	}
	if input.Name != "Metabase" || input.ServiceCode != "bi.metabase" || input.Purpose != "Raportare internă" || input.Objectives != "Dashboard-uri standardizate" || input.Criticality != "high" || input.DocumentationStatus != "in_progress" {
		t.Fatalf("unexpected normalization: %#v", input)
	}
}

func TestNormalizeServiceRejectsInvalidValues(t *testing.T) {
	tests := []InternalServiceInput{
		{},
		{Name: "X", Criticality: "urgent"},
		{Name: "X", DocumentationStatus: "done"},
		{Name: "X", ServiceCode: "BAD CODE"},
		{Name: "X", DocumentationURL: "file:///tmp/x"},
	}
	for i := range tests {
		if err := normalizeService(&tests[i]); err == nil {
			t.Fatalf("test %d: expected error", i)
		}
	}
}

func TestNormalizeServiceRichTextKeepsPlainCompatibility(t *testing.T) {
	input := InternalServiceInput{
		Name: "Serviciu",
		PurposeRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{
			{Type: "paragraph", Runs: []domain.RichTextRun{{Text: "Arie ", Bold: true}, {Text: "funcțională"}}},
		}},
		ObjectivesRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{
			{Type: "bullet", Runs: []domain.RichTextRun{{Text: "Primul obiectiv", Italic: true}}},
			{Type: "bullet", Level: 1, Runs: []domain.RichTextRun{{Text: "Sub-obiectiv"}}},
		}},
	}
	if err := normalizeService(&input); err != nil {
		t.Fatal(err)
	}
	if input.Purpose != "Arie funcțională" {
		t.Fatalf("unexpected purpose compatibility text: %q", input.Purpose)
	}
	if input.Objectives != "• Primul obiectiv\n  • Sub-obiectiv" {
		t.Fatalf("unexpected objectives compatibility text: %q", input.Objectives)
	}
}

func TestNormalizeServiceRequiresDependencyTypeForCommonService(t *testing.T) {
	common := true
	input := InternalServiceInput{Name: "DNS", IsCommon: &common}
	if err := normalizeService(&input); err == nil {
		t.Fatal("expected common service without dependency type to be rejected")
	}
	dependencyTypeID := int64(10)
	input = InternalServiceInput{Name: "DNS", IsCommon: &common, CommonDependencyTypeID: &dependencyTypeID}
	if err := normalizeService(&input); err != nil {
		t.Fatal(err)
	}
}
