package inventory

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"sort"
	"strings"
)

type DocumentView struct {
	GeneratedAt any               `json:"generated_at,omitempty"`
	Sections    []DocumentSection `json:"sections"`
}

type DocumentSection struct {
	Key    string `json:"key"`
	Title  string `json:"title"`
	Status string `json:"status,omitempty"`
	Data   any    `json:"data"`
}

var documentSectionTitles = map[string]string{
	"schema":           "Schema inventar",
	"agent":            "Agent",
	"identity":         "Identificare",
	"host":             "Sistem și hardware",
	"system":           "Sistem",
	"os":               "Sistem de operare",
	"operating_system": "Sistem de operare",
	"storage":          "Stocare",
	"disks":            "Discuri",
	"mounts":           "Filesystem și mount points",
	"network":          "Rețea",
	"proxy":            "Proxy",
	"services":         "Servicii",
	"listening_ports":  "Porturi ascultate",
	"firewall":         "Firewall",
	"accounts":         "Conturi și acces administrativ",
	"sssd":             "Integrare SSSD",
	"integrations":     "Integrări",
	"policies":         "Politici",
	"cron":             "Sarcini programate",
	"ntp":              "Sincronizare timp",
	"collection":       "Rezultatul colectării",
	"collectors":       "Starea colectorilor",
	"packages":         "Pachete instalate",
	"security":         "Securitate",
}

var documentSectionOrder = []string{
	"schema", "agent", "identity", "host", "system", "os", "operating_system", "storage", "disks", "mounts", "network", "proxy", "services", "listening_ports", "firewall", "accounts", "sssd", "integrations", "policies", "cron", "ntp", "security", "packages", "collection", "collectors",
}

func BuildDocumentView(raw []byte) (DocumentView, error) {
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var root map[string]any
	if err := decoder.Decode(&root); err != nil {
		return DocumentView{}, err
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return DocumentView{}, errors.New("inventory JSON contains trailing data")
	}
	view := DocumentView{Sections: make([]DocumentSection, 0, len(root))}
	for _, key := range []string{"generated_at", "collected_at", "timestamp"} {
		if value, ok := root[key]; ok {
			view.GeneratedAt = value
			delete(root, key)
			break
		}
	}

	keys := make([]string, 0, len(root))
	seen := make(map[string]bool, len(root))
	for _, key := range documentSectionOrder {
		if _, ok := root[key]; ok {
			keys = append(keys, key)
			seen[key] = true
		}
	}
	remaining := make([]string, 0)
	for key := range root {
		if !seen[key] {
			remaining = append(remaining, key)
		}
	}
	sort.Strings(remaining)
	keys = append(keys, remaining...)

	for _, key := range keys {
		value := sanitizeDocumentValue(key, root[key])
		if value == nil {
			continue
		}
		view.Sections = append(view.Sections, DocumentSection{
			Key:    key,
			Title:  documentTitle(key),
			Status: documentStatus(value),
			Data:   value,
		})
	}
	return view, nil
}

func sanitizeDocumentValue(key string, value any) any {
	if isSensitiveDocumentKey(key) {
		return "[redactat]"
	}
	switch typed := value.(type) {
	case map[string]any:
		clean := make(map[string]any, len(typed))
		for childKey, childValue := range typed {
			clean[childKey] = sanitizeDocumentValue(childKey, childValue)
		}
		return clean
	case []any:
		clean := make([]any, 0, len(typed))
		for _, item := range typed {
			clean = append(clean, sanitizeDocumentValue("", item))
		}
		return clean
	default:
		return typed
	}
}

func isSensitiveDocumentKey(key string) bool {
	normalized := strings.ToLower(strings.ReplaceAll(strings.TrimSpace(key), "-", "_"))
	if normalized == "" {
		return false
	}
	for _, token := range []string{"password", "passwd", "secret", "token", "credential", "private_key", "api_key", "access_key"} {
		if strings.Contains(normalized, token) {
			return true
		}
	}
	return false
}

func documentTitle(key string) string {
	if title := documentSectionTitles[key]; title != "" {
		return title
	}
	words := strings.Fields(strings.ReplaceAll(strings.ReplaceAll(key, "_", " "), "-", " "))
	for i := range words {
		if words[i] != "" {
			words[i] = strings.ToUpper(words[i][:1]) + words[i][1:]
		}
	}
	return strings.Join(words, " ")
}

func documentStatus(value any) string {
	if object, ok := value.(map[string]any); ok {
		for _, key := range []string{"status", "state", "result"} {
			if text, ok := object[key].(string); ok {
				return strings.ToLower(strings.TrimSpace(text))
			}
		}
	}
	return ""
}
