# Upgrade la vm-doc-server 0.3.6

## Schimbări

- relație multiplă între VM-uri și servicii interne;
- mai multe combinații layer–rol pentru același serviciu și VM;
- eliminarea profilului și datei de provisionare din modelul funcțional;
- migrarea lifecycle-ului local `Retired` către `Status operațional: Retras`;
- eliminarea cardului „Rezumat ultimul inventar”.

## Migrare

La prima pornire, `014_multi_service_assignments.up.sql`:

1. transformă `vm_internal_service_assignments` dintr-un singur rând per VM într-un tabel cu cheie proprie;
2. păstrează asocierea existentă și o marchează principală;
3. adaugă tipul de utilizare, observațiile și ordinea;
4. convertește vechiul marcaj `Retired` în status operațional `Retras`, dacă VM-ul nu avea deja status;
5. elimină profilul de provisionare din nomenclatoarele active și golește valorile legacy.

## Validare înainte de instalare

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

## Verificare după pornire

- deschide un VM și adaugă două asocieri pentru același serviciu, cu layer-e diferite;
- adaugă un al doilea serviciu intern;
- verifică faptul că rolurile sunt filtrate după serviciu și layer;
- verifică un VM marcat anterior `Retired`: trebuie să aibă status operațional `Retras` dacă nu avea alt status;
- verifică lipsa profilului de provisionare și a rezumatului redundant al inventarului.
