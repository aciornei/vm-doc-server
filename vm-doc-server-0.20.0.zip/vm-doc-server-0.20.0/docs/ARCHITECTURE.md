# Architecture 0.4.0

## Surse de adevăr

- **vCenter**: existența VM-ului, MoID, UUID, power state și resurse;
- **vm-doc-agent**: sistem de operare, rețea, servicii, politici și integrări;
- **vm-doc-server**: încadrare operațională, catalog de servicii, responsabilități, asocieri și istoric.

## Relația VM–serviciu

Relația este multiplă. Un VM poate deservi mai multe servicii interne, iar pentru același serviciu poate avea mai multe combinații arhitecturale.

```text
VM
 ├─ Domeniu A → Categorie X → Serviciu intern A → Layer aplicație → Rol aplicație
 ├─ Domeniu A → Categorie X → Serviciu intern A → Layer date → Rol PostgreSQL
 └─ Domeniu B → Categorie Y → Serviciu intern B → Layer cache → Rol Redis
```

Fiecare asociere poate fi `dedicated`, `shared` sau `dependency`, poate avea observații și cel mult una poate fi marcată principală pentru VM.

## Catalogul serviciilor

Serviciul intern este independent de domeniu și categorie. La nivelul lui se păstrează denumirea, codul, descrierea, scopul, criticitatea și documentația. Încadrările `Domeniu arhitectural → Categorie de serviciu` sunt salvate pe asocierile VM și agregate automat în pagina serviciului.

Astfel, același serviciu poate apărea în mai multe domenii sau categorii fără duplicarea sa în catalog.

## Relațiile controlate

- `nomenclature_item_parents` stabilește domeniul părinte al fiecărei categorii de serviciu;
- `layer_technical_role_mappings` stabilește layer-ele în care poate fi folosit un rol tehnic;
- `vm_internal_service_assignments` păstrează alegerea concretă pentru VM.

În interfața VM:

```text
Domeniu → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic
```

Backendul verifică faptul că categoria aparține domeniului și rolul aparține layer-ului.

## Procese

`vm-doc-server` deservește browserul/API-ul și execută schedulerul vCenter. `vm-doc-collector` este singurul proces care contactează agenții.

## Sincronizare vCenter

Rulările sunt persistate în `vcenter_sync_runs`. Un named lock MariaDB previne procesarea simultană a aceleiași surse. Operația este asincronă față de cererea HTTP.

## Coada agenților

Joburile sunt stocate în `collection_jobs`. Un worker revendică un job prin lease. Un job rămas `running` poate fi revendicat după expirarea lease-ului.

## Inventar și corelare

Fiecare colectare reușită produce un rând în `inventory_snapshots`. JSON-ul original este păstrat, iar câmpurile de identificare sunt extrase pentru corelare. SHA-256 identifică schimbările fără pierderea istoricului.

## Frontend

Frontendul este HTML/CSS/JavaScript fără Node.js și este inclus în binarul Go cu `go:embed`.
