# Upgrade la vm-doc-server 0.3.8

Versiunea 0.3.8 mută selecția `Domeniu → Serviciu intern → Layer → Rol tehnic` exclusiv pe fișa VM. Pagina serviciului intern devine o vedere agregată, calculată automat din asocierile VM-urilor.

## Model curent

```text
Layer arhitectural
  └── Roluri tehnice permise

VM
  └── Domeniu (filtru)
        └── Serviciu intern
              └── Layer
                    └── Rol tehnic
```

Domeniul este dedus din categoria de serviciu a serviciului și nu este duplicat în `vm_internal_service_assignments`. Backendul verifică existența serviciului și relația globală layer–rol.

## Interfață

- pe fișa VM, domeniul filtrează lista serviciilor;
- layer-ul filtrează lista rolurilor tehnice;
- în Nomenclatoare, layer-ele unui rol se aleg dintr-un selector multiplu cu căutare, complet offline;
- rolurile sunt ordonate după ordinea layer-ului, apoi după ordinea rolului;
- în pagina serviciului, perechile layer–rol și numărul de VM-uri apar automat.

## Baza de date

Nu există o migrare nouă de schemă. Tabelul istoric `internal_service_role_mappings` rămâne în bază pentru compatibilitate cu rollback-ul, dar aplicația 0.3.8 nu îl mai utilizează. Nu îl ștergeți manual înainte de încheierea perioadei de validare.

## Pași

1. Faceți backup la MariaDB, configurație și binarele active.
2. Aplicați update-ul 0.3.8 peste o copie a sursei 0.3.7 care conține directorul `vendor/`.
3. Executați testele și build-ul offline.
4. Opriți `vm-doc-collector` și `vm-doc-server`.
5. Înlocuiți binarele.
6. Porniți mai întâi serverul, apoi collectorul.
7. Faceți `Ctrl+F5` în browser.

## Verificare

- adăugarea unui rol tehnic permite căutarea și selectarea mai multor layer-e;
- lista rolurilor respectă ordinea layer-elor și ordinea rolurilor;
- pe VM, alegerea domeniului filtrează serviciile;
- alegerea layer-ului filtrează rolurile;
- o pereche layer–rol invalidă este respinsă de API;
- pagina serviciului nu mai are formular de configurare layer–rol și afișează automat datele VM-urilor.
