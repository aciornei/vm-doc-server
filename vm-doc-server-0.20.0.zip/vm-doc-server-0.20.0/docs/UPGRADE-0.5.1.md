# Upgrade la vm-doc-server 0.5.1

Versiunea 0.5.1 rafinează fișa DOCX introdusă în 0.5.0.

## Schimbări

- inventarul agentului este prezentat în tabele compacte și filtrate;
- secțiunile Agent și Proxy sunt eliminate din document;
- `uptime_seconds` nu mai este inclus;
- capacitățile de stocare sunt afișate în unități lizibile;
- sunt păstrate numai serviciile active, regulile UFW numbered și conturile relevante;
- tabelele au grilă și lățimi explicite pentru Word și LibreOffice.

## Bază de date

Nu există migrare MariaDB. Tabelele și documentele generate anterior rămân neschimbate. Fișele regenerate după upgrade folosesc noul format.

## Validare

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

După instalare, generați o fișă nouă și verificați în special secțiunile 6.5–6.16.
