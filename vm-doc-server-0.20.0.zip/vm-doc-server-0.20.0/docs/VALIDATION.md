# Validation notes for 0.4.0

În mediul de împachetare au fost efectuate:

- `gofmt` pentru sursele Go modificate;
- verificarea sintaxei JavaScript cu `node --check web/static/js/app.js`;
- parsarea documentului OpenAPI YAML;
- teste unitare țintite pentru catalog și validarea pachetului vCenter;
- verificarea structurii migrării `016_vm_service_classification.up.sql`;
- verificarea integrității arhivelor și aplicarea update-ului incremental peste o copie curată de 0.3.9.

Mediul nu conține directorul `vendor/` complet. Testul integral trebuie executat pe serverul offline:

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Nu au fost efectuate în mediul de împachetare:

- test runtime pe baza MariaDB de producție;
- test de sincronizare cu un vCenter real;
- test de export cu inventarul real de producție.
