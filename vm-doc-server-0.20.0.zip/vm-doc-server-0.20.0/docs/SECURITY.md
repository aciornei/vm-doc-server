# Security

- sesiuni opace stocate în MariaDB;
- cookie `HttpOnly`, `Secure` și `SameSite=Lax`;
- token CSRF pentru operații de modificare;
- OIDC Authorization Code Flow cu state, nonce și PKCE;
- LDAP prin LDAPS sau StartTLS;
- AES-256-GCM pentru fișierul de secrete și tokenurile agenților;
- AAD diferit pentru fiecare agent;
- protecție SSRF prin `collector.allowed_networks`;
- UUID binding după prima colectare reușită;
- limită pentru răspunsul agentului;
- secretele și headerul Authorization nu sunt scrise în audit;
- systemd rulează fără privilegii și cu restricții de filesystem/kernel.

## Citirea persoanelor din Active Directory

Directorul de persoane reutilizează contul bind LDAP configurat pentru autentificare. Contul trebuie limitat la citire în OU-ul configurat prin `auth.ldap.directory.base_dn`. Endpointul de listare necesită `nomenclatures.read`, iar importul necesită `nomenclatures.manage` și token CSRF. La import, serverul recitește DN-urile selectate din LDAP și refuză orice DN aflat în afara OU-ului configurat.
