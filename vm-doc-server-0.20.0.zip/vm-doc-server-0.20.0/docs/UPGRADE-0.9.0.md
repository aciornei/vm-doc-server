# Upgrade la vm-doc-server 0.9.0

Versiunea 0.9.0 introduce servicii comune, dependențe globale și explicite, îmbunătățiri pentru listele Agenți/Servicii și rapoarte de impact.

## Migrare MariaDB

La prima pornire se aplică automat:

```text
024_common_service_dependencies.up.sql
```

Migrarea:

- adaugă nomenclatorul `dependency_type` și valorile inițiale;
- extinde `internal_services` cu `is_common`, `implicit_global` și `common_dependency_type_id`;
- creează `internal_service_dependencies` pentru relații Serviciu → Serviciu comun;
- creează `vm_common_service_dependencies` pentru excepții declarate direct pe un VM.

Datele și asocierile existente nu sunt modificate. Toate serviciile existente rămân servicii normale (`is_common=0`).

## Înainte de upgrade

```bash
sudo systemctl stop vm-doc-collector vm-doc-server
```

Faceți backup la MariaDB, configurație și binarele 0.8.0.

## După upgrade

Porniți mai întâi serverul și verificați aplicarea migrării:

```bash
sudo systemctl start vm-doc-server
sudo journalctl -u vm-doc-server -n 100 --no-pager
```

Apoi porniți collectorul:

```bash
sudo systemctl start vm-doc-collector
```

Verificați în UI:

1. Nomenclatoare → **Tip dependență**;
2. Servicii → un serviciu poate fi marcat **Serviciu comun** și, opțional, **Global implicit**;
3. într-un serviciu aplicație poate fi adăugată o dependență către un serviciu comun;
4. fișa unui VM asociat moștenește dependența;
5. Rapoarte afișează analiza de impact.

Pentru servicii precum DNS care se aplică tuturor serviciilor, marcați `Global implicit`. Pentru OpenLDAP/AD care nu sunt folosite universal, lăsați global dezactivat și creați numai relațiile necesare.
