# Upgrade vm-doc-server 0.3.4 → 0.3.5

Versiunea 0.3.5 este un hotfix pentru endpointul `GET /api/v1/vms/{id}`.

După instalare, versiunea reală poate fi verificată cu:

```bash
curl -s http://127.0.0.1:9080/version
```

În cazul unei probleme, jurnalul va conține una dintre etapele:

- `stage=vm`
- `stage=operational`
- `stage=backup`
- `stage=agent`
- `stage=inventory`
- `stage=inventory_document`

Erorile din datele operaționale și backup sunt nefatale; pagina VM se încarcă parțial și afișează un avertisment.
