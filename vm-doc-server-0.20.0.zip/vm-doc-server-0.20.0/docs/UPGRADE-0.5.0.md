# Upgrade la vm-doc-server 0.5.0

Versiunea 0.5.0 introduce generarea fișei tehnice a VM-ului în format DOCX.

## Migrare MariaDB

La prima pornire, serverul aplică:

```text
018_document_generation.up.sql
```

Migrarea creează:

- `document_templates` — șabloanele DOCX;
- `generated_documents` — fișele generate și metadatele lor;
- permisiunile `documents.read` și `documents.manage`.

După migrare, aplicația creează automat șablonul implicit **Fișă tehnică VM standard**, dacă nu există încă niciun șablon.

## Înainte de upgrade

```bash
sudo systemctl stop vm-doc-collector vm-doc-server
```

Faceți backup pentru binare, configurație și baza MariaDB. Migrarea este structurală.

## După pornire

Verificați:

```bash
sudo journalctl -u vm-doc-server -n 120 --no-pager
```

În interfață:

1. deschideți meniul **Documente**;
2. verificați existența șablonului implicit;
3. deschideți un VM;
4. folosiți **Previzualizează datele**;
5. generați DOCX și verificați istoricul documentelor.

## Rollback

Revenirea numai la binarul 0.4.4 nu este suficientă pentru eliminarea tabelelor noi. Binarul 0.4.4 poate funcționa cu tabelele suplimentare rămase, dar pentru rollback complet restaurați backupul MariaDB realizat înainte de upgrade.
