# Upgrade la vm-doc-server 0.7.3

Versiunea 0.7.3 este un hotfix pentru editorul rich-text introdus în 0.7.2.

## Schimbare

Câmpurile **Scop și domeniu** și **Obiective** nu mai sunt învelite într-un element HTML `label`. În 0.7.2, clickul în zona `contenteditable` putea activa primul control etichetabil din interior, butonul **Bold**.

0.7.3 păstrează focusul direct în editor și nu modifică modelul rich-text, API-ul sau datele salvate.

## Baza de date

Nu există migrare MariaDB nouă pentru 0.7.3.

## Verificare

1. Deschide editarea unui Serviciu intern.
2. Click în zona **Scop și domeniu** și tastează text.
3. Repetă în **Obiective**.
4. Verifică Bold, Italic, Underline, bullets și numerotarea.
5. Salvează, redeschide serviciul și generează DOCX pentru confirmarea persistenței formatării.
