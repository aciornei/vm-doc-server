# Upgrade la vm-doc-server 0.10.0

Versiunea 0.10.0 adaugă servicii software principale selectabile din inventarul agentului și îmbunătățește prezentarea datelor colectate.

## Migrare MariaDB

La prima pornire serverul aplică:

```text
025_vm_primary_agent_services.up.sql
```

Migrarea creează tabela `vm_primary_agent_services`. Nu modifică snapshoturile de inventar existente.

## Compatibilitate agent

Serverul rămâne compatibil cu inventarele existente. Pentru versiuni software/pachet în lista serviciilor este recomandat `vm-doc-agent 1.3.1+`. Un agent mai vechi continuă să funcționeze, iar componentele principale pot fi selectate, însă câmpurile de versiune pot rămâne necompletate.

## După upgrade

1. deschide o fișă VM și secțiunea **Date colectate de agent → Servicii**;
2. marchează unul sau mai multe servicii ca **Principal**;
3. generează fișa VM și verifică secțiunea **Componente software principale**;
4. generează fișa Serviciului intern și verifică agregarea componentelor VM-urilor.

Selecția unui serviciu principal este persistentă între colectări. Dacă serviciul dispare din inventarul curent, rămâne selectat și este semnalat ca nedetectat.
