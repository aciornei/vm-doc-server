# Upgrade vm-doc-server 0.3.2 → 0.3.3

Versiunea 0.3.3 schimbă doar backendul API și interfața web. Nu adaugă migrare SQL.

## Modificări

- toate secțiunile din „Date colectate de agent” pornesc restrânse;
- istoricul inventarelor este încărcat paginat;
- pagina Audit este încărcată paginat;
- API-urile folosesc parametrii `page` și `page_size`;
- este inclusă corecția de compilare `nullableInt64Ptr` necesară sursei inițiale 0.3.2.

## Instalare

```bash
cp -a /usr/local/src/vm-doc-server-0.3.2 \
      /usr/local/src/vm-doc-server-0.3.3

tar -xzf vm-doc-server-0.3.3-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.3.3

cd /usr/local/src/vm-doc-server-0.3.3
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

După înlocuirea binarelor și restart, reîncărcați interfața cu `Ctrl+F5`.

## Compatibilitate API

Răspunsurile următoare nu mai sunt liste JSON simple, ci obiecte paginate:

- `GET /api/v1/vms/{id}/inventories`
- `GET /api/v1/audit/events`

Formatul este:

```json
{
  "items": [],
  "page": 1,
  "page_size": 20,
  "total": 0,
  "pages": 0
}
```
