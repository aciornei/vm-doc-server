# Upgrade la vm-doc-server 0.4.4

Versiunea 0.4.4 uniformizează ordonarea ierarhică și adaugă filtre pe toate paginile din Nomenclatoare.

## Ordonare

- valorile fără părinte: `Ordine → Denumire`;
- valorile cu părinte: `Ordinea părintelui → Denumirea părintelui → Ordinea valorii → Denumirea valorii`;
- categoriile de serviciu sunt grupate după domeniul arhitectural;
- rolurile tehnice sunt grupate după primul layer în ordinea layer-elor, apoi după ordinea rolului;
- valorile cu relații lipsă sau nemapate sunt afișate la final;
- Persoanele sunt ordonate după departament și apoi după nume.

## Filtre

Fiecare nomenclator are:

- căutare în denumire, cod, descriere și relația părinte;
- filtru Active / Inactive;
- filtru după domeniu pentru Categoriile de serviciu;
- filtru după layer pentru Rolurile tehnice;
- pentru Persoane: căutare, departament, sursă și stare.

Paginarea se recalculează după aplicarea filtrelor. Exportul Excel conține în continuare toate valorile active și inactive și respectă ordinea ierarhică.

## Baza de date

Nu există migrare MariaDB în această versiune.

## Verificare

1. Deschide fiecare pagină din Nomenclatoare.
2. Verifică ordinea domeniilor și a categoriilor de serviciu.
3. Verifică ordinea layer-elor și a rolurilor tehnice.
4. Aplică filtrele, schimbă pagina și resetează filtrele.
5. Exportă în Excel și verifică ordinea completă.
