# Schema logică a Serviciului intern

Schema este calculată în timp real din `service.vms`, adică din asocierile VM–Serviciu intern–Layer–Rol tehnic. Nu există o configurație paralelă care să poată deveni inconsistentă.

## Reguli

1. Un `vm_id` produce exact un nod vizual.
2. Toate asocierile acelui VM pentru serviciul curent sunt afișate în interiorul nodului.
3. Dacă VM-ul are un singur layer, nodul este plasat în coloana acelui layer.
4. Dacă VM-ul are asocieri în mai multe layere, nodul este plasat în **Multi-layer**.
5. Fiecare asociere afișează rolul tehnic, layer-ul, tipul soluției și Domeniu/Categorie.
6. `icon_key` din nomenclator controlează pictograma. Valorile necunoscute primesc o pictogramă generică.

Schema este intenționat o vedere logică. Relațiile de dependență direcționale între noduri (de exemplu proxy → aplicație → DB) vor putea fi adăugate ulterior fără a schimba modelul actual.

## Infrastructură comună în schemă (0.9.0)

Dependențele comune sunt afișate într-o zonă separată de VM-urile proprii serviciului. Nodul unei dependențe arată serviciul comun, tipul relației și VM-urile care îl furnizează. Serviciile globale sunt marcate distinct.

VM-urile serviciului consumator continuă să apară o singură dată chiar dacă au mai multe asocieri/layer-e.
