# Upgrade la vm-doc-server 0.7.2

Versiunea 0.7.2 introduce editare rich-text pentru câmpurile **Scop și domeniu** și **Obiective** ale Serviciului intern și păstrează formatarea în fișa DOCX.

## Migrare MariaDB

La prima pornire serverul aplică:

```text
022_service_rich_text.up.sql
```

Migrarea adaugă:

```text
internal_services.purpose_richtext
internal_services.objectives_richtext
```

Coloanele existente `purpose` și `objectives` nu sunt șterse și nu sunt rescrise de migrare. Ele rămân reprezentarea plain-text pentru compatibilitate API, căutare și placeholdere scalare.

## Compatibilitate cu datele existente

Pentru serviciile create înainte de 0.7.2, dacă noile coloane rich-text sunt goale, aplicația construiește automat documentul rich-text din textul existent. Rândurile de forma `- text`, `* text`, `• text` și `1. text` sunt recunoscute ca liste. La prima salvare din noul editor se persistă și structura rich-text.

## Editorul rich-text

Sunt suportate intenționat numai elementele necesare documentației tehnice:

- paragrafe și newline;
- bold, italic și underline;
- liste cu bullets;
- liste numerotate;
- până la 4 niveluri de indentare.

Conținutul nu este stocat ca HTML. Browserul trimite un document JSON restricționat, iar serverul îl validează și generează separat forma plain-text.

## DOCX

Secțiunile **Scop și domeniu** și **Obiective** din corpul `{{SERVICE_DOCUMENT_BODY}}` păstrează formatarea. Placeholderele scalare `{{service.scope_domain}}`, `{{service.purpose}}` și `{{service.objectives}}` rămân plain-text, deoarece pot fi amplasate oriunde în șabloanele Word existente.

## Verificare după upgrade

1. Deschideți un Serviciu intern existent. Textul vechi trebuie să apară în editor.
2. Aplicați bold/italic/underline și creați o listă cu bullets sau numerotată.
3. Salvați și redeschideți serviciul; formatarea trebuie păstrată.
4. Generați fișa DOCX; secțiunile narative trebuie să reproducă aceeași structură și aceleași stiluri.
