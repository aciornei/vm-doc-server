# Upgrade la vm-doc-server 0.4.3

Versiunea 0.4.3 adaugă paginare și export Excel în pagina Nomenclatoare.

## Modificări

- paginare locală pentru fiecare listă, cu 10, 20, 50 sau 100 de rânduri;
- export `.xlsx` pentru domenii, categorii de serviciu, layer-e, roluri tehnice, medii, statusuri, clasificări și persoane;
- exporturile conțin toate valorile, inclusiv cele inactive;
- relațiile dintre nomenclatoare sunt incluse în coloane dedicate.

## Baza de date

Nu există migrare MariaDB în această versiune.

## Verificare

1. Deschide fiecare secțiune din Nomenclatoare.
2. Schimbă dimensiunea paginii și navighează între pagini.
3. Folosește butonul **Export Excel** și verifică fișierul descărcat.
