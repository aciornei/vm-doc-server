# Upgrade 0.2.1 -> 0.2.2

## 1. Backup

```bash
mysqldump --single-transaction vm_doc > /root/vm_doc-before-0.2.2.sql
cp -a /etc/vm-doc-server /etc/vm-doc-server.backup-0.2.1
```

## 2. Configurație

Adaugă în `config.yaml`:

```yaml
agent_registration:
  enabled: true
  max_request_body_bytes: 26214400
```

Dacă API-ul local al agentului este HTTP:

```yaml
collector:
  allow_http: true
```

## 3. Secret

În YAML-ul de secrete adaugă:

```yaml
agent_registration_token: "TOKEN_RANDOM_DE_MINIMUM_32_CARACTERE"
```

Regenerează `secrets.enc` cu aceeași cheie master și cu utilitarul
`tools/encrypt-secrets`/procedura folosită la instalarea 0.2.1.

## 4. Build offline

Versiunea 0.2.2 nu adaugă module Go. Directorul `vendor` din 0.2.1 poate fi
păstrat.

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

## 5. Instalare

```bash
systemctl stop vm-doc-collector vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
install -m 0755 bin/vm-doc-collector /opt/vm-doc-server/bin/vm-doc-collector
systemctl start vm-doc-server
curl -s http://127.0.0.1:9080/version
systemctl start vm-doc-collector
```

La pornire se aplică migrarea `010_agent_registration.up.sql`.
