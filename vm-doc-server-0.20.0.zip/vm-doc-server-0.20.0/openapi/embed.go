package openapi

import "embed"

// Files contains the OpenAPI contract.
//
//go:embed openapi.yaml
var Files embed.FS
