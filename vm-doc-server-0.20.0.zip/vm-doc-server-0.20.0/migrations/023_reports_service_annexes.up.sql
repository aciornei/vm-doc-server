-- 0.8.0: rapoarte, evidențiere medii și anexe VM pentru fișele serviciilor interne.

CREATE TABLE IF NOT EXISTS service_document_annexes (
  service_document_id BIGINT UNSIGNED NOT NULL,
  vm_id BIGINT UNSIGNED NOT NULL,
  vm_document_id BIGINT UNSIGNED NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (service_document_id, vm_id),
  UNIQUE KEY uq_service_document_annex_vm_document (service_document_id, vm_document_id),
  KEY idx_service_document_annex_vm (vm_id),
  KEY idx_service_document_annex_document (vm_document_id),
  CONSTRAINT fk_service_document_annex_service_doc FOREIGN KEY (service_document_id) REFERENCES generated_documents(id) ON DELETE CASCADE,
  CONSTRAINT fk_service_document_annex_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_service_document_annex_vm_doc FOREIGN KEY (vm_document_id) REFERENCES generated_documents(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO permissions(name, description) VALUES
 ('reports.read', 'Vizualizare rapoarte și indicatori grafici ai infrastructurii și documentației');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name='admin' AND p.name='reports.read';

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.name='reports.read' WHERE r.name IN ('operator','viewer','auditor');
