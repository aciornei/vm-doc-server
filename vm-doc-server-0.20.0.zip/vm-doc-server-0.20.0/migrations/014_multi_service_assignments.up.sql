-- 0.3.6: multiple service/layer/role assignments per VM.
ALTER TABLE vm_internal_service_assignments
  DROP PRIMARY KEY,
  ADD COLUMN id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST;

ALTER TABLE vm_internal_service_assignments
  ADD COLUMN usage_type VARCHAR(32) NOT NULL DEFAULT 'dedicated' AFTER technical_role_id,
  ADD COLUMN is_primary TINYINT(1) NOT NULL DEFAULT 0 AFTER usage_type,
  ADD COLUMN notes VARCHAR(1000) NOT NULL DEFAULT '' AFTER is_primary,
  ADD COLUMN sort_order INT NOT NULL DEFAULT 0 AFTER notes,
  ADD UNIQUE KEY uq_vm_internal_service_assignment (vm_id,internal_service_id,layer_id,technical_role_id);

-- The former model allowed one assignment only, so preserve it as primary.
UPDATE vm_internal_service_assignments SET is_primary=1 WHERE is_primary=0;

-- Preserve the former manual Retired state as an operational status when no
-- operational status has already been selected.
INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,sort_order,active)
VALUES ('operational_status','Retras','retired','VM retras din exploatare; păstrat pentru istoric sau dezafectare ulterioară.',800,1);

INSERT IGNORE INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
SELECT vm.id,'operational_status',status_item.id
FROM virtual_machines vm
JOIN nomenclature_items status_item ON status_item.category_code='operational_status' AND status_item.item_code='retired'
LEFT JOIN vm_operational_nomenclatures existing_status ON existing_status.vm_id=vm.id AND existing_status.category_code='operational_status'
WHERE vm.retired=1 AND existing_status.vm_id IS NULL;

UPDATE vm_operational_metadata metadata
JOIN virtual_machines vm ON vm.id=metadata.vm_id AND vm.retired=1
SET metadata.operational_status='Retras'
WHERE metadata.operational_status='';

-- Provisioning was removed from the functional model. Remove its selectable
-- nomenclature and clear the legacy display fields while keeping the columns
-- for backward-compatible database upgrades.
DELETE relation
FROM nomenclature_item_parents relation
JOIN nomenclature_items item ON item.id=relation.child_item_id OR item.id=relation.parent_item_id
WHERE item.category_code='provisioning_profile';
DELETE FROM vm_operational_nomenclatures WHERE category_code='provisioning_profile';
DELETE FROM nomenclature_items WHERE category_code='provisioning_profile';
DELETE FROM nomenclature_categories WHERE code='provisioning_profile';
UPDATE vm_operational_metadata SET provisioning_profile='',provisioned_at=NULL;

UPDATE permissions SET description='Administrare asociere agent și date operaționale pentru VM-uri' WHERE name='vms.manage';
