-- 0.7.0: pictograme configurabile pentru nomenclatoare și schema logică a serviciului.
ALTER TABLE nomenclature_items
  ADD COLUMN IF NOT EXISTS icon_key VARCHAR(64) NOT NULL DEFAULT '' AFTER description;

UPDATE nomenclature_items SET icon_key='domain' WHERE category_code='architectural_domain' AND icon_key='';
UPDATE nomenclature_items SET icon_key='category' WHERE category_code='itil_category' AND icon_key='';
UPDATE nomenclature_items SET icon_key='layers' WHERE category_code='layer' AND icon_key='';
UPDATE nomenclature_items SET icon_key='role' WHERE category_code='technical_role' AND icon_key='';
UPDATE nomenclature_items SET icon_key='environment' WHERE category_code='environment' AND icon_key='';
UPDATE nomenclature_items SET icon_key='status' WHERE category_code='operational_status' AND icon_key='';
UPDATE nomenclature_items SET icon_key='tag' WHERE category_code='classification' AND icon_key='';
UPDATE nomenclature_items SET icon_key='package' WHERE category_code='solution_type' AND item_code='open_source';
UPDATE nomenclature_items SET icon_key='code' WHERE category_code='solution_type' AND item_code='internal_development';
UPDATE nomenclature_items SET icon_key='store' WHERE category_code='solution_type' AND item_code='commercial';

-- Încercăm să oferim iconițe mai expresive pentru layere/roluri uzuale, fără să
-- presupunem că nomenclatoarele personalizate folosesc exact aceleași denumiri.
UPDATE nomenclature_items SET icon_key='database' WHERE category_code IN ('layer','technical_role') AND (LOWER(name) LIKE '%data%' OR LOWER(name) LIKE '%database%' OR LOWER(name) LIKE '%mariadb%' OR LOWER(name) LIKE '%postgres%');
UPDATE nomenclature_items SET icon_key='app' WHERE category_code IN ('layer','technical_role') AND (LOWER(name) LIKE '%application%' OR LOWER(name) LIKE '%aplica%');
UPDATE nomenclature_items SET icon_key='web' WHERE category_code='technical_role' AND (LOWER(name) LIKE '%web%' OR LOWER(name) LIKE '%proxy%' OR LOWER(name) LIKE '%nginx%' OR LOWER(name) LIKE '%apache%');
UPDATE nomenclature_items SET icon_key='integration' WHERE category_code IN ('layer','technical_role') AND (LOWER(name) LIKE '%integration%' OR LOWER(name) LIKE '%integra%');
UPDATE nomenclature_items SET icon_key='monitor' WHERE category_code IN ('layer','technical_role') AND (LOWER(name) LIKE '%monitor%' OR LOWER(name) LIKE '%prometheus%' OR LOWER(name) LIKE '%grafana%' OR LOWER(name) LIKE '%exporter%');
UPDATE nomenclature_items SET icon_key='shield' WHERE category_code IN ('layer','technical_role') AND (LOWER(name) LIKE '%security%' OR LOWER(name) LIKE '%secur%' OR LOWER(name) LIKE '%auth%');
