CREATE TABLE IF NOT EXISTS nomenclature_categories (
  code VARCHAR(64) NOT NULL,
  label VARCHAR(128) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO nomenclature_categories(code,label,sort_order,active) VALUES
 ('service','Serviciu',10,1),
 ('component','Componentă',20,1),
 ('architectural_domain','Domeniu arhitectural',30,1),
 ('layer','Layer',40,1),
 ('environment','Mediu',50,1),
 ('operational_status','Status operațional',60,1),
 ('provisioning_profile','Profil provisionare',70,1),
 ('classification','Clasificare',80,1);

CREATE TABLE IF NOT EXISTS nomenclature_items (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_code VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  item_code VARCHAR(128) NOT NULL DEFAULT '',
  description TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_nomenclature_category_name (category_code,name),
  KEY idx_nomenclature_category_active (category_code,active,sort_order,name),
  CONSTRAINT fk_nomenclature_item_category FOREIGN KEY (category_code) REFERENCES nomenclature_categories(code),
  CONSTRAINT fk_nomenclature_item_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_nomenclature_item_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vm_operational_nomenclatures (
  vm_id BIGINT UNSIGNED NOT NULL,
  category_code VARCHAR(64) NOT NULL,
  item_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (vm_id,category_code),
  KEY idx_vm_operational_nomenclature_item (item_id),
  CONSTRAINT fk_vm_operational_nomenclature_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_operational_nomenclature_category FOREIGN KEY (category_code) REFERENCES nomenclature_categories(code),
  CONSTRAINT fk_vm_operational_nomenclature_item FOREIGN KEY (item_id) REFERENCES nomenclature_items(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS people (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  display_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL DEFAULT '',
  phone VARCHAR(64) NOT NULL DEFAULT '',
  department VARCHAR(255) NOT NULL DEFAULT '',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_people_name_email (display_name,email),
  KEY idx_people_active_name (active,display_name),
  CONSTRAINT fk_people_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_people_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vm_responsibilities (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  person_id BIGINT UNSIGNED NOT NULL,
  responsibility_type VARCHAR(64) NOT NULL,
  notes VARCHAR(512) NOT NULL DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_vm_responsibility (vm_id,person_id,responsibility_type),
  KEY idx_vm_responsibility_person (person_id),
  CONSTRAINT fk_vm_responsibility_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_responsibility_person FOREIGN KEY (person_id) REFERENCES people(id),
  CONSTRAINT fk_vm_responsibility_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vm_backup_summary (
  vm_id BIGINT UNSIGNED NOT NULL,
  provider VARCHAR(32) NOT NULL DEFAULT 'veeam',
  source_name VARCHAR(255) NOT NULL DEFAULT '',
  protected TINYINT(1) NOT NULL DEFAULT 0,
  job_name VARCHAR(255) NOT NULL DEFAULT '',
  policy_name VARCHAR(255) NOT NULL DEFAULT '',
  repository_name VARCHAR(255) NOT NULL DEFAULT '',
  last_result VARCHAR(64) NOT NULL DEFAULT '',
  last_backup_at DATETIME(6) NULL,
  next_run_at DATETIME(6) NULL,
  restore_points INT UNSIGNED NULL,
  rpo_minutes INT UNSIGNED NULL,
  rto_minutes INT UNSIGNED NULL,
  synced_at DATETIME(6) NULL,
  error_message TEXT NOT NULL,
  raw_json LONGTEXT NULL,
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (vm_id),
  CONSTRAINT fk_vm_backup_summary_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO nomenclature_items(category_code,name,description)
SELECT 'service',service_name,'' FROM vm_operational_metadata WHERE service_name<>'' GROUP BY service_name;
INSERT IGNORE INTO nomenclature_items(category_code,name,description)
SELECT 'component',component_name,'' FROM vm_operational_metadata WHERE component_name<>'' GROUP BY component_name;
INSERT IGNORE INTO nomenclature_items(category_code,name,description)
SELECT 'architectural_domain',architectural_domain,'' FROM vm_operational_metadata WHERE architectural_domain<>'' GROUP BY architectural_domain;
INSERT IGNORE INTO nomenclature_items(category_code,name,description)
SELECT 'layer',layer_name,'' FROM vm_operational_metadata WHERE layer_name<>'' GROUP BY layer_name;
INSERT IGNORE INTO nomenclature_items(category_code,name,description)
SELECT 'environment',environment,'' FROM vm_operational_metadata WHERE environment<>'' GROUP BY environment;
INSERT IGNORE INTO nomenclature_items(category_code,name,description)
SELECT 'operational_status',operational_status,'' FROM vm_operational_metadata WHERE operational_status<>'' GROUP BY operational_status;
INSERT IGNORE INTO nomenclature_items(category_code,name,description)
SELECT 'provisioning_profile',provisioning_profile,'' FROM vm_operational_metadata WHERE provisioning_profile<>'' GROUP BY provisioning_profile;
INSERT IGNORE INTO nomenclature_items(category_code,name,description)
SELECT 'classification',classification,'' FROM vm_operational_metadata WHERE classification<>'' GROUP BY classification;

INSERT IGNORE INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
SELECT m.vm_id,'service',n.id FROM vm_operational_metadata m JOIN nomenclature_items n ON n.category_code='service' AND n.name=m.service_name WHERE m.service_name<>'';
INSERT IGNORE INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
SELECT m.vm_id,'component',n.id FROM vm_operational_metadata m JOIN nomenclature_items n ON n.category_code='component' AND n.name=m.component_name WHERE m.component_name<>'';
INSERT IGNORE INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
SELECT m.vm_id,'architectural_domain',n.id FROM vm_operational_metadata m JOIN nomenclature_items n ON n.category_code='architectural_domain' AND n.name=m.architectural_domain WHERE m.architectural_domain<>'';
INSERT IGNORE INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
SELECT m.vm_id,'layer',n.id FROM vm_operational_metadata m JOIN nomenclature_items n ON n.category_code='layer' AND n.name=m.layer_name WHERE m.layer_name<>'';
INSERT IGNORE INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
SELECT m.vm_id,'environment',n.id FROM vm_operational_metadata m JOIN nomenclature_items n ON n.category_code='environment' AND n.name=m.environment WHERE m.environment<>'';
INSERT IGNORE INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
SELECT m.vm_id,'operational_status',n.id FROM vm_operational_metadata m JOIN nomenclature_items n ON n.category_code='operational_status' AND n.name=m.operational_status WHERE m.operational_status<>'';
INSERT IGNORE INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
SELECT m.vm_id,'provisioning_profile',n.id FROM vm_operational_metadata m JOIN nomenclature_items n ON n.category_code='provisioning_profile' AND n.name=m.provisioning_profile WHERE m.provisioning_profile<>'';
INSERT IGNORE INTO vm_operational_nomenclatures(vm_id,category_code,item_id)
SELECT m.vm_id,'classification',n.id FROM vm_operational_metadata m JOIN nomenclature_items n ON n.category_code='classification' AND n.name=m.classification WHERE m.classification<>'';

INSERT IGNORE INTO people(display_name,email)
SELECT technical_admin,'' FROM vm_operational_metadata WHERE technical_admin<>'' GROUP BY technical_admin;
INSERT IGNORE INTO people(display_name,email)
SELECT business_owner,owner_email FROM vm_operational_metadata WHERE business_owner<>'' GROUP BY business_owner,owner_email;

INSERT IGNORE INTO vm_responsibilities(vm_id,person_id,responsibility_type)
SELECT m.vm_id,p.id,'technical_admin' FROM vm_operational_metadata m JOIN people p ON p.display_name=m.technical_admin AND p.email='' WHERE m.technical_admin<>'';
INSERT IGNORE INTO vm_responsibilities(vm_id,person_id,responsibility_type)
SELECT m.vm_id,p.id,'service_owner' FROM vm_operational_metadata m JOIN people p ON p.display_name=m.business_owner AND p.email=m.owner_email WHERE m.business_owner<>'';

INSERT IGNORE INTO vm_backup_summary(vm_id,provider,protected,policy_name,rpo_minutes,rto_minutes,error_message)
SELECT vm_id,'manual',IF(backup_policy<>'',1,0),backup_policy,rpo_minutes,rto_minutes,''
FROM vm_operational_metadata
WHERE backup_policy<>'' OR rpo_minutes IS NOT NULL OR rto_minutes IS NOT NULL;

INSERT IGNORE INTO permissions(name, description) VALUES
 ('nomenclatures.read', 'Vizualizare nomenclatoare și persoane'),
 ('nomenclatures.manage', 'Administrare nomenclatoare și persoane');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name='admin' AND p.name IN ('nomenclatures.read','nomenclatures.manage');
INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name IN ('operator','viewer','auditor') AND p.name='nomenclatures.read';
