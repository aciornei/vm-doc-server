-- 0.9.0 · servicii comune / dependențe globale

INSERT IGNORE INTO nomenclature_categories(code,label,sort_order,active)
VALUES ('dependency_type','Tip dependență',95,1);

INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,icon_key,sort_order,active) VALUES
('dependency_type','Autentificare','authentication','Serviciu folosit pentru autentificarea utilizatorilor sau sistemelor.','shield',10,1),
('dependency_type','Directory / Identity','directory_identity','Director de identități, LDAP sau Active Directory.','domain',20,1),
('dependency_type','DNS / Name resolution','dns','Rezoluție de nume DNS.','web',30,1),
('dependency_type','NTP / Time','ntp','Sincronizare timp.','status',40,1),
('dependency_type','PKI / Certificate Authority','pki','Certificate digitale și infrastructură PKI.','shield',50,1),
('dependency_type','SMTP / Mail relay','smtp_relay','Transmitere e-mail / relay SMTP.','integration',60,1),
('dependency_type','Proxy','proxy','Proxy de ieșire sau reverse proxy comun.','integration',70,1),
('dependency_type','Logging / Syslog','logging','Colectare centralizată de loguri.','monitor',80,1),
('dependency_type','Monitoring','monitoring','Monitorizare comună a serviciului.','monitor',90,1),
('dependency_type','Backup','backup','Serviciu comun de backup și restaurare.','store',100,1),
('dependency_type','Storage','storage','Stocare comună sau partajată.','store',110,1),
('dependency_type','Database','database','Bază de date furnizată de alt serviciu.','database',120,1),
('dependency_type','Cache','cache','Cache comun.','database',130,1),
('dependency_type','Message broker','message_broker','Mesagerie / broker comun.','integration',140,1),
('dependency_type','API / integrare','api_integration','API sau integrare cu alt serviciu.','integration',150,1),
('dependency_type','Alt serviciu','other_service','Altă dependență tehnică sau funcțională.','package',999,1);

ALTER TABLE internal_services
  ADD COLUMN IF NOT EXISTS is_common TINYINT(1) NOT NULL DEFAULT 0 AFTER active,
  ADD COLUMN IF NOT EXISTS implicit_global TINYINT(1) NOT NULL DEFAULT 0 AFTER is_common,
  ADD COLUMN IF NOT EXISTS common_dependency_type_id BIGINT UNSIGNED NULL AFTER implicit_global;

ALTER TABLE internal_services
  ADD INDEX IF NOT EXISTS idx_internal_service_common (is_common,implicit_global);

SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA=DATABASE()
     AND TABLE_NAME='internal_services'
     AND CONSTRAINT_NAME='fk_internal_service_common_dependency_type')=0,
  'ALTER TABLE internal_services ADD CONSTRAINT fk_internal_service_common_dependency_type FOREIGN KEY (common_dependency_type_id) REFERENCES nomenclature_items(id)',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS internal_service_dependencies (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  source_service_id BIGINT UNSIGNED NOT NULL,
  target_service_id BIGINT UNSIGNED NOT NULL,
  dependency_type_id BIGINT UNSIGNED NOT NULL,
  notes VARCHAR(1000) NOT NULL DEFAULT '',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_internal_service_dependency (source_service_id,target_service_id,dependency_type_id),
  KEY idx_service_dependency_source (source_service_id,active),
  KEY idx_service_dependency_target (target_service_id,active),
  CONSTRAINT fk_service_dependency_source FOREIGN KEY (source_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_service_dependency_target FOREIGN KEY (target_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_service_dependency_type FOREIGN KEY (dependency_type_id) REFERENCES nomenclature_items(id),
  CONSTRAINT fk_service_dependency_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_service_dependency_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vm_common_service_dependencies (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  target_service_id BIGINT UNSIGNED NOT NULL,
  dependency_type_id BIGINT UNSIGNED NOT NULL,
  notes VARCHAR(1000) NOT NULL DEFAULT '',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_vm_common_service_dependency (vm_id,target_service_id,dependency_type_id),
  KEY idx_vm_common_dependency_vm (vm_id,active),
  CONSTRAINT fk_vm_common_dependency_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_common_dependency_target FOREIGN KEY (target_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_common_dependency_type FOREIGN KEY (dependency_type_id) REFERENCES nomenclature_items(id),
  CONSTRAINT fk_vm_common_dependency_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_vm_common_dependency_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
