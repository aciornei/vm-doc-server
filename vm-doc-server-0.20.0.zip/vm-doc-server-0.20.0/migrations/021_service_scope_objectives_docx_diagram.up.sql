-- 0.7.1 · conținut funcțional pentru serviciul intern
-- `purpose` este păstrat pentru compatibilitate și reprezintă în UI „Scop și domeniu”.
ALTER TABLE internal_services
  ADD COLUMN objectives TEXT NOT NULL AFTER purpose;
