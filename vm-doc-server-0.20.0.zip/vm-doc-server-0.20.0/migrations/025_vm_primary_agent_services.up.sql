-- 0.10.0 · servicii software principale selectate din inventarul agentului

CREATE TABLE IF NOT EXISTS vm_primary_agent_services (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  service_name VARCHAR(255) NOT NULL,
  selected_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_vm_primary_agent_service (vm_id,service_name),
  KEY idx_vm_primary_agent_services_vm (vm_id),
  CONSTRAINT fk_vm_primary_agent_services_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_primary_agent_services_user FOREIGN KEY (selected_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
