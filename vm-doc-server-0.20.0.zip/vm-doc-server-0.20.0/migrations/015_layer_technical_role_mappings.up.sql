CREATE TABLE IF NOT EXISTS layer_technical_role_mappings (
  layer_id BIGINT UNSIGNED NOT NULL,
  technical_role_id BIGINT UNSIGNED NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (layer_id,technical_role_id),
  KEY idx_layer_technical_role_role (technical_role_id,layer_id),
  CONSTRAINT fk_layer_technical_role_layer FOREIGN KEY (layer_id) REFERENCES nomenclature_items(id) ON DELETE CASCADE,
  CONSTRAINT fk_layer_technical_role_role FOREIGN KEY (technical_role_id) REFERENCES nomenclature_items(id) ON DELETE CASCADE,
  CONSTRAINT fk_layer_technical_role_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Preserve every layer-role pair already configured on an internal service.
INSERT IGNORE INTO layer_technical_role_mappings(layer_id,technical_role_id,created_by)
SELECT DISTINCT mapping.layer_id,mapping.technical_role_id,mapping.created_by
FROM internal_service_role_mappings mapping
JOIN nomenclature_items layer_item ON layer_item.id=mapping.layer_id AND layer_item.category_code='layer'
JOIN nomenclature_items role_item ON role_item.id=mapping.technical_role_id AND role_item.category_code='technical_role';

-- Also preserve pairs that may exist only on migrated VM assignments.
INSERT IGNORE INTO layer_technical_role_mappings(layer_id,technical_role_id,created_by)
SELECT DISTINCT assignment.layer_id,assignment.technical_role_id,assignment.updated_by
FROM vm_internal_service_assignments assignment
JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id AND layer_item.category_code='layer'
JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id AND role_item.category_code='technical_role'
WHERE assignment.layer_id IS NOT NULL AND assignment.technical_role_id IS NOT NULL;
