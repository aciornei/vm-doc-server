INSERT IGNORE INTO nomenclature_categories(code,label,sort_order,active) VALUES
 ('itil_category','Categorie ITIL',20,1),
 ('technical_role','Rol tehnic',40,1);

UPDATE nomenclature_categories SET label='Domeniu arhitectural',sort_order=10,active=1 WHERE code='architectural_domain';
UPDATE nomenclature_categories SET label='Layer',sort_order=30,active=1 WHERE code='layer';
UPDATE nomenclature_categories SET sort_order=50,active=1 WHERE code='environment';
UPDATE nomenclature_categories SET sort_order=60,active=1 WHERE code='operational_status';
UPDATE nomenclature_categories SET sort_order=70,active=1 WHERE code='provisioning_profile';
UPDATE nomenclature_categories SET sort_order=80,active=1 WHERE code='classification';
UPDATE nomenclature_categories SET label='Serviciu ITIL (legacy)',active=0 WHERE code='service';
UPDATE nomenclature_categories SET label='Componentă (legacy)',active=0 WHERE code='component';

CREATE TABLE IF NOT EXISTS nomenclature_item_parents (
  child_item_id BIGINT UNSIGNED NOT NULL,
  parent_item_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (child_item_id),
  KEY idx_nomenclature_parent (parent_item_id),
  CONSTRAINT fk_nomenclature_parent_child FOREIGN KEY (child_item_id) REFERENCES nomenclature_items(id) ON DELETE CASCADE,
  CONSTRAINT fk_nomenclature_parent_parent FOREIGN KEY (parent_item_id) REFERENCES nomenclature_items(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,sort_order,active)
VALUES ('architectural_domain','Necategorizat','uncategorized','Valoare temporară pentru date migrate care nu aveau domeniu arhitectural.',9999,1);

INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,sort_order,active,created_by,updated_by)
SELECT 'itil_category',name,item_code,description,sort_order,active,created_by,updated_by
FROM nomenclature_items
WHERE category_code='service';

INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,sort_order,active)
VALUES ('itil_category','Necategorizat','uncategorized','Valoare temporară pentru servicii interne migrate fără categorie ITIL.',9999,1);

INSERT IGNORE INTO nomenclature_item_parents(child_item_id,parent_item_id)
SELECT new_category.id,MIN(domain_map.item_id)
FROM vm_operational_nomenclatures service_map
JOIN nomenclature_items old_service ON old_service.id=service_map.item_id AND old_service.category_code='service'
JOIN nomenclature_items new_category ON new_category.category_code='itil_category' AND new_category.name=old_service.name
JOIN vm_operational_nomenclatures domain_map ON domain_map.vm_id=service_map.vm_id AND domain_map.category_code='architectural_domain'
GROUP BY new_category.id;

INSERT IGNORE INTO nomenclature_item_parents(child_item_id,parent_item_id)
SELECT category_item.id,uncategorized_domain.id
FROM nomenclature_items category_item
JOIN nomenclature_items uncategorized_domain ON uncategorized_domain.category_code='architectural_domain' AND uncategorized_domain.name='Necategorizat'
LEFT JOIN nomenclature_item_parents existing_parent ON existing_parent.child_item_id=category_item.id
WHERE category_item.category_code='itil_category' AND existing_parent.child_item_id IS NULL;

CREATE TABLE IF NOT EXISTS internal_services (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  itil_category_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(255) NOT NULL,
  service_code VARCHAR(128) NULL,
  description TEXT NOT NULL,
  purpose TEXT NOT NULL,
  criticality VARCHAR(32) NOT NULL DEFAULT 'normal',
  documentation_status VARCHAR(32) NOT NULL DEFAULT 'draft',
  documentation_url VARCHAR(1024) NOT NULL DEFAULT '',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_internal_service_category_name (itil_category_id,name),
  UNIQUE KEY uq_internal_service_code (service_code),
  KEY idx_internal_service_active (active,name),
  CONSTRAINT fk_internal_service_category FOREIGN KEY (itil_category_id) REFERENCES nomenclature_items(id),
  CONSTRAINT fk_internal_service_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_internal_service_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS internal_service_role_mappings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  internal_service_id BIGINT UNSIGNED NOT NULL,
  layer_id BIGINT UNSIGNED NOT NULL,
  technical_role_id BIGINT UNSIGNED NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_internal_service_role_mapping (internal_service_id,layer_id,technical_role_id),
  KEY idx_internal_service_mapping_layer (layer_id,technical_role_id),
  CONSTRAINT fk_service_mapping_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_service_mapping_layer FOREIGN KEY (layer_id) REFERENCES nomenclature_items(id),
  CONSTRAINT fk_service_mapping_role FOREIGN KEY (technical_role_id) REFERENCES nomenclature_items(id),
  CONSTRAINT fk_service_mapping_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vm_internal_service_assignments (
  vm_id BIGINT UNSIGNED NOT NULL,
  internal_service_id BIGINT UNSIGNED NOT NULL,
  layer_id BIGINT UNSIGNED NULL,
  technical_role_id BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (vm_id),
  KEY idx_vm_service_assignment_service (internal_service_id),
  KEY idx_vm_service_assignment_role (layer_id,technical_role_id),
  CONSTRAINT fk_vm_service_assignment_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_service_assignment_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id),
  CONSTRAINT fk_vm_service_assignment_layer FOREIGN KEY (layer_id) REFERENCES nomenclature_items(id),
  CONSTRAINT fk_vm_service_assignment_role FOREIGN KEY (technical_role_id) REFERENCES nomenclature_items(id),
  CONSTRAINT fk_vm_service_assignment_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO internal_services(itil_category_id,name,description,purpose,criticality,documentation_status,documentation_url,active,created_by,updated_by)
SELECT new_category.id,component_item.name,component_item.description,'','normal','draft','',component_item.active,component_item.created_by,component_item.updated_by
FROM vm_operational_nomenclatures component_map
JOIN nomenclature_items component_item ON component_item.id=component_map.item_id AND component_item.category_code='component'
JOIN vm_operational_nomenclatures service_map ON service_map.vm_id=component_map.vm_id AND service_map.category_code='service'
JOIN nomenclature_items old_service ON old_service.id=service_map.item_id AND old_service.category_code='service'
JOIN nomenclature_items new_category ON new_category.category_code='itil_category' AND new_category.name=old_service.name
GROUP BY new_category.id,component_item.name,component_item.description,component_item.active,component_item.created_by,component_item.updated_by;

INSERT IGNORE INTO internal_services(itil_category_id,name,description,purpose,criticality,documentation_status,documentation_url,active,created_by,updated_by)
SELECT uncategorized_category.id,component_item.name,component_item.description,'','normal','draft','',component_item.active,component_item.created_by,component_item.updated_by
FROM nomenclature_items component_item
JOIN nomenclature_items uncategorized_category ON uncategorized_category.category_code='itil_category' AND uncategorized_category.name='Necategorizat'
WHERE component_item.category_code='component'
  AND NOT EXISTS (SELECT 1 FROM internal_services s WHERE s.name=component_item.name);

INSERT IGNORE INTO vm_internal_service_assignments(vm_id,internal_service_id,layer_id,technical_role_id,updated_by)
SELECT component_map.vm_id,internal_service.id,layer_map.item_id,NULL,metadata.updated_by
FROM vm_operational_nomenclatures component_map
JOIN nomenclature_items component_item ON component_item.id=component_map.item_id AND component_item.category_code='component'
JOIN vm_operational_nomenclatures service_map ON service_map.vm_id=component_map.vm_id AND service_map.category_code='service'
JOIN nomenclature_items old_service ON old_service.id=service_map.item_id AND old_service.category_code='service'
JOIN nomenclature_items new_category ON new_category.category_code='itil_category' AND new_category.name=old_service.name
JOIN internal_services internal_service ON internal_service.itil_category_id=new_category.id AND internal_service.name=component_item.name
LEFT JOIN vm_operational_nomenclatures layer_map ON layer_map.vm_id=component_map.vm_id AND layer_map.category_code='layer'
LEFT JOIN vm_operational_metadata metadata ON metadata.vm_id=component_map.vm_id;

INSERT IGNORE INTO vm_internal_service_assignments(vm_id,internal_service_id,layer_id,technical_role_id,updated_by)
SELECT component_map.vm_id,internal_service.id,layer_map.item_id,NULL,metadata.updated_by
FROM vm_operational_nomenclatures component_map
JOIN nomenclature_items component_item ON component_item.id=component_map.item_id AND component_item.category_code='component'
JOIN nomenclature_items uncategorized_category ON uncategorized_category.category_code='itil_category' AND uncategorized_category.name='Necategorizat'
JOIN internal_services internal_service ON internal_service.itil_category_id=uncategorized_category.id AND internal_service.name=component_item.name
LEFT JOIN vm_operational_nomenclatures layer_map ON layer_map.vm_id=component_map.vm_id AND layer_map.category_code='layer'
LEFT JOIN vm_operational_metadata metadata ON metadata.vm_id=component_map.vm_id
WHERE NOT EXISTS (SELECT 1 FROM vm_internal_service_assignments assignment WHERE assignment.vm_id=component_map.vm_id);

INSERT IGNORE INTO permissions(name,description) VALUES
 ('services.read','Vizualizare catalog servicii interne'),
 ('services.manage','Administrare catalog servicii interne');

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT role_value.id,permission_value.id
FROM roles role_value
JOIN permissions permission_value ON permission_value.name IN ('services.read','services.manage')
WHERE role_value.name IN ('admin','operator');

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT role_value.id,permission_value.id
FROM roles role_value
JOIN permissions permission_value ON permission_value.name='services.read'
WHERE role_value.name IN ('viewer','auditor');
