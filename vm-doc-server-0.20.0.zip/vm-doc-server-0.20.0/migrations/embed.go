package migrations

import "embed"

// Files contains all forward SQL migrations.
//
//go:embed *.up.sql
var Files embed.FS
