INSERT IGNORE INTO permissions(name, description) VALUES
 ('vcenter.read', 'Vizualizare surse și sincronizări vCenter'),
 ('vcenter.manage', 'Administrare și sincronizare vCenter'),
 ('vms.manage', 'Administrare lifecycle și asociere agent pentru VM-uri');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name='admin';

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.name IN ('vcenter.read','vcenter.manage','vms.manage') WHERE r.name='operator';

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.name IN ('vcenter.read') WHERE r.name IN ('viewer','auditor');
