package main

import (
	"context"
	"flag"
	"log/slog"
	"os"
	"os/signal"
	"syscall"
	"time"

	"vm-doc-server/internal/agentclient"
	"vm-doc-server/internal/agents"
	"vm-doc-server/internal/audit"
	"vm-doc-server/internal/buildinfo"
	"vm-doc-server/internal/collection"
	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/database"
	"vm-doc-server/internal/inventory"
	"vm-doc-server/internal/secrets"
	"vm-doc-server/migrations"
)

func main() {
	configPath := flag.String("config", "/etc/vm-doc-server/config.yaml", "configuration file")
	flag.Parse()
	cfg, err := config.Load(*configPath)
	if err != nil {
		fatal("load configuration", err)
	}
	logger := newLogger(cfg.Logging)
	master, err := cryptox.LoadMasterKey(cfg.Secrets.MasterKeyFile, cfg.Secrets.MasterKeyEnv)
	if err != nil {
		fatal("load master key", err)
	}
	box, err := cryptox.New(master)
	if err != nil {
		fatal("initialize encryption", err)
	}
	secretValues, err := secrets.Load(cfg.Secrets, box)
	if err != nil {
		fatal("load secrets", err)
	}
	db, err := database.Open(cfg.Database, secretValues.DatabasePassword)
	if err != nil {
		fatal("open database", err)
	}
	defer db.Close()
	migrateCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	if err := database.Migrate(migrateCtx, db, migrations.Files); err != nil {
		cancel()
		fatal("database migrations", err)
	}
	cancel()
	client, err := agentclient.New(cfg.Collector.AllowedNetworks, cfg.Collector.MaxInventorySize)
	if err != nil {
		fatal("initialize agent client", err)
	}
	agentSvc := agents.Service{DB: db, Box: box, Config: cfg.Collector}
	invSvc := inventory.Service{DB: db}
	auditSvc := audit.Service{DB: db}
	svc := collection.New(db, agentSvc, invSvc, auditSvc, client, cfg, logger)
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	logger.Info("vm-doc-collector started", "version", buildinfo.Version, "workers", cfg.Collector.Workers)
	if err := svc.Run(ctx); err != nil && ctx.Err() == nil {
		fatal("collector", err)
	}
	logger.Info("vm-doc-collector stopped")
}
func newLogger(cfg config.LoggingConfig) *slog.Logger {
	level := slog.LevelInfo
	switch cfg.Level {
	case "debug":
		level = slog.LevelDebug
	case "warn":
		level = slog.LevelWarn
	case "error":
		level = slog.LevelError
	}
	opts := &slog.HandlerOptions{Level: level}
	if cfg.Format == "text" {
		return slog.New(slog.NewTextHandler(os.Stdout, opts))
	}
	return slog.New(slog.NewJSONHandler(os.Stdout, opts))
}
func fatal(message string, err error) { slog.Error(message, "error", err); os.Exit(1) }
