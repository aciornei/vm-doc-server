package web

import "embed"

// Static contains the browser application.
//
//go:embed static
var Static embed.FS
