CREATE TABLE IF NOT EXISTS inventory_change_baselines (
  vm_id BIGINT UNSIGNED NOT NULL,
  inventory_id BIGINT UNSIGNED NOT NULL,
  established_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  established_by BIGINT UNSIGNED NULL,
  source VARCHAR(24) NOT NULL DEFAULT 'manual',
  PRIMARY KEY (vm_id),
  CONSTRAINT fk_inventory_change_baselines_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_inventory_change_baselines_user FOREIGN KEY (established_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La upgrade, starea curentă a fiecărei VM devine baseline. Astfel istoricul
-- existent nu este interpretat drept backlog de modificări ce trebuie triat.
INSERT INTO inventory_change_baselines(vm_id,inventory_id,established_at,established_by,source)
SELECT vm.id,vm.current_inventory_id,UTC_TIMESTAMP(6),NULL,'upgrade'
FROM virtual_machines vm
WHERE vm.current_inventory_id IS NOT NULL
ON DUPLICATE KEY UPDATE
  inventory_id=VALUES(inventory_id),
  established_at=VALUES(established_at),
  established_by=NULL,
  source='upgrade';
