# Upgrade vm-doc-server 0.17.1 → 0.17.2

0.17.2 introduce baseline pentru meniul **Modificări** și reduce zgomotul inițial.

## Pași

1. Opriți `vm-doc-server`.
2. Aplicați `vm-doc-server-0.17.2-update.tar.gz` peste sursa 0.17.1.
3. Recompilați și instalați binarul serverului.
4. Porniți `vm-doc-server`.
5. Verificați în jurnal aplicarea migrației `033_inventory_change_baselines.up.sql`.

La aplicarea migrației, snapshot-ul curent al fiecărei VM existente devine baseline. Modificările deja existente nu sunt șterse; ele sunt ascunse din trierea curentă deoarece sunt anterioare sau egale cu baseline-ul.

În meniul **Modificări** există butonul **Stabilește inventarul curent ca baseline** pentru resetare globală, iar în fila Modificări a unei VM există **Stabilește baseline VM**.

Nu este necesar update de agent pentru această versiune.
