# Upgrade vm-doc-server 0.13.6 -> 0.13.7

Versiunea 0.13.7 este un hotfix pentru auto-inregistrarea unui agent nou.

## Problema rezolvata

In 0.13.6, ramura de INSERT folosita numai la prima inregistrare a unui agent avea 29 de coloane dar numai 28 de valori SQL, iar argumentele pentru `registered_at` / `last_heartbeat_at` erau decalate. Agentii deja existenti foloseau ramura UPDATE si nu erau afectati.

Simptom pe o masina instalata de la zero:

`central server returned HTTP 500: {"error":"internal_error","message":"internal server error"}`

## Ce se schimba

- INSERT-ul pentru `agents` are acum 29 de valori pentru 29 de coloane;
- `registered_at` si `last_heartbeat_at` primesc separat timestamp-ul curent;
- erorile interne de register / heartbeat / inventory push sunt scrise in jurnalul serverului, fara a expune detalii SQL clientului;
- test de regresie pentru egalitatea numarului de coloane si valori din INSERT.

## Upgrade

Nu exista migrare de baza de date.

Opreste serviciile, aplica arhiva de update peste sursa 0.13.6, reconstruieste binarele in mediul offline si reporneste serviciile.

Agentul 1.3.7 nu trebuie modificat pentru acest hotfix.
