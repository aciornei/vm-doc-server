package registration

import (
	"context"
	"database/sql"
	"strings"
	"testing"
	"time"
)

func TestAuthorized(t *testing.T) {
	svc := Service{Token: "registration-token-12345678901234567890"}
	if !svc.Authorized("Bearer registration-token-12345678901234567890") {
		t.Fatal("expected valid bearer token")
	}
	if svc.Authorized("Bearer wrong-token") || svc.Authorized("") {
		t.Fatal("unexpected authorization")
	}
}

func TestValidateRegistration(t *testing.T) {
	svc := Service{AllowHTTPAgents: true}
	request := RegistrationRequest{
		ProtocolVersion: "1",
		Agent:           RegistrationAgent{ID: "agent-1", Version: "1.1.0"},
		Host:            RegistrationHost{Hostname: "vm01"},
		BaseURL:         "http://10.20.30.40:9078",
		AgentToken:      "local-agent-token-1234567890",
	}
	if err := svc.validateRegistration(&request); err != nil {
		t.Fatal(err)
	}
}

func TestDurationOrDefault(t *testing.T) {
	fallback := 15 * time.Minute
	if got := durationOrDefault(300, fallback, time.Minute, time.Hour); got != 5*time.Minute {
		t.Fatalf("unexpected duration %s", got)
	}
	if got := durationOrDefault(1, fallback, time.Minute, time.Hour); got != fallback {
		t.Fatalf("expected fallback, got %s", got)
	}
}

type captureExec struct {
	calls int
	query string
	args  []any
}

type captureResult struct{}

func (captureResult) LastInsertId() (int64, error) { return 0, nil }
func (captureResult) RowsAffected() (int64, error) { return 1, nil }

func (e *captureExec) ExecContext(_ context.Context, query string, args ...any) (sql.Result, error) {
	e.calls++
	e.query = query
	e.args = append([]any(nil), args...)
	return captureResult{}, nil
}

func TestReconcileReportedVersionSkipsEmptyVersion(t *testing.T) {
	exec := &captureExec{}
	if err := reconcileReportedVersion(context.Background(), exec, 17, "   ", time.Now().UTC()); err != nil {
		t.Fatal(err)
	}
	if exec.calls != 0 {
		t.Fatalf("expected no SQL call, got %d", exec.calls)
	}
}

func TestReconcileReportedVersionTargetsCachedAvailableVersion(t *testing.T) {
	exec := &captureExec{}
	now := time.Date(2026, 9, 4, 11, 30, 0, 0, time.UTC)
	if err := reconcileReportedVersion(context.Background(), exec, 17, " 1.3.6 ", now); err != nil {
		t.Fatal(err)
	}
	if exec.calls != 1 {
		t.Fatalf("expected one SQL call, got %d", exec.calls)
	}
	if !strings.Contains(exec.query, "update_state='current'") || !strings.Contains(exec.query, "update_available_version=?") {
		t.Fatalf("unexpected reconciliation query: %s", exec.query)
	}
	if len(exec.args) != 4 || exec.args[2] != int64(17) || exec.args[3] != "1.3.6" {
		t.Fatalf("unexpected reconciliation args: %#v", exec.args)
	}
}

func TestAgentInsertSQLColumnValueCountMatches(t *testing.T) {
	upper := strings.ToUpper(agentInsertSQL)
	valuesAt := strings.Index(upper, ") VALUES(")
	if valuesAt < 0 {
		t.Fatalf("unexpected INSERT syntax: %s", agentInsertSQL)
	}
	columnsStart := strings.Index(agentInsertSQL, "(")
	if columnsStart < 0 || columnsStart >= valuesAt {
		t.Fatalf("cannot locate INSERT columns: %s", agentInsertSQL)
	}
	columns := strings.Split(agentInsertSQL[columnsStart+1:valuesAt], ",")
	valuesStart := valuesAt + len(") VALUES(")
	valuesEnd := strings.LastIndex(agentInsertSQL, ")")
	if valuesEnd <= valuesStart {
		t.Fatalf("cannot locate INSERT values: %s", agentInsertSQL)
	}
	values := strings.Split(agentInsertSQL[valuesStart:valuesEnd], ",")
	if len(columns) != len(values) {
		t.Fatalf("INSERT has %d columns but %d values", len(columns), len(values))
	}
	if got := strings.Count(agentInsertSQL, "?"); got != 20 {
		t.Fatalf("expected 20 placeholders for Register arguments, got %d", got)
	}
}
