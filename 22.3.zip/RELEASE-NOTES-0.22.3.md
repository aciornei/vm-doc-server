# VM-DOC Server 0.22.3 – Raport Integrări și catalogul Rapoarte

**Bază:** 0.22.2 · **Agent:** 1.7.18, neschimbat · **Schema MariaDB:** 087, fără migrare nouă.

## Noutăți

1. Raportul **Integrări** afișează pentru fiecare VM destinația Auditbeat, rezultatul `output_test_ok` (OK/NU/Necunoscut), aceleași date pentru Filebeat, versiunea GLPI Agent, starea serviciului Node Exporter și host/protocol Syslog. Datele sunt luate din ultima colectare; nu se fac probe noi.
2. Filtrare după căutare, sursă vCenter, mediu, Power, OS, status operațional, prezență VCSA, agent (asociat/online/offline/etc.), baseline, serviciu, permisiune/publicare Outline, suport OS și stările integrărilor. Carduri de sumar clicabile, paginare reală a răspunsului și export Excel pentru **toate VM-urile filtrate**.
3. **Rapoarte** deschide un catalog pe categorii, cu descrieri scurte; submeniul individual este grupat și pliabil. Linkurile anterioare `#reports/...` funcționează în continuare.

## Semantica stărilor

`OK`/`NU` pentru dial-up se bazează exclusiv pe rezultatul explicit colectat (`output_test_ok`, alternative compatibile). Faptul că un serviciu rulează sau are o destinație configurată **nu** este dovada conectivității. În absența datelor apare `Necunoscut`. `Node Exporter` reflectă starea serviciului din snapshot, nu statusul Prometheus.

## Compatibilitate

Fără migrare SQL, fără schimbări de agent, fără eliminarea rapoartelor existente. Endpointurile noi sunt protejate cu `reports.read`. VM-urile retrase/arhivate și cele excluse din resource pool nu apar, potrivit inventarului operațional.

## Verificări

- `gofmt`, `go test ./internal/integrationreport ./internal/xlsx` – PASS în mediul offline.
- Compilare/teste Go izolate pentru handlerul nou cu stub-uri – PASS.
- `node --check web/static/js/app.js` și verificare JSON releases – PASS.
- **Nevalidate aici:** build complet cu vendor (dependențe externe indisponibile), MariaDB reală, payloadurile reale 1.7.18, test integrare UI cu backend real.
