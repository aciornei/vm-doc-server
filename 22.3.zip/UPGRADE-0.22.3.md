# Upgrade VM-DOC Server 0.22.2 → 0.22.3

## Pregătire

1. Verifică `cat VERSION` = `0.22.2` în **arborele sursă** (nu în folderul binarului).
2. Fă backup pentru MariaDB, configurație, sursele serverului și binarul din `systemctl cat vm-doc-server` (`ExecStart`).
3. Testează pe staging. **Nu există migrare SQL** și **nu este necesară schimbarea agentului**.

## Instalare incrementală

```bash
cd /CALE/CATRE/SURSE-VM-DOC
unzip -o /CALE/VM-DOC-UPDATE-222-223.zip -d .
cat VERSION  # trebuie să fie 0.22.3
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Instalează binarul rezultat în calea **reală** din `ExecStart`, după oprirea serviciului și salvarea binarului anterior. Repornește și verifică `/version` = `0.22.3`; în browser dă `Ctrl+F5`.

## Test funcțional

1. `Rapoarte` → catalogul cu 5 categorii; verifică accesul la fiecare raport existent.
2. `Rapoarte` → `Monitorizare și integrări` → `Integrări`. Testează PROD/TEST, pornite/oprite/suspendate, vCenter, agent, baseline, serviciu, Outline și filtrele integrărilor.
3. Compară 2–3 VM cunoscute cu detaliile din ultimul snapshot pentru `auditbeat`, `filebeat`, `glpi_agent`, `node_exporter` și `syslog`. Un `output_test_ok` absent trebuie să afișeze `Necunoscut`.
4. Verifică **Export Excel**: toate VM-urile filtrate, inclusiv cele din paginile 2+; compară numărul cu sumarul filtrat.
5. Testează `#reports/overview`, `#reports/security-reviews` și `#reports/pool-vms` pentru regresii.

## Rollback

Înlocuiește binarul și sursele cu 0.22.2 și revino la 0.22.2. Fără rollback SQL.

## Limitări

Build complet și testele MariaDB/agent reale nu pot fi validate aici fără `vendor/` și instanța ta de staging. Nu activa în PROD fără verificare.
