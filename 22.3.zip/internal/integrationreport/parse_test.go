package integrationreport

import "testing"

func TestParse(t *testing.T) {
	v := Parse([]byte(`{"integrations":{"auditbeat":{"installed":true,"output_host":"10.0.0.1:5044","output_test_ok":true},"filebeat":{"output_hosts":["10.0.0.2:5044"],"output_test_ok":false},"glpi_agent":{"package_version":"1.15","service_active":"running"},"node_exporter":{"installed":true,"service_active":"active"},"syslog":{"destinations":[{"host":"log01:514","protocol":"tcp"},{"host":"log02:514","protocol":"udp"}]}}}`))
	if v.AuditbeatIP != "10.0.0.1:5044" || v.AuditbeatDial != "OK" || v.FilebeatDial != "NU" || v.GLPIVersion != "1.15" || v.NodeExporter != "OK" || v.SyslogProtocol != "tcp, udp" || v.SyslogStatus != "OK" {
		t.Fatalf("bad parse: %+v", v)
	}
}
func TestUnknownIsNotFailure(t *testing.T) {
	v := Parse([]byte(`{"integrations":{"auditbeat":{"installed":true,"output_host":"10.0.0.1"},"node_exporter":{"installed":false}}}`))
	if v.AuditbeatDial != "Necunoscut" || v.NodeExporter != "NU" {
		t.Fatalf("unexpected: %+v", v)
	}
}
func TestMissing(t *testing.T) {
	v := Parse(nil)
	if v.FilebeatDial != "Necunoscut" || v.NodeExporter != "Necunoscut" || v.SyslogStatus != "Necunoscut" {
		t.Fatalf("unexpected: %+v", v)
	}
}
