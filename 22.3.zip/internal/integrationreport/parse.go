// Package integrationreport reads the integration section of VM-DOC agent
// snapshots. A missing probe result is unknown, never a failed dial-up.
package integrationreport

import (
	"encoding/json"
	"fmt"
	"sort"
	"strings"
)

type Details struct {
	AuditbeatIP    string `json:"auditbeat_ip"`
	AuditbeatDial  string `json:"auditbeat_dial"`
	FilebeatIP     string `json:"filebeat_ip"`
	FilebeatDial   string `json:"filebeat_dial"`
	GLPIVersion    string `json:"glpi_version"`
	GLPIStatus     string `json:"glpi_status"`
	NodeExporter   string `json:"node_exporter"`
	SyslogHost     string `json:"syslog_host"`
	SyslogStatus   string `json:"syslog_status"`
	SyslogProtocol string `json:"syslog_protocol"`
}

func stringValue(v any) string {
	switch x := v.(type) {
	case string:
		return strings.TrimSpace(x)
	case json.Number:
		return x.String()
	case float64:
		return fmt.Sprint(x)
	case bool:
		if x {
			return "true"
		}
		return "false"
	default:
		return ""
	}
}
func object(v any) map[string]any {
	if x, ok := v.(map[string]any); ok {
		return x
	}
	return nil
}
func value(m map[string]any, keys ...string) any {
	for _, k := range keys {
		if v, ok := m[k]; ok && v != nil {
			return v
		}
	}
	return nil
}
func text(m map[string]any, keys ...string) string { return stringValue(value(m, keys...)) }
func boolState(v any) string {
	switch x := v.(type) {
	case bool:
		if x {
			return "OK"
		}
		return "NU"
	case float64:
		if x != 0 {
			return "OK"
		}
		return "NU"
	case string:
		switch strings.ToLower(strings.TrimSpace(x)) {
		case "true", "yes", "ok", "1", "success", "connected", "running", "active", "up":
			return "OK"
		case "false", "no", "0", "failed", "error", "down", "stopped", "inactive", "dead":
			return "NU"
		}
	}
	return "Necunoscut"
}
func listStrings(v any) []string {
	switch a := v.(type) {
	case string:
		if strings.TrimSpace(a) != "" {
			return []string{strings.TrimSpace(a)}
		}
	case []any:
		res := []string{}
		for _, x := range a {
			if s := stringValue(x); s != "" {
				res = append(res, s)
			} else if m := object(x); m != nil {
				for _, key := range []string{"host", "address", "ip", "destination", "url", "server", "endpoint"} {
					if t := text(m, key); t != "" {
						res = append(res, t)
						break
					}
				}
			}
		}
		return res
	}
	return nil
}
func distinct(values ...string) string {
	set := map[string]bool{}
	s := []string{}
	for _, v := range values {
		for _, p := range strings.Split(v, ",") {
			p = strings.TrimSpace(p)
			if p != "" && !set[p] {
				set[p] = true
				s = append(s, p)
			}
		}
	}
	sort.Strings(s)
	return strings.Join(s, ", ")
}
func dest(m map[string]any) string {
	vals := []string{text(m, "output_host", "host", "destination", "remote_host", "server", "ip")}
	for _, key := range []string{"output_hosts", "hosts", "destinations", "remote_destinations", "servers", "metrics_endpoints"} {
		vals = append(vals, listStrings(m[key])...)
	}
	// Do not treat a generic service URL as a confirmed outgoing connection.
	return distinct(vals...)
}
func serviceState(m map[string]any) string {
	if m == nil {
		return "Necunoscut"
	}
	if v := value(m, "service_active", "active", "running", "service_running"); v != nil {
		return boolState(v)
	}
	if v := value(m, "installed"); v != nil && boolState(v) == "NU" {
		return "NU"
	}
	return "Necunoscut"
}
func parseSyslog(m map[string]any) (string, string) {
	if m == nil {
		return "", ""
	}
	hosts := []string{text(m, "destination_host", "remote_host", "destination", "output_host", "host", "server")}
	protocols := []string{text(m, "protocol", "transport", "proto")}
	for _, key := range []string{"destinations", "remote_destinations", "forwarders", "remote_servers", "targets"} {
		for _, v := range anyArray(m[key]) {
			item := object(v)
			if item == nil {
				hosts = append(hosts, stringValue(v))
				continue
			}
			hosts = append(hosts, text(item, "host", "address", "server", "ip", "destination"))
			protocols = append(protocols, text(item, "protocol", "transport", "proto"))
		}
	}
	return distinct(hosts...), distinct(protocols...)
}
func anyArray(v any) []any {
	if a, ok := v.([]any); ok {
		return a
	}
	if v != nil {
		return []any{v}
	}
	return nil
}

// Parse does not infer successful connectivity from configured hosts or a
// running service. Only an explicit output_test_ok/probe outcome is decisive.
func Parse(raw []byte) Details {
	out := Details{AuditbeatDial: "Necunoscut", FilebeatDial: "Necunoscut", GLPIStatus: "Necunoscut", NodeExporter: "Necunoscut", SyslogStatus: "Necunoscut"}
	var root map[string]any
	if len(raw) == 0 || json.Unmarshal(raw, &root) != nil {
		return out
	}
	ints := object(root["integrations"])
	if ints == nil {
		ints = root
	}
	a := object(ints["auditbeat"])
	f := object(ints["filebeat"])
	if a != nil {
		out.AuditbeatIP = dest(a)
		out.AuditbeatDial = boolState(value(a, "output_test_ok", "dial_up_ok", "dialup_ok", "connection_test_ok", "output_test_status"))
	}
	if f != nil {
		out.FilebeatIP = dest(f)
		out.FilebeatDial = boolState(value(f, "output_test_ok", "dial_up_ok", "dialup_ok", "connection_test_ok", "output_test_status"))
	}
	glpi := object(value(ints, "glpi_agent", "glpi", "glpiagent"))
	if glpi != nil {
		out.GLPIVersion = text(glpi, "package_version", "version", "agent_version")
		out.GLPIStatus = serviceState(glpi)
		if out.GLPIStatus == "Necunoscut" && out.GLPIVersion != "" {
			out.GLPIStatus = "OK"
		}
	}
	node := object(value(ints, "node_exporter", "nodeexporter"))
	if node != nil {
		out.NodeExporter = serviceState(node)
	}
	syslog := object(value(ints, "syslog", "rsyslog"))
	out.SyslogHost, out.SyslogProtocol = parseSyslog(syslog)
	out.SyslogStatus = "Necunoscut"
	if syslog != nil {
		out.SyslogStatus = "NU"
		if out.SyslogHost != "" {
			out.SyslogStatus = "OK"
		}
	}
	return out
}
