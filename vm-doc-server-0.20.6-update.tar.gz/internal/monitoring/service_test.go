package monitoring

import (
	"testing"

	"vm-doc-server/internal/domain"
)

func testVM(id int64, name string, ips ...string) vmIdentity {
	v := vmIdentity{ID: id, Name: name, FQDNs: map[string]struct{}{}, Hostnames: map[string]struct{}{}, IPs: map[string]struct{}{}, VCenterIPs: map[string]struct{}{}, Aliases: map[string]struct{}{}}
	for _, ip := range ips {
		v.IPs[ip] = struct{}{}
	}
	return v
}

func TestMatchViaSourceHostsMapsAliasToVMIP(t *testing.T) {
	vms := []vmIdentity{testVM(1, "web01", "172.20.1.25"), testVM(2, "web02", "172.20.1.26")}
	hosts := sourceHostsIndex{Available: true, ByName: map[string][]string{"prod-linux-037": {"172.20.1.25"}}}
	vm, value, ambiguous := matchViaSourceHosts("prod-linux-037", hosts, vms)
	if ambiguous || vm == nil || vm.ID != 1 || value != "prod-linux-037 -> 172.20.1.25" {
		t.Fatalf("vm=%#v value=%q ambiguous=%v", vm, value, ambiguous)
	}
}

func TestMatchViaSourceHostsDetectsAmbiguousAlias(t *testing.T) {
	vms := []vmIdentity{testVM(1, "web01", "172.20.1.25"), testVM(2, "web02", "172.20.1.26")}
	hosts := sourceHostsIndex{Available: true, ByName: map[string][]string{"shared": {"172.20.1.25", "172.20.1.26"}}}
	vm, _, ambiguous := matchViaSourceHosts("shared", hosts, vms)
	if vm != nil || !ambiguous {
		t.Fatalf("vm=%#v ambiguous=%v", vm, ambiguous)
	}
}

func TestMatchTargetUsesPrometheusHostsBeforeManualAlias(t *testing.T) {
	vms := []vmIdentity{testVM(1, "web01", "172.20.1.25")}
	vms[0].Aliases["prod-linux-037"] = struct{}{}
	hosts := sourceHostsIndex{Available: true, ByName: map[string][]string{"prod-linux-037": {"172.20.1.25"}}}
	target := ActiveTarget{Labels: map[string]string{"instance": "prod-linux-037:9100"}}
	vm, method, value, ambiguous := matchTarget(domain.PrometheusSource{VMLabel: "vm_fqdn"}, target, vms, "prod-linux-037:9100", hosts)
	if ambiguous || vm == nil || vm.ID != 1 || method != "prometheus_hosts" || value != "prod-linux-037 -> 172.20.1.25" {
		t.Fatalf("vm=%#v method=%q value=%q ambiguous=%v", vm, method, value, ambiguous)
	}
}

func TestMatchTargetUsesPrometheusHostsShortAliasBeforeAmbiguousHostname(t *testing.T) {
	vms := []vmIdentity{testVM(1, "ns2-primary", "172.20.9.100", "172.20.10.100"), testVM(2, "ns2-old", "172.20.99.100")}
	vms[0].Hostnames["ns2"] = struct{}{}
	vms[1].Hostnames["ns2"] = struct{}{}
	vms[0].VCenterIPs["172.20.9.100"] = struct{}{}
	vms[0].VCenterIPs["172.20.10.100"] = struct{}{}
	vms[1].VCenterIPs["172.20.99.100"] = struct{}{}
	hosts := sourceHostsIndex{Available: true, ByName: map[string][]string{"ns2": {"172.20.9.100"}}}
	target := ActiveTarget{Labels: map[string]string{"instance": "ns2.stsnet.ro:9100"}}

	vm, method, value, ambiguous := matchTarget(domain.PrometheusSource{VMLabel: "vm_fqdn"}, target, vms, "ns2.stsnet.ro:9100", hosts)
	if ambiguous || vm == nil || vm.ID != 1 || method != "prometheus_hosts" || value != "ns2 -> 172.20.9.100" {
		t.Fatalf("vm=%#v method=%q value=%q ambiguous=%v", vm, method, value, ambiguous)
	}
}

func TestMatchViaSourceHostsPrefersVCenterIPsOverStaleInventoryIP(t *testing.T) {
	vms := []vmIdentity{testVM(1, "ns2", "172.20.9.100", "172.20.10.100"), testVM(2, "old-vm", "172.20.9.100")}
	vms[0].VCenterIPs["172.20.9.100"] = struct{}{}
	vms[0].VCenterIPs["172.20.10.100"] = struct{}{}
	vms[1].VCenterIPs["172.20.99.100"] = struct{}{}
	hosts := sourceHostsIndex{Available: true, ByName: map[string][]string{"ns2": {"172.20.9.100"}}}

	vm, value, ambiguous := matchViaSourceHosts("ns2", hosts, vms)
	if ambiguous || vm == nil || vm.ID != 1 || value != "ns2 -> 172.20.9.100" {
		t.Fatalf("vm=%#v value=%q ambiguous=%v", vm, value, ambiguous)
	}
}
