# Upgrade vm-doc-server 0.20.5 → 0.20.6

0.20.6 corectează matching-ul Prometheus prin `/etc/hosts` pentru targeturi FQDN care pot deveni ambigue la reducerea la hostname scurt.

## Upgrade offline

Păstrați `vendor/`, `go.mod` și `go.sum` funcționale din arborele 0.20.5:

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.5 vm-doc-server-0.20.6
tar -xzf vm-doc-server-0.20.6-update.tar.gz -C vm-doc-server-0.20.6
cd vm-doc-server-0.20.6

GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Nu există migrare DB și nu este necesar update de agent. După instalarea binarului, rulați Sync pe sursa Prometheus afectată.

## Verificare caz ns2

După Sync, targetul `ns2.stsnet.ro:9100` ar trebui să fie corelat prin:

```text
match_method = prometheus_hosts
match_value  = ns2 -> 172.20.9.100
```

și `matched_vm_id` trebuie să indice VM-ul care are IP-ul vCenter `172.20.9.100`.
