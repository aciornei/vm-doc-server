# Changelog

## 0.20.6

- corectare corelare Prometheus pentru targeturi FQDN care au alias scurt în `/etc/hosts` al serverului Prometheus;
- `/etc/hosts` este consultat înaintea fallback-ului pe hostname scurt, evitând blocarea pe un hostname ambiguu;
- matching-ul prin `/etc/hosts` preferă IP-urile guest curente din vCenter și folosește IP-urile inventarului agentului doar ca fallback;
- teste de regresie pentru `ns2.stsnet.ro:9100` → `ns2` → `172.20.9.100` și VM cu mai multe IP-uri;
- fără migrare DB și fără update de agent.

## 0.20.5

- adaugă `Nu necesită documentare` la nivelul fiecărui container Docker, catalog/bază logică și site/configurație Web; marcajele sunt persistente și nu sunt suprascrise la resync;
- păstrează și controalele coarse existente pentru Docker host, instanță DB și server Web, dar aliniază toate checkbox-urile de documentare într-o coloană dedicată;
- resursele marcate sunt excluse din fișele VM/serviciu și din calculul completitudinii documentației, fără a fi șterse din inventar;
- fișa VM unește `Principal` cu `Utilizare` pe două rânduri, elimină coloana `Pachet` din componentele software, concatenează detaliile port/proces și persoană/departament și elimină `Indicatori` din tabelul containerelor;
- exportul Markdown al anexelor VM folosește aceleași structuri de tabel ca DOCX pentru Sistem/OS/Stocare/Rețea/Servicii/Porturi/Firewall/Conturi/SSSD/Integrări/Politici/Cron/NTP și aplică aceleași filtre;
- corectează testul `buildVMWhere` pentru cele 17 argumente de căutare după introducerea IP-ului principal preferat;
- migrare DB `049_resource_documentation_exempt.up.sql`; nu necesită update de agent.

## 0.20.4

- redenumește `Data generării` în `Data referință` și permite ascunderea câmpului `Generat de` la generarea fișelor VM și serviciu;
- adaugă IP principal documentație și RPO/RTO în Date operaționale; IP-ul preferat este folosit în liste și fișe;
- adaugă `Nu necesită documentare` pentru Docker, instanțe DB și engine-uri Web; resursele exceptate rămân în inventar, dar sunt excluse din completitudine și documentație;
- normalizează cazul Node Exporter activ dar nedetectat ca instalat și scurtează versiunile tehnice la versiunea utilă;
- lărgește tabelele DOCX, elimină fraza automată de la final și permite blocurilor descriptive ale serviciului să curgă natural între pagini;
- completează exportul Markdown cu inventarul agentului și îmbunătățește conversia DOCX suplimentar → Markdown (paragrafe, headings, liste, bold/italic, tabele);
- migrare DB `048_documentation_controls.up.sql`; fără update de agent.

## 0.20.3

- corectează exportul Markdown pentru Outline când este bifată opțiunea `Lipește anexele A1, A2… în același document`;
- anexele VM sunt acum incluse efectiv în fișierul `.md`, nu doar listate ca linkuri/referințe;
- fiecare anexă este randată ca secțiune `A1`, `A2` etc. și include toate secțiunile disponibile ale fișei VM (identificare, încadrare, servicii, dependențe, software, Docker/DB/Web, backup, monitorizare și inventar agent);
- exportul Markdown nu generează și nu salvează o fișă VM nouă în baza de date; folosește datele curente ale VM-ului;
- fără migrare DB și fără modificări de agent.

# Changelog

## 0.20.2

- adaugă exportul fișei serviciului intern în Markdown, pregătit pentru import/paste manual în Outline sau alt wiki;
- nou buton **Markdown pentru Outline** în panoul de generare al serviciului;
- păstrează structura logică a fișei DOCX: identificare, descriere/scop/obiective, medii, dependențe, clasificări, componente, DB/Docker/Web, backup, monitorizare, VM-uri și anexe;
- convertește rich-text-ul serviciului în Markdown (bold, italic, liste; underline este păstrat prin tag HTML `<u>`);
- documentația suplimentară Word este inclusă în export prin textul extras, iar anexele VM sunt listate A1/A2… cu link către fișa existentă atunci când `base_url` este configurat;
- exportul Markdown este download direct `.md`, nu creează o versiune nouă în istoricul documentelor și nu necesită migrare DB sau update de agent.

## 0.20.1

- adaugă la generarea fișei serviciului opțiunea **Lipește anexele A1, A2… în același document**; fișele VM pot fi integrate în DOCX, fiecare pe pagină nouă, independent de pachetul ZIP;
- documentația suplimentară DOCX încărcată pe serviciu este inserată în capitolul 2 prin `altChunk`, pentru păstrarea formatării originale Word, inclusiv tabele, liste și imagini;
- din capitolul `VM-uri asociate` elimină coloana `Fișă VM`;
- din `Monitorizare` elimină coloanele `Versiune`, `Targets` și `Probe`;
- din `Backup și restaurare` elimină coloanele `Job` și `Storage`;
- normalizează afișarea mediului la codurile uppercase `PROD`, `TEST`, `DEV` în UI și documente;
- nu introduce migrare DB și nu necesită update de agent.

## 0.20.0

- adaugă `Tip soluție` din nomenclator pe asocierile manuale Docker, baze de date și Web;
- extinde Detalii serviciu cu `Descriere scurtă`, `Autentificare`, `Link serviciu` și `Tehnologii folosite`;
- adaugă `Documentație suplimentară a serviciului`: upload/download/delete DOCX, cu importul textului în capitolul 2 al fișei;
- redenumește în interfață și fișe `Număr document` în `Număr electronic document`;
- fișa serviciului pune numele serviciului în titlu și îl elimină din tabelul de identificare; tabelul include noile câmpuri de identificare;
- descrierea detaliată continuă să fie rich-text și este redată formatat în fișă;
- capitolul 3 listează VM-urile pe rând, nu grupate cu virgulă;
- elimină coloana `VM-uri furnizor` din dependențe și servicii comune;
- fișele tehnice VM sunt prezentate la final ca Anexe și pot fi incluse în pachetul ZIP;
- documentele generate folosesc Arial 12 pentru text normal, inclusiv peste șabloane DOCX personalizate;
- migrare DB `047_service_documentation_enrichment.up.sql`; nu necesită update de agent.

## 0.19.16

- normalizează inventarul `software.items` raportat de vm-doc-agent 1.7.2;
- adaugă fila VM `Software instalat`, cu căutare/filtre, export Excel și selecție persistentă `Principal`;
- fila apare numai când există inventar software raportat, deci în prezent în mod normal doar pentru VM-uri Windows;
- fișa VM include numai aplicațiile marcate Principal; selecțiile rămân vizibile și când software-ul nu mai este detectat;
- marcajul Principal supraviețuiește upgrade-urilor de versiune ale aceleiași aplicații;
- migrare DB `046_software_inventory.up.sql`.

## 0.19.15

- ascunde din UI și documentația VM/serviciu bazele marcate ca sistem (`postgres`, `template0`, `template1`, `mysql`, `information_schema`, `performance_schema`, `sys`, respectiv MongoDB `admin/config/local`), păstrându-le în inventarul brut și în stocarea normalizată;
- cardul `Baze aplicație` și `catalog_count` din vederea VM numără numai bazele non-system;
- Rezumatul VM avertizează când este detectat un engine/instanță DB dar enumerarea bazelor nu a reușit și afișează motivul secret-safe raportat de agent;
- asocierile manuale pentru Baze de date, Docker și Web includ acum `Mediu` și `Status operațional` din nomenclatoare, per componentă;
- asocierile existente rămân compatibile prin câmpuri nullable, iar UI cere contextul operațional la asocierile manuale noi;
- fișele VM și serviciu includ mediul/statusul pe asocierile DB/Docker/Web;
- migrare DB `045_component_assignment_context.up.sql`; recomandat cu vm-doc-agent 1.6.11 pentru PostgreSQL 8/9 multi-instance.

## 0.19.14

- persistă metadata joburilor PostgreSQL programate raportate de vm-doc-agent 1.6.10 (`pgAgent` / `pg_cron`) fără SQL/comenzi/scripturi;
- VM → Baze de date afișează numărul și starea discovery-ului joburilor per instanță și un tabel separat `Joburi programate PostgreSQL`;
- afișează mai clar instanțele PostgreSQL multi-instance, inclusiv data directory, endpoint și socket;
- fișa VM include metadata joburilor PostgreSQL și starea discovery-ului lor;
- fișa serviciului include numărul de joburi pe resursa DB și un tabel deduplicat cu joburile relevante;
- adaugă motivele `maintenance_database_missing` și `user_switch_unavailable` în UI/documentație;
- migrare DB `044_database_scheduled_jobs.up.sql`; recomandat cu vm-doc-agent 1.6.10 (schema 2.7).

## 0.19.13

- adaugă `386 (i386/i686)` în selectorul de arhitectură din Agenți → Release-uri agent și în filtrul repository;
- repository-ul existent este deja multi-arhitectură: cheia release-ului include canal + OS + arch + versiune, iar endpointul latest selectează exact arhitectura cerută de agent;
- documentează publicarea în paralel a binarelor `linux/amd64` și `linux/386` pentru vm-doc-agent 1.6.8;
- fără migrare DB; backend-ul de update nu necesită schimbare de schemă.

## 0.19.12

- folosește clasificarea serviciilor raportată de vm-doc-agent 1.6.7 (`system` / `application` / `unknown`);
- VM → Inventar → Servicii afișează implicit numai servicii active de aplicație + necunoscute și oferă filtru pentru serviciile OS;
- serviciile marcate `Principal` rămân vizibile indiferent de filtrul de clasificare/stare;
- fișa VM omite din `Servicii active` numai serviciile clasificate explicit `system`; serviciile `application`, `unknown` și snapshoturile vechi rămân documentate;
- păstrează clasificarea și motivul în metadatele serviciilor principale;
- fără migrare DB; necesită vm-doc-agent 1.6.7 pentru clasificare, dar rămâne compatibil cu agenți mai vechi.

## 0.19.11

- include Monitorizarea în fișa VM: stare generală, Node Exporter, targeturi Prometheus metrics și probe Blackbox, inclusiv stare, corelare, HTTP/durată/TLS unde sunt disponibile;
- include Monitorizarea agregată în fișa serviciului, pe VM-urile asociate;
- curăță afișarea Firewall în UI și DOCX: când există un manager high-level (UFW/firewalld/SuSEfirewall2), regulile tehnice nftables/iptables/ip6tables generate dedesubt nu mai sunt afișate;
- păstrează politicile implicite ca rezumat și zonele firewalld, iar pe hosturile care folosesc direct nftables/iptables regulile rămân documentate;
- nu modifică schema bazei de date și nu necesită upgrade de agent sau collector; versiunea recomandată de agent rămâne 1.6.6.

## 0.19.10

- persistă `catalog_discovery_reason` raportat de vm-doc-agent 1.6.5 pentru instanțele de baze de date;
- afișează în VM → Baze de date motivul pentru `metadata only` (autentificare, permisiuni, socket/server indisponibil, client lipsă, timeout etc.);
- include motivul și în fișa DOCX a VM-ului;
- urmărește schimbarea motivului în Modificări inventar;
- migrare DB nouă `043_database_catalog_discovery_reason.up.sql`.

## 0.19.9

- standardizează filtrele și paginarea: selecturile din zonele de filtrare rămân native, stabile și nu mai folosesc dropdown-ul searchable cu portal;
- lista VM afișează și procentele pentru prezența în vCenter, lipsă și asocierea cu agent;
- Backup este separat în taburile `Backup` și `Surse & sincronizări`, iar lista VM Veeam primește export Excel filtrat;
- Monitorizare păstrează filtrele într-un layout stabil și adaugă export Excel filtrat pentru VM-uri și targeturi;
- catalogul Servicii primește paginare, export Excel și elimină coloana cu butoanele `Deschide` / `Editează`; numele serviciului rămâne linkul de navigare;
- `Descriere` serviciu devine rich-text, inclusiv la creare, este păstrată separat în DB și este redată cu formatare în fișa DOCX;
- Conectivitate externă și Rețele externe folosesc secțiuni `Adaugă` colapsate, iar formularele/conexiunile primesc padding consistent;
- filtrele Agenți sunt reașezate în aceeași grilă responsive folosită în restul aplicației;
- migrare DB: `042_service_description_rich_text.up.sql`; agentul și collectorul nu se modifică.

## 0.19.8

- mută editarea serviciului intern în pagina lui de detaliu, în același model ca fișa VM;
- `Detalii` are subtabs `General`, `Descriere`, `Scop și domeniu` și `Obiective`, fiecare editabil direct și cu salvare proprie;
- formularul modal vechi rămâne numai pentru crearea unui serviciu nou; butonul `Editează` din catalog deschide fișa serviciului, nu modalul;
- reconstruiește filtrele din lista Servicii pe layout-ul aerisit folosit la VM, cu listbox-uri încadrate în grid, zonă separată de acțiuni și filtre active;
- elimină suprapunerile dintre listbox-uri și butoanele filtrării la lățimi intermediare;
- nu modifică schema DB și nu necesită upgrade de agent sau collector.

## 0.19.7

- reorganizează pagina detaliu a serviciului intern pe taburi, în același model vizual ca fișa VM;
- adaugă zonele Rezumat, Detalii, Arhitectură, Componente, Dependențe și Documentație, cu subtabs pentru zonele complexe;
- mută vizual toate informațiile administrate din formularul „Editează serviciul” în tabul Detalii;
- păstrează butonul Editează în contextul tabului Detalii și revine pe aceeași secțiune după salvare;
- adaugă navigare directă prin hash-uri `#services/<id>/<secțiune>`;
- nu modifică schema DB și nu necesită upgrade de agent.

## 0.19.6

- în `VM → Inventar → Porturi ascultate`, porturile/procesele pot fi marcate persistent ca **Principale**;
- identitatea selecției este `protocol + port + process_name`, fără PID, astfel încât persistă după restarturi;
- fișa VM adaugă **Porturi și procese principale** cu port, protocol, proces, PID curent, executabil, adresă de listen și stare;
- selecțiile dispărute din inventarul curent rămân vizibile ca `Nedetectat`, până la demarcare;
- secțiunea separată **Politici** este eliminată din fișa VM; politicile implicite ale firewall-ului rămân în capitolul Firewall;
- migrare DB: `041_vm_primary_agent_ports.up.sql`; agentul și collectorul nu se modifică, `vm-doc-agent` rămâne 1.6.3.

## 0.19.5

- reorganizare UI VM: `Inventar VM` separat de `Surse & sincronizări`;
- fișa VM are meniu principal pe zone funcționale și subtabs locale;
- filtre VM aerisite și rezumat al filtrelor active;
- listbox-uri searchable stabilizate: portal, direcție blocată, săgeată CSS și padding constant;
- chevron uniform pentru selecturile native;
- padding și spațiere îmbunătățite inclusiv în VM → Monitorizare;
- fără migrare DB; agentul rămâne 1.6.3.

## 0.19.4

- curățare definitivă pentru VM-uri dispărute din vCenter, fără introducerea unui flux nou de arhivare;
- filtru `vCenter` pentru prezente/lipsă și afișarea `missing_since`;
- ștergere individuală și bulk, maximum 200 VM-uri per operație;
- ștergerea este permisă numai pentru `present_in_vcenter=0` și este tranzacțională;
- preview de impact înainte de delete: servicii, documente, monitorizare, backup, conexiuni externe, responsabilități și schimbări;
- targeturile de monitorizare sunt decorelate, nu șterse; agentul asociat nu este șters;
- audit `vm.delete.permanent`;
- fără migrare DB nouă; agentul rămâne `vm-doc-agent 1.6.3`.

## 0.19.3

- vCenter sincronizează toate adresele IPv4 guest raportate de `/guest/networking/interfaces`, nu doar `guest/identity.ip_address`;
- adresele sunt păstrate în `vcenter_vm_ips`; setul complet este înlocuit numai când endpointul guest networking răspunde cu succes;
- corelarea Prometheus/Blackbox folosește și IP-urile secundare vCenter, inclusiv pentru VM-uri fără agent;
- pagina VM → Monitorizare afișează IP-urile vCenter folosite la corelare;
- Monitorizare este împărțită în două pagini: **Stare monitorizare** și **Surse & sincronizări**;
- formularul Prometheus este mărit și împărțit pe secțiuni, iar filtrele/paddingurile din Monitorizare și din fila VM au fost aerisite;
- migrare DB: `040_vcenter_vm_guest_ips.up.sql`; agentul rămâne `vm-doc-agent 1.6.3`.

## 0.19.2

- sursa Prometheus poate fi asociată explicit cu un agent vm-doc;
- UI oferă selectorul „Agent asociat” la creare/editare;
- serverul citește `hosts.entries` din inventarul curent al agentului asociat;
- corelarea devine label → FQDN → hostname → IP → Prometheus `/etc/hosts` → alias manual;
- metoda de corelare este salvată ca `prometheus_hosts` cu valoarea `alias -> IP`;
- Test Prometheus raportează și disponibilitatea / numărul de intrări hosts;
- migrare DB: `039_prometheus_source_agent_hosts.up.sql`;
- necesită vm-doc-agent 1.6.3 pe serverele Prometheus pentru corelarea prin hosts.

## 0.19.1
- separă targeturile `metrics` de `blackbox` chiar când ambele surse folosesc același Prometheus;
- identifică Blackbox după `/probe`, `__metrics_path__` și `__param_target`, fără dependență de numele jobului;
- Test raportează numărul de targeturi filtrat după tipul sursei;
- clientul Prometheus ocolește proxy-ul de mediu (`Proxy: nil`);
- următorul Sync marchează automat `present=0` rândurile importate greșit de 0.19.0, fără migrare DB.

# Changelog

## 0.19.9

- standardizează layout-ul filtrelor și dezactivează listbox-urile searchable custom în zonele de filtrare/paginare, pentru a elimina suprapunerile și poziționările instabile;
- VM: cardurile de inventar afișează și procentele pentru prezență vCenter, lipsă și acoperire agent;
- Backup: separă pagina în taburile `Backup` și `Surse & sincronizări`, adaugă Export Excel pentru lista filtrată;
- Monitorizare: aliniază filtrele cu restul aplicației și adaugă Export Excel separat pentru VM-uri și targeturi;
- Servicii: adaugă paginare configurabilă, Export Excel, elimină coloana/butoanele Deschide/Editează și face Descrierea rich-text persistentă;
- Conectivitate externă: formularele de adăugare sistem/rețea sunt colapsate implicit, iar editarea conexiunilor primește padding și spacing consistent;
- Agenți: filtrele sunt rearanjate pe layout-ul comun.
- migrare DB nouă `042_service_description_rich_text.up.sql`.

## 0.19.0

- adaugă fundația de monitorizare read-only pentru surse **Prometheus metrics** și **Prometheus Blackbox**;
- meniu nou **Monitorizare** cu surse configurabile, Test, Sync manual/global, scheduler și istoric paginat;
- sincronizează targeturile active prin API-ul Prometheus fără a duplica seriile de metrici în MariaDB;
- corelează targeturile cu VM-urile în ordinea: label explicit configurabil (implicit `vm_fqdn`) → FQDN → hostname → IP → alias manual;
- suportă joburi Prometheus care folosesc IP, FQDN sau hostname rezolvat local pe serverul Prometheus, inclusiv prin `/etc/hosts`;
- folosește inventarul agentului 1.6.2 pentru starea Node Exporter: instalat, service activ, versiune și endpoint;
- pentru sursele Blackbox citește `probe_success`, codul HTTP, durata probei și expirarea certificatului TLS;
- adaugă fila **Monitorizare** în pagina VM cu Node Exporter, targeturi Prometheus/Blackbox și aliasuri manuale;
- pagina globală afișează VM monitorizate/nemonitorizate, exporter fără target, targeturi DOWN, corelate/necorelate și filtre după power state;
- migrare nouă `038_prometheus_monitoring_foundation.up.sql`; agentul rămâne `vm-doc-agent 1.6.2`; integrarea Grafana este lăsată intenționat pentru etapa următoare după validarea Prometheus/Blackbox.

## 0.18.3

- citește VM-urile configurate direct în joburile Veeam din `virtualMachines.includes`, nu doar obiectele care au deja backup/restore point;
- separă starea `În job Veeam` de existența unui backup utilizabil: VM-urile nou adăugate apar imediat ca `Așteaptă primul backup`;
- detectează cazul invers: restore point existent, dar VM-ul nu mai este inclus direct într-un job (`Backup existent · în afara jobului`);
- pentru VM-urile configurate înainte de primul backup afișează deja jobul, repository-ul, programarea, retenția/GFS și `Next run` când sunt raportate de Veeam;
- pagina Backup adaugă filtre și carduri pentru `În job`, `Așteaptă primul backup` și `Backup în afara jobului`; cardurile rămân sensibile la filtre;
- întărește compatibilitatea 0.18.2: repară DSN-ul UTC, default-ul `cron_backup_notes` și INSERT-urile de sync/cron pentru instalări curate și upgrade-uri existente;
- migrare nouă `037_veeam_job_membership.up.sql`; agentul rămâne 1.6.2.

## 0.18.2

- citește din Veeam definițiile joburilor, programarea, retenția și politicile GFS Weekly / Monthly / Yearly;
- diferențiază storage-ul primar de storage-ul secundar (backup copy) și afișează ambele în UI și documente;
- cardurile din pagina Backup se recalculează după căutare și filtre, iar filtrarea include power state;
- adaugă backup cron/script local documentabil per VM; cron-urile raportate de agent pot fi selectate direct, iar backupul apare în tabul Backup și în fișele VM/serviciu;
- compactează listboxurile din filtrarea Backup;
- normalizează conexiunile MariaDB la UTC și expune timezone-ul aplicației către UI; timezone implicit: Europe/Bucharest.

## 0.18.1

- corectează corelarea ID-urilor Veeam pentru backup/job (case-insensitive și compatibilă cu UUID-uri între acolade), astfel încât să fie populate `Job`, `Repository`, `Last result` și `Next run`;
- păstrează Test-ul Veeam compatibil cu rolul **Backup Viewer**, fără apel la `serverInfo`;
- acceptă răspunsurile VBR 12.1 în care `platformName` nu este întotdeauna string;
- îmbunătățește pagina **Backup** cu filtre separate pentru protecție, power state și rezultat, plus căutare și paginare;
- adaugă card **Toate VM-urile** și procente pentru protejate, neprotejate și neverificate;
- adaugă fila **Backup** în pagina VM, cu sumar și detaliile Veeam ale lanțurilor de backup/restore point;
- include backupurile VM-urilor și în fișa DOCX a serviciului intern; fișa VM continua să includă secțiunea Backup;
- intervalul implicit pentru sursele Veeam noi devine 1440 minute (o dată pe zi); sursele existente își păstrează intervalul configurat;
- nu adaugă migrare DB și nu necesită update de agent (`vm-doc-agent 1.6.2`).

## 0.18.0

- adaugă integrare read-only cu **Veeam Backup & Replication** prin REST API;
- meniu nou **Backup** cu surse Veeam, Test conexiune, sincronizare manuală/globală și istoric paginat al sincronizărilor;
- parolele surselor Veeam sunt criptate cu cheia master a serverului și nu sunt returnate prin API;
- corelează obiectele Veeam cu VM-urile din vm-doc după **numele exact** al VM-ului;
- populează automat `vm_backup_summary` cu job, repository, ultimul rezultat, ultimul backup/restore point, următoarea rulare și numărul de restore points;
- scheduler per sursă, implicit la 360 minute (6 ore), cu stare și ultima eroare;
- migrare nouă `034_veeam_backup_integration.up.sql`; nu necesită update de agent, `vm-doc-agent 1.6.2` rămâne compatibil.

## 0.17.2

- introduce baseline pentru meniul Modificări, global și per VM;
- la upgrade, inventarul curent devine automat baseline pentru VM-urile existente, evitând zgomotul inițial;
- modificările de dinaintea baseline-ului rămân păstrate pentru audit, dar nu mai apar în trierea curentă și nu afectează procentul de completare;
- VM-urile noi își stabilesc automat primul snapshot drept baseline înainte de urmărirea diferențelor;
- butoane noi „Stabilește inventarul curent ca baseline” global și „Stabilește baseline VM” în fila Modificări.

## 0.17.1

- corectează migrarea `032_inventory_changes.up.sql`: coloanele care referențiază chei `BIGINT UNSIGNED` sunt acum tot `BIGINT UNSIGNED`;
- repară pornirea pe MariaDB/MySQL unde 0.17.0 eșua cu `Error 1005 ... Foreign key constraint is incorrectly formed`;
- nu adaugă o migrare nouă și nu schimbă schema funcțională planificată pentru 0.17.0; migrarea 032 eșuată este reluată automat la pornire.

## 0.17.0

- adaugă meniul global **Modificări** și fila **Modificări** în fiecare VM;
- compară semantic snapshot-ul JSON nou cu snapshot-ul anterior și ignoră zgomotul volatil (timpi de colectare, uptime, durate, PID-uri/inode-uri);
- urmărește schimbări relevante pentru documentație: conturi locale, baze/instanțe DB, containere Docker, site-uri/frontends Web, servicii OS, porturi, firewall, rețea, stocare, SSSD, integrări, NTP, OS și hardware;
- fiecare diferență este clasificată `added`, `removed` sau `modified` și păstrează valorile anterioare/noi pentru verificare;
- adaugă triere manuală `Documentație`: `Nesetat` (implicit), `Necesită documentație`, `Nu necesită`, plus starea `Nou / Revizuit / Ignorat` și observații;
- pagina globală are filtre, paginare și indicatori; din VM se văd numai schimbările VM-ului respectiv;
- include acțiunea **Compară ultimele snapshot-uri** pentru popularea inițială după upgrade;
- migrare nouă `032_inventory_changes.up.sql`; agentul 1.6.1 rămâne compatibil și nu necesită update.


## 0.16.4

- stabilizează dropdown-urile searchable: elimină repoziționarea dublă la focus/click și recalculează poziția după fiecare filtrare, folosind înălțimea reală a listei;
- dropdown-ul rămâne ancorat de listbox când rezultatele filtrate schimbă înălțimea listei, inclusiv când lista este deschisă deasupra controlului;
- adaugă padding explicit mesajului Docker „nu este instalat” și informației despre ultima colectare.

## 0.16.3

- repară listbox-urile searchable care puteau fi tăiate de panel/table overflow: dropdown-ul este randat ca portal cu z-index ridicat și repoziționat la scroll/resize;
- adaugă padding suplimentar în detaliile Docker;
- elimină subsecțiunea goală „Schema inventar” și numerotează continuu subsecțiunile Inventar agent, fără goluri pentru secțiuni eliminate;
- indentează explicit Heading2 în DOCX, astfel încât 5.1 și toate subsecțiunile să fie vizual sub capitolul părinte;
- deduplică Porturi ascultate la o singură intrare per port/protocol, păstrând exemplul cu cele mai bune informații de proces/executabil;
- fără migrare SQL; vm-doc-agent 1.6.1 rămâne suficient.


## 0.16.2

- mută versiunea agentului lângă badge-ul de stare din lista VM și elimină coloana separată;
- adaugă căutare prin tastare pentru select-urile single-value din interfață;
- adaugă paginare server-side pentru ultimele sincronizări vCenter;
- îmbunătățește spațierea filelor Docker/DB/Web, previzualizarea fișei VM și panoul de conexiuni externe;
- repară tabelul de porturi din fișa VM folosind `processes[]` din inventarul agentului;
- generalizează secțiunea Firewall pentru nftables, iptables/ip6tables, firewalld, UFW și SuSEfirewall2;
- include corect utilizatorii locali non-system, inclusiv UID 1000.
- fără migrare SQL; agentul 1.6.1 este suficient.

## 0.16.1

- compactează cardurile din Rezumat VM, Docker, Baze de date și Web astfel încât pe desktop să ocupe un singur rând; repară fundalul deschis al cardurilor Docker Compose în tema dark;
- aerisește controalele de asociere serviciu în taburile Docker, Baze de date și Web;
- listarea VM afișează versiunea agentului și toate serviciile asociate, inclusiv cele provenite din containere Docker, baze/instanțe DB și site-uri Web; adaugă filtru după serviciu;
- simplifică sistemul de operare și power state în listare (`ON` / `OFF`) și elimină coloana vCenter din tabel;
- procentul de completare devine dinamic: VM-urile cu Docker/DB/Web primesc criterii suplimentare pentru asocierea resurselor la servicii, iar VM-urile fără aceste resurse nu sunt penalizate;
- criteriul „Serviciu documentat” este satisfăcut și de asocieri Docker/DB/Web, util pentru hosturile partajate care nu aparțin integral unui singur serviciu;
- fără migrare SQL nouă.

## 0.16.0

- adaugă inventar structurat pentru Nginx, Apache HTTP Server și HAProxy: servere, site-uri/virtual hosts/frontends, nume publice, bind-uri, document root, backend-uri și ținte proxy;
- adaugă relația many-to-many site Web → serviciu intern, independentă de VM → serviciu, pentru hosturi web partajate;
- pagina VM primește tabul `Web`, iar pagina serviciului agregă site-urile asociate de pe orice VM gazdă;
- îmbunătățește controalele de asociere în taburile Docker și Baze de date și folosește aceleași controale aerisite în Web;
- fișa VM omite automat capitolele Docker, Baze de date și Web când nu există date și renumerotează dinamic capitolele următoare;
- repară prefixul subsecțiunilor Inventar agent, eliminând situații de tipul capitol 9 urmat de 8.x;
- fișa serviciului include Web numai când există site-uri asociate și renumerotează dinamic capitolele opționale;
- migrare DB nouă `031_web_inventory.up.sql`; necesită `vm-doc-agent 1.6.0` pentru colectarea Web.

## 0.15.0

- adaugă inventar structurat pentru PostgreSQL, MySQL, MariaDB, MongoDB, Oracle Database, Microsoft SQL Server, IBM Db2, Redis, Firebird și CockroachDB;
- inventariază engine-uri, instanțe, endpoint-uri, versiuni, servicii/procese, directoare/config și, când accesul local fără credențiale permite, bazele logice;
- adaugă relații many-to-many instanță → serviciu și bază logică → serviciu, independente de relația VM → serviciu;
- pagina VM primește tabul `Baze de date`, iar pagina serviciului agregă bazele/instanțele asociate de pe orice VM gazdă;
- fișele DOCX de VM și serviciu includ secțiuni DB;
- importul acceptă statusurile collectorului `success` și `partial` și poate face backfill din snapshot-ul curent;
- migrare DB nouă `030_database_inventory.up.sql`; necesită `vm-doc-agent 1.5.0` pentru colectare.

## 0.14.1

- repară normalizarea inventarului Docker când collectorul agentului are status `partial`; `vm-doc-agent` marchează un collector `partial` pentru orice warning, chiar dacă payload-ul Docker este valid și conține engine/containere;
- păstrează protecția pentru statusurile `disabled`, `error` și `timeout`, care nu suprascriu ultimul inventar Docker bun;
- adaugă backfill/self-healing din `inventory_snapshots.raw_json`: la deschiderea tabului Docker, dacă snapshot-ul curent conține Docker dar tabelele structurate nu au fost populate de 0.14.0, serverul reconstruiește automat inventarul fără o colectare nouă;
- nu există migrare DB nouă; agentul 1.4.0/1.4.1 este compatibil.

## 0.14.0

- inventar Docker structurat în baza de date pentru fiecare VM: engine, containere, Docker Compose, imagini, rețele și volume;
- containerele au identitate logică stabilă pentru a păstra asocierile manuale după redeploy;
- asociere many-to-many container → serviciu intern, independent de asocierea VM-ului; un host Docker partajat poate găzdui containere pentru servicii diferite;
- asociere manuală per container și asociere în masă per proiect Docker Compose;
- labels opționale `vm-doc.service`, `vm-doc.services`, `vm-doc.component` și `vm-doc.role` creează automat asocieri fără a suprascrie asocierile manuale;
- tab nou Docker în fișa VM, cu engine, Compose projects, containere, porturi, indicatori și serviciile asociate;
- pagina serviciului afișează containerele asociate chiar dacă VM-ul gazdă este partajat și nu aparține exclusiv serviciului;
- fișa DOCX a VM-ului și fișa DOCX a serviciului includ secțiuni Docker;
- migrare nouă `029_docker_inventory.up.sql`; necesită `vm-doc-agent 1.4.0` pentru colectarea Docker.


## 0.13.8

- Agent actions (Test / Colect / Update) now prefer the registered management IP when the stored agent URL still points to a VIP.
- Auto-registration normalizes a literal-IP base_url to the advertised management IP, preserving scheme and port.
- The agent list no longer shows the redundant "IP-uri raportate VM" column; those addresses remain available in inventory data.
- Agent Excel export removes the redundant reported-VM-IP column and exports the effective management URL.

## 0.13.7

- Fix auto-registration for a brand-new agent: the `agents` INSERT now has a value for every listed column, including `last_registration_ip`.
- Keep internal registration/heartbeat/inventory errors hidden from HTTP clients but log the real server-side error for troubleshooting.
- No database migration is required.

## 0.13.6

- separă în pagina Agenți adresa `IP agent / management` de adresele IP raportate de interfețele VM;
- afișează separat IP-ul sursă observat la register/heartbeat când diferă de IP-ul de management;
- inventarul curent păstrează compact lista adreselor raportate pentru listare/căutare/export fără a încărca payload-ul JSON complet;
- `primary_ip` al inventarului preferă `src/prefsrc` al rutei implicite înaintea primei adrese de interfață, reducând riscul ca un VIP să devină IP principal;
- exportul Excel pentru agenți include IP management, IP sursă register și IP-urile raportate;
- migrare nouă `028_agent_network_identity.up.sql`.

## 0.13.5

- layout fluid pe toată lățimea monitorului; eliminată limita fixă de 1600 px care lăsa spațiu gol pe ecrane mari;
- spațiere adaptivă cu `clamp()` pentru monitoare Full HD, 2K, 4K și ferestre redimensionate;
- cardurile, panourile, tabelele și workspace-urile pot folosi întreaga lățime disponibilă fără overflow inutil;
- toolbar-urile și antetele de panou se împachetează controlat când spațiul scade;
- dialogurile sunt limitate la viewport și pot fi derulate pe ecrane joase;
- navigarea secundară devine scrollabilă pe ecrane mobile, iar controalele se reașază fără să iasă din viewport;
- CSS-ul este versionat în URL pentru cache-busting la upgrade;
- fără migrare DB și fără modificări de backend/API.

## 0.13.4

- fix status auto-update rămas `stable / installing / <versiune>` după instalarea reușită;
- la register/heartbeat, serverul reconciliază cache-ul de update când `agent.version` este egal cu `update_available_version`;
- după reconciliere, `update_state` devine `current`, versiunea disponibilă se golește și se actualizează timestamp-ul de succes;
- UI-ul listei de agenți face refresh-uri scurte după butonul Update pentru a afișa finalizarea fără refresh manual;
- fără migrare DB; compatibil cu vm-doc-agent 1.3.6.

## 0.13.3

- hotfix pentru panic-ul `nil pointer dereference` din `agentclient.Client` introdus pe calea de refresh/update a agenților în 0.13.2;
- `vm-doc-server` inițializează acum propriul `agentclient.Client` cu aceleași `collector.allowed_networks` și limite folosite de collector;
- heartbeat-ul și butonul **Update** pot interoga `/v1/update` / `/v1/update/check` fără a opri procesul serverului;
- protecție defensivă în client: un client neinițializat returnează eroare explicită în loc de SIGSEGV;
- fără migrare MariaDB nouă și fără modificări obligatorii la `vm-doc-agent`.

## 0.13.2

- buton **Update** în lista Agenți pentru verificare/instalare imediată, fără a aștepta `updates.check_interval`;
- serverul apelează endpoint-ul existent `POST /v1/update/check` al agentului 1.3.3+ și respectă canalul configurat local pe agent;
- lista Agenți afișează canalul de update `stable` / `testing`, starea update-ului și versiunea disponibilă când există;
- filtru și căutare după canal/stare update;
- statusul de update este memorat central și reîmprospătat la Test/Colect, la update forțat și periodic pentru agenții auto-înregistrați;
- exportul Excel Agenți include canalul și starea auto-update;
- migrarea `027_agent_update_status.up.sql`;
- `vm-doc-agent 1.3.3` rămâne compatibil, fără upgrade obligatoriu al agentului.

## 0.13.1

- navigare orizontală în pagina Agenți;
- OS + versiune OS raportate de agent în listă și căutare;
- butoane compacte Test / Colect / Edit / Del;
- export Excel pentru agenți;
- publicarea unui release este colapsată implicit;
- release-uri cu filtre, paginare și export Excel;
- toate paginările pornesc implicit de la 10;
- fără migrare MariaDB.

## 0.13.0

- retenție configurabilă a snapshot-urilor de inventar și raportare a volumului de stocare;
- Audit paginat, filtrabil și cu before/after pentru operațiile principale instrumentate;
- obiect nou `external_networks`, cu culoare, tip zonă, risc, trust, CIDR-uri și metadate operaționale;
- sisteme externe asociate unei rețele externe și conexiuni către VM/Servicii interne;
- conectivitatea externă apare în UI, rapoarte și documentația DOCX;
- migrarea `026_inventory_retention_audit_external_systems.up.sql`.

## 0.12.0

- fișa VM împărțită în șapte subsecțiuni cu navigare sticky și URL dedicat;
- procent de completare pentru VM, vizibil în listă, rezumat și export Excel;
- paginare Nomenclatoare configurabilă 10/20/50/100/200, memorată pe categorie;
- pagina Agenți separată în listare și administrarea release-urilor;
- repară pierderea focusului în câmpul de căutare Agenți;
- fără migrare MariaDB nouă.

## 0.11.1

- administrare completă a repository-ului de agent din UI: publicare, promovare și ștergere;
- upload multipart protejat de RBAC `agents.manage` și CSRF;
- suport pentru rollout testing → stable;
- release recomandat împreună cu vm-doc-agent 1.3.2 pentru detecția robustă a versiunilor software.



## 0.11.0

- Servicii agent pe VM: căutare, filtru Active/Inactive/Toate și stare lângă nume;
- Network Routes afișate tabelar;
- Firewall Rules: reguli explicite separate de regulile tehnice backend și reguli brute ascunse implicit;
- Rapoarte împărțite în subcategorii;
- readuce repository-ul central de auto-update pentru vm-doc-agent 1.3.0+;
- pagina Agenți afișează versiunea agentului și release-urile publicate;
- fără migrare MariaDB nouă.

## 0.10.0

- servicii software principale selectabile din inventarul agentului;
- selecții persistente pe VM, independente de snapshotul curent;
- metadate de versiune software/pachet preluate din agentul 1.3.1+;
- componentele principale apar în fișa VM și sunt agregate în fișa Serviciului intern;
- renderer contextual pentru uptime, mount point, port, username, comandă cron și nume serviciu;
- migrarea `025_vm_primary_agent_services.up.sql`;
- OpenAPI și documentație actualizate.


## 0.9.1

- repară eroarea HTTP 500 la adăugarea unei dependențe directe `VM → Serviciu comun`;
- citirea dependențelor VM nu mai folosește un `UNION ALL` fragil în MariaDB, ci interogări separate agregate în aplicație;
- erorile de creare a unei dependențe directe pe VM sunt acum scrise explicit în log;
- fără migrare de bază de date.


## 0.9.0

- căutare, filtrare și paginare în pagina Agenți;
- filtre extinse și descriere scurtată în lista Serviciilor interne;
- carduri compacte în pagina serviciului și afișare condiționată a mediilor PROD/TEST/DEV;
- model nou pentru servicii comune și dependențe globale/explicite;
- nomenclator `dependency_type`;
- relații `internal_service_dependencies` și excepții `vm_common_service_dependencies`;
- servicii comune marcabile ca `is_common` și `implicit_global`;
- dependențe afișate în pagina VM, pagina serviciului și schema logică;
- VM-urile furnizor ale AD/DNS/LDAP și ale altor servicii comune sunt expuse în UI și documentație;
- fișele DOCX VM/Serviciu includ infrastructura comună și analiza de impact;
- rapoarte noi pentru servicii comune, tipuri de dependență și impact;
- migrarea `024_common_service_dependencies.up.sql`;
- OpenAPI și documentație actualizate.

## 0.8.0

- evidențiere explicită a mediilor **PROD / TEST / UAT / DEV** în pagina și fișa DOCX a Serviciului intern;
- lista VM-urilor serviciului afișează ultima fișă VM generată și link direct către document;
- generarea documentației serviciului poate fixa fișele VM ca anexe și poate regenera automat fișele lipsă sau toate fișele;
- pachet ZIP reproductibil cu fișa serviciului și versiunile exacte ale fișelor VM anexate;
- tabel `service_document_annexes` pentru relația dintre o fișă de serviciu și documentele VM folosite la generare;
- meniu nou **Rapoarte**, cu indicatori, pie/donut charts, bar charts și evoluția documentelor generate;
- rapoarte pentru medii, power state, CPU/RAM, OS, vCenter, agenți, backup, inventar, documentare, criticitate, domenii, categorii, layer-e, roluri, tip soluție și completitudinea asocierilor;
- liste de servicii și VM-uri cu informații lipsă pentru completarea documentației;
- permisiune nouă `reports.read`;
- migrarea `023_reports_service_annexes.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.3

- hotfix pentru editorul rich-text: clickul în **Scop și domeniu** / **Obiective** păstrează focusul în zona editabilă în loc să activeze butonul Bold;
- structură HTML corectată și îmbunătățiri de accesibilitate;
- fără migrare de bază de date.


## 0.7.2

- editor rich-text pentru **Scop și domeniu** și **Obiective**;
- suport pentru paragrafe, newline, bold, italic, underline, bullets, numerotare și indentare;
- model rich-text JSON restricționat și validat server-side, fără stocare de HTML executabil;
- compatibilitate menținută prin câmpurile plain-text `purpose` / `objectives`;
- randare rich-text în pagina serviciului și în DOCX;
- conversie automată din textul existent la prima afișare/editare;
- migrarea `022_service_rich_text.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.1

- câmp narativ **Scop și domeniu** pentru serviciul intern, reutilizând `purpose` pentru compatibilitate;
- câmp nou **Obiective** pe serviciul intern;
- afișare aerisită a Descrierii, Scopului și domeniului și Obiectivelor;
- schema logică a serviciului inclusă automat în DOCX;
- un singur nod per VM în schema DOCX, cu toate asocierile și rolurile acelui VM;
- placeholdere `{{service.scope_domain}}` și `{{service.objectives}}`;
- migrarea `021_service_scope_objectives_docx_diagram.up.sql`;
- OpenAPI, documentație și teste actualizate.

## 0.7.0

- schemă automată a serviciului, agregată din asocierile VM;
- un singur nod per VM, cu multiple asocieri afișate în același nod;
- grupare pe layer și zonă Multi-layer;
- pictograme configurabile prin `icon_key` în nomenclatoare;
- iconițe implicite pentru clasificare, layere, roluri și tipuri de soluție;
- export Excel nomenclatoare extins cu pictograma;
- migrarea `020_service_diagram_icons.up.sql`;
- OpenAPI și documentația actualizate.



## 0.6.0

- nomenclator `solution_type` și valori inițiale Open source / Dezvoltată intern / Comercială;
- `solution_type_id` pe asocierea VM–serviciu–layer–rol;
- interfață aerisită, pe carduri, pentru asocierile serviciilor din fișa VM;
- agregare tip soluție în lista și pagina Serviciilor interne;
- șabloane DOCX tipizate `vm` / `service` și șablon implicit pentru serviciu intern;
- previzualizare, generare, istoric și descărcare DOCX pentru Serviciu intern;
- numere de document `FSI-*` pentru fișele de serviciu;
- OpenAPI, documentație și migrarea `019_service_documents_solution_type.up.sql` actualizate.


## 0.5.1

- inventarul agentului este randat în tabele compacte, specifice fiecărei secțiuni, în locul flatten-ului generic;
- eliminate din document secțiunile Agent și Proxy și câmpul `uptime_seconds`;
- stocare în format partiție/filesystem/capacitate cu unități lizibile;
- rețea pe câte un rând pentru adresă și interfață;
- numai servicii active, porturi esențiale, reguli UFW numbered și conturi relevante;
- rezumat SSSD și matrice compactă pentru Auditbeat, Filebeat, GLPI Agent, Node Exporter și Syslog;
- cron și NTP simplificate; politici lăsate pregătite pentru completare ulterioară;
- tabele DOCX cu grilă explicită și lățimi fixe, compatibile cu randarea LibreOffice;
- fără migrare de bază de date.

## 0.5.0

- generator DOCX pentru fișa tehnică a VM-ului, disponibil direct în pagina VM;
- previzualizare a datelor și avertismente pentru inventar, servicii sau responsabilități lipsă;
- șabloane DOCX încărcabile și administrabile, cu șablon implicit creat automat;
- placeholder obligatoriu `{{VM_DOCUMENT_BODY}}` și placeholdere scalare pentru antetul șablonului;
- documentul include identificare, resurse, date operaționale, servicii, roluri, responsabilități, backup și inventarul structurat al agentului;
- istoric al documentelor generate, număr unic, fișier, dimensiune, SHA-256, autor și snapshot sursă;
- permisiuni noi `documents.read` și `documents.manage`;
- migrarea `018_document_generation.up.sql` creează `document_templates` și `generated_documents`.

## 0.4.4

- toate valorile nomenclatoarelor sunt sortate consecvent după ordinea părintelui, apoi după ordinea proprie și denumire;
- categoriile de serviciu sunt grupate după ordinea domeniului arhitectural;
- rolurile tehnice sunt grupate după primul layer în ordinea layer-elor, apoi după ordinea proprie; valorile nemapate sunt afișate la final;
- registrul Persoane este ordonat după departament, apoi după nume;
- filtre pe fiecare pagină de nomenclator: căutare text și stare, plus domeniu pentru categorii și layer pentru roluri;
- filtre suplimentare pentru Persoane: departament, sursă și stare;
- paginarea se aplică rezultatului filtrat, iar exportul Excel păstrează lista completă în ordinea nouă;
- fără migrare de bază de date.

## 0.4.3

- paginare pentru toate nomenclatoarele și pentru registrul Persoane, cu dimensiune selectabilă a paginii;
- export Excel pentru nomenclatorul curent, disponibil tuturor utilizatorilor cu permisiunea `nomenclatures.read`;
- exportul include toate rândurile active și inactive, nu numai pagina vizibilă;
- coloane relaționale în Excel pentru `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- export complet pentru persoane, inclusiv departament, sursă și cont AD;
- fără migrare de bază de date.

## 0.4.2

- corectată interogarea de citire a inventarului după ID: parametrul `id` este transmis către `QueryRowContext`;
- eliminată eroarea MariaDB `Error 1064 ... near '?' at line 1` la deschiderea fișei VM;
- inventarul curent și vederea structurată a JSON-ului agentului se încarcă din nou fără recollectare;
- fără migrare de bază de date.

## 0.4.1

- termenul vizibil **Categorie ITIL** este înlocuit cu **Categorie de serviciu**; cheia tehnică `itil_category` rămâne neschimbată pentru compatibilitate;
- integrare de tip director cu Active Directory, reutilizând gazdele LDAP, TLS-ul și contul bind deja configurate pentru autentificare;
- OU rădăcină configurabil, citire recursivă a utilizatorilor și afișare arborescentă după sub-OU-uri;
- filtrare obligatorie după atributul `department`, cu primul departament în ordine alfabetică selectat implicit sau cu un departament implicit configurabil;
- import multiplu și actualizare idempotentă a persoanelor din AD în registrul local de responsabilități, folosind `objectGUID` ca identitate stabilă;
- persoanele importate păstrează sursa LDAP și contul AD, iar reimportul actualizează numele, e-mailul, telefonul și departamentul;
- migrarea `017_service_category_ad_directory.up.sql` actualizează eticheta nomenclatorului și extinde tabelul `people` cu identitatea de director;
- migrarea `016_vm_service_classification.up.sql` este corectată astfel încât indexul nou să fie creat înainte de eliminarea indexului folosit de cheia externă.

## 0.4.0

- domeniul arhitectural și categoria de serviciu sunt mutate de la serviciul intern la asocierea VM–serviciu;
- formularul serviciului intern păstrează numai identitatea, descrierea, criticitatea și informațiile de documentare;
- fișa VM adaugă selectorul Categorie de serviciu între Domeniu și Serviciu intern;
- domeniul filtrează categoriile de serviciu, iar layer-ul filtrează rolurile tehnice;
- pagina și lista Servicii agregă automat încadrările domeniu–categorie din VM-uri;
- VM-urile din pagina serviciului afișează încadrarea folosită de fiecare asociere;
- validare backend pentru relația `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- migrarea `016_vm_service_classification.up.sql` păstrează încadrările existente și extinde cheia unică a asocierii.

## 0.3.9

- pagina Nomenclatoare nu mai afișează toate listele simultan;
- submeniu lateral grupat în Catalog servicii, Arhitectură tehnică, Operare VM și Responsabilități;
- se afișează o singură listă la un moment dat, cu numărul valorilor în submeniu;
- ruta păstrează categoria selectată, de exemplu `#nomenclatures/technical_role`;
- pe ecrane înguste, submeniul devine o grilă adaptivă de opțiuni;
- actualizarea este exclusiv de interfață și nu necesită migrare MariaDB.

## 0.3.8

- selecție în cascadă pe fișa VM: domeniu → serviciu intern → layer → rol tehnic;
- serviciile interne nu mai păstrează configurații layer–rol proprii; combinațiile observate sunt agregate automat din asocierile VM;
- validarea backend verifică serviciul și relația globală layer–rol, fără o restricție suplimentară la nivelul serviciului;
- selector multiplu cu căutare, stil Select2 și complet offline, pentru layer-ele permise ale unui rol tehnic;
- rolurile tehnice sunt ordonate după ordinea layer-ului, apoi după ordinea rolului;
- endpointul de modificare a combinațiilor layer–rol pe serviciu a fost eliminat din API și OpenAPI;
- actualizarea nu necesită migrare de schemă.

## 0.3.7

- fiecare rol tehnic este legat explicit de unul sau mai multe layer-e arhitecturale;
- rolurile sunt filtrate după layer în configurarea serviciului intern;
- validare server-side globală layer–rol, suplimentară față de validarea serviciului;
- relațiile deja folosite sunt migrate automat prin `015_layer_technical_role_mappings.up.sql`;
- relațiile utilizate nu pot fi eliminate accidental;
- Nomenclatoare afișează layer-ele permise pentru fiecare rol tehnic.

## 0.3.6

- relație multiplă VM–serviciu intern–layer–rol tehnic;
- mai multe servicii interne și mai multe roluri pentru același serviciu pe un singur VM;
- tip de utilizare `dedicated`, `shared` sau `dependency`, marcaj principal și observații pe asociere;
- profilul/data provisionării eliminate din modelul funcțional și din nomenclatoare;
- vechiul lifecycle `Retired` migrat la `Status operațional: Retras` și eliminat din interfața/API curent;
- cardul redundant „Rezumat ultimul inventar” eliminat;
- migrarea `014_multi_service_assignments.up.sql`, API, OpenAPI și documentație actualizate.

## 0.3.5

- fișa VM continuă să se încarce dacă datele operaționale sau sumarul de backup au o eroare;
- toate etapele de încărcare a fișei VM sunt jurnalizate cu `stage` și `vm_id`;
- versiunea din interfață este citită din `/version`, nu mai este hard-codată.

## 0.3.4

- pagina VM se încarcă degradat dacă datele agentului, snapshotul curent sau vederea structurată nu pot fi citite;
- erorile opționale din fișa VM sunt jurnalizate cu etapa exactă și `vm_id`;
- interfața afișează un avertisment fără a bloca datele vCenter și operaționale.

## 0.3.3

- secțiunile cu datele colectate de agent sunt restrânse implicit, inclusiv listele de obiecte din interior;
- istoricul inventarelor VM este paginat server-side, cu 10, 20, 50 sau 100 de înregistrări pe pagină;
- pagina Audit este paginată server-side, cu 25, 50, 100 sau 200 de evenimente pe pagină;
- endpointurile de inventar și audit acceptă `page` și `page_size` și întorc metadate de paginare;
- OpenAPI, testele și documentația de upgrade au fost actualizate;
- include corecția de compilare pentru funcția `nullableInt64Ptr` din 0.3.2.

## 0.3.2

- meniu principal **Servicii** pentru catalogul serviciilor interne;
- `Serviciu` ITIL este redenumit **Categorie de serviciu**, iar vechea `Componentă` devine **Serviciu intern**;
- ierarhie validată `Domeniu arhitectural → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- categoriile de serviciu sunt legate de domeniul arhitectural părinte;
- fiecare serviciu definește explicit combinațiile layer–rol permise;
- fișa VM folosește list-box-uri în cascadă și backendul respinge combinațiile incompatibile;
- pagina serviciului afișează descrierea, criticitatea, starea documentației, combinațiile permise și VM-urile asociate;
- migrare automată a datelor 0.3.1 și permisiuni RBAC `services.read` / `services.manage`;
- API și OpenAPI pentru catalogul serviciilor prin migrarea `013_internal_service_catalog.up.sql`.

## 0.3.1

- meniu nou **Nomenclatoare** pentru serviciu, componentă, domeniu arhitectural, layer, mediu, status operațional, profil de provisionare și clasificare;
- câmpurile controlate din fișa VM sunt list-box-uri și nu mai acceptă text liber;
- registru de persoane și mai multe responsabilități pe aceeași VM;
- secțiune separată **Backup și restaurare · Veeam**, cu model de date pregătit pentru sincronizarea prin API;
- migrarea automată a valorilor și responsabililor existenți din 0.3.0;
- endpointuri API, audit și OpenAPI pentru nomenclatoare și persoane;
- migrarea `012_nomenclatures_responsibilities_backup.up.sql`.

## 0.3.0

- pagină VM refăcută ca fișă tehnică structurată pe carduri și secțiuni pliabile;
- vedere sigură a inventarului agentului, cu mascarea câmpurilor sensibile;
- date operaționale separate de snapshoturile agentului și sincronizarea vCenter;
- tabel nou `vm_operational_metadata` prin migrarea 011;
- endpoint `PUT /api/v1/vms/{id}/operational` și audit `vm.operational.update`;
- formular pentru serviciu, componentă, domeniu, layer, mediu, status, scop, responsabili, provisionare, RPO/RTO, backup, clasificare și referințe;
- OpenAPI, documentație și teste actualizate.

## 0.2.2

- autoînregistrare pentru vm-doc-agent 1.1.0;
- heartbeat și stare online/offline fără creare manuală;
- push direct al inventarului;
- asociere automată cu VM după UUID;
- migrarea 010 și documentația de upgrade.


## 0.2.1

- căutare și filtre VM după nume/hostname, power, OS, IP, agent, `Retired` și sursă vCenter;
- paginare server-side și selector 25/50/100/200 înregistrări;
- statistici pentru rezultatele filtrate;
- export Excel `.xlsx` fără dependențe Go suplimentare;
- antet fix corect în tabelul VM, fără suprapunerea primului rând;
- API-ul `GET /api/v1/vms` întoarce un obiect paginat;
- endpoint nou `GET /api/v1/vms/export`;
- listele vCenter goale sunt serializate ca `[]`, nu `null`;
- rutele Swagger sunt înregistrate explicit ca `GET`, evitând panic în Go 1.23.

## 0.2.0

- vCenter devine sursa principală pentru lista de VM-uri;
- CRUD pentru surse vCenter, cu parolă criptată și verificare TLS;
- sincronizare manuală per sursă sau pentru toate sursele;
- scheduler zilnic configurabil per sursă, în fusul orar al aplicației;
- tabele `vcenter_sources`, `virtual_machines` și `vcenter_sync_runs`;
- VM-urile absente sunt marcate `missing_from_vcenter`, fără ștergere automată;
- lifecycle local `Retired`, cu dată, utilizator și notă;
- asociere automată după BIOS/DMI UUID, inclusiv ordinea SMBIOS legacy VMware;
- asociere manuală și dezlegare agent din fișa VM;
- stare agent și colectare manuală direct din fișa VM;
- parser pentru `agent.id`, `agent.version`, `collection.collectors`, FQDN și UUID-uri de corelare;
- listă VM, filtre, pagină de detaliu și istoric sincronizări în frontend;
- permisiuni RBAC noi: `vcenter.read`, `vcenter.manage`, `vms.manage`;
- OpenAPI 3.1 și documentație actualizate.

## 0.1.0

- două binare: `vm-doc-server` și `vm-doc-collector`;
- configurație YAML și secrete criptate AES-256-GCM;
- migrații MariaDB incluse în binar;
- autentificare LDAP și Keycloak/OIDC cu PKCE;
- sesiuni server-side, CSRF și RBAC;
- administrarea agenților și tokenuri criptate individual;
- joburi manuale și periodice cu lease;
- testare agent, colectare, UUID binding și validare schemă 2.x;
- snapshoturi brute, istoric, hash și stare online/offline;
- audit server/collector;
- frontend static fără Node.js;
- OpenAPI 3.1 și Swagger UI embedded;
- unități systemd și reverse proxy Nginx.
