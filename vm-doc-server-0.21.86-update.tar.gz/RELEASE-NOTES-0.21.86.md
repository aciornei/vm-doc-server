# VM-DOC Server 0.21.86 — UI Modificări și salvare în grup

**Bază:** 0.21.85. **Data:** 2026-10-23. **Agent:** 1.7.18, neschimbat.

### Funcționalități
- Navigarea globală Modificări / De documentat / Ghid are bara lată și taburi compacte, nu întinse pe toată lățimea.
- Cardurile globale de sinteză au dimensiuni comparabile cu cele din VM.
- De documentat (global și VM) folosește tabel de 14 px și căutare amplă, cu lupa la dreapta; filtrele și exportul Excel din 0.21.85 rămân.
- În VM → Modificări se pot bifa individual sau «toate» **numai pe pagina curentă**. Selectoare pentru Documentație și Stare și buton «Salvează selectate». Valorile necompletate la selectorul global rămân cele ale fiecărui rând. Operația solicită confirmare și salvează prin PATCH per rând, apoi reîncarcă lista. Revizuit/Ignorat avansează baseline-ul obiectelor conform logicii existente.
- În De documentat (global și VM) există selecție bulk pentru obligații **pending + reviewed**, cu confirmare și POST de documentare per obligație. Cele nerevizuite nu pot fi documentate direct. Dacă unele cereri eșuează, interfața raportează câte au reușit/eșuat.
- Ghidul este comun global/VM, fără matricea Documentație × Stare, și explică separate obligațiile de documentare.
- Timeline: data la stânga axei cronologice, comutator ignorate în dreapta antetului, explicațiile despre date sub timeline.
- Overflow orizontal document-wide este prevenit; tabelele mari derulează local.

### Limite
- Bulk nu este un tranzacțional atomic de server: folosește endpointuri existente, astfel că o eroare poate lăsa rezultate parțiale. Nu include elemente de pe alte pagini fără selecție explicită.
- Nu există migrare SQL, schimbare API, job nou de fundal sau notificări suplimentare.
- Nu am rulat integrarea completă cu MariaDB, AD, VCSA ori build-ul Go cu vendor/.
