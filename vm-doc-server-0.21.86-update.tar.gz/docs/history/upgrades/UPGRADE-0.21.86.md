# Upgrade VM-DOC 0.21.85 → 0.21.86

1. Faceți backup la MariaDB și păstrați binarul/sursele actuale pentru rollback.
2. Opriți serverul și aplicați `vm-doc-server-0.21.85-to-0.21.86-update.tar.gz` în rădăcina surselor **0.21.85** sau folosiți arhiva cu sursele complete.
3. Verificați `bash scripts/cleanup-source-tree.sh --check`.
4. Compilați offline: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build` cu `vendor/` corespunzător.
5. Instalați binarul nou în calea `ExecStart` a unității systemd și reporniți serviciul. JS/CSS sunt incluse în binar prin `go:embed`.
6. În browser verificați `app.js?v=0.21.86` și `app.css?v=0.21.86`.
7. Global → Modificări: taburi compacte; De documentat: căutare, font 14px, selecție bulk a obligațiilor revizuite și Excel existent.
8. VM → Modificări: verificați că selectarea tuturor se limitează la **pagina curentă** și că revizia bulk avansează baseline-ul numai pentru obiectele selectate.
9. VM → De documentat: confirmați închiderea independentă a obligațiilor eligibile, apoi verificați clopoțelul.
10. VM → Timeline/Ghid: dată pe axa din stânga, selector ignorate în dreapta, Ghid identic cu cel global și fără tabelul anterior de combinații.

**Fără migrare SQL și fără modificare de agent.** Rollback: reinstalați binarul 0.21.85; baza de date rămâne compatibilă. Bulk folosește apeluri individuale și poate avea succese parțiale; efectuați teste în staging înainte de producție.
