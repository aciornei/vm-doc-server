# VM-DOC Server 0.21.54 — Windows per-user service noise

Base: VM-DOC Server **0.21.53**. Agent 1.7.18 unchanged.

- Explicitly suppress `P9RdrService_*`, `NPSMSvc_*`, `DeviceAssociationBrokerSvc_*` per-user instances with 5–12 hexadecimal suffixes from change history.
- Leave base service names and unknown/application services tracked. Raw inventory, service UI and other change categories unchanged.
- Extend cumulative manual PREVIEW/CLEANUP SQL to remove existing unreviewed/undecided/unnoted rows matching these patterns.
- No migration, no API/dependency changes. Full build with vendor and SQL execution on MariaDB remain to be tested in staging.
