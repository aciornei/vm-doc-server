VM-DOC Server 0.21.54 — per-user Windows suffix noise, incremental over 0.21.53.
Includes source.zip, update.tar.gz, patch, SQL preview + cleanup (cumulative 0.21.50-0.21.54), CONTEXT, CHANGELOG, TODO, upgrade/rollback docs and SHA256.
Backup & staging test mandatory before SQL cleanup. Agent 1.7.18 unchanged.
