-- VM-DOC 0.21.54 · analiza/curatare zgomot inventory_changes
-- Ruleaza EXCLUSIV pe MariaDB-ul VM-DOC; operatorul trebuie sa selecteze baza corecta.
-- Protejeaza review-urile, deciziile de documentare si orice observatie manuala.
-- Criterii identice in PREVIEW si DELETE (sunt generate din aceeasi lista).
-- OPRITI vm-doc-server in timpul curatarii si faceti backup inainte.
-- NU afecteaza inventory_snapshots sau inventarul brut al agentului.
-- Ruleaza numai DUPA preview si backup. Operatia DELETE este ireversibila fara backup.
-- MariaDB / mysql CLI: mariadb -u ... -p NUME_BAZA < scripts/cleanup-inventory-changes.sql
-- O singura tranzactie: ori toate stergerile sunt confirmate, ori pot fi rollback.
START TRANSACTION;

-- porturi_dinamice
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'ports' AND c.object_type = 'listening_port' AND c.change_type IN ('added','removed')
AND c.object_label REGEXP '^Port [A-Za-z]+/[0-9]+$'
AND CAST(SUBSTRING_INDEX(c.object_label,'/',-1) AS UNSIGNED) BETWEEN 49152 AND 65535
AND NOT EXISTS (
 SELECT 1 FROM vm_primary_agent_ports pp WHERE pp.vm_id = c.vm_id
 AND LOWER(pp.protocol) = LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_label,' ', -1),'/',1))
 AND pp.port = CAST(SUBSTRING_INDEX(c.object_label,'/',-1) AS UNSIGNED)
));
SELECT 'porturi_dinamice' AS motiv, ROW_COUNT() AS sterse;

-- firewall_generat
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'firewall' AND c.object_type = 'rule' AND c.change_type IN ('added','removed')
AND LOWER(SUBSTRING_INDEX(c.object_key,'|',1)) IN ('nftables','iptables','ip6tables')
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',4),'|',-1)) REGEXP '^(ufw-(before|after|track|logging|skip|reject|not-local)(-|$)|docker(-|$)|cni-|kube-|libvirt)'
AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(c.object_key,'|',6),'|',-1)) NOT LIKE 'docker-user%');
SELECT 'firewall_generat' AS motiv, ROW_COUNT() AS sterse;

-- servicii_efemere
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'services' AND c.object_type = 'service'
AND SUBSTRING_INDEX(c.object_key,'|',-1) REGEXP '^(user|user-runtime-dir)@[0-9]+[.]service$|^lxd-installer@[0-9]+(-[0-9]+)*[.]service$');
SELECT 'servicii_efemere' AS motiv, ROW_COUNT() AS sterse;

-- stare_runtime_servicii
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='services' AND c.object_type='service' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND BINARY JSON_REMOVE(c.old_json,'$.active_state','$.sub_state') =
    BINARY JSON_REMOVE(c.new_json,'$.active_state','$.sub_state'));
SELECT 'stare_runtime_servicii' AS motiv, ROW_COUNT() AS sterse;

-- stare_runtime_ntp
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='time' AND c.object_type='ntp' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND BINARY JSON_REMOVE(c.old_json,'$.service_active','$.synchronized','$.current_source') =
    BINARY JSON_REMOVE(c.new_json,'$.service_active','$.synchronized','$.current_source'));
SELECT 'stare_runtime_ntp' AS motiv, ROW_COUNT() AS sterse;

-- probe_runtime_integrari
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='integrations' AND c.object_type='integration' AND c.change_type='modified'
AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
AND BINARY JSON_REMOVE(c.old_json,'$.service_active','$.config_valid','$.config_check_output','$.output_test_ok','$.output_test_output') =
    BINARY JSON_REMOVE(c.new_json,'$.service_active','$.config_valid','$.config_check_output','$.output_test_ok','$.output_test_output'));
SELECT 'probe_runtime_integrari' AS motiv, ROW_COUNT() AS sterse;


-- Extins in 0.21.54: + P9RdrService, NPSMSvc, DeviceAssociationBrokerSvc. Restul criteriilor raman nemodificate.
-- Noi in 0.21.51: instanțe Windows per-user, eroare versiunii MySQL

-- instante_windows_per_user
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='services' AND c.object_type='service' AND LOWER(SUBSTRING_INDEX(c.object_key,'|',-1)) REGEXP '^(aarsvc|bcastdvruserservice|bluetoothuserservice|captureservice|cbdhsvc|cdpusersvc|cloudbackuprestoresvc|consentuxusersvc|credentialenrollmentmanagerusersvc|devicepickerusersvc|devicesflowusersvc|deviceassociationbrokersvc|npsmsvc|p9rdrservice|messagingservice|onesyncsvc|pimindexmaintenancesvc|printworkflowusersvc|udkusersvc|unistoresvc|userdatasvc|webthreatdefusersvc|wpnuserservice)_[0-9a-f]{5,12}$');
SELECT 'instante_windows_per_user' AS motiv, ROW_COUNT() AS sterse;

-- warning_versiune_mysql
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category='services' AND c.object_type='service' AND c.change_type='modified'
 AND JSON_VALID(c.old_json) AND JSON_VALID(c.new_json)
 AND LOWER(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'')) LIKE '%[warning]%'
 AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'') REGEXP '^[0-9]{6} [0-9]{1,2}:[0-9]{2}:[0-9]{2} '
 AND LOCATE(CHAR(10),COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'')) = 0
 AND LOWER(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'')) LIKE '%[warning]%'
 AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'') REGEXP '^[0-9]{6} [0-9]{1,2}:[0-9]{2}:[0-9]{2} '
 AND LOCATE(CHAR(10),COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'')) = 0
 AND BINARY JSON_REMOVE(c.old_json,'$.version') = BINARY JSON_REMOVE(c.new_json,'$.version'));
SELECT 'warning_versiune_mysql' AS motiv, ROW_COUNT() AS sterse;


-- Perechi adăugat/eliminat cu conținut identic (porturi inclusiv TCP/80).
-- Folosim tabelă temporară pentru a evita citirea modificată a aceleiași tabele.
CREATE TEMPORARY TABLE tmp_vm_doc_port_flaps_02152 (
 id BIGINT NOT NULL PRIMARY KEY
) ENGINE=InnoDB;
INSERT IGNORE INTO tmp_vm_doc_port_flaps_02152(id)
SELECT c.id FROM inventory_changes c
WHERE c.review_status='new' AND c.documentation_requirement='unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'')=''
AND (c.category='ports' AND c.object_type='listening_port' AND c.change_type IN ('added','removed')
AND EXISTS (
    SELECT 1 FROM inventory_changes pair
    WHERE pair.id<>c.id AND pair.vm_id=c.vm_id
      AND pair.category=c.category AND pair.object_type=c.object_type
      AND pair.object_key=c.object_key AND pair.object_label=c.object_label
      AND pair.change_type=IF(c.change_type='added','removed','added')
      AND pair.occurred_at BETWEEN c.occurred_at - INTERVAL 10 MINUTE AND c.occurred_at + INTERVAL 10 MINUTE
      AND BINARY COALESCE(c.new_json,c.old_json,'') = BINARY COALESCE(pair.new_json,pair.old_json,'')
      AND pair.review_status='new' AND pair.documentation_requirement='unset'
      AND pair.reviewed_at IS NULL AND COALESCE(TRIM(pair.notes),'')=''
));
DELETE c FROM inventory_changes c
JOIN tmp_vm_doc_port_flaps_02152 f ON f.id=c.id;
SELECT 'fluctuatii_porturi_confirmate' AS motiv, ROW_COUNT() AS sterse;
DROP TEMPORARY TABLE tmp_vm_doc_port_flaps_02152;

-- 0.21.53: curata numai evenimentele pentru peer-uri veth generate automat.
-- NU sterge snapshoturi si NU sterge interfețe de retea permanente.
DELETE c FROM inventory_changes c
WHERE c.review_status = 'new' AND c.documentation_requirement = 'unset' AND c.reviewed_at IS NULL AND COALESCE(TRIM(c.notes),'') = ''
AND (c.category = 'network' AND c.object_type = 'interface'
AND LOWER(TRIM(c.object_key)) REGEXP '^veth[0-9a-f]{5,}(@if[0-9]+)?$');
SELECT 'interfete_veth_efemere' AS motiv, ROW_COUNT() AS sterse;

COMMIT;
SELECT COUNT(*) AS evenimente_ramase FROM inventory_changes;
-- Nu OPTIMIZE TABLE automat; poate bloca tabela si se decide separat in mentenanta.
