# Upgrade VM-DOC Server 0.21.53 → 0.21.54

1. Verificați că sursele de bază sunt versiunea **0.21.53**. Faceți backup la MariaDB, configurații, binar și sursele existente.
2. Opriți `vm-doc-server` și aplicați `vm-doc-server-0.21.54-update.tar.gz` peste sursele 0.21.53 sau patch-ul incremental. Nu suprascrieți `vendor/`/configurațiile. Pentru instalare de la zero există arhiva `source.zip`.
3. Pe mașina offline cu `vendor/`, rulați: `GOPROXY=off GOSUMDB=off go test ./internal/inventorychanges`, apoi `GOPROXY=off GOSUMDB=off go test ./...` și `make build`. Reinstalați binarul compilat doar după validare.
4. În staging confirmați că `P9RdrService_b6809`, `P9RdrService_31c5b23`, `NPSMSvc_*`, `DeviceAssociationBrokerSvc_*` nu mai generează evenimente, dar `P9RdrService` fără sufix și aplicațiile terțe sunt păstrate. Inventarele JSON brute rămân identice.
5. Pentru curățare istorică **opțională și manuală**, opriți serverul, faceți backup verificabil și rulați `scripts/preview-inventory-changes-cleanup.sql`. Analizați **toate** categoriile din scriptul cumulativ 0.21.50–0.21.54, nu doar serviciile Windows. După validare în staging, rulați `scripts/cleanup-inventory-changes.sql`; verificați contorii înainte/după.
6. Porniți serverul și urmăriți 2–3 zile. Nu rulați SQL-urile vechi suplimentar; cel curent este cumulativ.

**Nu există migrare SQL automată, schimbări API ori modificări de agent.** `vm-doc-agent` 1.7.18 este compatibil. SQL-ul nu a fost executat în această sesiune pe MariaDB reală.

**Rollback:** restaurați binarul/sursele 0.21.53. Pentru readucerea rândurilor eliminate din `inventory_changes`, restaurați backup-ul MariaDB; SQL cleanup nu poate fi inversat.
