package external

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/url"
	"regexp"
	"strings"
	"time"
)

type Service struct{ DB *sql.DB }

type Network struct {
	ID                int64     `json:"id"`
	Name              string    `json:"name"`
	Code              string    `json:"code"`
	Color             string    `json:"color"`
	ZoneType          string    `json:"zone_type"`
	RiskLevel         string    `json:"risk_level"`
	TrustLevel        string    `json:"trust_level"`
	CIDRs             string    `json:"cidrs"`
	OwnerOrganization string    `json:"owner_organization"`
	Description       string    `json:"description"`
	SecurityNotes     string    `json:"security_notes"`
	Active            bool      `json:"active"`
	SystemCount       int       `json:"system_count"`
	ConnectionCount   int       `json:"connection_count"`
	CreatedAt         time.Time `json:"created_at"`
	UpdatedAt         time.Time `json:"updated_at"`
}

type NetworkInput struct {
	Name              string `json:"name"`
	Code              string `json:"code"`
	Color             string `json:"color"`
	ZoneType          string `json:"zone_type"`
	RiskLevel         string `json:"risk_level"`
	TrustLevel        string `json:"trust_level"`
	CIDRs             string `json:"cidrs"`
	OwnerOrganization string `json:"owner_organization"`
	Description       string `json:"description"`
	SecurityNotes     string `json:"security_notes"`
	Active            *bool  `json:"active,omitempty"`
}

type System struct {
	ID                int64        `json:"id"`
	Name              string       `json:"name"`
	SystemType        string       `json:"system_type"`
	Hostname          string       `json:"hostname"`
	IPAddresses       string       `json:"ip_addresses"`
	OwnerOrganization string       `json:"owner_organization"`
	Description       string       `json:"description"`
	DocumentationURL  string       `json:"documentation_url"`
	NetworkID         *int64       `json:"network_id,omitempty"`
	NetworkName       string       `json:"network_name"`
	NetworkCode       string       `json:"network_code"`
	NetworkColor      string       `json:"network_color"`
	NetworkZoneType   string       `json:"network_zone_type"`
	NetworkRiskLevel  string       `json:"network_risk_level"`
	NetworkTrustLevel string       `json:"network_trust_level"`
	Active            bool         `json:"active"`
	ConnectionCount   int          `json:"connection_count"`
	Connections       []Connection `json:"connections,omitempty"`
	CreatedAt         time.Time    `json:"created_at"`
	UpdatedAt         time.Time    `json:"updated_at"`
}

type SystemInput struct {
	Name              string `json:"name"`
	SystemType        string `json:"system_type"`
	Hostname          string `json:"hostname"`
	IPAddresses       string `json:"ip_addresses"`
	OwnerOrganization string `json:"owner_organization"`
	Description       string `json:"description"`
	DocumentationURL  string `json:"documentation_url"`
	NetworkID         *int64 `json:"network_id,omitempty"`
	Active            *bool  `json:"active,omitempty"`
}

type Connection struct {
	ID                  int64     `json:"id"`
	ExternalSystemID    int64     `json:"external_system_id"`
	ExternalSystemName  string    `json:"external_system_name"`
	ExternalHostname    string    `json:"external_hostname"`
	ExternalIPAddresses string    `json:"external_ip_addresses"`
	NetworkID           *int64    `json:"network_id,omitempty"`
	NetworkName         string    `json:"network_name"`
	NetworkCode         string    `json:"network_code"`
	NetworkColor        string    `json:"network_color"`
	NetworkZoneType     string    `json:"network_zone_type"`
	NetworkRiskLevel    string    `json:"network_risk_level"`
	NetworkTrustLevel   string    `json:"network_trust_level"`
	InternalServiceID   *int64    `json:"internal_service_id,omitempty"`
	InternalServiceName string    `json:"internal_service_name"`
	VMID                *int64    `json:"vm_id,omitempty"`
	VMName              string    `json:"vm_name"`
	Direction           string    `json:"direction"`
	RemoteService       string    `json:"remote_service"`
	Protocol            string    `json:"protocol"`
	Port                *int      `json:"port,omitempty"`
	TLSEnabled          bool      `json:"tls_enabled"`
	Authentication      string    `json:"authentication"`
	Purpose             string    `json:"purpose"`
	Notes               string    `json:"notes"`
	Active              bool      `json:"active"`
	CreatedAt           time.Time `json:"created_at"`
	UpdatedAt           time.Time `json:"updated_at"`
}

type ConnectionInput struct {
	ExternalSystemID  int64  `json:"external_system_id"`
	InternalServiceID *int64 `json:"internal_service_id,omitempty"`
	VMID              *int64 `json:"vm_id,omitempty"`
	Direction         string `json:"direction"`
	RemoteService     string `json:"remote_service"`
	Protocol          string `json:"protocol"`
	Port              *int   `json:"port,omitempty"`
	TLSEnabled        bool   `json:"tls_enabled"`
	Authentication    string `json:"authentication"`
	Purpose           string `json:"purpose"`
	Notes             string `json:"notes"`
	Active            *bool  `json:"active,omitempty"`
}

var (
	codePattern  = regexp.MustCompile(`^[a-z0-9][a-z0-9_-]{0,63}$`)
	colorPattern = regexp.MustCompile(`^#[0-9A-Fa-f]{6}$`)
)

func (s Service) ListNetworks(ctx context.Context, q, active string) ([]Network, error) {
	where := []string{"1=1"}
	args := make([]any, 0, 5)
	if q = strings.TrimSpace(q); q != "" {
		like := "%" + q + "%"
		where = append(where, "(n.name LIKE ? OR n.code LIKE ? OR n.owner_organization LIKE ? OR n.cidrs LIKE ? OR n.description LIKE ?)")
		args = append(args, like, like, like, like, like)
	}
	switch strings.ToLower(strings.TrimSpace(active)) {
	case "active", "1", "true":
		where = append(where, "n.active=1")
	case "inactive", "0", "false":
		where = append(where, "n.active=0")
	}
	rows, err := s.DB.QueryContext(ctx, networkSelect+" WHERE "+strings.Join(where, " AND ")+" ORDER BY n.active DESC,n.name,n.id", args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]Network, 0)
	for rows.Next() {
		v, err := scanNetwork(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

func (s Service) GetNetwork(ctx context.Context, id int64) (Network, error) {
	return scanNetwork(s.DB.QueryRowContext(ctx, networkSelect+" WHERE n.id=?", id))
}

func (s Service) CreateNetwork(ctx context.Context, userID int64, input NetworkInput) (Network, error) {
	if err := normalizeNetwork(&input); err != nil {
		return Network{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO external_networks(name,code,color,zone_type,risk_level,trust_level,cidrs,owner_organization,description,security_notes,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`, input.Name, input.Code, input.Color, input.ZoneType, input.RiskLevel, input.TrustLevel, input.CIDRs, input.OwnerOrganization, input.Description, input.SecurityNotes, active, userID, userID)
	if err != nil {
		return Network{}, err
	}
	id, _ := res.LastInsertId()
	return s.GetNetwork(ctx, id)
}

func (s Service) UpdateNetwork(ctx context.Context, id, userID int64, input NetworkInput) (Network, error) {
	current, err := s.GetNetwork(ctx, id)
	if err != nil {
		return Network{}, err
	}
	if strings.TrimSpace(input.Name) == "" {
		input.Name = current.Name
	}
	if strings.TrimSpace(input.Code) == "" {
		input.Code = current.Code
	}
	if strings.TrimSpace(input.Color) == "" {
		input.Color = current.Color
	}
	if strings.TrimSpace(input.ZoneType) == "" {
		input.ZoneType = current.ZoneType
	}
	if strings.TrimSpace(input.RiskLevel) == "" {
		input.RiskLevel = current.RiskLevel
	}
	if strings.TrimSpace(input.TrustLevel) == "" {
		input.TrustLevel = current.TrustLevel
	}
	if input.Active == nil {
		v := current.Active
		input.Active = &v
	}
	if err := normalizeNetwork(&input); err != nil {
		return Network{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE external_networks SET name=?,code=?,color=?,zone_type=?,risk_level=?,trust_level=?,cidrs=?,owner_organization=?,description=?,security_notes=?,active=?,updated_by=? WHERE id=?`, input.Name, input.Code, input.Color, input.ZoneType, input.RiskLevel, input.TrustLevel, input.CIDRs, input.OwnerOrganization, input.Description, input.SecurityNotes, *input.Active, userID, id)
	if err != nil {
		return Network{}, err
	}
	return s.GetNetwork(ctx, id)
}

func (s Service) DeleteNetwork(ctx context.Context, id int64) error {
	var systems int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM external_systems WHERE network_id=?`, id).Scan(&systems); err != nil {
		return err
	}
	if systems > 0 {
		return fmt.Errorf("external network is used by %d systems", systems)
	}
	res, err := s.DB.ExecContext(ctx, `DELETE FROM external_networks WHERE id=?`, id)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) List(ctx context.Context, q string, networkID *int64, active string) ([]System, error) {
	where := []string{"1=1"}
	args := make([]any, 0, 5)
	q = strings.TrimSpace(q)
	if q != "" {
		like := "%" + q + "%"
		where = append(where, "(x.name LIKE ? OR x.hostname LIKE ? OR x.ip_addresses LIKE ? OR x.owner_organization LIKE ?)")
		args = append(args, like, like, like, like)
	}
	if networkID != nil && *networkID > 0 {
		where = append(where, "x.network_id=?")
		args = append(args, *networkID)
	}
	switch strings.ToLower(strings.TrimSpace(active)) {
	case "active", "1", "true":
		where = append(where, "x.active=1")
	case "inactive", "0", "false":
		where = append(where, "x.active=0")
	}
	query := systemSelect + " WHERE " + strings.Join(where, " AND ") + " ORDER BY x.active DESC,COALESCE(n.name,'zzzz'),x.name,x.id"
	rows, err := s.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]System, 0)
	for rows.Next() {
		v, err := scanSystem(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

func (s Service) Get(ctx context.Context, id int64) (System, error) {
	v, err := scanSystem(s.DB.QueryRowContext(ctx, systemSelect+" WHERE x.id=?", id))
	if err != nil {
		return System{}, err
	}
	v.Connections, err = s.ListConnectionsForSystem(ctx, id, false)
	return v, err
}

func (s Service) Create(ctx context.Context, userID int64, input SystemInput) (System, error) {
	if err := s.normalizeSystem(ctx, &input); err != nil {
		return System{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO external_systems(name,system_type,hostname,ip_addresses,owner_organization,description,documentation_url,network_id,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)`, input.Name, input.SystemType, input.Hostname, input.IPAddresses, input.OwnerOrganization, input.Description, input.DocumentationURL, nullableInt64(input.NetworkID), active, userID, userID)
	if err != nil {
		return System{}, err
	}
	id, _ := res.LastInsertId()
	return s.Get(ctx, id)
}

func (s Service) Update(ctx context.Context, id, userID int64, input SystemInput) (System, error) {
	current, err := s.Get(ctx, id)
	if err != nil {
		return System{}, err
	}
	if strings.TrimSpace(input.Name) == "" {
		input.Name = current.Name
	}
	if strings.TrimSpace(input.SystemType) == "" {
		input.SystemType = current.SystemType
	}
	if input.Active == nil {
		v := current.Active
		input.Active = &v
	}
	if err := s.normalizeSystem(ctx, &input); err != nil {
		return System{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE external_systems SET name=?,system_type=?,hostname=?,ip_addresses=?,owner_organization=?,description=?,documentation_url=?,network_id=?,active=?,updated_by=? WHERE id=?`, input.Name, input.SystemType, input.Hostname, input.IPAddresses, input.OwnerOrganization, input.Description, input.DocumentationURL, nullableInt64(input.NetworkID), *input.Active, userID, id)
	if err != nil {
		return System{}, err
	}
	return s.Get(ctx, id)
}

func (s Service) Delete(ctx context.Context, id int64) error {
	res, err := s.DB.ExecContext(ctx, `DELETE FROM external_systems WHERE id=?`, id)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) CreateConnection(ctx context.Context, userID int64, input ConnectionInput) (Connection, error) {
	if err := s.normalizeConnection(ctx, &input); err != nil {
		return Connection{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO external_connections(external_system_id,internal_service_id,vm_id,direction,remote_service,protocol,port,tls_enabled,authentication,purpose,notes,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, input.ExternalSystemID, nullableInt64(input.InternalServiceID), nullableInt64(input.VMID), input.Direction, input.RemoteService, input.Protocol, nullableInt(input.Port), input.TLSEnabled, input.Authentication, input.Purpose, input.Notes, active, userID, userID)
	if err != nil {
		return Connection{}, err
	}
	id, _ := res.LastInsertId()
	return s.GetConnection(ctx, id)
}

func (s Service) UpdateConnection(ctx context.Context, id, userID int64, input ConnectionInput) (Connection, error) {
	current, err := s.GetConnection(ctx, id)
	if err != nil {
		return Connection{}, err
	}
	if input.ExternalSystemID == 0 {
		input.ExternalSystemID = current.ExternalSystemID
	}
	if input.InternalServiceID == nil {
		input.InternalServiceID = current.InternalServiceID
	}
	if input.VMID == nil {
		input.VMID = current.VMID
	}
	if strings.TrimSpace(input.Direction) == "" {
		input.Direction = current.Direction
	}
	if strings.TrimSpace(input.RemoteService) == "" {
		input.RemoteService = current.RemoteService
	}
	if strings.TrimSpace(input.Protocol) == "" {
		input.Protocol = current.Protocol
	}
	if input.Port == nil {
		input.Port = current.Port
	}
	if input.Active == nil {
		v := current.Active
		input.Active = &v
	}
	if err := s.normalizeConnection(ctx, &input); err != nil {
		return Connection{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE external_connections SET external_system_id=?,internal_service_id=?,vm_id=?,direction=?,remote_service=?,protocol=?,port=?,tls_enabled=?,authentication=?,purpose=?,notes=?,active=?,updated_by=? WHERE id=?`, input.ExternalSystemID, nullableInt64(input.InternalServiceID), nullableInt64(input.VMID), input.Direction, input.RemoteService, input.Protocol, nullableInt(input.Port), input.TLSEnabled, input.Authentication, input.Purpose, input.Notes, *input.Active, userID, id)
	if err != nil {
		return Connection{}, err
	}
	return s.GetConnection(ctx, id)
}

func (s Service) DeleteConnection(ctx context.Context, id int64) error {
	res, err := s.DB.ExecContext(ctx, `DELETE FROM external_connections WHERE id=?`, id)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) GetConnection(ctx context.Context, id int64) (Connection, error) {
	return scanConnection(s.DB.QueryRowContext(ctx, connectionSelect+` WHERE c.id=?`, id))
}
func (s Service) ListConnectionsForSystem(ctx context.Context, id int64, activeOnly bool) ([]Connection, error) {
	return s.listConnections(ctx, `c.external_system_id=?`, []any{id}, activeOnly)
}
func (s Service) ListConnectionsForVM(ctx context.Context, id int64, activeOnly bool) ([]Connection, error) {
	return s.listConnections(ctx, `c.vm_id=?`, []any{id}, activeOnly)
}
func (s Service) ListConnectionsForService(ctx context.Context, id int64, activeOnly bool) ([]Connection, error) {
	return s.listConnections(ctx, `c.internal_service_id=?`, []any{id}, activeOnly)
}

func (s Service) listConnections(ctx context.Context, where string, args []any, activeOnly bool) ([]Connection, error) {
	if activeOnly {
		where = "(" + where + ") AND c.active=1 AND x.active=1"
	}
	rows, err := s.DB.QueryContext(ctx, connectionSelect+` WHERE `+where+` ORDER BY c.active DESC,x.name,c.remote_service,c.protocol,c.port,c.id`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]Connection, 0)
	for rows.Next() {
		v, err := scanConnection(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

func normalizeNetwork(input *NetworkInput) error {
	input.Name = strings.TrimSpace(input.Name)
	input.Code = strings.ToLower(strings.TrimSpace(input.Code))
	input.Color = strings.ToUpper(strings.TrimSpace(input.Color))
	input.ZoneType = strings.ToLower(strings.TrimSpace(input.ZoneType))
	input.RiskLevel = strings.ToLower(strings.TrimSpace(input.RiskLevel))
	input.TrustLevel = strings.ToLower(strings.TrimSpace(input.TrustLevel))
	input.CIDRs = strings.TrimSpace(input.CIDRs)
	input.OwnerOrganization = strings.TrimSpace(input.OwnerOrganization)
	input.Description = strings.TrimSpace(input.Description)
	input.SecurityNotes = strings.TrimSpace(input.SecurityNotes)
	if input.Name == "" {
		return errors.New("external network name is required")
	}
	if input.Code == "" {
		input.Code = slugCode(input.Name)
	}
	if !codePattern.MatchString(input.Code) {
		return errors.New("network code must contain only lowercase letters, digits, _ or -")
	}
	if input.Color == "" {
		input.Color = "#6B7280"
	}
	if !colorPattern.MatchString(input.Color) {
		return errors.New("color must be in #RRGGBB format")
	}
	if input.ZoneType == "" {
		input.ZoneType = "other"
	}
	switch input.ZoneType {
	case "internet", "partner", "institution", "cloud", "external_dmz", "other":
	default:
		return errors.New("invalid zone_type")
	}
	if input.RiskLevel == "" {
		input.RiskLevel = "unknown"
	}
	switch input.RiskLevel {
	case "unknown", "low", "medium", "high", "critical":
	default:
		return errors.New("invalid risk_level")
	}
	if input.TrustLevel == "" {
		input.TrustLevel = "restricted"
	}
	switch input.TrustLevel {
	case "untrusted", "restricted", "trusted":
	default:
		return errors.New("invalid trust_level")
	}
	return nil
}

func (s Service) normalizeSystem(ctx context.Context, input *SystemInput) error {
	input.Name = strings.TrimSpace(input.Name)
	input.SystemType = strings.ToLower(strings.TrimSpace(input.SystemType))
	if input.SystemType == "" {
		input.SystemType = "vm"
	}
	switch input.SystemType {
	case "vm", "server", "endpoint", "network_service":
	default:
		return errors.New("system_type must be vm, server, endpoint or network_service")
	}
	input.Hostname = strings.TrimSpace(input.Hostname)
	input.IPAddresses = strings.TrimSpace(input.IPAddresses)
	input.OwnerOrganization = strings.TrimSpace(input.OwnerOrganization)
	input.Description = strings.TrimSpace(input.Description)
	input.DocumentationURL = strings.TrimSpace(input.DocumentationURL)
	if input.Name == "" {
		return errors.New("external system name is required")
	}
	if len(input.Name) > 255 {
		return errors.New("external system name is too long")
	}
	if input.DocumentationURL != "" {
		u, err := url.Parse(input.DocumentationURL)
		if err != nil || u.Scheme == "" || u.Host == "" {
			return errors.New("documentation_url must be an absolute URL")
		}
	}
	if input.NetworkID != nil && *input.NetworkID > 0 {
		var active bool
		if err := s.DB.QueryRowContext(ctx, `SELECT active FROM external_networks WHERE id=?`, *input.NetworkID).Scan(&active); err != nil {
			return fmt.Errorf("invalid external network: %w", err)
		}
		if !active {
			return errors.New("external network is inactive")
		}
	}
	return nil
}

func (s Service) normalizeConnection(ctx context.Context, input *ConnectionInput) error {
	if input.ExternalSystemID <= 0 {
		return errors.New("external_system_id is required")
	}
	var exists int
	if err := s.DB.QueryRowContext(ctx, `SELECT 1 FROM external_systems WHERE id=?`, input.ExternalSystemID).Scan(&exists); err != nil {
		return fmt.Errorf("invalid external system: %w", err)
	}
	if input.InternalServiceID == nil && input.VMID == nil {
		return errors.New("internal_service_id or vm_id is required")
	}
	input.Direction = strings.ToLower(strings.TrimSpace(input.Direction))
	if input.Direction == "" {
		input.Direction = "outbound"
	}
	switch input.Direction {
	case "outbound", "inbound", "bidirectional":
	default:
		return errors.New("direction must be outbound, inbound or bidirectional")
	}
	input.RemoteService = strings.TrimSpace(input.RemoteService)
	if input.RemoteService == "" {
		return errors.New("remote_service is required")
	}
	input.Protocol = strings.ToLower(strings.TrimSpace(input.Protocol))
	if input.Protocol == "" {
		input.Protocol = "tcp"
	}
	if len(input.Protocol) > 32 {
		return errors.New("protocol is too long")
	}
	if input.Port != nil && (*input.Port < 1 || *input.Port > 65535) {
		return errors.New("port must be between 1 and 65535")
	}
	input.Authentication = strings.TrimSpace(input.Authentication)
	input.Purpose = strings.TrimSpace(input.Purpose)
	input.Notes = strings.TrimSpace(input.Notes)
	return nil
}

func slugCode(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	var b strings.Builder
	lastSep := false
	for _, r := range value {
		if r >= 'a' && r <= 'z' || r >= '0' && r <= '9' {
			b.WriteRune(r)
			lastSep = false
		} else if !lastSep && b.Len() > 0 {
			b.WriteByte('_')
			lastSep = true
		}
	}
	return strings.Trim(b.String(), "_")
}

const networkSelect = `SELECT n.id,n.name,n.code,n.color,n.zone_type,n.risk_level,n.trust_level,n.cidrs,n.owner_organization,n.description,n.security_notes,n.active,(SELECT COUNT(*) FROM external_systems x WHERE x.network_id=n.id),(SELECT COUNT(*) FROM external_connections c JOIN external_systems x ON x.id=c.external_system_id WHERE x.network_id=n.id),n.created_at,n.updated_at FROM external_networks n`
const systemSelect = `SELECT x.id,x.name,x.system_type,x.hostname,x.ip_addresses,x.owner_organization,x.description,x.documentation_url,x.network_id,COALESCE(n.name,''),COALESCE(n.code,''),COALESCE(n.color,''),COALESCE(n.zone_type,''),COALESCE(n.risk_level,''),COALESCE(n.trust_level,''),x.active,(SELECT COUNT(*) FROM external_connections c WHERE c.external_system_id=x.id),x.created_at,x.updated_at FROM external_systems x LEFT JOIN external_networks n ON n.id=x.network_id`
const connectionSelect = `SELECT c.id,c.external_system_id,x.name,x.hostname,x.ip_addresses,x.network_id,COALESCE(n.name,''),COALESCE(n.code,''),COALESCE(n.color,''),COALESCE(n.zone_type,''),COALESCE(n.risk_level,''),COALESCE(n.trust_level,''),c.internal_service_id,COALESCE(s.name,''),c.vm_id,COALESCE(vm.name,''),c.direction,c.remote_service,c.protocol,c.port,c.tls_enabled,c.authentication,c.purpose,c.notes,c.active,c.created_at,c.updated_at FROM external_connections c JOIN external_systems x ON x.id=c.external_system_id LEFT JOIN external_networks n ON n.id=x.network_id LEFT JOIN internal_services s ON s.id=c.internal_service_id LEFT JOIN virtual_machines vm ON vm.id=c.vm_id`

type scanner interface{ Scan(...any) error }

func scanNetwork(s scanner) (Network, error) {
	var v Network
	err := s.Scan(&v.ID, &v.Name, &v.Code, &v.Color, &v.ZoneType, &v.RiskLevel, &v.TrustLevel, &v.CIDRs, &v.OwnerOrganization, &v.Description, &v.SecurityNotes, &v.Active, &v.SystemCount, &v.ConnectionCount, &v.CreatedAt, &v.UpdatedAt)
	return v, err
}

func scanSystem(s scanner) (System, error) {
	var v System
	var network sql.NullInt64
	err := s.Scan(&v.ID, &v.Name, &v.SystemType, &v.Hostname, &v.IPAddresses, &v.OwnerOrganization, &v.Description, &v.DocumentationURL, &network, &v.NetworkName, &v.NetworkCode, &v.NetworkColor, &v.NetworkZoneType, &v.NetworkRiskLevel, &v.NetworkTrustLevel, &v.Active, &v.ConnectionCount, &v.CreatedAt, &v.UpdatedAt)
	if network.Valid {
		x := network.Int64
		v.NetworkID = &x
	}
	return v, err
}

func scanConnection(s scanner) (Connection, error) {
	var v Connection
	var network, serviceID, vmID sql.NullInt64
	var port sql.NullInt64
	err := s.Scan(&v.ID, &v.ExternalSystemID, &v.ExternalSystemName, &v.ExternalHostname, &v.ExternalIPAddresses, &network, &v.NetworkName, &v.NetworkCode, &v.NetworkColor, &v.NetworkZoneType, &v.NetworkRiskLevel, &v.NetworkTrustLevel, &serviceID, &v.InternalServiceName, &vmID, &v.VMName, &v.Direction, &v.RemoteService, &v.Protocol, &port, &v.TLSEnabled, &v.Authentication, &v.Purpose, &v.Notes, &v.Active, &v.CreatedAt, &v.UpdatedAt)
	if network.Valid {
		x := network.Int64
		v.NetworkID = &x
	}
	if serviceID.Valid {
		x := serviceID.Int64
		v.InternalServiceID = &x
	}
	if vmID.Valid {
		x := vmID.Int64
		v.VMID = &x
	}
	if port.Valid {
		x := int(port.Int64)
		v.Port = &x
	}
	return v, err
}

func nullableInt64(v *int64) any {
	if v == nil || *v <= 0 {
		return nil
	}
	return *v
}
func nullableInt(v *int) any {
	if v == nil || *v <= 0 {
		return nil
	}
	return *v
}
