package external

import (
	"context"
	"testing"
)

func TestNormalizeSystem(t *testing.T) {
	input := SystemInput{Name: "  Partener API  ", SystemType: " ENDPOINT ", Hostname: " api.example.ro ", DocumentationURL: "https://docs.example.ro/api"}
	if err := (Service{}).normalizeSystem(context.Background(), &input); err != nil {
		t.Fatal(err)
	}
	if input.Name != "Partener API" || input.SystemType != "endpoint" || input.Hostname != "api.example.ro" {
		t.Fatalf("unexpected normalization: %#v", input)
	}
}

func TestNormalizeSystemRejectsInvalidTypeAndURL(t *testing.T) {
	for _, input := range []SystemInput{{Name: "X", SystemType: "container"}, {Name: "X", SystemType: "vm", DocumentationURL: "/relative"}} {
		if err := (Service{}).normalizeSystem(context.Background(), &input); err == nil {
			t.Fatalf("expected validation error for %#v", input)
		}
	}
}

func TestNormalizeNetwork(t *testing.T) {
	input := NetworkInput{Name: " Internet Public ", Code: "internet", Color: "#d32f2f", ZoneType: " INTERNET ", RiskLevel: " HIGH ", TrustLevel: " UNTRUSTED "}
	if err := normalizeNetwork(&input); err != nil {
		t.Fatal(err)
	}
	if input.Name != "Internet Public" || input.Color != "#D32F2F" || input.ZoneType != "internet" || input.RiskLevel != "high" || input.TrustLevel != "untrusted" {
		t.Fatalf("unexpected normalization: %#v", input)
	}
}

func TestNormalizeNetworkRejectsInvalidValues(t *testing.T) {
	for _, input := range []NetworkInput{
		{Name: "X", Code: "Invalid Code"},
		{Name: "X", Code: "x", Color: "red"},
		{Name: "X", Code: "x", ZoneType: "lan"},
		{Name: "X", Code: "x", RiskLevel: "danger"},
		{Name: "X", Code: "x", TrustLevel: "maybe"},
	} {
		if err := normalizeNetwork(&input); err == nil {
			t.Fatalf("expected validation error for %#v", input)
		}
	}
}
