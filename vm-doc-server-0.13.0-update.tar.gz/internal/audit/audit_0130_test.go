package audit

import "testing"

func TestDescribeActionChangeKinds(t *testing.T) {
	tests := map[string]string{
		"external_system.create": "created",
		"vm.update":              "updated",
		"agent.delete":           "deleted",
		"collection.queue":       "operation",
		"custom.resource.remove": "deleted",
	}
	for action, want := range tests {
		label, description, got := DescribeAction(action)
		if label == "" || description == "" {
			t.Fatalf("%s has empty description", action)
		}
		if got != want {
			t.Fatalf("%s operation=%s want %s", action, got, want)
		}
	}
}
