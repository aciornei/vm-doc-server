package server

import (
	"errors"
	"net/http"
	"strconv"
	"strings"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/external"
)

func (a *App) listExternalNetworks(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	values, err := a.External.ListNetworks(r.Context(), q.Get("q"), q.Get("active"))
	respond(w, values, err)
}

func (a *App) getExternalNetwork(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.External.GetNetwork(r.Context(), id)
	respond(w, value, err)
}

func (a *App) createExternalNetwork(w http.ResponseWriter, r *http.Request) {
	var input external.NetworkInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.External.CreateNetwork(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "external_network.create", "external_network", strconv.FormatInt(value.ID, 10), "success", map[string]any{"created": value})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updateExternalNetwork(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, err := a.External.GetNetwork(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	var input external.NetworkInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.External.UpdateNetwork(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "external_network.update", "external_network", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": value})
	}
	respond(w, value, err)
}

func (a *App) deleteExternalNetwork(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, err := a.External.GetNetwork(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.External.DeleteNetwork(r.Context(), id); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "external_network.delete", "external_network", strconv.FormatInt(id, 10), "success", map[string]any{"deleted": before})
	w.WriteHeader(http.StatusNoContent)
}

func (a *App) listExternalSystems(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	var networkID *int64
	if raw := strings.TrimSpace(q.Get("network_id")); raw != "" {
		id, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || id <= 0 {
			badRequest(w, errors.New("invalid network_id"))
			return
		}
		networkID = &id
	}
	values, err := a.External.List(r.Context(), q.Get("q"), networkID, q.Get("active"))
	respond(w, values, err)
}

func (a *App) getExternalSystem(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.External.Get(r.Context(), id)
	respond(w, value, err)
}

func (a *App) createExternalSystem(w http.ResponseWriter, r *http.Request) {
	var input external.SystemInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.External.Create(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "external_system.create", "external_system", strconv.FormatInt(value.ID, 10), "success", map[string]any{"created": value})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updateExternalSystem(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.External.Get(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	var input external.SystemInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.External.Update(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "external_system.update", "external_system", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": value})
	}
	respond(w, value, err)
}

func (a *App) deleteExternalSystem(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.External.Get(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	if err := a.External.Delete(r.Context(), id); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "external_system.delete", "external_system", strconv.FormatInt(id, 10), "success", map[string]any{"deleted": before})
	w.WriteHeader(http.StatusNoContent)
}

func (a *App) listExternalConnections(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	activeOnly := q.Get("include_inactive") != "1" && strings.ToLower(q.Get("include_inactive")) != "true"
	parse := func(name string) (*int64, error) {
		raw := strings.TrimSpace(q.Get(name))
		if raw == "" {
			return nil, nil
		}
		id, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || id <= 0 {
			return nil, errors.New("invalid " + name)
		}
		return &id, nil
	}
	systemID, err := parse("system_id")
	if err != nil {
		badRequest(w, err)
		return
	}
	vmID, err := parse("vm_id")
	if err != nil {
		badRequest(w, err)
		return
	}
	serviceID, err := parse("service_id")
	if err != nil {
		badRequest(w, err)
		return
	}
	var values []external.Connection
	switch {
	case systemID != nil:
		values, err = a.External.ListConnectionsForSystem(r.Context(), *systemID, activeOnly)
	case vmID != nil:
		values, err = a.External.ListConnectionsForVM(r.Context(), *vmID, activeOnly)
	case serviceID != nil:
		values, err = a.External.ListConnectionsForService(r.Context(), *serviceID, activeOnly)
	default:
		err = errors.New("system_id, vm_id or service_id is required")
	}
	respond(w, values, err)
}

func (a *App) createExternalConnection(w http.ResponseWriter, r *http.Request) {
	var input external.ConnectionInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.External.CreateConnection(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "external_connection.create", "external_connection", strconv.FormatInt(value.ID, 10), "success", map[string]any{"created": value})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updateExternalConnection(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.External.GetConnection(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	var input external.ConnectionInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.External.UpdateConnection(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "external_connection.update", "external_connection", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": value})
	}
	respond(w, value, err)
}

func (a *App) deleteExternalConnection(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, beforeErr := a.External.GetConnection(r.Context(), id)
	if beforeErr != nil {
		respond(w, nil, beforeErr)
		return
	}
	if err := a.External.DeleteConnection(r.Context(), id); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "external_connection.delete", "external_connection", strconv.FormatInt(id, 10), "success", map[string]any{"deleted": before})
	w.WriteHeader(http.StatusNoContent)
}
