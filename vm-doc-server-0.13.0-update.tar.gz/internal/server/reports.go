package server

import (
	"context"
	"database/sql"
	"net/http"
	"sort"
	"time"
)

type reportPoint struct {
	Label string `json:"label"`
	Value int64  `json:"value"`
}

type reportTimelinePoint struct {
	Date    string `json:"date"`
	VM      int64  `json:"vm"`
	Service int64  `json:"service"`
}

type reportServiceRow struct {
	ID                  int64  `json:"id"`
	Name                string `json:"name"`
	Criticality         string `json:"criticality"`
	DocumentationStatus string `json:"documentation_status"`
	VMCount             int64  `json:"vm_count"`
	Issue               string `json:"issue,omitempty"`
}

type reportVMRow struct {
	ID          int64  `json:"id"`
	Name        string `json:"name"`
	Hostname    string `json:"hostname"`
	Environment string `json:"environment"`
	PowerState  string `json:"power_state"`
	Issue       string `json:"issue"`
}

func (a *App) reportsOverview(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	summary := map[string]int64{}
	countQueries := map[string]string{
		"vms_total":                  `SELECT COUNT(*) FROM virtual_machines`,
		"vms_present":                `SELECT COUNT(*) FROM virtual_machines WHERE present_in_vcenter=1 AND retired=0`,
		"vms_powered_on":             `SELECT COUNT(*) FROM virtual_machines WHERE power_state='POWERED_ON' AND retired=0`,
		"vms_with_agent":             `SELECT COUNT(*) FROM virtual_machines WHERE agent_id IS NOT NULL AND retired=0`,
		"vms_with_inventory":         `SELECT COUNT(*) FROM virtual_machines WHERE current_inventory_id IS NOT NULL AND retired=0`,
		"services_total":             `SELECT COUNT(*) FROM internal_services`,
		"services_active":            `SELECT COUNT(*) FROM internal_services WHERE active=1`,
		"services_critical":          `SELECT COUNT(*) FROM internal_services WHERE active=1 AND criticality='critical'`,
		"vm_documents":               `SELECT COUNT(*) FROM generated_documents WHERE object_type='vm'`,
		"service_documents":          `SELECT COUNT(*) FROM generated_documents WHERE object_type='service'`,
		"services_without_vm":        `SELECT COUNT(*) FROM internal_services s WHERE s.active=1 AND NOT EXISTS (SELECT 1 FROM vm_internal_service_assignments a WHERE a.internal_service_id=s.id)`,
		"vms_without_environment":    `SELECT COUNT(*) FROM virtual_machines vm LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id WHERE vm.retired=0 AND COALESCE(m.environment,'')=''`,
		"vms_without_service":        `SELECT COUNT(*) FROM virtual_machines vm WHERE vm.retired=0 AND NOT EXISTS (SELECT 1 FROM vm_internal_service_assignments a WHERE a.vm_id=vm.id)`,
		"vms_without_document":       `SELECT COUNT(*) FROM virtual_machines vm WHERE vm.retired=0 AND NOT EXISTS (SELECT 1 FROM generated_documents d WHERE d.object_type='vm' AND d.vm_id=vm.id)`,
		"services_without_document":  `SELECT COUNT(*) FROM internal_services s WHERE s.active=1 AND NOT EXISTS (SELECT 1 FROM generated_documents d WHERE d.object_type='service' AND d.internal_service_id=s.id)`,
		"services_common":            `SELECT COUNT(*) FROM internal_services WHERE active=1 AND is_common=1`,
		"services_global":            `SELECT COUNT(*) FROM internal_services WHERE active=1 AND is_common=1 AND implicit_global=1`,
		"service_dependencies":       `SELECT COUNT(*) FROM internal_service_dependencies WHERE active=1`,
		"external_networks":          `SELECT COUNT(*) FROM external_networks WHERE active=1`,
		"external_systems":           `SELECT COUNT(*) FROM external_systems WHERE active=1`,
		"external_connections":       `SELECT COUNT(*) FROM external_connections WHERE active=1`,
		"services_with_dependencies": `SELECT COUNT(DISTINCT source_service_id) FROM internal_service_dependencies WHERE active=1`,
	}
	for key, query := range countQueries {
		var value int64
		if err := a.DB.QueryRowContext(ctx, query).Scan(&value); err != nil {
			respond(w, nil, err)
			return
		}
		summary[key] = value
	}

	charts := map[string][]reportPoint{}
	queries := map[string]string{
		"vm_power_state":               `SELECT COALESCE(NULLIF(power_state,''),'Nespecificat'),COUNT(*) FROM virtual_machines WHERE retired=0 GROUP BY 1 ORDER BY 2 DESC`,
		"vm_environment":               `SELECT COALESCE(NULLIF(m.environment,''),'Nespecificat'),COUNT(DISTINCT vm.id) FROM virtual_machines vm LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id WHERE vm.retired=0 GROUP BY 1 ORDER BY 2 DESC`,
		"vm_os":                        `SELECT COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,''),'Nespecificat'),COUNT(*) FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0 GROUP BY 1 ORDER BY 2 DESC LIMIT 12`,
		"vm_source":                    `SELECT COALESCE(NULLIF(vs.name,''),'Nespecificat'),COUNT(*) FROM virtual_machines vm LEFT JOIN vcenter_sources vs ON vs.id=vm.vcenter_source_id WHERE vm.retired=0 GROUP BY 1 ORDER BY 2 DESC`,
		"agent_coverage":               `SELECT CASE WHEN vm.agent_id IS NULL THEN 'Fără agent' WHEN a.enabled=0 THEN 'Agent dezactivat' WHEN a.last_contact_at IS NOT NULL AND TIMESTAMPDIFF(SECOND,a.last_contact_at,UTC_TIMESTAMP())<=a.offline_after_seconds THEN 'Agent online' ELSE 'Agent offline' END,COUNT(*) FROM virtual_machines vm LEFT JOIN agents a ON a.id=vm.agent_id WHERE vm.retired=0 GROUP BY 1 ORDER BY 2 DESC`,
		"backup_protection":            `SELECT CASE WHEN b.vm_id IS NULL THEN 'Fără date backup' WHEN b.protected=1 THEN 'Protejat' ELSE 'Neprotejat' END,COUNT(*) FROM virtual_machines vm LEFT JOIN vm_backup_summary b ON b.vm_id=vm.id WHERE vm.retired=0 GROUP BY 1 ORDER BY 2 DESC`,
		"inventory_freshness":          `SELECT CASE WHEN vm.current_inventory_id IS NULL THEN 'Fără inventar' WHEN i.received_at>=UTC_TIMESTAMP()-INTERVAL 1 DAY THEN '< 24h' WHEN i.received_at>=UTC_TIMESTAMP()-INTERVAL 7 DAY THEN '1–7 zile' ELSE '> 7 zile' END,COUNT(*) FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0 GROUP BY 1 ORDER BY FIELD(CASE WHEN vm.current_inventory_id IS NULL THEN 'Fără inventar' WHEN i.received_at>=UTC_TIMESTAMP()-INTERVAL 1 DAY THEN '< 24h' WHEN i.received_at>=UTC_TIMESTAMP()-INTERVAL 7 DAY THEN '1–7 zile' ELSE '> 7 zile' END,'< 24h','1–7 zile','> 7 zile','Fără inventar')`,
		"vm_documentation":             `SELECT CASE WHEN d.vm_id IS NULL THEN 'Fără fișă VM' ELSE 'Cu fișă VM' END,COUNT(*) FROM virtual_machines vm LEFT JOIN (SELECT DISTINCT vm_id FROM generated_documents WHERE object_type='vm' AND vm_id IS NOT NULL) d ON d.vm_id=vm.id WHERE vm.retired=0 GROUP BY 1`,
		"service_criticality":          `SELECT COALESCE(NULLIF(criticality,''),'Nespecificat'),COUNT(*) FROM internal_services WHERE active=1 GROUP BY 1 ORDER BY 2 DESC`,
		"service_documentation_status": `SELECT COALESCE(NULLIF(documentation_status,''),'Nespecificat'),COUNT(*) FROM internal_services WHERE active=1 GROUP BY 1 ORDER BY 2 DESC`,
		"service_documentation":        `SELECT CASE WHEN d.internal_service_id IS NULL THEN 'Fără fișă serviciu' ELSE 'Cu fișă serviciu' END,COUNT(*) FROM internal_services s LEFT JOIN (SELECT DISTINCT internal_service_id FROM generated_documents WHERE object_type='service' AND internal_service_id IS NOT NULL) d ON d.internal_service_id=s.id WHERE s.active=1 GROUP BY 1`,
		"service_domain":               `SELECT domain_item.name,COUNT(DISTINCT a.internal_service_id) FROM vm_internal_service_assignments a JOIN nomenclature_items domain_item ON domain_item.id=a.architectural_domain_id GROUP BY domain_item.id,domain_item.name ORDER BY 2 DESC,domain_item.name LIMIT 15`,
		"service_category":             `SELECT category_item.name,COUNT(DISTINCT a.internal_service_id) FROM vm_internal_service_assignments a JOIN nomenclature_items category_item ON category_item.id=a.itil_category_id GROUP BY category_item.id,category_item.name ORDER BY 2 DESC,category_item.name LIMIT 15`,
		"solution_type":                `SELECT COALESCE(solution_item.name,'Nespecificat'),COUNT(*) FROM vm_internal_service_assignments a LEFT JOIN nomenclature_items solution_item ON solution_item.id=a.solution_type_id GROUP BY 1 ORDER BY 2 DESC`,
		"layer_usage":                  `SELECT COALESCE(layer_item.name,'Nespecificat'),COUNT(DISTINCT a.vm_id) FROM vm_internal_service_assignments a LEFT JOIN nomenclature_items layer_item ON layer_item.id=a.layer_id GROUP BY 1 ORDER BY 2 DESC LIMIT 15`,
		"technical_role_usage":         `SELECT COALESCE(role_item.name,'Nespecificat'),COUNT(DISTINCT a.vm_id) FROM vm_internal_service_assignments a LEFT JOIN nomenclature_items role_item ON role_item.id=a.technical_role_id GROUP BY 1 ORDER BY 2 DESC LIMIT 20`,
		"assignment_usage":             `SELECT CASE a.usage_type WHEN 'dedicated' THEN 'Dedicat' WHEN 'shared' THEN 'Partajat' WHEN 'dependency' THEN 'Dependență' ELSE COALESCE(NULLIF(a.usage_type,''),'Nespecificat') END,COUNT(*) FROM vm_internal_service_assignments a GROUP BY 1 ORDER BY 2 DESC`,
		"vm_cpu_size":                  `SELECT CASE WHEN cpu_count<=2 THEN '1–2 vCPU' WHEN cpu_count<=4 THEN '3–4 vCPU' WHEN cpu_count<=8 THEN '5–8 vCPU' WHEN cpu_count<=16 THEN '9–16 vCPU' ELSE '> 16 vCPU' END,COUNT(*) FROM virtual_machines WHERE retired=0 GROUP BY 1 ORDER BY MIN(cpu_count)`,
		"vm_memory_size":               `SELECT CASE WHEN memory_mib<=4096 THEN '≤ 4 GB' WHEN memory_mib<=8192 THEN '4–8 GB' WHEN memory_mib<=16384 THEN '8–16 GB' WHEN memory_mib<=32768 THEN '16–32 GB' ELSE '> 32 GB' END,COUNT(*) FROM virtual_machines WHERE retired=0 GROUP BY 1 ORDER BY MIN(memory_mib)`,
		"vm_hardware_version":          `SELECT COALESCE(NULLIF(hardware_version,''),'Nespecificat'),COUNT(*) FROM virtual_machines WHERE retired=0 GROUP BY 1 ORDER BY 2 DESC LIMIT 15`,
		"vm_operational_status":        `SELECT COALESCE(NULLIF(m.operational_status,''),'Nespecificat'),COUNT(*) FROM virtual_machines vm LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id WHERE vm.retired=0 GROUP BY 1 ORDER BY 2 DESC`,
		"assignment_primary":           `SELECT CASE WHEN a.is_primary=1 THEN 'Asociere principală' ELSE 'Asociere secundară' END,COUNT(*) FROM vm_internal_service_assignments a GROUP BY 1`,
		"assignment_completeness":      `SELECT CASE WHEN a.layer_id IS NULL THEN 'Layer lipsă' WHEN a.technical_role_id IS NULL THEN 'Rol tehnic lipsă' WHEN a.solution_type_id IS NULL THEN 'Tip soluție lipsă' ELSE 'Completă' END,COUNT(*) FROM vm_internal_service_assignments a GROUP BY 1 ORDER BY 2 DESC`,
		"service_vm_size":              `SELECT CASE WHEN x.vm_count=0 THEN 'Fără VM' WHEN x.vm_count=1 THEN '1 VM' WHEN x.vm_count<=3 THEN '2–3 VM' WHEN x.vm_count<=6 THEN '4–6 VM' ELSE '> 6 VM' END,COUNT(*) FROM (SELECT s.id,COUNT(DISTINCT a.vm_id) vm_count FROM internal_services s LEFT JOIN vm_internal_service_assignments a ON a.internal_service_id=s.id WHERE s.active=1 GROUP BY s.id) x GROUP BY 1 ORDER BY MIN(x.vm_count)`,
		"service_environment_presence": `SELECT COALESCE(NULLIF(m.environment,''),'Nespecificat'),COUNT(DISTINCT a.internal_service_id) FROM vm_internal_service_assignments a LEFT JOIN vm_operational_metadata m ON m.vm_id=a.vm_id GROUP BY 1 ORDER BY 2 DESC`,
		"service_solution_mix":         `SELECT CASE WHEN x.cnt=0 THEN 'Fără tip soluție' WHEN x.cnt=1 THEN 'Un singur tip' ELSE 'Soluție mixtă' END,COUNT(*) FROM (SELECT s.id,COUNT(DISTINCT a.solution_type_id) cnt FROM internal_services s LEFT JOIN vm_internal_service_assignments a ON a.internal_service_id=s.id AND a.solution_type_id IS NOT NULL WHERE s.active=1 GROUP BY s.id) x GROUP BY 1`,
		"common_service_kind":          `SELECT CASE WHEN implicit_global=1 THEN 'Global implicit' ELSE 'Serviciu comun' END,COUNT(*) FROM internal_services WHERE active=1 AND is_common=1 GROUP BY 1 ORDER BY 2 DESC`,
		"dependency_type_usage":        `SELECT COALESCE(NULLIF(t.name,''),'Nespecificat'),COUNT(*) FROM (SELECT dependency_type_id FROM internal_service_dependencies WHERE active=1 UNION ALL SELECT dependency_type_id FROM vm_common_service_dependencies WHERE active=1 UNION ALL SELECT common_dependency_type_id dependency_type_id FROM internal_services WHERE active=1 AND is_common=1 AND implicit_global=1 AND common_dependency_type_id IS NOT NULL) usage_rows LEFT JOIN nomenclature_items t ON t.id=usage_rows.dependency_type_id GROUP BY t.id,t.name ORDER BY 2 DESC,t.name LIMIT 20`,
		"common_service_impact":        `SELECT s.name,CASE WHEN s.implicit_global=1 THEN GREATEST((SELECT COUNT(*) FROM internal_services x WHERE x.active=1)-1,0) ELSE COUNT(DISTINCT d.source_service_id) END impacted FROM internal_services s LEFT JOIN internal_service_dependencies d ON d.target_service_id=s.id AND d.active=1 WHERE s.active=1 AND s.is_common=1 GROUP BY s.id,s.name,s.implicit_global ORDER BY impacted DESC,s.name LIMIT 20`,
		"common_service_vm_impact":     `SELECT s.name,CASE WHEN s.implicit_global=1 THEN (SELECT COUNT(DISTINCT a.vm_id) FROM vm_internal_service_assignments a JOIN internal_services src ON src.id=a.internal_service_id AND src.active=1 WHERE src.id<>s.id) ELSE COUNT(DISTINCT a.vm_id)+(SELECT COUNT(DISTINCT direct.vm_id) FROM vm_common_service_dependencies direct WHERE direct.target_service_id=s.id AND direct.active=1 AND NOT EXISTS (SELECT 1 FROM vm_internal_service_assignments a4 JOIN internal_service_dependencies d4 ON d4.source_service_id=a4.internal_service_id AND d4.target_service_id=s.id AND d4.active=1 WHERE a4.vm_id=direct.vm_id)) END impacted FROM internal_services s LEFT JOIN internal_service_dependencies d ON d.target_service_id=s.id AND d.active=1 LEFT JOIN vm_internal_service_assignments a ON a.internal_service_id=d.source_service_id WHERE s.active=1 AND s.is_common=1 GROUP BY s.id,s.name,s.implicit_global ORDER BY impacted DESC,s.name LIMIT 20`,
		"primary_agent_software":       `SELECT REPLACE(service_name,'.service',''),COUNT(DISTINCT vm_id) FROM vm_primary_agent_services GROUP BY service_name ORDER BY 2 DESC,1 LIMIT 30`,
		"external_network_usage":       `SELECT COALESCE(NULLIF(n.name,''),'Neclasificat'),COUNT(*) FROM external_systems x LEFT JOIN external_networks n ON n.id=x.network_id WHERE x.active=1 GROUP BY n.id,n.name ORDER BY 2 DESC,1`,
		"external_network_risk":        `SELECT COALESCE(NULLIF(n.risk_level,''),'unknown'),COUNT(*) FROM external_systems x LEFT JOIN external_networks n ON n.id=x.network_id WHERE x.active=1 GROUP BY n.risk_level ORDER BY 2 DESC,1`,
	}
	for key, query := range queries {
		values, err := reportSeries(ctx, a.DB, query)
		if err != nil {
			respond(w, nil, err)
			return
		}
		charts[key] = values
	}

	topServices, err := reportTopServices(ctx, a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}
	serviceIssues, err := reportServiceIssues(ctx, a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}
	vmIssues, err := reportVMIssues(ctx, a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}
	timeline, err := reportDocumentTimeline(ctx, a.DB)
	if err != nil {
		respond(w, nil, err)
		return
	}
	inventoryStorage, err := a.Inventory.StorageStats(ctx, 20)
	if err != nil {
		respond(w, nil, err)
		return
	}

	jsonResponse(w, http.StatusOK, map[string]any{
		"generated_at":      time.Now().UTC(),
		"summary":           summary,
		"charts":            charts,
		"document_timeline": timeline,
		"top_services":      topServices,
		"service_issues":    serviceIssues,
		"vm_issues":         vmIssues,
		"inventory_storage": inventoryStorage,
	})
}

func reportSeries(ctx context.Context, db *sql.DB, query string) ([]reportPoint, error) {
	rows, err := db.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]reportPoint, 0)
	for rows.Next() {
		var item reportPoint
		if err := rows.Scan(&item.Label, &item.Value); err != nil {
			return nil, err
		}
		out = append(out, item)
	}
	return out, rows.Err()
}

func reportTopServices(ctx context.Context, db *sql.DB) ([]reportServiceRow, error) {
	rows, err := db.QueryContext(ctx, `SELECT s.id,s.name,s.criticality,s.documentation_status,COUNT(DISTINCT a.vm_id) vm_count FROM internal_services s LEFT JOIN vm_internal_service_assignments a ON a.internal_service_id=s.id WHERE s.active=1 GROUP BY s.id,s.name,s.criticality,s.documentation_status ORDER BY vm_count DESC,s.name LIMIT 25`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]reportServiceRow, 0)
	for rows.Next() {
		var item reportServiceRow
		if err := rows.Scan(&item.ID, &item.Name, &item.Criticality, &item.DocumentationStatus, &item.VMCount); err != nil {
			return nil, err
		}
		out = append(out, item)
	}
	return out, rows.Err()
}

func reportServiceIssues(ctx context.Context, db *sql.DB) ([]reportServiceRow, error) {
	rows, err := db.QueryContext(ctx, `SELECT s.id,s.name,s.criticality,s.documentation_status,(SELECT COUNT(DISTINCT a.vm_id) FROM vm_internal_service_assignments a WHERE a.internal_service_id=s.id),
		CONCAT_WS('; ',IF(NOT EXISTS(SELECT 1 FROM vm_internal_service_assignments a WHERE a.internal_service_id=s.id),'fără VM',NULL),IF(TRIM(s.purpose)='','Scop și domeniu lipsă',NULL),IF(TRIM(s.objectives)='','Obiective lipsă',NULL),IF(NOT EXISTS(SELECT 1 FROM generated_documents d WHERE d.object_type='service' AND d.internal_service_id=s.id),'fișă serviciu lipsă',NULL),IF(EXISTS(SELECT 1 FROM vm_internal_service_assignments a JOIN vm_operational_metadata m ON m.vm_id=a.vm_id WHERE a.internal_service_id=s.id AND COALESCE(m.environment,'')=''),'VM fără mediu',NULL)) issue
		FROM internal_services s WHERE s.active=1 HAVING issue<>'' ORDER BY FIELD(s.criticality,'critical','high','normal','low'),s.name LIMIT 100`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]reportServiceRow, 0)
	for rows.Next() {
		var item reportServiceRow
		if err := rows.Scan(&item.ID, &item.Name, &item.Criticality, &item.DocumentationStatus, &item.VMCount, &item.Issue); err != nil {
			return nil, err
		}
		out = append(out, item)
	}
	return out, rows.Err()
}

func reportVMIssues(ctx context.Context, db *sql.DB) ([]reportVMRow, error) {
	rows, err := db.QueryContext(ctx, `SELECT vm.id,vm.name,COALESCE(NULLIF(i.hostname,''),vm.guest_hostname),COALESCE(m.environment,''),vm.power_state,
		CONCAT_WS('; ',IF(COALESCE(m.environment,'')='','mediu lipsă',NULL),IF(vm.current_inventory_id IS NULL,'inventar lipsă',NULL),IF(NOT EXISTS(SELECT 1 FROM vm_internal_service_assignments a WHERE a.vm_id=vm.id),'serviciu neasociat',NULL),IF(NOT EXISTS(SELECT 1 FROM generated_documents d WHERE d.object_type='vm' AND d.vm_id=vm.id),'fișă VM lipsă',NULL),IF(vm.agent_id IS NULL,'agent neasociat',NULL)) issue
		FROM virtual_machines vm LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id WHERE vm.retired=0 HAVING issue<>'' ORDER BY vm.name LIMIT 150`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]reportVMRow, 0)
	for rows.Next() {
		var item reportVMRow
		if err := rows.Scan(&item.ID, &item.Name, &item.Hostname, &item.Environment, &item.PowerState, &item.Issue); err != nil {
			return nil, err
		}
		out = append(out, item)
	}
	return out, rows.Err()
}

func reportDocumentTimeline(ctx context.Context, db *sql.DB) ([]reportTimelinePoint, error) {
	rows, err := db.QueryContext(ctx, `SELECT DATE_FORMAT(generated_at,'%Y-%m-%d'),SUM(object_type='vm'),SUM(object_type='service') FROM generated_documents WHERE generated_at>=UTC_TIMESTAMP()-INTERVAL 30 DAY GROUP BY DATE_FORMAT(generated_at,'%Y-%m-%d') ORDER BY DATE_FORMAT(generated_at,'%Y-%m-%d')`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	byDate := make(map[string]reportTimelinePoint)
	for rows.Next() {
		var item reportTimelinePoint
		if err := rows.Scan(&item.Date, &item.VM, &item.Service); err != nil {
			return nil, err
		}
		byDate[item.Date] = item
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	keys := make([]string, 0, len(byDate))
	for k := range byDate {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	out := make([]reportTimelinePoint, 0, len(keys))
	for _, k := range keys {
		out = append(out, byDate[k])
	}
	return out, nil
}
