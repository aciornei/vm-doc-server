# Conectivitate externă

`vm-doc-server 0.13.0` modelează explicit comunicațiile cu sisteme din afara infrastructurii proprii.

## Model

```text
Rețea externă
    └── Sistem extern
            └── Conexiune externă
                    └── VM intern și/sau Serviciu intern
```

### Rețea externă

Rețeaua este zona administrativă sau de securitate în care se află sistemele externe. Exemple: Internet, rețea partener, cloud, DMZ externă.

Câmpuri:
- nume și cod unic;
- culoare `#RRGGBB`, folosită în UI pentru identificare vizuală;
- tip zonă: `internet`, `partner`, `institution`, `cloud`, `external_dmz`, `other`;
- risc: `unknown`, `low`, `medium`, `high`, `critical`;
- trust: `untrusted`, `restricted`, `trusted`;
- CIDR-uri / intervale IP;
- organizație / proprietar;
- descriere și observații de securitate;
- activ / inactiv.

Migrarea creează două valori editabile: **Internet** și **Altă rețea**.

### Sistem extern

Poate reprezenta o VM, un server fizic, un endpoint/API sau un serviciu de rețea. Sistemul este asociat unei rețele externe și moștenește vizual culoarea, riscul și nivelul de trust al rețelei.

### Conexiune externă

Pentru fiecare relație se păstrează:
- sursa internă: VM și/sau Serviciu intern;
- sistemul extern;
- sensul văzut din infrastructura proprie: outbound, inbound sau bidirectional;
- serviciul destinație;
- protocol și port;
- TLS;
- mecanism de autentificare;
- scop, note și stare.

Conexiunile apar în fișa VM, pagina Serviciului intern, fișa DOCX VM și fișa DOCX a serviciului.

## Recomandări

Nu folosi culoarea ca unic indicator de risc. Culoarea este o convenție vizuală configurabilă, în timp ce `risk_level` și `trust_level` sunt atribute explicite.

Pentru Internet se recomandă risc `high` sau `critical` și trust `untrusted`, în funcție de politica organizației.
