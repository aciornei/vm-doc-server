# Upgrade la vm-doc-server 0.13.0

Versiunea 0.13.0 adaugă retenția automată a inventarelor, Audit extins și modelul Rețea externă → Sistem extern → Conexiune externă.

## Baza de date

Se aplică migrarea:

```text
026_inventory_retention_audit_external_systems.up.sql
```

Migrarea:
- adaugă indexuri pentru filtrarea Auditului;
- creează `external_networks`, `external_systems` și `external_connections`;
- adaugă permisiunile `external.read` și `external.manage`;
- creează rețelele inițiale editabile `Internet` și `Altă rețea`.

0.13.0 este primul release care include migrarea 026. Nu există o schemă intermediară cu `external_zone` care trebuie migrată.

## Configurație inventar

În `/etc/vm-doc-server/config.yaml`:

```yaml
inventory:
  accepted_schema_major: 2
  retain_snapshots_per_agent: 30
  retain_days: 90
  cleanup_interval: "24h"
```

Cleanup-ul rulează la aproximativ 30 de secunde după pornirea serverului și apoi la intervalul configurat. Snapshot-urile curente și cele referite de documente generate sunt protejate.

## Build și instalare

După aplicarea update-ului sursă:

```bash
GOPROXY=off GOFLAGS=-mod=vendor make build
sudo systemctl stop vm-doc-collector vm-doc-server
sudo cp bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
sudo cp bin/vm-doc-collector /opt/vm-doc-server/bin/vm-doc-collector
sudo chmod 755 /opt/vm-doc-server/bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-collector
sudo systemctl start vm-doc-server vm-doc-collector
```

Verifică:

```bash
curl -s http://127.0.0.1:9080/version
```

Trebuie să raporteze `0.13.0`.

După autentificare fă `Ctrl+F5`, deoarece 0.13.0 modifică semnificativ interfața.
