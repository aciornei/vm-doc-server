-- 0.13.0: inventory retention, audit filters/details and external network topology.

CREATE INDEX IF NOT EXISTS idx_audit_action_time ON audit_events(action,occurred_at);
CREATE INDEX IF NOT EXISTS idx_audit_outcome_time ON audit_events(outcome,occurred_at);
CREATE INDEX IF NOT EXISTS idx_audit_source_time ON audit_events(source,occurred_at);

CREATE TABLE IF NOT EXISTS external_networks (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  code VARCHAR(64) NOT NULL,
  color CHAR(7) NOT NULL DEFAULT '#6B7280',
  zone_type VARCHAR(32) NOT NULL DEFAULT 'other',
  risk_level VARCHAR(16) NOT NULL DEFAULT 'unknown',
  trust_level VARCHAR(16) NOT NULL DEFAULT 'restricted',
  cidrs TEXT NOT NULL,
  owner_organization VARCHAR(255) NOT NULL DEFAULT '',
  description TEXT NOT NULL,
  security_notes TEXT NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_external_network_name (name),
  UNIQUE KEY uq_external_network_code (code),
  KEY idx_external_network_active (active,name),
  CONSTRAINT chk_external_network_color CHECK (color REGEXP '^#[0-9A-Fa-f]{6}$'),
  CONSTRAINT chk_external_network_zone_type CHECK (zone_type IN ('internet','partner','institution','cloud','external_dmz','other')),
  CONSTRAINT chk_external_network_risk CHECK (risk_level IN ('unknown','low','medium','high','critical')),
  CONSTRAINT chk_external_network_trust CHECK (trust_level IN ('untrusted','restricted','trusted')),
  CONSTRAINT fk_external_network_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_external_network_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Useful defaults. They remain fully editable from the application.
INSERT IGNORE INTO external_networks(name,code,color,zone_type,risk_level,trust_level,cidrs,owner_organization,description,security_notes,active)
VALUES
 ('Internet','internet','#DC2626','internet','high','untrusted','','','Internet public. Destinațiile de aici sunt în afara controlului infrastructurii proprii.','Verifică expunerea, TLS, autentificarea și necesitatea fiecărei conexiuni.',1),
 ('Altă rețea','external_network','#16A34A','other','medium','restricted','','','Rețea externă controlată de o altă organizație sau zonă administrativă.','Validează regulile de interconectare și responsabilitatea operațională.',1);

CREATE TABLE IF NOT EXISTS external_systems (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  system_type VARCHAR(32) NOT NULL DEFAULT 'vm',
  hostname VARCHAR(255) NOT NULL DEFAULT '',
  ip_addresses VARCHAR(1024) NOT NULL DEFAULT '',
  owner_organization VARCHAR(255) NOT NULL DEFAULT '',
  description TEXT NOT NULL,
  documentation_url VARCHAR(1024) NOT NULL DEFAULT '',
  network_id BIGINT UNSIGNED NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  CONSTRAINT chk_external_system_type CHECK (system_type IN ('vm','server','endpoint','network_service')),
  UNIQUE KEY uq_external_system_name (name),
  KEY idx_external_system_network_active (network_id,active,name),
  CONSTRAINT fk_external_system_network FOREIGN KEY (network_id) REFERENCES external_networks(id) ON DELETE SET NULL,
  CONSTRAINT fk_external_system_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_external_system_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS external_connections (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  external_system_id BIGINT UNSIGNED NOT NULL,
  internal_service_id BIGINT UNSIGNED NULL,
  vm_id BIGINT UNSIGNED NULL,
  direction VARCHAR(16) NOT NULL DEFAULT 'outbound',
  remote_service VARCHAR(255) NOT NULL,
  protocol VARCHAR(32) NOT NULL DEFAULT 'tcp',
  port INT UNSIGNED NULL,
  tls_enabled TINYINT(1) NOT NULL DEFAULT 0,
  authentication VARCHAR(128) NOT NULL DEFAULT '',
  purpose VARCHAR(512) NOT NULL DEFAULT '',
  notes TEXT NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  KEY idx_external_connection_system (external_system_id,active),
  KEY idx_external_connection_service (internal_service_id,active),
  KEY idx_external_connection_vm (vm_id,active),
  CONSTRAINT fk_external_connection_system FOREIGN KEY (external_system_id) REFERENCES external_systems(id) ON DELETE CASCADE,
  CONSTRAINT fk_external_connection_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_external_connection_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_external_connection_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_external_connection_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT chk_external_connection_direction CHECK (direction IN ('outbound','inbound','bidirectional')),
  CONSTRAINT chk_external_connection_port CHECK (port IS NULL OR (port BETWEEN 1 AND 65535)),
  CONSTRAINT chk_external_connection_source CHECK (internal_service_id IS NOT NULL OR vm_id IS NOT NULL)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO permissions(name,description) VALUES
 ('external.read','Vizualizare rețele externe, sisteme externe și conexiuni'),
 ('external.manage','Administrare rețele externe, sisteme externe și conexiuni');

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name='admin' AND p.name IN ('external.read','external.manage');

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.name IN ('external.read','external.manage') WHERE r.name='operator';

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.name='external.read' WHERE r.name IN ('viewer','auditor');
