# Upgrade VM-DOC Server 0.20.46 -> 0.20.47

Versiune fără migrare DB și fără modificare de agent.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.46 \
      /usr/local/src/vm-doc-server-0.20.47

tar -xzf vm-doc-server-0.20.47-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.47

cd /usr/local/src/vm-doc-server-0.20.47
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După înlocuirea binarului, restartează serviciul și fă `Ctrl+F5` în browser.

Butonul **Publică tabelul în Outline** din lista VM este afișat numai dacă:
1. integrarea Outline este activă global;
2. destinația `Inventar VM` este activă;
3. destinația are Link / document Outline configurat.
