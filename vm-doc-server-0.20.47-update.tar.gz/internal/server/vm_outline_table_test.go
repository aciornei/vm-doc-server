package server

import (
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
)

func TestVMInventoryOutlineMarkdownUsesCompactColumnsAndLinks(t *testing.T) {
	now := time.Date(2026, 9, 30, 7, 0, 0, 0, time.UTC)
	a := &App{}
	vms := []domain.VirtualMachine{{
		ID:                           42,
		Name:                         "vm-app-01",
		PowerState:                   "POWERED_ON",
		CPUCount:                     4,
		MemoryMiB:                    8192,
		Environment:                  "Prod",
		InventoryHostname:            "app01.example.local",
		InventoryOSName:              "Ubuntu",
		InventoryOSVersion:           "22.04",
		OSSupportStatus:              "supported",
		InventoryPrimaryIP:           "10.10.10.42",
		ServiceNames:                 []string{"Portal", "Redis"},
		OutlineDocumentationDisabled: false,
		OutlineLastSyncedAt:          &now,
	}}
	links := vmOutlineTableLinks{
		VMURLs: map[int64]string{42: "https://outline.example/doc/vm-app-01"},
		Services: map[int64][]vmOutlineServiceLink{42: {
			{Name: "Portal", URL: "https://outline.example/doc/portal"},
			{Name: "Redis"},
		}},
	}

	md := a.vmInventoryOutlineMarkdown(vms, links)
	for _, forbidden := range []string{"| vCenter |", "| Agent |", "| Completare |", "| Ultimul JSON |"} {
		if strings.Contains(md, forbidden) {
			t.Fatalf("unexpected removed column %q in markdown:\n%s", forbidden, md)
		}
	}
	for _, expected := range []string{
		"| VM | Hostname | Power | CPU / RAM | Mediu | OS | Suport OS | IP | Servicii | Outline | Ultima publicare Outline |",
		"[vm-app-01](https://outline.example/doc/vm-app-01)",
		"[Portal](https://outline.example/doc/portal)<br>Redis",
		"| ON |",
		"| PROD |",
	} {
		if !strings.Contains(md, expected) {
			t.Fatalf("missing %q in markdown:\n%s", expected, md)
		}
	}
}

func TestOutlinePowerAndEnvironmentLabels(t *testing.T) {
	cases := map[string]string{
		"POWERED_ON": "ON",
		"poweredOff": "OFF",
		"SUSPENDED":  "SUSPENDED",
		"":           "—",
	}
	for input, want := range cases {
		if got := outlinePowerLabel(input); got != want {
			t.Fatalf("outlinePowerLabel(%q)=%q want %q", input, got, want)
		}
	}
	envs := map[string]string{"Prod": "PROD", "Test": "TEST", "Dev": "DEV", "producție": "PROD"}
	for input, want := range envs {
		if got := outlineEnvironmentLabel(input); got != want {
			t.Fatalf("outlineEnvironmentLabel(%q)=%q want %q", input, got, want)
		}
	}
}
