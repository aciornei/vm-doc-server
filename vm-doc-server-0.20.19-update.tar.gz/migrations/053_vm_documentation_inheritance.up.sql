-- 0.20.19 · documentație comună pentru noduri HA / cluster
-- Un VM poate moșteni configurația de documentare de la un VM sursă.
-- Datele tehnice colectate de agent/vCenter rămân întotdeauna locale VM-ului.

CREATE TABLE IF NOT EXISTS vm_documentation_inheritance (
  vm_id BIGINT UNSIGNED NOT NULL,
  source_vm_id BIGINT UNSIGNED NOT NULL,
  group_name VARCHAR(255) NOT NULL DEFAULT '',
  group_type VARCHAR(32) NOT NULL DEFAULT 'cluster',
  inherit_service_assignments TINYINT(1) NOT NULL DEFAULT 1,
  inherit_operational_metadata TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (vm_id),
  KEY idx_vm_documentation_source (source_vm_id,group_name),
  CONSTRAINT fk_vm_documentation_member FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_documentation_source FOREIGN KEY (source_vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_vm_documentation_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_vm_documentation_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
