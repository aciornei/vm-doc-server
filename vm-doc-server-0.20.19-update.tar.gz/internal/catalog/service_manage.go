package catalog

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
)

type ServiceDeleteImpact struct {
	ServiceID              int64  `json:"service_id"`
	ServiceName            string `json:"service_name"`
	VMAssignments          int    `json:"vm_assignments"`
	RoleMappings           int    `json:"role_mappings"`
	DockerAssignments      int    `json:"docker_assignments"`
	DatabaseInstances      int    `json:"database_instances"`
	DatabaseCatalogs       int    `json:"database_catalogs"`
	WebSites               int    `json:"web_sites"`
	OutgoingDependencies   int    `json:"outgoing_dependencies"`
	IncomingDependencies   int    `json:"incoming_dependencies"`
	VMDependencies         int    `json:"vm_dependencies"`
	ExternalConnections    int    `json:"external_connections"`
	GeneratedDocuments     int    `json:"generated_documents"`
	Attachments            int    `json:"attachments"`
	AffectedVMs            int    `json:"affected_vms"`
	TotalRelatedReferences int    `json:"total_related_references"`
}

type ServiceMergeResult struct {
	SourceServiceID int64               `json:"source_service_id"`
	TargetServiceID int64               `json:"target_service_id"`
	Impact          ServiceDeleteImpact `json:"impact"`
}

func (s Service) GetDeleteImpact(ctx context.Context, id int64) (ServiceDeleteImpact, error) {
	if id <= 0 {
		return ServiceDeleteImpact{}, errors.New("invalid service id")
	}
	impact := ServiceDeleteImpact{ServiceID: id}
	var implicitGlobal bool
	if err := s.DB.QueryRowContext(ctx, `SELECT name,implicit_global FROM internal_services WHERE id=?`, id).Scan(&impact.ServiceName, &implicitGlobal); err != nil {
		return ServiceDeleteImpact{}, err
	}
	queries := []struct {
		dst   *int
		query string
	}{
		{&impact.VMAssignments, `SELECT COUNT(*) FROM vm_internal_service_assignments WHERE internal_service_id=?`},
		{&impact.RoleMappings, `SELECT COUNT(*) FROM internal_service_role_mappings WHERE internal_service_id=?`},
		{&impact.DockerAssignments, `SELECT COUNT(*) FROM docker_container_service_assignments WHERE internal_service_id=?`},
		{&impact.DatabaseInstances, `SELECT COUNT(*) FROM database_instance_service_assignments WHERE internal_service_id=?`},
		{&impact.DatabaseCatalogs, `SELECT COUNT(*) FROM database_catalog_service_assignments WHERE internal_service_id=?`},
		{&impact.WebSites, `SELECT COUNT(*) FROM web_site_service_assignments WHERE internal_service_id=?`},
		{&impact.OutgoingDependencies, `SELECT COUNT(*) FROM internal_service_dependencies WHERE source_service_id=?`},
		{&impact.IncomingDependencies, `SELECT COUNT(*) FROM internal_service_dependencies WHERE target_service_id=?`},
		{&impact.VMDependencies, `SELECT COUNT(*) FROM vm_common_service_dependencies WHERE target_service_id=?`},
		{&impact.ExternalConnections, `SELECT COUNT(*) FROM external_connections WHERE internal_service_id=?`},
		{&impact.GeneratedDocuments, `SELECT COUNT(*) FROM generated_documents WHERE internal_service_id=?`},
		{&impact.Attachments, `SELECT COUNT(*) FROM internal_service_attachments WHERE internal_service_id=?`},
	}
	for _, item := range queries {
		if err := s.DB.QueryRowContext(ctx, item.query, id).Scan(item.dst); err != nil {
			return ServiceDeleteImpact{}, err
		}
	}
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(DISTINCT vm_id) FROM vm_internal_service_assignments WHERE internal_service_id=?`, id).Scan(&impact.AffectedVMs); err != nil {
		return ServiceDeleteImpact{}, err
	}
	impact.TotalRelatedReferences = impact.VMAssignments + impact.RoleMappings + impact.DockerAssignments + impact.DatabaseInstances + impact.DatabaseCatalogs + impact.WebSites + impact.OutgoingDependencies + impact.IncomingDependencies + impact.VMDependencies + impact.ExternalConnections + impact.GeneratedDocuments + impact.Attachments
	return impact, nil
}

func (s Service) Delete(ctx context.Context, id int64) (ServiceDeleteImpact, error) {
	impact, err := s.GetDeleteImpact(ctx, id)
	if err != nil {
		return ServiceDeleteImpact{}, err
	}
	var implicitGlobal bool
	if err := s.DB.QueryRowContext(ctx, `SELECT implicit_global FROM internal_services WHERE id=?`, id).Scan(&implicitGlobal); err != nil {
		return ServiceDeleteImpact{}, err
	}
	if implicitGlobal {
		return ServiceDeleteImpact{}, errors.New("the global flag must be disabled before an implicit global service can be deleted")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return ServiceDeleteImpact{}, err
	}
	defer tx.Rollback()
	// This is the only service relation whose historical FK does not cascade.
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_internal_service_assignments WHERE internal_service_id=?`, id); err != nil {
		return ServiceDeleteImpact{}, err
	}
	res, err := tx.ExecContext(ctx, `DELETE FROM internal_services WHERE id=?`, id)
	if err != nil {
		return ServiceDeleteImpact{}, err
	}
	if rows, _ := res.RowsAffected(); rows == 0 {
		return ServiceDeleteImpact{}, sql.ErrNoRows
	}
	if err := tx.Commit(); err != nil {
		return ServiceDeleteImpact{}, err
	}
	return impact, nil
}

func (s Service) Merge(ctx context.Context, sourceID, targetID, userID int64) (ServiceMergeResult, error) {
	if sourceID <= 0 || targetID <= 0 || sourceID == targetID {
		return ServiceMergeResult{}, errors.New("source and target services must be different valid services")
	}
	impact, err := s.GetDeleteImpact(ctx, sourceID)
	if err != nil {
		return ServiceMergeResult{}, err
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return ServiceMergeResult{}, err
	}
	defer tx.Rollback()

	var sourceGlobal, targetGlobal, sourceCommon, targetCommon bool
	var sourceName, targetName string
	if err := tx.QueryRowContext(ctx, `SELECT name,implicit_global,is_common FROM internal_services WHERE id=? FOR UPDATE`, sourceID).Scan(&sourceName, &sourceGlobal, &sourceCommon); err != nil {
		return ServiceMergeResult{}, err
	}
	if err := tx.QueryRowContext(ctx, `SELECT name,implicit_global,is_common FROM internal_services WHERE id=? FOR UPDATE`, targetID).Scan(&targetName, &targetGlobal, &targetCommon); err != nil {
		return ServiceMergeResult{}, err
	}
	if sourceGlobal {
		return ServiceMergeResult{}, errors.New("the global flag must be disabled before an implicit global service can be merged")
	}
	if sourceCommon && !targetCommon {
		return ServiceMergeResult{}, errors.New("target service must also be common when the source service is common")
	}
	_ = targetGlobal

	// VM classifications/roles. Keep the target authoritative when the exact
	// context already exists. Do not create a second primary assignment on a VM.
	if _, err := tx.ExecContext(ctx, `INSERT IGNORE INTO vm_internal_service_assignments(vm_id,internal_service_id,architectural_domain_id,itil_category_id,layer_id,technical_role_id,solution_type_id,usage_type,is_primary,notes,sort_order,updated_by)
		SELECT src.vm_id,?,src.architectural_domain_id,src.itil_category_id,src.layer_id,src.technical_role_id,src.solution_type_id,src.usage_type,
			CASE WHEN src.is_primary=1 AND EXISTS(SELECT 1 FROM vm_internal_service_assignments p WHERE p.vm_id=src.vm_id AND p.internal_service_id=? AND p.is_primary=1) THEN 0 ELSE src.is_primary END,
			src.notes,src.sort_order,?
		FROM vm_internal_service_assignments src WHERE src.internal_service_id=?`, targetID, targetID, userID, sourceID); err != nil {
		return ServiceMergeResult{}, fmt.Errorf("merge VM assignments: %w", err)
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_internal_service_assignments WHERE internal_service_id=?`, sourceID); err != nil {
		return ServiceMergeResult{}, err
	}

	if _, err := tx.ExecContext(ctx, `INSERT IGNORE INTO internal_service_role_mappings(internal_service_id,layer_id,technical_role_id,sort_order,active,created_by)
		SELECT ?,layer_id,technical_role_id,sort_order,active,? FROM internal_service_role_mappings WHERE internal_service_id=?`, targetID, userID, sourceID); err != nil {
		return ServiceMergeResult{}, err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM internal_service_role_mappings WHERE internal_service_id=?`, sourceID); err != nil {
		return ServiceMergeResult{}, err
	}

	resourceStatements := []struct {
		insert string
		delete string
	}{
		{`INSERT IGNORE INTO docker_container_service_assignments(docker_container_id,internal_service_id,environment_id,operational_status_id,solution_type_id,assignment_source,component_name,role_name,notes,created_by,updated_by)
		 SELECT docker_container_id,?,environment_id,operational_status_id,solution_type_id,assignment_source,component_name,role_name,notes,created_by,? FROM docker_container_service_assignments WHERE internal_service_id=?`, `DELETE FROM docker_container_service_assignments WHERE internal_service_id=?`},
		{`INSERT IGNORE INTO database_instance_service_assignments(database_instance_id,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by)
		 SELECT database_instance_id,?,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,? FROM database_instance_service_assignments WHERE internal_service_id=?`, `DELETE FROM database_instance_service_assignments WHERE internal_service_id=?`},
		{`INSERT IGNORE INTO database_catalog_service_assignments(database_catalog_id,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by)
		 SELECT database_catalog_id,?,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,? FROM database_catalog_service_assignments WHERE internal_service_id=?`, `DELETE FROM database_catalog_service_assignments WHERE internal_service_id=?`},
		{`INSERT IGNORE INTO web_site_service_assignments(web_site_id,internal_service_id,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,updated_by)
		 SELECT web_site_id,?,environment_id,operational_status_id,solution_type_id,component_name,role_name,notes,created_by,? FROM web_site_service_assignments WHERE internal_service_id=?`, `DELETE FROM web_site_service_assignments WHERE internal_service_id=?`},
	}
	for _, stmt := range resourceStatements {
		if _, err := tx.ExecContext(ctx, stmt.insert, targetID, userID, sourceID); err != nil {
			return ServiceMergeResult{}, err
		}
		if _, err := tx.ExecContext(ctx, stmt.delete, sourceID); err != nil {
			return ServiceMergeResult{}, err
		}
	}

	if _, err := tx.ExecContext(ctx, `INSERT IGNORE INTO vm_common_service_dependencies(vm_id,target_service_id,dependency_type_id,notes,active,created_by,updated_by)
		SELECT vm_id,?,dependency_type_id,notes,active,created_by,? FROM vm_common_service_dependencies WHERE target_service_id=?`, targetID, userID, sourceID); err != nil {
		return ServiceMergeResult{}, err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_common_service_dependencies WHERE target_service_id=?`, sourceID); err != nil {
		return ServiceMergeResult{}, err
	}

	// Drop the direct source<->target edge first; after the replacement it would
	// become a self-dependency. Then preserve all other incoming/outgoing edges.
	if _, err := tx.ExecContext(ctx, `DELETE FROM internal_service_dependencies WHERE (source_service_id=? AND target_service_id=?) OR (source_service_id=? AND target_service_id=?)`, sourceID, targetID, targetID, sourceID); err != nil {
		return ServiceMergeResult{}, err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE internal_service_dependencies SET source_service_id=?,updated_by=? WHERE source_service_id=?`, targetID, userID, sourceID); err != nil {
		return ServiceMergeResult{}, err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE internal_service_dependencies SET target_service_id=?,updated_by=? WHERE target_service_id=?`, targetID, userID, sourceID); err != nil {
		return ServiceMergeResult{}, err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM internal_service_dependencies WHERE source_service_id=target_service_id`); err != nil {
		return ServiceMergeResult{}, err
	}
	if _, err := tx.ExecContext(ctx, `DELETE d1 FROM internal_service_dependencies d1 JOIN internal_service_dependencies d2
		ON d1.id>d2.id AND d1.source_service_id=d2.source_service_id AND d1.target_service_id=d2.target_service_id AND d1.dependency_type_id=d2.dependency_type_id
		AND d1.source_environment_id <=> d2.source_environment_id AND d1.target_environment_id <=> d2.target_environment_id
		AND d1.criticality=d2.criticality AND d1.protocol=d2.protocol AND d1.port <=> d2.port AND d1.notes=d2.notes AND d1.active=d2.active`); err != nil {
		return ServiceMergeResult{}, err
	}

	for _, query := range []string{
		`UPDATE external_connections SET internal_service_id=?,updated_by=? WHERE internal_service_id=?`,
		`UPDATE generated_documents SET internal_service_id=? WHERE internal_service_id=?`,
		`UPDATE internal_service_attachments SET internal_service_id=? WHERE internal_service_id=?`,
	} {
		var args []any
		if query == `UPDATE external_connections SET internal_service_id=?,updated_by=? WHERE internal_service_id=?` {
			args = []any{targetID, userID, sourceID}
		} else {
			args = []any{targetID, sourceID}
		}
		if _, err := tx.ExecContext(ctx, query, args...); err != nil {
			return ServiceMergeResult{}, err
		}
	}

	res, err := tx.ExecContext(ctx, `DELETE FROM internal_services WHERE id=?`, sourceID)
	if err != nil {
		return ServiceMergeResult{}, err
	}
	if rows, _ := res.RowsAffected(); rows == 0 {
		return ServiceMergeResult{}, sql.ErrNoRows
	}
	if err := tx.Commit(); err != nil {
		return ServiceMergeResult{}, err
	}
	impact.ServiceName = sourceName
	return ServiceMergeResult{SourceServiceID: sourceID, TargetServiceID: targetID, Impact: impact}, nil
}
