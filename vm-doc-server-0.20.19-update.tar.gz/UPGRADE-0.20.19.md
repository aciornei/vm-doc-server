# Upgrade vm-doc-server 0.20.18 → 0.20.19

## Ce se schimbă

0.20.19 adaugă două funcții administrative:

1. **Ștergere / comasare proiecte (servicii interne)** – proiectele redundante pot fi comasate într-un proiect principal, păstrând asocierile tehnice și documentele.
2. **Documentație comună HA / cluster** – un VM membru poate prelua automat configurația documentată de la un VM sursă.

## Migrare DB

La pornire se aplică automat:

```text
053_vm_documentation_inheritance.up.sql
```

Migrarea creează `vm_documentation_inheritance`. Nu modifică inventarul tehnic și nu necesită schimbări pe agent.

## Instalare offline

Peste arborele 0.20.18:

```bash
cp -a /usr/local/src/vm-doc-server-0.20.18 /usr/local/src/vm-doc-server-0.20.19
tar -xzf vm-doc-server-0.20.19-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.19
cd /usr/local/src/vm-doc-server-0.20.19
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi înlocuiește binarul și repornește `vm-doc-server`. Migrarea este executată la startup.

## Verificare – comasare proiecte

1. Deschide proiectul redundant.
2. În **Rezumat → Administrare proiect / serviciu**, alege proiectul mare.
3. Apasă **Comasează proiectul** și verifică impactul afișat.
4. După confirmare, proiectul sursă dispare, iar asocierile trebuie să apară pe proiectul destinație.

## Verificare – două LB-uri / cluster

Exemplu `LB01` + `LB02`:

1. Documentează `LB01` normal.
2. Deschide `LB02 → Configurare → Servicii`.
3. În **Cluster / grup HA**, alege `LB01` drept VM sursă.
4. Completează numele grupului, de exemplu `LB-PROD`, și alege `Active / Active` sau `Active / Standby`.
5. Bifează ce dorești să moștenești și salvează.
6. Modifică apoi serviciile/datele comune pe `LB01`; ele trebuie să se actualizeze automat și pe `LB02`.
7. Hostname-ul, IP-ul, UUID-ul, inventarul agentului, backupul și monitorizarea trebuie să rămână individuale.

Dacă dezactivezi moștenirea pe `LB02`, valorile copiate până atunci rămân și devin editabile local.

## Agent

`vm-doc-agent 1.7.9` rămâne neschimbat.
