# VM-DOC Server 0.21.46 → 0.21.47

**Bază:** sursele integrale 0.21.46. **Agent:** 1.7.18, nemodificat. **Bază SQL / API:** nemodificate. Nu este necesară migrare SQL.

## Schimbări

- Carduri KPI compacte, margin-top/left și 8 coloane pe desktop (4/2 pe ecrane mici).
- Diagramă mai lată, VM central 274 px și delimitări mai aerisite.
- Policy din SVG afișează numai numărul, iar nodurile Sursă/Destinație nu repetă obiectele; datele complete rămân în lista expandabilă Fluxuri FortiGate corelate, în tooltip și în datele agentului.
- Vârfuri de săgeți mai mici; click pe port evidențiază liniile/policy-urile aferente; click pe linie/policy/nod de flux evidențiază portul asociat dacă există o potrivire observată. Click din nou sau în spațiul gol pentru deselectare, Escape când diagrama are focus.

## Upgrade în staging (offline)

1. Backup al binarului, surselor, configurației și DB. Păstrează `vendor/` al instalării curente.
2. Din rădăcina surselor 0.21.46, aplică **una dintre metode**, nu ambele:

```bash
tar -xzf /cale/vm-doc-server-0.21.47-update.tar.gz
# SAU, dacă sursele 0.21.46 nu sunt modificate:
git apply /cale/vm-doc-server-0.21.46-to-0.21.47.patch
```

3. Verifică `cat VERSION` → `0.21.47` și `bash scripts/cleanup-source-tree.sh --check`.
4. Cu dependențele offline disponibile: `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build`.
5. Testează paginile Hartă rețea VM și serviciu, inclusiv peste 10 porturi, grupuri interne cu 2+ VM, fluxuri inbound/outbound, export SVG, click port↔flux și zoom/scroll la rezoluțiile uzuale.
6. După validare instalează binarul recompilat, restartează serviciul și execută hard refresh în browser.

**Rollback:** reinstalează binarul și sursele 0.21.46. Nu este necesar rollback SQL.

**Limită verificări:** test Chromium cu inventare simulate; teste Go pentru module independente au trecut. `vendor/` lipsește aici și nu s-a rulat build complet sau test MariaDB în această sesiune.
