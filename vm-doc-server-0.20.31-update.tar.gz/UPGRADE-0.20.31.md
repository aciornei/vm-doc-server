# Upgrade vm-doc-server 0.20.30 → 0.20.31

Versiunea 0.20.31 schimbă publicarea Outline astfel încât fișele VM să fie publicate direct sub documentul **Virtualizare**, nu sub proiecte.

## Înainte de upgrade

Păstrează backupul obișnuit al bazei de date și al directorului aplicației.

## Upgrade

```bash
cp -a /usr/local/src/vm-doc-server-0.20.30 \
      /usr/local/src/vm-doc-server-0.20.31

tar -xzf vm-doc-server-0.20.31-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.31

cd /usr/local/src/vm-doc-server-0.20.31

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

## După pornire

În **Documente → Outline** completează `Virtualizare · Document ID` cu ID-ul paginii Outline sub care vrei să apară VM-urile și rulează **Testează conexiunea**.

Structura rezultată este:

```text
Virtualizare
├── VM — ...
├── VM — ...
└── VM — ...
```

Proiectele nu mai sunt create automat în Outline. Pentru proiecte folosește câmpul **Link documentație** din Detalii.

Migrarea `057_outline_virtualization_target.up.sql` creează ținta generică `virtualization` și mapping-ul global al paginilor VM. Nu este necesar update de vm-doc-agent.

Dacă ai publicat deja pagini în structura experimentală 0.20.30 (`Proiect → VM`), acestea nu sunt șterse automat din Outline. Noua structură creează mapping-uri separate sub Virtualizare; paginile vechi pot fi eliminate manual după verificare.
