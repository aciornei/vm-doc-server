package outline

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestCallUsesBearerAndRPCPath(t *testing.T) {
	var gotAuth, gotPath string
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotAuth = r.Header.Get("Authorization")
		gotPath = r.URL.Path
		if r.Header.Get("Content-Type") != "application/json" {
			t.Fatalf("unexpected content type: %s", r.Header.Get("Content-Type"))
		}
		var body map[string]any
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			t.Fatal(err)
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"data": map[string]any{"id": "doc-1", "title": "Test", "url": "/doc/test-doc-1"}})
	}))
	defer server.Close()

	svc := Service{}
	settings := settingsRecord{Settings: Settings{BaseURL: server.URL, VerifyTLS: false, RequestTimeoutSeconds: 5}}
	var out apiEnvelope[apiDocument]
	if err := svc.call(context.Background(), settings, "ol_api_test", "documents.create", map[string]any{"title": "Test"}, &out); err != nil {
		t.Fatal(err)
	}
	if gotAuth != "Bearer ol_api_test" {
		t.Fatalf("unexpected authorization: %q", gotAuth)
	}
	if gotPath != "/api/documents.create" {
		t.Fatalf("unexpected API path: %q", gotPath)
	}
	if out.Data.ID != "doc-1" {
		t.Fatalf("unexpected document: %#v", out.Data)
	}
}

func TestDocumentHashIsStable(t *testing.T) {
	a := documentHash("Title", []byte("body"))
	b := documentHash("Title", []byte("body"))
	c := documentHash("Title 2", []byte("body"))
	if a != b || a == c {
		t.Fatalf("unexpected hashes: %q %q %q", a, b, c)
	}
}

func TestSettingsTimeoutValidation(t *testing.T) {
	enabled, verify, allow := true, true, false
	in := SettingsInput{Enabled: &enabled, VerifyTLS: &verify, AllowHTTP: &allow, BaseURL: "https://outline.example", CollectionID: "collection", VirtualizationParentDocumentID: "virtualization-doc", RequestTimeoutSeconds: int((30 * time.Second) / time.Second)}
	if err := normalizeSettings(&in); err != nil {
		t.Fatal(err)
	}
}
