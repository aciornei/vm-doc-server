package outline

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/cryptox"
)

const secretAADPrefix = "vm-doc-outline-api-key:"

type Service struct {
	DB     *sql.DB
	Box    *cryptox.Box
	Logger *slog.Logger
}

type Settings struct {
	Enabled                        bool      `json:"enabled"`
	BaseURL                        string    `json:"base_url"`
	CollectionID                   string    `json:"collection_id,omitempty"`
	VirtualizationParentDocumentID string    `json:"virtualization_parent_document_id"`
	VerifyTLS                      bool      `json:"verify_tls"`
	AllowHTTP                      bool      `json:"allow_http"`
	RequestTimeoutSeconds          int       `json:"request_timeout_seconds"`
	APIKeyConfigured               bool      `json:"api_key_configured"`
	UpdatedAt                      time.Time `json:"updated_at"`
}

type SettingsInput struct {
	Enabled                        *bool  `json:"enabled,omitempty"`
	BaseURL                        string `json:"base_url"`
	CollectionID                   string `json:"collection_id,omitempty"`
	VirtualizationParentDocumentID string `json:"virtualization_parent_document_id"`
	APIKey                         string `json:"api_key,omitempty"`
	VerifyTLS                      *bool  `json:"verify_tls,omitempty"`
	AllowHTTP                      *bool  `json:"allow_http,omitempty"`
	RequestTimeoutSeconds          int    `json:"request_timeout_seconds,omitempty"`
}

type settingsRecord struct {
	Settings
	SecretRef string
	Cipher    sql.NullString
}

type TestResult struct {
	OK                  bool   `json:"ok"`
	CollectionID        string `json:"collection_id,omitempty"`
	CollectionName      string `json:"collection_name,omitempty"`
	ParentDocumentID    string `json:"parent_document_id,omitempty"`
	ParentDocumentTitle string `json:"parent_document_title,omitempty"`
	BaseURL             string `json:"base_url"`
}

type PublishResult struct {
	ObjectType string `json:"object_type"`
	ObjectID   int64  `json:"object_id"`
	ServiceID  int64  `json:"service_id,omitempty"`
	DocumentID string `json:"document_id"`
	URL        string `json:"url"`
	Created    bool   `json:"created"`
	Changed    bool   `json:"changed"`
	Title      string `json:"title"`
}

type apiDocument struct {
	ID    string `json:"id"`
	URL   string `json:"url"`
	Title string `json:"title"`
}

type apiCollection struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}

type apiEnvelope[T any] struct {
	Data T `json:"data"`
}

type apiErrorEnvelope struct {
	Error   string `json:"error"`
	Message string `json:"message"`
	Status  int    `json:"status"`
	OK      bool   `json:"ok"`
}

type remoteError struct {
	StatusCode int
	Message    string
}

func (e *remoteError) Error() string { return e.Message }

func NewService(db *sql.DB, box *cryptox.Box, logger *slog.Logger) *Service {
	if logger == nil {
		logger = slog.Default()
	}
	return &Service{DB: db, Box: box, Logger: logger}
}

func (s *Service) GetSettings(ctx context.Context) (Settings, error) {
	record, err := s.getRecord(ctx)
	return record.Settings, err
}

func (s *Service) getRecord(ctx context.Context) (settingsRecord, error) {
	var r settingsRecord
	var enabled, verifyTLS, allowHTTP bool
	var updatedAt time.Time
	err := s.DB.QueryRowContext(ctx, `SELECT s.enabled,s.base_url,s.collection_id,s.api_key_secret_ref,s.api_key_ciphertext,s.verify_tls,s.allow_http,s.request_timeout_seconds,s.updated_at,
		COALESCE((SELECT t.parent_document_id FROM outline_targets t WHERE t.target_code='virtualization' AND t.active=1),'')
		FROM outline_settings s WHERE s.id=1`).Scan(
		&enabled, &r.BaseURL, &r.CollectionID, &r.SecretRef, &r.Cipher, &verifyTLS, &allowHTTP, &r.RequestTimeoutSeconds, &updatedAt, &r.VirtualizationParentDocumentID,
	)
	if err != nil {
		return r, err
	}
	r.Enabled = enabled
	r.VerifyTLS = verifyTLS
	r.AllowHTTP = allowHTTP
	r.APIKeyConfigured = r.Cipher.Valid && strings.TrimSpace(r.Cipher.String) != "" && strings.TrimSpace(r.SecretRef) != ""
	r.UpdatedAt = updatedAt
	return r, nil
}

func (s *Service) UpdateSettings(ctx context.Context, userID int64, in SettingsInput) (Settings, error) {
	current, err := s.getRecord(ctx)
	if err != nil {
		return Settings{}, err
	}
	if in.Enabled == nil {
		v := current.Enabled
		in.Enabled = &v
	}
	if in.VerifyTLS == nil {
		v := current.VerifyTLS
		in.VerifyTLS = &v
	}
	if in.AllowHTTP == nil {
		v := current.AllowHTTP
		in.AllowHTTP = &v
	}
	if in.RequestTimeoutSeconds == 0 {
		in.RequestTimeoutSeconds = current.RequestTimeoutSeconds
		if in.RequestTimeoutSeconds == 0 {
			in.RequestTimeoutSeconds = 30
		}
	}
	if strings.TrimSpace(in.BaseURL) == "" {
		in.BaseURL = current.BaseURL
	}
	if strings.TrimSpace(in.CollectionID) == "" {
		in.CollectionID = current.CollectionID
	}
	if in.CollectionID == "-" {
		in.CollectionID = ""
	}
	if in.VirtualizationParentDocumentID == "" && current.VirtualizationParentDocumentID != "" {
		in.VirtualizationParentDocumentID = current.VirtualizationParentDocumentID
	}
	if in.VirtualizationParentDocumentID == "-" {
		in.VirtualizationParentDocumentID = ""
	}
	if err := normalizeSettings(&in); err != nil {
		return Settings{}, err
	}

	secretRef := current.SecretRef
	ciphertext := ""
	if current.Cipher.Valid {
		ciphertext = current.Cipher.String
	}
	if strings.TrimSpace(in.APIKey) != "" {
		if secretRef == "" {
			secretRef, err = cryptox.RandomToken(24)
			if err != nil {
				return Settings{}, err
			}
		}
		ciphertext, err = s.Box.Encrypt([]byte(strings.TrimSpace(in.APIKey)), secretAADPrefix+secretRef)
		if err != nil {
			return Settings{}, err
		}
	}
	if *in.Enabled && strings.TrimSpace(ciphertext) == "" {
		return Settings{}, errors.New("Outline API key is required when integration is enabled")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return Settings{}, err
	}
	defer tx.Rollback()
	if _, err = tx.ExecContext(ctx, `UPDATE outline_settings SET enabled=?,base_url=?,collection_id=?,api_key_secret_ref=?,api_key_ciphertext=?,verify_tls=?,allow_http=?,request_timeout_seconds=?,updated_by=? WHERE id=1`,
		*in.Enabled, strings.TrimRight(in.BaseURL, "/"), in.CollectionID, secretRef, nullableCipher(ciphertext), *in.VerifyTLS, *in.AllowHTTP, in.RequestTimeoutSeconds, userID,
	); err != nil {
		return Settings{}, err
	}
	if _, err = tx.ExecContext(ctx, `INSERT INTO outline_targets(target_code,target_name,parent_document_id,active,created_by,updated_by)
		VALUES('virtualization','Virtualizare',?,1,?,?)
		ON DUPLICATE KEY UPDATE target_name='Virtualizare',parent_document_id=VALUES(parent_document_id),active=1,updated_by=VALUES(updated_by)`, in.VirtualizationParentDocumentID, userID, userID); err != nil {
		return Settings{}, err
	}
	if err = tx.Commit(); err != nil {
		return Settings{}, err
	}
	return s.GetSettings(ctx)
}

func nullableCipher(value string) any {
	if strings.TrimSpace(value) == "" {
		return nil
	}
	return value
}

func normalizeSettings(in *SettingsInput) error {
	in.BaseURL = strings.TrimRight(strings.TrimSpace(in.BaseURL), "/")
	in.CollectionID = strings.TrimSpace(in.CollectionID)
	in.VirtualizationParentDocumentID = strings.TrimSpace(in.VirtualizationParentDocumentID)
	if *in.Enabled || in.BaseURL != "" {
		u, err := url.Parse(in.BaseURL)
		if err != nil || u.Host == "" || (u.Scheme != "https" && u.Scheme != "http") {
			return errors.New("Outline base_url must be an absolute http/https URL")
		}
		if u.Scheme == "http" && !*in.AllowHTTP {
			return errors.New("Outline HTTP URL requires allow_http=true")
		}
	}
	if *in.Enabled && in.VirtualizationParentDocumentID == "" {
		return errors.New("Outline virtualization_parent_document_id is required")
	}
	if in.RequestTimeoutSeconds < 5 || in.RequestTimeoutSeconds > 300 {
		return errors.New("Outline request_timeout_seconds must be between 5 and 300")
	}
	return nil
}

func (s *Service) Test(ctx context.Context) (TestResult, error) {
	record, key, err := s.runtime(ctx)
	if err != nil {
		return TestResult{}, err
	}
	var doc apiEnvelope[apiDocument]
	if err := s.call(ctx, record, key, "documents.info", map[string]any{"id": record.VirtualizationParentDocumentID}, &doc); err != nil {
		return TestResult{}, err
	}
	result := TestResult{OK: true, ParentDocumentID: doc.Data.ID, ParentDocumentTitle: doc.Data.Title, BaseURL: record.BaseURL}
	if record.CollectionID != "" {
		var collection apiEnvelope[apiCollection]
		if err := s.call(ctx, record, key, "collections.info", map[string]any{"id": record.CollectionID}, &collection); err == nil {
			result.CollectionID = collection.Data.ID
			result.CollectionName = collection.Data.Name
		}
	}
	return result, nil
}

func (s *Service) runtime(ctx context.Context) (settingsRecord, string, error) {
	record, err := s.getRecord(ctx)
	if err != nil {
		return record, "", err
	}
	if !record.Enabled {
		return record, "", errors.New("Outline integration is disabled")
	}
	if !record.APIKeyConfigured {
		return record, "", errors.New("Outline API key is not configured")
	}
	plain, err := s.Box.Decrypt(record.Cipher.String, secretAADPrefix+record.SecretRef)
	if err != nil {
		return record, "", fmt.Errorf("decrypt Outline API key: %w", err)
	}
	return record, strings.TrimSpace(string(plain)), nil
}

func (s *Service) UpsertServiceDocument(ctx context.Context, serviceID int64, title string, markdown []byte) (PublishResult, error) {
	record, key, err := s.runtime(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	title = cleanTitle(title)
	hash := documentHash(title, markdown)
	var documentID, documentURL, currentHash string
	err = s.DB.QueryRowContext(ctx, `SELECT document_id,document_url,content_hash FROM outline_service_documents WHERE internal_service_id=?`, serviceID).Scan(&documentID, &documentURL, &currentHash)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return PublishResult{}, err
	}
	created := false
	changed := currentHash != hash
	var doc apiDocument
	if documentID != "" {
		if !changed {
			return PublishResult{ObjectType: "service", ObjectID: serviceID, ServiceID: serviceID, DocumentID: documentID, URL: absoluteDocumentURL(record.BaseURL, documentURL), Created: false, Changed: false, Title: title}, nil
		}
		var env apiEnvelope[apiDocument]
		err = s.call(ctx, record, key, "documents.update", map[string]any{"id": documentID, "title": title, "text": string(markdown)}, &env)
		if err == nil {
			doc = env.Data
		} else if !isNotFound(err) {
			return PublishResult{}, err
		} else {
			documentID = ""
		}
	}
	if documentID == "" {
		payload := map[string]any{"title": title, "text": string(markdown), "publish": true}
		if record.CollectionID == "" {
			return PublishResult{}, errors.New("Outline collection_id is required for legacy service publishing")
		}
		payload["collectionId"] = record.CollectionID
		var env apiEnvelope[apiDocument]
		if err := s.call(ctx, record, key, "documents.create", payload, &env); err != nil {
			return PublishResult{}, err
		}
		doc = env.Data
		created = true
		changed = true
	}
	if doc.ID == "" {
		doc.ID = documentID
	}
	if doc.URL == "" {
		doc.URL = documentURL
	}
	_, err = s.DB.ExecContext(ctx, `INSERT INTO outline_service_documents(internal_service_id,document_id,document_url,content_hash,last_synced_at) VALUES(?,?,?,?,NOW(6)) ON DUPLICATE KEY UPDATE document_id=VALUES(document_id),document_url=VALUES(document_url),content_hash=VALUES(content_hash),last_synced_at=NOW(6)`, serviceID, doc.ID, doc.URL, hash)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "service", ObjectID: serviceID, ServiceID: serviceID, DocumentID: doc.ID, URL: absoluteDocumentURL(record.BaseURL, doc.URL), Created: created, Changed: changed, Title: title}, nil
}

func (s *Service) UpsertVMDocument(ctx context.Context, vmID int64, title string, markdown []byte) (PublishResult, error) {
	record, key, err := s.runtime(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	parentDocumentID := strings.TrimSpace(record.VirtualizationParentDocumentID)
	if parentDocumentID == "" {
		return PublishResult{}, errors.New("Outline Virtualizare parent document is not configured")
	}
	title = cleanTitle(title)
	hash := documentHash(title, markdown)
	var documentID, documentURL, storedParentDocumentID, currentHash string
	err = s.DB.QueryRowContext(ctx, `SELECT document_id,document_url,parent_document_id,content_hash FROM outline_vm_documents_global WHERE vm_id=? AND target_code='virtualization'`, vmID).Scan(&documentID, &documentURL, &storedParentDocumentID, &currentHash)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return PublishResult{}, err
	}
	created := false
	changed := currentHash != hash
	var doc apiDocument
	if documentID != "" {
		if strings.TrimSpace(storedParentDocumentID) != parentDocumentID {
			if err := s.call(ctx, record, key, "documents.move", map[string]any{"id": documentID, "parentDocumentId": parentDocumentID}, nil); err != nil {
				if !isNotFound(err) {
					return PublishResult{}, err
				}
				documentID = ""
			} else {
				changed = true
			}
		}
		if documentID != "" && currentHash == hash {
			_, err = s.DB.ExecContext(ctx, `UPDATE outline_vm_documents_global SET parent_document_id=?,last_synced_at=NOW(6) WHERE vm_id=? AND target_code='virtualization'`, parentDocumentID, vmID)
			if err != nil {
				return PublishResult{}, err
			}
			return PublishResult{ObjectType: "vm", ObjectID: vmID, DocumentID: documentID, URL: absoluteDocumentURL(record.BaseURL, documentURL), Created: false, Changed: changed, Title: title}, nil
		}
		if documentID != "" {
			var env apiEnvelope[apiDocument]
			err = s.call(ctx, record, key, "documents.update", map[string]any{"id": documentID, "title": title, "text": string(markdown)}, &env)
			if err == nil {
				doc = env.Data
			} else if !isNotFound(err) {
				return PublishResult{}, err
			} else {
				documentID = ""
			}
		}
	}
	if documentID == "" {
		var env apiEnvelope[apiDocument]
		if err := s.call(ctx, record, key, "documents.create", map[string]any{"title": title, "text": string(markdown), "parentDocumentId": parentDocumentID, "publish": true}, &env); err != nil {
			return PublishResult{}, err
		}
		doc = env.Data
		created = true
		changed = true
	}
	if doc.ID == "" {
		doc.ID = documentID
	}
	if doc.URL == "" {
		doc.URL = documentURL
	}
	_, err = s.DB.ExecContext(ctx, `INSERT INTO outline_vm_documents_global(vm_id,target_code,document_id,document_url,parent_document_id,content_hash,last_synced_at) VALUES(?,'virtualization',?,?,?,?,NOW(6)) ON DUPLICATE KEY UPDATE document_id=VALUES(document_id),document_url=VALUES(document_url),parent_document_id=VALUES(parent_document_id),content_hash=VALUES(content_hash),last_synced_at=NOW(6)`, vmID, doc.ID, doc.URL, parentDocumentID, hash)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "vm", ObjectID: vmID, DocumentID: doc.ID, URL: absoluteDocumentURL(record.BaseURL, doc.URL), Created: created, Changed: changed, Title: title}, nil
}

func (s *Service) ServiceDocumentID(ctx context.Context, serviceID int64) (string, error) {
	var id string
	err := s.DB.QueryRowContext(ctx, `SELECT document_id FROM outline_service_documents WHERE internal_service_id=?`, serviceID).Scan(&id)
	return id, err
}

func (s *Service) ServiceMapping(ctx context.Context, serviceID int64) (PublishResult, error) {
	var id, path string
	err := s.DB.QueryRowContext(ctx, `SELECT document_id,document_url FROM outline_service_documents WHERE internal_service_id=?`, serviceID).Scan(&id, &path)
	if err != nil {
		return PublishResult{}, err
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "service", ObjectID: serviceID, ServiceID: serviceID, DocumentID: id, URL: absoluteDocumentURL(settings.BaseURL, path)}, nil
}

func (s *Service) VMMapping(ctx context.Context, vmID int64) (PublishResult, error) {
	var id, path string
	err := s.DB.QueryRowContext(ctx, `SELECT document_id,document_url FROM outline_vm_documents_global WHERE vm_id=? AND target_code='virtualization'`, vmID).Scan(&id, &path)
	if err != nil {
		return PublishResult{}, err
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return PublishResult{}, err
	}
	return PublishResult{ObjectType: "vm", ObjectID: vmID, DocumentID: id, URL: absoluteDocumentURL(settings.BaseURL, path)}, nil
}

func (s *Service) call(ctx context.Context, settings settingsRecord, apiKey, method string, payload any, out any) error {
	body, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	endpoint := strings.TrimRight(settings.BaseURL, "/") + "/api/" + method
	transport := &http.Transport{TLSClientConfig: &tls.Config{MinVersion: tls.VersionTLS12, InsecureSkipVerify: !settings.VerifyTLS}} // #nosec G402 - explicit administrator-controlled compatibility option.
	client := &http.Client{Timeout: time.Duration(settings.RequestTimeoutSeconds) * time.Second, Transport: transport}
	var last error
	for attempt := 0; attempt < 3; attempt++ {
		req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(body))
		if err != nil {
			return err
		}
		req.Header.Set("Authorization", "Bearer "+apiKey)
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("Accept", "application/json")
		resp, err := client.Do(req)
		if err != nil {
			return fmt.Errorf("Outline %s: %w", method, err)
		}
		data, readErr := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
		resp.Body.Close()
		if readErr != nil {
			return fmt.Errorf("Outline %s response: %w", method, readErr)
		}
		if resp.StatusCode >= 200 && resp.StatusCode < 300 {
			if out == nil || len(data) == 0 {
				return nil
			}
			if err := json.Unmarshal(data, out); err != nil {
				return fmt.Errorf("Outline %s invalid response: %w", method, err)
			}
			return nil
		}
		var apiErr apiErrorEnvelope
		_ = json.Unmarshal(data, &apiErr)
		message := strings.TrimSpace(firstNonEmpty(apiErr.Message, apiErr.Error, string(data)))
		if message == "" {
			message = http.StatusText(resp.StatusCode)
		}
		last = &remoteError{StatusCode: resp.StatusCode, Message: "Outline " + method + ": " + message}
		if resp.StatusCode != http.StatusTooManyRequests || attempt == 2 {
			return last
		}
		wait := time.Second * time.Duration(attempt+1)
		if raw := resp.Header.Get("Retry-After"); raw != "" {
			if sec, convErr := strconv.Atoi(raw); convErr == nil && sec > 0 && sec <= 30 {
				wait = time.Duration(sec) * time.Second
			}
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(wait):
		}
	}
	return last
}

func isNotFound(err error) bool {
	var remote *remoteError
	return errors.As(err, &remote) && remote.StatusCode == http.StatusNotFound
}

func documentHash(title string, markdown []byte) string {
	sum := sha256.Sum256(append([]byte(title+"\n"), markdown...))
	return hex.EncodeToString(sum[:])
}

func cleanTitle(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "VM-DOC"
	}
	runes := []rune(value)
	if len(runes) > 100 {
		value = string(runes[:100])
	}
	return value
}

func absoluteDocumentURL(baseURL, path string) string {
	path = strings.TrimSpace(path)
	if path == "" {
		return ""
	}
	if u, err := url.Parse(path); err == nil && u.IsAbs() {
		return path
	}
	return strings.TrimRight(baseURL, "/") + "/" + strings.TrimLeft(path, "/")
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}
