package server

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/documents"
	outlineapi "vm-doc-server/internal/outline"
)

type outlineBulkInput struct {
	PoweredOnOnly bool `json:"powered_on_only"`
}

type outlineBulkJob struct {
	ID           string    `json:"id"`
	Status       string    `json:"status"`
	StartedAt    time.Time `json:"started_at"`
	FinishedAt   time.Time `json:"finished_at,omitempty"`
	TotalVMs     int       `json:"total_vms"`
	ProcessedVMs int       `json:"processed_vms"`
	PublishedVMs int       `json:"published_vms"`
	Errors       []string  `json:"errors,omitempty"`
	LastObject   string    `json:"last_object,omitempty"`
}

var outlineBulkJobs = struct {
	sync.RWMutex
	values map[string]*outlineBulkJob
}{values: map[string]*outlineBulkJob{}}

func (a *App) outlineSettings(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	value, err := a.Outline.GetSettings(r.Context())
	respond(w, value, err)
}

func (a *App) updateOutlineSettings(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	var input outlineapi.SettingsInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Outline.UpdateSettings(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "outline.settings.update", "outline_settings", "1", "success", map[string]any{
			"enabled":                           value.Enabled,
			"base_url":                          value.BaseURL,
			"collection_id":                     value.CollectionID,
			"virtualization_parent_document_id": value.VirtualizationParentDocumentID,
			"verify_tls":                        value.VerifyTLS,
			"allow_http":                        value.AllowHTTP,
		})
	}
	respond(w, value, err)
}

func (a *App) testOutline(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	value, err := a.Outline.Test(r.Context())
	if err == nil {
		a.auditRequest(r, "outline.connection.test", "outline_settings", "1", "success", map[string]any{
			"parent_document_id":    value.ParentDocumentID,
			"parent_document_title": value.ParentDocumentTitle,
		})
	}
	respond(w, value, err)
}

func (a *App) publishVMOutline(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.publishVMToOutline(r, vmID)
	if err == nil {
		a.auditRequest(r, "outline.vm.publish", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{
			"vm_id":               vmID,
			"outline_target":      "virtualization",
			"outline_document_id": result.DocumentID,
			"outline_url":         result.URL,
		})
	}
	respond(w, result, err)
}

func (a *App) outlineVMMapping(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Outline.VMMapping(r.Context(), vmID)
	if errors.Is(err, sql.ErrNoRows) {
		jsonResponse(w, http.StatusOK, map[string]any{"configured": false})
		return
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, map[string]any{"configured": true, "document_id": value.DocumentID, "url": value.URL})
}

func (a *App) startOutlineBulkPublish(w http.ResponseWriter, r *http.Request) {
	var input outlineBulkInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	if _, err := a.Outline.Test(r.Context()); err != nil {
		respond(w, nil, err)
		return
	}
	now := time.Now().UTC()
	id := fmt.Sprintf("outline-%d", now.UnixNano())
	job := &outlineBulkJob{ID: id, Status: "queued", StartedAt: now}
	outlineBulkJobs.Lock()
	for existingID, existing := range outlineBulkJobs.values {
		if !existing.FinishedAt.IsZero() && now.Sub(existing.FinishedAt) > 24*time.Hour {
			delete(outlineBulkJobs.values, existingID)
		}
	}
	outlineBulkJobs.values[id] = job
	outlineBulkJobs.Unlock()

	bgRequest := r.Clone(context.WithoutCancel(r.Context()))
	go a.runOutlineBulkPublish(bgRequest, job, input)
	jsonResponse(w, http.StatusAccepted, job)
}

func (a *App) getOutlineBulkJob(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimSpace(r.PathValue("id"))
	outlineBulkJobs.RLock()
	job := outlineBulkJobs.values[id]
	if job == nil {
		outlineBulkJobs.RUnlock()
		respond(w, nil, sql.ErrNoRows)
		return
	}
	copy := *job
	copy.Errors = append([]string(nil), job.Errors...)
	outlineBulkJobs.RUnlock()
	respond(w, copy, nil)
}

func (a *App) runOutlineBulkPublish(r *http.Request, job *outlineBulkJob, input outlineBulkInput) {
	update := func(fn func(*outlineBulkJob)) {
		outlineBulkJobs.Lock()
		fn(job)
		outlineBulkJobs.Unlock()
	}
	update(func(j *outlineBulkJob) { j.Status = "running" })
	items, err := a.Documents.ListBulkExportItems(r.Context(), "vm", input.PoweredOnOnly)
	if err != nil {
		update(func(j *outlineBulkJob) {
			j.Status = "failed"
			j.FinishedAt = time.Now().UTC()
			j.Errors = append(j.Errors, err.Error())
		})
		return
	}
	update(func(j *outlineBulkJob) { j.TotalVMs = len(items) })
	for _, item := range items {
		update(func(j *outlineBulkJob) { j.LastObject = item.ObjectName })
		_, publishErr := a.publishVMToOutline(r, item.ObjectID)
		update(func(j *outlineBulkJob) {
			j.ProcessedVMs++
			if publishErr != nil {
				j.Errors = append(j.Errors, item.ObjectName+": "+publishErr.Error())
				return
			}
			j.PublishedVMs++
		})
	}
	update(func(j *outlineBulkJob) {
		if len(j.Errors) > 0 {
			j.Status = "partial"
		} else {
			j.Status = "success"
		}
		j.FinishedAt = time.Now().UTC()
		j.LastObject = ""
	})
	a.auditRequest(r, "outline.bulk_publish", "outline", job.ID, "success", map[string]any{
		"target":          "virtualization",
		"powered_on_only": input.PoweredOnOnly,
		"vms":             job.PublishedVMs,
		"errors":          len(job.Errors),
	})
}

func (a *App) publishVMToOutline(r *http.Request, vmID int64) (outlineapi.PublishResult, error) {
	if a.Outline == nil {
		return outlineapi.PublishResult{}, errors.New("Outline integration is unavailable")
	}
	data, err := a.buildVMGenerationData(r, vmID)
	if err != nil {
		return outlineapi.PublishResult{}, err
	}
	if generated, listErr := a.Documents.ListGeneratedVM(r.Context(), vmID); listErr == nil && len(generated) > 0 {
		data.DocumentNumber = generated[0].DocumentNumber
		data.GeneratedAt = generated[0].GeneratedAt
	}
	data.IncludeGeneratedBy = false
	markdown := documents.RenderVMMarkdown(data)
	title := "VM — " + firstServerNonEmpty(data.VM.GuestHostname, data.VM.Name, fmt.Sprintf("VM %d", vmID))
	return a.Outline.UpsertVMDocument(r.Context(), vmID, title, markdown)
}
