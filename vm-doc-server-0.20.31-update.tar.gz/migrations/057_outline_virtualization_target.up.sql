-- 0.20.31: publicarea Outline a VM-urilor este separată de proiecte.
-- Fiecare categorie Outline poate avea propriul document părinte; prima categorie este Virtualizare.

CREATE TABLE IF NOT EXISTS outline_targets (
  target_code VARCHAR(64) NOT NULL,
  target_name VARCHAR(255) NOT NULL,
  parent_document_id VARCHAR(64) NOT NULL DEFAULT '',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (target_code),
  CONSTRAINT fk_outline_targets_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_outline_targets_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO outline_targets(target_code,target_name,parent_document_id,active)
VALUES ('virtualization','Virtualizare','',1)
ON DUPLICATE KEY UPDATE target_name=VALUES(target_name),active=1;

CREATE TABLE IF NOT EXISTS outline_vm_documents_global (
  vm_id BIGINT UNSIGNED NOT NULL,
  target_code VARCHAR(64) NOT NULL DEFAULT 'virtualization',
  document_id VARCHAR(64) NOT NULL,
  document_url VARCHAR(1024) NOT NULL DEFAULT '',
  parent_document_id VARCHAR(64) NOT NULL DEFAULT '',
  content_hash CHAR(64) NOT NULL DEFAULT '',
  last_synced_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (vm_id,target_code),
  UNIQUE KEY uq_outline_vm_global_document_id (document_id),
  KEY idx_outline_vm_global_target (target_code),
  CONSTRAINT fk_outline_vm_global_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_outline_vm_global_target FOREIGN KEY (target_code) REFERENCES outline_targets(target_code) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
