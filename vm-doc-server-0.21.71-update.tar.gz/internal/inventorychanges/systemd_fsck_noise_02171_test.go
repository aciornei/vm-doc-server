package inventorychanges

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestSystemdFsckServiceFilterIsExact(t *testing.T) {
	ignored := []string{
		"systemd-fsck.service", "systemd-fsckd.service", "systemd-fsck-root.service", "systemd-fsck-usr.service",
		`systemd-fsck@dev-disk-by\x2duuid-56b6594e\x2d455b\x2d422f\x2db2a8\x2dd40b0a7ab5fe.service`,
		`systemd-fsck@dev-disk-by\x2did-dm\x2duuid\x2dLVM\x2dXXX.service`,
	}
	for _, name := range ignored {
		if !isSystemdFsckNoiseService(name) {
			t.Errorf("fsck unit must be ignored: %q", name)
		}
	}
	kept := []string{"systemd.service", "systemd-udevd.service", "systemd-journald.service", "systemd-remount-fs.service", "systemd-fsck@.timer", "systemd-fsck-check.service", "my-systemd-fsck.service", "fsck.service", "postgresql.service", "systemd-fsck@dev-disk-by\x2duuid-99.timer"}
	for _, name := range kept {
		if isSystemdFsckNoiseService(name) {
			t.Errorf("non-fsck target wrongly ignored: %q", name)
		}
	}
}

func TestSystemdFsckSnapshotsRemainRawButNeverCreateTrackedEvents(t *testing.T) {
	oldSnap := map[string]any{"services": []any{
		map[string]any{"name": "systemd-fsckd.service", "package_version": "255.4-1ubuntu8.17", "version": "255.4-1ubuntu8.17"},
		map[string]any{"name": `systemd-fsck@dev-disk-by\x2duuid-56b6594e.service`, "package_version": "255.4-1ubuntu8.17", "version": "255.4-1ubuntu8.17"},
		map[string]any{"name": "postgresql.service", "package_version": "15.1", "enabled_state": "enabled"},
		map[string]any{"name": "systemd-journald.service", "package_version": "255.4-1ubuntu8.17"},
	}}
	newSnap := map[string]any{"services": []any{
		map[string]any{"name": "systemd-fsckd.service", "package_version": "255.4-1ubuntu8.18", "version": "255.4-1ubuntu8.18"},
		map[string]any{"name": `systemd-fsck@dev-disk-by\x2duuid-56b6594e.service`, "package_version": "255.4-1ubuntu8.18", "version": "255.4-1ubuntu8.18"},
		map[string]any{"name": "postgresql.service", "package_version": "15.2", "enabled_state": "enabled"},
		map[string]any{"name": "systemd-journald.service", "package_version": "255.4-1ubuntu8.18"},
	}}
	aBytes, err := json.Marshal(oldSnap)
	if err != nil {
		t.Fatal(err)
	}
	bBytes, err := json.Marshal(newSnap)
	if err != nil {
		t.Fatal(err)
	}
	a, err := extractTracked(aBytes)
	if err != nil {
		t.Fatal(err)
	}
	b, err := extractTracked(bBytes)
	if err != nil {
		t.Fatal(err)
	}
	for _, obj := range []map[string]trackedObject{a, b} {
		for k := range obj {
			if strings.Contains(k, "systemd-fsck") {
				t.Fatalf("filtered unit present: %s", k)
			}
		}
		if _, ok := obj["services|service|postgresql.service"]; !ok {
			t.Fatal("lost postgresql service")
		}
		if _, ok := obj["services|service|systemd-journald.service"]; !ok {
			t.Fatal("lost journald service")
		}
	}
	if trackedObjectsEqual(a["services|service|postgresql.service"], b["services|service|postgresql.service"]) {
		t.Fatal("real postgres package upgrade lost")
	}
	if trackedObjectsEqual(a["services|service|systemd-journald.service"], b["services|service|systemd-journald.service"]) {
		t.Fatal("other systemd package upgrade lost")
	}
	if !strings.Contains(string(aBytes), "255.4-1ubuntu8.17") || !strings.Contains(string(bBytes), "255.4-1ubuntu8.18") {
		t.Fatal("raw inventories changed")
	}
}

func TestSystemdFsckAddedRemovedBothIgnored(t *testing.T) {
	for _, raw := range []string{`{"services":[]}`, `{"services":[{"name":"systemd-fsckd.service"},{"name":"systemd-fsck@dev-disk-by\\x2duuid-aaa.service"}]}`} {
		objects, err := extractTracked([]byte(raw))
		if err != nil {
			t.Fatal(err)
		}
		for k := range objects {
			if strings.Contains(k, "systemd-fsck") {
				t.Fatalf("unexpected add/remove candidate %s", k)
			}
		}
	}
}
