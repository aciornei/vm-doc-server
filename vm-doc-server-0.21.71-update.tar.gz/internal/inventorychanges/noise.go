package inventorychanges

import (
	"context"
	"database/sql"
	"fmt"
	"net/netip"
	"regexp"
	"strconv"
	"strings"
)

// Default change-history policy: retain all raw snapshots. Only suppress
// unstable observations in change events. A selected Principal port is exempt.
const ephemeralPortStart = 49152
const ephemeralPortEnd = 65535

// Automatically generated Linux veth peer names (commonly Docker/LXC) are
// ephemeral topology, not durable VM network configuration. Match only the
// kernel-style hexadecimal suffix; keep deliberately named veth interfaces,
// bridges, VLANs and normal NICs in documentation-change history.
var ephemeralVethNameRE = regexp.MustCompile(`(?i)^veth[0-9a-f]{5,}(?:@if[0-9]+)?$`)

func isEphemeralVethInterface(name string) bool {
	return ephemeralVethNameRE.MatchString(strings.TrimSpace(name))
}

// Docker creates bridge interfaces named br-<12 hex> for user-defined networks.
// A recreated network gets a different hash without changing the VM network
// configuration. Keep docker0, stable/manual bridges and all raw inventory.
var ephemeralDockerBridgeRE = regexp.MustCompile(`(?i)^br-[0-9a-f]{12}$`)

func isEphemeralDockerBridgeInterface(name string) bool {
	return ephemeralDockerBridgeRE.MatchString(strings.TrimSpace(name))
}

// Linux transient instances: lxd-installer uses multi-number instance names
// such as lxd-installer@177-1372636-0.service. Do not match named templates.
var ephemeralServiceRE = regexp.MustCompile(`(?i)^(?:(?:user|user-runtime-dir)@[0-9]+|lxd-installer@[0-9]+(?:-[0-9]+)*)\.service$`)

// systemd-fsck units (including escaped /dev/disk/by-uuid instances) represent
// boot-time filesystem checks, not separately documented applications. Their
// version/package_version mirrors the same OS systemd package update for each
// disk and causes many redundant events. Keep all units in raw inventory, but
// do not emit add/remove/modify events for these exact systemd unit families.
// Explicit services and OS-level changes remain tracked normally.
var systemdFsckServiceRE = regexp.MustCompile(`(?i)^systemd-fsck(?:@.+|-root|-usr|d)?\.service$`)

func isSystemdFsckNoiseService(name string) bool {
	return systemdFsckServiceRE.MatchString(strings.TrimSpace(name))
}

// Windows per-user service instances have a session/logon-derived hexadecimal
// suffix. Match only Microsoft's known per-user service families, not every
// service ending with _<hex> (which might be an application service).
var windowsPerUserServiceRE = regexp.MustCompile(`(?i)^([a-z][a-z0-9]*)_([0-9a-f]{5,12})$`)

var windowsPerUserFamilies = map[string]bool{
	"aarsvc": true, "bcastdvruserservice": true,
	"bluetoothuserservice": true, "captureservice": true,
	"cbdhsvc": true, "cdpusersvc": true, "cloudbackuprestoresvc": true,
	"consentuxusersvc": true, "credentialenrollmentmanagerusersvc": true,
	"devicepickerusersvc": true, "devicesflowusersvc": true,
	"deviceassociationbrokersvc": true, "npsmsvc": true,
	"p9rdrservice":     true,
	"messagingservice": true, "onesyncsvc": true,
	"pimindexmaintenancesvc": true, "printworkflowusersvc": true,
	"udkusersvc": true, "unistoresvc": true, "userdatasvc": true,
	"webthreatdefusersvc": true, "wpnuserservice": true,
}

func isEphemeralService(name string) bool {
	name = strings.TrimSpace(name)
	if ephemeralServiceRE.MatchString(name) {
		return true
	}
	match := windowsPerUserServiceRE.FindStringSubmatch(name)
	return len(match) == 3 && windowsPerUserFamilies[strings.ToLower(match[1])]
}

var versionDiagnosticRE = regexp.MustCompile(`(?i)(?:\[(?:warning|error)\]|\b(?:warning|error):|\busing unique option prefix\b)`)
var versionOnlyPrefixRE = regexp.MustCompile(`(?i)^v?[0-9]+(?:\.[0-9]+){1,5}(?:[-+][a-z0-9._-]+)?$`)

// Elastic Beats may return either a plain semantic version or a long binary
// banner containing build IDs, timestamps and architecture. These represent the
// SAME application release. Restrict normalization to recognized Beat services
// and require a matching libbeat version to avoid masking inconsistent binaries.
// Preserve raw inventory and all package_version values unchanged.
var beatVersionBannerRE = regexp.MustCompile(`(?i)^(auditbeat|filebeat|metricbeat|packetbeat|heartbeat|winlogbeat) version v?([0-9]+(?:\.[0-9]+){1,5}) \([^\r\n)]{1,100}\), libbeat v?([0-9]+(?:\.[0-9]+){1,5})(?:\s+[^\r\n]*)?$`)

func normalizeBeatVersion(name, raw string) string {
	name = strings.ToLower(strings.TrimSpace(name))
	name = strings.TrimSuffix(name, ".service")
	match := beatVersionBannerRE.FindStringSubmatch(strings.TrimSpace(raw))
	if len(match) != 4 || name != strings.ToLower(match[1]) || match[2] != match[3] {
		return raw
	}
	return match[2]
}

// Do not mistake MySQL/MariaDB stderr warnings (often prefixed by changing
// timestamps) for installed software versions. The raw snapshot is untouched.
// Preserve actual version lines and package_version for real upgrade detection.
func trackedServiceFields(svc map[string]any) map[string]any {
	value := pick(svc, "name", "manager", "enabled_state", "software_name", "version", "package_name", "package_version")
	// On Windows SCM, software_name is Win32_Service.DisplayName: it can
	// alternate between a localized display name and the stable service name.
	// Name is the object identity; enabled_state and real versions remain tracked.
	// Do not apply this rule to Linux/systemd/SysV or unknown managers.
	if strings.EqualFold(strings.TrimSpace(first(svc, "manager")), "windows_scm") {
		delete(value, "software_name")
	}
	for _, field := range []string{"version", "package_version"} {
		if raw, ok := value[field].(string); ok && versionDiagnosticRE.MatchString(raw) {
			lines := strings.Split(strings.ReplaceAll(strings.ReplaceAll(raw, "\r\n", "\n"), "\r", "\n"), "\n")
			clean := make([]string, 0, len(lines))
			for _, line := range lines {
				line = strings.TrimSpace(line)
				if line == "" {
					continue
				}
				if at := versionDiagnosticRE.FindStringIndex(line); at != nil {
					// Preserve a legitimate leading version when warning text
					// was appended on the same line.
					if prefix := strings.TrimSpace(line[:at[0]]); versionOnlyPrefixRE.MatchString(prefix) {
						clean = append(clean, prefix)
					}
					continue
				}
				clean = append(clean, line)
			}
			if len(clean) == 0 {
				delete(value, field)
			} else {
				value[field] = strings.Join(clean, " ")
			}
		}
	}
	if version, ok := value["version"].(string); ok {
		value["version"] = normalizeBeatVersion(first(svc, "name"), version)
	}
	return value
}

// This is an intentionally narrow list of AUTOMATIC rules/chains. In particular
// ufw-user-*, DOCKER-USER and ordinary INPUT/OUTPUT/FORWARD rules are retained.
var generatedChainRE = regexp.MustCompile(`(?i)^(?:ufw-(?:before|after|track|logging|skip|reject|not-local)(?:-|$)|docker(?:-|$)|cni-|kube-|libvirt)`)

// Docker may insert one isolation guard per container IP on each recreated
// br-<12 hex> bridge, including in generic FORWARD chains. The chain name
// alone does not identify it as generated. Accept either quoted or unquoted
// bridge names and the optional nftables meta keyword. Suppress only the exact, normalized
// IPv4 RFC1918 guard: ip daddr A.B.C.D iifname != "br-XXXXXXXXXXXX" counter drop.
// Do not suppress general nft rules, static bridges or DOCKER-USER overrides.
var dockerBridgeGuardRE = regexp.MustCompile(`(?i)^ip daddr ((?:[0-9]{1,3}\.){3}[0-9]{1,3}) (?:meta )?iifname != (?:"br-[0-9a-f]{12}"|br-[0-9a-f]{12}) counter drop$`)

func isDockerBridgeGuardRule(text string) bool {
	parts := dockerBridgeGuardRE.FindStringSubmatch(normalizeFirewallRule(text))
	if len(parts) != 2 {
		return false
	}
	ip, err := netip.ParseAddr(parts[1])
	return err == nil && ip.Is4() && ip.IsPrivate()
}

// Docker's iptables backend can create its own raw/PREROUTING isolation guard
// for a container attached to a recreated br-<12hex> bridge. This is NOT the
// nftables string form. Match only the exact Docker-shaped IPv4 /32 DROP guard
// in raw PREROUTING; preserve ordinary PREROUTING/DROP rules, other tables,
// public destinations, manually named bridges and DOCKER-USER policies.
var dockerIptablesRawGuardRE = regexp.MustCompile(`(?i)^-A PREROUTING -d ((?:[0-9]{1,3}\.){3}[0-9]{1,3})/32 ! -i br-[0-9a-f]{12} -j DROP$`)

func isDockerIptablesRawGuardRule(rule map[string]any) bool {
	if !strings.EqualFold(first(rule, "backend"), "iptables") ||
		!strings.EqualFold(first(rule, "family"), "ipv4") ||
		!strings.EqualFold(first(rule, "table"), "raw") ||
		!strings.EqualFold(first(rule, "chain"), "PREROUTING") {
		return false
	}
	match := dockerIptablesRawGuardRE.FindStringSubmatch(normalizeFirewallRule(first(rule, "rule")))
	if len(match) != 2 {
		return false
	}
	ip, err := netip.ParseAddr(match[1])
	return err == nil && ip.Is4() && ip.IsPrivate()
}

// Docker's nftables NAT POSTROUTING bridge masquerade follows this shape:
// ip saddr 172.18.0.0/16 oifname != "br-<12hex>" counter masquerade.
// Keep this deliberately narrow: nat/POSTROUTING only, RFC1918 source prefix,
// automatic Docker bridge, no extra actions or conditions. Explicit NAT and
// DOCKER-USER rules remain visible in documentation-change history.
var dockerNftMasqueradeRE = regexp.MustCompile(`(?i)^ip saddr ((?:[0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}) (?:meta )?oifname != (?:"br-[0-9a-f]{12}"|br-[0-9a-f]{12}) (?:counter )?masquerade$`)

func isDockerNftMasqueradeRule(rule map[string]any) bool {
	if !strings.EqualFold(first(rule, "backend"), "nftables") ||
		!strings.EqualFold(first(rule, "table"), "nat") ||
		!strings.EqualFold(first(rule, "chain"), "POSTROUTING") {
		return false
	}
	family := strings.ToLower(first(rule, "family"))
	if family != "ip" && family != "ipv4" {
		return false
	}
	match := dockerNftMasqueradeRE.FindStringSubmatch(normalizeFirewallRule(first(rule, "rule")))
	if len(match) != 2 {
		return false
	}
	prefix, err := netip.ParsePrefix(match[1])
	return err == nil && prefix.Addr().Is4() && prefix.Addr().IsPrivate() && prefix.Masked() == prefix
}

// Docker's iptables (legacy/nft-compatible frontend) NAT bridge masquerade:
// -A POSTROUTING -s 172.18.0.0/16 ! -o br-<12hex> -j MASQUERADE.
// Do NOT confuse this with the separate nftables rule-text syntax. The
// exact match is constrained to IPv4/nat/POSTROUTING, one RFC1918 subnet,
// and a Docker-generated bridge. Raw firewall inventories stay unchanged.
var dockerIptablesNatMasqueradeRE = regexp.MustCompile(`(?i)^-A POSTROUTING -s ((?:[0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}) ! -o br-[0-9a-f]{12} -j MASQUERADE$`)

// A source CIDR must be entirely inside RFC1918 space (not merely start at
// a private address, e.g. 172.16.0.0/8 should not be classified as private).
func isRFC1918IPv4Subnet(cidr string) bool {
	prefix, err := netip.ParsePrefix(cidr)
	if err != nil || !prefix.Addr().Is4() || prefix.Masked() != prefix {
		return false
	}
	for _, cidr := range []string{"10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"} {
		p := netip.MustParsePrefix(cidr)
		if prefix.Bits() >= p.Bits() && p.Contains(prefix.Addr()) {
			return true
		}
	}
	return false
}

func isDockerIptablesNatMasqueradeRule(rule map[string]any) bool {
	if !strings.EqualFold(first(rule, "backend"), "iptables") ||
		!strings.EqualFold(first(rule, "family"), "ipv4") ||
		!strings.EqualFold(first(rule, "table"), "nat") ||
		!strings.EqualFold(first(rule, "chain"), "POSTROUTING") {
		return false
	}
	if action := first(rule, "action"); action != "" && !strings.EqualFold(action, "MASQUERADE") {
		return false
	}
	match := dockerIptablesNatMasqueradeRE.FindStringSubmatch(normalizeFirewallRule(first(rule, "rule")))
	return len(match) == 2 && isRFC1918IPv4Subnet(match[1])
}

func isGeneratedFirewallRule(rule map[string]any) bool {
	backend := strings.ToLower(first(rule, "backend"))
	if backend != "nftables" && backend != "iptables" && backend != "ip6tables" {
		return false
	}
	chain := first(rule, "chain")
	if strings.EqualFold(chain, "DOCKER-USER") || strings.HasPrefix(strings.ToLower(chain), "docker-user-") {
		return false
	}
	if backend == "nftables" && (isDockerBridgeGuardRule(first(rule, "rule")) || isDockerNftMasqueradeRule(rule)) {
		return true
	}
	if isDockerIptablesRawGuardRule(rule) || isDockerIptablesNatMasqueradeRule(rule) {
		return true
	}
	return generatedChainRE.MatchString(chain)
}

type portSelection struct {
	protocol string
	port     int
}

func loadPrimaryPortSelections(ctx context.Context, tx *sql.Tx, vmID int64) (map[portSelection]bool, error) {
	rows, err := tx.QueryContext(ctx, `SELECT protocol,port FROM vm_primary_agent_ports WHERE vm_id=?`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	selected := make(map[portSelection]bool)
	for rows.Next() {
		var protocol string
		var port int
		if err := rows.Scan(&protocol, &port); err != nil {
			return nil, err
		}
		selected[portSelection{strings.ToLower(strings.TrimSpace(protocol)), port}] = true
	}
	return selected, rows.Err()
}

func suppressDynamicPortChange(oldObj, newObj trackedObject, hadOld, hasNew bool, selected map[portSelection]bool) bool {
	o := newObj
	if !hasNew {
		o = oldObj
	}
	if o.Category != "ports" || o.Type != "listening_port" {
		return false
	}
	v, ok := o.Value.(map[string]any)
	if !ok {
		return false
	}
	pText := numberText(v["port"])
	port, err := strconv.Atoi(pText)
	if err != nil || port < 1 || port > 65535 {
		return false
	}
	proto := strings.ToLower(strings.TrimSpace(fmt.Sprint(v["protocol"])))
	// Minimal documentation policy: UDP observations are volatile unless
	// the operator explicitly marks the endpoint as Principal.
	// TCP keeps the prior 49152-65535 dynamic-port rule.
	if proto != "udp" && (proto != "tcp" || port < ephemeralPortStart || port > ephemeralPortEnd) {
		return false
	}
	return !selected[portSelection{proto, port}]
}

// trackedDockerNetworks creates a copy of Docker network attachments for
// documentation diffing. Only the transient endpoint MAC is excluded; the raw
// agent snapshot and the normalized Docker inventory keep the actual MAC.
// Never mutate the decoded source inventory in place.
func trackedDockerNetworks(raw any) any {
	networks := asSlice(raw)
	out := make([]any, 0, len(networks))
	for _, entry := range networks {
		m := asMap(entry)
		if m == nil {
			out = append(out, entry)
			continue
		}
		clone := make(map[string]any, len(m))
		for key, value := range m {
			if strings.EqualFold(key, "mac_address") {
				continue
			}
			clone[key] = value
		}
		out = append(out, clone)
	}
	return out
}

// Image digests are deployment artifacts, not user-facing version tags.
// Keep the repository and explicit tag, e.g. app:2.1@sha256:... -> app:2.1.
func trackedDockerImage(image string) string {
	image = strings.TrimSpace(image)
	if idx := strings.Index(strings.ToLower(image), "@sha256:"); idx >= 0 {
		return image[:idx]
	}
	return image
}

// Older MySQL/MariaDB startup logs can be returned by a probe in place of
// --version output. Each restart changes the timestamp and PID while the
// software version stays the same, e.g.:
// 261021 14:04:10 [Note] /usr/libexec/mysqld (mysqld 5.5.56-MariaDB) starting as process 59985 ...
// Restrict this to MySQL/MariaDB database instances and to complete, dated
// startup-log syntax; unrelated [Note] strings are not silently discarded.
// The actual version is retained to detect real upgrades. Raw inventory is
// NOT modified: only the tracked comparison map is normalized.
var mysqlDatedStartupNoteRE = regexp.MustCompile(`(?i)^\s*(?:[0-9]{6}\s+[0-9]{1,2}:[0-9]{2}:[0-9]{2}|[0-9]{4}-[0-9]{2}-[0-9]{2}[ T][0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?(?:Z|[+-][0-9]{2}:?[0-9]{2})?)\s+\[Note\]\s+.*\b(?:mysqld|mariadbd)\b`)
var mysqlDatedNoteRE = regexp.MustCompile(`(?i)^\s*(?:[0-9]{6}\s+[0-9]{1,2}:[0-9]{2}:[0-9]{2}|[0-9]{4}-[0-9]{2}-[0-9]{2}[ T][0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?(?:Z|[+-][0-9]{2}:?[0-9]{2})?)\s+\[Note\]\s+`)
var mysqlProcessStartedRE = regexp.MustCompile(`(?i)\((?:mysqld|mariadbd)\s+([0-9]+(?:\.[0-9]+){2,5}(?:[-+][a-z0-9._-]+)?)\)\s+starting as process\s+[0-9]+(?:\b|$)`)

// normalizeMySQLDatedNotes returns a normalized version and true only when
// the source is a dated MySQL/MariaDB note. A note without a trustworthy
// version is omitted from comparison rather than treated as a software upgrade.
// If a real version line accompanies the note, prefer that line.
func normalizeMySQLDatedNotes(raw string) (string, bool) {
	lines := strings.Split(strings.ReplaceAll(strings.ReplaceAll(raw, "\r\n", "\n"), "\r", "\n"), "\n")
	clean := make([]string, 0, len(lines))
	version := ""
	detected := false
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if mysqlDatedNoteRE.MatchString(line) {
			detected = true
			if mysqlDatedStartupNoteRE.MatchString(line) {
				if match := mysqlProcessStartedRE.FindStringSubmatch(line); len(match) == 2 {
					if version != "" && version != match[1] {
						// Conflicting versions in a probe are not normalized.
						return raw, false
					}
					version = match[1]
				}
			}
			continue
		}
		clean = append(clean, line)
	}
	if !detected {
		return raw, false
	}
	if len(clean) > 0 {
		return strings.Join(clean, " "), true
	}
	return version, true
}

func isMySQLDatabaseVersion(value map[string]any) bool {
	engine := strings.ToLower(strings.TrimSpace(first(value, "engine")))
	return engine == "mysql" || engine == "mariadb"
}

// A warning-only version is not a real version. The existing service
// normalization handles mixed warning lines and keeps any valid prefix.
func normalizeTrackedVersionField(value map[string]any, field string) {
	raw, ok := value[field].(string)
	if !ok {
		return
	}
	raw = strings.TrimSpace(raw)
	if raw == "" {
		delete(value, field)
		return
	}
	if field == "version" && isMySQLDatabaseVersion(value) {
		if normalized, handled := normalizeMySQLDatedNotes(raw); handled {
			raw = strings.TrimSpace(normalized)
			if raw == "" {
				delete(value, field)
				return
			}
		}
	}
	if versionDiagnosticRE.MatchString(raw) {
		lines := strings.Split(strings.ReplaceAll(strings.ReplaceAll(raw, "\r\n", "\n"), "\r", "\n"), "\n")
		clean := make([]string, 0, len(lines))
		for _, line := range lines {
			line = strings.TrimSpace(line)
			if line == "" {
				continue
			}
			if m := versionDiagnosticRE.FindStringIndex(line); m != nil {
				if prefix := strings.TrimSpace(line[:m[0]]); versionOnlyPrefixRE.MatchString(prefix) {
					clean = append(clean, prefix)
				}
				continue
			}
			clean = append(clean, line)
		}
		if len(clean) == 0 {
			delete(value, field)
		} else {
			value[field] = strings.Join(clean, " ")
		}
		return
	}
	value[field] = raw
}

// Incomplete/diagnostic version probes must not create a false change when
// an otherwise identical service or DB instance reports a version on one
// collection and no usable version on another. Two valid versions ARE compared.
func trackedObjectsEqual(oldObj, newObj trackedObject) bool {
	if oldObj.Category != newObj.Category || oldObj.Type != newObj.Type {
		return false
	}
	if oldObj.Type != "database_instance" && oldObj.Type != "service" {
		return canonicalEqual(oldObj.Value, newObj.Value)
	}
	oldValue, oldOK := oldObj.Value.(map[string]any)
	newValue, newOK := newObj.Value.(map[string]any)
	if !oldOK || !newOK {
		return canonicalEqual(oldObj.Value, newObj.Value)
	}
	a, b := make(map[string]any, len(oldValue)), make(map[string]any, len(newValue))
	for k, v := range oldValue {
		a[k] = v
	}
	for k, v := range newValue {
		b[k] = v
	}
	for _, field := range []string{"version", "package_version"} {
		if _, ok := a[field]; !ok {
			delete(b, field)
		}
		if _, ok := b[field]; !ok {
			delete(a, field)
		}
	}
	return canonicalEqual(a, b)
}
