# Upgrade VM-DOC Server 0.21.70 → 0.21.71

1. Fă backup recuperabil al binarului, al configurației și al MariaDB; testează schimbarea pe staging.
2. Aplică fie `vm-doc-server-0.21.70-to-0.21.71.patch`, fie `vm-doc-server-0.21.71-update.tar.gz` peste sursele **0.21.70**, nu ambele. Sau folosește sursele complete.
3. În mediul offline, folosește `vendor/` și execută `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off go build -o vm-doc-server ./cmd/vm-doc-server` (adaptează dacă serviciul folosește alt binar). **Fișierele livrate sunt surse, nu binar Go gata compilat.**
4. Oprește serviciul, înlocuiește binarul, pornește-l și confirmă versiunea 0.21.71. Nu există migrare DB nouă și nu este nevoie de update agent (rămâne 1.7.18).
5. Verifică două colectări succesive pe un Ubuntu cu `systemd-fsck@...` și `systemd-fsckd.service`: aceste unități trebuie să rămână în inventarul brut, fără adăugări în `inventory_changes`. Testează și un serviciu de aplicație real, care trebuie să rămână monitorizat.
6. **Istoric:** `scripts/preview-systemd-fsck-noise-02171.sql` afișează exclusiv înregistrările nerevizuite ale familiei systemd-fsck. Verifică rezultatele pe copia DB staging; apoi, doar cu backup verificat și server/writeri opriți, execută manual `scripts/cleanup-systemd-fsck-noise-02171.sql`. Nu șterge `inventory_snapshots` și nu atinge evenimente revizuite sau cu decizii/observații.
7. Rollback: restaurează binarul 0.21.70. Fără migrare reversibilă; reapar evenimentele fsck noi. Ștergerile SQL efectuate se inversează doar prin restaurarea backupului.

**Compromis asumat:** actualizările pachetului systemd nu se mai înregistrează *prin fiecare unitate fsck*, dar actualizări reale ale altor servicii (inclusiv alte unități systemd) pot fi detectate. Nu se elimină statusul de integritate al discurilor din inventarul brut; aplicația nu trebuie considerată sistem de monitorizare fsck.

**Limitări:** SQL-ul nu a fost executat pe MariaDB live și build-ul complet offline nu a fost validat aici; ambele trebuie validate în staging.
