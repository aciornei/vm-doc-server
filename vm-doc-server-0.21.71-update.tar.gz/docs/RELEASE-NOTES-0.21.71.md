# VM-DOC Server 0.21.71 — systemd-fsck noise

## Observație
La upgrade Ubuntu `systemd 255.4-1ubuntu8.17 → 255.4-1ubuntu8.18`, istoricul Modificări înregistrează câte un eveniment `version`/`package_version` pentru `systemd-fsck@dev-disk-by\x2duuid-....service`, `systemd-fsckd.service` și alte instanțe per disc. Actualizarea pachetului poate fi reală, dar este repetitivă pentru documentația VM.

## Fix
- La `extractTracked`, doar unitățile systemd-fsck recunoscute strict (`fsck`, `fsckd`, `fsck-root`, `fsck-usr`, `fsck@...`) sunt omise din comparația istorică, inclusiv adăugări/ștergeri/modificări.
- Alte servicii Linux/Windows și `systemd-journald` rămân monitorizate. Inventarele brute, rapoartele de OS și interfața de servicii rămân neschimbate.
- SQL PREVIEW/CLEANUP țintit pentru evenimente istorice nerevizuite; se execută manual. Fără migrare DB, API sau agent nou (1.7.18).

## Teste
Teste Go: pozitiv pentru serviciile din captură, negativ pentru alte servicii, comparație de snapshoturi cu pachete vechi/noi, confirmare că evenimentele reale pentru PostgreSQL/journald rămân vizibile. Build complet și MariaDB staging încă necesare.
