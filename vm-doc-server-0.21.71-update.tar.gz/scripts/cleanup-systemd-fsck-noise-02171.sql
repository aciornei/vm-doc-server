-- DANGER: ștergere fizică manuală a schimbărilor deja existente.
-- NU este migrare; nu se execută automat la update. Rulează pe copia
-- MariaDB staging după PREVIEW; backup recuperabil, serverul și writerii opriți.
-- Pentru undo după COMMIT este necesară restaurarea backupului.
-- VM-DOC 0.21.71: curățare istoric STRICT pentru familia systemd-fsck.
-- Ex.: systemd-fsckd.service, systemd-fsck@dev-disk-by\x2duuid-...service,
-- systemd-fsck-root.service și systemd-fsck-usr.service.
-- Schimbările versiunii systemd sunt reale, dar nu vrem evenimente
-- repetate pentru fiecare disk-check service din inventarul documentației.
-- Nu modifică inventory_snapshots; păstrează alte servicii și reviziile/manual notes.
-- ATENȚIE: verifică în staging MariaDB real; fă backup înainte de DELETE.
DROP TEMPORARY TABLE IF EXISTS tmp_vmdoc_fsck_02171;
CREATE TEMPORARY TABLE tmp_vmdoc_fsck_02171 (
  id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  reason VARCHAR(80) NOT NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO tmp_vmdoc_fsck_02171(id,reason)
SELECT c.id, 'systemd_fsck_unit_noise'
FROM inventory_changes c
WHERE c.category='services'
  AND c.object_type='service'
  AND c.change_type IN ('added','removed','modified')
  AND c.object_key REGEXP '^services[|]service[|]systemd-fsck(@.+|-root|-usr|d)?[.]service$'
  AND c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL AND c.reviewed_by IS NULL
  AND COALESCE(TRIM(c.notes),'')='';

SELECT COUNT(*) AS candidates_before_delete FROM tmp_vmdoc_fsck_02171;
START TRANSACTION;
DELETE c FROM inventory_changes c
INNER JOIN tmp_vmdoc_fsck_02171 t ON t.id=c.id
WHERE c.category='services'
  AND c.object_type='service'
  AND c.change_type IN ('added','removed','modified')
  AND c.object_key REGEXP '^services[|]service[|]systemd-fsck(@.+|-root|-usr|d)?[.]service$'
  AND c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL AND c.reviewed_by IS NULL
  AND COALESCE(TRIM(c.notes),'')='';
SELECT ROW_COUNT() AS deleted_inventory_changes;
COMMIT;
DROP TEMPORARY TABLE tmp_vmdoc_fsck_02171;
