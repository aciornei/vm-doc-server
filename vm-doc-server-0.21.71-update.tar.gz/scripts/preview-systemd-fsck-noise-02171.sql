-- VM-DOC 0.21.71: curățare istoric STRICT pentru familia systemd-fsck.
-- Ex.: systemd-fsckd.service, systemd-fsck@dev-disk-by\x2duuid-...service,
-- systemd-fsck-root.service și systemd-fsck-usr.service.
-- Schimbările versiunii systemd sunt reale, dar nu vrem evenimente
-- repetate pentru fiecare disk-check service din inventarul documentației.
-- Nu modifică inventory_snapshots; păstrează alte servicii și reviziile/manual notes.
-- ATENȚIE: verifică în staging MariaDB real; fă backup înainte de DELETE.
DROP TEMPORARY TABLE IF EXISTS tmp_vmdoc_fsck_02171;
CREATE TEMPORARY TABLE tmp_vmdoc_fsck_02171 (
  id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  reason VARCHAR(80) NOT NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO tmp_vmdoc_fsck_02171(id,reason)
SELECT c.id, 'systemd_fsck_unit_noise'
FROM inventory_changes c
WHERE c.category='services'
  AND c.object_type='service'
  AND c.change_type IN ('added','removed','modified')
  AND c.object_key REGEXP '^services[|]service[|]systemd-fsck(@.+|-root|-usr|d)?[.]service$'
  AND c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL AND c.reviewed_by IS NULL
  AND COALESCE(TRIM(c.notes),'')='';

SELECT DATABASE() AS database_name;
SELECT reason, COUNT(*) AS candidate_rows FROM tmp_vmdoc_fsck_02171 GROUP BY reason;
SELECT c.change_type, COUNT(*) AS candidate_rows
FROM inventory_changes c JOIN tmp_vmdoc_fsck_02171 t ON t.id=c.id
GROUP BY c.change_type ORDER BY c.change_type;
SELECT COUNT(*) AS total_candidates FROM tmp_vmdoc_fsck_02171;
SELECT c.id,c.vm_id,c.occurred_at,c.change_type,c.object_key,c.object_label,
  JSON_UNQUOTE(JSON_EXTRACT(CASE WHEN JSON_VALID(c.old_json) THEN c.old_json ELSE '{}' END,'$.package_version')) AS old_package_version,
  JSON_UNQUOTE(JSON_EXTRACT(CASE WHEN JSON_VALID(c.new_json) THEN c.new_json ELSE '{}' END,'$.package_version')) AS new_package_version
FROM inventory_changes c JOIN tmp_vmdoc_fsck_02171 t ON t.id=c.id
ORDER BY c.occurred_at DESC,c.id DESC LIMIT 100;
DROP TEMPORARY TABLE tmp_vmdoc_fsck_02171;
