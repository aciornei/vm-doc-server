# Upgrade VM-DOC Server 0.20.75 → 0.20.76

0.20.76 este un patch exclusiv de UI pentru tabelele FortiGate. Elimină scroll-ul vertical intern și lasă tabelul să curgă pe toată înălțimea paginii, păstrând un singur scrollbar orizontal în partea de jos.

Nu există migrare DB. Nu este necesar Sync FortiGate. Agentul rămâne **1.7.12**.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.75 /usr/local/src/vm-doc-server-0.20.76
tar -xzf vm-doc-server-0.20.76-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.76
cd /usr/local/src/vm-doc-server-0.20.76
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi restart server și **Ctrl+F5** în browser.

## Verificare

1. VM → Securitate → Firewall: tabelul trebuie să curgă normal pe verticală, fără scrollbar vertical intern.
2. La finalul tabelului trebuie să existe un singur scrollbar orizontal, mai gros și ușor de folosit.
3. Securitate → Firewall → Caută și Analiză Forti trebuie să aibă același comportament.
