# Upgrade VM-DOC Server 0.20.95 → 0.20.96

Nu există migrare DB și nu este necesar update de agent.

După upgrade și restart, fă `Ctrl+F5` în browser. În **Agenți → Listare agenți** apar filtrele **Power VM** și **Stare VM**. `Status=Offline` reprezintă acum numai agenții care ar trebui să fie online; VM-urile `POWERED_OFF`/retired sunt separate.
