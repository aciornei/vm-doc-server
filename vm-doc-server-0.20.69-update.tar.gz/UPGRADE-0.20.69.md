# Upgrade VM-DOC Server 0.20.68 → 0.20.69

0.20.69 este un hotfix pentru migrarea FortiGate 069. Dacă 0.20.68 a adăugat `disabled_policy_count` dar nu a reușit să înregistreze migrarea, serverul se oprea la următorul startup cu `Duplicate column name disabled_policy_count`.

Nu șterge coloana și nu modifica manual `schema_migrations` dacă aplici acest hotfix. Migrarea 069 din 0.20.69 este retry-safe și continuă automat de unde a rămas.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.68 /usr/local/src/vm-doc-server-0.20.69
tar -xzf vm-doc-server-0.20.69-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.69
cd /usr/local/src/vm-doc-server-0.20.69
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server`. La startup, migrarea `069_fortigate_ignore_disabled_policies.up.sql` va folosi `IF NOT EXISTS` pentru coloana și indexul deja create și va continua curățarea policy-urilor disabled.

După pornire rulează un Sync FortiGate manual și verifică **Policies active**, **Disabled ignorate** și **Corelări**.

Agentul nu trebuie actualizat: `vm-doc-agent 1.7.12` rămâne recomandat.
