-- 0.20.68/0.20.69 hotfix: FortiGate security inventory keeps only active policies.
-- IMPORTANT: MariaDB DDL commits implicitly. This migration is intentionally
-- retry-safe because a previous 0.20.68 startup may have added the column and
-- stopped before schema_migrations was recorded.

ALTER TABLE fortigate_sync_runs
  ADD COLUMN IF NOT EXISTS disabled_policy_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER policy_count;

CREATE INDEX IF NOT EXISTS idx_fortigate_policy_status
  ON fortigate_policies (status,source_id,vdom,policy_id);

DELETE m
FROM fortigate_vm_matches m
JOIN fortigate_policies p
  ON p.source_id=m.source_id AND p.vdom=m.vdom AND p.policy_id=m.policy_id
WHERE LOWER(TRIM(p.status)) IN ('disable','disabled','off','false','0');

DELETE FROM fortigate_policies
WHERE LOWER(TRIM(status)) IN ('disable','disabled','off','false','0');
