# Upgrade VM-DOC Server 0.20.16 → 0.20.17

Versiunea 0.20.17 adaugă sortare generică la click pentru tabelele din interfața web.

## Fișiere modificate

- `VERSION`
- `CHANGELOG.md`
- `web/static/js/app.js`
- `web/static/css/app.css`

## Migrare DB

Nu există migrare SQL pentru această versiune.

## Instalare

Peste arborele sursă 0.20.16:

```bash
cd /usr/local/src/vm-doc-server-0.20.16

tar -xzf /cale/vm-doc-server-0.20.17-update.tar.gz
```

Dacă păstrezi fiecare versiune într-un director separat:

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.16 vm-doc-server-0.20.17
tar -xzf /cale/vm-doc-server-0.20.17-update.tar.gz -C vm-doc-server-0.20.17
cd vm-doc-server-0.20.17
```

Apoi verifică/build:

```bash
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Nu este necesară actualizarea agentului VM-DOC.

## Comportament UI

- Click pe un antet: sortare crescătoare.
- Al doilea click: sortare descrescătoare.
- Enter/Space pe antet produce același efect.
- Coloanele de acțiuni/checkbox nu sunt sortabile.
- La tabele paginate, sortarea este locală paginii afișate.
