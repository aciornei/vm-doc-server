-- 0.20.54: permite ascunderea porturilor ascultate pentru VM-uri zgomotoase (ex. AD/DNS).
-- Marcajul este per VM si exclude porturile atat din interfata, cat si din fisele/documentatia VM.

ALTER TABLE virtual_machines
  ADD COLUMN IF NOT EXISTS hide_listening_ports TINYINT(1) NOT NULL DEFAULT 0 AFTER vault_url;

CREATE INDEX IF NOT EXISTS idx_vm_hide_listening_ports ON virtual_machines(hide_listening_ports);
