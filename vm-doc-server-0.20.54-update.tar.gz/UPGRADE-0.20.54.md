# Upgrade vm-doc-server 0.20.53 → 0.20.54

## Ce se schimbă

Versiunea 0.20.54 adaugă o opțiune per VM pentru ascunderea porturilor ascultate din interfață și documentație și rafinează pagina de publicare Outline.

Pentru servere precum AD/DNS, unde agentul poate detecta foarte multe porturi RPC dinamice, mergi la:

**VM → Configurare → Infrastructură → Porturi ascultate**

și bifează **Ascunde porturile ascultate**.

Setarea nu șterge inventarul colectat. Cât timp este activă:
- secțiunea Porturi ascultate nu mai este afișată în interfața VM;
- porturile/procesele principale sunt ascunse;
- secțiunea nu mai intră în fișa/documentația VM;
- JSON-ul brut deschis din fișa VM nu mai expune collectorul `listening_ports`;
- criteriul de completare Port / proces principal este exceptat.

În **Documente → Publică în Outline**:
- VM-urile sunt pe primul rând complet;
- Serviciile sunt pe al doilea rând complet;
- rezultatul verificării serviciilor are carduri clicabile, paginare și Export Excel filtrat.

Include migrarea DB `065_vm_hide_listening_ports.up.sql`. Nu este necesar update de agent.

## Upgrade

```bash
cp -a /usr/local/src/vm-doc-server-0.20.53 /usr/local/src/vm-doc-server-0.20.54
tar -xzf vm-doc-server-0.20.54-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.54
cd /usr/local/src/vm-doc-server-0.20.54

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server`. Migrarea 065 se aplică la pornire. Apoi fă `Ctrl+F5` în browser.

## Verificare

1. Deschide unul dintre VM-urile AD/DNS și mergi la **Configurare → Infrastructură → Porturi ascultate**.
2. Bifează **Ascunde porturile ascultate** și salvează.
3. Verifică în **Inventar** că secțiunea Porturi ascultate nu mai este afișată.
4. Generează o fișă VM și confirmă că porturile ascultate / porturile principale nu mai sunt incluse.
5. Deschide **Documente → Publică în Outline** și verifică cele două rânduri separate.
6. Rulează **Verifică serviciile**, apasă pe carduri, schimbă pagina și testează **Export Excel**.
