package server

import (
	"encoding/json"
	"strings"

	"vm-doc-server/internal/inventory"
)

func withoutListeningPorts(view inventory.DocumentView) inventory.DocumentView {
	filtered := view
	filtered.Sections = make([]inventory.DocumentSection, 0, len(view.Sections))
	for _, section := range view.Sections {
		if strings.EqualFold(strings.TrimSpace(section.Key), "listening_ports") {
			continue
		}
		filtered.Sections = append(filtered.Sections, section)
	}
	return filtered
}

// withoutRawListeningPorts keeps the diagnostic raw-inventory view aligned with
// the VM visibility policy. It deliberately removes only the top-level
// listening_ports collector; all other raw inventory data remains untouched.
func withoutRawListeningPorts(raw []byte) []byte {
	if len(raw) == 0 {
		return raw
	}
	var value map[string]json.RawMessage
	if err := json.Unmarshal(raw, &value); err != nil {
		return raw
	}
	changed := false
	for key := range value {
		normalized := strings.ToLower(strings.TrimSpace(key))
		normalized = strings.ReplaceAll(normalized, "-", "_")
		normalized = strings.ReplaceAll(normalized, " ", "_")
		if normalized == "listening_ports" || normalized == "listeningports" {
			delete(value, key)
			changed = true
		}
	}
	if !changed {
		return raw
	}
	filtered, err := json.Marshal(value)
	if err != nil {
		return raw
	}
	return filtered
}
