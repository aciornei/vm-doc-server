package server

import "testing"

func TestOutlineServicePreviewFilterMatches(t *testing.T) {
	tests := []struct {
		name   string
		row    outlineServicePreviewRow
		filter string
		want   bool
	}{
		{"all", outlineServicePreviewRow{ReasonCode: "missing_link"}, "", true},
		{"eligible", outlineServicePreviewRow{Eligible: true, ReasonCode: "eligible"}, "eligible", true},
		{"eligible-no", outlineServicePreviewRow{Eligible: false}, "eligible", false},
		{"missing-link", outlineServicePreviewRow{ReasonCode: "missing_link"}, "missing_link", true},
		{"outline-disabled", outlineServicePreviewRow{ReasonCode: "outline_disabled"}, "outline_disabled", true},
		{"inactive", outlineServicePreviewRow{ReasonCode: "inactive"}, "inactive_or_retired", true},
		{"retired", outlineServicePreviewRow{ReasonCode: "retired"}, "inactive_or_retired", true},
		{"link-error", outlineServicePreviewRow{ReasonCode: "link_error"}, "link_error", true},
		{"content-error", outlineServicePreviewRow{ReasonCode: "content_error"}, "content_error", true},
		{"different", outlineServicePreviewRow{ReasonCode: "missing_link"}, "link_error", false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := outlineServicePreviewFilterMatches(tt.row, tt.filter); got != tt.want {
				t.Fatalf("got %v, want %v", got, tt.want)
			}
		})
	}
}
