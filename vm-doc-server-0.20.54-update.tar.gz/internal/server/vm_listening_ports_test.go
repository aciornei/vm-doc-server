package server

import (
	"encoding/json"
	"testing"

	"vm-doc-server/internal/inventory"
)

func TestWithoutRawListeningPorts(t *testing.T) {
	raw := []byte(`{"system":{"hostname":"dc01"},"listening_ports":[{"port":49152}],"network":{"interfaces":[]}}`)
	filtered := withoutRawListeningPorts(raw)
	var value map[string]json.RawMessage
	if err := json.Unmarshal(filtered, &value); err != nil {
		t.Fatalf("filtered JSON is invalid: %v", err)
	}
	if _, ok := value["listening_ports"]; ok {
		t.Fatal("listening_ports must be removed")
	}
	if _, ok := value["system"]; !ok {
		t.Fatal("system must be preserved")
	}
	if _, ok := value["network"]; !ok {
		t.Fatal("network must be preserved")
	}
}

func TestWithoutRawListeningPortsLeavesInvalidJSONUntouched(t *testing.T) {
	raw := []byte(`not-json`)
	if got := string(withoutRawListeningPorts(raw)); got != string(raw) {
		t.Fatalf("invalid JSON must remain untouched: %q", got)
	}
}

func TestWithoutListeningPortsRemovesSection(t *testing.T) {
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{
		{Key: "system", Label: "Sistem"},
		{Key: "listening_ports", Label: "Porturi ascultate"},
		{Key: "network", Label: "Rețea"},
	}}
	filtered := withoutListeningPorts(view)
	if len(filtered.Sections) != 2 {
		t.Fatalf("expected 2 sections, got %d", len(filtered.Sections))
	}
	for _, section := range filtered.Sections {
		if section.Key == "listening_ports" {
			t.Fatal("listening_ports section must be removed")
		}
	}
}
