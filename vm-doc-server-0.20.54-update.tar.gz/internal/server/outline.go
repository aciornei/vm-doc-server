package server

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/documents"
	outlineapi "vm-doc-server/internal/outline"
	"vm-doc-server/internal/xlsx"
)

type outlineBulkInput struct {
	PoweredOnOnly bool `json:"powered_on_only"`
}

type outlineServiceBulkInput struct {
	ServiceIDs []int64 `json:"service_ids"`
}

type outlineServicePreviewRow struct {
	ID                           int64  `json:"id"`
	Name                         string `json:"name"`
	Active                       bool   `json:"active"`
	Retired                      bool   `json:"retired"`
	OutlineDocumentationDisabled bool   `json:"outline_documentation_disabled"`
	DocumentationURL             string `json:"documentation_url,omitempty"`
	ResolvedDocumentID           string `json:"resolved_document_id,omitempty"`
	ResolvedURL                  string `json:"resolved_url,omitempty"`
	Eligible                     bool   `json:"eligible"`
	ReasonCode                   string `json:"reason_code"`
	Reason                       string `json:"reason"`
}

type outlineServicePreview struct {
	GeneratedAt       time.Time                  `json:"generated_at"`
	Total             int                        `json:"total"`
	Eligible          int                        `json:"eligible"`
	MissingLink       int                        `json:"missing_link"`
	ExcludedOutline   int                        `json:"excluded_outline"`
	InactiveOrRetired int                        `json:"inactive_or_retired"`
	LinkErrors        int                        `json:"link_errors"`
	ContentErrors     int                        `json:"content_errors"`
	EligibleIDs       []int64                    `json:"eligible_ids"`
	Services          []outlineServicePreviewRow `json:"services"`
}

type outlineBulkJob struct {
	ID                string                 `json:"id"`
	Kind              string                 `json:"kind"`
	Status            string                 `json:"status"`
	StartedAt         time.Time              `json:"started_at"`
	FinishedAt        time.Time              `json:"finished_at,omitempty"`
	TotalVMs          int                    `json:"total_vms,omitempty"`
	ProcessedVMs      int                    `json:"processed_vms,omitempty"`
	PublishedVMs      int                    `json:"published_vms,omitempty"`
	SkippedVMs        int                    `json:"skipped_vms,omitempty"`
	TotalServices     int                    `json:"total_services,omitempty"`
	ProcessedServices int                    `json:"processed_services,omitempty"`
	PublishedServices int                    `json:"published_services,omitempty"`
	SkippedServices   int                    `json:"skipped_services,omitempty"`
	Errors            []string               `json:"errors,omitempty"`
	LastObject        string                 `json:"last_object,omitempty"`
	Preview           *outlineServicePreview `json:"preview,omitempty"`
}

var errVMOutlinePublicationDisabled = errors.New("VM-ul este marcat «Nu se publică în Outline»")
var errServiceOutlineRetired = errors.New("serviciul este retras și nu se publică în Outline")
var errServiceOutlineInactive = errors.New("serviciul este inactiv și nu se publică în Outline")
var errServiceOutlinePublicationDisabled = errors.New("serviciul este marcat «Nu se documentează în Outline»")
var errServiceOutlineMissingLink = errors.New("Link documentație nu este configurat pentru acest serviciu")

var outlineBulkJobs = struct {
	sync.RWMutex
	values map[string]*outlineBulkJob
}{values: map[string]*outlineBulkJob{}}

func (a *App) outlineSettings(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	value, err := a.Outline.GetSettings(r.Context())
	respond(w, value, err)
}

func (a *App) updateOutlineSettings(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	var input outlineapi.SettingsInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Outline.UpdateSettings(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "outline.settings.update", "outline_settings", "1", "success", map[string]any{
			"enabled":                           value.Enabled,
			"base_url":                          value.BaseURL,
			"collection_id":                     value.CollectionID,
			"virtualization_parent_document_id": value.VirtualizationParentDocumentID,
			"verify_tls":                        value.VerifyTLS,
			"allow_http":                        value.AllowHTTP,
		})
	}
	if err != nil && a.Logger != nil {
		a.Logger.Error("Outline settings update failed", "error", err)
	}
	outlineRespond(w, value, err)
}

func (a *App) testOutline(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		outlineRespond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	settings, settingsErr := a.Outline.GetSettings(r.Context())
	if settingsErr != nil {
		outlineRespond(w, nil, settingsErr)
		return
	}
	if !settings.Enabled {
		badRequest(w, errors.New("Integrarea Outline este dezactivată. Bifează «Activează integrarea Outline» și salvează setările înainte de test"))
		return
	}
	value, err := a.Outline.Test(r.Context())
	if err == nil {
		a.auditRequest(r, "outline.connection.test", "outline_settings", "1", "success", map[string]any{
			"parent_document_id":    value.ParentDocumentID,
			"parent_document_title": value.ParentDocumentTitle,
		})
	} else if a.Logger != nil {
		a.Logger.Error("Outline connection test failed", "error", err)
	}
	outlineRespond(w, value, err)
}

func (a *App) publishVMOutline(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.publishVMToOutline(r, vmID)
	if err == nil {
		a.auditRequest(r, "outline.vm.publish", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{
			"vm_id":               vmID,
			"outline_target":      "virtualization",
			"outline_document_id": result.DocumentID,
			"outline_url":         result.URL,
		})
	}
	if err != nil && a.Logger != nil {
		a.Logger.Error("Outline VM publish failed", "vm_id", vmID, "error", err)
	}
	outlineRespond(w, result, err)
}

func (a *App) outlineVMMapping(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Outline.VMMapping(r.Context(), vmID)
	if errors.Is(err, sql.ErrNoRows) {
		jsonResponse(w, http.StatusOK, map[string]any{"configured": false})
		return
	}
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, map[string]any{"configured": true, "document_id": value.DocumentID, "url": value.URL})
}

func (a *App) publishServiceOutline(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.publishServiceToOutline(r, serviceID)
	if err == nil {
		a.auditRequest(r, "outline.service.publish", "internal_service", strconv.FormatInt(serviceID, 10), "success", map[string]any{
			"service_id":          serviceID,
			"outline_document_id": result.DocumentID,
			"outline_url":         result.URL,
		})
	} else if a.Logger != nil {
		a.Logger.Error("Outline service publish failed", "service_id", serviceID, "error", err)
	}
	outlineRespond(w, result, err)
}

func (a *App) outlineServiceMapping(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Outline.ServiceMapping(r.Context(), serviceID)
	if errors.Is(err, sql.ErrNoRows) {
		jsonResponse(w, http.StatusOK, map[string]any{"configured": false})
		return
	}
	if err != nil {
		outlineRespond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, map[string]any{"configured": true, "document_id": value.DocumentID, "url": value.URL})
}

func (a *App) startOutlineBulkPublish(w http.ResponseWriter, r *http.Request) {
	var input outlineBulkInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	if _, err := a.Outline.Test(r.Context()); err != nil {
		outlineRespond(w, nil, err)
		return
	}
	now := time.Now().UTC()
	id := fmt.Sprintf("outline-%d", now.UnixNano())
	job := &outlineBulkJob{ID: id, Kind: "vm", Status: "queued", StartedAt: now}
	outlineBulkJobs.Lock()
	for existingID, existing := range outlineBulkJobs.values {
		if !existing.FinishedAt.IsZero() && now.Sub(existing.FinishedAt) > 24*time.Hour {
			delete(outlineBulkJobs.values, existingID)
		}
	}
	outlineBulkJobs.values[id] = job
	outlineBulkJobs.Unlock()

	bgRequest := r.Clone(context.WithoutCancel(r.Context()))
	go a.runOutlineBulkPublish(bgRequest, job, input)
	jsonResponse(w, http.StatusAccepted, job)
}

func (a *App) previewOutlineServiceBulkPublish(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		outlineRespond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	settings, err := a.Outline.GetSettings(r.Context())
	if err != nil {
		outlineRespond(w, nil, err)
		return
	}
	if !settings.Enabled {
		badRequest(w, errors.New("Integrarea Outline este dezactivată"))
		return
	}

	now := time.Now().UTC()
	id := fmt.Sprintf("outline-services-preview-%d", now.UnixNano())
	job := &outlineBulkJob{ID: id, Kind: "service_preview", Status: "queued", StartedAt: now}
	outlineBulkJobs.Lock()
	for existingID, existing := range outlineBulkJobs.values {
		if !existing.FinishedAt.IsZero() && now.Sub(existing.FinishedAt) > 24*time.Hour {
			delete(outlineBulkJobs.values, existingID)
		}
	}
	outlineBulkJobs.values[id] = job
	outlineBulkJobs.Unlock()

	bgRequest := r.Clone(context.WithoutCancel(r.Context()))
	go a.runOutlineServiceBulkPreview(bgRequest, job)
	jsonResponse(w, http.StatusAccepted, job)
}

func (a *App) runOutlineServiceBulkPreview(r *http.Request, job *outlineBulkJob) {
	update := func(fn func(*outlineBulkJob)) {
		outlineBulkJobs.Lock()
		fn(job)
		outlineBulkJobs.Unlock()
	}
	fail := func(err error) {
		update(func(j *outlineBulkJob) {
			j.Status = "failed"
			j.FinishedAt = time.Now().UTC()
			j.LastObject = ""
			j.Errors = append(j.Errors, err.Error())
		})
	}

	update(func(j *outlineBulkJob) { j.Status = "running" })
	if _, err := a.Outline.Test(r.Context()); err != nil {
		fail(err)
		return
	}
	items, err := a.Catalog.List(r.Context(), true)
	if err != nil {
		fail(err)
		return
	}
	update(func(j *outlineBulkJob) { j.TotalServices = len(items) })

	result := outlineServicePreview{
		GeneratedAt: time.Now().UTC(),
		Total:       len(items),
		EligibleIDs: []int64{},
		Services:    make([]outlineServicePreviewRow, 0, len(items)),
	}
	for _, item := range items {
		update(func(j *outlineBulkJob) { j.LastObject = item.Name })
		row := outlineServicePreviewRow{
			ID:                           item.ID,
			Name:                         item.Name,
			Active:                       item.Active,
			Retired:                      item.Retired,
			OutlineDocumentationDisabled: item.OutlineDocumentationDisabled,
			DocumentationURL:             strings.TrimSpace(item.DocumentationURL),
		}
		switch {
		case item.Retired:
			row.ReasonCode = "retired"
			row.Reason = "Serviciu retras / scos din uz"
			result.InactiveOrRetired++
		case !item.Active:
			row.ReasonCode = "inactive"
			row.Reason = "Serviciu inactiv"
			result.InactiveOrRetired++
		case item.OutlineDocumentationDisabled:
			row.ReasonCode = "outline_disabled"
			row.Reason = "Bifat «Nu se documentează în Outline»"
			result.ExcludedOutline++
		case row.DocumentationURL == "":
			row.ReasonCode = "missing_link"
			row.Reason = "Lipsește Link documentație"
			result.MissingLink++
		default:
			resolved, resolveErr := a.Outline.ResolveDocument(r.Context(), row.DocumentationURL)
			if resolveErr != nil {
				row.ReasonCode = "link_error"
				row.Reason = "Link Outline invalid/inaccesibil: " + resolveErr.Error()
				result.LinkErrors++
				break
			}
			row.ResolvedDocumentID = resolved.ID
			row.ResolvedURL = resolved.URL
			if _, _, contentErr := a.buildServiceOutlineMarkdown(r, item.ID); contentErr != nil {
				row.ReasonCode = "content_error"
				row.Reason = "Conținutul nu poate fi generat: " + contentErr.Error()
				result.ContentErrors++
				break
			}
			row.Eligible = true
			row.ReasonCode = "eligible"
			row.Reason = "Eligibil pentru publicare"
			result.Eligible++
			result.EligibleIDs = append(result.EligibleIDs, item.ID)
		}
		result.Services = append(result.Services, row)
		update(func(j *outlineBulkJob) { j.ProcessedServices++ })
	}

	update(func(j *outlineBulkJob) {
		j.Status = "success"
		j.FinishedAt = time.Now().UTC()
		j.LastObject = ""
		j.Preview = &result
	})
	a.auditRequest(r, "outline.service_bulk_preview", "outline", "services", "success", map[string]any{
		"total":               result.Total,
		"eligible":            result.Eligible,
		"missing_link":        result.MissingLink,
		"excluded_outline":    result.ExcludedOutline,
		"inactive_or_retired": result.InactiveOrRetired,
		"link_errors":         result.LinkErrors,
		"content_errors":      result.ContentErrors,
	})
}

func (a *App) startOutlineServiceBulkPublish(w http.ResponseWriter, r *http.Request) {
	var input outlineServiceBulkInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	input.ServiceIDs = uniquePositiveIDs(input.ServiceIDs)
	if len(input.ServiceIDs) == 0 {
		badRequest(w, errors.New("Rulează mai întâi verificarea serviciilor și selectează lista eligibilă pentru publicare"))
		return
	}
	if a.Outline == nil {
		outlineRespond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	if _, err := a.Outline.Test(r.Context()); err != nil {
		outlineRespond(w, nil, err)
		return
	}
	now := time.Now().UTC()
	id := fmt.Sprintf("outline-services-%d", now.UnixNano())
	job := &outlineBulkJob{ID: id, Kind: "service", Status: "queued", StartedAt: now, TotalServices: len(input.ServiceIDs)}
	outlineBulkJobs.Lock()
	for existingID, existing := range outlineBulkJobs.values {
		if !existing.FinishedAt.IsZero() && now.Sub(existing.FinishedAt) > 24*time.Hour {
			delete(outlineBulkJobs.values, existingID)
		}
	}
	outlineBulkJobs.values[id] = job
	outlineBulkJobs.Unlock()

	bgRequest := r.Clone(context.WithoutCancel(r.Context()))
	go a.runOutlineServiceBulkPublish(bgRequest, job, input.ServiceIDs)
	jsonResponse(w, http.StatusAccepted, job)
}

func uniquePositiveIDs(values []int64) []int64 {
	seen := make(map[int64]bool, len(values))
	result := make([]int64, 0, len(values))
	for _, value := range values {
		if value <= 0 || seen[value] {
			continue
		}
		seen[value] = true
		result = append(result, value)
	}
	return result
}

func (a *App) getOutlineBulkJob(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimSpace(r.PathValue("id"))
	outlineBulkJobs.RLock()
	job := outlineBulkJobs.values[id]
	if job == nil {
		outlineBulkJobs.RUnlock()
		respond(w, nil, sql.ErrNoRows)
		return
	}
	copy := *job
	copy.Errors = append([]string(nil), job.Errors...)
	if job.Preview != nil {
		previewCopy := *job.Preview
		previewCopy.EligibleIDs = append([]int64(nil), job.Preview.EligibleIDs...)
		previewCopy.Services = append([]outlineServicePreviewRow(nil), job.Preview.Services...)
		copy.Preview = &previewCopy
	}
	outlineBulkJobs.RUnlock()
	respond(w, copy, nil)
}

func outlineServicePreviewFilterMatches(row outlineServicePreviewRow, filter string) bool {
	switch strings.TrimSpace(filter) {
	case "eligible":
		return row.Eligible
	case "missing_link":
		return row.ReasonCode == "missing_link"
	case "outline_disabled":
		return row.ReasonCode == "outline_disabled"
	case "inactive_or_retired":
		return row.ReasonCode == "inactive" || row.ReasonCode == "retired"
	case "link_error":
		return row.ReasonCode == "link_error"
	case "content_error":
		return row.ReasonCode == "content_error"
	default:
		return true
	}
}

func (a *App) exportOutlineServicePreview(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimSpace(r.PathValue("id"))
	outlineBulkJobs.RLock()
	job := outlineBulkJobs.values[id]
	if job == nil || job.Preview == nil {
		outlineBulkJobs.RUnlock()
		respond(w, nil, sql.ErrNoRows)
		return
	}
	preview := *job.Preview
	preview.Services = append([]outlineServicePreviewRow(nil), job.Preview.Services...)
	outlineBulkJobs.RUnlock()

	filter := strings.TrimSpace(r.URL.Query().Get("filter"))
	rows := [][]xlsx.Cell{{
		xlsx.Text("Serviciu"), xlsx.Text("Stare"), xlsx.Text("Link Outline"), xlsx.Text("Publică"), xlsx.Text("Verificare"), xlsx.Text("Document Outline ID"),
	}}
	for _, item := range preview.Services {
		if !outlineServicePreviewFilterMatches(item, filter) {
			continue
		}
		state := "Activ"
		if item.Retired {
			state = "Retras"
		} else if !item.Active {
			state = "Inactiv"
		}
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(item.Name), xlsx.Text(state), xlsx.Text(item.DocumentationURL), xlsx.Text(yesNo(item.Eligible)), xlsx.Text(item.Reason), xlsx.Text(item.ResolvedDocumentID),
		})
	}
	if err := writeXLSXResponse(w, "Verificare servicii Outline", "verificare-servicii-outline", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write Outline service preview XLSX", "error", err)
	}
}

func (a *App) runOutlineBulkPublish(r *http.Request, job *outlineBulkJob, input outlineBulkInput) {
	update := func(fn func(*outlineBulkJob)) {
		outlineBulkJobs.Lock()
		fn(job)
		outlineBulkJobs.Unlock()
	}
	update(func(j *outlineBulkJob) { j.Status = "running" })
	// Deliberately load every active candidate here and enforce the Outline flag
	// explicitly below. This keeps the bulk workflow safe even if another caller
	// changes the document-export query in the future.
	items, err := a.Documents.ListBulkExportItems(r.Context(), "vm", input.PoweredOnOnly, false)
	if err != nil {
		update(func(j *outlineBulkJob) {
			j.Status = "failed"
			j.FinishedAt = time.Now().UTC()
			j.Errors = append(j.Errors, err.Error())
		})
		return
	}
	update(func(j *outlineBulkJob) { j.TotalVMs = len(items) })
	for _, item := range items {
		update(func(j *outlineBulkJob) { j.LastObject = item.ObjectName })

		disabled, checkErr := a.vmOutlinePublicationDisabled(r.Context(), item.ObjectID)
		if checkErr != nil {
			update(func(j *outlineBulkJob) {
				j.ProcessedVMs++
				j.Errors = append(j.Errors, item.ObjectName+": "+checkErr.Error())
			})
			continue
		}
		if disabled {
			update(func(j *outlineBulkJob) {
				j.ProcessedVMs++
				j.SkippedVMs++
			})
			continue
		}

		_, publishErr := a.publishVMToOutline(r, item.ObjectID)
		update(func(j *outlineBulkJob) {
			j.ProcessedVMs++
			if errors.Is(publishErr, errVMOutlinePublicationDisabled) {
				// The flag may have changed after the pre-check. Never publish it and
				// report it as skipped rather than as a failed publication.
				j.SkippedVMs++
				return
			}
			if publishErr != nil {
				j.Errors = append(j.Errors, item.ObjectName+": "+publishErr.Error())
				return
			}
			j.PublishedVMs++
		})
	}
	update(func(j *outlineBulkJob) {
		if len(j.Errors) > 0 {
			j.Status = "partial"
		} else {
			j.Status = "success"
		}
		j.FinishedAt = time.Now().UTC()
		j.LastObject = ""
	})
	a.auditRequest(r, "outline.bulk_publish", "outline", job.ID, "success", map[string]any{
		"target":          "virtualization",
		"powered_on_only": input.PoweredOnOnly,
		"vms":             job.PublishedVMs,
		"skipped_vms":     job.SkippedVMs,
		"errors":          len(job.Errors),
	})
}

func (a *App) runOutlineServiceBulkPublish(r *http.Request, job *outlineBulkJob, serviceIDs []int64) {
	update := func(fn func(*outlineBulkJob)) {
		outlineBulkJobs.Lock()
		fn(job)
		outlineBulkJobs.Unlock()
	}
	update(func(j *outlineBulkJob) {
		j.Status = "running"
		j.TotalServices = len(serviceIDs)
	})
	for _, serviceID := range serviceIDs {
		item, loadErr := a.Catalog.Get(r.Context(), serviceID)
		if loadErr != nil {
			update(func(j *outlineBulkJob) {
				j.ProcessedServices++
				j.Errors = append(j.Errors, fmt.Sprintf("serviciu %d: %v", serviceID, loadErr))
			})
			continue
		}
		update(func(j *outlineBulkJob) { j.LastObject = item.Name })
		if item.Retired || !item.Active || item.OutlineDocumentationDisabled || strings.TrimSpace(item.DocumentationURL) == "" {
			update(func(j *outlineBulkJob) {
				j.ProcessedServices++
				j.SkippedServices++
			})
			continue
		}
		_, publishErr := a.publishServiceToOutline(r, item.ID)
		update(func(j *outlineBulkJob) {
			j.ProcessedServices++
			if errors.Is(publishErr, errServiceOutlineRetired) || errors.Is(publishErr, errServiceOutlineInactive) || errors.Is(publishErr, errServiceOutlinePublicationDisabled) || errors.Is(publishErr, errServiceOutlineMissingLink) {
				j.SkippedServices++
				return
			}
			if publishErr != nil {
				j.Errors = append(j.Errors, item.Name+": "+publishErr.Error())
				return
			}
			j.PublishedServices++
		})
	}
	update(func(j *outlineBulkJob) {
		if len(j.Errors) > 0 {
			j.Status = "partial"
		} else {
			j.Status = "success"
		}
		j.FinishedAt = time.Now().UTC()
		j.LastObject = ""
	})
	a.auditRequest(r, "outline.service_bulk_publish", "outline", job.ID, "success", map[string]any{
		"requested_services": len(serviceIDs),
		"services":           job.PublishedServices,
		"skipped":            job.SkippedServices,
		"errors":             len(job.Errors),
	})
}

func (a *App) buildServiceOutlineMarkdown(r *http.Request, serviceID int64) (string, []byte, error) {
	if a.Outline == nil {
		return "", nil, errors.New("Outline integration is unavailable")
	}
	service, err := a.Catalog.Get(r.Context(), serviceID)
	if err != nil {
		return "", nil, err
	}
	if service.Retired {
		return "", nil, errServiceOutlineRetired
	}
	if !service.Active {
		return "", nil, errServiceOutlineInactive
	}
	if service.OutlineDocumentationDisabled {
		return "", nil, errServiceOutlinePublicationDisabled
	}
	documentationURL := strings.TrimSpace(service.DocumentationURL)
	if documentationURL == "" {
		return "", nil, errServiceOutlineMissingLink
	}
	_, data, err := a.serviceDocumentGenerationData(r, serviceID, templateRequest{IncludeGeneratedBy: false}, false)
	if err != nil {
		return "", nil, err
	}
	if generated, listErr := a.Documents.ListGeneratedService(r.Context(), serviceID); listErr == nil && len(generated) > 0 {
		data.DocumentNumber = generated[0].DocumentNumber
		data.GeneratedAt = generated[0].GeneratedAt
	}
	data.IncludeGeneratedBy = false
	data.OutlineMode = true
	attachments, attachmentErr := a.Catalog.ListAttachments(r.Context(), serviceID, true)
	if attachmentErr != nil {
		return "", nil, fmt.Errorf("load service supplemental documentation for Outline: %w", attachmentErr)
	}
	data.Attachments = attachments
	vmIDs := make([]int64, 0, len(data.Service.VMs))
	seen := map[int64]bool{}
	for _, vm := range data.Service.VMs {
		if vm.ID > 0 && !seen[vm.ID] {
			seen[vm.ID] = true
			vmIDs = append(vmIDs, vm.ID)
		}
	}
	data.OutlineVMURLs, err = a.Outline.VMURLs(r.Context(), vmIDs)
	if err != nil {
		return "", nil, fmt.Errorf("load Outline VM links: %w", err)
	}
	markdown := documents.RenderServiceMarkdown(data)
	if strings.TrimSpace(string(markdown)) == "" {
		return "", nil, errors.New("conținutul Markdown pentru Outline este gol")
	}
	if vaultURL := strings.TrimSpace(service.VaultURL); vaultURL != "" && strings.Contains(string(markdown), vaultURL) {
		return "", nil, errors.New("publicarea a fost blocată deoarece linkul Vault a ajuns în conținutul Outline")
	}
	return documentationURL, markdown, nil
}

func (a *App) publishServiceToOutline(r *http.Request, serviceID int64) (outlineapi.PublishResult, error) {
	documentationURL, markdown, err := a.buildServiceOutlineMarkdown(r, serviceID)
	if err != nil {
		return outlineapi.PublishResult{}, err
	}
	return a.Outline.UpdateLinkedServiceDocument(r.Context(), serviceID, documentationURL, markdown)
}

func (a *App) vmOutlinePublicationDisabled(ctx context.Context, vmID int64) (bool, error) {
	if a.DB == nil {
		return false, errors.New("database is unavailable")
	}
	var disabled bool
	err := a.DB.QueryRowContext(ctx, `SELECT COALESCE(outline_documentation_disabled,0) FROM virtual_machines WHERE id=?`, vmID).Scan(&disabled)
	if err != nil {
		return false, err
	}
	return disabled, nil
}

func (a *App) publishVMToOutline(r *http.Request, vmID int64) (outlineapi.PublishResult, error) {
	if a.Outline == nil {
		return outlineapi.PublishResult{}, errors.New("Outline integration is unavailable")
	}
	disabled, err := a.vmOutlinePublicationDisabled(r.Context(), vmID)
	if err != nil {
		return outlineapi.PublishResult{}, err
	}
	if disabled {
		return outlineapi.PublishResult{}, errVMOutlinePublicationDisabled
	}
	data, err := a.buildVMGenerationData(r, vmID)
	if err != nil {
		return outlineapi.PublishResult{}, err
	}
	if data.VM.OutlineDocumentationDisabled {
		return outlineapi.PublishResult{}, errVMOutlinePublicationDisabled
	}
	if generated, listErr := a.Documents.ListGeneratedVM(r.Context(), vmID); listErr == nil && len(generated) > 0 {
		data.DocumentNumber = generated[0].DocumentNumber
		data.GeneratedAt = generated[0].GeneratedAt
	}
	data.IncludeGeneratedBy = false
	data.OutlineMode = true
	serviceIDs := make([]int64, 0, len(data.Operational.ServiceAssignments))
	seenServices := map[int64]bool{}
	for _, assignment := range data.Operational.ServiceAssignments {
		if assignment.InternalServiceID > 0 && !seenServices[assignment.InternalServiceID] {
			seenServices[assignment.InternalServiceID] = true
			serviceIDs = append(serviceIDs, assignment.InternalServiceID)
		}
	}
	data.OutlineServiceURLs, err = a.Outline.ServiceOutlineURLs(r.Context(), serviceIDs)
	if err != nil {
		return outlineapi.PublishResult{}, fmt.Errorf("load Outline service links: %w", err)
	}
	markdown := documents.RenderVMMarkdown(data)
	title := firstServerNonEmpty(data.VM.Name, data.VM.GuestHostname, fmt.Sprintf("VM %d", vmID))
	return a.Outline.UpsertVMDocument(r.Context(), vmID, title, markdown)
}

func outlineRespond(w http.ResponseWriter, value any, err error) {
	if err == nil {
		jsonResponse(w, http.StatusOK, value)
		return
	}
	if status, message, ok := outlineapi.RemoteErrorDetails(err); ok {
		if status < 400 || status > 599 {
			status = http.StatusBadGateway
		}
		jsonResponse(w, status, map[string]any{"error": "outline_error", "message": message})
		return
	}
	lower := strings.ToLower(err.Error())
	if strings.Contains(lower, "disabled") || strings.Contains(lower, "not configured") || strings.Contains(lower, "link documentație") || strings.Contains(lower, "outline document") || strings.Contains(lower, "outline instance") || strings.Contains(lower, "serviciul este retras") || strings.Contains(lower, "serviciul este inactiv") {
		badRequest(w, err)
		return
	}
	respond(w, value, err)
}
