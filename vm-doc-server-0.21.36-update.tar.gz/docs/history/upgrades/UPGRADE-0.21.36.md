# VM-DOC Server 0.21.36 — 16 octombrie 2026

**Bază:** 0.21.35. **Agent:** 1.7.18 (neschimbat). **SQL:** fără migrare nouă. **Necesită rebuild server Go:** DA (API + XLSX).

## Database Access: UI

- Fiecare instanță are taburile proprii: **Users / Roles**, **Grants** și, **numai pentru PostgreSQL**, **Conectare / HBA**.
- Butonul **Revizuiește secțiunea** este în interiorul fiecărui tab, independent pentru Users, Grants și HBA. Nu mai apare la „Toate instanțele DB”. Revizuirile individuale rămân.
- PostgreSQL Grants este grupat în principal (`principal + host`), nu separat pe SELECT, DELETE, INSERT etc. În fiecare principal: privilegii, baze/schema/scope, obiecte și surse tehnice. Un grup este încărcat doar când se extinde; obiectele individuale se încarcă în loturi de 200.
- Nu se elimină/simplifică auditabil drepturi de tip DENY / GRANT OPTION. Niciun grant nu este trunchiat în export.
- Pentru HBA, `all` în coloana Database înseamnă toate bazele; `all` în coloana User înseamnă toți utilizatorii. Nu înseamnă automat toate IP-urile. `md5` este metoda de autentificare cu parolă, care poate negocia SCRAM în funcție de tipul hash-ului stocat. UI nu mai repetă `md5` sau `all/all` în descrierea warning; păstrează Type, Address, Source file și Line. Prima regulă HBA aplicabilă este decisivă.

## Model revizii (fără migrare DB)

- `database_principal`: vechea revizie individuală din **Users**; cheia stabilă per instanță + nume/host/bază; neschimbată.
- `database_grants`: cheie per **instanță + principal + host**, nu per fiecare rând de grant. Un review al grupului acoperă întregul set curent de granturi al utilizatorului. Modificarea inventarului trebuie revalidată operațional după resync; sistemul nu anulează automat o revizie pentru un privilegiu nou.
- `database_hba`: cheie per **instanță + regulă concretă**, inclusiv fișier sursă, linie și condițiile Type/Database/User/Address/Method/Options. Mutarea regulii în fișier poate produce o nouă cheie și necesită revizie nouă, intenționat pentru trasabilitate.
- `PUT /api/v1/security/review/bulk` acceptă în plus `database_grants` și `database_hba`, cu `instance_id` obligatoriu pentru aceste categorii. Enumerarea țintelor și tranzacția se execută server-side. Sunt păstrate validarea identității, RBAC `vms.manage`, CSRF, 6/12 luni, justificare, observații obligatorii, confirmare de suprascriere și audit. User/grants/HBA nu sunt revizuite implicit împreună.
- Calendarul reviziilor primește intrări distincte pentru Users/Grants/HBA. Rezumatul `database_due` include și noile categorii.

## Excel

- Buton **Export Excel** în locul Revizuiește secțiunea la Toate instanțele DB: `GET /api/v1/security/databases/export`.
- `GET /api/v1/security/databases/export?vm_id=<ID>` exportă doar VM respectivă din fișa sa.
- Workbook cu **Users** obligatoriu, **Grants** dacă există granturi și **HBA** numai dacă există reguli PostgreSQL. Până la 3 sheet-uri. Include toate instanțele eligibile, nu doar pagina/filtrul vizual din browser.
- Granturile sunt exportate individual cu obiect, schemă, scope, privilege, grant option, source și revizia grupului per principal; regula HBA include address, source file:line, review.

## Upgrade offline din 0.21.35

1. Backup MariaDB, directorul server (în special config/secrets) și binarul/sursele 0.21.35. Pentru rollback după revizii colective este util un backup consistent al `security_reviews`.
2. În **copia surselor 0.21.35**, din rădăcina proiectului: `tar -xzf vm-doc-server-0.21.36-update.tar.gz` (fără să înlocuiești `vendor/`, configurația sau datele).
3. Verifică `cat VERSION` = `0.21.36`; `bash scripts/cleanup-source-tree.sh --check`.
4. În mediul offline care deține vendor: `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off make build`. Oprește dacă există erori.
5. Staging: API security, roluri DB, granturi 20.000+, HBA/MD5 și xlsx cu 1/2/3 worksheet-uri, RBAC+CSRF, tranzacția bulk și audit, navigarea între taburi, browser 1595/1024/390.
6. Promovează binarul validat și fă hard refresh în browser.

**Rollback:** restaurează 0.21.35 sursele/binarul (nu necesită rollback de schemă). Noile review-uri `database_grants` / `database_hba` pot rămâne în SQL, dar UI 0.21.35 nu le afișează. Pentru rollback complet al *deciziilor* de review, folosește backupul `security_reviews` realizat înainte de update.

## Ce a fost verificat în această sesiune

- `node --check web/static/js/app.js`: OK.
- 20.000 granturi / 40 utilizatori: test JS al grupării și randării fără obiecte expandate: OK.
- Chromium simulated la 1595/1024/390, deschidere Grants, extindere utilizator, încărcare per subgrup de maximum 200 rânduri, navigare HBA: OK.
- `go test ./internal/xlsx ./internal/domain ./internal/buildinfo ./web ./migrations ./openapi` cu `GOPROXY=off`: OK.
- OpenAPI YAML parsabil, rute/versiune sincronizate: OK.
- Build `go test ./internal/server` și `make build` cu dependențe complete: **NEVERIFICATE** deoarece mediul local nu deține module Go externe (`vendor/`).
- **MariaDB reală, export XLSX E2E cu 20k granturi, endpoint review bulk E2E, autentificare/RBAC și audit: NECONFIRMATE.**
