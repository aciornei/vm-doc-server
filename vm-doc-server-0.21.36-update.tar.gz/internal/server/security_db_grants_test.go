package server

import (
	"strings"
	"testing"
)

func TestSecurityDBGrantReviewIdentity(t *testing.T) {
	a := securityDBGrantReviewKey(42, "jira_user", "")
	b := securityDBGrantReviewKey(42, "jira_user", "")
	if a != b || a == securityDBGrantReviewKey(43, "jira_user", "") || a == securityDBGrantReviewKey(42, "other", "") {
		t.Fatal("grant group key not stable/distinct")
	}
	if !strings.HasPrefix(a, "dbg:42:") {
		t.Fatal(a)
	}
}
func TestSecurityDBHBAIdentityKeepsDistinctSourceLine(t *testing.T) {
	rule := securityHBARule{Type: "host", Databases: []string{"all"}, Users: []string{"all"}, Address: "127.0.0.1/32", Method: "md5", SourceFile: "pg_hba.conf", Line: 90}
	one := securityDBHBAReviewKey(1, rule)
	rule.Line = 91
	if one == securityDBHBAReviewKey(1, rule) {
		t.Fatal("two HBA records merged")
	}
}
func TestSecurityBulkGrantAndHBATargets(t *testing.T) {
	db := securityDatabase{ID: 12, Engine: "postgresql", GrantReviews: []securityDBGrantReview{{Principal: "jira", Review: securityReview{ResourceKey: "dbg:12:abc"}}}, HBARules: []securityHBARule{{Review: securityReview{ResourceKey: "dbh:12:def"}}}}
	v := securityResponse{Databases: []securityDatabase{db}}
	if got := securityBulkTargets(v, "database_grants", 12); len(got) != 1 || got[0].Type != "database_grants" {
		t.Fatalf("%+v", got)
	}
	if got := securityBulkTargets(v, "database_hba", 12); len(got) != 1 || got[0].Type != "database_hba" {
		t.Fatalf("%+v", got)
	}
	if got := securityBulkTargets(v, "database_grants", 0); len(got) != 0 {
		t.Fatalf("must not include all instances: %+v", got)
	}
}
func TestSecurityDatabaseWorkbookSheets(t *testing.T) {
	db := securityDatabase{Engine: "postgresql", Principals: []securityDBPrincipal{{Name: "app", Login: true}}, Privileges: []securityDBPrivilege{{Principal: "app", Privilege: "SELECT"}}, HBARules: []securityHBARule{{Method: "md5"}}}
	if got := securityDatabaseWorkbook([]securityDatabase{db}); len(got) != 3 || len(got[1].Rows) != 2 {
		t.Fatalf("unexpected sheets: %+v", got)
	}
	db.Engine = "mysql"
	if got := securityDatabaseWorkbook([]securityDatabase{db}); len(got) != 2 {
		t.Fatalf("mysql must have 2 sheets, got %d", len(got))
	}
}
