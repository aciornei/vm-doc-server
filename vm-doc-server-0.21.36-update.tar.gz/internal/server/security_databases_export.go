package server

import (
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"
	"vm-doc-server/internal/xlsx"
)

func securityDatabaseWorkbook(databases []securityDatabase) []xlsx.Sheet {
	users := xlsx.Sheet{Name: "Users", Rows: [][]xlsx.Cell{{xlsx.Text("VM"), xlsx.Text("Motor"), xlsx.Text("Instanță"), xlsx.Text("Utilizator"), xlsx.Text("Host"), xlsx.Text("Database"), xlsx.Text("LOGIN"), xlsx.Text("SUPERUSER"), xlsx.Text("CREATEROLE"), xlsx.Text("CREATEDB"), xlsx.Text("REPLICATION"), xlsx.Text("Roluri"), xlsx.Text("Ultima revizie"), xlsx.Text("Next review"), xlsx.Text("De")}}}
	grants := xlsx.Sheet{Name: "Grants", Rows: [][]xlsx.Cell{{xlsx.Text("VM"), xlsx.Text("Motor"), xlsx.Text("Instanță"), xlsx.Text("Principal"), xlsx.Text("Host"), xlsx.Text("Bază"), xlsx.Text("Schemă"), xlsx.Text("Scope"), xlsx.Text("Tip obiect"), xlsx.Text("Obiect"), xlsx.Text("Privilegiu"), xlsx.Text("Stare"), xlsx.Text("Grant option"), xlsx.Text("Sursă"), xlsx.Text("Ultima revizie grup"), xlsx.Text("Next review grup"), xlsx.Text("Revizuit de")}}}
	hba := xlsx.Sheet{Name: "HBA", Rows: [][]xlsx.Cell{{xlsx.Text("VM"), xlsx.Text("Instanță"), xlsx.Text("Type"), xlsx.Text("Database"), xlsx.Text("User"), xlsx.Text("Address"), xlsx.Text("Method"), xlsx.Text("Options"), xlsx.Text("Fișier"), xlsx.Text("Linie"), xlsx.Text("Indicator"), xlsx.Text("Ultima revizie"), xlsx.Text("Next review"), xlsx.Text("De")}}}
	hasHBA := false
	stamp := func(t *time.Time) string {
		if t == nil {
			return ""
		}
		return t.UTC().Format(time.RFC3339)
	}
	yes := func(v bool) string {
		if v {
			return "Da"
		}
		return "Nu"
	}
	for _, db := range databases {
		for _, p := range db.Principals {
			if securityDatabaseBuiltInNoLogin(db.Engine, p) {
				continue
			}
			users.Rows = append(users.Rows, []xlsx.Cell{xlsx.Text(db.VMName), xlsx.Text(db.Engine), xlsx.Text(db.InstanceName), xlsx.Text(p.Name), xlsx.Text(p.Host), xlsx.Text(p.Database), xlsx.Text(yes(p.Login)), xlsx.Text(yes(p.Superuser)), xlsx.Text(yes(p.CreateRole)), xlsx.Text(yes(p.CreateDB)), xlsx.Text(yes(p.Replication)), xlsx.Text(strings.Join(p.Roles, ", ")), xlsx.Text(stamp(p.Review.ReviewedAt)), xlsx.Text(stamp(p.Review.NextReviewAt)), xlsx.Text(p.Review.ReviewedBy)})
		}
		reviewByGrantee := make(map[string]securityReview)
		for _, gr := range db.GrantReviews {
			reviewByGrantee[gr.Principal+"\x00"+gr.Host] = gr.Review
		}
		for _, g := range db.Privileges {
			grReview := reviewByGrantee[g.Principal+"\x00"+g.Host]
			grants.Rows = append(grants.Rows, []xlsx.Cell{xlsx.Text(db.VMName), xlsx.Text(db.Engine), xlsx.Text(db.InstanceName), xlsx.Text(g.Principal), xlsx.Text(g.Host), xlsx.Text(g.Database), xlsx.Text(g.Schema), xlsx.Text(g.Scope), xlsx.Text(g.ObjectType), xlsx.Text(g.ObjectName), xlsx.Text(g.Privilege), xlsx.Text(g.State), xlsx.Text(yes(g.Grantable)), xlsx.Text(g.Source), xlsx.Text(stamp(grReview.ReviewedAt)), xlsx.Text(stamp(grReview.NextReviewAt)), xlsx.Text(grReview.ReviewedBy)})
		}
		if strings.EqualFold(db.Engine, "postgresql") && len(db.HBARules) > 0 {
			hasHBA = true
			for _, rule := range db.HBARules {
				hba.Rows = append(hba.Rows, []xlsx.Cell{xlsx.Text(db.VMName), xlsx.Text(db.InstanceName), xlsx.Text(rule.Type), xlsx.Text(strings.Join(rule.Databases, ", ")), xlsx.Text(strings.Join(rule.Users, ", ")), xlsx.Text(rule.Address), xlsx.Text(rule.Method), xlsx.Text(strings.Join(rule.Options, ", ")), xlsx.Text(rule.SourceFile), xlsx.Number(float64(rule.Line)), xlsx.Text(rule.WarningText), xlsx.Text(stamp(rule.Review.ReviewedAt)), xlsx.Text(stamp(rule.Review.NextReviewAt)), xlsx.Text(rule.Review.ReviewedBy)})
			}
		}
	}
	sheets := []xlsx.Sheet{users}
	if len(grants.Rows) > 1 {
		sheets = append(sheets, grants)
	}
	if hasHBA {
		sheets = append(sheets, hba)
	}
	return sheets
}

func (a *App) exportSecurityDatabases(w http.ResponseWriter, r *http.Request) {
	var vmID int64
	if raw := strings.TrimSpace(r.URL.Query().Get("vm_id")); raw != "" {
		id, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || id <= 0 {
			badRequest(w, fmt.Errorf("vm_id invalid"))
			return
		}
		vmID = id
	}
	reviews, err := a.loadSecurityReviews(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	result := securityResponse{}
	if err = a.loadSecurityDatabases(r.Context(), reviews, &result, vmID); err != nil {
		respond(w, nil, err)
		return
	}
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="vm-doc-security-databases-%s.xlsx"`, time.Now().Format("20060102-150405")))
	if err = xlsx.WriteSheets(w, securityDatabaseWorkbook(result.Databases)); err != nil && a.Logger != nil {
		a.Logger.Error("database access export XLSX", "error", err)
	}
}
