package documents

import (
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/inventory"
)

func TestRenderServiceMarkdownOutlineExport(t *testing.T) {
	data := ServiceGenerationData{
		Service: domain.InternalService{
			ID:                  7,
			Name:                "Metabase",
			ServiceCode:         "bi.metabase",
			ShortDescription:    "Rapoarte BI",
			Authentication:      "OIDC / Keycloak",
			ServiceURL:          "https://bi.example",
			Technologies:        "Java, PostgreSQL, Nginx",
			Criticality:         "high",
			DocumentationStatus: "approved",
			Active:              true,
			Description:         "Descriere",
			DescriptionRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{{Type: "paragraph", Runs: []domain.RichTextRun{{Text: "Important", Bold: true}, {Text: " text", Italic: true}}}}},
			Purpose:             "Scop",
			Objectives:          "Obiectiv",
			VMCount:             2,
			VMs: []domain.InternalServiceVM{
				{ID: 10, Name: "vm-prod", GuestHostname: "vm-prod", Environment: "prod", PrimaryIP: "10.0.0.10", LayerName: "App", TechnicalRole: "Frontend"},
				{ID: 11, Name: "vm-test", GuestHostname: "vm-test", Environment: "test", PrimaryIP: "10.0.1.10", LayerName: "App", TechnicalRole: "Frontend"},
			},
		},
		GeneratedAt:    time.Date(2026, 9, 14, 10, 0, 0, 0, time.UTC),
		DocumentNumber: "FSI-20260914-000007-ABCD",
		Attachments:    []domain.InternalServiceAttachment{{Title: "Arhitectură", FileName: "arhitectura.docx", ExtractedText: "Detalii proiect"}},
		VMDocuments:    []ServiceVMDocument{{VMID: 10, VMName: "vm-prod", Environment: "prod", DocumentNumber: "FVM-1", DownloadURL: "https://vm-doc.example/api/v1/documents/1/download"}},
	}

	text := string(RenderServiceMarkdown(data))
	for _, expected := range []string{
		"# Fișă tehnică și operațională a serviciului — Metabase",
		"**Număr electronic document:** FSI-20260914-000007-ABCD",
		"## 1. Identificare serviciu",
		"**Important**",
		"*text*",
		"### PROD",
		"### TEST",
		"Anexe — proceduri operaționale și fluxuri de lucru",
		"B1 — Arhitectură",
		"Detalii proiect",
		"Anexe — fișe tehnice VM",
		"A1. vm-prod",
		"[Deschide fișa VM](https://vm-doc.example/api/v1/documents/1/download)",
	} {
		if !strings.Contains(text, expected) {
			t.Fatalf("markdown export missing %q:\n%s", expected, text)
		}
	}
	vmAnnexPos := strings.Index(text, "Anexe — fișe tehnice VM")
	supplementalPos := strings.Index(text, "Anexe — proceduri operaționale și fluxuri de lucru")
	if vmAnnexPos < 0 || supplementalPos < 0 || supplementalPos <= vmAnnexPos {
		t.Fatalf("supplemental documentation must be the final annex section: vm=%d supplemental=%d\n%s", vmAnnexPos, supplementalPos, text)
	}
}

func TestServiceMarkdownFileName(t *testing.T) {
	name := ServiceMarkdownFileName(ServiceGenerationData{Service: domain.InternalService{ID: 9, ServiceCode: "bi.metabase"}, DocumentNumber: "FSI-TEST"})
	if name != "bi.metabase-fsi-test.md" {
		t.Fatalf("unexpected markdown filename: %s", name)
	}
}

func TestRenderServiceMarkdownEmbedsVMAnnexes(t *testing.T) {
	data := ServiceGenerationData{
		Service: domain.InternalService{
			ID:   7,
			Name: "Metabase",
			VMs:  []domain.InternalServiceVM{{ID: 10, Name: "vm-prod", Environment: "prod"}},
		},
		GeneratedAt:    time.Date(2026, 9, 14, 10, 0, 0, 0, time.UTC),
		DocumentNumber: "FSI-20260914-000007-ABCD",
		EmbedVMAnnexes: true,
		VMAnnexData: []GenerationData{{
			VM:             domain.VirtualMachine{ID: 10, Name: "vm-prod", GuestHostname: "vm-prod.example", PrimaryIP: "10.0.0.10", GuestOS: "Ubuntu 24.04", CPUCount: 4, MemoryMiB: 8192, PowerState: "poweredOn"},
			Operational:    domain.VMOperationalMetadata{Environment: "prod", OperationalStatus: "active", Purpose: "Application server"},
			GeneratedAt:    time.Date(2026, 9, 14, 10, 0, 0, 0, time.UTC),
			DocumentNumber: "FVM-20260914-000010-TEST",
		}},
	}

	text := string(RenderServiceMarkdown(data))
	for _, expected := range []string{
		"Anexe — fișe tehnice VM",
		"### A1 — vm-prod",
		"#### Identificare și resurse",
		"| Nume VM | vm-prod |",
		"| Sistem de operare | Ubuntu 24.04 |",
		"#### Încadrare operațională",
		"| Mediu | PROD |",
		"#### Backup și restaurare",
		"#### Monitorizare",
	} {
		if !strings.Contains(text, expected) {
			t.Fatalf("embedded VM annex missing %q:\n%s", expected, text)
		}
	}
}

func TestRenderServiceMarkdownVMAnnexUsesStructuredInventoryTables(t *testing.T) {
	view := &inventory.DocumentView{Sections: []inventory.DocumentSection{
		{Key: "network", Data: map[string]any{"interfaces": []any{map[string]any{"name": "ens160", "addresses": []any{map[string]any{"address": "10.20.30.40", "prefix": "24"}}, "gateway": "10.20.30.1", "dns": []any{"10.20.0.10"}}}}},
		{Key: "services", Data: []any{map[string]any{"name": "nginx.service", "active": true, "classification": "application", "description": "Web server"}}},
		{Key: "listening_ports", Data: []any{map[string]any{"port": 443, "protocol": "tcp", "address": "0.0.0.0", "processes": []any{map[string]any{"name": "nginx", "pid": 123, "executable": "/usr/sbin/nginx"}}}}},
		{Key: "firewall", Data: map[string]any{"detected": true, "active": true, "backends": []any{"ufw"}, "default_policies": map[string]any{"incoming": "deny", "outgoing": "allow"}}},
		{Key: "accounts", Data: []any{map[string]any{"username": "root", "uid": 0, "home": "/root", "shell": "/bin/bash"}}},
		{Key: "cron", Data: []any{map[string]any{"schedule": "0 2 * * *", "command": "/opt/app/backup.sh", "user": "root"}}},
	}}
	data := ServiceGenerationData{
		Service:     domain.InternalService{ID: 7, Name: "Test", VMs: []domain.InternalServiceVM{{ID: 10, Name: "vm-prod", Environment: "prod"}}},
		GeneratedAt: time.Date(2026, 9, 16, 10, 0, 0, 0, time.UTC), DocumentNumber: "FSI-TEST", EmbedVMAnnexes: true,
		VMAnnexData: []GenerationData{{VM: domain.VirtualMachine{ID: 10, Name: "vm-prod"}, GeneratedAt: time.Date(2026, 9, 16, 10, 0, 0, 0, time.UTC), DocumentNumber: "FVM-TEST", InventoryDocument: view}},
	}
	text := string(RenderServiceMarkdown(data))
	for _, expected := range []string{
		"##### Rețea", "| IP | Mask / Gateway | DNS | Interfață |", "10.20.30.40",
		"##### Servicii active", "| Nume | Descriere |", "nginx.service",
		"##### Porturi ascultate", "| Nume / proces | Executabil | Adresă | Port | Protocol |",
		"##### Firewall", "###### Politici implicite", "| Context | Politică |",
		"##### Conturi importante", "| Utilizator | UID | Home | Grupuri / shell |",
		"##### Sarcini programate", "| Programare | Comandă | Utilizator |",
	} {
		if !strings.Contains(text, expected) {
			t.Fatalf("structured markdown inventory missing %q:\n%s", expected, text)
		}
	}
}
