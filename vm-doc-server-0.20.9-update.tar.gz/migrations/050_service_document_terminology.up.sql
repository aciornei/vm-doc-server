-- 0.20.9: terminologie unitară pentru documentația serviciului.
UPDATE document_templates
SET name='Fișă tehnică și operațională a serviciului — standard',
    description='Șablonul implicit pentru fișa tehnică și operațională a serviciilor interne. Conține placeholderul {{SERVICE_DOCUMENT_BODY}}.',
    file_name='fisa-tehnica-operationala-serviciu-standard.docx'
WHERE object_type='service'
  AND template_code='service.standard'
  AND name='Fișă serviciu intern standard';
