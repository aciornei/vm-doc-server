# Generarea fișelor DOCX

În 0.6.0 același motor generează două tipuri de documente: **fișa tehnică VM** și **fișa Serviciului intern**. Șabloanele sunt separate prin `object_type=vm|service`, iar fiecare tip are propriul șablon implicit.

## Flux VM

```text
Fișa VM
└── alegere șablon DOCX
    ├── previzualizare date
    └── generare DOCX
        ├── număr unic
        ├── SHA-256
        ├── snapshot inventar sursă
        ├── autor și dată
        └── istoric și descărcare
```

## Date incluse

- identificare și resurse din vCenter;
- hostname, IP și sistem de operare din inventarul agentului, cu fallback la vCenter;
- mediu, status operațional, clasificare, scop și observații;
- domeniu, categorie de serviciu, serviciu intern, layer, rol tehnic și tip soluție;
- responsabilități și date de contact;
- backup și restaurare;
- inventarul structurat al agentului, cu mascarea valorilor sensibile realizată de `inventory.BuildDocumentView`.

## Șablonul DOCX

Șablonul trebuie să fie un fișier `.docx` valid și să conțină, într-un paragraf separat:

```text
{{VM_DOCUMENT_BODY}}
```

Paragraful este înlocuit cu toate secțiunile generate. Pentru rezultate previzibile, placeholderul nu trebuie formatat pe bucăți diferite în Word.

Placeholdere scalare disponibile:

```text
{{document.number}}
{{document.generated_at}}
{{document.generated_by}}
{{vm.name}}
{{vm.hostname}}
{{vm.ip}}
{{vm.os}}
{{vm.environment}}
{{vm.status}}
{{vm.classification}}
{{vm.purpose}}
```

Placeholderele scalare trebuie și ele păstrate într-un singur segment de text Word.

## Flux Serviciu intern

```text
Pagina Serviciului intern
└── alegere șablon DOCX de tip service
    ├── previzualizare date agregate
    └── generare DOCX
        ├── număr unic FSI-*
        ├── SHA-256
        ├── autor și dată
        └── istoric și descărcare
```

Fișa serviciului include identificarea, domeniile și categoriile observate, tipurile de soluție, combinațiile layer–rol și VM-urile asociate. Datele sunt calculate din asocierile existente ale VM-urilor, nu duplicate manual pe serviciu.

Șablonul de serviciu trebuie să conțină într-un paragraf separat:

```text
{{SERVICE_DOCUMENT_BODY}}
```

Placeholdere scalare suplimentare pentru serviciu:

```text
{{service.name}}
{{service.code}}
{{service.criticality}}
{{service.status}}
{{service.description}}
{{service.purpose}}
```


## Securitate

- șabloanele și documentele sunt stocate în MariaDB;
- fișierele generate păstrează SHA-256 și dimensiunea;
- generarea și descărcarea sunt auditate;
- valorile din inventar cu nume de tip `password`, `secret`, `token`, `credential`, `private_key`, `api_key` sau `access_key` sunt redactate înainte de generare;
- accesul este controlat prin `documents.read` și `documents.manage`.

## Structura compactă a inventarului în 0.5.1

```text
6.1  Schema inventar
6.3  Sistem și hardware
6.4  Sistem de operare
6.5  Stocare
6.6  Rețea
6.8  Servicii active
6.9  Porturi ascultate
6.10 Firewall UFW
6.11 Conturi importante
6.12 Integrare SSSD
6.13 Integrări operaționale
6.14 Politici
6.15 Sarcini programate
6.16 Sincronizare timp
```

Secțiunile 6.2 Agent și 6.7 Proxy nu mai sunt incluse. Datele sunt filtrate și prezentate în tabele cu lățimi fixe. Valorile numerice de capacitate sunt transformate automat în KB, MB, GB sau TB.


## Fișa Serviciului intern în 0.7.1

Corpul generat pentru un Serviciu intern include, în această ordine:

1. Identificare serviciu;
2. Scop, domeniu și obiective;
3. Schema logică a serviciului;
4. Domenii și categorii observate;
5. Tipuri de soluție;
6. Arhitectură tehnică observată;
7. VM-uri asociate.

Schema DOCX este nativă Word (tabele/carduri), nu o captură de ecran. VM-urile sunt deduplicate după `vm_id`: un VM cu mai multe asocieri apare o singură dată, iar rolurile sale sunt afișate în același nod.

Placeholdere suplimentare pentru șabloanele de serviciu:

- `{{service.scope_domain}}` — Scop și domeniu;
- `{{service.objectives}}` — Obiective;
- `{{service.purpose}}` — alias compatibil pentru Scop și domeniu.

## Rich-text în fișa Serviciului intern (0.7.2)

`Scop și domeniu` și `Obiective` sunt stocate într-un model rich-text restricționat (`version`, `blocks`, `runs`). Blocurile pot fi `paragraph`, `bullet` sau `number`, iar run-urile pot avea `bold`, `italic` și `underline`. Nivelul de listă este limitat la 0–4.

În corpul `{{SERVICE_DOCUMENT_BODY}}`, generatorul DOCX transformă structura în paragrafe Word cu indentare și run-uri formatate. Bullets și numerotarea sunt randate stabil, inclusiv în LibreOffice, fără să depindă de stilurile de listă ale șablonului personalizat.

Placeholderele scalare `{{service.scope_domain}}`, `{{service.purpose}}` și `{{service.objectives}}` folosesc în continuare reprezentarea plain-text sincronizată automat.

## Limitări 0.6.0

- se generează numai DOCX;
- conversia PDF și semnarea digitală vor fi implementate ulterior;
- șablonul personalizat trebuie să păstreze placeholderul principal într-un paragraf separat;
- documentele foarte mari pot crește dimensiunea bazei MariaDB, deoarece conținutul este păstrat pentru audit și redescărcare.

## Medii, fișe VM și anexe pentru Serviciul intern (0.8.0)

Fișa Serviciului intern evidențiază acum separat **PROD**, **TEST/UAT/QA**, **DEV** și mediile neclasificate. Mediul provine din `vm_operational_metadata.environment`, iar fiecare VM este numărat o singură dată chiar dacă are mai multe asocieri tehnice în același serviciu.

Capitolul VM-uri asociate include numărul ultimei fișe VM disponibile și, atunci când `app.base_url` este configurat, un hyperlink direct către documentul generat.

La generarea fișei serviciului sunt disponibile două opțiuni:

- **Include fișele VM ca anexe** — fixează în `service_document_annexes` documentul VM exact folosit pentru fiecare VM. Dacă un VM nu are încă o fișă, aceasta este generată automat înainte de fișa serviciului;
- **Regenerează fișele VM înainte de anexare** — generează o fișă nouă pentru fiecare VM, apoi le fixează ca anexe ale documentului de serviciu.

Pachetul `/api/v1/documents/{id}/package` este un ZIP care conține:

```text
<fisa-serviciu>.docx
anexe/
  A01_<fisa-vm-1>.docx
  A02_<fisa-vm-2>.docx
  ...
```

Relația de anexe este versionată per document de serviciu. Generarea ulterioară a unei alte fișe VM nu modifică anexele documentației de serviciu deja generate.

## Dependențe comune în documente (0.9.0)

Fișa VM include **Dependențe infrastructură comună**, agregând relațiile moștenite din serviciile asociate, relațiile globale și excepțiile directe de pe VM. Pentru fiecare dependență sunt incluse tipul, caracterul, proveniența și VM-urile furnizor.

Fișa Serviciului intern include **Dependențe și servicii comune**. Pentru un serviciu marcat comun este inclusă suplimentar secțiunea **Impact asupra serviciilor dependente**; pentru un serviciu global este menționat numărul tuturor serviciilor active potențial afectate.

Pentru un serviciu comun, analiza de impact din DOCX include atât serviciile dependente, cât și VM-urile care au o dependență directă declarată ca excepție tehnică.


## Componente software principale

Din 0.10.0, operatorul poate marca unul sau mai multe servicii din inventarul agentului ca **Principale**. Selecția este salvată pe VM (`vm_id + service_name`) și nu depinde de ID-ul snapshotului.

Fișa VM include pentru fiecare selecție: numele software, serviciul, versiunea produsului, pachetul, versiunea pachetului și starea curentă atunci când agentul le raportează. Dacă serviciul selectat nu mai este detectat, documentația îl păstrează și îl marchează ca nedetectat.

Fișa Serviciului intern agregă aceleași componente pentru toate VM-urile asociate, împreună cu mediul fiecărei mașini. Agenții anteriori versiunii 1.3.1 rămân compatibili, dar pot lăsa versiunea necompletată.

## Conectivitate externă (0.13.0)

Fișele VM și Serviciu includ conexiunile către sisteme externe. Pentru fiecare relație se afișează sistemul și adresa, rețeaua externă împreună cu risc/trust, sensul comunicației, serviciul, protocolul/portul, TLS/autentificarea și scopul.

## Paginare tabele și proceduri operaționale (0.20.7 / 0.20.9)

Rândurile de date din tabelele generate pentru fișele VM și Serviciu pot continua pe pagina următoare. Generatorul nu mai setează `w:cantSplit` pe rândurile de conținut, astfel încât un rând lung (de exemplu un Site Web cu multe server names/bindings/backends) nu este mutat integral pe pagina următoare. Header-ele de tabel rămân marcate cu `w:tblHeader` și se pot repeta la schimbarea paginii.

Documentele DOCX încărcate la **Proceduri operaționale și fluxuri de lucru** sunt anexate la finalul **Fișei tehnice și operaționale a serviciului**, fiecare pe pagină nouă, cu etichete **B1, B2, ...**. Fișele VM integrate păstrează etichetele **A1, A2, ...**. Aceeași ordine este folosită și de exportul Markdown.
