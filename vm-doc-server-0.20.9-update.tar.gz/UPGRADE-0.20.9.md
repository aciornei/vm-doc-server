# Upgrade vm-doc-server 0.20.8 → 0.20.9

0.20.9 uniformizează denumirea documentelor de serviciu și a procedurilor atașate.

## Upgrade offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.8 vm-doc-server-0.20.9
tar -xzf /cale/vm-doc-server-0.20.9-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.9
cd /usr/local/src/vm-doc-server-0.20.9
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Păstrați `vendor/`, `go.mod` și `go.sum` din arborele 0.20.8 care compilează deja în mediul offline. Update-ul 0.20.9 nu le modifică.

La prima pornire se aplică migrarea `050_service_document_terminology.up.sql`. Ea schimbă numai numele/descrierea/filename-ul șablonului implicit `service.standard`; nu modifică schema bazei de date.

Nu este necesar update de agent.
