package inventorychanges

import (
	"encoding/json"
	"testing"
)

func dockerMACSnapshot(mac, ip, gateway, image, networkID string) []byte {
	item := map[string]any{
		"docker": map[string]any{"containers": []any{map[string]any{
			"name": "app", "compose_project": "prod", "compose_service": "api", "image": image,
			"networks": []any{map[string]any{"name": "front", "network_id": networkID, "ip_address": ip, "gateway": gateway, "mac_address": mac}},
		}}},
	}
	raw, err := json.Marshal(item)
	if err != nil {
		panic(err)
	}
	return raw
}

func TestDockerContainerMACOnlyDoesNotProduceChange(t *testing.T) {
	oldRaw := dockerMACSnapshot("02:42:ac:12:00:02", "172.18.0.2", "172.18.0.1", "my-app:1", "network-1")
	newRaw := dockerMACSnapshot("02:42:ac:12:00:fe", "172.18.0.2", "172.18.0.1", "my-app:1", "network-1")
	before, err := extractTracked(oldRaw)
	if err != nil {
		t.Fatal(err)
	}
	after, err := extractTracked(newRaw)
	if err != nil {
		t.Fatal(err)
	}
	if len(before) != 1 || len(after) != 1 {
		t.Fatalf("unexpected containers %v %v", before, after)
	}
	key := "docker|container|prod|api|app"
	if !canonicalEqual(before[key].Value, after[key].Value) {
		t.Fatalf("MAC-only rotation created a change: %v != %v", before[key].Value, after[key].Value)
	}
	// Removing MAC from tracked values MUST NOT modify the source agent JSON.
	var source map[string]any
	if err := json.Unmarshal(newRaw, &source); err != nil {
		t.Fatal(err)
	}
	networks := source["docker"].(map[string]any)["containers"].([]any)[0].(map[string]any)["networks"].([]any)
	if networks[0].(map[string]any)["mac_address"] != "02:42:ac:12:00:fe" {
		t.Fatal("original MAC lost")
	}
}

func TestDockerNetworksRetainMeaningfulChanges(t *testing.T) {
	original, err := extractTracked(dockerMACSnapshot("aa:bb:cc:dd:ee:00", "172.18.0.2", "172.18.0.1", "my-app:1", "network-1"))
	if err != nil {
		t.Fatal(err)
	}
	key := "docker|container|prod|api|app"
	variations := []struct{ name, ip, gateway, image, networkID string }{
		{"ip", "172.18.0.3", "172.18.0.1", "my-app:1", "network-1"},
		{"gateway", "172.18.0.2", "172.18.0.254", "my-app:1", "network-1"},
		{"image", "172.18.0.2", "172.18.0.1", "my-app:2", "network-1"},
		{"network", "172.18.0.2", "172.18.0.1", "my-app:1", "network-2"},
	}
	for _, tc := range variations {
		t.Run(tc.name, func(t *testing.T) {
			changed, err := extractTracked(dockerMACSnapshot("aa:bb:cc:dd:ee:11", tc.ip, tc.gateway, tc.image, tc.networkID))
			if err != nil {
				t.Fatal(err)
			}
			if canonicalEqual(original[key].Value, changed[key].Value) {
				t.Fatal("real configuration change was suppressed")
			}
		})
	}
}

func TestDockerMACNormalizationDoesNotMutateSourceMap(t *testing.T) {
	m := map[string]any{"name": "front", "mac_address": "02:42:ff:00:00:01", "ip_address": "172.18.0.3"}
	result := trackedDockerNetworks([]any{m}).([]any)[0].(map[string]any)
	if _, ok := result["mac_address"]; ok {
		t.Fatal("MAC present in tracked value")
	}
	if _, ok := m["mac_address"]; !ok {
		t.Fatal("source map mutated")
	}
	if result["ip_address"] != "172.18.0.3" {
		t.Fatal("IP lost")
	}
}
