# Upgrade vm-doc-server 0.20.35 -> 0.20.36

Versiunea 0.20.36 corectează UX-ul Componentelor suport. Nu adaugă migrare DB și nu necesită update de vm-doc-agent.

## Schimbări

- Bifarea `Componentă suport` se salvează inline și nu mai reconstruiește pagina VM.
- Rămâi în tabul/subsecțiunea curentă și la poziția curentă din listă.
- După bifare se deschide imediat editorul componentei.
- `Componentă propusă` poate fi modificată direct.
- `Versiune manuală` și `Port(uri) manual` sunt override-uri opționale; dacă sunt goale se folosesc valorile detectate automat.
- Salvarea editorului este inline și afișează imediat valorile efective folosite în raport.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.35 \
      /usr/local/src/vm-doc-server-0.20.36

tar -xzf vm-doc-server-0.20.36-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.36

cd /usr/local/src/vm-doc-server-0.20.36
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

După restart folosește `Ctrl+F5` pentru încărcarea `app.js?v=0.20.36`.
