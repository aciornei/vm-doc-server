package server

import (
	"net/http"
	"strconv"
	"strings"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/inventory"
)

func (a *App) setVMSupportComponent(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input inventory.SupportComponentInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	if err := a.Inventory.SaveSupportComponent(r.Context(), vmID, user.ID, input); err != nil {
		respond(w, nil, err)
		return
	}
	var component any
	if input.Enabled {
		var raw []byte
		if vm, vmErr := a.VCenter.GetVM(r.Context(), vmID); vmErr == nil && vm.CurrentInventoryID != nil {
			if current, inventoryErr := a.Inventory.Get(r.Context(), *vm.CurrentInventoryID, true); inventoryErr == nil {
				raw = append([]byte(nil), current.RawJSON...)
			}
		}
		if values, listErr := a.Inventory.ListSupportComponents(r.Context(), vmID, raw); listErr == nil {
			for _, value := range values {
				if strings.EqualFold(strings.TrimSpace(value.ServiceName), strings.TrimSpace(input.ServiceName)) {
					component = value
					break
				}
			}
		}
	}
	a.auditRequest(r, "vm.support_component.update", "virtual_machine", strconv.FormatInt(vmID, 10), "success", map[string]any{
		"service_name":     input.ServiceName,
		"component_name":   input.ComponentName,
		"version_override": input.VersionOverride,
		"port_override":    input.PortOverride,
		"enabled":          input.Enabled,
	})
	jsonResponse(w, http.StatusOK, map[string]any{"vm_id": vmID, "service_name": input.ServiceName, "enabled": input.Enabled, "component": component})
}
