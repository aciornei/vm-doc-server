# Upgrade VM-DOC Server 0.20.89 → 0.20.90

## Scop

0.20.90 corectează deduplicarea istoricului VM la colectarea manuală. Aceeași execuție putea ajunge prin push-ul agentului și prin pull-ul worker-ului serverului.

0.20.89 încerca să deduplice după payload + `collected_at`, dar coloana MariaDB `inventory_snapshots.collected_at` este `DATETIME(6)` și nu păstrează nanosecundele din JSON. 0.20.90 folosește timestamp-ul original din `raw_json` pentru comparație și păstrează un fallback la precizie de microsecundă.

## Upgrade

Extrage update-ul peste sursa 0.20.89, apoi construiește și repornește serverul:

```bash
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
systemctl restart vm-doc-server
```

Nu există migrare DB. Nu este necesar update de agent; vm-doc-agent 1.7.14 rămâne recomandat.

După upgrade, un singur click pe **Colectează** trebuie să creeze un singur rând nou în Istoric. Dublurile deja existente nu sunt șterse automat.
