# Upgrade vm-doc-server 0.14.1 → 0.15.0

Versiunea 0.15.0 introduce inventarul structurat de baze de date și asocierea independentă a instanțelor/bazelor logice cu serviciile interne.

## 1. Backup

Faceți backup bazei de date și al directorului aplicației.

## 2. Actualizare surse

Aplicați `vm-doc-server-0.15.0-update.tar.gz` peste sursa 0.14.1 sau patch-ul `vm-doc-server-0.14.1-to-0.15.0.patch`.

## 3. Compilare

```bash
go build -o vm-doc-server ./cmd/vm-doc-server
```

Înlocuiți binarul folosit de systemd și reporniți serviciul.

## 4. Migrare DB

La pornire se aplică `030_database_inventory.up.sql`. Verificați existența tabelelor `database_hosts`, `database_engines`, `database_instances`, `database_catalogs`, `database_instance_service_assignments` și `database_catalog_service_assignments`.

## 5. Agent

Pentru colectare este necesar `vm-doc-agent 1.5.0`. Upgrade-ul de la 1.4.1 migrează aditiv `config.json` și adaugă automat `collectors.databases=true` plus limitele noi, păstrând valorile existente.

După upgrade-ul agentului, forțați o colectare. În fila **Baze de date** a VM-ului trebuie să apară engine-urile/instanțele detectate. Bazele logice apar numai când pot fi enumerate local fără credențiale noi.

## 6. Asocieri servicii

Pe un host DB partajat, asocierea VM → serviciu nu decide apartenența bazelor. Asociați preferabil fiecare bază logică serviciului său; când catalogul nu poate fi enumerat, puteți asocia întreaga instanță.
