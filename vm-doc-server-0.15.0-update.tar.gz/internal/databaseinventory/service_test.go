package databaseinventory

import "testing"

func TestCollectorStatusUsable(t *testing.T) {
	for _, v := range []string{"success", "partial", " SUCCESS "} {
		if !collectorStatusUsable(v) {
			t.Fatalf("expected usable %q", v)
		}
	}
	for _, v := range []string{"error", "timeout", "disabled", ""} {
		if collectorStatusUsable(v) {
			t.Fatalf("expected unusable %q", v)
		}
	}
}
func TestInstanceIdentityStable(t *testing.T) {
	v := agentDatabaseInstance{Engine: "postgresql", InstanceName: "main", DataDir: "/var/lib/postgresql/16/main", Endpoints: []agentDatabaseEndpoint{{Port: 5432}}}
	if got := instanceIdentity(v); got != "postgresql|main|/var/lib/postgresql/16/main|5432" {
		t.Fatal(got)
	}
}
func TestCatalogIdentity(t *testing.T) {
	if got := catalogIdentity(agentDatabaseCatalog{Name: "AppDB", Kind: "database"}); got != "database|appdb" {
		t.Fatal(got)
	}
}
