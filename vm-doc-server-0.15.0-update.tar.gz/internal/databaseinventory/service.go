package databaseinventory

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

type Service struct{ DB *sql.DB }

type AssignmentInput struct {
	ServiceID     int64  `json:"service_id"`
	ComponentName string `json:"component_name,omitempty"`
	RoleName      string `json:"role_name,omitempty"`
	Notes         string `json:"notes,omitempty"`
}

type agentDatabaseInfo struct {
	Engines   []agentDatabaseEngine   `json:"engines"`
	Instances []agentDatabaseInstance `json:"instances"`
}

type agentDatabaseEngine struct {
	Engine     string   `json:"engine"`
	Product    string   `json:"product"`
	Installed  bool     `json:"installed"`
	Executable string   `json:"executable"`
	Version    string   `json:"version"`
	Sources    []string `json:"sources"`
}

type agentDatabaseEndpoint struct {
	Protocol string `json:"protocol"`
	Address  string `json:"address"`
	Port     uint16 `json:"port"`
	Wildcard bool   `json:"wildcard"`
}

type agentDatabaseCatalog struct {
	Name   string `json:"name"`
	Kind   string `json:"kind"`
	System bool   `json:"system"`
}

type agentDatabaseInstance struct {
	Engine                 string                  `json:"engine"`
	Product                string                  `json:"product"`
	InstanceName           string                  `json:"instance_name"`
	Version                string                  `json:"version"`
	Edition                string                  `json:"edition"`
	Status                 string                  `json:"status"`
	ServiceName            string                  `json:"service_name"`
	PID                    int                     `json:"pid"`
	Executable             string                  `json:"executable"`
	DataDir                string                  `json:"data_dir"`
	ConfigFiles            []string                `json:"config_files"`
	Endpoints              []agentDatabaseEndpoint `json:"endpoints"`
	SocketPaths            []string                `json:"socket_paths"`
	Catalogs               []agentDatabaseCatalog  `json:"catalogs"`
	CatalogDiscoveryStatus string                  `json:"catalog_discovery_status"`
	DetectionSources       []string                `json:"detection_sources"`
}

func (s Service) Sync(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, raw []byte) error {
	if tx == nil || vmID < 1 || inventoryID < 1 {
		return nil
	}
	var root struct {
		Databases  json.RawMessage `json:"databases"`
		Collection struct {
			Collectors map[string]struct {
				Status string `json:"status"`
			} `json:"collectors"`
		} `json:"collection"`
	}
	dec := json.NewDecoder(bytes.NewReader(raw))
	if err := dec.Decode(&root); err != nil {
		return fmt.Errorf("decode database inventory envelope: %w", err)
	}
	if status, ok := root.Collection.Collectors["databases"]; ok && !collectorStatusUsable(status.Status) {
		// A disabled/error/timeout collection must never erase the last known
		// database topology or its manual service mappings.
		return nil
	}
	payloadRaw := bytes.TrimSpace(root.Databases)
	if len(payloadRaw) == 0 || bytes.Equal(payloadRaw, []byte("null")) {
		return nil
	}
	var payload agentDatabaseInfo
	if err := json.Unmarshal(payloadRaw, &payload); err != nil {
		return fmt.Errorf("decode database inventory: %w", err)
	}
	now := time.Now().UTC()
	catalogCount := 0
	for _, instance := range payload.Instances {
		catalogCount += len(instance.Catalogs)
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO database_hosts(vm_id,current_inventory_id,engine_count,instance_count,catalog_count,observed_at)
		VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE current_inventory_id=VALUES(current_inventory_id),engine_count=VALUES(engine_count),instance_count=VALUES(instance_count),catalog_count=VALUES(catalog_count),observed_at=VALUES(observed_at)`, vmID, inventoryID, len(payload.Engines), len(payload.Instances), catalogCount, now)
	if err != nil {
		return fmt.Errorf("upsert database host: %w", err)
	}
	for _, table := range []string{"database_engines", "database_instances", "database_catalogs"} {
		if _, err := tx.ExecContext(ctx, `UPDATE `+table+` SET present=0 WHERE vm_id=?`, vmID); err != nil {
			return err
		}
	}
	for _, engine := range payload.Engines {
		if err := upsertEngine(ctx, tx, vmID, inventoryID, engine, now); err != nil {
			return err
		}
	}
	for _, instance := range payload.Instances {
		instanceID, err := upsertInstance(ctx, tx, vmID, inventoryID, instance, now)
		if err != nil {
			return err
		}
		for _, catalog := range instance.Catalogs {
			if err := upsertCatalog(ctx, tx, vmID, inventoryID, instanceID, catalog, now); err != nil {
				return err
			}
		}
	}
	return nil
}

func collectorStatusUsable(status string) bool {
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "success", "partial":
		return true
	default:
		return false
	}
}

func upsertEngine(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, v agentDatabaseEngine, now time.Time) error {
	sources, _ := json.Marshal(v.Sources)
	_, err := tx.ExecContext(ctx, `INSERT INTO database_engines(vm_id,engine,product,installed,executable,version,sources_json,present,current_inventory_id,last_seen_at)
		VALUES(?,?,?,?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE product=VALUES(product),installed=VALUES(installed),executable=VALUES(executable),version=VALUES(version),sources_json=VALUES(sources_json),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`, vmID, clean(v.Engine, 64), clean(v.Product, 255), v.Installed, clean(v.Executable, 2048), clean(v.Version, 512), sources, inventoryID, now)
	return err
}

func instanceIdentity(v agentDatabaseInstance) string {
	port := ""
	for _, endpoint := range v.Endpoints {
		if endpoint.Port > 0 {
			port = strconv.Itoa(int(endpoint.Port))
			break
		}
	}
	parts := []string{strings.ToLower(strings.TrimSpace(v.Engine)), strings.ToLower(strings.TrimSpace(v.InstanceName)), strings.TrimSpace(v.DataDir), port}
	identity := strings.Join(parts, "|")
	if len(identity) > 512 {
		identity = identity[:512]
	}
	return identity
}

func upsertInstance(ctx context.Context, tx *sql.Tx, vmID, inventoryID int64, v agentDatabaseInstance, now time.Time) (int64, error) {
	configFiles, _ := json.Marshal(v.ConfigFiles)
	endpoints, _ := json.Marshal(v.Endpoints)
	sockets, _ := json.Marshal(v.SocketPaths)
	sources, _ := json.Marshal(v.DetectionSources)
	identity := instanceIdentity(v)
	_, err := tx.ExecContext(ctx, `INSERT INTO database_instances(vm_id,identity_key,engine,product,instance_name,version,edition,status,service_name,process_pid,executable,data_dir,config_files_json,endpoints_json,socket_paths_json,catalog_discovery_status,detection_sources_json,present,current_inventory_id,last_seen_at)
		VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE engine=VALUES(engine),product=VALUES(product),instance_name=VALUES(instance_name),version=VALUES(version),edition=VALUES(edition),status=VALUES(status),service_name=VALUES(service_name),process_pid=VALUES(process_pid),executable=VALUES(executable),data_dir=VALUES(data_dir),config_files_json=VALUES(config_files_json),endpoints_json=VALUES(endpoints_json),socket_paths_json=VALUES(socket_paths_json),catalog_discovery_status=VALUES(catalog_discovery_status),detection_sources_json=VALUES(detection_sources_json),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`,
		vmID, identity, clean(v.Engine, 64), clean(v.Product, 255), clean(v.InstanceName, 255), clean(v.Version, 512), clean(v.Edition, 255), clean(v.Status, 64), clean(v.ServiceName, 255), v.PID, clean(v.Executable, 2048), clean(v.DataDir, 2048), configFiles, endpoints, sockets, clean(v.CatalogDiscoveryStatus, 64), sources, inventoryID, now)
	if err != nil {
		return 0, fmt.Errorf("upsert database instance %q: %w", v.InstanceName, err)
	}
	var id int64
	if err := tx.QueryRowContext(ctx, `SELECT id FROM database_instances WHERE vm_id=? AND identity_key=?`, vmID, identity).Scan(&id); err != nil {
		return 0, err
	}
	return id, nil
}

func catalogIdentity(v agentDatabaseCatalog) string {
	kind := strings.ToLower(strings.TrimSpace(v.Kind))
	if kind == "" {
		kind = "database"
	}
	value := kind + "|" + strings.ToLower(strings.TrimSpace(v.Name))
	if len(value) > 512 {
		value = value[:512]
	}
	return value
}

func upsertCatalog(ctx context.Context, tx *sql.Tx, vmID, inventoryID, instanceID int64, v agentDatabaseCatalog, now time.Time) error {
	kind := clean(v.Kind, 64)
	if kind == "" {
		kind = "database"
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO database_catalogs(database_instance_id,vm_id,identity_key,name,catalog_kind,is_system,present,current_inventory_id,last_seen_at)
		VALUES(?,?,?,?,?,?,1,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),catalog_kind=VALUES(catalog_kind),is_system=VALUES(is_system),present=1,current_inventory_id=VALUES(current_inventory_id),last_seen_at=VALUES(last_seen_at)`, instanceID, vmID, catalogIdentity(v), clean(v.Name, 512), kind, v.System, inventoryID, now)
	return err
}

func (s Service) ensureCurrentSnapshot(ctx context.Context, vmID int64) error {
	if s.DB == nil || vmID < 1 {
		return nil
	}
	var inventoryID int64
	var raw []byte
	var normalized sql.NullInt64
	err := s.DB.QueryRowContext(ctx, `SELECT vm.current_inventory_id,i.raw_json,dh.current_inventory_id FROM virtual_machines vm JOIN inventory_snapshots i ON i.id=vm.current_inventory_id LEFT JOIN database_hosts dh ON dh.vm_id=vm.id WHERE vm.id=? AND vm.current_inventory_id IS NOT NULL`, vmID).Scan(&inventoryID, &raw, &normalized)
	if errors.Is(err, sql.ErrNoRows) {
		return nil
	}
	if err != nil {
		return err
	}
	if normalized.Valid && normalized.Int64 == inventoryID {
		return nil
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if err := s.Sync(ctx, tx, vmID, inventoryID, raw); err != nil {
		return err
	}
	return tx.Commit()
}

func (s Service) GetVM(ctx context.Context, vmID int64) (domain.DatabaseVMView, error) {
	view := domain.DatabaseVMView{Engines: []domain.DatabaseEngine{}, Instances: []domain.DatabaseInstance{}}
	if s.DB == nil {
		return view, nil
	}
	if err := s.ensureCurrentSnapshot(ctx, vmID); err != nil {
		return view, fmt.Errorf("synchronize current database snapshot: %w", err)
	}
	var host domain.DatabaseHostSummary
	var inventory sql.NullInt64
	var observed sql.NullTime
	err := s.DB.QueryRowContext(ctx, `SELECT vm_id,current_inventory_id,engine_count,instance_count,catalog_count,observed_at FROM database_hosts WHERE vm_id=?`, vmID).Scan(&host.VMID, &inventory, &host.EngineCount, &host.InstanceCount, &host.CatalogCount, &observed)
	if errors.Is(err, sql.ErrNoRows) {
		return view, nil
	}
	if err != nil {
		return view, err
	}
	if inventory.Valid {
		v := inventory.Int64
		host.CurrentInventoryID = &v
	}
	if observed.Valid {
		t := observed.Time
		host.ObservedAt = &t
	}
	view.Host = &host
	if err := s.loadEngines(ctx, vmID, &view); err != nil {
		return view, err
	}
	instances, err := s.loadInstances(ctx, vmID, 0)
	if err != nil {
		return view, err
	}
	view.Instances = instances
	return view, nil
}

func (s Service) loadEngines(ctx context.Context, vmID int64, view *domain.DatabaseVMView) error {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,vm_id,engine,product,installed,executable,version,sources_json FROM database_engines WHERE vm_id=? AND present=1 ORDER BY product,engine`, vmID)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var v domain.DatabaseEngine
		var sources sql.NullString
		if err := rows.Scan(&v.ID, &v.VMID, &v.Engine, &v.Product, &v.Installed, &v.Executable, &v.Version, &sources); err != nil {
			return err
		}
		decodeJSON(sources.String, &v.Sources)
		view.Engines = append(view.Engines, v)
	}
	return rows.Err()
}

func (s Service) loadInstances(ctx context.Context, vmID, onlyServiceID int64) ([]domain.DatabaseInstance, error) {
	query := `SELECT di.id,di.vm_id,vm.name,COALESCE(vm.guest_hostname,''),di.identity_key,di.engine,di.product,di.instance_name,di.version,di.edition,di.status,di.service_name,di.process_pid,di.executable,di.data_dir,di.config_files_json,di.endpoints_json,di.socket_paths_json,di.catalog_discovery_status,di.detection_sources_json,di.present FROM database_instances di JOIN virtual_machines vm ON vm.id=di.vm_id WHERE di.vm_id=? AND di.present=1 ORDER BY di.engine,di.instance_name,di.id`
	rows, err := s.DB.QueryContext(ctx, query, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.DatabaseInstance{}
	for rows.Next() {
		var v domain.DatabaseInstance
		var config, endpoints, sockets, sources sql.NullString
		if err := rows.Scan(&v.ID, &v.VMID, &v.VMName, &v.VMHostname, &v.IdentityKey, &v.Engine, &v.Product, &v.InstanceName, &v.Version, &v.Edition, &v.Status, &v.ServiceName, &v.PID, &v.Executable, &v.DataDir, &config, &endpoints, &sockets, &v.CatalogDiscoveryStatus, &sources, &v.Present); err != nil {
			return nil, err
		}
		decodeJSON(config.String, &v.ConfigFiles)
		decodeJSON(endpoints.String, &v.Endpoints)
		decodeJSON(sockets.String, &v.SocketPaths)
		decodeJSON(sources.String, &v.DetectionSources)
		assignments, err := s.instanceAssignments(ctx, v.ID)
		if err != nil {
			return nil, err
		}
		v.ServiceAssignments = assignments
		catalogs, err := s.catalogs(ctx, v.ID)
		if err != nil {
			return nil, err
		}
		v.Catalogs = catalogs
		out = append(out, v)
	}
	return out, rows.Err()
}

func (s Service) catalogs(ctx context.Context, instanceID int64) ([]domain.DatabaseCatalog, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT dc.id,dc.database_instance_id,dc.vm_id,vm.name,COALESCE(vm.guest_hostname,''),di.engine,di.product,di.instance_name,di.version,dc.name,dc.catalog_kind,dc.is_system,dc.present FROM database_catalogs dc JOIN database_instances di ON di.id=dc.database_instance_id JOIN virtual_machines vm ON vm.id=dc.vm_id WHERE dc.database_instance_id=? AND dc.present=1 ORDER BY dc.is_system,dc.name`, instanceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.DatabaseCatalog{}
	for rows.Next() {
		var v domain.DatabaseCatalog
		if err := rows.Scan(&v.ID, &v.InstanceID, &v.VMID, &v.VMName, &v.VMHostname, &v.Engine, &v.Product, &v.InstanceName, &v.InstanceVersion, &v.Name, &v.Kind, &v.System, &v.Present); err != nil {
			return nil, err
		}
		a, err := s.catalogAssignments(ctx, v.ID)
		if err != nil {
			return nil, err
		}
		v.ServiceAssignments = a
		out = append(out, v)
	}
	return out, rows.Err()
}

func (s Service) instanceAssignments(ctx context.Context, instanceID int64) ([]domain.DatabaseServiceAssignment, error) {
	return s.assignments(ctx, `SELECT a.id,a.internal_service_id,svc.name,COALESCE(svc.service_code,''),a.component_name,a.role_name,a.notes FROM database_instance_service_assignments a JOIN internal_services svc ON svc.id=a.internal_service_id WHERE a.database_instance_id=? ORDER BY svc.name`, instanceID)
}
func (s Service) catalogAssignments(ctx context.Context, catalogID int64) ([]domain.DatabaseServiceAssignment, error) {
	return s.assignments(ctx, `SELECT a.id,a.internal_service_id,svc.name,COALESCE(svc.service_code,''),a.component_name,a.role_name,a.notes FROM database_catalog_service_assignments a JOIN internal_services svc ON svc.id=a.internal_service_id WHERE a.database_catalog_id=? ORDER BY svc.name`, catalogID)
}
func (s Service) assignments(ctx context.Context, query string, id int64) ([]domain.DatabaseServiceAssignment, error) {
	rows, err := s.DB.QueryContext(ctx, query, id)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []domain.DatabaseServiceAssignment{}
	for rows.Next() {
		var a domain.DatabaseServiceAssignment
		if err := rows.Scan(&a.ID, &a.ServiceID, &a.ServiceName, &a.ServiceCode, &a.ComponentName, &a.RoleName, &a.Notes); err != nil {
			return nil, err
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

func (s Service) ReplaceInstanceAssignments(ctx context.Context, vmID, instanceID, userID int64, inputs []AssignmentInput) error {
	return s.replaceAssignments(ctx, vmID, instanceID, userID, inputs, true)
}
func (s Service) ReplaceCatalogAssignments(ctx context.Context, vmID, catalogID, userID int64, inputs []AssignmentInput) error {
	return s.replaceAssignments(ctx, vmID, catalogID, userID, inputs, false)
}
func (s Service) replaceAssignments(ctx context.Context, vmID, objectID, userID int64, inputs []AssignmentInput, instance bool) error {
	if s.DB == nil {
		return errors.New("database inventory service is not configured")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	var exists int
	if instance {
		err = tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM database_instances WHERE id=? AND vm_id=?`, objectID, vmID).Scan(&exists)
	} else {
		err = tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM database_catalogs WHERE id=? AND vm_id=?`, objectID, vmID).Scan(&exists)
	}
	if err != nil {
		return err
	}
	if exists == 0 {
		return sql.ErrNoRows
	}
	if err := validateAssignments(ctx, tx, inputs); err != nil {
		return err
	}
	if instance {
		if _, err = tx.ExecContext(ctx, `DELETE FROM database_instance_service_assignments WHERE database_instance_id=?`, objectID); err != nil {
			return err
		}
	} else {
		if _, err = tx.ExecContext(ctx, `DELETE FROM database_catalog_service_assignments WHERE database_catalog_id=?`, objectID); err != nil {
			return err
		}
	}
	for _, in := range dedupeInputs(inputs) {
		if instance {
			_, err = tx.ExecContext(ctx, `INSERT INTO database_instance_service_assignments(database_instance_id,internal_service_id,component_name,role_name,notes,created_by,updated_by) VALUES(?,?,?,?,?,?,?)`, objectID, in.ServiceID, clean(in.ComponentName, 255), clean(in.RoleName, 255), clean(in.Notes, 1000), nullableUser(userID), nullableUser(userID))
		} else {
			_, err = tx.ExecContext(ctx, `INSERT INTO database_catalog_service_assignments(database_catalog_id,internal_service_id,component_name,role_name,notes,created_by,updated_by) VALUES(?,?,?,?,?,?,?)`, objectID, in.ServiceID, clean(in.ComponentName, 255), clean(in.RoleName, 255), clean(in.Notes, 1000), nullableUser(userID), nullableUser(userID))
		}
		if err != nil {
			return err
		}
	}
	return tx.Commit()
}

func (s Service) ListForService(ctx context.Context, serviceID int64) ([]domain.DatabaseServiceResource, error) {
	if s.DB == nil {
		return []domain.DatabaseServiceResource{}, nil
	}
	out := []domain.DatabaseServiceResource{}
	// Logical databases first. This is the preferred mapping for shared hosts.
	rows, err := s.DB.QueryContext(ctx, `SELECT dc.id,di.id,di.vm_id,vm.name,COALESCE(vm.guest_hostname,''),di.engine,di.product,di.instance_name,di.version,di.status,di.endpoints_json,dc.name,dc.catalog_kind,dc.is_system FROM database_catalog_service_assignments a JOIN database_catalogs dc ON dc.id=a.database_catalog_id JOIN database_instances di ON di.id=dc.database_instance_id JOIN virtual_machines vm ON vm.id=di.vm_id WHERE a.internal_service_id=? AND dc.present=1 AND di.present=1 ORDER BY vm.name,di.engine,di.instance_name,dc.name`, serviceID)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var v domain.DatabaseServiceResource
		var endpoints sql.NullString
		if err := rows.Scan(&v.CatalogID, &v.InstanceID, &v.VMID, &v.VMName, &v.VMHostname, &v.Engine, &v.Product, &v.InstanceName, &v.Version, &v.Status, &endpoints, &v.DatabaseName, &v.DatabaseKind, &v.System); err != nil {
			rows.Close()
			return nil, err
		}
		v.ResourceType = "database"
		decodeJSON(endpoints.String, &v.Endpoints)
		a, err := s.catalogAssignments(ctx, v.CatalogID)
		if err != nil {
			rows.Close()
			return nil, err
		}
		v.ServiceAssignments = filterAssignments(a, serviceID)
		out = append(out, v)
	}
	rows.Close()
	rows, err = s.DB.QueryContext(ctx, `SELECT di.id,di.vm_id,vm.name,COALESCE(vm.guest_hostname,''),di.engine,di.product,di.instance_name,di.version,di.status,di.endpoints_json FROM database_instance_service_assignments a JOIN database_instances di ON di.id=a.database_instance_id JOIN virtual_machines vm ON vm.id=di.vm_id WHERE a.internal_service_id=? AND di.present=1 ORDER BY vm.name,di.engine,di.instance_name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var v domain.DatabaseServiceResource
		var endpoints sql.NullString
		if err := rows.Scan(&v.InstanceID, &v.VMID, &v.VMName, &v.VMHostname, &v.Engine, &v.Product, &v.InstanceName, &v.Version, &v.Status, &endpoints); err != nil {
			return nil, err
		}
		v.ResourceType = "instance"
		decodeJSON(endpoints.String, &v.Endpoints)
		a, err := s.instanceAssignments(ctx, v.InstanceID)
		if err != nil {
			return nil, err
		}
		v.ServiceAssignments = filterAssignments(a, serviceID)
		out = append(out, v)
	}
	return out, rows.Err()
}

func filterAssignments(values []domain.DatabaseServiceAssignment, serviceID int64) []domain.DatabaseServiceAssignment {
	out := []domain.DatabaseServiceAssignment{}
	for _, v := range values {
		if v.ServiceID == serviceID {
			out = append(out, v)
		}
	}
	return out
}
func validateAssignments(ctx context.Context, tx *sql.Tx, inputs []AssignmentInput) error {
	for _, in := range dedupeInputs(inputs) {
		if in.ServiceID < 1 {
			return errors.New("service_id must be positive")
		}
		var n int
		if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM internal_services WHERE id=?`, in.ServiceID).Scan(&n); err != nil {
			return err
		}
		if n == 0 {
			return fmt.Errorf("internal service %d does not exist", in.ServiceID)
		}
	}
	return nil
}
func dedupeInputs(inputs []AssignmentInput) []AssignmentInput {
	seen := map[int64]struct{}{}
	out := []AssignmentInput{}
	for _, in := range inputs {
		if in.ServiceID < 1 {
			continue
		}
		if _, ok := seen[in.ServiceID]; ok {
			continue
		}
		seen[in.ServiceID] = struct{}{}
		out = append(out, in)
	}
	return out
}
func nullableUser(id int64) any {
	if id > 0 {
		return id
	}
	return nil
}
func clean(v string, max int) string {
	v = strings.TrimSpace(v)
	if len(v) > max {
		return v[:max]
	}
	return v
}
func decodeJSON(raw string, target any) {
	if strings.TrimSpace(raw) != "" {
		_ = json.Unmarshal([]byte(raw), target)
	}
}

// Stable ordering helper used by tests and future exporters.
func SortResources(values []domain.DatabaseServiceResource) {
	sort.Slice(values, func(i, j int) bool {
		a, b := values[i], values[j]
		if a.VMName != b.VMName {
			return strings.ToLower(a.VMName) < strings.ToLower(b.VMName)
		}
		if a.Engine != b.Engine {
			return a.Engine < b.Engine
		}
		if a.InstanceName != b.InstanceName {
			return strings.ToLower(a.InstanceName) < strings.ToLower(b.InstanceName)
		}
		return strings.ToLower(a.DatabaseName) < strings.ToLower(b.DatabaseName)
	})
}
