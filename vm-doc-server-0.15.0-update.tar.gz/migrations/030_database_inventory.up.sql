-- 0.15.0: database-engine / instance / logical-database inventory.
-- Associations are independent of VM -> service so a shared DB host can serve
-- many internal services and each logical database can be mapped separately.

CREATE TABLE IF NOT EXISTS database_hosts (
  vm_id BIGINT UNSIGNED NOT NULL,
  current_inventory_id BIGINT UNSIGNED NULL,
  engine_count INT NOT NULL DEFAULT 0,
  instance_count INT NOT NULL DEFAULT 0,
  catalog_count INT NOT NULL DEFAULT 0,
  observed_at DATETIME(6) NULL,
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (vm_id),
  KEY idx_database_host_inventory (current_inventory_id),
  CONSTRAINT fk_database_host_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_database_host_inventory FOREIGN KEY (current_inventory_id) REFERENCES inventory_snapshots(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS database_engines (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  engine VARCHAR(64) NOT NULL,
  product VARCHAR(255) NOT NULL DEFAULT '',
  installed TINYINT(1) NOT NULL DEFAULT 0,
  executable VARCHAR(2048) NOT NULL DEFAULT '',
  version VARCHAR(512) NOT NULL DEFAULT '',
  sources_json LONGTEXT NULL,
  present TINYINT(1) NOT NULL DEFAULT 1,
  current_inventory_id BIGINT UNSIGNED NULL,
  last_seen_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_database_engine_vm (vm_id,engine),
  KEY idx_database_engine_vm_present (vm_id,present,engine),
  CONSTRAINT fk_database_engine_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_database_engine_inventory FOREIGN KEY (current_inventory_id) REFERENCES inventory_snapshots(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS database_instances (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  identity_key VARCHAR(512) NOT NULL,
  engine VARCHAR(64) NOT NULL,
  product VARCHAR(255) NOT NULL DEFAULT '',
  instance_name VARCHAR(255) NOT NULL DEFAULT '',
  version VARCHAR(512) NOT NULL DEFAULT '',
  edition VARCHAR(255) NOT NULL DEFAULT '',
  status VARCHAR(64) NOT NULL DEFAULT '',
  service_name VARCHAR(255) NOT NULL DEFAULT '',
  process_pid INT NOT NULL DEFAULT 0,
  executable VARCHAR(2048) NOT NULL DEFAULT '',
  data_dir VARCHAR(2048) NOT NULL DEFAULT '',
  config_files_json LONGTEXT NULL,
  endpoints_json LONGTEXT NULL,
  socket_paths_json LONGTEXT NULL,
  catalog_discovery_status VARCHAR(64) NOT NULL DEFAULT '',
  detection_sources_json LONGTEXT NULL,
  present TINYINT(1) NOT NULL DEFAULT 1,
  current_inventory_id BIGINT UNSIGNED NULL,
  first_seen_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  last_seen_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_database_instance_identity (vm_id,identity_key),
  KEY idx_database_instance_vm_present (vm_id,present,engine,instance_name),
  KEY idx_database_instance_engine (engine,product),
  CONSTRAINT fk_database_instance_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_database_instance_inventory FOREIGN KEY (current_inventory_id) REFERENCES inventory_snapshots(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS database_catalogs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  database_instance_id BIGINT UNSIGNED NOT NULL,
  vm_id BIGINT UNSIGNED NOT NULL,
  identity_key VARCHAR(512) NOT NULL,
  name VARCHAR(512) NOT NULL,
  catalog_kind VARCHAR(64) NOT NULL DEFAULT 'database',
  is_system TINYINT(1) NOT NULL DEFAULT 0,
  present TINYINT(1) NOT NULL DEFAULT 1,
  current_inventory_id BIGINT UNSIGNED NULL,
  first_seen_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  last_seen_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_database_catalog_identity (database_instance_id,identity_key),
  KEY idx_database_catalog_vm_present (vm_id,present,name(191)),
  CONSTRAINT fk_database_catalog_instance FOREIGN KEY (database_instance_id) REFERENCES database_instances(id) ON DELETE CASCADE,
  CONSTRAINT fk_database_catalog_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_database_catalog_inventory FOREIGN KEY (current_inventory_id) REFERENCES inventory_snapshots(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS database_instance_service_assignments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  database_instance_id BIGINT UNSIGNED NOT NULL,
  internal_service_id BIGINT UNSIGNED NOT NULL,
  component_name VARCHAR(255) NOT NULL DEFAULT '',
  role_name VARCHAR(255) NOT NULL DEFAULT '',
  notes VARCHAR(1000) NOT NULL DEFAULT '',
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_database_instance_service (database_instance_id,internal_service_id),
  KEY idx_database_instance_service_service (internal_service_id,database_instance_id),
  CONSTRAINT fk_database_instance_service_instance FOREIGN KEY (database_instance_id) REFERENCES database_instances(id) ON DELETE CASCADE,
  CONSTRAINT fk_database_instance_service_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_database_instance_service_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_database_instance_service_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS database_catalog_service_assignments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  database_catalog_id BIGINT UNSIGNED NOT NULL,
  internal_service_id BIGINT UNSIGNED NOT NULL,
  component_name VARCHAR(255) NOT NULL DEFAULT '',
  role_name VARCHAR(255) NOT NULL DEFAULT '',
  notes VARCHAR(1000) NOT NULL DEFAULT '',
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_database_catalog_service (database_catalog_id,internal_service_id),
  KEY idx_database_catalog_service_service (internal_service_id,database_catalog_id),
  CONSTRAINT fk_database_catalog_service_catalog FOREIGN KEY (database_catalog_id) REFERENCES database_catalogs(id) ON DELETE CASCADE,
  CONSTRAINT fk_database_catalog_service_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_database_catalog_service_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_database_catalog_service_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
