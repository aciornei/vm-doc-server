# Upgrade 0.20.57 → 0.20.58

## Ce se schimbă

0.20.58 adaugă raportul **Rapoarte → Componente software**, calculat automat din inventarul deja existent. Nu transformă și nu înlocuiește raportul **Componente suport**.

Poți filtra direct componente precum PostgreSQL, MongoDB, MariaDB, SQL Server, Redis, Nginx, Java etc. și obții VM-ul, versiunea, mediul, IP-ul, serviciile/proiectele și sursele de detecție.

## Migrare DB

Nu există migrare nouă.

## Agent

Nu este necesar update de `vm-doc-agent`.

## Instalare offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.57 \
      /usr/local/src/vm-doc-server-0.20.58

tar -xzf vm-doc-server-0.20.58-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.58

cd /usr/local/src/vm-doc-server-0.20.58
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Înlocuiește binarul și repornește `vm-doc-server`, apoi fă `Ctrl+F5` în browser.

## Verificare recomandată

1. Deschide **Rapoarte → Componente software**.
2. Apasă cardul **PostgreSQL**: trebuie să rămână numai VM-urile pe care PostgreSQL este detectat.
3. Repetă cu **MongoDB**.
4. Filtrează după versiune (de exemplu `8`, `14.11`, `7.0`) și mediu.
5. Verifică o VM cu PostgreSQL/Mongo într-un container Docker: imaginea trebuie să contribuie la detecție chiar dacă nu există o bifă manuală.
6. Verifică **Export Excel**; exportul trebuie să respecte filtrele curente, nu pagina curentă.
7. Confirmă că **Rapoarte → Componente suport** și marcajele **Principal** au rămas neschimbate.
