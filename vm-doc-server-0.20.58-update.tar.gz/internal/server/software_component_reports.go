package server

import (
	"context"
	"fmt"
	"net/http"
	"sort"
	"strings"
	"time"
	"unicode"

	"vm-doc-server/internal/inventory"
	"vm-doc-server/internal/xlsx"
)

type softwareComponentDefinition struct {
	Key      string
	Name     string
	Category string
	Needles  []string
}

// softwareComponentCatalog is deliberately curated.  The automatic report must
// answer inventory questions ("where is PostgreSQL?") without turning every OS
// package into a component.  New technologies can be added here without a DB
// migration or agent change.
var softwareComponentCatalog = []softwareComponentDefinition{
	{Key: "postgresql", Name: "PostgreSQL", Category: "Baze de date", Needles: []string{"postgresql", "postgres"}},
	{Key: "mongodb", Name: "MongoDB", Category: "Baze de date", Needles: []string{"mongodb", "mongod", "mongo db", "mongo"}},
	{Key: "mariadb", Name: "MariaDB", Category: "Baze de date", Needles: []string{"mariadb"}},
	{Key: "mysql", Name: "MySQL", Category: "Baze de date", Needles: []string{"mysql"}},
	{Key: "oracle", Name: "Oracle Database", Category: "Baze de date", Needles: []string{"oracle database", "oracle db", "oracle xe", "oracledb"}},
	{Key: "sqlserver", Name: "Microsoft SQL Server", Category: "Baze de date", Needles: []string{"sql server", "sqlserver", "mssql"}},
	{Key: "redis", Name: "Redis", Category: "Cache / Key-Value", Needles: []string{"redis"}},
	{Key: "memcached", Name: "Memcached", Category: "Cache / Key-Value", Needles: []string{"memcached"}},
	{Key: "nginx", Name: "Nginx", Category: "Web / Reverse Proxy", Needles: []string{"nginx"}},
	{Key: "apache", Name: "Apache HTTP Server", Category: "Web / Reverse Proxy", Needles: []string{"apache http", "apache2", "httpd"}},
	{Key: "iis", Name: "Microsoft IIS", Category: "Web / Reverse Proxy", Needles: []string{"internet information services", "microsoft iis", "iis web"}},
	{Key: "haproxy", Name: "HAProxy", Category: "Web / Reverse Proxy", Needles: []string{"haproxy"}},
	{Key: "tomcat", Name: "Tomcat", Category: "Application Server", Needles: []string{"tomcat"}},
	{Key: "wildfly", Name: "JBoss / WildFly", Category: "Application Server", Needles: []string{"wildfly", "jboss"}},
	{Key: "weblogic", Name: "Oracle WebLogic", Category: "Application Server", Needles: []string{"weblogic"}},
	{Key: "websphere", Name: "IBM WebSphere", Category: "Application Server", Needles: []string{"websphere"}},
	{Key: "java", Name: "Java", Category: "Runtime", Needles: []string{"openjdk", "jdk", "jre", "java runtime", "java tm", "java se"}},
	{Key: "dotnet", Name: ".NET", Category: "Runtime", Needles: []string{"dotnet", ".net runtime", ".net hosting", ".net sdk", "asp.net core"}},
	{Key: "php", Name: "PHP", Category: "Runtime", Needles: []string{"php"}},
	{Key: "nodejs", Name: "Node.js", Category: "Runtime", Needles: []string{"node.js", "nodejs"}},
	{Key: "python", Name: "Python", Category: "Runtime", Needles: []string{"python 3", "python3", "python 2", "python2"}},
	{Key: "rabbitmq", Name: "RabbitMQ", Category: "Messaging", Needles: []string{"rabbitmq"}},
	{Key: "kafka", Name: "Kafka", Category: "Messaging", Needles: []string{"apache kafka", "kafka"}},
	{Key: "activemq", Name: "ActiveMQ", Category: "Messaging", Needles: []string{"activemq"}},
	{Key: "zookeeper", Name: "ZooKeeper", Category: "Messaging", Needles: []string{"zookeeper"}},
	{Key: "keycloak", Name: "Keycloak", Category: "Identity", Needles: []string{"keycloak"}},
	{Key: "openldap", Name: "OpenLDAP", Category: "Identity", Needles: []string{"openldap", "slapd"}},
	{Key: "postfix", Name: "Postfix", Category: "Mail", Needles: []string{"postfix"}},
	{Key: "dovecot", Name: "Dovecot", Category: "Mail", Needles: []string{"dovecot"}},
	{Key: "docker", Name: "Docker", Category: "Containere", Needles: []string{"docker engine", "docker-ce", "docker ce", "docker desktop", "dockerd"}},
	{Key: "podman", Name: "Podman", Category: "Containere", Needles: []string{"podman"}},
	{Key: "containerd", Name: "containerd", Category: "Containere", Needles: []string{"containerd"}},
	{Key: "kubernetes", Name: "Kubernetes", Category: "Containere / Orchestrare", Needles: []string{"kubernetes", "kubelet", "kubeadm"}},
	{Key: "nodeexporter", Name: "Node Exporter", Category: "Observability", Needles: []string{"node exporter", "node_exporter", "node-exporter"}},
	{Key: "prometheus", Name: "Prometheus", Category: "Observability", Needles: []string{"prometheus"}},
	{Key: "grafana", Name: "Grafana", Category: "Observability", Needles: []string{"grafana"}},
	{Key: "graylog", Name: "Graylog", Category: "Observability", Needles: []string{"graylog"}},
	{Key: "filebeat", Name: "Filebeat", Category: "Observability", Needles: []string{"filebeat"}},
	{Key: "auditbeat", Name: "Auditbeat", Category: "Observability", Needles: []string{"auditbeat"}},
	{Key: "elasticsearch", Name: "Elasticsearch", Category: "Search / Storage", Needles: []string{"elasticsearch"}},
	{Key: "opensearch", Name: "OpenSearch", Category: "Search / Storage", Needles: []string{"opensearch"}},
	{Key: "solr", Name: "Solr", Category: "Search / Storage", Needles: []string{"solr"}},
	{Key: "minio", Name: "MinIO", Category: "Search / Storage", Needles: []string{"minio"}},
	{Key: "meilisearch", Name: "Meilisearch", Category: "Search / Storage", Needles: []string{"meilisearch"}},
	{Key: "vault", Name: "Vault", Category: "Platformă", Needles: []string{"hashicorp vault", "vault"}},
	{Key: "consul", Name: "Consul", Category: "Platformă", Needles: []string{"hashicorp consul", "consul"}},
	{Key: "sentry", Name: "Sentry", Category: "Platformă", Needles: []string{"sentry"}},
}

type softwareComponentVM struct {
	ID          int64
	Name        string
	Hostname    string
	Environment string
	IP          string
	PowerState  string
	Services    string
	Raw         []byte
}

type softwareComponentReportRow struct {
	ComponentKey  string   `json:"component_key"`
	ComponentName string   `json:"component_name"`
	Category      string   `json:"category"`
	Versions      []string `json:"versions"`
	Version       string   `json:"version"`
	Environment   string   `json:"environment"`
	VMID          int64    `json:"vm_id"`
	VMName        string   `json:"vm_name"`
	Hostname      string   `json:"hostname"`
	IP            string   `json:"ip"`
	PowerState    string   `json:"power_state"`
	Status        string   `json:"status"`
	Sources       []string `json:"sources"`
	Source        string   `json:"source"`
	Evidence      []string `json:"evidence"`
	Services      string   `json:"services"`
}

type softwareComponentReportSummary struct {
	Components    int `json:"components"`
	Versions      int `json:"versions"`
	Installations int `json:"installations"`
	VMs           int `json:"vms"`
}

type softwareComponentCount struct {
	Key      string `json:"key"`
	Name     string `json:"name"`
	Category string `json:"category"`
	VMs      int    `json:"vms"`
}

type softwareComponentReportResponse struct {
	GeneratedAt time.Time                      `json:"generated_at"`
	Summary     softwareComponentReportSummary `json:"summary"`
	Components  []softwareComponentCount       `json:"components"`
	Rows        []softwareComponentReportRow   `json:"rows"`
}

type softwareComponentAggregate struct {
	definition      softwareComponentDefinition
	vm              softwareComponentVM
	versions        map[string]bool
	versionPriority int
	sources         map[string]bool
	evidence        map[string]bool
	status          string
	statusPriority  int
}

type componentCandidate struct {
	Definition softwareComponentDefinition
	Version    string
	Status     string
	Source     string
	Evidence   string
	Priority   int
}

func (a *App) reportsSoftwareComponents(w http.ResponseWriter, r *http.Request) {
	value, err := a.softwareComponentReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	value.Rows = filterSoftwareComponentRows(value.Rows,
		r.URL.Query().Get("q"), r.URL.Query().Get("component"), r.URL.Query().Get("category"),
		r.URL.Query().Get("version"), r.URL.Query().Get("environment"))
	value.Summary = summarizeSoftwareComponentRows(value.Rows)
	value.Components = countSoftwareComponents(value.Rows)
	jsonResponse(w, http.StatusOK, value)
}

func (a *App) softwareComponentReport(ctx context.Context) (softwareComponentReportResponse, error) {
	out := softwareComponentReportResponse{GeneratedAt: time.Now().UTC(), Rows: []softwareComponentReportRow{}, Components: []softwareComponentCount{}}
	vms, err := a.loadSoftwareComponentVMs(ctx)
	if err != nil {
		return out, err
	}
	byID := make(map[int64]softwareComponentVM, len(vms))
	for _, vm := range vms {
		byID[vm.ID] = vm
	}
	aggregates := map[string]*softwareComponentAggregate{}
	add := func(vmID int64, candidate componentCandidate) {
		vm, ok := byID[vmID]
		if !ok || candidate.Definition.Key == "" {
			return
		}
		key := fmt.Sprintf("%d\x00%s", vmID, candidate.Definition.Key)
		agg := aggregates[key]
		if agg == nil {
			agg = &softwareComponentAggregate{definition: candidate.Definition, vm: vm, versions: map[string]bool{}, sources: map[string]bool{}, evidence: map[string]bool{}}
			aggregates[key] = agg
		}
		if source := strings.TrimSpace(candidate.Source); source != "" {
			agg.sources[source] = true
		}
		if evidence := strings.TrimSpace(candidate.Evidence); evidence != "" {
			agg.evidence[evidence] = true
		}
		if version := cleanComponentVersion(candidate.Version); version != "" {
			if candidate.Priority > agg.versionPriority {
				agg.versions = map[string]bool{version: true}
				agg.versionPriority = candidate.Priority
			} else if candidate.Priority == agg.versionPriority {
				agg.versions[version] = true
			}
		}
		if status := strings.TrimSpace(candidate.Status); status != "" && candidate.Priority >= agg.statusPriority {
			agg.status = status
			agg.statusPriority = candidate.Priority
		}
	}

	// The specialized collectors are authoritative for product version/state.
	// database_engines also covers an installed engine without a discovered/running
	// instance, which is important for inventory questions and upgrade planning.
	rows, err := a.DB.QueryContext(ctx, `SELECT vm_id,engine,product,version,executable FROM database_engines WHERE present=1 AND installed=1`)
	if err != nil {
		return out, err
	}
	for rows.Next() {
		var vmID int64
		var engine, product, version, executable string
		if err := rows.Scan(&vmID, &engine, &product, &version, &executable); err != nil {
			rows.Close()
			return out, err
		}
		if def, ok := identifyDatabaseComponent(engine, product); ok {
			add(vmID, componentCandidate{Definition: def, Version: version, Status: "instalat", Source: "Baze de date", Evidence: firstComponentText(product, engine, executable), Priority: 38})
		}
	}
	if err := rows.Close(); err != nil {
		return out, err
	}

	rows, err = a.DB.QueryContext(ctx, `SELECT vm_id,engine,product,version,status,service_name FROM database_instances WHERE present=1`)
	if err != nil {
		return out, err
	}
	for rows.Next() {
		var vmID int64
		var engine, product, version, status, serviceName string
		if err := rows.Scan(&vmID, &engine, &product, &version, &status, &serviceName); err != nil {
			rows.Close()
			return out, err
		}
		if def, ok := identifyDatabaseComponent(engine, product); ok {
			add(vmID, componentCandidate{Definition: def, Version: version, Status: status, Source: "Baze de date", Evidence: firstComponentText(product, engine, serviceName), Priority: 40})
		}
	}
	if err := rows.Close(); err != nil {
		return out, err
	}

	rows, err = a.DB.QueryContext(ctx, `SELECT vm_id,engine,product,version,status,service_name FROM web_servers WHERE present=1`)
	if err != nil {
		return out, err
	}
	for rows.Next() {
		var vmID int64
		var engine, product, version, status, serviceName string
		if err := rows.Scan(&vmID, &engine, &product, &version, &status, &serviceName); err != nil {
			rows.Close()
			return out, err
		}
		if def, ok := identifyWebComponent(engine, product); ok {
			add(vmID, componentCandidate{Definition: def, Version: version, Status: status, Source: "Web", Evidence: firstComponentText(product, engine, serviceName), Priority: 40})
		}
	}
	if err := rows.Close(); err != nil {
		return out, err
	}

	rows, err = a.DB.QueryContext(ctx, `SELECT vm_id,engine_version,service_state,executable FROM docker_hosts WHERE installed=1`)
	if err != nil {
		return out, err
	}
	for rows.Next() {
		var vmID int64
		var version, status, executable string
		if err := rows.Scan(&vmID, &version, &status, &executable); err != nil {
			rows.Close()
			return out, err
		}
		def, _ := softwareComponentByKey("docker")
		add(vmID, componentCandidate{Definition: def, Version: version, Status: status, Source: "Docker", Evidence: firstComponentText(executable, "Docker Engine"), Priority: 40})
	}
	if err := rows.Close(); err != nil {
		return out, err
	}

	// A component that runs in a container still belongs to the VM for inventory
	// questions.  The image tag is useful as a version hint when no specialized
	// collector has a better version.
	rows, err = a.DB.QueryContext(ctx, `SELECT vm_id,name,image_ref,state,status FROM docker_containers WHERE present=1`)
	if err != nil {
		return out, err
	}
	for rows.Next() {
		var vmID int64
		var name, imageRef, state, status string
		if err := rows.Scan(&vmID, &name, &imageRef, &state, &status); err != nil {
			rows.Close()
			return out, err
		}
		if def, ok := identifySoftwareComponent(strings.Join([]string{name, imageRef}, " ")); ok && def.Key != "docker" {
			version := versionFromContainerImage(imageRef)
			add(vmID, componentCandidate{Definition: def, Version: version, Status: firstComponentText(state, status), Source: "Container Docker", Evidence: firstComponentText(imageRef, name), Priority: 30})
		}
	}
	if err := rows.Close(); err != nil {
		return out, err
	}

	rows, err = a.DB.QueryContext(ctx, `SELECT vm_id,name,version,publisher,state,source FROM software_items WHERE present=1`)
	if err != nil {
		return out, err
	}
	for rows.Next() {
		var vmID int64
		var name, version, publisher, status, source string
		if err := rows.Scan(&vmID, &name, &version, &publisher, &status, &source); err != nil {
			rows.Close()
			return out, err
		}
		if def, ok := identifySoftwareComponent(strings.Join([]string{name, publisher}, " ")); ok {
			add(vmID, componentCandidate{Definition: def, Version: version, Status: status, Source: "Software instalat", Evidence: firstComponentText(name, publisher, source), Priority: 20})
		}
	}
	if err := rows.Close(); err != nil {
		return out, err
	}

	// Agent services cover Linux/application technologies that do not always have
	// a dedicated collector or package entry (Keycloak, Redis, RabbitMQ etc.).
	for _, vm := range vms {
		services, parseErr := inventory.ObservedAgentServices(vm.Raw)
		if parseErr != nil {
			continue // best effort: one malformed/legacy snapshot must not break the report
		}
		for _, service := range services {
			if def, ok := identifySoftwareComponent(strings.Join([]string{service.ServiceName, service.SoftwareName, service.PackageName, service.Description}, " ")); ok {
				version := firstComponentText(service.Version, service.PackageVersion)
				status := firstComponentText(service.ActiveState, service.SubState, service.EnabledState)
				add(vm.ID, componentCandidate{Definition: def, Version: version, Status: status, Source: "Servicii agent", Evidence: firstComponentText(service.ServiceName, service.SoftwareName, service.PackageName), Priority: 25})
			}
		}
	}

	out.Rows = make([]softwareComponentReportRow, 0, len(aggregates))
	for _, agg := range aggregates {
		versions := sortedComponentValues(agg.versions, true)
		sources := sortedComponentValues(agg.sources, false)
		evidence := sortedComponentValues(agg.evidence, false)
		out.Rows = append(out.Rows, softwareComponentReportRow{
			ComponentKey: agg.definition.Key, ComponentName: agg.definition.Name, Category: agg.definition.Category,
			Versions: versions, Version: strings.Join(versions, ", "), Environment: agg.vm.Environment,
			VMID: agg.vm.ID, VMName: agg.vm.Name, Hostname: agg.vm.Hostname, IP: agg.vm.IP, PowerState: agg.vm.PowerState,
			Status: agg.status, Sources: sources, Source: strings.Join(sources, ", "), Evidence: evidence, Services: agg.vm.Services,
		})
	}
	sortSoftwareComponentRows(out.Rows)
	out.Summary = summarizeSoftwareComponentRows(out.Rows)
	out.Components = countSoftwareComponents(out.Rows)
	return out, nil
}

func (a *App) loadSoftwareComponentVMs(ctx context.Context) ([]softwareComponentVM, error) {
	rows, err := a.DB.QueryContext(ctx, `SELECT vm.id,vm.name,
		COALESCE(NULLIF(i.hostname,''),NULLIF(vm.guest_hostname,''),''),
		COALESCE(m.environment,''),
		COALESCE(NULLIF(m.preferred_ip,''),NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,''),''),
		COALESCE(vm.power_state,''),
		COALESCE((SELECT GROUP_CONCAT(DISTINCT s.name ORDER BY s.name SEPARATOR ', ') FROM vm_internal_service_assignments a JOIN internal_services s ON s.id=a.internal_service_id AND s.active=1 WHERE a.vm_id=vm.id),''),
		COALESCE(i.raw_json,'')
		FROM virtual_machines vm
		LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id
		LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id
		WHERE vm.retired=0
		ORDER BY LOWER(vm.name),vm.id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]softwareComponentVM, 0)
	for rows.Next() {
		var vm softwareComponentVM
		if err := rows.Scan(&vm.ID, &vm.Name, &vm.Hostname, &vm.Environment, &vm.IP, &vm.PowerState, &vm.Services, &vm.Raw); err != nil {
			return nil, err
		}
		out = append(out, vm)
	}
	return out, rows.Err()
}

func identifyDatabaseComponent(engine, product string) (softwareComponentDefinition, bool) {
	value := strings.ToLower(strings.TrimSpace(engine + " " + product))
	switch {
	case strings.Contains(value, "postgres"):
		return softwareComponentByKey("postgresql")
	case strings.Contains(value, "mongo"):
		return softwareComponentByKey("mongodb")
	case strings.Contains(value, "mariadb"):
		return softwareComponentByKey("mariadb")
	case strings.Contains(value, "mysql"):
		return softwareComponentByKey("mysql")
	case strings.Contains(value, "oracle"):
		return softwareComponentByKey("oracle")
	case strings.Contains(value, "sqlserver"), strings.Contains(value, "sql server"), strings.Contains(value, "mssql"):
		return softwareComponentByKey("sqlserver")
	default:
		return softwareComponentDefinition{}, false
	}
}

func identifyWebComponent(engine, product string) (softwareComponentDefinition, bool) {
	value := strings.ToLower(strings.TrimSpace(engine + " " + product))
	switch {
	case strings.Contains(value, "nginx"):
		return softwareComponentByKey("nginx")
	case strings.Contains(value, "haproxy"):
		return softwareComponentByKey("haproxy")
	case strings.Contains(value, "apache"), containsComponentToken(value, "httpd"):
		return softwareComponentByKey("apache")
	case strings.Contains(value, " iis"), strings.HasPrefix(value, "iis"), strings.Contains(value, "internet information services"):
		return softwareComponentByKey("iis")
	default:
		return softwareComponentDefinition{}, false
	}
}

func identifySoftwareComponent(value string) (softwareComponentDefinition, bool) {
	normalized := normalizeComponentText(value)
	if normalized == "" {
		return softwareComponentDefinition{}, false
	}
	// Order matters for names where one product can contain another generic token
	// (MariaDB before MySQL; OpenSearch before generic search tooling, etc.).
	for _, def := range softwareComponentCatalog {
		for _, needle := range def.Needles {
			if componentNeedleMatches(normalized, needle) {
				if componentMatchIsNoise(def, normalized) {
					continue
				}
				return def, true
			}
		}
	}
	return softwareComponentDefinition{}, false
}

func componentMatchIsNoise(def softwareComponentDefinition, normalized string) bool {
	// Client libraries/exporters should not answer a question such as "which VM
	// runs PostgreSQL?" with a false positive. Dedicated collectors and actual
	// server services still detect the component when it is really present.
	if def.Category == "Baze de date" {
		for _, token := range []string{"exporter", "client", "jdbc", "odbc", "driver", "connector", "devel", "dev package"} {
			if strings.Contains(normalized, token) {
				return true
			}
		}
	}
	if def.Key == "prometheus" && strings.Contains(normalized, "exporter") {
		return true
	}
	return false
}

func softwareComponentByKey(key string) (softwareComponentDefinition, bool) {
	for _, def := range softwareComponentCatalog {
		if def.Key == key {
			return def, true
		}
	}
	return softwareComponentDefinition{}, false
}

func normalizeComponentText(value string) string {
	var b strings.Builder
	lastSpace := true
	for _, r := range strings.ToLower(value) {
		if unicode.IsLetter(r) || unicode.IsDigit(r) || r == '.' || r == '_' || r == '-' {
			b.WriteRune(r)
			lastSpace = false
			continue
		}
		if !lastSpace {
			b.WriteByte(' ')
			lastSpace = true
		}
	}
	return strings.TrimSpace(b.String())
}

func componentNeedleMatches(normalized, needle string) bool {
	needle = normalizeComponentText(needle)
	if needle == "" {
		return false
	}
	if strings.Contains(normalized, needle) {
		// Short/generic runtime names need token-ish boundaries to avoid examples
		// such as php-like text embedded in unrelated package names.
		if len(needle) <= 3 || needle == "jdk" || needle == "jre" {
			return containsComponentToken(normalized, needle)
		}
		return true
	}
	return false
}

func containsComponentToken(value, token string) bool {
	for _, field := range strings.FieldsFunc(value, func(r rune) bool {
		return !(unicode.IsLetter(r) || unicode.IsDigit(r))
	}) {
		if field == token {
			return true
		}
		if strings.HasPrefix(field, token) && len(field) > len(token) {
			next := rune(field[len(token)])
			if unicode.IsDigit(next) {
				return true
			}
		}
	}
	return false
}

func versionFromContainerImage(image string) string {
	image = strings.TrimSpace(image)
	if image == "" {
		return ""
	}
	// Remove digest first. A registry port belongs before the final slash and is
	// therefore not mistaken for an image tag.
	if at := strings.Index(image, "@"); at >= 0 {
		image = image[:at]
	}
	lastSlash := strings.LastIndex(image, "/")
	lastColon := strings.LastIndex(image, ":")
	if lastColon > lastSlash {
		return cleanComponentVersion(image[lastColon+1:])
	}
	return ""
}

func cleanComponentVersion(value string) string {
	value = strings.TrimSpace(value)
	if value == "" || strings.EqualFold(value, "latest") || strings.EqualFold(value, "unknown") || value == "-" {
		return ""
	}
	if len(value) > 255 {
		value = value[:255]
	}
	return value
}

func firstComponentText(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}

func sortedComponentValues(values map[string]bool, numeric bool) []string {
	out := make([]string, 0, len(values))
	for value := range values {
		if strings.TrimSpace(value) != "" {
			out = append(out, value)
		}
	}
	sort.SliceStable(out, func(i, j int) bool {
		if numeric {
			return naturalComponentLess(out[i], out[j])
		}
		return strings.ToLower(out[i]) < strings.ToLower(out[j])
	})
	return out
}

func naturalComponentLess(a, b string) bool {
	// A small natural comparator is sufficient for version labels and keeps the
	// report useful for values such as 8.4, 14.11 and 26.5.7.
	aParts, bParts := strings.FieldsFunc(strings.ToLower(a), func(r rune) bool { return r == '.' || r == '-' || r == '_' || r == '+' }), strings.FieldsFunc(strings.ToLower(b), func(r rune) bool { return r == '.' || r == '-' || r == '_' || r == '+' })
	for i := 0; i < len(aParts) && i < len(bParts); i++ {
		if aParts[i] == bParts[i] {
			continue
		}
		var ai, bi int
		_, aErr := fmt.Sscanf(aParts[i], "%d", &ai)
		_, bErr := fmt.Sscanf(bParts[i], "%d", &bi)
		if aErr == nil && bErr == nil && ai != bi {
			return ai < bi
		}
		return aParts[i] < bParts[i]
	}
	if len(aParts) != len(bParts) {
		return len(aParts) < len(bParts)
	}
	return strings.ToLower(a) < strings.ToLower(b)
}

func sortSoftwareComponentRows(rows []softwareComponentReportRow) {
	sort.SliceStable(rows, func(i, j int) bool {
		a, b := rows[i], rows[j]
		if strings.ToLower(a.Category) != strings.ToLower(b.Category) {
			return strings.ToLower(a.Category) < strings.ToLower(b.Category)
		}
		if strings.ToLower(a.ComponentName) != strings.ToLower(b.ComponentName) {
			return strings.ToLower(a.ComponentName) < strings.ToLower(b.ComponentName)
		}
		if supportEnvironmentRank(a.Environment) != supportEnvironmentRank(b.Environment) {
			return supportEnvironmentRank(a.Environment) < supportEnvironmentRank(b.Environment)
		}
		return strings.ToLower(a.VMName) < strings.ToLower(b.VMName)
	})
}

func summarizeSoftwareComponentRows(rows []softwareComponentReportRow) softwareComponentReportSummary {
	components := map[string]bool{}
	versions := map[string]bool{}
	vms := map[int64]bool{}
	for _, row := range rows {
		components[row.ComponentKey] = true
		vms[row.VMID] = true
		for _, version := range row.Versions {
			versions[row.ComponentKey+"\x00"+strings.ToLower(strings.TrimSpace(version))] = true
		}
	}
	return softwareComponentReportSummary{Components: len(components), Versions: len(versions), Installations: len(rows), VMs: len(vms)}
}

func countSoftwareComponents(rows []softwareComponentReportRow) []softwareComponentCount {
	type counter struct {
		def softwareComponentCount
		vms map[int64]bool
	}
	values := map[string]*counter{}
	for _, row := range rows {
		item := values[row.ComponentKey]
		if item == nil {
			item = &counter{def: softwareComponentCount{Key: row.ComponentKey, Name: row.ComponentName, Category: row.Category}, vms: map[int64]bool{}}
			values[row.ComponentKey] = item
		}
		item.vms[row.VMID] = true
	}
	out := make([]softwareComponentCount, 0, len(values))
	for _, item := range values {
		item.def.VMs = len(item.vms)
		out = append(out, item.def)
	}
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].VMs != out[j].VMs {
			return out[i].VMs > out[j].VMs
		}
		return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name)
	})
	return out
}

func filterSoftwareComponentRows(rows []softwareComponentReportRow, q, component, category, version, environment string) []softwareComponentReportRow {
	q, component, category, version, environment = strings.ToLower(strings.TrimSpace(q)), strings.ToLower(strings.TrimSpace(component)), strings.ToLower(strings.TrimSpace(category)), strings.ToLower(strings.TrimSpace(version)), strings.ToLower(strings.TrimSpace(environment))
	out := make([]softwareComponentReportRow, 0, len(rows))
	for _, row := range rows {
		if component != "" && strings.ToLower(row.ComponentKey) != component && strings.ToLower(row.ComponentName) != component {
			continue
		}
		if category != "" && strings.ToLower(row.Category) != category {
			continue
		}
		if environment != "" && strings.ToLower(row.Environment) != environment {
			continue
		}
		if version != "" {
			matched := false
			for _, candidate := range row.Versions {
				if strings.EqualFold(strings.TrimSpace(candidate), version) || strings.HasPrefix(strings.ToLower(strings.TrimSpace(candidate)), version) {
					matched = true
					break
				}
			}
			if !matched {
				continue
			}
		}
		if q != "" {
			haystack := strings.ToLower(strings.Join([]string{row.ComponentKey, row.ComponentName, row.Category, row.Version, row.Environment, row.VMName, row.Hostname, row.IP, row.PowerState, row.Status, row.Source, strings.Join(row.Evidence, " "), row.Services}, " "))
			if !strings.Contains(haystack, q) {
				continue
			}
		}
		out = append(out, row)
	}
	return out
}

func (a *App) exportReportSoftwareComponents(w http.ResponseWriter, r *http.Request) {
	value, err := a.softwareComponentReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	items := filterSoftwareComponentRows(value.Rows,
		r.URL.Query().Get("q"), r.URL.Query().Get("component"), r.URL.Query().Get("category"),
		r.URL.Query().Get("version"), r.URL.Query().Get("environment"))
	rows := [][]xlsx.Cell{{
		xlsx.Text("Componentă"), xlsx.Text("Categorie"), xlsx.Text("Versiune"), xlsx.Text("VM"), xlsx.Text("Hostname"), xlsx.Text("IP"), xlsx.Text("Power"), xlsx.Text("Mediu"), xlsx.Text("Stare"), xlsx.Text("Servicii / proiecte"), xlsx.Text("Surse detectare"), xlsx.Text("Dovezi"),
	}}
	for _, item := range items {
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(item.ComponentName), xlsx.Text(item.Category), xlsx.Text(item.Version), xlsx.Text(item.VMName), xlsx.Text(item.Hostname), xlsx.Text(item.IP), xlsx.Text(item.PowerState), xlsx.Text(item.Environment), xlsx.Text(item.Status), xlsx.Text(item.Services), xlsx.Text(item.Source), xlsx.Text(strings.Join(item.Evidence, "; ")),
		})
	}
	if err := writeXLSXResponse(w, "Inventar componente software", "componente-software", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write software components report XLSX", "error", err)
	}
}
