#!/usr/bin/env bash
# Organize historical release docs and archive nested, obsolete Go source trees.
# Dry-run by default. Never touches vendor/, migrations/, configs/, deploy/ or runtime data.
set -euo pipefail

usage() {
  cat <<'HELP'
VM-DOC — source tree cleanup (safe, idempotent)
Usage: bash scripts/cleanup-source-tree.sh [--dry-run | --check | --apply]
  --dry-run  (default) Show changes without touching files.
  --check   Exit 2 if legacy release docs or nested versioned sources remain.
  --apply   Move release docs to docs/history/; archive nested source trees
            outside the active project. Existing history duplicates are removed
            ONLY after a byte-for-byte cmp. Nothing is permanently deleted from
            nested source trees.
Set VM_DOC_ARCHIVE_DIR to change the external archive directory.
HELP
}
mode=dry-run
if [[ $# -gt 1 ]]; then usage; exit 2; fi
if [[ $# -eq 1 ]]; then
  case "$1" in
    --dry-run) mode=dry-run ;;
    --check) mode=check ;;
    --apply) mode=apply ;;
    -h|--help) usage; exit 0 ;;
    *) usage; exit 2 ;;
  esac
fi
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
[[ -f "$root/go.mod" && -f "$root/VERSION" && -d "$root/internal" ]] || {
  echo 'ERROR: script must be inside a VM-DOC Server source tree' >&2; exit 2;
}
archive="${VM_DOC_ARCHIVE_DIR:-$(dirname -- "$root")/_vm-doc-archived-sources/$(basename -- "$root")}" 
if [[ "$archive" == "$root" || "$archive" == "$root/"* ]]; then
  echo "ERROR: archive directory must be outside the active Go source tree" >&2; exit 2
fi
shopt -s nullglob
upgrade_files=("$root"/UPGRADE-*.md)
release_files=("$root"/RELEASE-NOTES-*.txt)
verification_files=("$root"/VERIFICATION-*.md)
old_sources=()
for candidate in "$root"/vm-doc-server-*; do
  [[ -d "$candidate" && ! -L "$candidate" ]] || continue
  b="$(basename -- "$candidate")"
  if [[ "$b" =~ ^vm-doc-server-[0-9]+\.[0-9]+\.[0-9]+$ ]] && \
    [[ -f "$candidate/go.mod" || -d "$candidate/cmd/vm-doc-server" ]]; then
    old_sources+=("$candidate")
  fi
done
printf 'VM-DOC %s: historical files: %d upgrades, %d release notes, %d verification notes; nested Go projects: %d\n' \
  "$mode" "${#upgrade_files[@]}" "${#release_files[@]}" "${#verification_files[@]}" "${#old_sources[@]}"
for dir in "${old_sources[@]}"; do printf '  OLD PROJECT: %s\n' "$dir"; done
if [[ "$mode" == check ]]; then
  if (( ${#upgrade_files[@]} + ${#release_files[@]} + ${#verification_files[@]} + ${#old_sources[@]} > 0 )); then
    echo 'Source layout needs cleanup: run --dry-run, then --apply.' >&2
    exit 2
  fi
  echo 'Source layout OK.'
  exit 0
fi
if [[ "$mode" == dry-run ]]; then
  printf 'Would organize docs into %s/docs/history and archive old projects into %s\n' "$root" "$archive"
  echo 'No files changed. Run with --apply to perform the cleanup.'
  exit 0
fi
# Preflight all conflicts before changing even one file.
for category in upgrades release-notes verification; do
  case "$category" in
    upgrades) originals=("${upgrade_files[@]}") ;;
    release-notes) originals=("${release_files[@]}") ;;
    verification) originals=("${verification_files[@]}") ;;
  esac
  for source in "${originals[@]}"; do
    target="$root/docs/history/$category/$(basename -- "$source")"
    if [[ -e "$target" ]] && ! cmp -s -- "$source" "$target"; then
      echo "ERROR: conflicting file, no changes made: $source" >&2
      exit 1
    fi
  done
done
for candidate in "${old_sources[@]}"; do
  dest="$archive/$(basename -- "$candidate")"
  if [[ -e "$dest" ]]; then
    echo "ERROR: archive already exists, no changes made: $dest" >&2
    exit 1
  fi
done
organize_files() {
  local category="$1" src target
  shift
  local -a files=("$@")
  ((${#files[@]})) || return 0
  mkdir -p -- "$root/docs/history/$category"
  for src in "${files[@]}"; do
    target="$root/docs/history/$category/$(basename -- "$src")"
    if [[ -e "$target" ]]; then
      if cmp -s -- "$src" "$target"; then
        # Exact duplicate already archived by the update package.
        rm -- "$src"
      else
        echo "ERROR: history version conflict; preserving original file: $src" >&2
        return 1
      fi
    else
      mv -- "$src" "$target"
    fi
  done
  printf 'Organized %d %s files.\n' "${#files[@]}" "$category"
}
organize_files upgrades "${upgrade_files[@]}"
organize_files release-notes "${release_files[@]}"
organize_files verification "${verification_files[@]}"
for candidate in "${old_sources[@]}"; do
  dest="$archive/$(basename -- "$candidate")"
  if [[ -e "$dest" ]]; then
    echo "ERROR: archive already exists; not overwriting: $dest" >&2
    exit 1
  fi
  mkdir -p -- "$archive"
  mv -- "$candidate" "$dest"
  printf 'Archived old source tree: %s -> %s\n' "$candidate" "$dest"
done
echo 'Cleanup complete. No vendor/, migrations/, configurations or active source files modified.'
