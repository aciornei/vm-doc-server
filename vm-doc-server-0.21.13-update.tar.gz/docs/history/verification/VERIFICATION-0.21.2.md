# VM-DOC Server 0.21.2 — verificări

Efectuate în mediul de împachetare:
- Parsare sintactică a surselor Go și gofmt pe fișierele modificate.
- `node --check web/static/js/app.js`: OK.
- OpenAPI 3.1 YAML: OK.
- `go test ./internal/xlsx`: OK.
- Integritate ZIP/TAR și test patch -p1 peste 0.21.1: OK, rezultate identice byte-cu-byte.
- Teste de regresie pentru mapping-ul MariaDB / identitate versiune au fost adăugate, dar nu au fost executate aici (necesită `vendor/`).

Nevalidate aici:
- Compilarea întregului server și testele unitare ale pachetului server (lipsește `vendor/` din arhiva sursă încărcată).
- Endpointurile pe date reale MariaDB/AD și testele vizuale în browser pe un server funcțional.

Nu există migrare SQL pentru 0.21.2. Aplicați mai întâi în staging.
