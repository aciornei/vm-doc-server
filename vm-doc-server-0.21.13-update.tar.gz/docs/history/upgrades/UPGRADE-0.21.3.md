# VM-DOC Server 0.21.2 → 0.21.3

## Modificări

- În fișa VM, Beneficiari se găsește în **Operațional → Responsabilități**, sub lista **Persoane**. Eliminat cardul separat de sus. Resursele fără servicii inventariate (de exemplu un file server) pot avea beneficiari direct pe VM.
- Raportul Beneficiari: selectare **Toate departamentele**, posibilitatea includerii sub-OU-urilor la selectarea unui singur departament, fără categoria **Componente suport** în acest raport. Componente software rămâne distinctă.
- Listele Docker/Baze/Web: în locul controalelor repetate pe fiecare rând se afișează starea documentării, serviciile / mediile / statusurile / tipurile de soluție concatenate și beneficiarii. Butonul **Configurează** deschide un dialog unic cu setările existente.
- Export XLSX pentru fiecare dintre cele trei inventare VM.
- Optimizarea încărcării: citire beneficiari în lot, încărcare condiționată a datelor auxiliare și cache scurt pentru vizualizările VM. Nu există garanții de timp de răspuns fără profilare pe infrastructura reală.
- Actualizare OpenAPI/Swagger pentru endpointurile noi și parametrii de raport.
- `index.html` referă explicit `app.css?v=0.21.3` și `app.js?v=0.21.3`, pentru invalidarea cache-ului vechi (`v=0.21.1`).

## Upgrade offline

Se aplică peste sursele funcționale **0.21.2**, păstrând `vendor/` și configurațiile/secretele locale. Faceți înainte un backup MariaDB și un snapshot / copie de siguranță a codului instalat.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.2 vm-doc-server-0.21.3
tar -xzf /cale/vm-doc-server-0.21.3-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.3
cd /usr/local/src/vm-doc-server-0.21.3
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Dacă comenzile trec, folosiți fluxul local obișnuit pentru înlocuirea binarului și restartarea serviciului. Efectuați `Ctrl+F5` în browser la prima deschidere. **Nu aplicați în producție fără verificare în staging.**

## Verificări după instalare

1. Deschideți un VM → Operațional → Responsabilități: blocul Beneficiari trebuie să fie sub Persoane și să NU existe un card Beneficiari între cardurile de sumar.
2. Rapoarte → Beneficiari: alegeți „Toate departamentele”; nu trebuie să apară „Componente suport” în categoriile rezultatului.
3. În VM → Docker, Baze, Web, verificați rezumatul pe rânduri, beneficiarii vizibili, dialogul „Configurează”, salvarea și persistența asocierii după refresh.
4. Descărcați XLSX separat pentru fiecare tab și verificați coloanele și datele.
5. Verificați selectarea beneficiarilor direct pe VM (inclusiv VM fără Docker/DB/Web).
6. Măsurați timpii reali de răspuns în browser / logurile aplicației; cache-ul reduce apelurile repetate, fără un SLA prestabilit.

## Compatibilitate și limitări de validare

- Nu necesită migrare SQL nouă, schimbare de `go.mod`/`go.sum` sau actualizare vm-doc-agent.
- Au fost validate sintaxa JavaScript și YAML OpenAPI, teste modul XLSX și fluxuri UI în Chromium pe API simulat.
- Compilarea completă a serverului Go și testele de integrare MariaDB/AD/LDAP necesită `vendor/` și servicii care nu au fost disponibile în mediul de creare. Instalați mai întâi într-un mediu de test.
