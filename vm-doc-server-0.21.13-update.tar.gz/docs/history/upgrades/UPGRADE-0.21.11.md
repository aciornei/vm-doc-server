# Upgrade VM-DOC Server 0.21.10 → 0.21.11

**Hotfix de compilare.** Nu adaugă migrare SQL, nu modifică API/Swagger, agentul sau datele. Nu instala binarul nou până când testele și buildul nu au trecut.

## Aplicare offline (recomandat)

1. Salvează sursa curentă și fă backup bazei conform procedurii curente (migrarea 075 aparține versiunii 0.21.10).
2. Creează o copie nouă a arborelui 0.21.10, păstrând directorul `vendor/` și perechea `go.mod` + `go.sum`.
3. Aplică **doar una** dintre metode (update sau patch):

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.10 vm-doc-server-0.21.11
cd vm-doc-server-0.21.11
tar -xzf /cale/vm-doc-server-0.21.11-update.tar.gz -C .
# ALTERNATIV, nu împreună cu arhiva update:
# patch -p1 --dry-run < /cale/vm-doc-server-0.21.10-to-0.21.11.patch
# patch -p1 < /cale/vm-doc-server-0.21.10-to-0.21.11.patch

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./internal/... ./cmd/...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

4. Numai după build reușit, instalează binarul cu procedura ta obișnuită. Verifică `/version` = `0.21.11`, navigarea către Hardening și `releases.json`.
5. La build cu `go test ./...`, asigură-te că nu ai copii ale altor versiuni în interiorul proiectului; păstrează-le în directoare-surori.

## Verificare rapidă

```bash
grep -n 'ExecContext.*UPDATE hardening_' internal/server/hardening.go
cat VERSION
```

## Rollback

Reinstalează binarul server 0.21.10 doar dacă există o problemă de runtime; nu executa migrarea down 075, deoarece ar șterge configurațiile Hardening. Dacă upgradeul eșuează la compilare, nu înlocui binarul curent.

**Limitare:** pachetul a fost verificat structural, nu prin compilare integrală în mediul care a generat arhivele (nu dispune de vendor). Testele complete trebuie rulate în mediul tău.
