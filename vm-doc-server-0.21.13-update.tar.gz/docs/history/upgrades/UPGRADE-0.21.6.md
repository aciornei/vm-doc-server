# Upgrade vm-doc-server 0.21.5 → 0.21.6

Hotfix UI și metadate versiuni. **Fără migrare SQL nouă, fără actualizare agent, fără modificare a `go.mod`, `go.sum` sau `vendor/`.**

## Instalare offline

Se pornește de la directorul sursă 0.21.5 funcțional, cu `vendor/` păstrat:

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.5 vm-doc-server-0.21.6
tar -xzf /cale/vm-doc-server-0.21.6-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.6
cd /usr/local/src/vm-doc-server-0.21.6
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Aplică apoi procedura ta uzuală de înlocuire a binarelor și restart al serviciului. Verifică `/version` pentru `0.21.6` și reîncarcă pagina (Ctrl+F5 dacă e necesar).

## Verificări

1. **Nomenclatoare:** în sidebar, categoria Responsabilități conține în această ordine: Persoane, Beneficiari; Beneficiari nu mai apare sus.
2. **VM → Docker:** bara Nu necesită documentare are checkbox și text compacte.
3. **Proiecte Docker Compose:** toate cele 4 selectoare au înălțimea 42 px și sunt aliniate cu butonul Asociază. Testează și după selecție și salvare.
4. **Releasuri:** în Istoric versiuni apar 0.21.6, 0.21.5, 0.21.4, 0.21.3, 0.21.2, 0.21.1, 0.21.0.
5. **Regresie:** linkurile serviciilor și beneficiarii existenți rămân vizibili; asocierea Compose continuă să funcționeze.

Aceste modificări nu schimbă datele salvate și nu necesită migrare MariaDB.
