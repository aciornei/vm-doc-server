# VM-DOC Server 0.21.8 → 0.21.9

## Inainte de upgrade

1. Efectueaza backup complet al bazei MariaDB si al surselor serverului 0.21.8.
2. Valideaza ca ai 0.21.8 functional si `vendor/` compatibil deja instalat.
3. Testeaza mai intai in staging. Migrarea 074 ruleaza automat la pornire.

## Upgrade offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.8 vm-doc-server-0.21.9
tar -xzf /cale/vm-doc-server-0.21.9-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.9
cd /usr/local/src/vm-doc-server-0.21.9
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Respecta procesul tau existent de oprire a serviciilor, inlocuire a binarului si pornire.
Nu executa `go mod vendor` si nu suprascrie `vendor/` de pe serverul offline.

## Verificari

- Pagina Version arata 0.21.9; JS/CSS folosesc `v=0.21.9`.
- O VM cu agent 1.7.16 si doua containere MongoDB cu 27017 trebuie sa afiseze doua instante DB.
- Origin Docker arata containerul/imaginea/Compose; la MongoDB se vad Replica Set, rol si PRIMARY daca agentul le raporteaza.
- Valorile din `catalog_discovery_status` arata enumerarea reusita/eșuata per instanta.
- Exportul Excel contine aceleasi valori ca lista de instante.
- Agentii 1.7.15, Windows XP si SLES9 raman compatibili; origin poate fi Nespecificat.
- Nomenclatorul de excluderi DB (inclusiv Db2/Redis cand e selectat) trebuie sa ramana functional.

## Rollback

Restabileste binarul si sursele 0.21.8. Coloanele adaugate de migrarea 074 pot ramane
inactiv in DB pana la urmatorul upgrade; nu aplica DOWN daca exista date noi.
Daca este necesar un rollback complet de schema, restaureaza backupul MariaDB.

## Validare

Testele partiale ale modulelor Go, sintaxa JS si OpenAPI pot fi verificate in mediul de build.
Validarea reala MariaDB si testarea cu agentul pe instanta MongoDB SECONDARY necesita infrastructura staging.
