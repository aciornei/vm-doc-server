# Upgrade VM-DOC Server 0.21.9 → 0.21.10

Aceasta este o versiune **de test/staging**. Realizați un backup MariaDB înainte de aplicare.

1. Păstrați `vendor/`, `go.mod`, `go.sum` ale proiectului existent.
2. Aplicați update-ul peste sursele 0.21.9 sau patch-ul (nu amândouă).
3. Compilați offline: `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` apoi `GOPROXY=off GOFLAGS=-mod=vendor make build`.
4. Verificați migrarea `075_hardening_profiles.up.sql` și drepturile DB. Migrarea adaugă doar tabele și setări inițiale; nu șterge date.
5. Restartați serviciul și deschideți Nomenclatoare → Securitate → Hardening și Securitate → Hardening.
6. Testați cu Agent 1.7.18; agenții vechi vor avea în mod normal rezultate `unknown` pentru evidențe noi.

**Nu se efectuează remediere automată.** Reguli interne cu referințe CIS; ID-urile CIS individuale rămân pending până la validare. Este interzisă prezentarea scorului drept certificare CIS.
Rollback: reveniți la binarul anterior; tabelele 075 pot rămâne. Nu executați migrarea down pe producție deoarece elimină configurațiile hardening.
