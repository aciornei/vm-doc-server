# VM-DOC Server 0.21.4 → 0.21.5

## Modificări

1. **Proiecte Docker Compose**: panou colapsabil (inițial restrâns), număr de proiecte în antet, câte un proiect pe rând, selectoare **Serviciu / Mediu / Status operațional / Tip soluție** mai late și buton Asociază pe aceeași linie. La viewporturi înguste se derulează orizontal doar interiorul secțiunii. Starea expand/collapse se păstrează cât timp este deschisă sesiunea paginii.
2. **Servicii clicabile**: numele serviciului din coloana Documentare/Servicii/Beneficiari este link către fișa serviciului. Aceeași regulă se aplică rezumatelor Docker, baze logice, site-uri Web; din cardul Compose sunt disponibile linkurile distincte ale serviciilor asociate containerelor.
3. **Beneficiari sub proiect**: fiecare proiect Compose afișează beneficiarii calculați din containerele acelui proiect. Se folosește aceeași citire în lot deja existentă, fără interogări suplimentare per proiect. Beneficiarii sunt afișați și în tabelul containerelor.
4. **Nomenclatoare/rapoarte**: link mai scurt „Beneficiari”, aliniere, spațiere și wrapping îmbunătățite în sidebar.
5. Asset-urile CSS/JS au query `v=0.21.5` pentru invalidarea cache-ului.

**Nu există migrare SQL.** Nu se modifică agentul, `go.mod`, `go.sum` sau `vendor/`. API-ul/Swagger rămân neschimbate în această versiune exclusiv UI.

## Actualizare offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.4 vm-doc-server-0.21.5
tar -xzf /cale/vm-doc-server-0.21.5-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.5
cd /usr/local/src/vm-doc-server-0.21.5
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Păstrați `vendor/` deja funcțional de pe server. Instalați noul binar și reporniți serviciul numai dacă testele și build-ul reușesc; efectuați Ctrl+F5 în browser după actualizare.

## Verificare funcțională

1. Deschideți VM → Docker. Secțiunea „Proiecte Docker Compose” este inițial restrânsă; un clic o extinde.
2. Verificați că numărul de proiecte din antet este corect și că fiecare rând are patru selectoare plus butonul Asociază pe o singură linie.
3. Selectați un serviciu + mediu + status + tip soluție și asociați un proiect într-un mediu de test; rezultatul trebuie să apară și în tabelul containerelor.
4. În tabel, serviciul asociat trebuie să fie link funcțional către fișa sa. Beneficiarii trebuie afișați sub proiect și în tabel, fără duplicarea aceluiași beneficiar provenit din mai multe containere.
5. Verificați sidebar-ul Nomenclatoare, Raport Beneficiari și versiunea de cache CSS/JS.
6. Verificați comportamentul la lățimi diferite: ecrane înguste au scroll *în interiorul* secțiunii Compose, nu la nivelul întregii pagini.

## Validare în mediul de generare

- `node --check` pentru JS.
- Teste vizuale în Chromium la 1800/1280/900/420 px pe markup-ul generat de funcția reală `dockerVMSection`, cu date simulate, inclusiv colapsare/expandare, rând unic, linkuri și absența overflow-ului paginii.
- Teste `go test ./internal/xlsx` (module fără dependențe externe) și verificare mecanică a pachetelor.
- Compilarea completă Go și testarea integrată cu MariaDB/AD nu sunt validate local; efectuați-le în mediul de test cu `vendor/`.
