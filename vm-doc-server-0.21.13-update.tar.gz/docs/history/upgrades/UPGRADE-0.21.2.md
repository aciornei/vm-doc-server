# VM-DOC Server 0.21.1 → 0.21.2

Actualizare exclusiv server/UI/raportare. **Fără migrare SQL**, fără upgrade de agent, fără modificări `go.mod`, `go.sum` sau `vendor/`.

## Schimbări

- Beneficiarii VM sunt afișați în **Configurare → Operațional → Responsabilități**, imediat sub lista Persoane, nu între cardurile de sumar și navigarea VM.
- Raportul Beneficiari are controale grupate, padding și spațieri consistente, carduri de sumar responsive și tabele cu antet/detalii distincte.
- Raportul include o categorie separată **Componente software**, cu versiuni detectate (de exemplu `MariaDB 10.11.14`), atunci când o bază logică a acelui motor este asociată direct unui beneficiar.
- Componentele software se calculează strict pe baza resursei DB și a motorului ei, pe același VM; nu se transmit beneficiari către alte motoare de pe VM.
- Excel: o foaie nouă `Componente software` și coloane suplimentare `Componentă` / `Versiune`, cu proveniență explicită din baza care justifică asocierea. Rezultă **8 foi** inclusiv `Sumar`.
- Documentația OpenAPI este actualizată. Ruta /api/v1/reports/beneficiaries și exportul își păstrează parametrii existenți.

## Instalare offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.1 vm-doc-server-0.21.2
tar -xzf /cale/vm-doc-server-0.21.2-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.2
cd /usr/local/src/vm-doc-server-0.21.2
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Nu instala noul binar dacă testele sau compilarea eșuează. Folosește procedura de înlocuire binar și restart deja aplicată în mediul tău. În browser: Ctrl+F5.

## Verificări după instalare

1. VM → Configurare → Operațional: secțiunea Beneficiari apare **sub Persoane**, în Responsabilități. Nu mai apare cardul separat sub sumarul VM.
2. Editează beneficiarul VM din noua poziție; verifică salvarea, reîncărcarea, compatibilitatea cu persoanele responsabile.
3. Rapoarte → Beneficiari: tabel și filtre încadrate corect la lățimi diferite; totaluri și detalii coerente.
4. Pentru o bază MariaDB asociată departamentului X: în `Baze de date` se vede baza, iar în `Componente software` se vede `MariaDB <versiune>` pe VM-ul acelei baze. Coloana Proveniență arată numele bazei.
5. Pentru două baze ale aceluiași MariaDB/versiune pe același VM: totalul componentelor software este **1**, dar se pot vedea ambele justificări.
6. O altă bază ori motor de pe VM, fără asociere la X, nu trebuie să fie atribuit automat departamentului X.
7. Export Excel: 8 foi (Sumar + Servicii + Componente suport + Componente software + Baze + Web + Docker + VM), cu versiunile și proveniența raportate.
8. Documentația Swagger/OpenAPI este actualizată.

## Limitări verificare

Testele end-to-end cu AD/MariaDB și compilarea întregului server nu au fost posibile în mediul de împachetare (arhiva surselor nu include `vendor/`). Actualizarea nu necesită migrare de date. Se recomandă mai întâi staging.
