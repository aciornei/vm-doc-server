# VM-DOC Server 0.21.12 → 0.21.13

**Scop:** numai curățarea structurii surselor și istoricului release-urilor. Nu modifică logica aplicației, baza de date, API/Swagger, agenții sau schema inventar.

## Recomandat: folosește director nou și păstrează vendor/

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.12 vm-doc-server-0.21.13
cd vm-doc-server-0.21.13

# Aplică DOAR una dintre metode:
# Metoda A — update peste vechea sursă:
tar -xzf /cale/vm-doc-server-0.21.13-update.tar.gz -C .
# Metoda B — patch, alternativă:
# patch -p1 --dry-run < /cale/vm-doc-server-0.21.12-to-0.21.13.patch
# patch -p1 < /cale/vm-doc-server-0.21.12-to-0.21.13.patch

# Inspecție non-distructivă — NU execută modificări:
bash scripts/cleanup-source-tree.sh --dry-run

# Aplică organizarea: arhivează sursele vechi imbricate în afara proiectului
# și elimină duplicatele de documente numai dacă au conținut IDENTIC:
bash scripts/cleanup-source-tree.sh --apply
bash scripts/cleanup-source-tree.sh --check

# Verifică înainte de a instala binarul:
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Scriptul `cleanup-source-tree.sh` **nu șterge copiile vechi de surse**: le mută în `../_vm-doc-archived-sources/vm-doc-server-0.21.13/` (sau în locația definită de `VM_DOC_ARCHIVE_DIR`). `--dry-run` este implicit. Fișierele `vendor/`, `migrations/`, `configs/`, `deploy/`, aplicația și datele runtime nu sunt modificate.

**Important:** update-ul TAR este de tip overlay și **nu poate șterge** fișierele UPGRADE/RELEASE-NOTES deja existente în rădăcină. De aceea, după extragere trebuie executat scriptul `--apply`. Patch-ul include mutările explicite, iar rularea scriptului rămâne necesară dacă sursele vechi sunt imbricate.

## Dacă preferi sursele complete (ZIP)

Dezarhivează `vm-doc-server-0.21.13-source.zip` într-un director nou. Apoi copiază `vendor/` din versiunea care compila anterior. **Nu înlocui configurațiile/secretele instalate.** Testează înainte de instalare.

## Verificări și compatibilitate

- `go.mod`, `go.sum`, API, migrarea `075`, UI funcțional și agentul 1.7.18 sunt **neschimbate**.
- `Makefile` verifică structura prin `scripts/cleanup-source-tree.sh --check` înainte de `make test`/`make build`.
- În cazul în care versiunea curentă din producție este 0.21.12, doar codul compilat poate fi înlocuit după test. Nu este necesar rollback DB.
- Căutare în istoricul release-urilor: `docs/history/INDEX.md`.

## Rollback

Dacă orice verificare eșuează, păstrează binarul anterior 0.21.12 și revino la directorul sursă anterior. Copiile istorice mutate există în directorul de arhivare; nu sunt șterse permanent. `vendor/` rămâne neschimbat.
