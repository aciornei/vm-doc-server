VM-DOC Server 0.21.55 - incremental over 0.21.54.
Full source, update archive, patch, cumulative manual PREVIEW/CLEANUP SQL, CONTEXT/CHANGELOG/TODO, upgrade/rollback notes and SHA256 checksums.
Change tracking: ignore Windows SCM DisplayName-only differences; real service events preserved. Raw agent inventory unchanged. Agent 1.7.18.
Use staging and backup before SQL. Build with vendor/ on offline build server.
