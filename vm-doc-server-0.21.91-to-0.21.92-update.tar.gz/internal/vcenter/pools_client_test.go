package vcenter

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
	"vm-doc-server/internal/domain"
)

func TestPoolInventoryExcludesAndPreservesPoweredOnWarning(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/session", func(w http.ResponseWriter, r *http.Request) { _ = json.NewEncoder(w).Encode("session") })
	mux.HandleFunc("DELETE /api/session", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusNoContent) })
	mux.HandleFunc("GET /api/vcenter/resource-pool/{pool}", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{"resource_pools": []string{}})
	})
	mux.HandleFunc("GET /api/vcenter/resource-pool", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]map[string]string{{"resource_pool": "resgroup-1", "name": "ACTIVE"}, {"resource_pool": "resgroup-2", "name": "QUARANTINE"}})
	})
	mux.HandleFunc("GET /api/vcenter/vm", func(w http.ResponseWriter, r *http.Request) {
		var list []map[string]any
		switch r.URL.Query().Get("resource_pools") {
		case "resgroup-1":
			list = []map[string]any{{"vm": "vm-1", "name": "GOOD", "power_state": "POWERED_ON"}}
		case "resgroup-2":
			list = []map[string]any{{"vm": "vm-2", "name": "OLD", "power_state": "POWERED_ON"}}
		default:
			list = []map[string]any{{"vm": "vm-1", "name": "GOOD", "power_state": "POWERED_ON"}, {"vm": "vm-2", "name": "OLD", "power_state": "POWERED_ON"}}
		}
		_ = json.NewEncoder(w).Encode(list)
	})
	mux.HandleFunc("GET /api/vcenter/vm/vm-1", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{"identity": map[string]any{"name": "GOOD"}, "power_state": "POWERED_ON"})
	})
	mux.HandleFunc("GET /api/vcenter/vm/vm-2", func(w http.ResponseWriter, r *http.Request) {
		t.Error("excluded VM details must not be requested")
		http.Error(w, "should not load", 500)
	})
	server := httptest.NewServer(mux)
	defer server.Close()
	client, err := NewClient(domain.VCenterSource{BaseURL: server.URL, VerifyTLS: false}, "", 5*time.Second, 2)
	if err != nil {
		t.Fatal(err)
	}
	vms, pools, err := client.InventoryWithPools(context.Background(), map[string]bool{"resgroup-1": true, "resgroup-2": false})
	if err != nil {
		t.Fatal(err)
	}
	if len(vms) != 2 || vms[0].ResourcePoolID != "resgroup-1" || vms[1].ResourcePoolID != "resgroup-2" {
		t.Fatalf("wrong placement: %#v", vms)
	}
	if vms[1].InstanceUUID != "" || vms[1].PowerState != "POWERED_ON" {
		t.Fatalf("excluded VM should have only a summary: %+v", vms[1])
	}
	if len(pools) != 2 || pools[1].PoweredOnCount != 1 {
		t.Fatalf("missing powered on warning: %+v", pools)
	}
}

func TestPoolInventoryImportsUnmappedVMWithExcludedPool(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/session", func(w http.ResponseWriter, r *http.Request) { _ = json.NewEncoder(w).Encode("session") })
	mux.HandleFunc("DELETE /api/session", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(204) })
	mux.HandleFunc("GET /api/vcenter/resource-pool/{pool}", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{"resource_pools": []string{}})
	})
	mux.HandleFunc("GET /api/vcenter/resource-pool", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]map[string]string{{"resource_pool": "resgroup-2", "name": "ARCHIVE"}})
	})
	mux.HandleFunc("GET /api/vcenter/vm", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("resource_pools") != "" {
			_ = json.NewEncoder(w).Encode([]map[string]any{{"vm": "vm-excluded", "name": "ARCHIVED", "power_state": "POWERED_ON"}})
			return
		}
		_ = json.NewEncoder(w).Encode([]map[string]any{
			{"vm": "vm-excluded", "name": "ARCHIVED", "power_state": "POWERED_ON"},
			{"vm": "vm-3", "name": "NEW-ROOT", "power_state": "POWERED_ON"},
		})
	})
	var unmappedReads int
	mux.HandleFunc("GET /api/vcenter/vm/vm-3", func(w http.ResponseWriter, r *http.Request) {
		unmappedReads++
		_ = json.NewEncoder(w).Encode(map[string]any{"identity": map[string]any{"name": "NEW-ROOT", "instance_uuid": "uuid-3"}, "power_state": "POWERED_ON"})
	})
	mux.HandleFunc("GET /api/vcenter/vm/vm-excluded", func(w http.ResponseWriter, r *http.Request) {
		t.Error("excluded VM details must not be requested")
		http.Error(w, "not allowed", 500)
	})
	server := httptest.NewServer(mux)
	defer server.Close()
	client, err := NewClient(domain.VCenterSource{BaseURL: server.URL}, "", 5*time.Second, 1)
	if err != nil {
		t.Fatal(err)
	}

	// First discovery has no saved choice for the new bucket: include by default.
	vms, pools, err := client.InventoryWithPools(context.Background(), map[string]bool{"resgroup-2": false})
	if err != nil {
		t.Fatal(err)
	}
	if len(vms) != 2 || vms[0].ResourcePoolID != "resgroup-2" || vms[1].ResourcePoolID != unassignedPoolMoID || vms[1].InstanceUUID != "uuid-3" {
		t.Fatalf("unmapped VM not imported or excluded pool bypassed: %+v", vms)
	}
	if unmappedReads != 1 {
		t.Fatalf("unmapped VM details not read: %d", unmappedReads)
	}
	var found bool
	for _, p := range pools {
		if p.MoID == unassignedPoolMoID {
			found = true
			if p.VMCount != 1 || p.PoweredOnCount != 1 {
				t.Fatalf("bad unmapped counts: %+v", p)
			}
		}
	}
	if !found {
		t.Fatalf("missing unassigned bucket: %+v", pools)
	}

	// User explicitly excludes the synthetic bucket: don't fetch details.
	vms, _, err = client.InventoryWithPools(context.Background(), map[string]bool{"resgroup-2": false, unassignedPoolMoID: false})
	if err != nil {
		t.Fatal(err)
	}
	if vms[1].ResourcePoolID != unassignedPoolMoID || vms[1].InstanceUUID != "" || unmappedReads != 1 {
		t.Fatalf("unmapped exclusion ignored: %+v, details calls=%d", vms, unmappedReads)
	}
}

func TestPoolDiscoveryUnassignedAbsentWhenNoUnmappedVMs(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/session", func(w http.ResponseWriter, r *http.Request) { _ = json.NewEncoder(w).Encode("session") })
	mux.HandleFunc("DELETE /api/session", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(204) })
	mux.HandleFunc("GET /api/vcenter/resource-pool", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]map[string]string{{"resource_pool": "resgroup-1", "name": "Resources"}})
	})
	mux.HandleFunc("GET /api/vcenter/resource-pool/{pool}", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{"resource_pools": []string{}})
	})
	mux.HandleFunc("GET /api/vcenter/vm", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]map[string]any{{"vm": "vm-1", "name": "NORMAL"}})
	})
	ts := httptest.NewServer(mux)
	defer ts.Close()
	client, err := NewClient(domain.VCenterSource{BaseURL: ts.URL}, "", 5*time.Second, 2)
	if err != nil {
		t.Fatal(err)
	}
	pools, assigned, err := client.PoolDiscovery(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if len(pools) != 1 || assigned["vm-1"] != "resgroup-1" {
		t.Fatalf("expected only real pool: %+v / %+v", pools, assigned)
	}
}

func TestPoolDiscoveryResolvesHierarchyByMoRef(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/session", func(w http.ResponseWriter, r *http.Request) { _ = json.NewEncoder(w).Encode("session") })
	mux.HandleFunc("DELETE /api/session", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(204) })
	mux.HandleFunc("GET /api/vcenter/resource-pool", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]map[string]string{
			{"resource_pool": "resgroup-1", "name": "Resources"}, {"resource_pool": "resgroup-2", "name": "Archive"}, {"resource_pool": "resgroup-3", "name": "Archive"},
		})
	})
	mux.HandleFunc("GET /api/vcenter/resource-pool/{pool}", func(w http.ResponseWriter, r *http.Request) {
		children := []string{}
		if r.PathValue("pool") == "resgroup-1" {
			children = []string{"resgroup-2"}
		}
		if r.PathValue("pool") == "resgroup-2" {
			children = []string{"resgroup-3"}
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"resource_pools": children})
	})
	mux.HandleFunc("GET /api/vcenter/vm", func(w http.ResponseWriter, r *http.Request) { _ = json.NewEncoder(w).Encode([]any{}) })
	ts := httptest.NewServer(mux)
	defer ts.Close()
	client, err := NewClient(domain.VCenterSource{BaseURL: ts.URL}, "", 5*time.Second, 2)
	if err != nil {
		t.Fatal(err)
	}
	pools, _, err := client.PoolDiscovery(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	parents := map[string]string{}
	for _, p := range pools {
		parents[p.MoID] = p.ParentMoID
	}
	if parents["resgroup-1"] != "" || parents["resgroup-2"] != "resgroup-1" || parents["resgroup-3"] != "resgroup-2" {
		t.Fatalf("incorrect hierarchy: %+v", parents)
	}
}

func TestPoolDiscoveryWithoutAnyListedPools(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/session", func(w http.ResponseWriter, r *http.Request) { _ = json.NewEncoder(w).Encode("session") })
	mux.HandleFunc("DELETE /api/session", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(204) })
	mux.HandleFunc("GET /api/vcenter/resource-pool", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]any{})
	})
	mux.HandleFunc("GET /api/vcenter/vm", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]map[string]any{{"vm": "vm-4", "name": "STANDALONE", "power_state": "POWERED_OFF"}})
	})
	ts := httptest.NewServer(mux)
	defer ts.Close()
	client, err := NewClient(domain.VCenterSource{BaseURL: ts.URL}, "", 5*time.Second, 1)
	if err != nil {
		t.Fatal(err)
	}
	pools, placement, err := client.PoolDiscovery(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if len(pools) != 1 || pools[0].MoID != unassignedPoolMoID || pools[0].VMCount != 1 || pools[0].PoweredOnCount != 0 || placement["vm-4"] != unassignedPoolMoID {
		t.Fatalf("unexpected standalone classification: %+v / %+v", pools, placement)
	}
}

func TestPoolDiscoveryFailsClosedOnPoolEndpointError(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/session", func(w http.ResponseWriter, r *http.Request) { _ = json.NewEncoder(w).Encode("session") })
	mux.HandleFunc("DELETE /api/session", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(204) })
	mux.HandleFunc("GET /api/vcenter/resource-pool", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode([]map[string]string{{"resource_pool": "resgroup-1", "name": "SECURE"}})
	})
	mux.HandleFunc("GET /api/vcenter/resource-pool/{pool}", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{"resource_pools": []string{}})
	})
	mux.HandleFunc("GET /api/vcenter/vm", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("resource_pools") != "" {
			http.Error(w, "not permitted", http.StatusForbidden)
			return
		}
		_ = json.NewEncoder(w).Encode([]map[string]any{{"vm": "vm-1"}})
	})
	ts := httptest.NewServer(mux)
	defer ts.Close()
	client, err := NewClient(domain.VCenterSource{BaseURL: ts.URL}, "", 5*time.Second, 1)
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err := client.PoolDiscovery(context.Background()); err == nil {
		t.Fatal("failed pool membership endpoint must abort sync, not mark VM unassigned")
	}
}
