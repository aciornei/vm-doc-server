# VM-DOC Server 0.21.92 — 2026-11-02

## Scop
Importarea VM-urilor noi prezente în `/api/vcenter/vm` care nu apar în nicio listă filtrată `resource_pools`. În vSphere, o VM aparține de regulă pool-ului implicit al hostului/clusterului, însă asocierea poate să nu fie disponibilă în REST.

## Schimbări
- Descoperirea folosește o singură sesiune VCSA pentru lista generală și listele filtrate după pool; pentru VM-urile fără corespondență se creează categoria virtuală `vm-doc:unassigned` / „Fără pool identificat (VCSA)”.
- Categoria este inclusă **implicit**, dacă nu există deja o selecție salvată. Utilizatorul o poate debifa în `Surse & sincronizări → vCenter → Resource pool-uri` ca pe orice altă categorie. Este creată numai când există VM-uri neclasificate și păstrează opțiunea aleasă la viitoarele sincronizări.
- VM-urile din pool-uri explicit excluse rămân excluse. Cele vechi rămân în DB, fără a fi șterse/retirate automat; cele noi excluse nu sunt inserate.
- Scanarea pool-urilor include și categoria virtuală, cu număr de VM-uri și numărul celor pornite. Auditul pentru categoria exclusă rămâne activ.

## Atenție privind drepturile VCSA
O VM „fără pool identificat” nu înseamnă neapărat că VMware nu i-a atribuit un pool. Poate fi pool-ul implicit `Resources` sau o asociere neexpusă de REST. Dacă politica de excludere este strictă, verificați în VCSA VM-urile din această categorie și debifați-o până la confirmarea drepturilor/filtrelor contului API. Eșecul unui endpoint pentru enumerarea pool-urilor continuă să oprească sincronizarea; numai lipsa apartenenței din rezultate este tratată prin categorie.

## Compatibilitate
- Server 0.21.92, actualizare peste 0.21.91.
- Agent 1.7.18 neschimbat.
- Fără migrare SQL (categoria este o înregistrare normală în tabela existentă `vcenter_resource_pools`), fără endpointuri noi.
- Fără schimbări în documentele, publicarea Outline sau regulile de retragere/arhivare.

## Validare
- Teste HTTP izolate pentru includere implicită, excludere explicită, păstrarea excluderii altor pool-uri, ierarhie, numărătoare; testate cu stubs standard-library, nu cu VCSA real.
- Sunt necesare testul complet Go cu `vendor/`, testul cu MariaDB staging și sincronizarea pe VCSA reală, înainte de producție.
