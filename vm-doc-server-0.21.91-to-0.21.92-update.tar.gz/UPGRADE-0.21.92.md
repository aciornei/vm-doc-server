# Upgrade VM-DOC Server 0.21.91 → 0.21.92

1. Faceți backup verificabil la binar, configurație și MariaDB înainte de instalare; lucrați mai întâi în staging.
2. Aplicați **unul** din pachete: `vm-doc-server-0.21.91-to-0.21.92-update.tar.gz` peste directorul de surse 0.21.91 sau extrageți sursele complete `vm-doc-server-0.21.92-source.zip` într-un director nou. Nu suprascrieți `configs/` personalizat.
3. Recompilați pe serverul offline care are `vendor/` și dependențele Go necesare:

   ```bash
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./internal/vcenter
   GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
   ```

4. Instalați binarul rezultat exact în calea serviciului systemd (`systemctl cat vm-doc-server`, `ExecStart`), reporniți serviciul și faceți Ctrl+F5 în browser.
5. Verificați `/version` = `0.21.92` și `app.js?v=0.21.92`. În `Surse & sincronizări`, folosiți **Descoperă / actualizează** la resource pool-uri: categoria „Fără pool identificat (VCSA)” apare numai dacă există VM-uri neclasificate. Este bifată implicit; opțional debifați și salvați înainte de sincronizare.
6. Sincronizați. Verificați că VM-ul nou a intrat în inventar, că pool-urile excluse au rămas excluse și că nicio VM existentă nu a fost retrasă automat.

**Nu există migrare SQL** și nu trebuie actualizat agentul (rămâne 1.7.18). Categoria virtuală se păstrează în tabela existentă `vcenter_resource_pools`, unde ID-ul `vm-doc:unassigned` este rezervat pentru această utilizare.

**Precauție de securitate:** lipsa unei asocieri REST nu garantează că VM nu aparține unui pool VMware. Dacă excluderile sunt sensibile, revizuiți această categorie sau debifați-o până confirmați în VCSA drepturile contului tehnic și asocierea VM-urilor.

**Rollback:** restaurați sursele/binarul 0.21.91 (nu există migrare nouă de inversat). Opțional, categoria virtuală poate rămâne în DB ca înregistrare absentă în vCenter; nu ștergeți înregistrări fără verificare/backup.
