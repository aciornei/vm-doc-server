// VM-DOC 0.21.67 static regression for archive presentation and transition actions.
// Uses pure UI functions from the shipping app.js; does not simulate MariaDB/vCenter.
const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const src=fs.readFileSync('web/static/js/app.js','utf8');
const start=src.indexOf('function lifecycleRowState(');
const end=src.indexOf('async function lifecycleArchivePage(',start);
assert(start>=0 && end>start,'lifecycle archive helpers missing');
const code=src.slice(start,end);
const sandbox={e:s=>String(s??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),badge:s=>String(s),dt:s=>String(s??'—'),empty:s=>String(s),can:p=>true,lifecycleNames:{active:'Activ',retired:'Retras',archived:'Arhivat'}};
vm.createContext(sandbox);vm.runInContext(code,sandbox);
const live={type:'vm',id:1,name:'APP01',status:'active',present_in_vcenter:true};
const missing={...live,present_in_vcenter:false};
const archived={...live,status:'archived'};
assert.equal(sandbox.lifecycleRowState(live),'active');
assert.equal(sandbox.lifecycleRowState(missing),'missing');
assert.equal(sandbox.lifecycleRowState(archived),'archived');
assert.match(sandbox.lifecycleActionButtons(live),/Retrage/);
assert.doesNotMatch(sandbox.lifecycleActionButtons(live),/Arhivează/);
assert.match(sandbox.lifecycleActionButtons({...live,status:'retired'}),/Arhivează/);
assert.match(sandbox.lifecycleActionButtons(archived),/Revino la retras/);
const html=sandbox.lifecycleArchiveTable([{...archived,name:'<script>alert(1)</script>',service_names:'<example>',power_state:'POWERED_OFF',reason:'Approved',approved_by:'IT',retention_until:'2099-01-01'}]);
assert(!html.includes('<script>') && html.includes('&lt;script&gt;'),'row labels must be escaped');
console.log('PASS: lifecycle states, missing-in-vCenter audit status, controls, output escaping');
