# VM-DOC Server 0.21.67 — Ciclu de viață și arhivare VM / servicii

Bază: **0.21.66** | Data: **2026-10-21** | Agent: **1.7.18**, fără actualizare.

## Scop
- O VM/proiect poate ieși din exploatare și poate rămâne 3–6 luni oprit(ă) în vCenter, fără a apărea în inventarul operațional.
- Când VM-ul dispare definitiv din vCenter, aplicația îi păstrează fișa și `missing_since`, nu face DELETE și nu arhivează implicit.
- Distincție explicită: **Activă → Retrasă → Arhivată**; un VM dispărut fără retragere este **incident de verificat**.

## UI și API
- Navigare → **Arhivă VM & servicii**: rezumat, căutare, filtre, paginare, linkuri către fișele istorice și acțiuni.
- `GET /api/v1/lifecycle/archive` (inventories.read).
- `PUT /api/v1/lifecycle/vm/{id}` (vms.manage); `PUT /api/v1/lifecycle/service/{id}` (services.manage).
- Body: `{ "status":"retired|archived|active", "reason":"...", "approved_by":"...", "retention_until":"YYYY-MM-DD", "notes":"..." }`.
- Pentru `archived` sunt obligatorii motivul și aprobatorul, iar resursa trebuie deja retrasă.
- VM încă în vCenter și `POWERED_ON`: **arhivare respinsă**. La VM dispărute din vCenter, power_state este istoric și nu blochează verificarea/arhivarea.
- Serviciile cu VM-uri încă active direct asociate nu pot fi arhivate, inclusiv când VM-urile sunt doar excluse din pool-uri. Retragerea serviciului nu modifică implicit VM-urile asociate.
- Reapariția unei VM deja retrase/arhivate la sincronizarea vCenter **nu o reactivează automat**. Reactivarea manuală a unei VM absente din vCenter este blocată până când VM-ul reapare și se sincronizează.
- Pentru serviciile și VM-urile arhivate, vechile operațiuni destructive sunt protejate; comasarea serviciilor retrase sau arhivate este blocată. Nu există ștergere după retenție în acest release.

## Persistență și documentație
- Migrarea aditivă **081_lifecycle_archive.up.sql**: `lifecycle_archives`, `lifecycle_archive_relations`, `internal_services.retired_note`.
- Se păstrează înregistrările VM, serviciu, documentele DOCX/PDF/MD deja generate, toate `inventory_snapshots`, asocierile existente și istoricul Audit.
- La arhivare se capturează numele și ID-urile din `vm_internal_service_assignments`; astfel referințele istorice rămân și după redenumiri.
- Nu se publică arhive în Outline; linkurile Vault rămân exclusiv în aplicație. Nu se generează documente noi automat.
- Retenție: dată informativă/compliance; **fără purge automat**. UI sugerează +24 luni, modificabil înainte de confirmare.
- Înregistrările cu `retired=1` deja existente sunt afișate în Arhivă ca retrase, dar **nu sunt arhivate retroactiv**.
- Schimbările utilizatorului sunt logate în `audit_events` cu `lifecycle.retired`, `lifecycle.archived`, `lifecycle.active`.
- Sincronizarea reușită care constată prima dată o VM anterior prezentă, dar absentă și neretrasă, generează un singur `vcenter.vm.unexpected_missing`. Nu marchează VM automat retrasă.

## Limite, de verificat în staging
- Relațiile istorice capturate ca snapshot vizează **asocierile directe VM–serviciu**; nu toate asocierile independente DB/Docker/Web. Aceste date rămân în tabelele existente. Snapshot complet pentru resurse independente poate fi dezvoltat ulterior.
- Rapoartele transversale mai vechi care nu respectau `retired=0` trebuie auditate separat pentru includerea istoricului.
- Nu există interfață de purge sau job automat pentru expirarea retenției.
- Build-ul integral Go, migrarea 081 pe MariaDB 10.6/10.11 și fluxul real vCenter necesită **staging**; mediul de lucru nu are dependențele `vendor/` și nici instanța utilizatorului.
