# Upgrade VM-DOC Server 0.21.66 → 0.21.67

1. În staging, efectuează backup consistent la MariaDB, binar, configurație și surse 0.21.66; notează versiunea curentă.
2. Aplică **update.tar.gz** în rădăcina surselor 0.21.66 **sau** patch incremental, nu ambele. Alternativ înlocuiește sursele cu arhiva completă.
3. Folosește `vendor/` din mediul tău offline, verifică `GOPROXY=off go test ./...`, `node --check web/static/js/app.js`, apoi construiește binarul Go prin procedura existentă. JavaScript-ul este inclus prin go:embed.
4. Oprește vm-doc-server, păstrează binarul precedent și instalează binarul 0.21.67. Migrarea **081_lifecycle_archive.up.sql** se execută automat la pornire. **Nu se execută CLEANUP SQL.**
5. Verifică `/version`, `app.js?v=0.21.67`, meniul Arhivă și migrarea 081.
6. Testează **separat**: (a) VM oprită încă în vCenter → Retrage → Arhivează cu motiv/aprobator; (b) VM pornită → arhivare respinsă; (c) serviciu cu VM active → arhivare respinsă; (d) VM retrasă ștersă în vCenter → fișă păstrată; (e) VM activă absentă la Sync → audit la primul sync, nu repetat; (f) reactivarea unei VM absente → respinsă; (g) comasarea unui serviciu retras → respinsă.
7. Verifică legătura VM–serviciu în registrul Arhivă, dashboard, Outline, exporturi, liste VM și servicii și accesul la fișe.

Rollback: păstrează datele în `lifecycle_archives` și `lifecycle_archive_relations` și **nu executa DOWN în producție** fără backup și analiză. Serverul 0.21.66 nu va interpreta aceste metadate de arhivare, deci reîntoarcerea binarului poate face vizibile din nou unele resurse arhivate; menține-l în mentenanță până la re-upgrade dacă este important să nu reapară.

**Fără modificări ale agentului 1.7.18 și fără ștergeri automate.**
