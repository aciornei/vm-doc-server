-- 0.21.67: arhivare logică VM/servicii; fără ștergere de inventare sau asocieri.
-- Nu se aplică arhivarea retroactiv: retrasele existente necesită decizie explicită.
ALTER TABLE internal_services ADD COLUMN IF NOT EXISTS retired_note TEXT NOT NULL;

CREATE TABLE IF NOT EXISTS lifecycle_archives (
  resource_type VARCHAR(16) NOT NULL,
  resource_id BIGINT UNSIGNED NOT NULL,
  archived_at DATETIME(6) NOT NULL,
  archived_by BIGINT UNSIGNED NULL,
  reason VARCHAR(1000) NOT NULL DEFAULT '',
  approved_by VARCHAR(255) NOT NULL DEFAULT '',
  retention_until DATE NULL,
  notes TEXT NOT NULL,
  PRIMARY KEY (resource_type,resource_id),
  KEY idx_lifecycle_archives_date (resource_type,archived_at),
  KEY idx_lifecycle_archives_retention (retention_until),
  CONSTRAINT chk_lifecycle_archives_type CHECK (resource_type IN ('vm','service')),
  CONSTRAINT fk_lifecycle_archives_user FOREIGN KEY (archived_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Snapshot istoric al asocierilor VM–serviciu la arhivare.
CREATE TABLE IF NOT EXISTS lifecycle_archive_relations (
 owner_type VARCHAR(16) NOT NULL,
 owner_id BIGINT UNSIGNED NOT NULL,
 related_type VARCHAR(16) NOT NULL,
 related_id BIGINT UNSIGNED NOT NULL,
 related_name VARCHAR(255) NOT NULL,
 captured_at DATETIME(6) NOT NULL,
 PRIMARY KEY (owner_type,owner_id,related_type,related_id),
 KEY idx_archive_relation_target (related_type,related_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
