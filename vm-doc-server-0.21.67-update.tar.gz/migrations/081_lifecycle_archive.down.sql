-- Rollback explicit, doar după exportul datelor și decizie administrativă.
DROP TABLE IF EXISTS lifecycle_archive_relations;
DROP TABLE IF EXISTS lifecycle_archives;
ALTER TABLE internal_services DROP COLUMN IF EXISTS retired_note;
