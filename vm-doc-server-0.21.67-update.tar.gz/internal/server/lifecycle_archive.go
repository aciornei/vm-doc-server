package server

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/auth"
)

// lifecycleArchives deliberately stores only lifecycle metadata. Existing VM/service
// records, their inventory snapshots, documents and dependencies are never deleted.
type archiveRow struct {
	Type           string     `json:"type"`
	ID             int64      `json:"id"`
	Name           string     `json:"name"`
	Status         string     `json:"status"`
	Power          string     `json:"power_state,omitempty"`
	Present        bool       `json:"present_in_vcenter"`
	MissingSince   *time.Time `json:"missing_since,omitempty"`
	RetiredAt      *time.Time `json:"retired_at,omitempty"`
	ArchivedAt     *time.Time `json:"archived_at,omitempty"`
	Reason         string     `json:"reason"`
	ApprovedBy     string     `json:"approved_by"`
	RetentionUntil *string    `json:"retention_until,omitempty"`
	Notes          string     `json:"notes"`
	ServiceNames   string     `json:"service_names,omitempty"`
}

type lifecycleChange struct {
	Status         string `json:"status"`
	Reason         string `json:"reason"`
	ApprovedBy     string `json:"approved_by"`
	RetentionUntil string `json:"retention_until"`
	Notes          string `json:"notes"`
}

func lifecycleStatus(retired, archived bool) string {
	if archived {
		return "archived"
	}
	if retired {
		return "retired"
	}
	return "active"
}

func validLifecycleChange(c lifecycleChange) error {
	switch c.Status {
	case "active", "retired", "archived":
	default:
		return errors.New("status must be active, retired or archived")
	}
	if len([]rune(c.Reason)) > 1000 || len([]rune(c.ApprovedBy)) > 255 || len([]rune(c.Notes)) > 4000 {
		return errors.New("lifecycle text too long")
	}
	if c.Status == "archived" {
		if strings.TrimSpace(c.Reason) == "" || strings.TrimSpace(c.ApprovedBy) == "" {
			return errors.New("archive requires a reason and approver")
		}
	}
	if c.RetentionUntil != "" {
		date, err := time.Parse("2006-01-02", c.RetentionUntil)
		if err != nil || date.Before(time.Now().UTC().Truncate(24*time.Hour)) {
			return errors.New("invalid retention date (YYYY-MM-DD, not in the past)")
		}
	}
	return nil
}

func (a *App) listLifecycleArchive(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	items := make([]archiveRow, 0)
	rows, err := a.DB.QueryContext(ctx, `SELECT vm.id,vm.name,vm.retired,vm.power_state,vm.present_in_vcenter,vm.missing_since,vm.retired_at,
 ar.archived_at,COALESCE(NULLIF(ar.reason,''),vm.retired_note,''),COALESCE(ar.approved_by,''),DATE_FORMAT(ar.retention_until,'%Y-%m-%d'),COALESCE(ar.notes,''),
 COALESCE((SELECT GROUP_CONCAT(rel.related_name ORDER BY rel.related_name SEPARATOR ', ') FROM lifecycle_archive_relations rel WHERE rel.owner_type='vm' AND rel.owner_id=vm.id),(SELECT GROUP_CONCAT(DISTINCT svc.name ORDER BY svc.name SEPARATOR ', ') FROM vm_internal_service_assignments x JOIN internal_services svc ON svc.id=x.internal_service_id WHERE x.vm_id=vm.id),'')
 FROM virtual_machines vm LEFT JOIN lifecycle_archives ar ON ar.resource_type='vm' AND ar.resource_id=vm.id
 WHERE vm.retired=1 OR vm.present_in_vcenter=0 OR ar.resource_id IS NOT NULL
 ORDER BY COALESCE(ar.archived_at,vm.retired_at,vm.missing_since,vm.last_seen_at) DESC,vm.name`)
	if err != nil {
		respond(w, nil, err)
		return
	}
	for rows.Next() {
		var item archiveRow
		var retired bool
		var archived, missing, retiredAt sql.NullTime
		var retention sql.NullString
		if err = rows.Scan(&item.ID, &item.Name, &retired, &item.Power, &item.Present, &missing, &retiredAt, &archived, &item.Reason, &item.ApprovedBy, &retention, &item.Notes, &item.ServiceNames); err != nil {
			break
		}
		item.Type = "vm"
		item.Status = lifecycleStatus(retired, archived.Valid)
		if missing.Valid {
			item.MissingSince = &missing.Time
		}
		if retiredAt.Valid {
			item.RetiredAt = &retiredAt.Time
		}
		if archived.Valid {
			item.ArchivedAt = &archived.Time
		}
		if retention.Valid {
			item.RetentionUntil = &retention.String
		}
		items = append(items, item)
	}
	if err == nil {
		err = rows.Err()
	}
	rows.Close()
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows, err = a.DB.QueryContext(ctx, `SELECT svc.id,svc.name,svc.retired,svc.retired_at,ar.archived_at,COALESCE(NULLIF(ar.reason,''),svc.retired_note,''),COALESCE(ar.approved_by,''),DATE_FORMAT(ar.retention_until,'%Y-%m-%d'),COALESCE(ar.notes,''),COALESCE((SELECT GROUP_CONCAT(rel.related_name ORDER BY rel.related_name SEPARATOR ', ') FROM lifecycle_archive_relations rel WHERE rel.owner_type='service' AND rel.owner_id=svc.id),(SELECT GROUP_CONCAT(vm.name ORDER BY vm.name SEPARATOR ', ') FROM vm_internal_service_assignments a JOIN virtual_machines vm ON vm.id=a.vm_id WHERE a.internal_service_id=svc.id),'')
 FROM internal_services svc LEFT JOIN lifecycle_archives ar ON ar.resource_type='service' AND ar.resource_id=svc.id
 WHERE svc.retired=1 OR ar.resource_id IS NOT NULL ORDER BY svc.name`)
	if err != nil {
		respond(w, nil, err)
		return
	}
	for rows.Next() {
		var item archiveRow
		var retired bool
		var archived sql.NullTime
		var retiredAt sql.NullTime
		var retention sql.NullString
		if err = rows.Scan(&item.ID, &item.Name, &retired, &retiredAt, &archived, &item.Reason, &item.ApprovedBy, &retention, &item.Notes, &item.ServiceNames); err != nil {
			break
		}
		item.Type = "service"
		item.Status = lifecycleStatus(retired, archived.Valid)
		if retiredAt.Valid {
			item.RetiredAt = &retiredAt.Time
		}
		if archived.Valid {
			item.ArchivedAt = &archived.Time
		}
		if retention.Valid {
			item.RetentionUntil = &retention.String
		}
		items = append(items, item)
	}
	if err == nil {
		err = rows.Err()
	}
	rows.Close()
	respond(w, items, err)
}

// Perform state transitions transactionally. Arhivare never performs DELETE,
// even when a VM has disappeared from vCenter.
func applyLifecycleChange(ctx context.Context, db *sql.DB, kind string, id, userID int64, change lifecycleChange) error {
	if kind != "vm" && kind != "service" {
		return errors.New("invalid resource type")
	}
	if err := validLifecycleChange(change); err != nil {
		return err
	}
	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	table := "virtual_machines"
	if kind == "service" {
		table = "internal_services"
	}
	var retired bool
	var powered string
	var present bool
	if kind == "vm" {
		err = tx.QueryRowContext(ctx, `SELECT retired,power_state,present_in_vcenter FROM virtual_machines WHERE id=? FOR UPDATE`, id).Scan(&retired, &powered, &present)
	} else {
		err = tx.QueryRowContext(ctx, `SELECT retired FROM internal_services WHERE id=? FOR UPDATE`, id).Scan(&retired)
	}
	if err != nil {
		return err
	}
	var archived int
	if err = tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM lifecycle_archives WHERE resource_type=? AND resource_id=?`, kind, id).Scan(&archived); err != nil {
		return err
	}
	if change.Status == "archived" {
		if !retired {
			return errors.New("retragerea trebuie confirmată înaintea arhivării")
		}
		if kind == "vm" && present && strings.EqualFold(powered, "POWERED_ON") {
			return errors.New("VM este pornită; oprește-o înainte de arhivare")
		}
		if kind == "service" {
			var running int
			if err = tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM vm_internal_service_assignments a JOIN virtual_machines vm ON vm.id=a.vm_id WHERE a.internal_service_id=? AND vm.retired=0`, id).Scan(&running); err != nil {
				return err
			}
			if running > 0 {
				return fmt.Errorf("serviciul are %d VM active asociate; retrage-le sau verifică asocierile înainte de arhivare", running)
			}
		}
		var date any
		if change.RetentionUntil != "" {
			date = change.RetentionUntil
		}
		_, err = tx.ExecContext(ctx, `INSERT INTO lifecycle_archives(resource_type,resource_id,archived_at,archived_by,reason,approved_by,retention_until,notes) VALUES(?,?,UTC_TIMESTAMP(6),?,?,?,?,?) ON DUPLICATE KEY UPDATE reason=VALUES(reason),approved_by=VALUES(approved_by),retention_until=VALUES(retention_until),notes=VALUES(notes)`, kind, id, userID, strings.TrimSpace(change.Reason), strings.TrimSpace(change.ApprovedBy), date, strings.TrimSpace(change.Notes))
	} else {
		if kind == "vm" && change.Status == "active" && !present {
			return errors.New("VM lipsește din vCenter; verifică restaurarea și sincronizează înainte de reactivare")
		}
		if archived > 0 { // unarchive intentionally requires explicit transition; no loss of content
			if _, err = tx.ExecContext(ctx, `DELETE FROM lifecycle_archives WHERE resource_type=? AND resource_id=?`, kind, id); err != nil {
				return err
			}
		}
		if change.Status == "retired" {
			if kind == "vm" {
				_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET retired=1,retired_at=COALESCE(retired_at,UTC_TIMESTAMP(6)),retired_by=?,retired_note=? WHERE id=?`, userID, strings.TrimSpace(change.Reason), id)
			} else {
				_, err = tx.ExecContext(ctx, `UPDATE internal_services SET retired=1,active=0,retired_at=COALESCE(retired_at,UTC_DATE()),retired_note=? WHERE id=?`, strings.TrimSpace(change.Reason), id)
			}
		} else {
			if kind == "vm" {
				_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET retired=0,retired_at=NULL,retired_by=NULL WHERE id=?`, id)
			} else {
				_, err = tx.ExecContext(ctx, `UPDATE internal_services SET retired=0,active=1,retired_at=NULL,retirement_reason_id=NULL WHERE id=?`, id)
			}
		}
	}
	if err != nil {
		return fmt.Errorf("update %s lifecycle: %w", table, err)
	}
	if change.Status == "archived" {
		// Immutable relationship snapshot, captured at explicit archive decision.
		if kind == "vm" {
			_, err = tx.ExecContext(ctx, `INSERT IGNORE INTO lifecycle_archive_relations(owner_type,owner_id,related_type,related_id,related_name,captured_at)
          SELECT 'vm',a.vm_id,'service',s.id,s.name,UTC_TIMESTAMP(6)
          FROM vm_internal_service_assignments a JOIN internal_services s ON s.id=a.internal_service_id
          WHERE a.vm_id=?`, id)
		} else {
			_, err = tx.ExecContext(ctx, `INSERT IGNORE INTO lifecycle_archive_relations(owner_type,owner_id,related_type,related_id,related_name,captured_at)
          SELECT 'service',a.internal_service_id,'vm',vm.id,vm.name,UTC_TIMESTAMP(6)
          FROM vm_internal_service_assignments a JOIN virtual_machines vm ON vm.id=a.vm_id
          WHERE a.internal_service_id=?`, id)
		}
		if err != nil {
			return fmt.Errorf("snapshot service-VM relations: %w", err)
		}
	} else {
		if _, err = tx.ExecContext(ctx, `DELETE FROM lifecycle_archive_relations WHERE owner_type=? AND owner_id=?`, kind, id); err != nil {
			return err
		}
	}
	return tx.Commit()
}

func (a *App) getLifecycle(w http.ResponseWriter, r *http.Request, kind string) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id < 1 {
		badRequest(w, errors.New("invalid resource ID"))
		return
	}
	table := "virtual_machines"
	if kind == "service" {
		table = "internal_services"
	}
	var retired bool
	if err = a.DB.QueryRowContext(r.Context(), `SELECT retired FROM `+table+` WHERE id=?`, id).Scan(&retired); err != nil {
		respond(w, nil, err)
		return
	}
	var when sql.NullTime
	if err = a.DB.QueryRowContext(r.Context(), `SELECT archived_at FROM lifecycle_archives WHERE resource_type=? AND resource_id=?`, kind, id).Scan(&when); err != nil && err != sql.ErrNoRows {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, map[string]any{"type": kind, "id": id, "status": lifecycleStatus(retired, when.Valid), "archived_at": func() any {
		if when.Valid {
			return when.Time
		}
		return nil
	}()})
}

func (a *App) changeLifecycle(w http.ResponseWriter, r *http.Request, kind string) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id < 1 {
		badRequest(w, errors.New("invalid resource ID"))
		return
	}
	if kind != "vm" && kind != "service" {
		badRequest(w, errors.New("invalid resource type"))
		return
	}
	var change lifecycleChange
	if err = decodeJSON(r, &change, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	var previous string
	// Read state for audit details; the transition transaction locks the row.
	var retired bool
	var archiveCount int
	table := "virtual_machines"
	if kind == "service" {
		table = "internal_services"
	}
	err = a.DB.QueryRowContext(r.Context(), `SELECT retired FROM `+table+` WHERE id=?`, id).Scan(&retired)
	if err != nil {
		respond(w, nil, err)
		return
	}
	err = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM lifecycle_archives WHERE resource_type=? AND resource_id=?`, kind, id).Scan(&archiveCount)
	if err != nil {
		respond(w, nil, err)
		return
	}
	previous = lifecycleStatus(retired, archiveCount > 0)
	if err = applyLifecycleChange(r.Context(), a.DB, kind, id, u.ID, change); err != nil {
		badRequest(w, err)
		return
	}
	resourceType := "virtual_machine"
	if kind == "service" {
		resourceType = "internal_service"
	}
	a.auditRequest(r, "lifecycle."+change.Status, resourceType, strconv.FormatInt(id, 10), "success", map[string]any{"before": previous, "after": change.Status, "reason": change.Reason, "approved_by": change.ApprovedBy, "retention_until": change.RetentionUntil, "notes": change.Notes})
	jsonResponse(w, http.StatusOK, map[string]any{"type": kind, "id": id, "status": change.Status})
}

// Explicit archive state may not be bypassed using an older update endpoint.
func (a *App) ensureNotArchived(ctx context.Context, kind string, id int64) error {
	var n int
	if err := a.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM lifecycle_archives WHERE resource_type=? AND resource_id=?`, kind, id).Scan(&n); err != nil {
		return err
	}
	if n > 0 {
		return errors.New("resursa este arhivată; reactiveaz-o explicit din Arhivă")
	}
	return nil
}
