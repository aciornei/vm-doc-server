package server

import (
	"strings"
	"testing"
)

func TestLifecycleStatus(t *testing.T) {
	for _, tc := range []struct {
		retired, archived bool
		want              string
	}{
		{false, false, "active"}, {true, false, "retired"}, {true, true, "archived"},
	} {
		if got := lifecycleStatus(tc.retired, tc.archived); got != tc.want {
			t.Errorf("lifecycleStatus(%v,%v)=%q want %q", tc.retired, tc.archived, got, tc.want)
		}
	}
}
func TestLifecycleValidation(t *testing.T) {
	for _, tc := range []struct {
		name   string
		change lifecycleChange
		valid  bool
	}{
		{"retire", lifecycleChange{Status: "retired", Reason: "End of project"}, true},
		{"archive approved", lifecycleChange{Status: "archived", Reason: "End of project", ApprovedBy: "Head of IT", RetentionUntil: "2099-01-01"}, true},
		{"unknown status", lifecycleChange{Status: "deleted"}, false},
		{"no reason", lifecycleChange{Status: "archived", ApprovedBy: "Admin"}, false},
		{"no approver", lifecycleChange{Status: "archived", Reason: "End"}, false},
		{"invalid retention", lifecycleChange{Status: "archived", Reason: "End", ApprovedBy: "Admin", RetentionUntil: "12/01/2099"}, false},
		{"too long note", lifecycleChange{Status: "retired", Notes: strings.Repeat("x", 4001)}, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			err := validLifecycleChange(tc.change)
			if (err == nil) != tc.valid {
				t.Fatalf("valid=%v err=%v want valid=%v", err == nil, err, tc.valid)
			}
		})
	}
}
