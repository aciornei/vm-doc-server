# Upgrade vm-doc-server 0.17.2 → 0.18.0

0.18.0 adaugă integrarea read-only cu Veeam Backup & Replication.

## Pași

1. Opriți `vm-doc-server`.
2. Aplicați `vm-doc-server-0.18.0-update.tar.gz` peste sursa 0.17.2.
3. Păstrați configurația existentă și adăugați opțional blocul `veeam` din `configs/config.example.yaml`.
4. Recompilați și instalați binarul serverului.
5. Porniți `vm-doc-server`.
6. Verificați în jurnal aplicarea migrației `034_veeam_backup_integration.up.sql`.
7. În UI deschideți **Backup → Adaugă sursă** și configurați Veeam.

## Configurație server

```yaml
veeam:
  allow_http: false
  request_timeout: "60s"
  scheduler_interval: "1m"
```

`request_timeout` este timeout-ul unei cereri REST. Intervalul efectiv de sincronizare se configurează per sursă în UI și este implicit 360 minute.

## Compatibilitate agent

Nu este necesar update de agent. `vm-doc-agent 1.6.2` rămâne compatibil.
