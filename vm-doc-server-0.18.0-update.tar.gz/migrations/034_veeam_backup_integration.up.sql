-- 0.18.0: integrare read-only cu Veeam Backup & Replication.

CREATE TABLE IF NOT EXISTS veeam_sources (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  secret_ref VARCHAR(96) NOT NULL,
  name VARCHAR(255) NOT NULL,
  base_url VARCHAR(1024) NOT NULL,
  username VARCHAR(255) NOT NULL,
  password_ciphertext TEXT NOT NULL,
  api_version VARCHAR(32) NOT NULL DEFAULT '1.1-rev1',
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  verify_tls TINYINT(1) NOT NULL DEFAULT 1,
  tls_server_name VARCHAR(255) NOT NULL DEFAULT '',
  sync_interval_minutes INT UNSIGNED NOT NULL DEFAULT 360,
  last_sync_at DATETIME(6) NULL,
  last_success_at DATETIME(6) NULL,
  last_error TEXT NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_veeam_sources_secret_ref (secret_ref),
  UNIQUE KEY uq_veeam_sources_name (name),
  CONSTRAINT fk_veeam_sources_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_veeam_sources_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS veeam_sync_runs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  veeam_source_id BIGINT UNSIGNED NOT NULL,
  source VARCHAR(24) NOT NULL DEFAULT 'manual',
  status VARCHAR(24) NOT NULL DEFAULT 'queued',
  requested_by_user_id BIGINT UNSIGNED NULL,
  started_at DATETIME(6) NULL,
  finished_at DATETIME(6) NULL,
  backup_object_count INT UNSIGNED NOT NULL DEFAULT 0,
  matched_vm_count INT UNSIGNED NOT NULL DEFAULT 0,
  protected_vm_count INT UNSIGNED NOT NULL DEFAULT 0,
  unprotected_vm_count INT UNSIGNED NOT NULL DEFAULT 0,
  ambiguous_count INT UNSIGNED NOT NULL DEFAULT 0,
  error_message TEXT NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  KEY idx_veeam_sync_runs_source_created (veeam_source_id, created_at DESC),
  KEY idx_veeam_sync_runs_status (status, created_at DESC),
  CONSTRAINT fk_veeam_sync_runs_source FOREIGN KEY (veeam_source_id) REFERENCES veeam_sources(id) ON DELETE CASCADE,
  CONSTRAINT fk_veeam_sync_runs_requested_by FOREIGN KEY (requested_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE vm_backup_summary
  ADD COLUMN veeam_source_id BIGINT UNSIGNED NULL AFTER provider,
  ADD KEY idx_vm_backup_summary_veeam_source (veeam_source_id),
  ADD CONSTRAINT fk_vm_backup_summary_veeam_source FOREIGN KEY (veeam_source_id) REFERENCES veeam_sources(id) ON DELETE SET NULL;

INSERT IGNORE INTO permissions(name, description) VALUES
 ('veeam.read', 'Vizualizare surse, stare backup și sincronizări Veeam'),
 ('veeam.manage', 'Administrare surse și sincronizare Veeam');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name='admin' AND p.name IN ('veeam.read','veeam.manage');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name='operator' AND p.name IN ('veeam.read','veeam.manage');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name IN ('viewer','auditor') AND p.name='veeam.read';
