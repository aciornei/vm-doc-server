package buildinfo

var (
	Version = "0.18.0-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
