package config

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"net"
	"net/url"
	"os"
	"regexp"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

var ldapAttributePattern = regexp.MustCompile(`^[A-Za-z][A-Za-z0-9.-]*$`)

type Duration time.Duration

func (d *Duration) UnmarshalYAML(value *yaml.Node) error {
	parsed, err := time.ParseDuration(value.Value)
	if err != nil {
		return err
	}
	*d = Duration(parsed)
	return nil
}

func (d Duration) Value() time.Duration { return time.Duration(d) }

type Config struct {
	Version           int                     `yaml:"version"`
	App               AppConfig               `yaml:"app"`
	Server            ServerConfig            `yaml:"server"`
	Database          DatabaseConfig          `yaml:"database"`
	Secrets           SecretsConfig           `yaml:"secrets"`
	Session           SessionConfig           `yaml:"session"`
	Auth              AuthConfig              `yaml:"auth"`
	RBAC              RBACConfig              `yaml:"rbac"`
	Collector         CollectorConfig         `yaml:"collector"`
	Inventory         InventoryConfig         `yaml:"inventory"`
	VCenter           VCenterConfig           `yaml:"vcenter"`
	Veeam             VeeamConfig             `yaml:"veeam"`
	AgentRegistration AgentRegistrationConfig `yaml:"agent_registration"`
	AgentUpdates      AgentUpdatesConfig      `yaml:"agent_updates"`
	Audit             AuditConfig             `yaml:"audit"`
	OpenAPI           OpenAPIConfig           `yaml:"openapi"`
	Logging           LoggingConfig           `yaml:"logging"`
}

type AppConfig struct {
	Name        string `yaml:"name"`
	Environment string `yaml:"environment"`
	BaseURL     string `yaml:"base_url"`
	Timezone    string `yaml:"timezone"`
}

type ServerConfig struct {
	Listen            string   `yaml:"listen"`
	TrustedProxies    []string `yaml:"trusted_proxies"`
	ReadHeaderTimeout Duration `yaml:"read_header_timeout"`
	ReadTimeout       Duration `yaml:"read_timeout"`
	WriteTimeout      Duration `yaml:"write_timeout"`
	IdleTimeout       Duration `yaml:"idle_timeout"`
	MaxRequestBody    int64    `yaml:"max_request_body_bytes"`
}

type DatabaseConfig struct {
	Host                  string   `yaml:"host"`
	Port                  int      `yaml:"port"`
	Name                  string   `yaml:"name"`
	User                  string   `yaml:"user"`
	MaxOpenConnections    int      `yaml:"max_open_connections"`
	MaxIdleConnections    int      `yaml:"max_idle_connections"`
	ConnectionMaxLifetime Duration `yaml:"connection_max_lifetime"`
}

type SecretsConfig struct {
	EncryptedFile      string `yaml:"encrypted_file"`
	MasterKeyFile      string `yaml:"master_key_file"`
	MasterKeyEnv       string `yaml:"master_key_env"`
	AllowPlaintextFile bool   `yaml:"allow_plaintext_file"`
}

type SessionConfig struct {
	CookieName      string   `yaml:"cookie_name"`
	IdleTimeout     Duration `yaml:"idle_timeout"`
	AbsoluteTimeout Duration `yaml:"absolute_timeout"`
	Secure          bool     `yaml:"secure"`
	SameSite        string   `yaml:"same_site"`
}

type AuthConfig struct {
	LDAP LDAPConfig `yaml:"ldap"`
	OIDC OIDCConfig `yaml:"oidc"`
	Dev  DevConfig  `yaml:"dev"`
}

type LDAPConfig struct {
	Enabled              bool                `yaml:"enabled"`
	Hosts                []string            `yaml:"hosts"`
	Mode                 string              `yaml:"mode"`
	BaseDN               string              `yaml:"base_dn"`
	UserBaseDN           string              `yaml:"user_base_dn"`
	GroupBaseDN          string              `yaml:"group_base_dn"`
	UserFilter           string              `yaml:"user_filter"`
	UsernameAttribute    string              `yaml:"username_attribute"`
	DisplayNameAttribute string              `yaml:"display_name_attribute"`
	EmailAttribute       string              `yaml:"email_attribute"`
	GroupsAttribute      string              `yaml:"groups_attribute"`
	CAFile               string              `yaml:"ca_file"`
	InsecureSkipVerify   bool                `yaml:"insecure_skip_verify"`
	Directory            LDAPDirectoryConfig `yaml:"directory"`
}

type LDAPDirectoryConfig struct {
	Enabled             bool   `yaml:"enabled"`
	BaseDN              string `yaml:"base_dn"`
	UserFilter          string `yaml:"user_filter"`
	IdentityAttribute   string `yaml:"identity_attribute"`
	DepartmentAttribute string `yaml:"department_attribute"`
	PhoneAttribute      string `yaml:"phone_attribute"`
	PageSize            uint32 `yaml:"page_size"`
	DefaultDepartment   string `yaml:"default_department"`
}

type OIDCConfig struct {
	Enabled       bool     `yaml:"enabled"`
	IssuerURL     string   `yaml:"issuer_url"`
	ClientID      string   `yaml:"client_id"`
	Scopes        []string `yaml:"scopes"`
	UsernameClaim string   `yaml:"username_claim"`
	GroupsClaim   string   `yaml:"groups_claim"`
}

type DevConfig struct {
	Enabled  bool   `yaml:"enabled"`
	Username string `yaml:"username"`
	Password string `yaml:"password"`
}

type RBACConfig struct {
	BootstrapAdminGroups []string `yaml:"bootstrap_admin_groups"`
}

type CollectorConfig struct {
	PollInterval              Duration `yaml:"poll_interval"`
	Workers                   int      `yaml:"workers"`
	LeaseDuration             Duration `yaml:"lease_duration"`
	DefaultCollectionInterval Duration `yaml:"default_collection_interval"`
	DefaultRequestTimeout     Duration `yaml:"default_request_timeout"`
	DefaultOfflineAfter       Duration `yaml:"default_offline_after"`
	RefreshBeforeCollect      bool     `yaml:"refresh_before_collect"`
	MaxInventorySize          int64    `yaml:"max_inventory_size_bytes"`
	AllowedNetworks           []string `yaml:"allowed_networks"`
	AllowHTTP                 bool     `yaml:"allow_http"`
}

type InventoryConfig struct {
	AcceptedSchemaMajor     int      `yaml:"accepted_schema_major"`
	RetainDays              int      `yaml:"retain_days"`
	RetainSnapshotsPerAgent int      `yaml:"retain_snapshots_per_agent"`
	CleanupInterval         Duration `yaml:"cleanup_interval"`
}

type VCenterConfig struct {
	AllowHTTP         bool     `yaml:"allow_http"`
	RequestTimeout    Duration `yaml:"request_timeout"`
	DetailWorkers     int      `yaml:"detail_workers"`
	SchedulerInterval Duration `yaml:"scheduler_interval"`
}

type VeeamConfig struct {
	AllowHTTP         bool     `yaml:"allow_http"`
	RequestTimeout    Duration `yaml:"request_timeout"`
	SchedulerInterval Duration `yaml:"scheduler_interval"`
}

type AgentRegistrationConfig struct {
	Enabled        bool  `yaml:"enabled"`
	MaxRequestBody int64 `yaml:"max_request_body_bytes"`
}

type AgentUpdatesConfig struct {
	Enabled   bool   `yaml:"enabled"`
	Directory string `yaml:"directory"`
}

type AuditConfig struct {
	RetainDays int `yaml:"retain_days"`
}
type OpenAPIConfig struct {
	Enabled     bool   `yaml:"enabled"`
	SwaggerPath string `yaml:"swagger_path"`
}
type LoggingConfig struct {
	Level  string `yaml:"level"`
	Format string `yaml:"format"`
}

type Secrets struct {
	DatabasePassword       string `yaml:"database_password"`
	LDAPBindDN             string `yaml:"ldap_bind_dn"`
	LDAPBindPassword       string `yaml:"ldap_bind_password"`
	OIDCClientSecret       string `yaml:"oidc_client_secret"`
	AgentRegistrationToken string `yaml:"agent_registration_token"`
}

func Load(path string) (Config, error) {
	var cfg Config
	b, err := os.ReadFile(path)
	if err != nil {
		return cfg, fmt.Errorf("read config: %w", err)
	}
	decoder := yaml.NewDecoder(bytes.NewReader(b))
	decoder.KnownFields(true)
	if err := decoder.Decode(&cfg); err != nil {
		return cfg, fmt.Errorf("parse config: %w", err)
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return cfg, errors.New("configuration contains multiple YAML documents")
	}
	applyDefaults(&cfg)
	if err := cfg.Validate(); err != nil {
		return cfg, err
	}
	return cfg, nil
}

func applyDefaults(c *Config) {
	if c.Version == 0 {
		c.Version = 1
	}
	if c.App.Name == "" {
		c.App.Name = "VM Documentation"
	}
	if c.App.Environment == "" {
		c.App.Environment = "production"
	}
	if c.App.Timezone == "" {
		c.App.Timezone = "UTC"
	}
	if c.Server.Listen == "" {
		c.Server.Listen = "127.0.0.1:9080"
	}
	if c.Server.ReadHeaderTimeout == 0 {
		c.Server.ReadHeaderTimeout = Duration(10 * time.Second)
	}
	if c.Server.ReadTimeout == 0 {
		c.Server.ReadTimeout = Duration(30 * time.Second)
	}
	if c.Server.WriteTimeout == 0 {
		c.Server.WriteTimeout = Duration(60 * time.Second)
	}
	if c.Server.IdleTimeout == 0 {
		c.Server.IdleTimeout = Duration(120 * time.Second)
	}
	if c.Server.MaxRequestBody == 0 {
		c.Server.MaxRequestBody = 12 << 20
	}
	if c.Database.Port == 0 {
		c.Database.Port = 3306
	}
	if c.Database.MaxOpenConnections == 0 {
		c.Database.MaxOpenConnections = 20
	}
	if c.Database.MaxIdleConnections == 0 {
		c.Database.MaxIdleConnections = 10
	}
	if c.Database.ConnectionMaxLifetime == 0 {
		c.Database.ConnectionMaxLifetime = Duration(30 * time.Minute)
	}
	if c.Session.CookieName == "" {
		c.Session.CookieName = "vm_doc_session"
	}
	if c.Session.IdleTimeout == 0 {
		c.Session.IdleTimeout = Duration(30 * time.Minute)
	}
	if c.Session.AbsoluteTimeout == 0 {
		c.Session.AbsoluteTimeout = Duration(8 * time.Hour)
	}
	if c.Session.SameSite == "" {
		c.Session.SameSite = "lax"
	}
	if c.Auth.LDAP.Directory.BaseDN == "" {
		c.Auth.LDAP.Directory.BaseDN = c.Auth.LDAP.UserBaseDN
		if c.Auth.LDAP.Directory.BaseDN == "" {
			c.Auth.LDAP.Directory.BaseDN = c.Auth.LDAP.BaseDN
		}
	}
	if c.Auth.LDAP.Directory.UserFilter == "" {
		c.Auth.LDAP.Directory.UserFilter = "(&(objectCategory=person)(objectClass=user)(!(objectClass=computer))(!(userAccountControl:1.2.840.113556.1.4.803:=2)))"
	}
	if c.Auth.LDAP.Directory.IdentityAttribute == "" {
		c.Auth.LDAP.Directory.IdentityAttribute = "objectGUID"
	}
	if c.Auth.LDAP.Directory.DepartmentAttribute == "" {
		c.Auth.LDAP.Directory.DepartmentAttribute = "department"
	}
	if c.Auth.LDAP.Directory.PhoneAttribute == "" {
		c.Auth.LDAP.Directory.PhoneAttribute = "telephoneNumber"
	}
	if c.Auth.LDAP.Directory.PageSize == 0 {
		c.Auth.LDAP.Directory.PageSize = 500
	}
	if c.Collector.PollInterval == 0 {
		c.Collector.PollInterval = Duration(5 * time.Second)
	}
	if c.Collector.Workers == 0 {
		c.Collector.Workers = 4
	}
	if c.Collector.LeaseDuration == 0 {
		c.Collector.LeaseDuration = Duration(2 * time.Minute)
	}
	if c.Collector.DefaultCollectionInterval == 0 {
		c.Collector.DefaultCollectionInterval = Duration(15 * time.Minute)
	}
	if c.Collector.DefaultRequestTimeout == 0 {
		c.Collector.DefaultRequestTimeout = Duration(45 * time.Second)
	}
	if c.Collector.DefaultOfflineAfter == 0 {
		c.Collector.DefaultOfflineAfter = Duration(45 * time.Minute)
	}
	if c.Collector.MaxInventorySize == 0 {
		c.Collector.MaxInventorySize = 10 << 20
	}
	if c.Inventory.AcceptedSchemaMajor == 0 {
		c.Inventory.AcceptedSchemaMajor = 2
	}
	if c.Inventory.RetainSnapshotsPerAgent == 0 {
		c.Inventory.RetainSnapshotsPerAgent = 30
	}
	if c.Inventory.RetainDays == 0 {
		c.Inventory.RetainDays = 90
	}
	if c.Inventory.CleanupInterval == 0 {
		c.Inventory.CleanupInterval = Duration(24 * time.Hour)
	}
	if c.VCenter.RequestTimeout == 0 {
		c.VCenter.RequestTimeout = Duration(60 * time.Second)
	}
	if c.VCenter.DetailWorkers == 0 {
		c.VCenter.DetailWorkers = 8
	}
	if c.VCenter.SchedulerInterval == 0 {
		c.VCenter.SchedulerInterval = Duration(time.Minute)
	}
	if c.Veeam.RequestTimeout == 0 {
		c.Veeam.RequestTimeout = Duration(60 * time.Second)
	}
	if c.Veeam.SchedulerInterval == 0 {
		c.Veeam.SchedulerInterval = Duration(time.Minute)
	}
	if c.AgentRegistration.MaxRequestBody == 0 {
		c.AgentRegistration.MaxRequestBody = 25 << 20
	}
	if c.AgentUpdates.Directory == "" {
		c.AgentUpdates.Directory = "/var/lib/vm-doc-server/agent-updates"
	}
	if c.OpenAPI.SwaggerPath == "" {
		c.OpenAPI.SwaggerPath = "/docs/"
	}
	if c.Logging.Level == "" {
		c.Logging.Level = "info"
	}
	if c.Logging.Format == "" {
		c.Logging.Format = "json"
	}
}

func (c Config) Validate() error {
	var errs []string
	if c.Version != 1 {
		errs = append(errs, "version must be 1")
	}
	if c.Database.Host == "" || c.Database.Name == "" || c.Database.User == "" {
		errs = append(errs, "database host, name and user are required")
	}
	if c.Secrets.EncryptedFile == "" {
		errs = append(errs, "secrets.encrypted_file is required")
	}
	if c.Secrets.MasterKeyFile == "" && c.Secrets.MasterKeyEnv == "" {
		errs = append(errs, "secrets.master_key_file or secrets.master_key_env is required")
	}
	if c.Session.IdleTimeout.Value() <= 0 || c.Session.AbsoluteTimeout.Value() < c.Session.IdleTimeout.Value() {
		errs = append(errs, "session.absolute_timeout must be greater than or equal to session.idle_timeout")
	}
	if c.Collector.Workers < 1 || c.Collector.Workers > 100 {
		errs = append(errs, "collector.workers must be between 1 and 100")
	}
	if c.VCenter.DetailWorkers < 1 || c.VCenter.DetailWorkers > 64 {
		errs = append(errs, "vcenter.detail_workers must be between 1 and 64")
	}
	if c.VCenter.RequestTimeout.Value() < time.Second || c.VCenter.RequestTimeout.Value() > 10*time.Minute {
		errs = append(errs, "vcenter.request_timeout must be between 1s and 10m")
	}
	if c.VCenter.SchedulerInterval.Value() < time.Second || c.VCenter.SchedulerInterval.Value() > time.Hour {
		errs = append(errs, "vcenter.scheduler_interval must be between 1s and 1h")
	}
	if c.Veeam.RequestTimeout.Value() < time.Second || c.Veeam.RequestTimeout.Value() > 10*time.Minute {
		errs = append(errs, "veeam.request_timeout must be between 1s and 10m")
	}
	if c.Veeam.SchedulerInterval.Value() < time.Second || c.Veeam.SchedulerInterval.Value() > time.Hour {
		errs = append(errs, "veeam.scheduler_interval must be between 1s and 1h")
	}
	if c.AgentRegistration.MaxRequestBody < 1<<20 || c.AgentRegistration.MaxRequestBody > 1<<30 {
		errs = append(errs, "agent_registration.max_request_body_bytes must be between 1 MiB and 1 GiB")
	}
	if c.AgentUpdates.Enabled && !strings.HasPrefix(c.AgentUpdates.Directory, "/") {
		errs = append(errs, "agent_updates.directory must be an absolute path")
	}
	if c.AgentUpdates.Enabled && !c.AgentRegistration.Enabled {
		errs = append(errs, "agent_updates.enabled requires agent_registration.enabled=true because update downloads use the registration token")
	}
	if c.Inventory.RetainSnapshotsPerAgent < 1 || c.Inventory.RetainSnapshotsPerAgent > 10000 {
		errs = append(errs, "inventory.retain_snapshots_per_agent must be between 1 and 10000")
	}
	if c.Inventory.RetainDays < 1 || c.Inventory.RetainDays > 36500 {
		errs = append(errs, "inventory.retain_days must be between 1 and 36500")
	}
	if c.Inventory.CleanupInterval.Value() < time.Hour || c.Inventory.CleanupInterval.Value() > 7*24*time.Hour {
		errs = append(errs, "inventory.cleanup_interval must be between 1h and 168h")
	}
	if _, err := time.LoadLocation(c.App.Timezone); err != nil {
		errs = append(errs, fmt.Sprintf("invalid app.timezone %q", c.App.Timezone))
	}
	for _, raw := range c.Server.TrustedProxies {
		if _, _, err := net.ParseCIDR(raw); err != nil {
			errs = append(errs, fmt.Sprintf("invalid server.trusted_proxies CIDR %q", raw))
		}
	}
	for _, raw := range c.Collector.AllowedNetworks {
		if _, _, err := net.ParseCIDR(raw); err != nil {
			errs = append(errs, fmt.Sprintf("invalid collector.allowed_networks CIDR %q", raw))
		}
	}
	if c.Auth.LDAP.Enabled && len(c.Auth.LDAP.Hosts) == 0 {
		errs = append(errs, "LDAP is enabled but no hosts are configured")
	}
	if c.Auth.LDAP.Directory.Enabled {
		if !c.Auth.LDAP.Enabled {
			errs = append(errs, "LDAP directory requires auth.ldap.enabled=true")
		}
		if strings.TrimSpace(c.Auth.LDAP.Directory.BaseDN) == "" {
			errs = append(errs, "auth.ldap.directory.base_dn is required when the directory is enabled")
		}
		if c.Auth.LDAP.Directory.PageSize < 1 || c.Auth.LDAP.Directory.PageSize > 5000 {
			errs = append(errs, "auth.ldap.directory.page_size must be between 1 and 5000")
		}
		for name, attribute := range map[string]string{
			"identity_attribute":   c.Auth.LDAP.Directory.IdentityAttribute,
			"department_attribute": c.Auth.LDAP.Directory.DepartmentAttribute,
			"phone_attribute":      c.Auth.LDAP.Directory.PhoneAttribute,
		} {
			if !ldapAttributePattern.MatchString(attribute) {
				errs = append(errs, fmt.Sprintf("auth.ldap.directory.%s is invalid", name))
			}
		}
	}
	if c.Auth.OIDC.Enabled && (c.Auth.OIDC.IssuerURL == "" || c.Auth.OIDC.ClientID == "") {
		errs = append(errs, "OIDC issuer_url and client_id are required")
	}
	if !c.Auth.LDAP.Enabled && !c.Auth.OIDC.Enabled && !c.Auth.Dev.Enabled {
		errs = append(errs, "at least one authentication provider must be enabled")
	}
	if c.Auth.OIDC.Enabled {
		base, err := url.Parse(c.App.BaseURL)
		if err != nil || base.Host == "" || base.Scheme == "" {
			errs = append(errs, "app.base_url must be an absolute URL when OIDC is enabled")
		} else if c.App.Environment == "production" && base.Scheme != "https" {
			errs = append(errs, "app.base_url must use HTTPS in production")
		}
	}
	if c.App.Environment == "production" && len(c.Collector.AllowedNetworks) == 0 {
		errs = append(errs, "collector.allowed_networks is required in production")
	}
	if c.App.Environment == "production" && c.Auth.Dev.Enabled {
		errs = append(errs, "development authentication cannot be enabled in production")
	}
	if c.App.Environment == "production" && !c.Session.Secure {
		errs = append(errs, "session.secure must be true in production")
	}
	if !strings.HasPrefix(c.OpenAPI.SwaggerPath, "/") || c.OpenAPI.SwaggerPath == "/" {
		errs = append(errs, "openapi.swagger_path must be an absolute non-root path")
	}
	if len(errs) > 0 {
		return errors.New(strings.Join(errs, "; "))
	}
	return nil
}
