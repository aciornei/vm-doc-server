# Upgrade Server VM-DOC 0.21.17 → 0.21.18

Release de UI + extensie read-only a API-ului `GET /api/v1/vms`, fără migrare SQL.

1. Fă backup la directorul și binarul 0.21.17. Copiază sursele într-un director nou `vm-doc-server-0.21.18` și **păstrează vendor/**.
2. Aplică `vm-doc-server-0.21.18-update.tar.gz` în rădăcina surselor noi.
3. Rulează `bash scripts/cleanup-source-tree.sh --check`, `GOPROXY=off GOFLAGS=-mod=vendor go test ./...`, apoi `GOPROXY=off GOFLAGS=-mod=vendor make build`.
4. Abia după ce build-ul trece, înlocuiește binarul conform procedurii curente și reîncarcă browserul (Ctrl+F5).
5. În VM-uri, verifică primele 4 servicii + Extinde, bara filtrelor, cardurile noi, filtrarea Pornite/Publicare Outline, sortarea Completare și resetarea.
6. Verifică pe date reale rezultatele agregate pentru o căutare cu mai multe pagini și timpii de răspuns ai listei VM. Dacă noua medie crește semnificativ timpul query-ului, capturăm EXPLAIN și optimizăm la următorul release.

**Definiții:** Publicare Outline = existența unei ultime publicări înregistrate în `outline_vm_documents_global` pentru `virtualization`; nu înseamnă doar că VM-ul este eligibil pentru publicare. Completarea generală = media aritmetică a procentelor de completare ale VM-urilor filtrate, nu media exclusiv a paginii vizibile.

**Nu există migrare SQL sau schimbare de agent.** Nu șterge `vendor/`, bazele de date, configurațiile ori documentele proiectului.

**Teste locale:** Chromium cu API simulat la 1440/1024/390, Go pentru filtre testat izolat, JS `node --check`, parser OpenAPI, `go test ./web ./internal/buildinfo`; integrarea completă Go și MariaDB reală **nu** sunt verificate în acest mediu, din cauza dependențelor externe indisponibile.
