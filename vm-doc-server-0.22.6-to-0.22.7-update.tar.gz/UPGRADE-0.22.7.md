# Upgrade VM-DOC Server 0.22.6 → 0.22.7

1. **Backup** MariaDB, `config.yaml`, binar și directorul de surse. Verificați în `systemctl cat vm-doc-server` calea executabilului; exemplele de mai jos folosesc `/opt/vm-doc-server/bin/vm-doc-server`.
2. Pe server, copiați sursele actuale (inclusiv `vendor/`, dacă este instalat în același arbore):

```bash
sudo cp -a /usr/local/src/vm-doc-server-0.22.6 /usr/local/src/vm-doc-server-0.22.7
sudo tar -xzf vm-doc-server-0.22.6-to-0.22.7-update.tar.gz -C /usr/local/src/vm-doc-server-0.22.7
cd /usr/local/src/vm-doc-server-0.22.7
```

3. **Teste și compilare offline** (nu instalați dacă testele nu trec):

```bash
GOPROXY=off GOSUMDB=off go test -mod=vendor ./...
node --check web/static/js/app.js
node scripts/test-retirement-history-ui-0227.cjs
CGO_ENABLED=0 GOPROXY=off GOSUMDB=off go build -mod=vendor -trimpath \
  -ldflags "-X vm-doc-server/internal/buildinfo.Version=0.22.7" \
  -o bin/vm-doc-server ./cmd/vm-doc-server
```

4. Într-o fereastră de mentenanță, după validarea în staging:

```bash
sudo systemctl stop vm-doc-server
sudo cp -a /opt/vm-doc-server/bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server.before-0.22.7
sudo install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
sudo systemctl start vm-doc-server
sudo systemctl status vm-doc-server --no-pager
sudo journalctl -u vm-doc-server -n 50 --no-pager
```

5. Verificați: `Servicii → [serviciu] → VM-uri → Istoric VM-uri asociate`, `VM retrasă → Rezumat → Istoric servicii asociate`, și linkurile în ambele sensuri. Verificați pentru aceleași date că tabelul **VM-uri asociate** conține doar VM-uri active.

**Rollback binar:** opriți serviciul, restaurați `vm-doc-server.before-0.22.7`, porniți-l. Nu sunt migrări SQL noi. Agenții și `vm-doc-collector` nu se actualizează.

**Notă:** ZIP-ul cu surse nu include `vendor/`. Compilarea se face în arborele serverului care are aceste dependențe. Verificați drepturile/ownership după `install` în funcție de unit-ul systemd.
