# VM-DOC Server 0.22.7 — Istoric asocieri VM–servicii

## Funcționalitate

- **Servicii → VM-uri**: apare un panou colapsabil **Istoric VM-uri asociate** sub tabela componenței active. O VM poate avea mai multe asocieri istorice; panoul grupează după VM, iar fiecare rol poate fi extins separat. Sunt disponibile data desprinderii, data asocierii inițiale, încadrarea domeniu/categorie, layer/rol, tip soluție, utilizare, marcaj Principal, observații, motivul și aprobatorul retragerii, dacă există.
- **VM → Rezumat / Servicii**: panou colapsabil **Istoric servicii asociate**; linkuri navigabile spre fiecare serviciu. Rezumatul îl afișează pentru VM-uri retrase; tabul Servicii îl afișează și pentru VM-uri reactivate ulterior.
- Asocierile au rămas **read-only**, separate de componența activă. Nu modifică serviciile, numărul de VM-uri active, dependențele, documentele sau publicările Outline.
- Istoricul deja existent în tabela introdusă de **migrarea 088** (0.22.6) este citit automat. **Nicio migrare SQL nouă.** Pentru viitoarele retrageri, se înregistrează și legătura istorică inversă serviciu → VM în `lifecycle_archive_relations`.
- API/Swagger: `GET /api/v1/services/{id}/retired-vms` cu `services.read` și `GET /api/v1/vms/{id}/former-services` cu `inventories.read`.
- Agenții și `vm-doc-collector` rămân neschimbați.

## Fișiere schimbate

`internal/server/server.go`, `internal/server/vm_retired_services.go`, `internal/server/vm_retirement_history.go`, `internal/server/vm_retirement_history_test.go`, `web/static/js/app.js`, `web/static/css/app.css`, `web/static/index.html`, `web/static/releases.json`, `openapi/openapi.yaml`, `scripts/test-retirement-history-ui-0227.cjs`, `VERSION`, `CHANGELOG.md`, `CONTEXT.md`, `README.md`, notele de release și upgrade.

## Verificare

- OK: `node --check web/static/js/app.js`, test UI cu asocieri duplicate, navigare și escaping XSS.
- OK: parser YAML și prezența celor două rute OpenAPI, `go test ./web ./migrations ./internal/buildinfo ./internal/domain` (offline).
- **Neconfirmat aici**: compilarea/testarea `internal/server` și `go test ./...` cu `vendor/` și integrarea cu MariaDB din producție, deoarece arhiva sursă nu conține `vendor/` și mediul nu are module Go în cache.
- Recomandat: staging, teste cu o VM retrasă anterior în 0.22.6, confirmarea datelor în panou și a faptului că VM-ul nu revine în lista activă a serviciului.
