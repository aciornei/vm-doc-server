package server

import (
	"context"
	"database/sql"
	"errors"
	"net/http"
	"time"
)

// RetiredServiceAssignment is a read-only record of a VM/service link removed
// from the active catalog. It is deliberately not merged into live service
// assignments, dependency graphs, exports or Outline publications.
type retiredServiceAssignment struct {
	AssignmentID      int64      `json:"assignment_id"`
	VMID              int64      `json:"vm_id"`
	VMName            string     `json:"vm_name"`
	VMRetired         bool       `json:"vm_retired"`
	VMArchived        bool       `json:"vm_archived"`
	VMRetiredAt       *time.Time `json:"vm_retired_at,omitempty"`
	Reason            string     `json:"retirement_reason"`
	ApprovedBy        string     `json:"approved_by"`
	ServiceID         int64      `json:"service_id"`
	ServiceName       string     `json:"service_name"`
	Domain            string     `json:"architectural_domain"`
	Category          string     `json:"itil_category"`
	Layer             string     `json:"layer_name"`
	TechnicalRole     string     `json:"technical_role"`
	SolutionType      string     `json:"solution_type"`
	UsageType         string     `json:"usage_type"`
	IsPrimary         bool       `json:"is_primary"`
	Notes             string     `json:"notes"`
	OriginalCreatedAt time.Time  `json:"original_created_at"`
	DetachedAt        time.Time  `json:"detached_at"`
}

// History queries are bounded by a single resource and its indexed foreign
// ID. Both variants use a server-owned predicate, never user-supplied SQL.
const historicalServiceAssignmentsQuery = `SELECT
 h.assignment_id,h.vm_id,
 COALESCE(vm.name,(SELECT rel.related_name FROM lifecycle_archive_relations rel
   WHERE rel.owner_type='service' AND rel.owner_id=h.internal_service_id
     AND rel.related_type='vm' AND rel.related_id=h.vm_id LIMIT 1),CONCAT('VM #',h.vm_id)),
 COALESCE(vm.retired,1),
 arch.archived_at IS NOT NULL,
 vm.retired_at,COALESCE(NULLIF(vm.retired_note,''),NULLIF(arch.reason,''),''),COALESCE(arch.approved_by,''),
 h.internal_service_id,
 COALESCE(s.name,(SELECT rel.related_name FROM lifecycle_archive_relations rel
   WHERE rel.owner_type='vm' AND rel.owner_id=h.vm_id
     AND rel.related_type='service' AND rel.related_id=h.internal_service_id LIMIT 1),CONCAT('Serviciu #',h.internal_service_id)),
 COALESCE(d.name,''),COALESCE(cat.name,''),COALESCE(l.name,''),COALESCE(role.name,''),COALESCE(sol.name,''),
 h.usage_type,h.is_primary,h.notes,h.original_created_at,h.detached_at
 FROM vm_retirement_service_assignments h
 LEFT JOIN virtual_machines vm ON vm.id=h.vm_id
 LEFT JOIN lifecycle_archives arch ON arch.resource_type='vm' AND arch.resource_id=h.vm_id
 LEFT JOIN internal_services s ON s.id=h.internal_service_id
 LEFT JOIN nomenclature_items d ON d.id=h.architectural_domain_id
 LEFT JOIN nomenclature_items cat ON cat.id=h.itil_category_id
 LEFT JOIN nomenclature_items l ON l.id=h.layer_id
 LEFT JOIN nomenclature_items role ON role.id=h.technical_role_id
 LEFT JOIN nomenclature_items sol ON sol.id=h.solution_type_id
 WHERE `

func retiredAssignmentsSQL(resource string) (string, error) {
	var predicate string
	switch resource {
	case "vm":
		predicate = "h.vm_id=?"
	case "service":
		predicate = "h.internal_service_id=?"
	default:
		return "", errors.New("invalid historical relation resource")
	}
	return historicalServiceAssignmentsQuery + predicate + ` ORDER BY h.detached_at DESC,h.assignment_id DESC`, nil
}

func listRetiredServiceAssignments(ctx context.Context, db *sql.DB, resource string, id int64) ([]retiredServiceAssignment, error) {
	query, err := retiredAssignmentsSQL(resource)
	if err != nil {
		return nil, err
	}
	rows, err := db.QueryContext(ctx, query, id)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := make([]retiredServiceAssignment, 0)
	for rows.Next() {
		var item retiredServiceAssignment
		var retiredAt sql.NullTime
		if err := rows.Scan(&item.AssignmentID, &item.VMID, &item.VMName,
			&item.VMRetired, &item.VMArchived, &retiredAt, &item.Reason, &item.ApprovedBy, &item.ServiceID, &item.ServiceName,
			&item.Domain, &item.Category, &item.Layer, &item.TechnicalRole, &item.SolutionType,
			&item.UsageType, &item.IsPrimary, &item.Notes, &item.OriginalCreatedAt,
			&item.DetachedAt); err != nil {
			return nil, err
		}
		if retiredAt.Valid {
			item.VMRetiredAt = &retiredAt.Time
		}
		result = append(result, item)
	}
	return result, rows.Err()
}

func (a *App) getServiceRetiredVMHistory(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	// Do not expose a former relationship for an unknown service ID.
	var exists int
	if err = a.DB.QueryRowContext(r.Context(), `SELECT 1 FROM internal_services WHERE id=?`, id).Scan(&exists); err != nil {
		respond(w, nil, err)
		return
	}
	items, err := listRetiredServiceAssignments(r.Context(), a.DB, "service", id)
	respond(w, items, err)
}

func (a *App) getVMRetiredServiceHistory(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var exists int
	if err = a.DB.QueryRowContext(r.Context(), `SELECT 1 FROM virtual_machines WHERE id=?`, id).Scan(&exists); err != nil {
		respond(w, nil, err)
		return
	}
	items, err := listRetiredServiceAssignments(r.Context(), a.DB, "vm", id)
	respond(w, items, err)
}
