package server

import (
	"encoding/json"
	"strings"
	"testing"
	"time"
)

func TestRetiredAssignmentsSQLStrictResourceFilter(t *testing.T) {
	for resource, filter := range map[string]string{"vm": "WHERE h.vm_id=?", "service": "WHERE h.internal_service_id=?"} {
		sql, err := retiredAssignmentsSQL(resource)
		if err != nil {
			t.Fatalf("%s: %v", resource, err)
		}
		if !strings.Contains(sql, filter) || !strings.Contains(sql, "FROM vm_retirement_service_assignments h") {
			t.Errorf("%s missing historical table or scoped filter", resource)
		}
		if strings.Contains(sql, "DELETE ") || strings.Contains(sql, "UPDATE ") || strings.Contains(sql, "INSERT ") {
			t.Errorf("%s query must be read-only", resource)
		}
	}
	if _, err := retiredAssignmentsSQL("service; DROP TABLE"); err == nil {
		t.Fatal("unknown resource filter accepted")
	}
}

func TestRetiredAssignmentJSONDoesNotExposeSecretFields(t *testing.T) {
	date := time.Date(2026, 11, 20, 10, 30, 0, 0, time.UTC)
	item := retiredServiceAssignment{
		AssignmentID: 12, VMID: 1, VMName: "vm-test", ServiceID: 2, ServiceName: "Service",
		VMRetired: true, DetachedAt: date, OriginalCreatedAt: date,
	}
	raw, err := json.Marshal(item)
	if err != nil {
		t.Fatal(err)
	}
	for _, key := range []string{`"vm_name"`, `"service_name"`, `"detached_at"`, `"vm_retired"`} {
		if !strings.Contains(string(raw), key) {
			t.Errorf("missing field %s", key)
		}
	}
	for _, secret := range []string{`"vault_url"`, `"token"`, `"password"`} {
		if strings.Contains(string(raw), secret) {
			t.Errorf("sensitive field %s leaked", secret)
		}
	}
}
