package server

import (
	"context"
	"database/sql"
	"fmt"
)

// detachVMServiceAssignments preserves the exact active relation metadata before
// removing it from live service composition. It must run inside the lifecycle
// transaction. The history table is immutable by original assignment ID.
func detachVMServiceAssignments(ctx context.Context, tx *sql.Tx, vmID int64) (int64, error) {
	if _, err := tx.ExecContext(ctx, `INSERT IGNORE INTO lifecycle_archive_relations(owner_type,owner_id,related_type,related_id,related_name,captured_at)
        SELECT 'vm',a.vm_id,'service',s.id,s.name,UTC_TIMESTAMP(6)
        FROM vm_internal_service_assignments a JOIN internal_services s ON s.id=a.internal_service_id
        WHERE a.vm_id=?`, vmID); err != nil {
		return 0, fmt.Errorf("snapshot links: %w", err)
	}
	// Preserve the reverse direction for the service's history and for
	// future resilience if the VM is later removed from the main catalog.
	if _, err := tx.ExecContext(ctx, `INSERT IGNORE INTO lifecycle_archive_relations(owner_type,owner_id,related_type,related_id,related_name,captured_at)
        SELECT 'service',a.internal_service_id,'vm',vm.id,vm.name,UTC_TIMESTAMP(6)
        FROM vm_internal_service_assignments a JOIN virtual_machines vm ON vm.id=a.vm_id
        WHERE a.vm_id=?`, vmID); err != nil {
		return 0, fmt.Errorf("snapshot reverse links: %w", err)
	}
	if _, err := tx.ExecContext(ctx, `INSERT IGNORE INTO vm_retirement_service_assignments(
        assignment_id,vm_id,internal_service_id,architectural_domain_id,itil_category_id,layer_id,technical_role_id,solution_type_id,
        usage_type,is_primary,notes,sort_order,updated_by,original_created_at,original_updated_at,detached_at)
        SELECT id,vm_id,internal_service_id,architectural_domain_id,itil_category_id,layer_id,technical_role_id,solution_type_id,
        usage_type,is_primary,notes,sort_order,updated_by,created_at,updated_at,UTC_TIMESTAMP(6)
        FROM vm_internal_service_assignments WHERE vm_id=?`, vmID); err != nil {
		return 0, fmt.Errorf("snapshot complete: %w", err)
	}
	if _, err := tx.ExecContext(ctx, `UPDATE vm_common_service_dependencies SET active=0 WHERE vm_id=? AND active=1`, vmID); err != nil {
		return 0, fmt.Errorf("deactivate VM dependencies to common services: %w", err)
	}
	res, err := tx.ExecContext(ctx, `DELETE FROM vm_internal_service_assignments WHERE vm_id=?`, vmID)
	if err != nil {
		return 0, fmt.Errorf("detach live links: %w", err)
	}
	count, err := res.RowsAffected()
	return count, err
}
