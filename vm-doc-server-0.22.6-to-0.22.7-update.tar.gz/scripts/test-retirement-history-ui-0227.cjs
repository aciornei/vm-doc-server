// Lightweight UI regression check; intentionally no network / DOM dependency.
const fs=require('fs');
const vm=require('vm');
const assert=require('assert');
const src=fs.readFileSync('web/static/js/app.js','utf8');
const start=src.indexOf('function retirementHistoryHTML(');
const end=src.indexOf('function serviceVMRows(',start);
assert(start>0&&end>start);
const mock={
 e:(v)=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;'),
 dt:(v)=>String(v??'—'), serviceUsageLabels:{dedicated:'Dedicat'},
};
vm.createContext(mock);vm.runInContext(src.slice(start,end),mock);
const row={assignment_id:41,vm_id:10,vm_name:'VM <malicious>',vm_retired:true,vm_archived:true,
 service_id:4,service_name:'Business service',architectural_domain:'Aplicații',itil_category:'Web',
 layer_name:'Frontend',technical_role:'Web server',solution_type:'Intern',usage_type:'dedicated',
 is_primary:true,notes:'<script>bad()</script>',retirement_reason:'Înlocuit',approved_by:'Tech lead',
 original_created_at:'2025-02-04T00:00:00Z',detached_at:'2026-11-20T09:00:00Z'};
const serviceHTML=mock.retirementHistoryHTML([row,{...row,assignment_id:42,technical_role:'Proxy'}],'service');
assert(serviceHTML.includes('2 asocieri'));
assert(serviceHTML.includes('1 VM'));
assert(serviceHTML.includes('#vms/10/overview'));
assert(!serviceHTML.includes('<script>'));
assert(serviceHTML.includes('&lt;script&gt;bad()&lt;/script&gt;'));
assert(serviceHTML.includes('Motiv retragere:'));
const vmHTML=mock.retirementHistoryHTML([row],'vm');
assert(vmHTML.includes('#services/4/vms'));
assert(vmHTML.includes('Istoric servicii asociate'));
assert.strictEqual(mock.retirementHistoryHTML([],'vm'),'');
console.log('OK: VM and service retired-history UI, grouping, links, empty and XSS cases');
