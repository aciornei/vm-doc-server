# Upgrade VM-DOC 0.21.83 → 0.21.84

1. Faceți backup binar + surse 0.21.83; păstrați backupul MariaDB.
2. Aplicați update-ul TAR peste **sursele 0.21.83** sau folosiți ZIP-ul cu sursele complete 0.21.84.
3. Verificați structura: `bash scripts/cleanup-source-tree.sh --check`.
4. Compilați offline cu dependențele existente: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
5. Opriți serviciul; copiați binarul nou; reporniți serviciul. HTML/JS/CSS sunt incluse în binarul Go prin `go:embed`.
6. Verificați că HTML încarcă `app.js?v=0.21.84`; folosiți Ctrl+F5 dacă e nevoie.
7. Testați `Modificări` global: `Modificări / De documentat / Ghid`, lista paginată, apoi VM → `Timeline / Modificări / De documentat / Ghid`.
8. Testați clopoțelul cu mai mult de 10 VM-uri/servicii restante: cifra indică totalul, panoul arată 10 intrări, `Vezi toate obligațiile` duce la paginare și linkurile VM la `changes-documentation`.

**Nu există migrare SQL** și nu trebuie reinstalat agentul. Rollback: reinstalați binarul 0.21.83; baza rămâne compatibilă. Build-ul complet și integrarea reală se validează în staging.
