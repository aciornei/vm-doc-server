# VM-DOC Server 0.21.84 — Subpagini Modificări și notificări compacte

## Ce este nou
- **Modificări global**: trei subpagini cu aceeași navigare vizuală ca în fișa VM: `Modificări` (implicit), `De documentat`, `Ghid`. Ghidul include explicarea workflow-ului, baseline-ului și detectorului semantic.
- **VM → Modificări**: patru subpagini: `Timeline` (implicit), `Modificări`, `De documentat`, `Ghid`. Restanțele de documentare nu mai ocupă spațiu în Timeline; se afișează în subpagina proprie.
- **Notificări în antet**: clopoțel 33×33px, panou 540px responsive. Panoul prezintă **ultimele 10 resurse** cu documentație restantă, în ordine descrescătoare a ultimei obligații; cifra din clopoțel și sumarul VM/servicii reprezintă în continuare **totalul**. `Vezi toate obligațiile` deschide lista globală paginată (20/pagină). Linkurile notificărilor VM merg direct la `VM → Modificări → De documentat`.
- Corecție text ajutor: `Documentat` nu este stare a reviziei, ci confirmare de închidere a obligației.

## Nemodificat
- Fluxul `Nou → Revizuit`, baseline-ul per obiect, timeline, API-ul taskurilor și criteriile de completitudine.
- Nu există migrare SQL. Agentul rămâne **1.7.18**.

## Testare și limite
- Validat `node --check`, teste Go offline pentru detector și pachete independente, test Chromium local (640/1024/1440px): navigări, 4 file VM, 10 notificări, destinații și scroll.
- **Nu au fost executate** build-ul Go integral cu `vendor/`, interogările pe MariaDB reală, OIDC și testul din instalarea de producție. Compilați și testați în staging.
