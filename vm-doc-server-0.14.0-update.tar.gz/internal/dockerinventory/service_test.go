package dockerinventory

import "testing"

func TestContainerIdentityComposeNumberSurvivesRecreate(t *testing.T) {
	first := agentContainer{ID: "aaa", Name: "portal-app-1", ComposeProject: "portal", ComposeService: "app", Labels: map[string]string{"com.docker.compose.container-number": "1"}}
	second := agentContainer{ID: "bbb", Name: "portal-app-1", ComposeProject: "portal", ComposeService: "app", Labels: map[string]string{"com.docker.compose.container-number": "1"}}
	if got, want := containerIdentity(first), "compose:portal:app:1"; got != want {
		t.Fatalf("identity=%q want %q", got, want)
	}
	if containerIdentity(first) != containerIdentity(second) {
		t.Fatalf("compose identity changed when engine id changed")
	}
}

func TestContainerIdentitySeparatesComposeReplicas(t *testing.T) {
	one := agentContainer{Name: "worker-1", ComposeProject: "portal", ComposeService: "worker", Labels: map[string]string{"com.docker.compose.container-number": "1"}}
	two := agentContainer{Name: "worker-2", ComposeProject: "portal", ComposeService: "worker", Labels: map[string]string{"com.docker.compose.container-number": "2"}}
	if containerIdentity(one) == containerIdentity(two) {
		t.Fatal("compose replicas must have different identities")
	}
}

func TestContainerIdentityFallsBackToName(t *testing.T) {
	c := agentContainer{ID: "engine-id", Name: "shared-nginx"}
	if got, want := containerIdentity(c), "name:shared-nginx"; got != want {
		t.Fatalf("identity=%q want %q", got, want)
	}
}
