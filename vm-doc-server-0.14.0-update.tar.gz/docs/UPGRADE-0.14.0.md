# Upgrade vm-doc-server 0.13.8 → 0.14.0

Versiunea 0.14.0 introduce inventarul Docker structurat și relația many-to-many dintre containere și servicii interne.

## 1. Backup

Faceți backup bazei de date și al directorului aplicației înainte de upgrade.

## 2. Actualizare surse

Aplicați pachetul `vm-doc-server-0.14.0-update.tar.gz` peste sursa 0.13.8 sau folosiți patch-ul `vm-doc-server-0.13.8-to-0.14.0.patch`.

## 3. Compilare

```bash
go build -o vm-doc-server ./cmd/vm-doc-server
```

Înlocuiți binarul folosit de systemd și reporniți serviciul.

## 4. Migrare DB

La pornire, mecanismul normal de migrare aplică `029_docker_inventory.up.sql`. Verificați în jurnal că serverul pornește fără erori și că tabelele `docker_hosts`, `docker_containers`, `docker_images`, `docker_networks`, `docker_volumes` și `docker_container_service_assignments` există.

## 5. Agent

Pentru colectarea Docker este necesar `vm-doc-agent 1.4.0`. Agenții mai vechi continuă să funcționeze, însă nu actualizează secțiunea Docker.

După upgrade-ul agentului, forțați o colectare. În fila Docker a VM-ului trebuie să apară engine-ul, containerele și proiectele Compose.

## 6. Asocieri servicii

Asocierea VM → serviciu nu este folosită pentru a decide serviciul containerelor. Un host Docker partajat poate avea containere asociate cu servicii diferite. Asocierile se fac manual per container/proiect Compose sau opțional prin labels `vm-doc.service` / `vm-doc.services`.
