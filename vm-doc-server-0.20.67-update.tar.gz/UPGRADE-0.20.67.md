# Upgrade VM-DOC Server 0.20.66 → 0.20.67

0.20.67 adaugă integrarea **FortiGate REST API** și pagina **Securitate → Firewall central**.

La primul startup se aplică migrarea `068_fortigate_firewall_inventory.up.sql`. Nu este necesar agent nou; `vm-doc-agent 1.7.12` rămâne recomandat.

```bash
cp -a /usr/local/src/vm-doc-server-0.20.66 /usr/local/src/vm-doc-server-0.20.67
tar -xzf vm-doc-server-0.20.67-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.67
cd /usr/local/src/vm-doc-server-0.20.67
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Repornește `vm-doc-server` și fă `Ctrl+F5` în browser.

## FortiGate

În FortiGate creează un REST API Administrator read-only, limitează Trusted Hosts la IP-ul serverului VM-DOC și acordă doar drepturile necesare pentru citirea obiectelor/politicilor firewall. În VM-DOC mergi la **Securitate → Firewall central → Adaugă FortiGate**, completează URL-ul HTTPS, VDOM-ul și tokenul, apoi rulează **Test** și **Sync**.

Configurația serverului are opțional:

```yaml
fortigate:
  allow_http: false
  request_timeout: "30s"
  scheduler_interval: "1m"
```

`allow_http` trebuie lăsat `false` în mod normal. Dezactivarea verificării TLS este disponibilă per sursă pentru certificate interne/self-signed, dar verificarea certificatului rămâne valoarea implicită.
