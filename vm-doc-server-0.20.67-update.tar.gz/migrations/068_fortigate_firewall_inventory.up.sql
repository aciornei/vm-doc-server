-- 0.20.67: FortiGate REST API inventory and VM firewall correlation.

CREATE TABLE IF NOT EXISTS fortigate_sources (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  secret_ref CHAR(48) NOT NULL,
  name VARCHAR(190) NOT NULL,
  base_url VARCHAR(1024) NOT NULL,
  api_token_ciphertext TEXT NOT NULL,
  vdom VARCHAR(128) NOT NULL DEFAULT 'root',
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  verify_tls TINYINT(1) NOT NULL DEFAULT 1,
  tls_server_name VARCHAR(255) NOT NULL DEFAULT '',
  sync_interval_minutes INT UNSIGNED NOT NULL DEFAULT 15,
  last_sync_at DATETIME(6) NULL,
  last_success_at DATETIME(6) NULL,
  last_error TEXT NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_fortigate_sources_name (name),
  UNIQUE KEY uq_fortigate_sources_secret_ref (secret_ref),
  CONSTRAINT fk_fortigate_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_fortigate_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fortigate_addresses (
  source_id BIGINT UNSIGNED NOT NULL,
  vdom VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  object_type VARCHAR(64) NOT NULL DEFAULT '',
  subnet VARCHAR(128) NOT NULL DEFAULT '',
  start_ip VARCHAR(64) NOT NULL DEFAULT '',
  end_ip VARCHAR(64) NOT NULL DEFAULT '',
  fqdn VARCHAR(255) NOT NULL DEFAULT '',
  raw_json LONGTEXT NOT NULL,
  synced_at DATETIME(6) NOT NULL,
  PRIMARY KEY (source_id,vdom,name),
  KEY idx_fortigate_addresses_name (name),
  CONSTRAINT fk_fortigate_addresses_source FOREIGN KEY (source_id) REFERENCES fortigate_sources(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fortigate_address_groups (
  source_id BIGINT UNSIGNED NOT NULL,
  vdom VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  members_json LONGTEXT NOT NULL,
  raw_json LONGTEXT NOT NULL,
  synced_at DATETIME(6) NOT NULL,
  PRIMARY KEY (source_id,vdom,name),
  KEY idx_fortigate_groups_name (name),
  CONSTRAINT fk_fortigate_groups_source FOREIGN KEY (source_id) REFERENCES fortigate_sources(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fortigate_policies (
  source_id BIGINT UNSIGNED NOT NULL,
  vdom VARCHAR(128) NOT NULL,
  policy_id BIGINT NOT NULL,
  name VARCHAR(255) NOT NULL DEFAULT '',
  status VARCHAR(32) NOT NULL DEFAULT '',
  srcintf_json LONGTEXT NOT NULL,
  dstintf_json LONGTEXT NOT NULL,
  srcaddr_json LONGTEXT NOT NULL,
  dstaddr_json LONGTEXT NOT NULL,
  service_json LONGTEXT NOT NULL,
  action VARCHAR(32) NOT NULL DEFAULT '',
  schedule_name VARCHAR(255) NOT NULL DEFAULT '',
  nat TINYINT(1) NOT NULL DEFAULT 0,
  comments TEXT NOT NULL,
  raw_json LONGTEXT NOT NULL,
  synced_at DATETIME(6) NOT NULL,
  PRIMARY KEY (source_id,vdom,policy_id),
  KEY idx_fortigate_policy_name (name),
  CONSTRAINT fk_fortigate_policies_source FOREIGN KEY (source_id) REFERENCES fortigate_sources(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fortigate_vips (
  source_id BIGINT UNSIGNED NOT NULL,
  vdom VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  extip VARCHAR(128) NOT NULL DEFAULT '',
  mappedip_json LONGTEXT NOT NULL,
  extintf VARCHAR(255) NOT NULL DEFAULT '',
  protocol VARCHAR(32) NOT NULL DEFAULT '',
  portforward TINYINT(1) NOT NULL DEFAULT 0,
  extport VARCHAR(64) NOT NULL DEFAULT '',
  mappedport VARCHAR(64) NOT NULL DEFAULT '',
  raw_json LONGTEXT NOT NULL,
  synced_at DATETIME(6) NOT NULL,
  PRIMARY KEY (source_id,vdom,name),
  KEY idx_fortigate_vips_name (name),
  CONSTRAINT fk_fortigate_vips_source FOREIGN KEY (source_id) REFERENCES fortigate_sources(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fortigate_vm_matches (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  source_id BIGINT UNSIGNED NOT NULL,
  vm_id BIGINT UNSIGNED NOT NULL,
  vdom VARCHAR(128) NOT NULL,
  policy_id BIGINT NOT NULL,
  direction VARCHAR(16) NOT NULL,
  vm_ip VARCHAR(64) NOT NULL,
  match_object VARCHAR(255) NOT NULL DEFAULT '',
  match_reason VARCHAR(1024) NOT NULL DEFAULT '',
  vip_name VARCHAR(255) NOT NULL DEFAULT '',
  extip VARCHAR(128) NOT NULL DEFAULT '',
  risk_json LONGTEXT NOT NULL,
  synced_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_fortigate_vm_match (source_id,vm_id,vdom,policy_id,direction,vm_ip,match_object,vip_name),
  KEY idx_fortigate_vm_matches_vm (vm_id,direction),
  KEY idx_fortigate_vm_matches_policy (source_id,vdom,policy_id),
  CONSTRAINT fk_fortigate_matches_source FOREIGN KEY (source_id) REFERENCES fortigate_sources(id) ON DELETE CASCADE,
  CONSTRAINT fk_fortigate_matches_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fortigate_sync_runs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  source_id BIGINT UNSIGNED NOT NULL,
  source VARCHAR(16) NOT NULL,
  status VARCHAR(16) NOT NULL,
  requested_by_user_id BIGINT UNSIGNED NULL,
  started_at DATETIME(6) NULL,
  finished_at DATETIME(6) NULL,
  address_count INT UNSIGNED NOT NULL DEFAULT 0,
  group_count INT UNSIGNED NOT NULL DEFAULT 0,
  policy_count INT UNSIGNED NOT NULL DEFAULT 0,
  vip_count INT UNSIGNED NOT NULL DEFAULT 0,
  match_count INT UNSIGNED NOT NULL DEFAULT 0,
  error_message TEXT NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  KEY idx_fortigate_runs_source (source_id,id),
  KEY idx_fortigate_runs_status (status,created_at),
  CONSTRAINT fk_fortigate_runs_source FOREIGN KEY (source_id) REFERENCES fortigate_sources(id) ON DELETE CASCADE,
  CONSTRAINT fk_fortigate_runs_user FOREIGN KEY (requested_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO permissions(name,description) VALUES
 ('fortigate.read','Vizualizare inventar FortiGate și reguli corelate cu VM-uri'),
 ('fortigate.manage','Administrare surse FortiGate și sincronizări');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name='admin' AND p.name IN ('fortigate.read','fortigate.manage');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name='operator' AND p.name IN ('fortigate.read','fortigate.manage');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name IN ('viewer','auditor') AND p.name='fortigate.read';
