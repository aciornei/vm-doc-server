package server

import (
	"net/http"
	"strconv"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/fortigate"
)

func (a *App) listFortiGateSources(w http.ResponseWriter, r *http.Request) {
	v, err := a.FortiGate.ListSources(r.Context())
	respond(w, v, err)
}
func (a *App) getFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.FortiGate.GetSource(r.Context(), id)
	respond(w, v, err)
}
func (a *App) createFortiGateSource(w http.ResponseWriter, r *http.Request) {
	var in fortigate.SourceInput
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.FortiGate.CreateSource(r.Context(), in, u.ID)
	if err == nil {
		a.auditRequest(r, "fortigate.source.create", "fortigate_source", strconv.FormatInt(v.ID, 10), "success", map[string]any{"name": v.Name, "base_url": v.BaseURL, "vdom": v.VDOM})
	}
	respondStatus(w, v, err, http.StatusCreated)
}
func (a *App) updateFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in fortigate.SourceInput
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.FortiGate.UpdateSource(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "fortigate.source.update", "fortigate_source", strconv.FormatInt(id, 10), "success", map[string]any{"name": v.Name, "base_url": v.BaseURL, "vdom": v.VDOM})
	}
	respond(w, v, err)
}
func (a *App) deleteFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	err = a.FortiGate.DeleteSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "fortigate.source.delete", "fortigate_source", strconv.FormatInt(id, 10), "success", nil)
	}
	respond(w, map[string]any{"deleted": err == nil}, err)
}
func (a *App) testFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.FortiGate.TestSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "fortigate.source.test", "fortigate_source", strconv.FormatInt(id, 10), "success", v)
	}
	respond(w, v, err)
}
func (a *App) syncFortiGateSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	run, err := a.FortiGate.StartSync(r.Context(), id, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "fortigate.sync.queue", "fortigate_source", strconv.FormatInt(id, 10), "success", map[string]any{"run_id": run.ID})
	}
	respondStatus(w, run, err, http.StatusAccepted)
}
func (a *App) syncAllFortiGate(w http.ResponseWriter, r *http.Request) {
	u, _ := auth.UserFromContext(r.Context())
	runs, err := a.FortiGate.StartAll(r.Context(), &u.ID)
	if err == nil {
		a.auditRequest(r, "fortigate.sync.queue_all", "fortigate", "all", "success", map[string]any{"runs": len(runs)})
	}
	respondStatus(w, runs, err, http.StatusAccepted)
}
func (a *App) listFortiGateRuns(w http.ResponseWriter, r *http.Request) {
	page, size, err := paginationFromRequest(r, 10, 200)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.FortiGate.ListRunsPage(r.Context(), page, size)
	respond(w, v, err)
}
func (a *App) listFortiGateRules(w http.ResponseWriter, r *http.Request) {
	page, size, err := paginationFromRequest(r, 50, 500)
	if err != nil {
		badRequest(w, err)
		return
	}
	q := r.URL.Query()
	v, err := a.FortiGate.ListRules(r.Context(), q.Get("q"), q.Get("direction"), q.Get("risk"), q.Get("action"), q.Get("status"), q.Get("service"), q.Get("interface"), q.Get("vdom"), fortigate.ParseIntQuery(q.Get("source_id")), fortigate.ParseIntQuery(q.Get("vm_id")), page, size)
	respond(w, v, err)
}
