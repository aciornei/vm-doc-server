package fortigate

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestClientInventoryUsesBearerAndVDOM(t *testing.T) {
	seen := 0
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get("Authorization"); got != "Bearer token-123" {
			t.Fatalf("authorization = %q", got)
		}
		if got := r.URL.Query().Get("vdom"); got != "root" {
			t.Fatalf("vdom = %q", got)
		}
		seen++
		fmt.Fprint(w, `{"status":"success","http_status":200,"results":[]}`)
	}))
	defer ts.Close()
	client, err := NewClient(ts.URL, "token-123", "root", true, "", 5*time.Second, true)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := client.Inventory(context.Background()); err != nil {
		t.Fatal(err)
	}
	if seen != 4 {
		t.Fatalf("expected 4 CMDB calls, got %d", seen)
	}
}
