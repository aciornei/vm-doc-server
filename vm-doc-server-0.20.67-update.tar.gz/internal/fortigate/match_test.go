package fortigate

import "testing"

func TestResolverSubnetAndNestedGroup(t *testing.T) {
	r := Resolver{Addresses: map[string]Address{
		"net-app": {Name: "NET-APP", Type: "ipmask", Subnet: "10.20.10.0 255.255.255.0"},
	}, Groups: map[string]Group{
		"grp-prod": {Name: "GRP-PROD", Members: []string{"NET-APP"}},
	}}
	ok, why := r.Match("GRP-PROD", "10.20.10.25")
	if !ok || why != "GRP-PROD → NET-APP (10.20.10.0/24)" {
		t.Fatalf("unexpected match: %v %q", ok, why)
	}
	if ok, _ := r.Match("GRP-PROD", "10.20.11.25"); ok {
		t.Fatal("unexpected subnet match")
	}
}

func TestResolverIPRange(t *testing.T) {
	r := Resolver{Addresses: map[string]Address{"range": {Name: "RANGE", Type: "iprange", StartIP: "10.1.1.10", EndIP: "10.1.1.20"}}, Groups: map[string]Group{}}
	if ok, _ := r.Match("RANGE", "10.1.1.15"); !ok {
		t.Fatal("range should match")
	}
	if ok, _ := r.Match("RANGE", "10.1.1.21"); ok {
		t.Fatal("range should not match")
	}
}

func TestResolverDoesNotClaimAllWithoutInterfaceEvidence(t *testing.T) {
	r := Resolver{Addresses: map[string]Address{}, Groups: map[string]Group{}}
	if ok, _ := r.Match("all", "10.1.1.15"); ok {
		t.Fatal("all must not be used as a positive VM correlation")
	}
}

func TestVIPRange(t *testing.T) {
	v := VIP{Name: "vip-app", MappedIPs: []string{"10.20.10.20-10.20.10.30"}}
	if ok, _ := vipContains(v, "10.20.10.25"); !ok {
		t.Fatal("VIP range should match")
	}
}
