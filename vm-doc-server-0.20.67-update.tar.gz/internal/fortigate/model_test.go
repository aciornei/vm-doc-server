package fortigate

import "testing"

func TestParseFortiObjects(t *testing.T) {
	addr := ParseAddress(RawObject{"name": "NET-APP", "type": "ipmask", "subnet": "10.20.10.0 255.255.255.0"})
	if addr.Name != "NET-APP" || addr.Subnet != "10.20.10.0 255.255.255.0" {
		t.Fatalf("unexpected address: %#v", addr)
	}
	grp := ParseGroup(RawObject{"name": "GRP-PROD", "member": []any{map[string]any{"name": "NET-APP"}}})
	if len(grp.Members) != 1 || grp.Members[0] != "NET-APP" {
		t.Fatalf("unexpected group: %#v", grp)
	}
	pol := ParsePolicy(RawObject{
		"policyid": float64(142), "name": "APP -> DB", "status": "enable", "action": "accept", "nat": "enable",
		"srcintf": []any{map[string]any{"name": "VLAN_APP"}},
		"dstintf": []any{map[string]any{"name": "VLAN_DB"}},
		"srcaddr": []any{map[string]any{"name": "GRP-PROD"}},
		"dstaddr": []any{map[string]any{"name": "DB-PROD"}},
		"service": []any{map[string]any{"name": "TCP-5432"}},
	})
	if pol.ID != 142 || !pol.NAT || len(pol.SrcAddr) != 1 || pol.SrcAddr[0] != "GRP-PROD" || len(pol.Services) != 1 || pol.Services[0] != "TCP-5432" {
		t.Fatalf("unexpected policy: %#v", pol)
	}
	vip := ParseVIP(RawObject{"name": "app-public", "extip": "203.0.113.10", "mappedip": []any{map[string]any{"range": "10.20.10.25"}}})
	if len(vip.MappedIPs) != 1 || vip.MappedIPs[0] != "10.20.10.25" {
		t.Fatalf("unexpected VIP: %#v", vip)
	}
}
