# Upgrade vm-doc-server 0.20.12 → 0.20.13

Release exclusiv server-side. Nu necesită update de agent și nu adaugă migrare SQL.

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.12 vm-doc-server-0.20.13
tar -xzf /cale/vm-doc-server-0.20.13-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.13
cd /usr/local/src/vm-doc-server-0.20.13
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Apoi înlocuiești binarul conform fluxului normal și restartezi `vm-doc-server`.

Nu rula `go mod vendor` pe serverul izolat. Update-ul 0.20.13 nu modifică `go.mod`, `go.sum` sau `vendor/`.

## Verificări rapide

1. În Docker / Baze / Web, `Nu necesită documentare` apare deasupra asocierii la serviciu, nu într-o coloană separată.
2. Câmpurile Serviciu / Mediu / Status operațional / Tip soluție apar 2 × 2 și nu mai împing tabelul spre dreapta.
3. Bifează `Nu necesită documentare`: cardul `Completare fișă` trebuie să se actualizeze în aproximativ 250–500 ms, fără refresh complet al paginii.
4. În Inventar, marchează un serviciu sau un port/proces ca `Principal`: procentul trebuie să se actualizeze automat.
5. Clickurile rapide nu trebuie să producă suprapuneri sau actualizări ale procentului pentru alt VM.
