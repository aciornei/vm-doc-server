# VM-DOC Server 0.21.53 — transient veth history noise

Base: VM-DOC Server **0.21.52**. Agent 1.7.18 unchanged.

- Suppress auto-generated veth interfaces from change tracking (exact hexadecimal-name pattern) without removing raw networking inventory.
- Leave persistent interfaces, DNS/IP changes and manually named veth interfaces tracked.
- Cumulative optional SQL PREVIEW and CLEANUP for historic veth rows, preserving reviewed/documented/noted changes.
- No DB migration, API or dependency changes. Full vendor build and real MariaDB execution pending.
