# Upgrade VM-DOC Server 0.21.52 → 0.21.53

1. Faceți backup la surse, configurații, binar și MariaDB. Verificați restaurarea pe staging.
2. Opriți `vm-doc-server`, aplicați `vm-doc-server-0.21.53-update.tar.gz` peste **sursele 0.21.52** ori aplicați patch-ul. Sursele complete sunt în arhiva source.zip. Păstrați `vendor/` și configurațiile locale.
3. Pe sistemul de build offline: `gofmt -w internal/inventorychanges/{service.go,noise.go,veth_noise_test.go}` și `GOPROXY=off GOSUMDB=off go test ./internal/inventorychanges`; apoi `GOPROXY=off GOSUMDB=off go test ./...` și `make build` cu `vendor/`. Instalați noul binar doar dacă testele cerute intern reușesc.
4. Porniți serverul și testați o colectare care recreează un container Docker/LXC: `veth` cu sufix hex nu trebuie să apară în Modificări. Verificați concomitent schimbări reale la `ens192`, `docker0`, `br-*`, IP, gateway, DNS.
5. Pentru ștergerea zgomotului istoric **opțională**: opriți serverul, exportați DB (dump complet), rulați `scripts/preview-inventory-changes-cleanup.sql`; examinați `interfete_veth_efemere` și toate celelalte categorii **cumulative**. Dacă regulile sunt acceptate, rulați `scripts/cleanup-inventory-changes.sql` și verificați `sterse` / `evenimente_ramase`.
6. Reporniți serverul. Monitorizați 2–3 zile noile evenimente. Nu executați și scripturile de cleanup vechi, pentru că cel curent include deja toate regulile anterioare.

**Nicio migrare automată**, **API neschimbat**, **agent 1.7.18 neschimbat**, `inventory_snapshots` neatins. Scripturile SQL nu au fost executate în această sesiune pe o instanță MariaDB reală.

**Rollback:** restaurați sursele și binarul 0.21.52. Dacă ați rulat cleanup, doar restaurarea backup-ului DB readuce înregistrările șterse.
