VM-DOC Server 0.21.53 — filtare interfețe veth efemere din inventory_changes.
Base: 0.21.52, Agent 1.7.18 compatibil.
Include surse complete, update, patch, context, changelog, TODO, manual PREVIEW/CLEANUP cumulativ 0.21.50–0.21.53 și SHA256.
Backup și validare MariaDB staging înainte de ștergere. SQL nu rulează automat.
