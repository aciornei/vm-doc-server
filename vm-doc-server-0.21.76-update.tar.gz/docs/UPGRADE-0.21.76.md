# Upgrade VM-DOC Server 0.21.75 → 0.21.76

1. Fă backup directorului sursă, al binarului și al configurației; această versiune nu modifică schema MariaDB.
2. Peste sursele **0.21.75** aplică patch-ul `vm-doc-server-0.21.75-to-0.21.76.patch` sau dezarhivează `vm-doc-server-0.21.76-update.tar.gz`; nu aplica patch-ul peste altă versiune.
3. Verifică `VERSION` = `0.21.76` și execută `bash scripts/cleanup-source-tree.sh --check`.
4. În mediu offline cu `vendor/`: `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build`.
5. Oprește VM-DOC, actualizează binarul în calea indicată de `systemctl cat vm-doc-server`, repornește-l și verifică `journalctl -u vm-doc-server`.
6. În browser verifică URL-ul `app.js?v=0.21.76`, pagina **Modificări** globală și pagina VM → **Modificări**.
7. Testează un eveniment valid la primul nou snapshot și absența unui eveniment pentru colector cu `partial`.

## Rollback

Reinstalează binarul anterior 0.21.75. Datele nu necesită rollback; evenimentele apărute sub 0.21.76 rămân în DB. Comportamentul confirmării prin două observații revine la cel din 0.21.75.
