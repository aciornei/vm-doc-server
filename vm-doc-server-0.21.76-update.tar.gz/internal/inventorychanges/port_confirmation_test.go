package inventorychanges

import "testing"

func TestChangedBetweenConsecutiveSnapshots(t *testing.T) {
	old := trackedObject{Value: map[string]any{"port": 25}}
	other := trackedObject{Value: map[string]any{"port": 443}}
	if !changedBetweenSnapshots(trackedObject{}, old, false, true) {
		t.Fatal("addition must be emitted at the first new snapshot")
	}
	if !changedBetweenSnapshots(old, trackedObject{}, true, false) {
		t.Fatal("removal must be emitted at the first missing snapshot")
	}
	if !changedBetweenSnapshots(old, other, true, true) {
		t.Fatal("modification must be emitted immediately")
	}
	if changedBetweenSnapshots(old, old, true, true) {
		t.Fatal("unchanged object")
	}
	if changedBetweenSnapshots(trackedObject{}, trackedObject{}, false, false) {
		t.Fatal("both missing")
	}
}
