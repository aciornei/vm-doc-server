package inventorychanges

import (
	"encoding/json"
	"strconv"
	"strings"
)

// semanticHistoryObjects is a positive projection of known stable configuration
// fields. No collector data is deleted; every exclusion is history-only.
func semanticHistoryObjects(objects map[string]trackedObject, selectedPorts map[portSelection]bool) map[string]trackedObject {
	out := make(map[string]trackedObject, len(objects))
	for _, obj := range objects {
		value, ok := obj.Value.(map[string]any)
		if !ok {
			continue
		}
		switch obj.Category {
		case "ports":
			proto := strings.ToLower(first(value, "protocol"))
			port, err := strconv.Atoi(numberText(value["port"]))
			if err != nil || port < 1 || port > 65535 {
				continue
			}
			principal := selectedPorts[portSelection{proto, port}]
			// UDP/DNS client and mDNS/LLMNR sockets are often generated and
			// short-lived. Operators can explicitly track any of them as Principal.
			// TCP ephemeral RPC (>49151) is noisy by default, too.
			if !principal && (proto != "tcp" || port >= ephemeralPortStart ||
				port == 53 || port == 5353 || port == 5355) {
				continue
			}
			obj.Key = proto + "/" + strconv.Itoa(port)
			obj.Label = "Port " + strings.ToUpper(proto) + "/" + strconv.Itoa(port)
			obj.Value = map[string]any{"protocol": proto, "port": port}
		case "services":
			if obj.Type != "service" {
				continue
			}
			// Name is identity; enabled state is configuration, running state
			// is operational monitoring. OS-supplied systemd helper package
			// updates are represented at OS level, not dozens of unit events.
			obj.Value = pick(value, "version", "package_version", "enabled_state", "package_name")
			if strings.HasPrefix(strings.ToLower(obj.Key), "systemd-") {
				obj.Value = pick(value, "enabled_state")
			}
		case "firewall":
			if obj.Type == "firewall" {
				obj.Value = normalizeUnorderedStrictFields(pick(value, "default_policies", "active"), "default_policies")
			} else if obj.Type == "rule" {
				obj.Value = pick(value, "backend", "family", "table", "chain", "action", "rule")
			} else {
				continue
			}
		case "databases":
			switch obj.Type {
			case "database_instance":
				obj.Value = pick(value, "engine", "product", "version", "edition")
			case "database":
				if isSystemDatabase(value) {
					continue
				}
				obj.Value = pick(value, "engine", "instance", "name")
			default:
				continue
			}
		case "db_security":
			if obj.Type != "db_user" && obj.Type != "db_privilege" && obj.Type != "hba_rule" {
				continue
			}
			// Access metadata is collected without passwords. Keep only grants,
			// role memberships and HBA policy, not probe status or line number.
		case "docker":
			if obj.Type != "container" {
				continue
			}
			obj.Value = pick(value, "name", "image")
		case "web":
			if obj.Type != "web_site" {
				continue
			}
			obj.Value = normalizeUnorderedStrictFields(pick(value,
				"engine", "site_type", "name", "server_names", "enabled", "document_root",
				"config_file", "proxy_targets", "backends", "bindings"),
				"server_names", "proxy_targets", "backends", "bindings")
		case "web_acl":
			if obj.Type != "web_acl" {
				continue
			}
		case "cron":
			if obj.Type != "cron_entry" && obj.Type != "cron_script" {
				continue
			}
		case "software":
			if obj.Type != "software_package" {
				continue
			}
			obj.Value = pick(value, "name", "version", "publisher", "architecture", "scope", "kind", "state")
		case "network":
			if obj.Type == "interface" {
				obj.Value = normalizeUnorderedStrictFields(pick(value, "name", "addresses", "mtu"), "addresses")
			} else if obj.Type == "resolver" {
				obj.Value = normalizeUnorderedStrictFields(pick(value, "default_gateways", "dns_servers", "search_domains"), "default_gateways", "dns_servers", "search_domains")
			} else {
				continue
			}
		case "storage":
			if obj.Type != "partition" {
				continue
			}
			fs := strings.ToLower(first(value, "filesystem"))
			mp := first(value, "mount_point")
			if fs == "overlay" || fs == "aufs" || strings.HasPrefix(mp, "/var/lib/docker/") {
				continue
			}
			obj.Value = pick(value, "device", "mount_point", "filesystem", "total_bytes", "read_only")
		case "integrations":
			obj.Value = pick(value, "installed", "version", "package_version", "service_enabled")
		case "identity":
			obj.Value = pick(value, "installed", "version", "config_present", "services", "domains")
		case "time":
			obj.Value = pick(value, "installed", "implementation", "version", "service_enabled", "servers")
		case "system", "accounts":
			// Only stable identity or account security fields were extracted.
		default:
			continue
		}
		out[obj.Category+"|"+obj.Type+"|"+obj.Key] = obj
	}
	return out
}

func isSystemDatabase(value map[string]any) bool {
	v, ok := value["system"].(bool)
	return ok && v
}

// healthyForObject checks the two snapshots being compared. Missing
// collectors, partial results, timeouts, disabled, and truncations are not valid
// evidence for any add/modify/remove. Legacy snapshots without collection
// metadata are allowed for backwards compatibility; if either snapshot provides
// statuses, both must report success for the pertinent collector.
func healthyForObject(previousRaw, currentRaw []byte, obj trackedObject) bool {
	collector := collectorForCategory(obj.Category)
	if collector == "" {
		return false
	}
	samples := [][]byte{previousRaw, currentRaw}
	roots := make([]map[string]any, 0, 2)
	anyStatuses := false
	for _, raw := range samples {
		var root map[string]any
		if json.Unmarshal(raw, &root) != nil {
			return false
		}
		roots = append(roots, root)
		collect := asMap(root["collection"])
		if collect != nil && asMap(collect["collectors"]) != nil {
			anyStatuses = true
		}
	}
	for _, root := range roots {
		if anyStatuses {
			collect := asMap(root["collection"])
			st := asMap(asMap(collect["collectors"])[collector])
			if !strings.EqualFold(first(st, "status"), "success") || st["truncated"] == true {
				return false
			}
		}
		truncations := asMap(root["truncations"])
		if _, exists := truncations[collector]; exists {
			return false
		}
		// Some nested DB enumerations may succeed only in metadata-only mode
		// even if the outer database collector reports success.
		if obj.Category == "db_security" || obj.Type == "database" {
			db := asMap(root["databases"])
			if db == nil {
				return false
			}
			for _, it := range asSlice(db["instances"]) {
				inst := asMap(it)
				if obj.Category == "db_security" && !strings.EqualFold(first(asMap(inst["access"]), "status"), "discovered") {
					return false
				}
				if obj.Type == "database" && !strings.EqualFold(first(inst, "catalog_discovery_status"), "discovered") {
					return false
				}
			}
		}
	}
	return true
}

func collectorForCategory(category string) string {
	switch category {
	case "system":
		return "system"
	case "storage":
		return "storage"
	case "network":
		return "network"
	case "services":
		return "services"
	case "ports":
		return "listening_ports"
	case "firewall":
		return "firewall"
	case "accounts":
		return "accounts"
	case "identity":
		return "sssd"
	case "integrations":
		return "integrations"
	case "time":
		return "ntp"
	case "databases", "db_security":
		return "databases"
	case "docker":
		return "docker"
	case "web", "web_acl":
		return "web"
	case "cron":
		return "cron"
	case "software":
		return "software"
	default:
		return ""
	}
}

func objectForPair(old, current trackedObject, hadOld, hadCurrent bool) trackedObject {
	if hadCurrent {
		return current
	}
	if hadOld {
		return old
	}
	return trackedObject{}
}
