package inventorychanges

import (
	"encoding/json"
	"fmt"
	"testing"
)

func semanticObjectsForTest(t *testing.T, raw string, selected map[portSelection]bool) map[string]trackedObject {
	t.Helper()
	objects, err := extractTracked([]byte(raw))
	if err != nil {
		t.Fatal(err)
	}
	return semanticHistoryObjects(objects, selected)
}

func TestSemanticPortsPostfixUDPAndGeneratedDNS(t *testing.T) {
	raw := `{"listening_ports":[{"protocol":"tcp","port":25,"processes":[{"name":"master"}]},{"protocol":"tcp","port":25,"processes":[{"name":"master"},{"name":"smtpd"}]},{"protocol":"udp","port":36761},{"protocol":"tcp","port":53},{"protocol":"udp","port":53},{"protocol":"tcp","port":54991},{"protocol":"tcp","port":443}]}`
	got := semanticObjectsForTest(t, raw, nil)
	for _, port := range []string{"tcp/25", "tcp/443"} {
		if _, ok := got["ports|listening_port|"+port]; !ok {
			t.Errorf("missing stable TCP/%s", port)
		}
	}
	for _, port := range []string{"udp/36761", "tcp/53", "udp/53", "tcp/54991"} {
		if _, ok := got["ports|listening_port|"+port]; ok {
			t.Errorf("noisy generated port %s tracked", port)
		}
	}
	got = semanticObjectsForTest(t, raw, map[portSelection]bool{{"udp", 36761}: true, {"tcp", 53}: true, {"udp", 53}: true, {"tcp", 54991}: true})
	for _, port := range []string{"udp/36761", "tcp/53", "udp/53", "tcp/54991"} {
		if _, ok := got["ports|listening_port|"+port]; !ok {
			t.Errorf("principal port %s not tracked", port)
		}
	}
	onlyMaster := semanticObjectsForTest(t, `{"listening_ports":[{"protocol":"tcp","port":25,"processes":[{"name":"master"}]}]}`, nil)
	withSMTPD := semanticObjectsForTest(t, `{"listening_ports":[{"protocol":"tcp","port":25,"processes":[{"name":"master"},{"name":"smtpd"}]}]}`, nil)
	if !canonicalEqual(onlyMaster["ports|listening_port|tcp/25"].Value, withSMTPD["ports|listening_port|tcp/25"].Value) {
		t.Fatal("Postfix worker fluctuation generated false diff")
	}
}

func TestSemanticDetectsExplicitFirewallServicesAndSoftware(t *testing.T) {
	a := `{"services":[{"name":"postgresql.service","version":"15.4","enabled_state":"enabled"},{"name":"systemd-journald.service","version":"255.4","enabled_state":"enabled"}],"firewall":{"rules":[{"backend":"nftables","family":"ip","table":"filter","chain":"INPUT","rule":"tcp dport 443 accept","action":"accept"},{"backend":"iptables","family":"ipv4","table":"nat","chain":"POSTROUTING","rule":"-A POSTROUTING -s 172.19.0.0/16 ! -o br-f7410327c933 -j MASQUERADE","action":"MASQUERADE"}]},"software":{"items":[{"name":"7-Zip","version":"23.01","kind":"desktop"}]}}`
	b := `{"services":[{"name":"postgresql.service","version":"15.5","enabled_state":"enabled"},{"name":"systemd-journald.service","version":"255.5","enabled_state":"enabled"}],"firewall":{"rules":[{"backend":"nftables","family":"ip","table":"filter","chain":"INPUT","rule":"tcp dport 8443 accept","action":"accept"},{"backend":"iptables","family":"ipv4","table":"nat","chain":"POSTROUTING","rule":"-A POSTROUTING -s 172.19.0.0/16 ! -o br-8214d3580664 -j MASQUERADE","action":"MASQUERADE"}]},"software":{"items":[{"name":"7-Zip","version":"24.01","kind":"desktop"}]}}`
	old, newItems := semanticObjectsForTest(t, a, nil), semanticObjectsForTest(t, b, nil)
	if canonicalEqual(old["services|service|postgresql.service"].Value, newItems["services|service|postgresql.service"].Value) {
		t.Fatal("real service upgrade suppressed")
	}
	if !canonicalEqual(old["services|service|systemd-journald.service"].Value, newItems["services|service|systemd-journald.service"].Value) {
		t.Fatal("systemd package fanout is noise")
	}
	firewallOld, firewallNew := 0, 0
	for k := range old {
		if len(k) > 14 && k[:14] == "firewall|rule|" {
			firewallOld++
		}
	}
	for k := range newItems {
		if len(k) > 14 && k[:14] == "firewall|rule|" {
			firewallNew++
		}
	}
	if firewallOld != 1 || firewallNew != 1 {
		t.Fatalf("expected only explicit firewall rules: %d/%d", firewallOld, firewallNew)
	}
	for k, v := range old {
		if v.Type == "software_package" {
			if canonicalEqual(v.Value, newItems[k].Value) {
				t.Fatal("real software upgrade suppressed")
			}
			return
		}
	}
	t.Fatal("software package was omitted")
}

func TestSemanticCronHBAAccessAndWebACL(t *testing.T) {
	raw := `{"cron":{"entries":[{"source":"/etc/crontab","user":"backup","schedule":"0 2 * * *","command":"/usr/local/bin/backup","line":13}]},"databases":{"instances":[{"engine":"postgresql","instance_name":"main","catalog_discovery_status":"discovered","access":{"status":"discovered","principals":[{"name":"app","login":true,"roles":["readonly"]}],"privileges":[{"principal":"app","scope":"database","database":"portal","privilege":"CONNECT"}],"hba_rules":[{"type":"host","databases":["portal"],"users":["app"],"address":"10.0.0.0/8","method":"scram-sha-256","source_file":"/etc/postgresql/pg_hba.conf","line":17}]}}]},"web":{"sites":[{"name":"portal","engine":"nginx","access_control":[{"action":"deny","source":"10.1.2.3","scope":"location","source_file":"/etc/nginx/sites-enabled/portal"}]}]}}`
	got := semanticObjectsForTest(t, raw, nil)
	want := map[string]bool{"cron_entry": false, "db_user": false, "db_privilege": false, "hba_rule": false, "web_acl": false}
	for _, obj := range got {
		if _, ok := want[obj.Type]; ok {
			want[obj.Type] = true
		}
	}
	for k, v := range want {
		if !v {
			t.Errorf("missing %s", k)
		}
	}
}

func TestSemanticCollectorHealthPreventsFalseRemovals(t *testing.T) {
	wrap := func(status string, truncated bool) []byte {
		m := map[string]any{"collection": map[string]any{"collectors": map[string]any{"firewall": map[string]any{"status": status, "truncated": truncated}, "services": map[string]any{"status": "success"}}}, "firewall": map[string]any{"rules": []any{}}}
		data, _ := json.Marshal(m)
		return data
	}
	old, partial, good := wrap("success", false), wrap("partial", false), wrap("success", false)
	fw := trackedObject{Category: "firewall", Type: "rule"}
	if healthyForObject(old, partial, fw) {
		t.Fatal("partial collector may not imply deletion")
	}
	if healthyForObject(old, wrap("success", true), fw) {
		t.Fatal("truncated collector may not imply deletion")
	}
	if !healthyForObject(old, good, fw) {
		t.Fatal("three successful snapshots should permit changes")
	}
	if !healthyForObject(old, partial, trackedObject{Category: "services", Type: "service"}) {
		t.Fatal("unrelated firewall failure must not block service history")
	}
}

func TestSemanticAccessIncompleteDoesNotEraseUsers(t *testing.T) {
	mk := func(access string) []byte {
		raw := fmt.Sprintf(`{"collection":{"collectors":{"databases":{"status":"success"}}},"databases":{"instances":[{"engine":"postgresql","instance_name":"main","catalog_discovery_status":"discovered","access":{"status":%q}}]}}`, access)
		return []byte(raw)
	}
	obj := trackedObject{Category: "db_security", Type: "db_user"}
	if healthyForObject(mk("discovered"), mk("partial"), obj) {
		t.Fatal("partial DB access produced deletion")
	}
	if !healthyForObject(mk("discovered"), mk("discovered"), obj) {
		t.Fatal("discovered DB access should allow changes")
	}
}

func TestSemanticVersionProbeBlankIsNotUpgrade(t *testing.T) {
	a := trackedObject{Category: "databases", Type: "database_instance", Value: map[string]any{"version": "14.2", "engine": "postgresql"}}
	b := trackedObject{Category: "databases", Type: "database_instance", Value: map[string]any{"engine": "postgresql"}}
	if changedBetweenSnapshots(a, b, true, true) {
		t.Fatal("missing version probe created modification")
	}
}
