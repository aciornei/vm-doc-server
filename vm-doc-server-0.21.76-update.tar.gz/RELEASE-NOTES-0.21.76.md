# VM-DOC Server 0.21.76 — Căutare Modificări și comparație 1:1

## Schimbări

- În lista globală **Modificări** și în fila VM → **Modificări**, căutarea se aplică după tastare (debounce 200 ms), la Enter și la golirea câmpului; afișează mesaj cu termenul căutat când nu există rezultate.
- Căutarea în API (`GET /api/v1/changes?q=...`) include în plus `object_key`, `object_type` și `category`, alături de nume VM, hostname, descriere și note. Nu face full-scan în coloanele JSON mari.
- Cererile asincrone vechi nu mai pot înlocui o listă deja filtrată printr-un termen mai nou; la căutare paginarea revine la prima pagină.
- Detectorul compară snapshotul anterior cu cel curent **1:1**; pentru schimbări relevante nu mai așteaptă două observații succesive ale stării noi.
- Bariera de sănătate a colectorilor rămâne: pentru categoria respectivă ambele snapshoturi comparate trebuie să aibă colectare completă (`success`), dacă există metadata; accesul incomplet la DB și truncările blochează evenimentele.
- Filtrele semantice din 0.21.73 rămân: UDP și porturi dinamice/DNS nemarcate Principal, Docker runtime, reguli generate etc. nu devin evenimente noi automat.

## Limitări și comportament asumat

- După eliminarea confirmării prin a treia colectare, un obiect prezent în două snapshoturi valide diferite poate genera un eveniment și dacă fluctuația dispare la următoarea colectare. Acesta este comportamentul 1:1 solicitat; filtrele de zgomot și calitatea colectoarelor limitează riscul.
- Nu se reprocesează snapshoturi istorice. Modificarea este pentru colectările noi, după instalarea binarului.
- Nu se șterg evenimente, baseline-uri, documente sau snapshoturi existente.
- Nu există migrare SQL. Agentul rămâne **1.7.18**.

## Validare staging

1. Caută în Modificări un hostname, nume de obiect, `TCP/25`, tipul obiectului și o cheie specifică.
2. Confirmă că după Enter și după ștergerea textului rezultatul se schimbă și pagina revine la 1.
3. Colectează de două ori succesiv un VM de test, cu o schimbare reală între snapshoturi. Evenimentul trebuie să apară după prima colectare care observă schimbarea.
4. Simulează o colectare `partial`/`timeout` și verifică faptul că nu generează ștergeri.
5. Verifică că un TCP/25 cu variații `master/smtpd` și un UDP dinamic nemarcat Principal nu generează evenimente.
