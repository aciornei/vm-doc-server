const fs=require('fs');
const vm=require('vm');
const assert=require('assert/strict');
const source=fs.readFileSync('web/static/js/app.js','utf8');
const bindStart=source.indexOf('function bindChangeFilters(');
const bindEnd=source.indexOf('\nlet changeSearchGlobalTicket',bindStart);
assert(bindStart>=0&&bindEnd>bindStart,'search handler exists');
const queryStart=source.indexOf('function changeFilterQuery(');
const queryEnd=source.indexOf('\nfunction changesFilterHTML(',queryStart);
const events=new Map();
const field={value:'',addEventListener:(type,handler)=>events.set(type,handler)};
const els={changeSearch:field};
const document={getElementById:id=>els[id]||null};
const f={q:'',category:'',changeType:'',doc:'',review:'',page:3,pageSize:25};
let reloads=0;
const context={document,clearTimeout,setTimeout,URLSearchParams,reload:()=>{reloads++},f};
vm.createContext(context);
vm.runInContext(source.slice(bindStart,bindEnd)+'\n'+source.slice(queryStart,queryEnd)+'\nbindChangeFilters(reload,f);',context);
(async()=>{
  field.value='tcp/25';events.get('input')({});await new Promise(r=>setTimeout(r,270));
  assert.equal(f.q,'tcp/25');assert.equal(f.page,1);assert.equal(reloads,1);
  assert(context.changeFilterQuery(f).includes('q=tcp%2F25'));
  field.value='auditbeat';events.get('keydown')({key:'Enter',preventDefault(){}});
  assert.equal(f.q,'auditbeat');assert.equal(reloads,2);
  field.value='';events.get('search')({});assert.equal(f.q,'');assert.equal(reloads,3);
  // Changing the existing query must not trigger duplicate loads.
  events.get('change')({});assert.equal(reloads,3);
  console.log('PASS search input, Enter, clear search, API URL and pagination reset');
})().catch(e=>{console.error(e);process.exitCode=1});
