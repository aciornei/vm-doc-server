package documents

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"io"
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/external"
	"vm-doc-server/internal/inventory"
)

func TestDefaultTemplateAndRender(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplate(template); err != nil {
		t.Fatal(err)
	}
	now := time.Date(2026, 9, 1, 12, 30, 0, 0, time.UTC)
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{{Key: "network", Title: "Rețea", Data: map[string]any{"primary_ip": "10.0.0.10"}}}}
	data := GenerationData{
		VM:                  domain.VirtualMachine{ID: 295, Name: "vm-test", CPUCount: 4, MemoryMiB: 8192, PowerState: "poweredOn", GuestHostname: "vm-test", PrimaryIP: "10.0.0.10"},
		Operational:         domain.VMOperationalMetadata{Environment: "Producție", OperationalStatus: "Activ"},
		PrimaryServices:     []domain.PrimaryAgentService{{ServiceName: "postfix.service", SoftwareName: "Postfix", Version: "3.8.6", PackageName: "postfix", PackageVersion: "3.8.6-1", ActiveState: "active", EnabledState: "enabled", Detected: true}},
		PrimaryPorts:        []domain.PrimaryAgentPort{{Protocol: "tcp", Port: 8100, ProcessName: "soffice.bin", PIDs: []int{4412}, Executable: "/usr/lib/libreoffice/program/soffice.bin", Addresses: []string{"127.0.0.1"}, Detected: true}},
		ExternalConnections: []external.Connection{{ExternalSystemName: "Partner API", ExternalHostname: "api.partner.example", NetworkName: "Internet", NetworkCode: "internet", NetworkColor: "#DC2626", NetworkZoneType: "internet", NetworkRiskLevel: "high", NetworkTrustLevel: "untrusted", Direction: "outbound", RemoteService: "HTTPS API", Protocol: "tcp", Port: intPtr(443), TLSEnabled: true, Authentication: "OAuth2", Purpose: "Schimb date"}},
		InventoryDocument:   &view,
		GeneratedBy:         domain.User{Username: "tester", DisplayName: "Test User"},
		GeneratedAt:         now,
		DocumentNumber:      "FVM-20260901-000295-ABCD",
	}
	output, err := RenderDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	reader, err := zip.NewReader(bytes.NewReader(output), int64(len(output)))
	if err != nil {
		t.Fatal(err)
	}
	var document string
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		handle, err := file.Open()
		if err != nil {
			t.Fatal(err)
		}
		content, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		document = string(content)
	}
	if document == "" {
		t.Fatal("word/document.xml missing")
	}
	if strings.Contains(document, BodyPlaceholder) {
		t.Fatal("body placeholder was not replaced")
	}
	for _, expected := range []string{"Fișă tehnică VM", "vm-test", "FVM-20260901-000295-ABCD", "Componente software principale", "Postfix", "3.8.6", "postfix.service", "Porturi și procese principale", "8100", "soffice.bin", "/usr/lib/libreoffice/program/soffice.bin", "Conexiuni către sisteme externe", "Partner API", "api.partner.example", "HTTPS API", "Internet", "OAuth2", "Rețea", "10.0.0.10"} {
		if !strings.Contains(document, expected) {
			t.Fatalf("document does not contain %q", expected)
		}
	}
}

func TestValidateTemplateRequiresBodyPlaceholder(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	reader, err := zip.NewReader(bytes.NewReader(template), int64(len(template)))
	if err != nil {
		t.Fatal(err)
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	for _, source := range reader.File {
		handle, err := source.Open()
		if err != nil {
			t.Fatal(err)
		}
		content, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		if source.Name == "word/document.xml" {
			content = bytes.ReplaceAll(content, []byte(BodyPlaceholder), []byte("missing"))
		}
		destination, err := writer.Create(source.Name)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := destination.Write(content); err != nil {
			t.Fatal(err)
		}
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplate(output.Bytes()); err == nil {
		t.Fatal("expected validation error")
	}
}

func TestCompactInventoryRendering(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{
		{Key: "schema", Data: map[string]any{"name": "vm-doc-agent-inventory", "version": "2.0"}},
		{Key: "agent", Data: map[string]any{"version": "1.0.0"}},
		{Key: "system", Data: map[string]any{"architecture": "x86_64", "uptime_seconds": json.Number("123456")}},
		{Key: "os", Data: map[string]any{"name": "Ubuntu", "version": "24.04"}},
		{Key: "storage", Data: map[string]any{"mounts": []any{
			map[string]any{"mount_point": "/", "filesystem": "ext4", "size_bytes": json.Number("107374182400")},
			map[string]any{"mount_point": "/data", "filesystem": "xfs", "size_bytes": json.Number("1099511627776")},
		}}},
		{Key: "network", Data: map[string]any{"interfaces": []any{
			map[string]any{"name": "ens192", "addresses": []any{"10.20.30.40/24"}, "gateway": "10.20.30.1", "dns_servers": []any{"10.20.0.10", "10.20.0.11"}},
		}}},
		{Key: "proxy", Data: map[string]any{"http_proxy": "http://proxy.example"}},
		{Key: "services", Data: []any{
			map[string]any{"name": "sshd.service", "description": "OpenSSH server", "status": "active"},
			map[string]any{"name": "cups.service", "description": "Printing", "status": "inactive"},
		}},
		{Key: "listening_ports", Data: []any{
			map[string]any{"address": "0.0.0.0", "port": json.Number("22"), "protocol": "tcp", "processes": []any{map[string]any{"pid": json.Number("4242"), "name": "sshd", "executable": "/usr/sbin/sshd"}}},
		}},
		{Key: "firewall", Data: map[string]any{
			"detected": true, "active": true, "backends": []any{"nftables", "firewalld"},
			"default_policies": map[string]any{"nftables:inet:filter:input": "drop"},
			"zones":            []any{map[string]any{"name": "public", "active": true, "interfaces": []any{"ens192"}, "services": []any{"ssh", "https"}}},
			"rules":            []any{map[string]any{"backend": "nftables", "family": "inet", "table": "filter", "chain": "input", "action": "accept", "rule": "tcp dport 22 accept"}},
		}},
		{Key: "accounts", Data: []any{
			map[string]any{"username": "root", "uid": json.Number("0"), "home": "/root", "shell": "/bin/bash", "system_account": true},
			map[string]any{"username": "service", "uid": json.Number("500"), "home": "/srv/service", "shell": "/usr/sbin/nologin", "system_account": true},
			map[string]any{"username": "operator", "uid": json.Number("1000"), "home": "/home/operator", "shell": "/bin/bash", "system_account": false},
			map[string]any{"username": "appadmin", "uid": json.Number("1001"), "home": "/home/appadmin", "groups": []any{"sudo"}, "system_account": false},
		}},
		{Key: "sssd", Data: map[string]any{"installed": true, "ldap_search_base": "OU=Linux,DC=example,DC=ro", "version": "2.9.4"}},
		{Key: "integrations", Data: map[string]any{
			"auditbeat":     map[string]any{"installed": true, "version": "8.16", "config_ok": true, "output_host": "graylog.example.ro", "details": "system module"},
			"filebeat":      map[string]any{"installed": true, "version": "8.16", "config_ok": true, "output_host": "logstash.example.ro"},
			"glpi_agent":    map[string]any{"installed": true, "version": "1.15", "config_ok": true, "server": "glpi.example.ro"},
			"node_exporter": map[string]any{"installed": true, "version": "1.9.1", "config_ok": true, "host": "0.0.0.0:9100"},
			"syslog":        map[string]any{"enabled": true, "version": "8.2312", "config_ok": true, "destination": "graylog.example.ro:514"},
		}},
		{Key: "policies", Data: map[string]any{"vm_doc_policy_marker": "THIS_POLICY_SECTION_MUST_NOT_RENDER"}},
		{Key: "cron", Data: []any{map[string]any{"schedule": "0 2 * * *", "command": "/opt/app/backup.sh", "user": "root"}}},
		{Key: "ntp", Data: map[string]any{"conf_file": "/etc/chrony/chrony.conf", "sources": []any{"ntp1.example.ro", "ntp2.example.ro"}, "version": "4.5"}},
	}}
	data := GenerationData{
		VM:                domain.VirtualMachine{ID: 295, Name: "metabase", CPUCount: 4, MemoryMiB: 8192},
		InventoryDocument: &view,
		GeneratedAt:       time.Date(2026, 9, 1, 12, 30, 0, 0, time.UTC),
		DocumentNumber:    "FVM-TEST",
	}
	output, err := RenderDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	document := documentXMLFromDOCX(t, output)
	for _, expected := range []string{
		"9.3 Stocare", "100 GB", "1.00 TB", "ens192", "10.20.30.40", "sshd.service", "sshd (PID 4242)", "/usr/sbin/sshd", "nftables", "Zone firewalld", "public", "operator", "appadmin", "OU=Linux,DC=example,DC=ro", "Auditbeat", "graylog.example.ro", "/etc/chrony/chrony.conf", "<w:tblGrid>",
	} {
		if !strings.Contains(document, expected) {
			t.Fatalf("document does not contain %q", expected)
		}
	}
	for _, unexpected := range []string{"9.2 Agent", "9.7 Proxy", "uptime_seconds", "cups.service", "/srv/service", "http://proxy.example", "THIS_POLICY_SECTION_MUST_NOT_RENDER", "vm_doc_policy_marker", "tcp dport 22 accept"} {
		if strings.Contains(document, unexpected) {
			t.Fatalf("document unexpectedly contains %q", unexpected)
		}
	}
}

func documentXMLFromDOCX(t *testing.T, content []byte) string {
	t.Helper()
	reader, err := zip.NewReader(bytes.NewReader(content), int64(len(content)))
	if err != nil {
		t.Fatal(err)
	}
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		handle, err := file.Open()
		if err != nil {
			t.Fatal(err)
		}
		data, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		return string(data)
	}
	t.Fatal("word/document.xml missing")
	return ""
}

func TestDefaultServiceTemplateAndRender(t *testing.T) {
	template, err := DefaultServiceTemplate()
	if err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplateFor(template, "service"); err != nil {
		t.Fatal(err)
	}
	now := time.Date(2026, 9, 2, 8, 30, 0, 0, time.UTC)
	service := domain.InternalService{
		ID:          17,
		Name:        "Metabase",
		ServiceCode: "metabase",
		Description: "Platformă internă de raportare.",
		Purpose:     "Serviciul furnizează raportare BI internă pentru echipele operaționale și management.",
		PurposeRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{
			{Type: "paragraph", Runs: []domain.RichTextRun{{Text: "Serviciul furnizează ", Bold: false}, {Text: "raportare BI internă", Bold: true}, {Text: " pentru echipele operaționale și management."}}},
		}},
		Objectives: "Centralizarea indicatorilor.\nReducerea raportării manuale.\nAcces controlat la dashboard-uri.",
		ObjectivesRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{
			{Type: "bullet", Runs: []domain.RichTextRun{{Text: "Centralizarea indicatorilor.", Italic: true}}},
			{Type: "bullet", Runs: []domain.RichTextRun{{Text: "Reducerea raportării manuale.", Underline: true}}},
			{Type: "number", Runs: []domain.RichTextRun{{Text: "Acces controlat la dashboard-uri."}}},
		}},
		Criticality:         "high",
		DocumentationStatus: "approved",
		Active:              true,
		VMCount:             2,
		Classifications: []domain.InternalServiceClassification{{
			ArchitecturalDomainID: 1, ArchitecturalDomain: "Aplicații de business", ITILCategoryID: 2, ITILCategory: "Raportare", VMCount: 2, AssignmentCount: 2,
		}},
		SolutionTypes: []domain.InternalServiceSolutionType{{SolutionTypeID: 3, SolutionType: "Open source", VMCount: 2, AssignmentCount: 2}},
		Dependencies:  []domain.ServiceDependency{{TargetServiceID: 90, TargetServiceName: "Active Directory", DependencyTypeID: 91, DependencyType: "Autentificare", TargetVMCount: 2, TargetVMNames: "dc01, dc02", Notes: "Autentificare utilizatori"}},
		RoleMappings: []domain.ServiceRoleMapping{
			{LayerID: 1, LayerName: "Aplicație", TechnicalRoleID: 2, TechnicalRole: "Aplicație BI", VMCount: 1},
			{LayerID: 3, LayerName: "Date", TechnicalRoleID: 4, TechnicalRole: "MariaDB", VMCount: 1},
		},
		VMs: []domain.InternalServiceVM{
			{AssignmentID: 101, ID: 10, Name: "metabase01", GuestHostname: "metabase01", PrimaryIP: "10.20.30.40", PowerState: "poweredOn", Environment: "PROD", LatestDocumentNumber: "FVM-20260902-000010-AAAA", ArchitecturalDomain: "Aplicații de business", ITILCategory: "Raportare", LayerID: int64Ptr(1), LayerName: "Aplicație", TechnicalRoleID: int64Ptr(2), TechnicalRole: "Aplicație BI", SolutionType: "Open source", UsageType: "dedicated", Primary: true},
			{AssignmentID: 102, ID: 10, Name: "metabase01", GuestHostname: "metabase01", PrimaryIP: "10.20.30.40", PowerState: "poweredOn", Environment: "PROD", LatestDocumentNumber: "FVM-20260902-000010-AAAA", ArchitecturalDomain: "Aplicații de business", ITILCategory: "Raportare", LayerID: int64Ptr(3), LayerName: "Date", TechnicalRoleID: int64Ptr(4), TechnicalRole: "MariaDB", SolutionType: "Open source", UsageType: "dedicated"},
		},
	}
	data := ServiceGenerationData{Service: service, GeneratedBy: domain.User{Username: "tester", DisplayName: "Test User"}, GeneratedAt: now, DocumentNumber: "FSI-20260902-000017-ABCD", BaseURL: "https://vm-doc.example", IncludeVMAnnexes: true, ExternalConnections: []external.Connection{{ExternalSystemName: "BI Vendor", ExternalHostname: "bi.vendor.example", NetworkName: "Internet", NetworkCode: "internet", NetworkColor: "#DC2626", NetworkZoneType: "internet", NetworkRiskLevel: "high", NetworkTrustLevel: "untrusted", Direction: "outbound", RemoteService: "HTTPS API", Protocol: "tcp", Port: intPtr(443), TLSEnabled: true, Authentication: "API key", Purpose: "Export rapoarte", InternalServiceName: "Metabase"}}, PrimaryComponents: []ServicePrimaryComponent{{VMID: 10, VMName: "metabase01", Environment: "PROD", ServiceName: "mariadb.service", SoftwareName: "MariaDB", Version: "10.11.13", PackageName: "mariadb-server", PackageVersion: "1:10.11.13", ActiveState: "active", EnabledState: "enabled", Detected: true}}, VMDocuments: []ServiceVMDocument{{VMID: 10, VMName: "metabase01", Environment: "PROD", DocumentID: 77, DocumentNumber: "FVM-20260902-000010-AAAA", FileName: "metabase01.docx", GeneratedAt: now, DownloadURL: "https://vm-doc.example/api/v1/documents/77/download"}}}
	backupTime := now.Add(-2 * time.Hour)
	nextRun := now.Add(22 * time.Hour)
	data.Backups = []ServiceVMBackup{{VMID: 10, VMName: "metabase01", Environment: "PROD", Backup: domain.VMBackupSummary{VMID: 10, Provider: "veeam", SourceName: "Veeam principal", Protected: true, JobName: "JOB-PROD", RepositoryName: "Repo-01", LastResult: "Success", LastBackupAt: &backupTime, NextRunAt: &nextRun, RestorePoints: intPtr(14), SyncedAt: &now}}}
	output, err := RenderServiceDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	document := documentXMLFromDOCX(t, output)
	if strings.Contains(document, ServiceBodyPlaceholder) {
		t.Fatal("service body placeholder was not replaced")
	}
	for _, expected := range []string{"Fișă serviciu intern", "Metabase", "FSI-20260902-000017-ABCD", "Scop și domeniu", "Obiective", "Schemă logică a serviciului", "Multi-layer", "Aplicații de business", "Open source", "Aplicație BI", "MariaDB", "metabase01", "10.20.30.40", "PROD", "Încadrare pe medii", "Legături către fișele VM", "Deschide fișa", "https://vm-doc.example/api/v1/documents/77/download", "Anexe", "FVM-20260902-000010-AAAA", "Reducerea raportării manuale", "Active Directory", "Autentificare", "dc01, dc02", "Componente software principale", "MariaDB", "10.11.13", "mariadb.service", "Conexiuni către sisteme externe", "BI Vendor", "bi.vendor.example", "Export rapoarte", "Backup și restaurare", "JOB-PROD", "Repo-01", "Success", "14", "• ", "1. ", `<w:u w:val="single"/>`, `<w:i/>`} {
		if !strings.Contains(document, expected) {
			t.Fatalf("service document does not contain %q", expected)
		}
	}
}

func TestServiceDiagramGroupsVMOnlyOnce(t *testing.T) {
	assignments := []domain.InternalServiceVM{
		{ID: 10, Name: "vm01", LayerName: "Aplicație", TechnicalRole: "Backend"},
		{ID: 10, Name: "vm01", LayerName: "Date", TechnicalRole: "MariaDB"},
		{ID: 11, Name: "vm02", LayerName: "Aplicație", TechnicalRole: "Frontend"},
	}
	lanes := buildServiceDiagramLanes(assignments)
	vmCount := 0
	var vm01 *serviceDiagramVM
	for i := range lanes {
		vmCount += len(lanes[i].VMs)
		for j := range lanes[i].VMs {
			if lanes[i].VMs[j].ID == 10 {
				vm01 = &lanes[i].VMs[j]
			}
		}
	}
	if vmCount != 2 {
		t.Fatalf("expected 2 unique VM nodes, got %d", vmCount)
	}
	if vm01 == nil || len(vm01.Assignments) != 2 {
		t.Fatalf("expected vm01 once with 2 assignments, got %#v", vm01)
	}
}

func int64Ptr(value int64) *int64 { return &value }
func intPtr(value int) *int       { return &value }

func TestServiceTemplateRejectsVMTemplate(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplateFor(template, "service"); err == nil {
		t.Fatal("expected service template validation error")
	}
}

func TestCommonServiceDocumentIncludesDirectVMImpact(t *testing.T) {
	template, err := DefaultServiceTemplate()
	if err != nil {
		t.Fatal(err)
	}
	service := domain.InternalService{
		ID:                    90,
		Name:                  "OpenLDAP",
		ServiceCode:           "openldap",
		Criticality:           "high",
		DocumentationStatus:   "approved",
		Active:                true,
		IsCommon:              true,
		CommonDependencyType:  "Directory / Identity",
		DependentServiceCount: 1,
		Dependents: []domain.ServiceDependency{{
			SourceServiceID: 12, SourceServiceName: "Resurse Umane", TargetServiceID: 90, TargetServiceName: "OpenLDAP", DependencyTypeID: 2, DependencyType: "Directory / Identity",
		}},
		DirectVMDependents: []domain.VMDependencyImpact{{
			VMID: 44, VMName: "legacy-app01", DependencyTypeID: 2, DependencyType: "Directory / Identity", Notes: "Integrare LDAP directă",
		}},
	}
	data := ServiceGenerationData{Service: service, GeneratedBy: domain.User{Username: "tester"}, GeneratedAt: time.Date(2026, 9, 2, 12, 0, 0, 0, time.UTC), DocumentNumber: "FSI-TEST"}
	output, err := RenderServiceDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	document := documentXMLFromDOCX(t, output)
	for _, expected := range []string{"Impact asupra serviciilor dependente", "Resurse Umane", "VM-uri dependente direct", "legacy-app01", "Integrare LDAP directă"} {
		if !strings.Contains(document, expected) {
			t.Fatalf("common service document does not contain %q", expected)
		}
	}
}

func TestVMDocumentOmitsEmptyOptionalInventorySectionsAndKeepsNumbering(t *testing.T) {
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{{Key: "network", Data: map[string]any{"primary_ip": "10.0.0.10"}}}}
	data := GenerationData{
		VM:                domain.VirtualMachine{ID: 1, Name: "vm-no-optional"},
		InventoryDocument: &view,
		GeneratedAt:       time.Date(2026, 9, 5, 8, 0, 0, 0, time.UTC),
		DocumentNumber:    "FVM-TEST-OPTIONAL",
	}
	body := documentBodyXML(data)
	for _, unexpected := range []string{"Docker și containere", "Baze de date", "Site-uri web și frontends"} {
		if strings.Contains(body, unexpected) {
			t.Fatalf("empty optional section %q should not be rendered", unexpected)
		}
	}
	for _, expected := range []string{"9. Inventar agent", "9.1 Sistem și hardware", "9.4 Rețea", "9.7 Firewall"} {
		if !strings.Contains(body, expected) {
			t.Fatalf("expected dynamic inventory heading %q", expected)
		}
	}
	if strings.Index(body, "9. Inventar agent") > strings.Index(body, "9.1 Sistem și hardware") {
		t.Fatal("inventory chapter must appear before its subsections")
	}
	for _, unexpected := range []string{"Schema inventar", "9.14 ", "9.2 Agent", "9.5 Proxy"} {
		if strings.Contains(body, unexpected) {
			t.Fatalf("inventory document should not contain obsolete/gapped heading %q", unexpected)
		}
	}
}

func TestVMDocumentIncludesWebOnlyWhenInventoryExists(t *testing.T) {
	data := GenerationData{
		VM: domain.VirtualMachine{ID: 2, Name: "web01"},
		Web: domain.WebVMView{
			Host:    &domain.WebHostSummary{VMID: 2, ServerCount: 1, SiteCount: 1},
			Servers: []domain.WebServer{{Engine: "nginx", Product: "Nginx", Version: "1.26", Status: "running"}},
			Sites:   []domain.WebSite{{ID: 1, VMID: 2, Engine: "nginx", Product: "Nginx", SiteType: "server", Name: "portal.example.ro", ServerNames: []string{"portal.example.ro"}, Bindings: []domain.WebBinding{{Address: "*", Port: 443, Protocol: "https", TLS: true}}, ProxyTargets: []string{"http://127.0.0.1:8080"}, Enabled: true, Present: true}},
		},
		GeneratedAt:    time.Date(2026, 9, 5, 8, 0, 0, 0, time.UTC),
		DocumentNumber: "FVM-WEB",
	}
	body := documentBodyXML(data)
	for _, expected := range []string{"9. Site-uri web și frontends", "portal.example.ro", "https://*:443", "http://127.0.0.1:8080", "10. Inventar agent"} {
		if !strings.Contains(body, expected) {
			t.Fatalf("expected web document value %q", expected)
		}
	}
}

func TestRenderPortsTableDeduplicatesSameListeningPort(t *testing.T) {
	value := []any{
		map[string]any{"address": "0.0.0.0", "port": json.Number("22"), "protocol": "tcp", "processes": []any{map[string]any{"pid": json.Number("4242"), "name": "sshd", "executable": "/usr/sbin/sshd"}}},
		map[string]any{"address": "::", "port": json.Number("22"), "protocol": "tcp", "processes": []any{map[string]any{"pid": json.Number("4242"), "name": "sshd", "executable": "/usr/sbin/sshd"}}},
		map[string]any{"address": "10.0.0.10", "port": json.Number("443"), "protocol": "tcp", "processes": []any{map[string]any{"pid": json.Number("5000"), "name": "nginx", "executable": "/opt/nginx/sbin/nginx"}}},
	}
	xml := renderPortsTable(value)
	if got := strings.Count(xml, ">22<"); got != 1 {
		t.Fatalf("expected port 22 once, got %d: %s", got, xml)
	}
	if !strings.Contains(xml, "sshd (PID 4242)") || !strings.Contains(xml, "/usr/sbin/sshd") {
		t.Fatal("deduplicated port lost process metadata")
	}
}

func TestHeadingTwoHasExplicitIndent(t *testing.T) {
	xml := heading("5.1 Conexiuni către sisteme externe", 2)
	if !strings.Contains(xml, `w:pStyle w:val="Heading2"`) || !strings.Contains(xml, `w:ind w:left="360"`) {
		t.Fatalf("Heading2 should keep style and explicit indent: %s", xml)
	}
}

func TestFirewallManagedBackendSuppressesGeneratedTechnicalRules(t *testing.T) {
	value := map[string]any{
		"detected": true,
		"active":   true,
		"backends": []any{"nftables", "ufw"},
		"default_policies": map[string]any{
			"ufw": "deny (incoming), allow (outgoing)",
		},
		"rules": []any{
			map[string]any{"backend": "nftables", "family": "inet", "table": "filter", "chain": "ufw-user-input", "action": "accept", "rule": "counter packets 123 bytes 456 jump ufw-user-input"},
			map[string]any{"backend": "ufw", "rule": "22/tcp ALLOW Anywhere"},
		},
	}
	xml := renderFirewallTable(value)
	if !strings.Contains(xml, "22/tcp ALLOW Anywhere") {
		t.Fatal("explicit UFW rule should be documented")
	}
	if strings.Contains(xml, "counter packets 123") || strings.Contains(xml, "ufw-user-input") {
		t.Fatal("generated nftables rule should be suppressed when UFW manages the firewall")
	}
	if !strings.Contains(xml, "Politici implicite") {
		t.Fatal("default firewall policies should remain summarized")
	}
}

func TestFirewallDirectNFTablesRulesRemainDocumented(t *testing.T) {
	value := map[string]any{
		"detected": true,
		"active":   true,
		"backends": []any{"nftables"},
		"rules": []any{
			map[string]any{"backend": "nftables", "family": "inet", "table": "filter", "chain": "input", "action": "accept", "rule": "tcp dport 8443 accept"},
		},
	}
	xml := renderFirewallTable(value)
	if !strings.Contains(xml, "tcp dport 8443 accept") {
		t.Fatal("direct nftables configuration should remain documented when no high-level firewall manager is present")
	}
}

func TestVMDocumentIncludesMonitoring(t *testing.T) {
	probeOK := true
	httpStatus := 200
	duration := 0.125
	now := time.Date(2026, 9, 9, 14, 0, 0, 0, time.UTC)
	data := GenerationData{
		VM:             domain.VirtualMachine{ID: 77, Name: "app01"},
		GeneratedAt:    now,
		DocumentNumber: "FVM-MON",
		Monitoring: domain.VMMonitoringSummary{
			VMID:              77,
			VMName:            "app01",
			ExporterInstalled: true,
			ExporterRunning:   true,
			ExporterVersion:   "1.9.1",
			ExporterEndpoint:  "0.0.0.0:9100",
			MetricsMonitored:  true,
			MetricsUp:         true,
			BlackboxMonitored: true,
			BlackboxUp:        true,
			MonitoringState:   "monitored",
			MetricsTargets:    []domain.MonitoringTarget{{PrometheusSourceName: "prom-main", SourceType: "metrics", JobName: "node", Instance: "app01:9100", Health: "up", MatchMethod: "fqdn", MatchValue: "app01.example.ro", LastScrapeAt: &now}},
			BlackboxTargets:   []domain.MonitoringTarget{{PrometheusSourceName: "prom-main", SourceType: "blackbox", TargetURL: "https://app.example.ro/health", Health: "up", ProbeSuccess: &probeOK, HTTPStatusCode: &httpStatus, ProbeDurationSeconds: &duration, MatchMethod: "alias", MatchValue: "app01"}},
		},
	}
	body := documentBodyXML(data)
	for _, expected := range []string{"8. Monitorizare", "Monitorizat · UP", "Node Exporter", "1.9.1", "prom-main", "app01:9100", "https://app.example.ro/health", "HTTP", "0.125s"} {
		if !strings.Contains(body, expected) {
			t.Fatalf("monitoring section missing %q", expected)
		}
	}
}

func TestServiceDocumentIncludesMonitoring(t *testing.T) {
	data := ServiceGenerationData{
		Service:        domain.InternalService{ID: 7, Name: "Portal"},
		GeneratedAt:    time.Date(2026, 9, 9, 15, 0, 0, 0, time.UTC),
		DocumentNumber: "FSI-MON",
		Backups:        []ServiceVMBackup{{VMID: 1, VMName: "portal01", Environment: "PROD"}},
		Monitorings: []ServiceVMMonitoring{{
			VMID: 1, VMName: "portal01", Environment: "PROD",
			Monitoring: domain.VMMonitoringSummary{VMID: 1, VMName: "portal01", ExporterInstalled: true, ExporterRunning: true, ExporterVersion: "1.9.1", MetricsMonitored: true, MetricsUp: true, MonitoringState: "monitored"},
		}},
	}
	template, err := DefaultServiceTemplate()
	if err != nil {
		t.Fatal(err)
	}
	output, err := RenderServiceDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	document := documentXMLFromDOCX(t, output)
	for _, expected := range []string{"Monitorizare", "portal01", "PROD", "Monitorizat · UP", "Node Exporter", "1.9.1", "Prometheus"} {
		if !strings.Contains(document, expected) {
			t.Fatalf("service monitoring section missing %q", expected)
		}
	}
}
