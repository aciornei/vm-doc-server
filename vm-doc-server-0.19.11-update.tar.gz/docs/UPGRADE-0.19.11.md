# Upgrade vm-doc-server 0.19.10 → 0.19.11

0.19.11 este un release de documentație și prezentare. Nu modifică schema bazei de date și nu necesită upgrade de agent sau collector.

## Noutăți

- fișa VM include un capitol `Monitorizare` după `Backup și restaurare`;
- sunt documentate Node Exporter, targeturile Prometheus metrics și probele Blackbox, fără secrete;
- fișa serviciului include o vedere agregată a monitorizării VM-urilor asociate;
- Firewall nu mai afișează regulile tehnice nftables/iptables/ip6tables generate de UFW/firewalld/SuSEfirewall2;
- politicile implicite rămân rezumate, zonele firewalld rămân disponibile, iar nftables/iptables directe sunt păstrate când nu există un manager high-level.

## Upgrade

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.10 vm-doc-server-0.19.11
tar -xzf /cale/vm-doc-server-0.19.11-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.11
cd /usr/local/src/vm-doc-server-0.19.11
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

Nu există migrare nouă. După upgrade folosiți `Ctrl+F5` pentru a reîncărca JavaScript-ul.

## Verificări

1. `/version` trebuie să raporteze `0.19.11`.
2. Generați preview/DOCX pentru o VM monitorizată și verificați capitolul `Monitorizare`.
3. Generați fișa unui serviciu cu mai multe VM-uri și verificați tabelul agregat `Monitorizare`.
4. Pe o VM cu UFW/firewalld peste nftables, fila Firewall și DOCX nu trebuie să mai enumere lanțurile tehnice generate de backend.
5. Pe o VM cu nftables/iptables configurat direct, regulile trebuie să rămână vizibile.
