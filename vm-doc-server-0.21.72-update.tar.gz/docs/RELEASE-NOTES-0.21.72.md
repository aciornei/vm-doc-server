# VM-DOC 0.21.72 — Jurnalul „Modificări” STRICT

**Schimbare de politică, nu doar filtru cosmetic.** Din versiunea aceasta, evenimentele neeligibile NU mai sunt introduse în `inventory_changes`. Inventarele complete din `inventory_snapshots` rămân intacte.

- Porturi: doar selecțiile VM „Principal” din `vm_primary_agent_ports`, indiferent de TCP/UDP și intervalul numeric; identitatea este `protocol/port` — procesele `master`, `smtpd`, `apache2` nu pot declanșa o schimbare de port. Evenimentele reale added/removed sunt confirmate la a doua observare.
- Servicii OS: doar numele selectate la VM → „Componente suport” (`vm_support_components`). Se urmăresc versiunea, versiunea pachetului și `enabled_state`, nu active/running, texte display și alte câmpuri runtime. **Serviciile nemarcate nu mai generează istoric, chiar dacă sunt instalate/actualizate.**
- Firewall: exclus total `firewall|rule|...` din istoric; păstrată numai schimbarea `default_policies` în categoria firewall. Reguli NAT și cele definite manual rămân în inventarul brut și în secțiunile de securitate. Atenție: o modificare de regulă fără schimbare de politică implicită NU mai apare în `Modificări`.
- DB: identitatea instanței este cea existentă (suportă instalări multiple ale aceluiași motor); comparăm doar engine, product, version, edition. Catalogele baze de date sunt identificate după nume/instanță; ignorăm status/sonde/PID/config runtime din diffs.
- Docker: numai container name și imaginea/tag (digest eliminat anterior); fără IP, MAC, network, ports, mounts sau stare runtime.
- Web: engine, site_type, nume, server_names, enabled; nu ținte proxy dinamice sau probe runtime. Cheile de identitate rămân cele existente (inclusiv binds/config file).
- Sistem, conturi, setări DNS, rețea de bază, partiții non-Docker, integrare, timp: doar câmpuri stabile, utile documentației.
- **Confirmare universală**: pentru orice eveniment, noua stare trebuie să se repete în două inventare consecutive. Debutul modificării este contabilizat la a doua colectare și `previous_inventory_id` indică primul snapshot înainte de schimbare. După două colectări cu date lipsă, o dispariție poate totuși fi raportată; nu înlocuiește monitorizarea operațională.

### Efect asupra istoricului vechi

Modificările înregistrate cu versiunile precedente rămân în DB. Poți folosi `scripts/preview-strict-history-cleanup-02172.sql` pentru numărătoare și `scripts/cleanup-strict-history-02172.sql` doar manual, după backup/staging. Acestea curăță numai: reguli firewall individuale, porturi nemarcate Principal și servicii nemarcate Componente suport, **fără revizii/decizii/observații**. Alte fluctuații istorice nu sunt șterse arbitrar; se poate crea un baseline pentru afișare (acesta nu elimină rândurile).

### Limitări și validare

- Opt-in prin selecții existente: marchează înainte de upgrade porturile și serviciile importante, altfel nu vei primi evenimente pentru ele.
- Politica STRICT este implicită pentru toate VM-urile, nu are încă un comutator UI. Întoarcerea la 0.21.71 restabilește vechea politică pentru evenimentele viitoare; rândurile deja create rămân.
- Fără migrare SQL, fără schimbări API/agent (agent 1.7.18). Serverul Go trebuie **recompilat** cu vendor/ pe mașina offline.
- `go test ./...`, testarea live MariaDB și integrarea cu colectorii reali trebuie confirmate în staging; în acest mediu pot fi testate doar pachetele independente.
