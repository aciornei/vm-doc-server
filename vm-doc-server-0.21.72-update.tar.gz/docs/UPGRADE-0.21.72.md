# Upgrade VM-DOC 0.21.71 → 0.21.72

1. **Atenție schimbare de politică:** înainte de instalare verifică selecția Porturi Principal și Componente suport pentru VM-urile unde trebuie urmărite modificări. Porturile și serviciile nemarcate nu generează istoric după upgrade. Reguli firewall individuale nu mai generează evenimente în Modificări; rămân în inventar.
2. Salvează binarul/configurația și backup MariaDB recuperabil. Testează mai întâi pe staging cu cel puțin o VM Postfix, o VM Docker și una cu DB.
3. Aplică **ori** patch 0.21.71→0.21.72, **ori** update.tar.gz peste sursele 0.21.71; nu ambele. Alternativ, folosește source.zip integral.
4. Compilează pe serverul offline cu vendor/: `GOPROXY=off GOSUMDB=off go test ./...` și `GOPROXY=off GOSUMDB=off go build -o vm-doc-server ./cmd/vm-doc-server`. Livrarea nu conține binar Go precompilat.
5. Oprește serviciul, înlocuiește binarul, pornește-l. Confirmă versiunea 0.21.72. JavaScript este embedded: necesită rebuild și Ctrl+F5 în browser.
6. Trimite 3–4 inventare consecutive: TCP/25 master ↔ master+smtpd trebuie să rămână același port; un port Principal care dispare două colectări consecutive trebuie raportat; porturile neprincipale nu apar. Un serviciu Componente suport cu versiune reală schimbată trebuie raportat după confirmare, unul nemarcat nu.
7. PREVIEW SQL: `scripts/preview-strict-history-cleanup-02172.sql`. Curățarea vechilor rânduri este **manuală**, opțională și ireversibilă fără backup: execută `cleanup-strict-history-02172.sql` numai cu serverul oprit, după testare pe o copie a MariaDB. Nu sunt atinse snapshoturile brute.
8. Rollback: restaurează binarul 0.21.71. Nu există migrare nouă; curățarea manuală a rândurilor vechi poate fi inversată numai prin restore DB.

NOTĂ: `inventory_changes` nu este și nu trebuie tratat ca alertă operațională pentru disponibilitate, trafic, reguli NAT sau apariția întregului software. Monitorizarea și securitatea folosesc datele brute/integrările existente.
