package inventorychanges

import (
	"encoding/json"
	"testing"
)

func extractStrictForTest(t *testing.T, raw string, ports map[portSelection]bool, services map[string]bool) map[string]trackedObject {
	t.Helper()
	objects, err := extractTracked([]byte(raw))
	if err != nil {
		t.Fatal(err)
	}
	return strictHistoryObjects(objects, ports, services)
}

func TestStrictPostfixWorkerFlappingDoesNotChangePort(t *testing.T) {
	single := `{"listening_ports":[{"protocol":"tcp","port":25,"processes":[{"name":"master","executable":"/usr/lib/postfix/sbin/master"}]}]}`
	workers := `{"listening_ports":[{"protocol":"tcp","port":25,"processes":[{"name":"master","executable":"/usr/lib/postfix/sbin/master"},{"name":"smtpd","executable":"/usr/lib/postfix/sbin/smtpd"}]}]}`
	selected := map[portSelection]bool{{"tcp", 25}: true}
	a := extractStrictForTest(t, single, selected, nil)
	b := extractStrictForTest(t, workers, selected, nil)
	const key = "ports|listening_port|tcp/25"
	if len(a) != 1 || len(b) != 1 {
		t.Fatalf("unexpected ports: a=%+v b=%+v", a, b)
	}
	if !canonicalEqual(a[key].Value, b[key].Value) {
		t.Fatalf("Postfix worker changed listener: %v vs %v", a[key], b[key])
	}
	if len(extractStrictForTest(t, single, nil, nil)) != 0 {
		t.Fatal("unselected port created a history object")
	}
	if !confirmedPortTransition(trackedObject{}, a[key], b[key], false, true, true) {
		t.Fatal("selected port true appearance must be confirmed")
	}
	if confirmedPortTransition(a[key], trackedObject{}, a[key], true, false, true) {
		t.Fatal("one-off port collector failure created a change")
	}
}

func TestStrictAllowlistAndSemanticFields(t *testing.T) {
	a := `{"services":[{"name":"postgresql.service","version":"15.4","enabled_state":"enabled","active_state":"running"},{"name":"systemd-journald.service","version":"255.4","enabled_state":"enabled"}],"databases":{"instances":[{"engine":"postgres","instance_name":"main","version":"15.4","status":"running","catalog_discovery_reason":"timeout"}]},"docker":{"containers":[{"name":"web","image":"nginx:1.25","networks":[{"mac_address":"a"}]}]},"firewall":{"active":true,"default_policies":[{"chain":"INPUT","policy":"DROP"}],"rules":[{"backend":"nftables","family":"ip","table":"filter","chain":"INPUT","rule":"tcp dport 443 accept"}]},"web":{"sites":[{"name":"example.test","engine":"nginx","enabled":true,"server_names":["example.test"],"proxy_targets":["10.1.2.3"]}]}}`
	b := `{"services":[{"name":"postgresql.service","version":"15.4","enabled_state":"enabled","active_state":"stopped"},{"name":"systemd-journald.service","version":"255.5","enabled_state":"enabled"}],"databases":{"instances":[{"engine":"postgres","instance_name":"main","version":"15.4","status":"stopped","catalog_discovery_reason":"ok"}]},"docker":{"containers":[{"name":"web","image":"nginx:1.25","networks":[{"mac_address":"b"}]}]},"firewall":{"active":false,"default_policies":[{"chain":"INPUT","policy":"DROP"}],"rules":[{"backend":"nftables","family":"ip","table":"filter","chain":"INPUT","rule":"tcp dport 8080 accept"}]},"web":{"sites":[{"name":"example.test","engine":"nginx","enabled":true,"server_names":["example.test"],"proxy_targets":["10.9.8.7"]}]}}`
	aa := extractStrictForTest(t, a, nil, map[string]bool{"postgresql.service": true})
	bb := extractStrictForTest(t, b, nil, map[string]bool{"postgresql.service": true})
	if len(aa) != 5 || len(bb) != 5 {
		t.Fatalf("unexpected number of strict objects: before %d, after %d (%v)", len(aa), len(bb), aa)
	}
	for key, old := range aa {
		nw, found := bb[key]
		if !found || !canonicalEqual(old.Value, nw.Value) {
			t.Errorf("noise changed strict object %s: %v, %v", key, old.Value, nw.Value)
		}
	}
	if _, ok := aa["services|service|systemd-journald.service"]; ok {
		t.Fatal("unselected systemd service tracked")
	}
	if _, ok := aa["firewall|rule|nftables|ip|filter|INPUT|tcp dport 443 accept"]; ok {
		t.Fatal("individual firewall rule tracked")
	}
	c := `{"services":[{"name":"postgresql.service","version":"15.5","enabled_state":"enabled"}],"databases":{"instances":[{"engine":"postgres","instance_name":"main","version":"15.5"}]},"docker":{"containers":[{"name":"web","image":"nginx:1.26"}]},"firewall":{"default_policies":[{"chain":"INPUT","policy":"ACCEPT"}]}}`
	cc := extractStrictForTest(t, c, nil, map[string]bool{"postgresql.service": true})
	for _, key := range []string{"services|service|postgresql.service", "databases|database_instance|postgres|main||", "docker|container|web", "firewall|firewall|firewall"} {
		old, ok := aa[key]
		if !ok {
			t.Errorf("original missing %s", key)
			continue
		}
		nw, ok := cc[key]
		if !ok || canonicalEqual(old.Value, nw.Value) {
			t.Errorf("real change not detected: %s", key)
		}
	}
}

func TestStrictConfirmationForAllCategories(t *testing.T) {
	old := trackedObject{Category: "docker", Value: map[string]any{"image": "web:1"}}
	newObj := trackedObject{Category: "docker", Value: map[string]any{"image": "web:2"}}
	if confirmedPortTransition(old, old, newObj, true, true, true) {
		t.Fatal("unconfirmed upgrade")
	}
	if !confirmedPortTransition(old, newObj, newObj, true, true, true) {
		t.Fatal("confirmed upgrade omitted")
	}
	if confirmedPortTransition(old, trackedObject{}, newObj, true, false, true) {
		t.Fatal("collector gap generated upgrade")
	}
	if !confirmedPortTransition(old, trackedObject{}, trackedObject{}, true, false, false) {
		t.Fatal("confirmed removal omitted")
	}
	if !confirmedPortTransition(trackedObject{}, newObj, newObj, false, true, true) {
		t.Fatal("confirmed addition omitted")
	}
	if confirmedPortTransition(newObj, old, newObj, true, true, true) {
		t.Fatal("flapping event emitted")
	}
}

func TestStrictPortIdentityIsJSONStable(t *testing.T) {
	obj := extractStrictForTest(t, `{"listening_ports":[{"protocol":"tcp","port":25,"processes":[{"name":"master"}]}]}`, map[portSelection]bool{{"tcp", 25}: true}, nil)
	encoded, err := json.Marshal(obj["ports|listening_port|tcp/25"].Value)
	if err != nil {
		t.Fatal(err)
	}
	if string(encoded) != "{\"port\":25,\"protocol\":\"tcp\"}" {
		t.Fatalf("unexpected port value %s", encoded)
	}
}

func TestStrictUnorderedDNSAndAddresses(t *testing.T) {
	a := `{"network":{"interfaces":[{"name":"eth0","addresses":[{"address":"192.168.1.3"},{"address":"192.168.1.4"}]}],"dns_servers":["1.1.1.1","8.8.8.8"]}}`
	b := `{"network":{"interfaces":[{"name":"eth0","addresses":[{"address":"192.168.1.4"},{"address":"192.168.1.3"}]}],"dns_servers":["8.8.8.8","1.1.1.1"]}}`
	aa := extractStrictForTest(t, a, nil, nil)
	bb := extractStrictForTest(t, b, nil, nil)
	for key, old := range aa {
		if !canonicalEqual(old.Value, bb[key].Value) {
			t.Fatalf("unordered collector list caused noise in %s", key)
		}
	}
}
