package inventorychanges

import (
	"context"
	"database/sql"
	"encoding/json"
	"sort"
	"strconv"
	"strings"
)

// STRICT history is an allowlist of documented, durable changes. The full
// collector inventory remains available in inventory_snapshots and VM views.
// A false negative is an explicit trade-off: unselected services and ports
// must not generate documentation work. No automatic data deletion occurs.
func strictHistoryObjects(objects map[string]trackedObject, selectedPorts map[portSelection]bool, selectedServices map[string]bool) map[string]trackedObject {
	out := make(map[string]trackedObject, len(objects))
	for _, obj := range objects {
		switch obj.Category {
		case "ports":
			if obj.Type != "listening_port" {
				continue
			}
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			protocol := strings.ToLower(strings.TrimSpace(first(value, "protocol")))
			port, err := strconv.Atoi(numberText(value["port"]))
			if err != nil || port < 1 || port > 65535 || !selectedPorts[portSelection{protocol, port}] {
				continue
			}
			// Process names and executables (Postfix master/smtpd, Apache
			// workers, etc.) are *not* listener identity or configuration.
			obj.Key = protocol + "/" + strconv.Itoa(port)
			obj.Label = "Port " + strings.ToUpper(protocol) + "/" + strconv.Itoa(port)
			obj.Value = map[string]any{"protocol": protocol, "port": port}
		case "services":
			if obj.Type != "service" || !selectedServices[strings.ToLower(strings.TrimSpace(obj.Key))] {
				continue
			}
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			obj.Value = pick(value, "version", "package_version", "enabled_state")
		case "firewall":
			// Individual firewall rules can number in the thousands and
			// Docker/NAT dynamically rewrites them. Follow effective default
			// policy only; all rules remain accessible in the raw inventory.
			if obj.Type != "firewall" {
				continue
			}
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			obj.Value = normalizeUnorderedStrictFields(pick(value, "default_policies"), "default_policies")
		case "databases":
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			switch obj.Type {
			case "database_instance":
				// A database instance is still identified by its collector
				// key (engine/name/path/endpoints), preserving multi-instance
				// hosts. Ignore live status, catalog probes and sockets.
				obj.Value = pick(value, "engine", "product", "version", "edition")
			case "database":
				obj.Value = pick(value, "engine", "instance", "name")
			default:
				continue
			}
		case "docker":
			if obj.Type != "container" {
				continue
			}
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			obj.Value = pick(value, "name", "image")
		case "web":
			if obj.Type != "web_site" {
				continue
			}
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			obj.Value = normalizeUnorderedStrictFields(pick(value, "engine", "site_type", "name", "server_names", "enabled"), "server_names")
		case "network":
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			if obj.Type == "interface" {
				obj.Value = normalizeUnorderedStrictFields(pick(value, "name", "addresses", "mtu"), "addresses")
			} else if obj.Type == "resolver" {
				obj.Value = normalizeUnorderedStrictFields(pick(value, "default_gateways", "dns_servers", "search_domains"), "default_gateways", "dns_servers", "search_domains")
			} else {
				continue
			}
		case "storage":
			if obj.Type != "partition" {
				continue
			}
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			filesystem := strings.ToLower(strings.TrimSpace(first(value, "filesystem")))
			mountPoint := first(value, "mount_point")
			if filesystem == "overlay" || filesystem == "aufs" || strings.HasPrefix(mountPoint, "/var/lib/docker/") {
				continue
			}
			obj.Value = pick(value, "device", "mount_point", "filesystem", "total_bytes", "read_only")
		case "integrations":
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			obj.Value = pick(value, "installed", "version", "package_version", "service_enabled")
		case "identity":
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			obj.Value = pick(value, "installed", "version", "config_present", "services", "domains")
		case "time":
			value, ok := obj.Value.(map[string]any)
			if !ok {
				continue
			}
			obj.Value = pick(value, "installed", "implementation", "version", "service_enabled", "servers")
		case "system", "accounts":
			// Host/OS and account/security changes stay documented.
		default:
			continue
		}
		out[obj.Category+"|"+obj.Type+"|"+obj.Key] = obj
	}
	return out
}

func loadTrackedSupportServiceSelections(ctx context.Context, tx *sql.Tx, vmID int64) (map[string]bool, error) {
	rows, err := tx.QueryContext(ctx, `SELECT service_name FROM vm_support_components WHERE vm_id=?`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	selected := make(map[string]bool)
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			return nil, err
		}
		name = strings.ToLower(strings.TrimSpace(name))
		if name != "" {
			selected[name] = true
		}
	}
	return selected, rows.Err()
}

// Collection order is not configuration. Sort unordered address, DNS, rule-
// policy and name lists by canonical JSON without changing raw snapshots.
func normalizeUnorderedStrictFields(value map[string]any, keys ...string) map[string]any {
	for _, key := range keys {
		values, ok := value[key].([]any)
		if !ok {
			continue
		}
		copyValues := append([]any(nil), values...)
		sort.SliceStable(copyValues, func(i, j int) bool {
			a, _ := json.Marshal(copyValues[i])
			b, _ := json.Marshal(copyValues[j])
			return string(a) < string(b)
		})
		value[key] = copyValues
	}
	return value
}
