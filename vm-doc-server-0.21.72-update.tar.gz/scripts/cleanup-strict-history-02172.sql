-- VM-DOC 0.21.72 STRICT: candidate SQL, NU rulează automat.
-- ATENȚIE: politica STRICT exclude din istoricul Modificări și reguli firewall
-- manuale / servicii nemarcate, nu doar zgomot Docker. Verifică eșantioane.
-- Tabele brute inventory_snapshots / VM, servicii, comp. suport NU sunt atinse.
-- Necesită MariaDB staging, backup recuperabil, server/writeri opriți pentru CLEANUP.
DROP TEMPORARY TABLE IF EXISTS tmp_vmdoc_strict_02172;
CREATE TEMPORARY TABLE tmp_vmdoc_strict_02172 (
  id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  reason VARCHAR(72) NOT NULL
) ENGINE=InnoDB;

-- Doar evenimente complet neprocesate, fără note, revizii sau decizii.
-- O categorie poate intra o singură dată prin INSERT IGNORE.
INSERT IGNORE INTO tmp_vmdoc_strict_02172(id,reason)
SELECT c.id,'individual_firewall_rule'
FROM inventory_changes c
WHERE c.category='firewall' AND c.object_type='rule'
  AND c.review_status='new' AND c.documentation_requirement='unset'
  AND c.reviewed_by IS NULL AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')='';

INSERT IGNORE INTO tmp_vmdoc_strict_02172(id,reason)
SELECT c.id,'unselected_os_service'
FROM inventory_changes c
WHERE c.category='services' AND c.object_type='service'
  AND c.object_key LIKE 'services|service|%'
  AND NOT EXISTS (
    SELECT 1 FROM vm_support_components sc
    WHERE sc.vm_id=c.vm_id
      AND LOWER(TRIM(sc.service_name))=LOWER(TRIM(SUBSTRING(c.object_key,CHAR_LENGTH('services|service|')+1)))
  )
  AND c.review_status='new' AND c.documentation_requirement='unset'
  AND c.reviewed_by IS NULL AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')='';

INSERT IGNORE INTO tmp_vmdoc_strict_02172(id,reason)
SELECT c.id,'unselected_listener'
FROM inventory_changes c
WHERE c.category='ports' AND c.object_type='listening_port'
  AND (JSON_VALID(c.old_json)=1 OR JSON_VALID(c.new_json)=1)
  AND NOT EXISTS (
    SELECT 1 FROM vm_primary_agent_ports p
    WHERE p.vm_id=c.vm_id
      AND LOWER(TRIM(p.protocol))=LOWER(JSON_UNQUOTE(JSON_EXTRACT(
        CASE WHEN JSON_VALID(c.new_json)=1 THEN c.new_json ELSE c.old_json END,'$.protocol')))
      AND p.port=CAST(JSON_UNQUOTE(JSON_EXTRACT(
        CASE WHEN JSON_VALID(c.new_json)=1 THEN c.new_json ELSE c.old_json END,'$.port')) AS UNSIGNED)
  )
  AND c.review_status='new' AND c.documentation_requirement='unset'
  AND c.reviewed_by IS NULL AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')='';

-- Portul este selectat, dar valoarea protocol/port e identică: modificarea
-- este doar lista de procese / executabile. Doar evenimente MODIFIED.
INSERT IGNORE INTO tmp_vmdoc_strict_02172(id,reason)
SELECT c.id,'listener_process_metadata_only'
FROM inventory_changes c
WHERE c.category='ports' AND c.object_type='listening_port'
  AND c.change_type='modified'
  AND JSON_VALID(c.old_json)=1 AND JSON_VALID(c.new_json)=1
  AND JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.protocol'))=JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.protocol'))
  AND JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.port'))=JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.port'))
  AND c.review_status='new' AND c.documentation_requirement='unset'
  AND c.reviewed_by IS NULL AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')='';

-- Runtime-only metadata: versiunea/imaginea reală rămân verificabile.
INSERT IGNORE INTO tmp_vmdoc_strict_02172(id,reason)
SELECT c.id,'docker_runtime_only'
FROM inventory_changes c
WHERE c.category='docker' AND c.object_type='container'
  AND c.change_type='modified'
  AND JSON_VALID(c.old_json)=1 AND JSON_VALID(c.new_json)=1
  AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.name')),'')=COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.name')),'')
  AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.image')),'')=COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.image')),'')
  AND c.review_status='new' AND c.documentation_requirement='unset'
  AND c.reviewed_by IS NULL AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')='';

-- DB: elimină doar MODIFIED când câmpurile versiune identitate sunt egale,
-- NU când engine/product/version/edition diferă.
INSERT IGNORE INTO tmp_vmdoc_strict_02172(id,reason)
SELECT c.id,'database_runtime_only'
FROM inventory_changes c
WHERE c.category='databases' AND c.object_type='database_instance'
  AND c.change_type='modified'
  AND JSON_VALID(c.old_json)=1 AND JSON_VALID(c.new_json)=1
  AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.engine')),'')=COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.engine')),'')
  AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.product')),'')=COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.product')),'')
  AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.version')),'')=COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.version')),'')
  AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.old_json,'$.edition')),'')=COALESCE(JSON_UNQUOTE(JSON_EXTRACT(c.new_json,'$.edition')),'')
  AND c.review_status='new' AND c.documentation_requirement='unset'
  AND c.reviewed_by IS NULL AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')='';

SELECT DATABASE() AS database_name;
SELECT reason,COUNT(*) AS candidate_rows FROM tmp_vmdoc_strict_02172 GROUP BY reason ORDER BY candidate_rows DESC;
SELECT c.category,c.change_type,COUNT(*) AS candidate_rows
FROM inventory_changes c JOIN tmp_vmdoc_strict_02172 t ON t.id=c.id
GROUP BY c.category,c.change_type ORDER BY candidate_rows DESC;
SELECT COUNT(*) AS total_candidates FROM tmp_vmdoc_strict_02172;
SELECT c.id,c.vm_id,c.occurred_at,c.category,c.change_type,c.object_key,c.object_label,t.reason
FROM inventory_changes c JOIN tmp_vmdoc_strict_02172 t ON t.id=c.id
ORDER BY c.occurred_at DESC,c.id DESC LIMIT 150;
-- Ultima siguranță: reevaluează protecțiile, în caz că rândurile s-au
-- modificat între SELECT și DELETE (de aceea serverul trebuie oprit).
START TRANSACTION;
DELETE c FROM inventory_changes c
JOIN tmp_vmdoc_strict_02172 t ON t.id=c.id
WHERE c.review_status='new' AND c.documentation_requirement='unset'
  AND c.reviewed_by IS NULL AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')='';
SELECT ROW_COUNT() AS physically_deleted_events;
COMMIT;
DROP TEMPORARY TABLE tmp_vmdoc_strict_02172;
