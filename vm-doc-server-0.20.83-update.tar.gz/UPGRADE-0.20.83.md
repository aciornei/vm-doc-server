# Upgrade VM-DOC Server 0.20.82 → 0.20.83

0.20.83 extinde regula **Outline numai pentru PROD** la publicarea individuală a VM-urilor. Nu există migrare DB și nu este necesar update de agent.

## Comportament nou

- în **VM → Documentație**, butonul **Trimite în Outline** apare numai pentru `Mediu = PROD`;
- TEST / DEV / mediu nespecificat afișează un mesaj informativ și nu au buton de publicare;
- bifa **Nu se publică în Outline** continuă să aibă prioritate și ascunde acțiunea;
- endpoint-ul individual verifică aceeași regulă server-side;
- Rezumatul și raportul de publicabilitate Outline marchează VM-urile non-PROD ca nepublicabile.

## Upgrade offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.82 vm-doc-server-0.20.83
tar -xzf /cale/vm-doc-server-0.20.83-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.83
cd /usr/local/src/vm-doc-server-0.20.83

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

Apoi înlocuiește binarul conform procedurii curente, repornește `vm-doc-server` și fă **Ctrl+F5** în browser.

## Verificare

1. VM PROD → Documentație: butonul **Trimite în Outline** trebuie să fie vizibil dacă bifa de excludere nu este activă.
2. VM TEST/DEV/fără mediu → Documentație: butonul nu trebuie să apară; trebuie afișat motivul.
3. VM PROD cu **Nu se publică în Outline**: butonul nu trebuie să apară.
4. În Rezumat, non-PROD trebuie să apară ca `Nu · numai PROD (...)`.
5. Un apel direct la `POST /api/v1/vms/{id}/outline` pentru non-PROD trebuie să fie refuzat.
