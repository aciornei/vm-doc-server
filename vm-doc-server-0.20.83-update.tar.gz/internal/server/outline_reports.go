package server

import (
	"context"
	"net/http"
	"strings"
	"time"

	"vm-doc-server/internal/xlsx"
)

type outlinePublishVMRow struct {
	ID          int64  `json:"id"`
	Name        string `json:"name"`
	Hostname    string `json:"hostname"`
	Environment string `json:"environment"`
	PowerState  string `json:"power_state"`
	Publish     bool   `json:"publish"`
	Reason      string `json:"reason"`
	ReasonCode  string `json:"reason_code"`
}

type outlinePublishServiceRow struct {
	ID                  int64  `json:"id"`
	Name                string `json:"name"`
	Active              bool   `json:"active"`
	Retired             bool   `json:"retired"`
	Criticality         string `json:"criticality"`
	DocumentationStatus string `json:"documentation_status"`
	DocumentationURL    string `json:"documentation_url"`
	Publish             bool   `json:"publish"`
	Reason              string `json:"reason"`
	ReasonCode          string `json:"reason_code"`
	State               string `json:"state"`
}

type outlinePublishReport struct {
	GeneratedAt        time.Time                  `json:"generated_at"`
	IntegrationEnabled bool                       `json:"integration_enabled"`
	VMChart            []reportPoint              `json:"vm_chart"`
	ServiceChart       []reportPoint              `json:"service_chart"`
	VMs                []outlinePublishVMRow      `json:"vms"`
	Services           []outlinePublishServiceRow `json:"services"`
}

type outlinePublishVMReport struct {
	GeneratedAt        time.Time             `json:"generated_at"`
	IntegrationEnabled bool                  `json:"integration_enabled"`
	Chart              []reportPoint         `json:"chart"`
	Rows               []outlinePublishVMRow `json:"rows"`
}

type outlinePublishServiceReport struct {
	GeneratedAt        time.Time                  `json:"generated_at"`
	IntegrationEnabled bool                       `json:"integration_enabled"`
	Chart              []reportPoint              `json:"chart"`
	Rows               []outlinePublishServiceRow `json:"rows"`
}

func (a *App) outlineIntegrationEnabled(ctx context.Context) bool {
	if a.Outline == nil {
		return false
	}
	settings, err := a.Outline.GetSettings(ctx)
	return err == nil && settings.Enabled
}

func (a *App) outlineVMRows(ctx context.Context, integrationEnabled bool) ([]outlinePublishVMRow, []reportPoint, error) {
	values := []outlinePublishVMRow{}
	vmOutlineExpr := "0"
	if a.tableColumnExists(ctx, "virtual_machines", "outline_documentation_disabled") {
		vmOutlineExpr = "vm.outline_documentation_disabled"
	}
	rows, err := a.DB.QueryContext(ctx, `SELECT vm.id,vm.name,COALESCE(NULLIF(i.hostname,''),NULLIF(vm.guest_hostname,''),''),COALESCE(m.environment,''),COALESCE(vm.power_state,''),`+vmOutlineExpr+` FROM virtual_machines vm LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id LEFT JOIN vm_operational_metadata m ON m.vm_id=vm.id WHERE vm.retired=0 ORDER BY LOWER(vm.name),vm.id`)
	if err != nil {
		return nil, nil, err
	}
	defer rows.Close()
	var yes, no int64
	for rows.Next() {
		var row outlinePublishVMRow
		var disabled bool
		if err := rows.Scan(&row.ID, &row.Name, &row.Hostname, &row.Environment, &row.PowerState, &disabled); err != nil {
			return nil, nil, err
		}
		row.Publish = integrationEnabled && !disabled && outlineBulkProductionEnvironment(row.Environment)
		if !integrationEnabled {
			row.Reason = "Integrarea Outline este dezactivată global"
			row.ReasonCode = "integration_disabled"
		} else if disabled {
			row.Reason = "Marcat «Nu se publică în Outline»"
			row.ReasonCode = "excluded"
		} else if !outlineBulkProductionEnvironment(row.Environment) {
			row.Reason = outlineBulkEnvironmentSkipReason(row.Environment)
			row.ReasonCode = "environment_not_prod"
		} else {
			row.Reason = "Configurat pentru publicare"
			row.ReasonCode = "enabled"
		}
		if row.Publish {
			yes++
		} else {
			no++
		}
		values = append(values, row)
	}
	if err := rows.Err(); err != nil {
		return nil, nil, err
	}
	return values, []reportPoint{{Label: "Se publică", Value: yes}, {Label: "Nu se publică", Value: no}}, nil
}

func (a *App) outlineServiceRows(ctx context.Context, integrationEnabled bool) ([]outlinePublishServiceRow, []reportPoint, error) {
	values := []outlinePublishServiceRow{}
	retiredExpr := "0"
	if a.tableColumnExists(ctx, "internal_services", "retired") {
		retiredExpr = "retired"
	}
	outlineExpr := "0"
	if a.tableColumnExists(ctx, "internal_services", "outline_documentation_disabled") {
		outlineExpr = "outline_documentation_disabled"
	}
	rows, err := a.DB.QueryContext(ctx, `SELECT id,name,active,`+retiredExpr+`,COALESCE(criticality,''),COALESCE(documentation_status,''),COALESCE(documentation_url,''),`+outlineExpr+` FROM internal_services ORDER BY LOWER(name),id`)
	if err != nil {
		return nil, nil, err
	}
	defer rows.Close()
	var yes, no int64
	for rows.Next() {
		var row outlinePublishServiceRow
		var disabled bool
		if err := rows.Scan(&row.ID, &row.Name, &row.Active, &row.Retired, &row.Criticality, &row.DocumentationStatus, &row.DocumentationURL, &disabled); err != nil {
			return nil, nil, err
		}
		switch {
		case row.Retired:
			row.State = "retired"
		case !row.Active:
			row.State = "inactive"
		default:
			row.State = "active"
		}
		switch {
		case !integrationEnabled:
			row.Reason = "Integrarea Outline este dezactivată global"
			row.ReasonCode = "integration_disabled"
		case row.Retired:
			row.Reason = "Serviciu retras"
			row.ReasonCode = "retired"
		case !row.Active:
			row.Reason = "Serviciu inactiv"
			row.ReasonCode = "inactive"
		case disabled:
			row.Reason = "Marcat «Nu se documentează în Outline»"
			row.ReasonCode = "excluded"
		case strings.TrimSpace(row.DocumentationURL) == "":
			row.Reason = "Fără Link documentație"
			row.ReasonCode = "missing_documentation_url"
		default:
			row.Publish = true
			row.Reason = "Configurat pentru publicare"
			row.ReasonCode = "enabled"
		}
		if row.Publish {
			yes++
		} else {
			no++
		}
		values = append(values, row)
	}
	if err := rows.Err(); err != nil {
		return nil, nil, err
	}
	return values, []reportPoint{{Label: "Se publică", Value: yes}, {Label: "Nu se publică", Value: no}}, nil
}

func (a *App) outlinePublishabilityReport(ctx context.Context) (outlinePublishReport, error) {
	generatedAt := time.Now().UTC()
	enabled := a.outlineIntegrationEnabled(ctx)
	vms, vmChart, err := a.outlineVMRows(ctx, enabled)
	if err != nil {
		return outlinePublishReport{}, err
	}
	services, serviceChart, err := a.outlineServiceRows(ctx, enabled)
	if err != nil {
		return outlinePublishReport{}, err
	}
	return outlinePublishReport{GeneratedAt: generatedAt, IntegrationEnabled: enabled, VMChart: vmChart, ServiceChart: serviceChart, VMs: vms, Services: services}, nil
}

func (a *App) reportsOutlinePublishability(w http.ResponseWriter, r *http.Request) {
	value, err := a.outlinePublishabilityReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, value)
}

func (a *App) reportsOutlineVMs(w http.ResponseWriter, r *http.Request) {
	generatedAt := time.Now().UTC()
	enabled := a.outlineIntegrationEnabled(r.Context())
	rows, chart, err := a.outlineVMRows(r.Context(), enabled)
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, outlinePublishVMReport{GeneratedAt: generatedAt, IntegrationEnabled: enabled, Chart: chart, Rows: rows})
}

func (a *App) reportsOutlineServices(w http.ResponseWriter, r *http.Request) {
	generatedAt := time.Now().UTC()
	enabled := a.outlineIntegrationEnabled(r.Context())
	rows, chart, err := a.outlineServiceRows(r.Context(), enabled)
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, outlinePublishServiceReport{GeneratedAt: generatedAt, IntegrationEnabled: enabled, Chart: chart, Rows: rows})
}

func outlinePublishQueryMatch(value string, publish bool) bool {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "yes", "true", "1", "published", "on":
		return publish
	case "no", "false", "0", "unpublished", "off":
		return !publish
	default:
		return true
	}
}

func outlinePowerMatches(filter, state string) bool {
	filter = strings.ToLower(strings.TrimSpace(filter))
	state = strings.ToLower(strings.TrimSpace(state))
	if filter == "" {
		return true
	}
	on := state == "poweredon" || state == "on" || state == "running" || state == "powered_on"
	off := state == "poweredoff" || state == "off" || state == "stopped" || state == "powered_off"
	switch filter {
	case "on":
		return on
	case "off":
		return off
	case "other":
		return !on && !off
	default:
		return true
	}
}

func outlineVMFilterMatches(r *http.Request, row outlinePublishVMRow) bool {
	q := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("q")))
	if q != "" && !strings.Contains(strings.ToLower(strings.Join([]string{row.Name, row.Hostname, row.Environment, row.PowerState, row.Reason}, " ")), q) {
		return false
	}
	if !outlinePublishQueryMatch(r.URL.Query().Get("publish"), row.Publish) {
		return false
	}
	if !outlinePowerMatches(r.URL.Query().Get("power"), row.PowerState) {
		return false
	}
	if environment := strings.TrimSpace(r.URL.Query().Get("environment")); environment != "" && !strings.EqualFold(environment, row.Environment) {
		return false
	}
	if reason := strings.TrimSpace(r.URL.Query().Get("reason")); reason != "" && !strings.EqualFold(reason, row.ReasonCode) {
		return false
	}
	return true
}

func outlineServiceFilterMatches(r *http.Request, row outlinePublishServiceRow) bool {
	q := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("q")))
	if q != "" && !strings.Contains(strings.ToLower(strings.Join([]string{row.Name, row.Criticality, row.DocumentationStatus, row.DocumentationURL, row.Reason}, " ")), q) {
		return false
	}
	if !outlinePublishQueryMatch(r.URL.Query().Get("publish"), row.Publish) {
		return false
	}
	if state := strings.TrimSpace(r.URL.Query().Get("state")); state != "" && !strings.EqualFold(state, row.State) {
		return false
	}
	if criticality := strings.TrimSpace(r.URL.Query().Get("criticality")); criticality != "" && !strings.EqualFold(criticality, row.Criticality) {
		return false
	}
	if documentationStatus := strings.TrimSpace(r.URL.Query().Get("documentation_status")); documentationStatus != "" && !strings.EqualFold(documentationStatus, row.DocumentationStatus) {
		return false
	}
	if reason := strings.TrimSpace(r.URL.Query().Get("reason")); reason != "" && !strings.EqualFold(reason, row.ReasonCode) {
		return false
	}
	return true
}

func (a *App) exportReportOutlineVMs(w http.ResponseWriter, r *http.Request) {
	enabled := a.outlineIntegrationEnabled(r.Context())
	values, _, err := a.outlineVMRows(r.Context(), enabled)
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := [][]xlsx.Cell{{xlsx.Text("VM"), xlsx.Text("Hostname"), xlsx.Text("Mediu"), xlsx.Text("Power state"), xlsx.Text("Se publică în Outline"), xlsx.Text("Motiv")}}
	for _, v := range values {
		if !outlineVMFilterMatches(r, v) {
			continue
		}
		rows = append(rows, []xlsx.Cell{xlsx.Text(v.Name), xlsx.Text(v.Hostname), xlsx.Text(v.Environment), xlsx.Text(v.PowerState), xlsx.Text(yesNo(v.Publish)), xlsx.Text(v.Reason)})
	}
	if err := writeXLSXResponse(w, "Publicare Outline VM", "publicare-outline-vm", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write Outline VM publishability XLSX", "error", err)
	}
}

func (a *App) exportReportOutlineServices(w http.ResponseWriter, r *http.Request) {
	enabled := a.outlineIntegrationEnabled(r.Context())
	values, _, err := a.outlineServiceRows(r.Context(), enabled)
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := [][]xlsx.Cell{{xlsx.Text("Serviciu"), xlsx.Text("Stare"), xlsx.Text("Criticitate"), xlsx.Text("Status documentație"), xlsx.Text("Link documentație"), xlsx.Text("Se publică în Outline"), xlsx.Text("Motiv")}}
	for _, s := range values {
		if !outlineServiceFilterMatches(r, s) {
			continue
		}
		rows = append(rows, []xlsx.Cell{xlsx.Text(s.Name), xlsx.Text(s.State), xlsx.Text(s.Criticality), xlsx.Text(s.DocumentationStatus), xlsx.Text(s.DocumentationURL), xlsx.Text(yesNo(s.Publish)), xlsx.Text(s.Reason)})
	}
	if err := writeXLSXResponse(w, "Publicare Outline servicii", "publicare-outline-servicii", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write Outline service publishability XLSX", "error", err)
	}
}

// Endpointul vechi rămâne pentru compatibilitate cu bookmark-uri/API-uri existente.
func (a *App) exportReportOutlinePublishability(w http.ResponseWriter, r *http.Request) {
	value, err := a.outlinePublishabilityReport(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := [][]xlsx.Cell{{xlsx.Text("Tip"), xlsx.Text("Nume"), xlsx.Text("Hostname / Link"), xlsx.Text("Mediu / Stare"), xlsx.Text("Se publică în Outline"), xlsx.Text("Motiv")}}
	for _, v := range value.VMs {
		rows = append(rows, []xlsx.Cell{xlsx.Text("VM"), xlsx.Text(v.Name), xlsx.Text(v.Hostname), xlsx.Text(v.Environment), xlsx.Text(yesNo(v.Publish)), xlsx.Text(v.Reason)})
	}
	for _, s := range value.Services {
		rows = append(rows, []xlsx.Cell{xlsx.Text("Serviciu"), xlsx.Text(s.Name), xlsx.Text(s.DocumentationURL), xlsx.Text(s.State), xlsx.Text(yesNo(s.Publish)), xlsx.Text(s.Reason)})
	}
	if err := writeXLSXResponse(w, "Publicare Outline", "publicare-outline", rows); err != nil && a.Logger != nil {
		a.Logger.Error("write Outline publishability XLSX", "error", err)
	}
}
