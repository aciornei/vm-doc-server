# Upgrade VM-DOC Server 0.21.77 → 0.21.78

1. Salvați configurația și baza de date; asigurați backup și opțiune rollback.
2. Opriți serverul. Aplicați `vm-doc-server-0.21.78-update.tar.gz` în rădăcina **surselor 0.21.77** sau aplicați patch-ul; alternativ folosiți arhiva completă.
3. Compilați cu `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build` în mediul dvs. cu `vendor/`. Confirmare obligatorie a rezultatului build.
4. Înlocuiți binarul de la `systemctl cat vm-doc-server` → `ExecStart` și reporniți serviciul.
5. În browser confirmați `app.js?v=0.21.78`. În Modificări căutați numele unei VM și verificați că lista se restrânge; testați Filtre avansate, Detalii și Export Excel.
6. La rollback, reveniți la binarul 0.21.77 și resursele embed aferente; nu există migrare SQL de reversat.

**Notă:** Exportul XLSX folosește filtrarea server-side exact ca lista. Include cel mult 20.000 de evenimente; restrângeți filtrul la depășire. Nu conține JSON complet ori linkuri Vault.
