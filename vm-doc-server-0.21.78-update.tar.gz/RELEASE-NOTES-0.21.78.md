# VM-DOC Server 0.21.78 — Modificări UI, căutare și export

## Remediere cauză reală
În 0.21.77 callback-ul `flag=>flag?changesPage():loadGlobalChanges` **nu invoca** `loadGlobalChanges` când utilizatorul tasta în căutare. În 0.21.78 este `flag=>flag?changesPage():loadGlobalChanges()`; test Chromium reproduce regresia și confirmă noul comportament.

## UX
- Detector semantic și Baseline: `<details>` colapsate implicit.
- Căutarea: singur rând, domeniu implicit `VM` pentru filtre eficiente pe VM.name/hostname, opțiuni Toate/VM/Serviciu/Obiect; feedback, Enter, buton Caută.
- Filtre avansate: Categorie, Tip, Documentație, Stare colapsate implicit, cu contor filtre active; păstrează starea deschis la reîncărcare.
- Detalii: rând pe toată lățimea + 3 coloane metadate tip Firewall + diferențe anterior/nou și JSON brut colapsat.
- Export: `GET /api/v1/changes/export` cu parametri identici listei (fără page/page_size), format XLSX, maximum 20.000 de rezultate, autorizare inventories.read. Conține rezumatul schimbării, fără JSON brut și fără linkuri Vault, care trebuie să rămână interne.

## Instalare
De la 0.21.77: upgrade surse TAR sau patch apoi rebuild cu `vendor/`, restart serviciu, verificare `app.js?v=0.21.78`.

## Limitări
Testele JS, Go independente, OpenAPI, browser mock Chromium, arhive și patch sunt verificate. Compilarea integrală, interogările MariaDB și exportul live nu pot fi validate în mediul offline actual.
Nu se schimbă agentul 1.7.18, schema DB, baseline-urile, snapshoturile sau semantica detectorului.
