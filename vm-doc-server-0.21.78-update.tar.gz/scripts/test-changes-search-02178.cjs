// Regression guard: the 0.21.77 callback returned a function reference instead of calling it.
const fs=require('node:fs'),assert=require('node:assert/strict');
const js=fs.readFileSync('web/static/js/app.js','utf8');
const server=fs.readFileSync('internal/server/changes.go','utf8');
const routes=fs.readFileSync('internal/server/server.go','utf8');
assert(js.includes('flag=>flag?changesPage():loadGlobalChanges(),f'), 'global search callback must INVOKE loadGlobalChanges()');
assert(!js.includes('flag=>flag?changesPage():loadGlobalChanges,f'), 'regression: missing invocation');
assert(js.includes("changes:{q:'',scope:'vm'"),'VM search must default to VM scope');
assert(js.includes('class="changes-search-line"')&&js.includes('changes-advanced-filter'),'collapsed advanced filter layout');
assert(js.includes('changes-explain')&&js.includes('change-policy-detail-grid'),'collapsible help and Firewall-style details');
assert(js.includes('id="changeExport"'),'filtered Excel button is present');
assert(server.includes('func (a *App) exportInventoryChanges(')&&server.includes('f.PageSize = 200'), 'XLSX export must walk all pages');
assert(server.includes('maxExportRows = 20000'),'XLSX export must limit size');
assert(routes.includes('GET /api/v1/changes/export'),'XLSX export route must be registered');
console.log('PASS Changes search invocation regression, layout, filtered Excel export route');
