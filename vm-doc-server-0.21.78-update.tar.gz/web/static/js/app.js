const state={user:null,csrf:'',timezone:'Europe/Bucharest',agents:[],agentVMOperationalStatuses:[],sources:[],veeamSources:[],prometheusSources:[],vms:[],documentTemplates:[],agentFilters:{q:'',status:'',channel:'',type:'',power:'POWERED_ON',environment:'PROD',vmStatus:'',page:1,pageSize:10},agentReleaseFilters:{q:'',channel:'',os:'',arch:'',validity:'',page:1,pageSize:10},serviceFilters:{q:'',domain:'',category:'',criticality:'',docStatus:'',common:'',page:1,pageSize:10},vmFilters:{q:'',power:'POWERED_ON',environment:'PROD',agent:'',presence:'',baseline:'',serviceId:'',sourceId:'',outline:'',osSupport:'',published:'',sort:'',page:1,pageSize:10},vmAdvancedFiltersOpen:false,vcenterRunPaging:{page:1,pageSize:10},veeamRunPaging:{page:1,pageSize:10},veeamVMFilters:{q:'',status:'',power:'POWERED_ON',environment:'PROD',result:'',page:1,pageSize:10},monitoringVMFilters:{q:'',state:'',power:'POWERED_ON',environment:'PROD',page:1,pageSize:10},monitoringTargetFilters:{q:'',sourceType:'',health:'',matched:'',page:1,pageSize:10},monitoringRunPaging:{page:1,pageSize:10},vmHistory:{vmId:0,page:1,pageSize:10},changes:{q:'',scope:'vm',category:'',changeType:'',doc:'',review:'',page:1,pageSize:10},vmChanges:{vmId:0,q:'',scope:'all',category:'',changeType:'',doc:'',review:'',page:1,pageSize:10},audit:{page:1,pageSize:10,q:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:null},vmAudit:{vmId:0,page:1,pageSize:10,q:'',area:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:null},serviceAudit:{serviceId:0,page:1,pageSize:10,q:'',area:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:null},equipmentFilters:{q:'',type:'',status:'active'},externalFilters:{q:'',network:'',status:'active'},externalNetworkEdit:0,nomenclaturePaging:{},nomenclatureFilters:{},securityData:null,securityDataSection:'',securityFilters:{accounts:{q:'',type:'relevant',login:'',password:'',privileged:'',review:'',page:1,pageSize:25},databases:{q:'',engine:'',indicator:'',review:'',page:1,pageSize:20},web:{q:'',engine:'',coverage:'',action:'',warning:'',review:'',page:1,pageSize:20}},fortigateSources:[],fortigateSourceEdit:0,fortigateFilters:{q:'',sourceId:'',direction:'',risk:'',action:'',status:'',service:'',iface:'',vdom:'',review:'',page:1,pageSize:50},fortigateAnalysisFilters:{q:'',sourceId:'',vdom:'',classification:'review',flag:'',page:1,pageSize:50},reportsData:null,securityReviewReport:{q:'',vmId:'',agentVersion:'',category:'',status:'',period:'',reviewer:'',justified:'',risk:'',lastFrom:'',lastTo:'',nextFrom:'',nextTo:'',daysMin:'',daysMax:'',page:1,pageSize:50}};
let routeGeneration=0;
let vmDetailGeneration=0;
// Capture source and stack for any future VM resource context runtime errors.
// The missing vmResourceContexts registry was fixed in VM-DOC 0.21.67.
window.addEventListener('error',event=>{
  if(!/(?:vmcontext|vmresourcecontexts)/i.test(String(event.message||'')))return;
  const source=String(event.filename||'unknown');
  const locationText=`${source}:${Number(event.lineno||0)}:${Number(event.colno||0)}`;
  console.error('[VM-DOC 0.21.71] Resource context error; source:',locationText,'stack:',event.error?.stack||'unavailable');
  const target=document.getElementById('content');
  if(target&&/^#vms\/\d+\/(docker|databases|web)/.test(location.hash||'')){
    const note=document.createElement('div');note.className='notice warning';
    note.textContent=`Eroare JavaScript (VM-DOC 0.21.71): ${event.message}. Sursă: ${locationText}. Trimite această linie pentru diagnostic.`;
    target.prepend(note);
  }
});
const content=document.getElementById('content');
const title=document.getElementById('pageTitle');
const subtitle=document.getElementById('pageSubtitle');
const agentDialog=document.getElementById('agentDialog');
const agentForm=document.getElementById('agentForm');
const vcenterDialog=document.getElementById('vcenterDialog');
const vcenterForm=document.getElementById('vcenterForm');
const veeamDialog=document.getElementById('veeamDialog');
const veeamForm=document.getElementById('veeamForm');
const prometheusDialog=document.getElementById('prometheusDialog');
const prometheusForm=document.getElementById('prometheusForm');
const nomenclatureDialog=document.getElementById('nomenclatureDialog');
const nomenclatureForm=document.getElementById('nomenclatureForm');
const personDialog=document.getElementById('personDialog');
const personForm=document.getElementById('personForm');
const directoryDialog=document.getElementById('directoryDialog');
const directoryForm=document.getElementById('directoryForm');
const internalServiceDialog=document.getElementById('internalServiceDialog');
const internalServiceForm=document.getElementById('internalServiceForm');
const documentTemplateDialog=document.getElementById('documentTemplateDialog');
const documentTemplateForm=document.getElementById('documentTemplateForm');
const documentPreviewDialog=document.getElementById('documentPreviewDialog');

const rolePermissions={
  admin:new Set(['*']),
  operator:new Set(['dashboard.read','reports.read','agents.read','agents.manage','collections.read','collections.run','inventories.read','inventories.raw.read','vcenter.read','vcenter.manage','veeam.read','veeam.manage','monitoring.read','monitoring.manage','vms.manage','nomenclatures.read','services.read','services.manage','documents.read','documents.manage','equipment.read','equipment.manage','external.read','external.manage','fortigate.read','fortigate.manage']),
  viewer:new Set(['dashboard.read','reports.read','agents.read','collections.read','inventories.read','vcenter.read','veeam.read','monitoring.read','nomenclatures.read','services.read','documents.read','equipment.read','external.read','fortigate.read']),
  auditor:new Set(['dashboard.read','reports.read','agents.read','collections.read','inventories.read','inventories.raw.read','audit.read','vcenter.read','veeam.read','monitoring.read','nomenclatures.read','services.read','documents.read','equipment.read','external.read','fortigate.read'])
};
function can(permission){return (state.user?.roles||[]).some(role=>rolePermissions[role]?.has('*')||rolePermissions[role]?.has(permission))}

// Shared registry used by the VM Docker, Databases and Web resource editors.
// It must exist before registerResourceEditor() runs on a VM detail route.
const vmResourceContexts=new Map();
const vmReadCache=new Map();
function cachedVMRead(path,ttl=25000){
 const now=Date.now();
 // Prune expired large VM responses on EVERY lookup, not only after 64 entries.
 for(const [key,value] of vmReadCache){if(value.expires<=now)vmReadCache.delete(key)}
 const found=vmReadCache.get(path);
 if(found)return found.promise;
 const promise=api(path).catch(error=>{if(vmReadCache.get(path)?.promise===promise)vmReadCache.delete(path);throw error});
 // Small bound: a VM snapshot may contain sizable normalized inventories.
 while(vmReadCache.size>=16)vmReadCache.delete(vmReadCache.keys().next().value);
 vmReadCache.set(path,{expires:now+ttl,promise});return promise;
}
async function api(path,options={}){
  if(!['GET','HEAD'].includes((options.method||'GET').toUpperCase())){vmReadCache.clear();if(path.startsWith('/api/v1/nomenclatures'))environmentCataloguePromise=null;}
  const headers={Accept:'application/json',...(options.headers||{})};
  if(options.body&&!(options.body instanceof FormData)&&!headers['Content-Type'])headers['Content-Type']='application/json';
  if(!['GET','HEAD'].includes((options.method||'GET').toUpperCase())&&state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{...options,headers});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  const type=response.headers.get('content-type')||'';
  const body=response.status===204?null:type.includes('json')?await response.json():await response.text();
  if(!response.ok)throw new Error(body?.message||body?.error||`HTTP ${response.status}`);
  return body;
}
async function postDownload(path,body,fallbackName='document'){
  const headers={Accept:'*/*','Content-Type':'application/json'};if(state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{method:'POST',headers,body:JSON.stringify(body||{})});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  if(!response.ok){const type=response.headers.get('content-type')||'';const value=type.includes('json')?await response.json():await response.text();throw new Error(value?.message||value?.error||value||`HTTP ${response.status}`)}
  const blob=await response.blob(),disposition=response.headers.get('content-disposition')||'';
  const match=disposition.match(/filename="?([^";]+)"?/i),name=(match?.[1]||fallbackName).trim();
  const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
const e=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
// Datele din UI: data și ora sunt afișate pe două rânduri, în fusul configurat.
const dt=v=>{
  if(!v)return '—';
  const d=new Date(v);if(Number.isNaN(d.getTime()))return '—';
  const zone=state.timezone||'Europe/Bucharest';
  const date=d.toLocaleDateString('ro-RO',{timeZone:zone,day:'2-digit',month:'2-digit',year:'numeric'});
  const time=d.toLocaleTimeString('ro-RO',{timeZone:zone,hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
  return `<span class="ui-datetime" title="${e(date+' '+time)}"><span class="ui-datetime-date">${e(date)}</span><span class="ui-datetime-time">${e(time)}</span></span>`;
};
const badge=v=>{const text=String(v??'unknown');return `<span class="badge ${e(text.toLowerCase().replaceAll('_','-'))}">${e(text)}</span>`};
const boolText=v=>v?'Da':'Nu';
const memory=v=>v?`${(Number(v)/1024).toFixed(Number(v)>=10240?0:1)} GB`:'—';
function shortOS(v){
  const raw=String(v?.inventory_os_name||v?.guest_os||'').trim(),versionRaw=String(v?.inventory_os_version||'').trim();
  if(!raw&&!versionRaw)return '—';
  const rules=[[/windows server/i,'Windows Server'],[/windows/i,'Windows'],[/ubuntu/i,'Ubuntu'],[/debian/i,'Debian'],[/red hat enterprise|\brhel\b/i,'RHEL'],[/rocky/i,'Rocky'],[/alma/i,'AlmaLinux'],[/centos/i,'CentOS'],[/suse linux enterprise|\bsles\b/i,'SLES'],[/opensuse/i,'openSUSE']];
  let name=raw.replace(/\s*\(64-bit\)\s*/ig,' ').replace(/\s+/g,' ').trim();for(const [re,label] of rules){if(re.test(name)){name=label;break}}
  const version=(versionRaw||raw).match(/\b\d{1,4}(?:\.\d+){0,3}\b/)?.[0]||'';
  return `${name||'OS'}${version&&!name.includes(version)?` ${version}`:''}`.trim();
}
function powerShortBadge(value){const raw=String(value||'').toUpperCase(),on=raw==='POWERED_ON';return `<span class="badge ${on?'powered-on':'powered-off'}" title="${e(raw||'unknown')}">${on?'ON':'OFF'}</span>`}
function vmServiceNamesHTML(values){
  const names=Array.isArray(values)?values.filter(Boolean):[];
  if(!names.length)return '<span class="muted">—</span>';
  const rest=Math.max(0,names.length-4);
  return `<div class="vm-service-tags">${names.map((name,index)=>`<span ${index>=4?'hidden':''}>${e(name)}</span>`).join('')}${rest?`<button type="button" class="vm-services-toggle" aria-expanded="false" data-hidden-count="${rest}" title="Arată toate serviciile">+${rest} · Extinde</button>`:''}</div>`;
}
function bindVMServiceExpand(area){
  area.querySelectorAll('.vm-services-toggle').forEach(button=>button.addEventListener('click',()=>{
    const expanded=button.getAttribute('aria-expanded')!=='true',tags=button.parentElement;
    tags.querySelectorAll('span').forEach((tag,index)=>{if(index>=4)tag.hidden=!expanded});
    button.setAttribute('aria-expanded',String(expanded));
    button.textContent=expanded?'Restrânge':`+${button.dataset.hiddenCount} · Extinde`;
    button.title=expanded?'Arată primele patru servicii':'Arată toate serviciile';
  }));
}
function toast(message,error=false){const box=document.getElementById('toast');box.textContent=message;box.className=`toast show${error?' error':''}`;setTimeout(()=>box.className='toast',3200)}
function pageMeta(name,sub){title.textContent=name;subtitle.textContent=sub||''}
function panel(head,body,tools='',extraClass=''){return `<section class="panel${extraClass?` ${extraClass}`:''}"><div class="panel-header"><h2>${head}</h2><div class="toolbar">${tools}</div></div>${body}</section>`}
function empty(text){return `<div class="empty">${e(text)}</div>`}
function detail(label,value,mono=false){return `<div class="detail-item"><span>${e(label)}</span><div class="${mono?'mono':''}">${value??'—'}</div></div>`}
function jsonSections(raw){const entries=raw&&typeof raw==='object'&&!Array.isArray(raw)?Object.entries(raw):[['inventory',raw]];return `<div class="json-sections">${entries.map(([name,value])=>`<details><summary>${e(name)}</summary><pre class="json">${e(JSON.stringify(value,null,2))}</pre></details>`).join('')}</div>`}


function richTextFromPlain(value){
  const text=String(value??'').replace(/\r\n?/g,'\n');if(!text)return {version:1,blocks:[]};
  return {version:1,blocks:text.split('\n').map(line=>{let type='paragraph',content=line;if(/^\s*[-*•]\s+/.test(line)){type='bullet';content=line.replace(/^\s*[-*•]\s+/,'')}else if(/^\s*\d+[.)]\s+/.test(line)){type='number';content=line.replace(/^\s*\d+[.)]\s+/,'')}return {type,level:0,runs:content?[{text:content}]:[]}})};
}
function normalizeRichTextDocument(value,fallback=''){
  const source=value&&typeof value==='object'&&Array.isArray(value.blocks)?value:richTextFromPlain(fallback);
  return {version:1,blocks:source.blocks.slice(0,250).map(block=>({type:['bullet','number'].includes(block?.type)?block.type:'paragraph',level:Math.max(0,Math.min(4,Number(block?.level||0))),runs:Array.isArray(block?.runs)?block.runs.map(run=>({text:String(run?.text??''),bold:!!run?.bold,italic:!!run?.italic,underline:!!run?.underline})).filter(run=>run.text!==''):[]}))};
}
function richTextPlain(value,fallback=''){
  const doc=normalizeRichTextDocument(value,fallback);const counters=[0,0,0,0,0];let prevType='',prevLevel=0;
  return doc.blocks.map(block=>{let prefix='';const level=Math.max(0,Math.min(4,Number(block.level||0)));if(block.type==='bullet')prefix=`${'  '.repeat(level)}• `;else if(block.type==='number'){if(prevType!=='number'||level>prevLevel)counters[level]=0;for(let i=level+1;i<counters.length;i++)counters[i]=0;counters[level]++;prefix=`${'  '.repeat(level)}${counters[level]}. `}prevType=block.type;prevLevel=level;return prefix+block.runs.map(run=>run.text).join('')}).join('\n').trim();
}
function richTextRunHTML(run){
  let html=e(run.text).replace(/\n/g,'<br>');if(run.underline)html=`<u>${html}</u>`;if(run.italic)html=`<em>${html}</em>`;if(run.bold)html=`<strong>${html}</strong>`;return html;
}
function richTextView(value,fallback=''){
  const doc=normalizeRichTextDocument(value,fallback);if(!doc.blocks.length)return '<div class="rich-text-readonly empty-rich">—</div>';
  const counters=[0,0,0,0,0];let prevType='',prevLevel=0;
  const blocks=doc.blocks.map(block=>{const level=Math.max(0,Math.min(4,Number(block.level||0)));let marker='';if(block.type==='bullet')marker='•';else if(block.type==='number'){if(prevType!=='number'||level>prevLevel)counters[level]=0;for(let i=level+1;i<counters.length;i++)counters[i]=0;counters[level]++;marker=`${counters[level]}.`}prevType=block.type;prevLevel=level;const body=block.runs.map(richTextRunHTML).join('')||'<br>';return `<div class="rich-text-block ${e(block.type)} level-${level}">${marker?`<span class="rich-text-marker">${e(marker)}</span>`:''}<div>${body}</div></div>`}).join('');
  return `<div class="rich-text-readonly">${blocks}</div>`;
}
function appendRichRuns(parent,runs){
  for(const run of runs||[]){let node=document.createTextNode(String(run.text??''));if(run.underline){const tag=document.createElement('u');tag.append(node);node=tag}if(run.italic){const tag=document.createElement('em');tag.append(node);node=tag}if(run.bold){const tag=document.createElement('strong');tag.append(node);node=tag}parent.append(node)}
}
function setRichTextEditor(id,value,fallback=''){
  const editor=document.getElementById(id);if(!editor)return;const doc=normalizeRichTextDocument(value,fallback);editor.replaceChildren();
  let index=0;while(index<doc.blocks.length){const block=doc.blocks[index];if(block.type==='paragraph'){const p=document.createElement('p');appendRichRuns(p,block.runs);if(!block.runs.length)p.append(document.createElement('br'));editor.append(p);index++;continue}
    const type=block.type,level=block.level;const list=document.createElement(type==='number'?'ol':'ul');list.dataset.rtLevel=String(level);list.classList.add(`rt-level-${level}`);while(index<doc.blocks.length&&doc.blocks[index].type===type&&Number(doc.blocks[index].level||0)===level){const li=document.createElement('li');appendRichRuns(li,doc.blocks[index].runs);if(!doc.blocks[index].runs.length)li.append(document.createElement('br'));list.append(li);index++}editor.append(list)}
}
function richRunStyle(node,parentStyle){
  const style={...parentStyle};if(node.nodeType!==Node.ELEMENT_NODE)return style;const tag=node.tagName.toLowerCase();if(tag==='b'||tag==='strong')style.bold=true;if(tag==='i'||tag==='em')style.italic=true;if(tag==='u')style.underline=true;const css=node.style||{};if(css.fontWeight&&(['bold','600','700','800','900'].includes(css.fontWeight)||Number(css.fontWeight)>=600))style.bold=true;if(css.fontStyle==='italic')style.italic=true;if(String(css.textDecoration||css.textDecorationLine||'').includes('underline'))style.underline=true;return style;
}
function collectRichRuns(node,style={}){
  const runs=[];const push=(text,current)=>{if(text==='')return;const next={text,bold:!!current.bold,italic:!!current.italic,underline:!!current.underline};const last=runs[runs.length-1];if(last&&last.bold===next.bold&&last.italic===next.italic&&last.underline===next.underline)last.text+=next.text;else runs.push(next)};
  const walk=(current,currentStyle)=>{if(current.nodeType===Node.TEXT_NODE){push(current.nodeValue||'',currentStyle);return}if(current.nodeType!==Node.ELEMENT_NODE)return;const tag=current.tagName.toLowerCase();if(tag==='ul'||tag==='ol')return;if(tag==='br'){push('\n',currentStyle);return}const childStyle=richRunStyle(current,currentStyle);for(const child of current.childNodes)walk(child,childStyle)};
  for(const child of node.childNodes)walk(child,style);return runs.map(run=>({...run,text:run.text.replace(/\u00a0/g,' ')})).filter(run=>run.text!=='');
}
function richTextDocumentFromEditor(id){
  const editor=document.getElementById(id);if(!editor)return {version:1,blocks:[]};const blocks=[];
  const addBlock=(type,node,level=0)=>{const runs=collectRichRuns(node);blocks.push({type,level:Math.max(0,Math.min(4,Number(level||0))),runs})};
  const process=node=>{if(node.nodeType===Node.TEXT_NODE){if((node.nodeValue||'').trim()){const holder=document.createElement('span');holder.textContent=node.nodeValue;addBlock('paragraph',holder,0)}return}if(node.nodeType!==Node.ELEMENT_NODE)return;const tag=node.tagName.toLowerCase();if(tag==='ul'||tag==='ol'){const type=tag==='ol'?'number':'bullet';const explicitRaw=node.dataset.rtLevel;let level=explicitRaw!==undefined&&explicitRaw!==''?Number(explicitRaw):NaN;if(!Number.isFinite(level)){level=0;let nesting=0,parent=node.parentElement;while(parent&&parent!==editor){if(parent.matches?.('ul,ol')){nesting++;const baseRaw=parent.dataset.rtLevel;const base=baseRaw!==undefined&&baseRaw!==''?Number(baseRaw):NaN;if(Number.isFinite(base)){level=base+nesting;break}level=nesting}parent=parent.parentElement}}for(const li of [...node.children].filter(child=>child.tagName?.toLowerCase()==='li')){addBlock(type,li,level);for(const nested of [...li.children].filter(child=>['ul','ol'].includes(child.tagName?.toLowerCase())))process(nested)}return}if(tag==='p'||tag==='div'||tag==='blockquote'){addBlock('paragraph',node,0);for(const nested of [...node.children].filter(child=>['ul','ol'].includes(child.tagName?.toLowerCase())))process(nested);return}for(const child of node.childNodes)process(child)};
  for(const child of editor.childNodes)process(child);return normalizeRichTextDocument({version:1,blocks});
}
function bindRichTextToolbars(){
  document.querySelectorAll('.rich-text-toolbar [data-rich-command]').forEach(button=>{if(button.dataset.richBound==='1')return;button.dataset.richBound='1';button.addEventListener('mousedown',event=>{event.preventDefault();const wrapper=button.closest('[data-rich-editor]');const editor=document.getElementById(wrapper?.dataset.richEditor||'');if(!editor)return;editor.focus();document.execCommand(button.dataset.richCommand,false,null)})});
}
function richTextEditorHTML(id,label,placeholder){return `<div class="rich-text-field"><div class="rich-text-field-label" id="${e(id)}Label">${e(label)}</div><div class="rich-text-editor" data-rich-editor="${e(id)}"><div class="rich-text-toolbar" role="toolbar" aria-label="Formatare ${e(label)}"><button type="button" data-rich-command="bold" title="Bold"><strong>B</strong></button><button type="button" data-rich-command="italic" title="Italic"><em>I</em></button><button type="button" data-rich-command="underline" title="Subliniat"><u>U</u></button><span class="rich-toolbar-separator"></span><button type="button" data-rich-command="insertUnorderedList" title="Listă cu bullets">• Listă</button><button type="button" data-rich-command="insertOrderedList" title="Listă numerotată">1. Listă</button><button type="button" data-rich-command="outdent" title="Micșorează indentarea">←</button><button type="button" data-rich-command="indent" title="Mărește indentarea">→</button></div><div id="${e(id)}" class="rich-text-surface" contenteditable="true" role="textbox" aria-multiline="true" aria-labelledby="${e(id)}Label" tabindex="0" data-placeholder="${e(placeholder)}"></div></div></div>`}


// 0.21.16 — navigare coerentă desktop/mobil; păstrează toate rutele și permisiunile existente.
const mobileNavToggle=document.getElementById('mobileNavToggle');
function closeMobileNav(){
  document.body.classList.remove('mobile-nav-open');
  mobileNavToggle?.setAttribute('aria-expanded','false');
  mobileNavToggle?.setAttribute('aria-label','Deschide meniul');
}
function updateSidebarGroups(){
  document.querySelectorAll('#nav .nav-group').forEach(group=>{
    group.hidden=![...group.querySelectorAll('a')].some(link=>!link.hidden);
  });
}
mobileNavToggle?.addEventListener('click',()=>{
  const open=document.body.classList.toggle('mobile-nav-open');
  mobileNavToggle.setAttribute('aria-expanded',String(open));
  mobileNavToggle.setAttribute('aria-label',open?'Închide meniul':'Deschide meniul');
});
window.addEventListener('keydown',event=>{if(event.key==='Escape')closeMobileNav()});
window.matchMedia('(min-width: 761px)').addEventListener('change',event=>{if(event.matches)closeMobileNav()});

// Meniurile sticky de secțiune sunt aliniate fără spațiu la topbar (care își poate schimba înălțimea).
function syncTopbarHeight(){
  const bar=document.querySelector('.topbar');
  if(bar)document.documentElement.style.setProperty('--ui-topbar-height',`${Math.ceil(bar.getBoundingClientRect().height)}px`);
}
syncTopbarHeight();
if(typeof ResizeObserver!=='undefined')new ResizeObserver(syncTopbarHeight).observe(document.querySelector('.topbar'));
window.addEventListener('resize',syncTopbarHeight,{passive:true});

async function init(){
  try{
    const versionElement=document.getElementById('appVersion');
    try{const build=await api('/version');state.timezone=build.timezone||state.timezone;if(versionElement)versionElement.textContent=`Server ${build.version||''}`.trim()}catch{if(versionElement)versionElement.textContent='Server'}
    state.user=await api('/api/v1/auth/me');state.csrf=state.user.csrf_token;
    document.getElementById('currentUser').textContent=state.user.display_name||state.user.username;
    document.querySelector('[data-page="audit"]').hidden=!can('audit.read');
    document.querySelector('[data-page="access"]').hidden=!can('rbac.manage');
    document.querySelector('[data-page="nomenclatures"]').hidden=!can('nomenclatures.read');
    document.querySelector('[data-page="services"]').hidden=!can('services.read');
    document.querySelector('[data-page="reports"]').hidden=!can('reports.read');
    document.querySelector('[data-page="security"]').hidden=!can('inventories.read');
    document.querySelector('[data-page="documents"]').hidden=!can('documents.read');
    document.querySelector('[data-page="equipment"]').hidden=!can('equipment.read');
    document.querySelector('[data-page="external"]').hidden=!can('external.read');
    document.querySelector('[data-page="changes"]').hidden=!can('inventories.read');
    document.querySelector('[data-page="backup"]').hidden=!can('veeam.read');
    document.querySelector('[data-page="monitoring"]').hidden=!can('monitoring.read');
    updateSidebarGroups();
    document.body.classList.remove('booting');route();
  }catch{location.href='/login'}
}

async function route(){
  const routeID=++routeGeneration;
  const raw=(location.hash||'#dashboard').slice(1);const [page,id,section]=raw.split('/');
  if(page!=='security'||!['overview','accounts','databases','web'].includes(id||'overview')){
    state.securityData=null;state.securityDataSection='';
    securityDBRenderCache.clear();
  }
  document.querySelectorAll('#nav a[data-page]').forEach(a=>{
    const active=a.dataset.page===page;
    a.classList.toggle('active',active);
    if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');
  });
  closeMobileNav();
  content.innerHTML='<div class="loading">Se încarcă…</div>';
  try{
    if(page==='dashboard')await dashboard();
    else if(page==='agents')await agentsPage(id||'list',section||'');
    else if(page==='vms'&&id&&/^\d+$/.test(id))await vmDetail(Number(id),section||'overview');
    else if(page==='vms')await vmsPage(id||'inventory');
    else if(page==='changes')await changesPage();
    else if(page==='archive')await lifecycleArchivePage();
    else if(page==='backup')await backupPage(id||'backup');
    else if(page==='monitoring')await monitoringPage(id||'overview');
    else if(page==='services'&&id)await internalServiceDetail(Number(id),section||'overview');
    else if(page==='services')await internalServicesPage();
    else if(page==='equipment')await equipmentPage(id||'');
    else if(page==='external')await externalSystemsPage(id||'');
    else if(page==='nomenclatures')await nomenclaturesPage(id||'');
    else if(page==='documents')await documentsPage(id||'export');
    else if(page==='releases')await releasesPage();
    else if(page==='reports')await reportsPage(id||'overview',section||'');
    else if(page==='security')await securityPage(id||'overview');
    else if(page==='audit')await auditPage();
    else if(page==='access')await accessPage();
    else location.hash='#dashboard';
  }catch(err){
    if(routeID!==routeGeneration)return;
    console.error('[VM-DOC 0.21.71] Route error:',location.hash,err);
    const dockerArea=page==='vms'&&['docker','databases','web'].includes(section);
    const trace=String(err?.stack||'').split('\n').slice(0,3).map(x=>x.trim()).join(' | ');
    const diagnostics=dockerArea&&/vmcontext/i.test(String(err?.message||''))?
      `<div class="notice warning"><strong>Diagnostic VM Docker/DB/Web · 0.21.71</strong><div>${e(trace||'Stack trace indisponibil')}</div><div>Trimite sursa și linia din acest mesaj sau din F12 → Console.</div></div>`:'';
    content.innerHTML=empty(err.message)+diagnostics;toast(err.message,true);
  }
}

function dashboardKPI(label,value,href,kind='',help=''){return `<a class="dashboard-kpi ${e(kind)}" href="${e(href)}"><span>${e(label)}</span><strong>${Number(value||0).toLocaleString('ro-RO')}</strong>${help?`<small>${e(help)}</small>`:''}</a>`}
function dashboardIssueBadges(row){const badges=[];if(row.no_agent)badges.push(['agent','Fără agent']);else if(row.agent_offline)badges.push(['agent','Agent offline']);if(row.backup_gap)badges.push(['backup','Backup']);if(row.inventory_stale)badges.push(['inventory','Inventar']);if(row.monitoring_gap)badges.push(['monitoring','Monitorizare']);if(row.ha_gap)badges.push(['ha','HA']);if(row.no_responsibility)badges.push(['documentation','Responsabil']);if(row.no_service)badges.push(['documentation','Serviciu']);if(row.no_environment)badges.push(['documentation','Mediu']);if(row.no_baseline)badges.push(['documentation','Baseline']);if(row.no_document)badges.push(['documentation','Fișă']);return badges.map(([kind,label])=>`<span class="dashboard-issue ${e(kind)}">${e(label)}</span>`).join('')}
function dashboardAttentionMatch(row,filter){if(!filter||filter==='all')return true;if(filter==='agent')return !!(row.no_agent||row.agent_offline);if(filter==='backup')return !!row.backup_gap;if(filter==='monitoring')return !!row.monitoring_gap;if(filter==='documentation')return !!row.documentation_gap;if(filter==='ha')return !!row.ha_gap;if(filter==='inventory')return !!row.inventory_stale;return true}
function dashboardAttentionTable(rows,filter='all'){const visible=(rows||[]).filter(row=>dashboardAttentionMatch(row,filter));if(!visible.length)return empty('Nu sunt VM-uri care necesită atenție pentru filtrul selectat.');return `<div class="table-wrap dashboard-attention-table"><table><thead><tr><th>VM</th><th>Probleme</th><th>Serviciu</th><th>Responsabil</th><th>Ultima colectare</th></tr></thead><tbody>${visible.map(row=>`<tr><td><a href="#vms/${row.id}/overview"><strong>${e(row.name)}</strong></a><div class="muted mono">${e(row.hostname||'—')}</div></td><td><div class="dashboard-issue-list">${dashboardIssueBadges(row)}</div></td><td>${e(row.services||'—')}</td><td>${e(row.responsibilities||'—')}</td><td>${row.inventory_received_at?dt(row.inventory_received_at):'—'}</td></tr>`).join('')}</tbody></table></div>`}
function dashboardRecentChanges(items){if(!items?.length)return empty('Nu există modificări recente relevante.');return `<div class="dashboard-change-list">${items.map(item=>`<article><div class="dashboard-change-time">${dt(item.occurred_at)}</div><div><strong>${e(item.action_label||item.action)}</strong><div class="dashboard-change-resource">${item.resource_url?`<a href="${e(item.resource_url)}">${e(item.resource_label||auditResourceTypeLabel(item.resource_type))}</a>`:e(item.resource_label||auditResourceTypeLabel(item.resource_type))}${item.vm_name&&item.resource_type!=='virtual_machine'?` <span>· ${e(item.vm_name)}</span>`:''}</div><small>${e(item.actor_username||item.source||'sistem')}</small></div>${auditOperationBadge(item.operation)}</article>`).join('')}</div>`}
function dashboardCoverage(rows){if(!rows?.length)return empty('Nu există indicatori de acoperire.');return `<div class="dashboard-coverage">${rows.map(row=>`<a href="${e(row.url||'#reports')}"><div><span>${e(row.label)}</span><strong>${Number(row.percent||0)}%</strong></div><div class="dashboard-progress"><i style="width:${Math.max(0,Math.min(100,Number(row.percent||0)))}%"></i></div><small>${Number(row.done||0).toLocaleString('ro-RO')} din ${Number(row.total||0).toLocaleString('ro-RO')}</small></a>`).join('')}</div>`}
function dashboardHA(groups,healthy){if(!groups?.length)return Number(healthy||0)>0?`<div class="dashboard-ok-block"><strong>${Number(healthy||0)}</strong><span>clustere / grupuri HA fără probleme detectate</span></div>`:`<div class="dashboard-ok-block"><strong>—</strong><span>Nu sunt configurate grupuri HA / cluster.</span></div>`;return `<div class="dashboard-ha-list">${groups.map(group=>`<article><div><a href="#vms/${group.source_vm_id}/services"><strong>${e(group.name)}</strong></a><span>${e(group.type||'cluster')} · ${Number(group.nodes||0)} noduri · sursă ${e(group.source_vm_name||'—')}</span></div><div class="warning-text">${e(group.issue)}</div></article>`).join('')}${healthy?`<div class="dashboard-healthy-note">+ ${Number(healthy).toLocaleString('ro-RO')} grupuri HA fără probleme detectate</div>`:''}</div>`}
function dashboardServiceIssues(rows){if(!rows?.length)return `<div class="dashboard-ok-block"><strong>✓</strong><span>Nu sunt servicii cu lipsuri majore de documentare.</span></div>`;return `<div class="dashboard-service-list">${rows.map(row=>`<article><div><a href="#services/${row.id}/overview"><strong>${e(row.name)}</strong></a><span>${Number(row.vm_count||0)} VM · ${e(row.documentation_status||'')}</span></div><div class="warning-text">${e(row.issue||'')}</div></article>`).join('')}</div>`}
function dashboardSearchResults(items){if(!items?.length)return `<div class="dashboard-search-empty">Niciun rezultat.</div>`;let last='';return items.map(item=>{const heading=item.type_label!==last?`<div class="dashboard-search-group">${e(item.type_label)}</div>`:'';last=item.type_label;return `${heading}<a class="dashboard-search-result" href="${e(item.url)}"><strong>${e(item.label)}</strong><span>${e(item.subtitle||'')}</span></a>`}).join('')}
async function dashboard(){
  pageMeta('Dashboard','Ce necesită atenție acum');
  const d=await api('/api/v1/dashboard'),s=d.summary||{},o=d.operations||{},attention=Array.isArray(d.attention)?d.attention:[];
  const search=`<section class="dashboard-search-shell"><div class="dashboard-search-box"><span class="dashboard-search-icon">⌕</span><input id="dashboardGlobalSearch" type="search" autocomplete="off" placeholder="Caută VM, IP, hostname, serviciu, persoană, DB, container, Web…"><span class="dashboard-search-hint">min. 2 caractere</span></div><div id="dashboardSearchResults" class="dashboard-search-results" hidden></div></section>`;
  const kpis=`<div class="dashboard-kpis">${dashboardKPI('VM-uri active',s.vms_total,'#vms/inventory','neutral','inventar curent')}${dashboardKPI('Agenți offline',s.agents_offline,'#agents/list/offline',s.agents_offline?'danger':'ok','agenți activați')}${dashboardKPI('Inventar vechi',s.inventory_stale,'#reports/operations/inventory',s.inventory_stale?'warning':'ok','lipsă sau > 7 zile')}${dashboardKPI('Fără backup',s.backup_gaps,'#reports/operations/backup',s.backup_gaps?'danger':'ok','VM-uri neacoperite')}${dashboardKPI('Fără monitorizare',s.monitoring_gaps,'#reports/operations/monitoring',s.monitoring_gaps?'warning':'ok','fără target asociat')}${dashboardKPI('Documentație incompletă',s.documentation_incomplete,'#reports/operations/documentation',s.documentation_incomplete?'warning':'ok','responsabil / serviciu / mediu / baseline / fișă') }</div>`;
  const attentionFilters=`<div class="dashboard-attention-filters"><button type="button" class="small active" data-attention-filter="all">Toate</button><button type="button" class="small secondary" data-attention-filter="agent">Agent</button><button type="button" class="small secondary" data-attention-filter="backup">Backup</button><button type="button" class="small secondary" data-attention-filter="monitoring">Monitorizare</button><button type="button" class="small secondary" data-attention-filter="documentation">Documentație</button><button type="button" class="small secondary" data-attention-filter="ha">HA</button></div>`;
  const operations=`<div class="dashboard-ops-grid"><div><span>Agenți online</span><strong>${Number(o.agents_online||0).toLocaleString('ro-RO')} / ${Number(o.agents_enabled||0).toLocaleString('ro-RO')}</strong></div><div><span>Inventar &lt; 24h</span><strong>${Number(o.inventory_fresh_24h||0).toLocaleString('ro-RO')} / ${Number(o.vms_active||0).toLocaleString('ro-RO')}</strong></div><div><span>Erori colectare · 24h</span><strong class="${Number(o.collection_errors_24h||0)?'warning-text':''}">${Number(o.collection_errors_24h||0).toLocaleString('ro-RO')}</strong></div><div><span>Joburi în așteptare</span><strong>${Number(o.jobs_pending||0).toLocaleString('ro-RO')}</strong></div></div><div class="dashboard-sync-list"><span>vCenter <strong>${dt(o.last_vcenter_sync)}</strong></span><span>Veeam <strong>${dt(o.last_veeam_sync)}</strong></span><span>Prometheus <strong>${dt(o.last_monitoring_sync)}</strong></span></div>`;
  const shortcuts=`<div class="dashboard-shortcuts"><a href="#vms/inventory">VM-uri</a><a href="#services">Servicii</a><a href="#backup">Backup</a><a href="#monitoring">Monitorizare</a><a href="#reports/operations">Lipsuri operaționale</a>${can('audit.read')?'<a href="#audit">Audit</a>':''}<a href="#reports">Rapoarte</a></div>`;
  content.innerHTML=`${search}${kpis}${panel('Necesită atenție',`${attentionFilters}<div id="dashboardAttentionArea">${dashboardAttentionTable(attention,'all')}</div>`,'<a href="#reports/operations" class="button-link small secondary">Deschide lista completă</a>')}<div class="dashboard-columns">${panel('Modificări recente',can('audit.read')?dashboardRecentChanges(d.recent_changes):empty('Vizualizarea modificărilor recente necesită permisiunea Audit.'),can('audit.read')?'<a href="#audit" class="button-link small secondary">Audit complet</a>':'<span class="muted">Acces restricționat</span>')}${panel('Colectări & stare infrastructură',operations)}</div><div class="dashboard-columns">${panel('Grad de acoperire',dashboardCoverage(d.coverage))}${panel('Clustere / HA cu probleme',dashboardHA(d.ha_groups,d.ha_groups_healthy))}</div>${panel('Servicii care necesită atenție',dashboardServiceIssues(d.service_issues),'<a href="#reports/documents" class="button-link small secondary">Raport documentație</a>')}${panel('Scurtături',shortcuts)}`;
  document.querySelectorAll('[data-attention-filter]').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('[data-attention-filter]').forEach(node=>{node.classList.toggle('active',node===button);node.classList.toggle('secondary',node!==button)});const area=document.getElementById('dashboardAttentionArea');if(area)area.innerHTML=dashboardAttentionTable(attention,button.dataset.attentionFilter)}));
  const input=document.getElementById('dashboardGlobalSearch'),results=document.getElementById('dashboardSearchResults');let timer=0,searchGeneration=0;
  const closeSearch=()=>{if(results){results.hidden=true;results.innerHTML=''}};
  input?.addEventListener('input',()=>{clearTimeout(timer);const value=input.value.trim();if(value.length<2){closeSearch();return}timer=setTimeout(async()=>{const generation=++searchGeneration;try{const items=await api(`/api/v1/dashboard/search?q=${encodeURIComponent(value)}`);if(generation!==searchGeneration)return;results.innerHTML=dashboardSearchResults(items);results.hidden=false}catch(err){if(generation!==searchGeneration)return;results.innerHTML=`<div class="dashboard-search-empty">${e(err.message)}</div>`;results.hidden=false}},220)});
  input?.addEventListener('keydown',event=>{if(event.key==='Escape'){input.value='';closeSearch()}else if(event.key==='Enter'){const first=results?.querySelector('a.dashboard-search-result');if(first){event.preventDefault();first.click()}}});
  document.addEventListener('click',function dashboardOutsideSearch(event){if(!document.querySelector('.dashboard-search-shell')){document.removeEventListener('click',dashboardOutsideSearch);return}if(!event.target.closest('.dashboard-search-shell'))closeSearch()});
}

function agentSectionNavigation(selected){
  const items=[['list','Listare agenți','Inventar, stare și colectare'],['releases','Release-uri agent','Publicare și auto-update']];
  return `<nav class="monitoring-section-tabs agent-section-tabs" aria-label="Secțiuni agenți">${items.map(([code,label,help])=>`<a href="#agents/${code}" class="${selected===code?'active':''}"><span>${e(label)}</span><small>${e(help)}</small></a>`).join('')}</nav>`;
}
function agentVMStatusOptionsMarkup(selected=''){
  const values=Array.isArray(state.agentVMOperationalStatuses)?[...state.agentVMOperationalStatuses]:[];
  if(selected&&selected!=='__unspecified__'&&selected!=='__unlinked__'&&!values.includes(selected))values.unshift(selected);
  return values.map(v=>`<option value="${e(v)}" ${selected===v?'selected':''}>${e(v)}</option>`).join('');
}
function syncAgentVMStatusOptions(result){
  const values=Array.isArray(result?.vm_operational_statuses)?result.vm_operational_statuses:[];
  state.agentVMOperationalStatuses=values;
  const select=document.getElementById('agentVMStatusFilter');if(!select)return;
  const selected=state.agentFilters.vmStatus||'';
  select.innerHTML=`<option value="">Toate</option>${agentVMStatusOptionsMarkup(selected)}<option value="__unspecified__" ${selected==='__unspecified__'?'selected':''}>Fără status operațional</option><option value="__unlinked__" ${selected==='__unlinked__'?'selected':''}>Fără VM</option>`;
  select.value=selected;
}
// Values come from the VM environment nomenclature, never a hardcoded PROD/TEST/DEV list.
let environmentCatalogue=[],environmentCataloguePromise=null;
async function loadEnvironmentCatalogue(){
  if(environmentCataloguePromise)return environmentCataloguePromise;
  environmentCataloguePromise=api('/api/v1/nomenclatures?include_inactive=true').then(categories=>{
    environmentCatalogue=categoryItems(categories,'environment').filter(item=>item&&String(item.name||'').trim());
    return environmentCatalogue;
  }).catch(error=>{environmentCataloguePromise=null;throw error});
  return environmentCataloguePromise;
}
function preferredProductionEnvironment(items=environmentCatalogue){
  return items.find(item=>item.active!==false&&String(item.item_code||'').trim().toUpperCase()==='PROD')||
    items.find(item=>item.active!==false&&environmentKind(item.name)==='prod')||null;
}
function environmentFilterOptions(selected){
  const production=preferredProductionEnvironment();
  const choices=environmentCatalogue;
  return `<option value="" ${selected===''?'selected':''}>Toate</option>`+choices.map(item=>{
    const value=item===production?'PROD':'name:'+item.name;
    return `<option value="${e(value)}" ${selected===value?'selected':''}>${e(item.name)}${item.active===false?' (inactiv)':''}</option>`;
  }).join('');
}
// Exact nomenclature names are intentionally distinct from broad, legacy PROD matching.
function environmentReportKey(label){return label?'name:'+String(label).trim():''}
function environmentReportMatches(rowValue,selected){
  if(!selected)return true;
  const name=String(rowValue||'').replace(/^name:/,'');
  return selected.startsWith('name:')?name.toLocaleLowerCase('ro-RO')===selected.slice(5).toLocaleLowerCase('ro-RO'):
    environmentKind(name)===String(selected).toLocaleLowerCase('ro-RO');
}
function agentListFilterMarkup(){
  const f=state.agentFilters,vmStatusOptions=agentVMStatusOptionsMarkup(f.vmStatus);
  return `<div class="agent-filter-shell"><div class="agent-filter-search-row"><label><span>Căutare</span><input id="agentSearch" type="search" value="${e(f.q)}" placeholder="Nume agent/VM, status VM, power, tip, IP, UUID, versiune, OS, canal sau eroare"></label></div><div class="agent-filter-options-row"><label><span>Status agent</span><select id="agentStatusFilter"><option value="">Toate</option><option value="online" ${f.status==='online'?'selected':''}>Online</option><option value="offline" ${f.status==='offline'?'selected':''}>Offline · problemă</option><option value="powered_off" ${f.status==='powered_off'?'selected':''}>VM oprit</option><option value="retired" ${f.status==='retired'?'selected':''}>VM retrasă</option><option value="unknown" ${f.status==='unknown'?'selected':''}>Necunoscut</option><option value="disabled" ${f.status==='disabled'?'selected':''}>Dezactivat</option></select></label><label><span>Status operațional VM</span><select id="agentVMStatusFilter"><option value="">Toate</option>${vmStatusOptions}<option value="__unspecified__" ${f.vmStatus==='__unspecified__'?'selected':''}>Fără status operațional</option><option value="__unlinked__" ${f.vmStatus==='__unlinked__'?'selected':''}>Fără VM</option></select></label><label><span>Power VM</span><select id="agentPowerFilter"><option value="">Toate</option><option value="POWERED_ON" ${f.power==='POWERED_ON'?'selected':''}>Power ON</option><option value="POWERED_OFF" ${f.power==='POWERED_OFF'?'selected':''}>Power OFF</option><option value="SUSPENDED" ${f.power==='SUSPENDED'?'selected':''}>Suspendat</option><option value="UNKNOWN" ${f.power==='UNKNOWN'?'selected':''}>Necunoscut</option><option value="UNLINKED" ${f.power==='UNLINKED'?'selected':''}>Fără VM</option></select></label><label><span>Mediu</span><select id="agentEnvironmentFilter">${environmentFilterOptions(f.environment)}</select></label><label><span>Tip agent</span><select id="agentTypeFilter"><option value="">Toate</option><option value="linux-amd64" ${f.type==='linux-amd64'?'selected':''}>Linux amd64</option><option value="linux-386" ${f.type==='linux-386'?'selected':''}>Linux 386</option><option value="windows-amd64" ${f.type==='windows-amd64'?'selected':''}>Windows amd64</option><option value="windows-386" ${f.type==='windows-386'?'selected':''}>Windows 386</option><option value="windows-xp" ${f.type==='windows-xp'?'selected':''}>Windows XP</option><option value="windows-legacy" ${f.type==='windows-legacy'?'selected':''}>Windows legacy</option><option value="sles9-legacy" ${f.type==='sles9-legacy'?'selected':''}>SLES 9 legacy</option><option value="unknown" ${f.type==='unknown'?'selected':''}>Necunoscut</option></select></label><label><span>Canal update</span><select id="agentChannelFilter"><option value="">Toate</option><option value="stable" ${f.channel==='stable'?'selected':''}>stable</option><option value="testing" ${f.channel==='testing'?'selected':''}>testing</option><option value="unknown" ${f.channel==='unknown'?'selected':''}>Necunoscut</option></select></label><button id="clearAgentFilters" type="button" class="secondary">Resetează</button></div></div>`;
}
function agentOSLabel(agent){const name=String(agent.os_name||'').trim(),version=String(agent.os_version||'').trim();return name?`${e(name)}${version?`<div class="muted">${e(version)}</div>`:''}`:'—'}
function agentTypeLabel(agent){const type=String(agent?.agent_type||'unknown').trim().toLowerCase(),labels={'linux-amd64':'Linux amd64','linux-386':'Linux 386','windows-amd64':'Windows amd64','windows-386':'Windows 386','windows-xp':'Windows XP','windows-legacy':'Windows legacy','sles9-legacy':'SLES 9 legacy','windows-unknown':'Windows · arch necunoscut','linux-unknown':'Linux · arch necunoscut','unknown':'Necunoscut'};const label=labels[type]||type,version=String(agent?.agent_version||'').trim(),arch=String(agent?.architecture||'').trim();return `<strong>${e(label)}</strong>${version?`<div class="muted">v${e(version)}</div>`:''}${arch&&!label.toLowerCase().includes(arch.toLowerCase())?`<div class="muted">${e(arch)}</div>`:''}`}
function agentOperationalStatusLabel(agent){const status=String(agent?.operational_status||agent?.status||'unknown').toLowerCase();if(status==='powered_off')return '<span class="badge powered-off">VM oprit</span>';if(status==='retired')return '<span class="badge disabled">VM retrasă</span>';if(status==='offline')return '<span class="badge missing">Offline</span>';return badge(status)}
function agentVMPowerBadge(agent){if(!agent?.vm_id)return '';const power=String(agent.vm_power_state||'').toUpperCase();if(power==='POWERED_ON')return '<span class="badge powered-on">ON</span>';if(power==='POWERED_OFF')return '<span class="badge powered-off">OFF</span>';if(power==='SUSPENDED')return '<span class="badge">SUSP</span>';return power?badge(power):'<span class="badge">?</span>'}
function agentVMOperationalLabel(agent){if(!agent?.vm_id)return '<span class="muted">Fără VM</span>';let status=String(agent.vm_operational_status||'').trim();const code=String(agent.vm_operational_status_code||'').trim().toLowerCase();if(!status&&agent.vm_retired)status='Retras';const retired=agent.vm_retired||code==='retired'||/^retras/i.test(status);const state=status?`<span class="badge ${retired?'disabled':''}">${e(status)}</span>`:'<span class="badge">Nespecificat</span>';const power=agentVMPowerBadge(agent),absent=agent.vm_present_in_vcenter===false?'<div class="muted">absent din vCenter</div>':'';return `${state}<div class="agent-vm-subline">${power}<a href="#vms/${agent.vm_id}/overview">${e(agent.vm_name||('VM #'+agent.vm_id))}</a></div>${absent}`}
function agentManagementLabel(agent){
  let ip=String(agent?.management_ip||'').trim();
  if(!ip){try{ip=new URL(agent?.base_url||'').hostname||''}catch(_){ip=''}}
  const registration=String(agent?.registration_ip||'').trim();
  const source=registration&&registration!==ip?`<div class="muted" title="IP sursă observat la register/heartbeat">Sursă: ${e(registration)}</div>`:'';
  return ip?`<strong class="mono" title="IP folosit de server pentru Test / Colect / Update">${e(ip)}</strong>${source}`:'—';
}
function agentUpdateLabel(agent){
  const u=agent?.update||{};if(!u.known)return '<span class="muted" title="Se detectează la următorul Test, Colect sau heartbeat">—</span>';
  const channel=u.channel?badge(u.channel):'<span class="muted">necunoscut</span>';
  const detail=!u.enabled?' <span class="muted">(oprit)</span>':u.state&&u.state!=='idle'&&u.state!=='current'?`<div class="muted">${e(u.state)}${u.available_version?` · ${e(u.available_version)}`:''}</div>`:'';
  return `${channel}${detail}`;
}
function agentIconAction(action,id,icon,label,kind='secondary'){return `<button type="button" class="agent-icon-action ${e(kind)}" data-action="${e(action)}" data-id="${id}" title="${e(label)}" aria-label="${e(label)}"><span aria-hidden="true">${icon}</span></button>`}
function agentActionLegend(){return `<div class="agent-table-legend"><strong>Legendă acțiuni</strong><span><b>↔</b> Test conexiune</span><span><b>↻</b> Colectează</span><span><b>⇧</b> Update</span><span><b>✎</b> Editare</span><span><b>×</b> Ștergere</span><span class="muted">Stare VM = Status operațional din fișa VM; Power ON/OFF este afișat dedesubt.</span></div>`}

function agentListTable(result){
  const f=state.agentFilters;state.agents=Array.isArray(result?.items)?result.items:[];f.page=Number(result?.page||1);
  const rows=state.agents.map(a=>{const actions=[can('collections.run')?`${agentIconAction('test',a.id,'↔','Test conexiune')}${agentIconAction('collect',a.id,'↻','Colectează','primary')}`:'',can('agents.manage')?`${agentIconAction('update',a.id,'⇧','Forțează update','primary')}${agentIconAction('edit',a.id,'✎','Editează agent')}${agentIconAction('delete',a.id,'×','Șterge agent','danger')}`:''].join('');const uuid=String(a.agent_uuid||'').trim(),err=String(a.last_error||'').trim();return `<tr><td class="agent-name-cell"><strong>${e(a.name)}</strong>${uuid?`<div class="muted mono agent-uuid-short" title="${e(uuid)}">${e(cropText(uuid,20))}</div>`:''}</td><td>${agentOperationalStatusLabel(a)}</td><td>${agentVMOperationalLabel(a)}</td><td>${agentTypeLabel(a)}</td><td>${agentManagementLabel(a)}</td><td>${agentOSLabel(a)}</td><td>${agentUpdateLabel(a)}</td><td>${dt(a.last_contact_at)}<div class="muted">Colect: ${dt(a.last_success_at)}</div></td><td class="muted agent-error-cell" title="${e(err)}">${e(err?cropText(err,70):'—')}</td><td class="agent-actions-cell"><div class="agent-row-actions">${actions||'—'}</div></td></tr>`}).join('');
  const total=Number(result?.total||0),pages=Number(result?.pages||0),startRow=total?(f.page-1)*f.pageSize+1:0,endRow=Math.min(f.page*f.pageSize,total);
  const pager=`<div class="pagination"><span>Afișate ${startRow.toLocaleString('ro-RO')}–${endRow.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="agentPageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'agent-page')}</div></div>`;
  return `${rows?`<div class="table-wrap agent-table-wrap"><table><thead><tr><th>Agent</th><th>Status agent</th><th title="Status operațional din fișa VM">Status VM</th><th>Tip / versiune</th><th>IP management</th><th>OS</th><th>Update</th><th>Contact</th><th>Eroare</th><th class="agent-actions-head">Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>${agentActionLegend()}`:empty('Nu există agenți pentru filtrele selectate.')}${pager}`;
}

function bindAgentTableActions(scope=document){
  scope.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>agentAction(b.dataset.action,Number(b.dataset.id)));
  scope.querySelectorAll('.agent-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.agentFilters.page){state.agentFilters.page=page;loadAgentList()}}));
  document.getElementById('agentPageSize')?.addEventListener('change',event=>{state.agentFilters.pageSize=Number(event.target.value);state.agentFilters.page=1;loadAgentList()});
}
function agentQuery(includePage=true){const f=state.agentFilters,p=new URLSearchParams();if(f.q)p.set('q',f.q);if(f.status)p.set('status',f.status);if(f.channel)p.set('channel',f.channel);if(f.type)p.set('agent_type',f.type);if(f.power)p.set('power',f.power);if(f.environment)p.set('environment',f.environment);if(f.vmStatus)p.set('vm_status',f.vmStatus);if(includePage){p.set('page',String(f.page));p.set('page_size',String(f.pageSize))}return p.toString()}
async function loadAgentList(){
  const area=document.getElementById('agentTableArea');if(!area)return;
  area.classList.add('is-loading');
  try{const result=await api(`/api/v1/agents?${agentQuery(true)}`);syncAgentVMStatusOptions(result);area.innerHTML=agentListTable(result);bindAgentTableActions(area);const exportLink=document.getElementById('exportAgents');if(exportLink)exportLink.href=`/api/v1/agents/export?${agentQuery(false)}`}catch(err){area.innerHTML=empty(err.message);changeSearchResultFeedback(0,err.message);toast(err.message,true)}finally{area.classList.remove('is-loading','loading')}
}
function agentReleaseQuery(includePage=true){const f=state.agentReleaseFilters,p=new URLSearchParams();[['q',f.q],['channel',f.channel],['os',f.os],['arch',f.arch],['validity',f.validity]].forEach(([k,v])=>{if(v)p.set(k,v)});if(includePage){p.set('page',String(f.page));p.set('page_size',String(f.pageSize))}return p.toString()}
function releaseListTable(result){
  const f=state.agentReleaseFilters,items=Array.isArray(result?.items)?result.items:[];f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
  const rows=items.map(r=>{const actions=can('agents.manage')?`<div class="actions">${r.channel==='testing'?`<button type="button" class="small agent-release-promote" data-version="${e(r.version)}" data-os="${e(r.os)}" data-arch="${e(r.arch)}">Promovează stable</button>`:''}<button type="button" class="small danger agent-release-delete" data-version="${e(r.version)}" data-channel="${e(r.channel)}" data-os="${e(r.os)}" data-arch="${e(r.arch)}">Șterge</button></div>`:'—';return `<tr><td><strong>${e(r.version)}</strong></td><td>${badge(r.channel)}</td><td>${e(r.os)} / ${e(r.arch)}</td><td>${r.valid?badge('ready'):badge('invalid')}</td><td>${dt(r.published_at)}</td><td class="muted">${e(r.notes||'—')}</td><td>${actions}</td></tr>`}).join('');
  const total=Number(result?.total||0),pages=Number(result?.pages||0),start=total?(f.page-1)*f.pageSize+1:0,end=Math.min(f.page*f.pageSize,total);
  const pager=`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="releasePageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'release-page')}</div></div>`;
  return `${rows?`<div class="table-wrap"><table><thead><tr><th>Versiune</th><th>Canal</th><th>Platformă</th><th>Repository</th><th>Publicat</th><th>Note</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există release-uri pentru filtrele selectate.')}${pager}`;
}
function bindReleaseTableActions(scope=document){
  scope.querySelectorAll('.agent-release-promote').forEach(button=>button.addEventListener('click',()=>promoteAgentRelease(button)));
  scope.querySelectorAll('.agent-release-delete').forEach(button=>button.addEventListener('click',()=>deleteAgentRelease(button)));
  scope.querySelectorAll('.release-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.agentReleaseFilters.page){state.agentReleaseFilters.page=page;loadReleaseList()}}));
  document.getElementById('releasePageSize')?.addEventListener('change',event=>{state.agentReleaseFilters.pageSize=Number(event.target.value);state.agentReleaseFilters.page=1;loadReleaseList()});
}
async function loadReleaseList(){
  const area=document.getElementById('releaseTableArea');if(!area)return;area.classList.add('is-loading');
  try{const result=await api(`/api/v1/agent-updates/releases?${agentReleaseQuery(true)}`);area.innerHTML=releaseListTable(result);bindReleaseTableActions(area);const exportLink=document.getElementById('exportAgentReleases');if(exportLink)exportLink.href=`/api/v1/agent-updates/releases/export?${agentReleaseQuery(false)}`}catch(err){area.innerHTML=empty(err.message);changeSearchResultFeedback(0,err.message);toast(err.message,true)}finally{area.classList.remove('is-loading','loading')}
}
async function agentsPage(requestedSection='list',preset=''){
  const section=['list','releases'].includes(requestedSection)?requestedSection:'list';if(section==='list'&&['online','offline','unknown','disabled'].includes(preset))state.agentFilters.status=preset;if(section!==requestedSection)history.replaceState(null,'',`#agents/${section}`);
  pageMeta('Agenți',section==='list'?'Inventar, stare și colectare':'Publicare versiuni și auto-update');
  const nav=agentSectionNavigation(section);let workspace='';
  if(section==='list'){
    await loadEnvironmentCatalogue();
    const tools=`<a id="exportAgents" class="button secondary" href="/api/v1/agents/export">Export Excel</a>${can('agents.manage')?'<button id="newAgent">Adaugă agent</button>':''}`;
    workspace=panel('Lista agenților',`${agentListFilterMarkup()}<div id="agentTableArea" class="loading">Se încarcă agenții…</div>`,tools);
  }else{
    const f=state.agentReleaseFilters;
    const publishForm=can('agents.manage')?`<form id="agentReleaseForm" class="form-grid upload-form agent-release-form"><label><span>Versiune</span><input name="version" required placeholder="1.3.4"></label><label><span>Canal</span><select name="channel"><option value="testing">testing</option><option value="stable">stable</option></select></label><label><span>OS</span><select name="os"><option value="linux">Linux</option><option value="windows">Windows</option></select></label><label><span>Arhitectură</span><select name="arch"><option value="amd64">amd64</option><option value="386">386 (i386/i686)</option></select></label><label class="span-2"><span>Agent</span><input name="agent" type="file" required></label><label class="span-2"><span>Updater</span><input name="updater" type="file" required></label><label class="span-2"><span>Note release</span><textarea name="notes" rows="2" placeholder="Modificările acestei versiuni"></textarea></label><div class="span-2 actions"><button type="submit">Publică în repository</button></div></form>`:'<p class="muted agent-release-form">Nu ai permisiunea agents.manage.</p>';
    const addRelease=`<details class="panel collapsible-panel agent-release-publish"><summary><span><strong>Adaugă release</strong><small>Închis implicit · deschide pentru publicare</small></span><span class="collapse-indicator">▾</span></summary><div class="collapsible-panel-body">${publishForm}<p class="muted panel-note">Publică mai întâi pe testing, validează pe un VM pilot, apoi promovează în stable.</p></div></details>`;
    const filters=`<div class="filterbar release-filterbar"><label class="release-search-field"><span>Căutare</span><input id="releaseSearch" type="search" value="${e(f.q)}" placeholder="Versiune, note sau fișier"></label><label><span>Canal</span><select id="releaseChannel"><option value="">Toate</option><option value="testing" ${f.channel==='testing'?'selected':''}>testing</option><option value="stable" ${f.channel==='stable'?'selected':''}>stable</option></select></label><label><span>OS</span><select id="releaseOS"><option value="">Toate</option><option value="linux" ${f.os==='linux'?'selected':''}>Linux</option><option value="windows" ${f.os==='windows'?'selected':''}>Windows</option></select></label><label><span>Arhitectură</span><select id="releaseArch"><option value="">Toate</option><option value="amd64" ${f.arch==='amd64'?'selected':''}>amd64</option><option value="386" ${f.arch==='386'?'selected':''}>386 (i386/i686)</option></select></label><label><span>Repository</span><select id="releaseValidity"><option value="">Toate</option><option value="valid" ${f.validity==='valid'?'selected':''}>Ready</option><option value="invalid" ${f.validity==='invalid'?'selected':''}>Invalid</option></select></label><button id="clearReleaseFilters" type="button" class="secondary">Resetează</button></div>`;
    workspace=addRelease+panel('Release-uri publicate',`${filters}<div id="releaseTableArea" class="loading">Se încarcă release-urile…</div>`,`<a id="exportAgentReleases" class="button secondary" href="/api/v1/agent-updates/releases/export">Export Excel</a>`);
  }
  content.innerHTML=`<div class="monitoring-workspace agent-layout">${nav}${workspace}</div>`;
  if(section==='list'){
    document.getElementById('newAgent')?.addEventListener('click',()=>openAgent());
    let timer;const search=document.getElementById('agentSearch');search?.addEventListener('input',event=>{clearTimeout(timer);const value=event.target.value;timer=setTimeout(()=>{state.agentFilters.q=value.trim();state.agentFilters.page=1;loadAgentList()},350)});
    document.getElementById('agentStatusFilter')?.addEventListener('change',event=>{state.agentFilters.status=event.target.value;state.agentFilters.page=1;loadAgentList()});document.getElementById('agentPowerFilter')?.addEventListener('change',event=>{state.agentFilters.power=event.target.value;state.agentFilters.page=1;loadAgentList()});document.getElementById('agentEnvironmentFilter')?.addEventListener('change',event=>{state.agentFilters.environment=event.target.value;state.agentFilters.page=1;loadAgentList()});document.getElementById('agentVMStatusFilter')?.addEventListener('change',event=>{state.agentFilters.vmStatus=event.target.value;state.agentFilters.page=1;loadAgentList()});document.getElementById('agentTypeFilter')?.addEventListener('change',event=>{state.agentFilters.type=event.target.value;state.agentFilters.page=1;loadAgentList()});document.getElementById('agentChannelFilter')?.addEventListener('change',event=>{state.agentFilters.channel=event.target.value;state.agentFilters.page=1;loadAgentList()});
    document.getElementById('clearAgentFilters')?.addEventListener('click',()=>{state.agentFilters={q:'',status:'',channel:'',type:'',power:'POWERED_ON',environment:'PROD',vmStatus:'',page:1,pageSize:10};if(search)search.value='';const status=document.getElementById('agentStatusFilter');if(status)status.value='';const power=document.getElementById('agentPowerFilter');if(power)power.value='POWERED_ON';const env=document.getElementById('agentEnvironmentFilter');if(env)env.value='PROD';const vmStatus=document.getElementById('agentVMStatusFilter');if(vmStatus)vmStatus.value='';const type=document.getElementById('agentTypeFilter');if(type)type.value='';const channel=document.getElementById('agentChannelFilter');if(channel)channel.value='';loadAgentList();search?.focus()});
    await loadAgentList();
  }else{
    document.getElementById('agentReleaseForm')?.addEventListener('submit',publishAgentRelease);
    let timer;document.getElementById('releaseSearch')?.addEventListener('input',event=>{clearTimeout(timer);const value=event.target.value;timer=setTimeout(()=>{state.agentReleaseFilters.q=value.trim();state.agentReleaseFilters.page=1;loadReleaseList()},350)});
    [['releaseChannel','channel'],['releaseOS','os'],['releaseArch','arch'],['releaseValidity','validity']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{state.agentReleaseFilters[key]=event.target.value;state.agentReleaseFilters.page=1;loadReleaseList()}));
    document.getElementById('clearReleaseFilters')?.addEventListener('click',()=>{state.agentReleaseFilters={q:'',channel:'',os:'',arch:'',validity:'',page:1,pageSize:10};agentsPage('releases')});
    await loadReleaseList();
  }
}
async function publishAgentRelease(event){
  event.preventDefault();const form=event.currentTarget;const data=new FormData(form);const button=form.querySelector('button[type=submit]');if(button)button.disabled=true;
  try{const release=await api('/api/v1/agent-updates/releases',{method:'POST',body:data});toast(`Agent ${release.version} publicat pe ${release.channel}.`);form.reset();await loadReleaseList()}catch(err){toast(err.message,true)}finally{if(button)button.disabled=false}
}
async function promoteAgentRelease(button){
  const {version,os,arch}=button.dataset;if(!confirm(`Promovezi agentul ${version} ${os}/${arch} din testing în stable?`))return;
  try{await api(`/api/v1/agent-updates/releases/${encodeURIComponent(version)}/promote?os=${encodeURIComponent(os)}&arch=${encodeURIComponent(arch)}`,{method:'POST'});toast(`Agent ${version} promovat în stable.`);loadReleaseList()}catch(err){toast(err.message,true)}
}
async function deleteAgentRelease(button){
  const {version,channel,os,arch}=button.dataset;if(!confirm(`Ștergi release-ul ${version} ${channel} ${os}/${arch}?`))return;
  try{await api(`/api/v1/agent-updates/releases/${encodeURIComponent(version)}?channel=${encodeURIComponent(channel)}&os=${encodeURIComponent(os)}&arch=${encodeURIComponent(arch)}`,{method:'DELETE'});toast('Release șters.');loadReleaseList()}catch(err){toast(err.message,true)}
}
function openAgent(agent=null){
  document.getElementById('agentDialogTitle').textContent=agent?'Editare agent':'Agent nou';
  document.getElementById('agentId').value=agent?.id||'';document.getElementById('agentName').value=agent?.name||'';document.getElementById('agentURL').value=agent?.base_url||'';document.getElementById('agentToken').value='';document.getElementById('agentToken').required=!agent;
  document.getElementById('agentInterval').value=agent?.collection_interval_seconds||900;document.getElementById('agentTimeout').value=agent?.request_timeout_seconds||45;document.getElementById('agentOffline').value=agent?.offline_after_seconds||2700;document.getElementById('agentEnabled').checked=agent?.enabled??true;document.getElementById('agentVerifyTLS').checked=agent?.verify_tls??true;agentDialog.showModal();
}
async function agentAction(action,id){
  const agent=state.agents.find(a=>a.id===id);
  if(action==='edit'){openAgent(agent);return}
  if(action==='delete'){if(!confirm(`Ștergi agentul ${agent.name}? Istoricul lui va fi șters.`))return;await api(`/api/v1/agents/${id}`,{method:'DELETE'});toast('Agent șters.');loadAgentList();return}
  if(action==='update'){
    const channel=agent?.update?.channel||'canalul configurat pe agent';if(!confirm(`Forțezi verificarea și instalarea update-ului pentru ${agent.name} pe ${channel}?`))return;
    try{const u=await api(`/api/v1/agents/${id}/update`,{method:'POST'});if(u.state==='disabled')toast(`Update dezactivat pe ${agent.name}.`,true);else if(u.state==='current')toast(`${agent.name} este deja la zi (${u.current_version||agent.agent_version||'versiune curentă'}) · ${u.channel||channel}.`);else if(u.state==='installing')toast(`Update ${u.available_version||''} pornit pe ${agent.name} · ${u.channel||channel}.`);else toast(`Update ${agent.name}: ${u.state||'verificare terminată'}${u.available_version?` · ${u.available_version}`:''}.`);[1200,3500,7000,15000].forEach(delay=>setTimeout(()=>{if(location.hash.startsWith('#agents/list'))loadAgentList()},delay))}catch(err){toast(err.message,true);setTimeout(loadAgentList,800)}return
  }
  const job=await api(`/api/v1/agents/${id}/${action==='test'?'test':'collect'}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(loadAgentList,1000);
}
agentForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('agentId').value||0);
  const body={name:document.getElementById('agentName').value.trim(),base_url:document.getElementById('agentURL').value.trim(),token:document.getElementById('agentToken').value,enabled:document.getElementById('agentEnabled').checked,verify_tls:document.getElementById('agentVerifyTLS').checked,collection_interval_seconds:Number(document.getElementById('agentInterval').value),request_timeout_seconds:Number(document.getElementById('agentTimeout').value),offline_after_seconds:Number(document.getElementById('agentOffline').value)};
  if(id&&!body.token)delete body.token;
  try{await api(id?`/api/v1/agents/${id}`:'/api/v1/agents',{method:id?'PATCH':'POST',body:JSON.stringify(body)});agentDialog.close();toast(id?'Agent actualizat.':'Agent creat.');agentsPage()}catch(err){toast(err.message,true)}
});

function vmsCurrentSection(){
  const parts=(location.hash||'#vms/inventory').slice(1).split('/');
  return parts[0]==='vms'&&parts[1]==='sources'?'sources':'inventory';
}
function vmsSectionNavigation(selected){
  const items=[['inventory','Inventar VM','Căutare, filtre și administrarea VM-urilor'],['sources','Surse & sincronizări','vCenter, programare și istoricul sincronizărilor']];
  return `<nav class="vm-section-tabs" aria-label="Secțiuni VM">${items.map(([code,label,help])=>`<a href="#vms/${code}" class="${selected===code?'active':''}"><span>${e(label)}</span><small>${e(help)}</small></a>`).join('')}</nav>`;
}
async function vmsPage(section='inventory'){
  section=section==='sources'?'sources':'inventory';
  if((location.hash||'')==='#vms')history.replaceState(null,'','#vms/inventory');
  if(section==='inventory')await loadEnvironmentCatalogue();
  const nav=vmsSectionNavigation(section),runPaging=state.vcenterRunPaging||{page:1,pageSize:10};
  const needsOutlinePublishState=section==='inventory'&&can('documents.read');
  const requests=[can('vcenter.read')?api('/api/v1/vcenter/sources'):Promise.resolve([]),section==='sources'&&can('vcenter.read')?api(`/api/v1/vcenter/sync-runs?page=${runPaging.page}&page_size=${runPaging.pageSize}`):Promise.resolve({items:[],page:1,page_size:10,total:0,pages:0}),section==='inventory'?api('/api/v1/services?include_inactive=true'):Promise.resolve([]),needsOutlinePublishState?api('/api/v1/outline/settings').catch(()=>({enabled:false})):Promise.resolve({enabled:false}),needsOutlinePublishState?api('/api/v1/outline/publication-targets').catch(()=>[]):Promise.resolve([])];
  const results=await Promise.all(requests);state.sources=Array.isArray(results[0])?results[0]:[];const runPage=results[1]||{},runs=Array.isArray(runPage.items)?runPage.items:[],vmServices=Array.isArray(results[2])?results[2]:[],outlineSettings=results[3]||{enabled:false},outlinePublicationTargets=Array.isArray(results[4])?results[4]:[];
  if(section==='sources'){
    state.vcenterRunPaging.page=Number(runPage.page||1);state.vcenterRunPaging.pageSize=Number(runPage.page_size||state.vcenterRunPaging.pageSize||10);
    pageMeta('VM-uri','Surse vCenter și istoricul sincronizărilor');
    const tools=can('vcenter.manage')?'<button id="syncAll">Sincronizează toate</button><button id="newVCenter" class="secondary">Adaugă sursă</button>':'';
    const sourceRows=state.sources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${e(s.username)}</td><td>${s.daily_sync_enabled?`Zilnic ${e(s.daily_sync_time)} · ${e(state.timezone)}`:'Manual'}</td><td>${dt(s.last_success_at)}<div class="error-text">${e(s.last_error||'')}</div><div class="muted">${Number(s.excluded_pool_count||0)} pool-uri excluse</div>${Number(s.excluded_powered_on_count||0)?`<div class="error-text"><strong>⚠ ${Number(s.excluded_powered_on_count)} VM pornite în pool-uri excluse</strong></div>`:''}</td><td><div class="actions">${can('vcenter.manage')?`<button class="small secondary vc-action" data-action="test" data-id="${s.id}">Test</button><button class="small vc-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary vc-action" data-action="pools" data-id="${s.id}">Pool-uri</button><button class="small secondary vc-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger vc-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
    const runRows=runs.map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.vcenter_source_name)}</td><td>${badge(r.status)}</td><td>${r.found_count}</td><td>+${r.created_count} / ~${r.updated_count} / lipsă ${r.missing_count}</td><td>${r.linked_agent_count}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');
    const runTotal=Number(runPage.total||0),runCurrent=Number(runPage.page||1),runPageSize=Number(runPage.page_size||10),runStart=runTotal?(runCurrent-1)*runPageSize+1:0,runEnd=Math.min(runCurrent*runPageSize,runTotal);
    const runPager=runTotal?`<div class="pagination"><span>Afișate ${runStart.toLocaleString('ro-RO')}–${runEnd.toLocaleString('ro-RO')} din ${runTotal.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="vcenterRunPageSize">${pageSizeOptions(runPageSize,[10,25,50,100,200])}</select></label>${paginationButtons(runCurrent,Number(runPage.pages||1),'vcenter-run-page')}</div></div>`:'';
    content.innerHTML=`<div class="vm-page-workspace">${nav}${panel('Surse vCenter',state.sources.length?`<div class="table-wrap vcenter-source-table"><table><thead><tr><th>Sursă</th><th>Utilizator</th><th>Program</th><th>Ultima sincronizare</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse vCenter configurate.'),tools)}${panel('Ultimele sincronizări',runRows?`<div class="table-wrap vcenter-run-table"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Găsite</th><th>Modificări</th><th>Agenți legați</th><th>Eroare</th></tr></thead><tbody>${runRows}</tbody></table></div>${runPager}`:empty('Nu există sincronizări.'))}</div>`;
    document.getElementById('syncAll')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/vcenter/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări introduse în coadă.`);setTimeout(()=>vmsPage('sources'),1200)}catch(err){toast(err.message,true)}});
    document.getElementById('newVCenter')?.addEventListener('click',()=>openVCenter());
    content.querySelectorAll('.vc-action').forEach(b=>b.onclick=()=>vcenterAction(b.dataset.action,Number(b.dataset.id)));
    content.querySelectorAll('.vcenter-run-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vcenterRunPaging.page){state.vcenterRunPaging.page=page;vmsPage('sources')}}));
    document.getElementById('vcenterRunPageSize')?.addEventListener('change',event=>{state.vcenterRunPaging.pageSize=Number(event.target.value);state.vcenterRunPaging.page=1;vmsPage('sources')});
    return;
  }
  pageMeta('VM-uri','Inventar, stare, servicii și documentație');
  const filters=state.vmFilters,sourceOptions=state.sources.map(s=>`<option value="${s.id}" ${String(filters.sourceId)===String(s.id)?'selected':''}>${e(s.name)}</option>`).join(''),serviceOptions=vmServices.filter(s=>s.active!==false).map(s=>`<option value="${s.id}" ${String(filters.serviceId)===String(s.id)?'selected':''}>${e(s.name)}</option>`).join('');
  const vmOutlineTarget=outlinePublicationTargets.find(item=>item?.code==='vm_inventory')||{},canPublishVMInventoryOutline=can('documents.manage')&&outlineSettings.enabled===true&&vmOutlineTarget.active===true&&String(vmOutlineTarget.document_reference||'').trim()!=='';
  const tools=`<div class="actions"><a id="exportVMs" class="button secondary" href="/api/v1/vms/export">Export Excel</a>${canPublishVMInventoryOutline?'<button id="publishVMInventoryOutline" type="button">Publică tabelul în Outline</button>':''}</div>`;
  const filterBody=`<div class="vm-filter-shell">
    <div class="vm-filter-primary">
      <label class="vm-search-field"><span>Căutare VM</span><input id="vmSearch" type="search" value="${e(filters.q)}" placeholder="Nume, hostname, OS, IP, agent, serviciu sau sursă"></label>
      <label class="vm-power-field"><span>Power</span><select id="vmPower"><option value="">Toate</option><option value="POWERED_ON" ${filters.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${filters.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${filters.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label><label class="vm-environment-field"><span>Mediu</span><select id="vmEnvironment">${environmentFilterOptions(filters.environment)}</select></label>
    </div>
    <div class="vm-filter-disclosure">
      <div class="vm-filter-overview">
        <div id="vmActiveFilters" class="vm-active-filters" aria-live="polite"><span class="vm-filter-caption">Filtre:</span><span class="muted">Niciun filtru activ</span></div>
        <button id="vmAdvancedToggle" class="vm-advanced-toggle" type="button" aria-label="Arată filtrele suplimentare" aria-controls="vmAdvancedFilters" aria-expanded="${state.vmAdvancedFiltersOpen?'true':'false'}"><span aria-hidden="true">⌄</span></button>
        <button id="clearVMFilters" class="secondary vm-clear-filter" type="button">Resetează</button>
      </div>
      <div id="vmAdvancedFilters" class="vm-filter-advanced" ${state.vmAdvancedFiltersOpen?'':'hidden'}>
        <div class="vm-filter-grid">
      <label><span>Agent</span><select id="vmAgentFilter"><option value="">Toți</option><option value="configured" ${filters.agent==='configured'?'selected':''}>Asociat</option><option value="unconfigured" ${filters.agent==='unconfigured'?'selected':''}>Fără agent</option><option value="online" ${filters.agent==='online'?'selected':''}>Online</option><option value="offline" ${filters.agent==='offline'?'selected':''}>Offline</option><option value="unknown" ${filters.agent==='unknown'?'selected':''}>Necunoscut</option><option value="disabled" ${filters.agent==='disabled'?'selected':''}>Dezactivat</option></select></label>
      <label><span>vCenter</span><select id="vmPresence"><option value="">Toate</option><option value="present" ${filters.presence==='present'?'selected':''}>Prezente</option><option value="missing" ${filters.presence==='missing'?'selected':''}>Lipsă din vCenter</option></select></label>
      <label><span>Baseline</span><select id="vmBaseline"><option value="">Toate</option><option value="yes" ${filters.baseline==='yes'?'selected':''}>Da</option><option value="no" ${filters.baseline==='no'?'selected':''}>Nu</option></select></label>
      <label><span>Serviciu</span><select id="vmServiceFilter"><option value="">Toate serviciile</option>${serviceOptions}</select></label>
      <label><span>Sursă vCenter</span><select id="vmSource"><option value="">Toate sursele</option>${sourceOptions}</select></label>
      <label><span>Outline</span><select id="vmOutlineFilter"><option value="" ${!filters.outline?'selected':''}>Toate</option><option value="yes" ${filters.outline==='yes'?'selected':''}>DA</option><option value="no" ${filters.outline==='no'?'selected':''}>NU</option></select></label>
      <label><span>OS suportat</span><select id="vmOSSupportFilter"><option value="" ${!filters.osSupport?'selected':''}>Toate</option><option value="yes" ${filters.osSupport==='yes'?'selected':''}>DA</option><option value="no" ${filters.osSupport==='no'?'selected':''}>NU</option></select></label>
      <label><span>Pe pagină</span><select id="vmPageSize">${[10,25,50,100,200].map(n=>`<option value="${n}" ${Number(filters.pageSize)===n?'selected':''}>${n}</option>`).join('')}</select></label>
        </div>
      </div>
    </div>
  </div><div id="vmTableArea" class="loading">Se încarcă VM-urile…</div>`;
  content.innerHTML=`<div class="vm-page-workspace">${nav}<div class="cards ui-kpi-seven vm-list-summary-cards" id="vmSummaryCards" aria-label="Rezumat VM filtrate">
    <button type="button" class="card vm-summary-card" data-vm-card="total" title="Resetează filtrele și afișează toate VM-urile"><span class="label">Rezultate</span><strong id="vmTotal" class="value">—</strong><small class="card-percent">Total filtrat</small></button>
    <button type="button" class="card vm-summary-card" data-vm-card="powered" title="Filtrează VM-urile pornite"><span class="label">Pornite</span><strong id="vmPoweredOn" class="value">—</strong><small id="vmPoweredOnPct" class="card-percent">—</small></button>
    <button type="button" class="card vm-summary-card" data-vm-card="outline_published" title="Filtrează VM-urile publicate în Outline"><span class="label">Publicare Outline</span><strong id="vmOutlinePublished" class="value">—</strong><small id="vmOutlinePublishedPct" class="card-percent">—</small></button>
    <button type="button" class="card vm-summary-card" data-vm-card="completion" title="Ordonează VM-urile după completare, crescător"><span class="label">Completare generală</span><strong id="vmCompletionAvg" class="value">—</strong><small class="card-percent">Medie VM filtrate</small></button>
    <button type="button" class="card vm-summary-card" data-vm-card="present" title="Filtrează VM-urile prezente în vCenter"><span class="label">Prezente în vCenter</span><strong id="vmPresent" class="value">—</strong><small id="vmPresentPct" class="card-percent">—</small></button>
    <button type="button" class="card vm-summary-card" data-vm-card="missing" title="Filtrează VM-urile lipsă din vCenter"><span class="label">Lipsă din vCenter</span><strong id="vmMissing" class="value">—</strong><small id="vmMissingPct" class="card-percent">—</small></button>
    <button type="button" class="card vm-summary-card" data-vm-card="agent" title="Filtrează VM-urile cu agent asociat"><span class="label">Cu agent asociat</span><strong id="vmWithAgent" class="value">—</strong><small id="vmWithAgentPct" class="card-percent">—</small></button>
  </div>${panel('Inventar VM',filterBody,tools)}</div>`;
  bindVMFilters();bindVMCardActions();updateVMCardSelection();document.getElementById('publishVMInventoryOutline')?.addEventListener('click',publishFilteredVMInventoryOutline);await loadVMPage();
}

function vmQuery(includePage=true){
  const f=state.vmFilters,params=new URLSearchParams();
  params.set('retired','false'); // inventarul operațional nu include VM-uri retrase
  if(f.q)params.set('q',f.q);if(f.power)params.set('power',f.power);if(f.environment)params.set('environment',f.environment);if(f.agent)params.set('agent',f.agent);if(f.presence)params.set('presence',f.presence);if(f.baseline)params.set('baseline',f.baseline);if(f.serviceId)params.set('service_id',f.serviceId);if(f.sourceId)params.set('source_id',f.sourceId);if(f.outline)params.set('outline',f.outline);if(f.osSupport)params.set('os_support',f.osSupport);if(f.published)params.set('published',f.published);if(f.sort)params.set('sort',f.sort);
  if(includePage){params.set('page',String(f.page));params.set('page_size',String(f.pageSize))}
  return params.toString();
}

function updateVMActiveFilters(){
  const host=document.getElementById('vmActiveFilters');if(!host)return;
  const f=state.vmFilters,items=[];
  if(f.q)items.push(`Căutare: ${f.q}`);
  const picks=[['vmPower','power','Power'],['vmEnvironment','environment','Mediu'],['vmAgentFilter','agent','Agent'],['vmPresence','presence','vCenter'],['vmBaseline','baseline','Baseline'],['vmServiceFilter','serviceId','Serviciu'],['vmSource','sourceId','Sursă']];
  for(const [id,key,name] of picks){if(!f[key])continue;const select=document.getElementById(id),text=select?.options?.[select.selectedIndex]?.textContent?.trim();if(text)items.push(`${name}: ${text}`)}
  if(f.outline)items.push(`Publicare permisă: ${f.outline==='yes'?'DA':'NU'}`);
  if(f.osSupport)items.push(`OS suportat: ${f.osSupport==='yes'?'DA':'NU'}`);
  if(f.published)items.push(`Publicate în Outline: ${f.published==='yes'?'DA':'NU'}`);
  if(f.sort){const [column,direction]=vmSortParts(f.sort);items.push(`Sortare: ${vmSortLabels[column]||'Completare'} · ${direction==='desc'?'descrescător':'crescător'}`)}
  host.innerHTML=`<span class="vm-filter-caption">Filtre:</span>${items.length?items.map(v=>`<span class="vm-filter-chip">${e(v)}</span>`).join(''):'<span class="muted">Niciun filtru activ</span>'}`;
  const arrow=document.getElementById('vmAdvancedToggle');if(arrow)arrow.title=state.vmAdvancedFiltersOpen?'Ascunde filtrele suplimentare':'Arată filtrele suplimentare';
}
function bindVMCardActions(){
  const cards=document.getElementById('vmSummaryCards');if(!cards)return;
  cards.addEventListener('click',event=>{
    const button=event.target.closest('[data-vm-card]');if(!button)return;
    const f=state.vmFilters,action=button.dataset.vmCard;
    if(action==='total'){
      state.vmFilters={q:'',power:'POWERED_ON',environment:'PROD',agent:'',presence:'',baseline:'',serviceId:'',sourceId:'',outline:'',osSupport:'',published:'',sort:'',page:1,pageSize:f.pageSize};
      vmsPage('inventory');return;
    }
    if(action==='powered')f.power=f.power==='POWERED_ON'?'':'POWERED_ON';
    else if(action==='outline_published')f.published=f.published==='yes'?'':'yes';
    else if(action==='completion')f.sort=f.sort==='completion_asc'?'':'completion_asc';
    else if(action==='present')f.presence=f.presence==='present'?'':'present';
    else if(action==='missing')f.presence=f.presence==='missing'?'':'missing';
    else if(action==='agent')f.agent=f.agent==='configured'?'':'configured';
    f.page=1;
    // Rebuild the selects and chips to reflect selections triggered by summary cards.
    vmsPage('inventory');
  });
}
function updateVMCardSelection(){
  const f=state.vmFilters;
  const selected={powered:f.power==='POWERED_ON',outline_published:f.published==='yes',completion:f.sort==='completion_asc',present:f.presence==='present',missing:f.presence==='missing',agent:f.agent==='configured'};
  document.querySelectorAll('#vmSummaryCards [data-vm-card]').forEach(button=>{
    const active=!!selected[button.dataset.vmCard];button.classList.toggle('active-filter',active);button.setAttribute('aria-pressed',String(active));
  });
}

function bindVMFilters(){
  document.getElementById('vmAdvancedToggle')?.addEventListener('click',event=>{
    state.vmAdvancedFiltersOpen=!state.vmAdvancedFiltersOpen;
    const panel=document.getElementById('vmAdvancedFilters');if(panel)panel.hidden=!state.vmAdvancedFiltersOpen;
    event.currentTarget.setAttribute('aria-expanded',String(state.vmAdvancedFiltersOpen));
    event.currentTarget.setAttribute('aria-label',state.vmAdvancedFiltersOpen?'Ascunde filtrele suplimentare':'Arată filtrele suplimentare');
    updateVMActiveFilters();
  });
  let timer;
  document.getElementById('vmSearch')?.addEventListener('input',event=>{clearTimeout(timer);timer=setTimeout(()=>{state.vmFilters.q=event.target.value.trim();state.vmFilters.page=1;updateVMActiveFilters();loadVMPage()},300)});
  const bindings={vmPower:'power',vmEnvironment:'environment',vmAgentFilter:'agent',vmPresence:'presence',vmBaseline:'baseline',vmServiceFilter:'serviceId',vmSource:'sourceId',vmOutlineFilter:'outline',vmOSSupportFilter:'osSupport'};
  Object.entries(bindings).forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{state.vmFilters[key]=event.target.value;state.vmFilters.page=1;updateVMActiveFilters();loadVMPage()}));
  document.getElementById('vmPageSize')?.addEventListener('change',event=>{state.vmFilters.pageSize=Number(event.target.value);state.vmFilters.page=1;loadVMPage()});
  document.getElementById('clearVMFilters')?.addEventListener('click',()=>{state.vmFilters={q:'',power:'POWERED_ON',environment:'PROD',agent:'',presence:'',baseline:'',serviceId:'',sourceId:'',outline:'',osSupport:'',published:'',sort:'',page:1,pageSize:10};vmsPage('inventory')});updateVMActiveFilters();
}

async function loadVMPage(){
  const area=document.getElementById('vmTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă VM-urile…';
  try{
    const result=await api(`/api/v1/vms?${vmQuery(true)}`);state.vms=Array.isArray(result?.items)?result.items:[];state.vmFilters.page=Number(result?.page||1);
    const vmTotal=Number(result?.total||0);state.vmListTotal=vmTotal;
    const vmPresent=Number(result?.present_count||0),vmMissing=Math.max(0,vmTotal-vmPresent),vmAgent=Number(result?.with_agent_count||0),vmPowered=Number(result?.powered_on_count||0),vmPublished=Number(result?.outline_published_count||0);
    const avg=Number(result?.completion_average_percent||0),vmPct=value=>vmTotal?`${(Number(value)*100/vmTotal).toFixed(1)}%`:'0%';
    const setNum=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=Number(value).toLocaleString('ro-RO')};
    const setText=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=value};
    for(const [id,value] of [['vmTotal',vmTotal],['vmPresent',vmPresent],['vmMissing',vmMissing],['vmWithAgent',vmAgent],['vmPoweredOn',vmPowered],['vmOutlinePublished',vmPublished]])setNum(id,value);
    for(const [id,value] of [['vmPresentPct',vmPresent],['vmMissingPct',vmMissing],['vmWithAgentPct',vmAgent],['vmPoweredOnPct',vmPowered],['vmOutlinePublishedPct',vmPublished]])setText(id,vmPct(value));
    setText('vmCompletionAvg',vmTotal?`${avg.toLocaleString('ro-RO',{minimumFractionDigits:1,maximumFractionDigits:1})}%`:'—');
    updateVMCardSelection();
    const exportLink=document.getElementById('exportVMs');if(exportLink)exportLink.href=`/api/v1/vms/export?${vmQuery(false)}`;
    area.className='';area.innerHTML=renderVMPage(result);bindVMDeleteActions(area);bindVMServiceExpand(area);bindVMGlobalSorting(area);
    area.querySelectorAll('.vm-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmFilters.page){state.vmFilters.page=page;loadVMPage();area.scrollIntoView({behavior:'smooth',block:'start'})}}));
  }catch(err){area.className='';area.innerHTML=empty(err.message);changeSearchResultFeedback(0,err.message);toast(err.message,true)}
}

async function publishFilteredVMInventoryOutline(event){
  const button=event?.currentTarget||document.getElementById('publishVMInventoryOutline');
  const total=Number(state.vmListTotal||0);
  if(total===0){toast('Nu există VM-uri pentru filtrele curente; pagina Outline nu a fost modificată.',true);return}
  if(!confirm(`Publici în Outline tabelul cu ${total.toLocaleString('ro-RO')} VM-uri rezultate din filtrele curente?\n\nPagina țintă este cea configurată la Documente → Configurare Outline → Destinații publicare.`))return;
  if(button){button.disabled=true;button.textContent='Se publică…'}
  try{const response=await api(`/api/v1/vms/outline-table?${vmQuery(false)}`,{method:'POST',body:'{}'});const result=response?.result||{};toast(`Tabelul VM a fost publicat în Outline · ${Number(response?.rows||0).toLocaleString('ro-RO')} rânduri.`);if(result.url){const link=document.createElement('a');link.href=result.url;link.target='_blank';link.rel='noopener';link.click()}}catch(err){toast(err.message,true)}finally{if(button){button.disabled=false;button.textContent='Publică tabelul în Outline'}}
}

function vmVCenterState(v){
  if(v.present_in_vcenter)return '<span class="badge vm-vcenter-present">Prezentă</span>';
  return `<span class="badge vm-vcenter-missing">Lipsă</span>${v.missing_since?`<div class="muted">din ${dt(v.missing_since)}</div>`:''}`;
}
function vmDeleteImpactText(impact){
  const values=[];
  if(impact.agent_id)values.push('agent asociat: da (agentul NU va fi șters)');
  if(impact.direct_service_assignments)values.push(`asocieri directe servicii: ${impact.direct_service_assignments}`);
  if(impact.resource_service_links)values.push(`asocieri servicii pe Docker/DB/Web: ${impact.resource_service_links}`);
  if(impact.generated_documents)values.push(`fișe generate: ${impact.generated_documents}`);
  if(impact.monitoring_targets)values.push(`targeturi monitorizare ce vor deveni necorelate: ${impact.monitoring_targets}`);
  if(impact.backup_records)values.push(`înregistrări backup: ${impact.backup_records}`);
  if(impact.external_connections)values.push(`conexiuni externe: ${impact.external_connections}`);
  if(impact.common_dependencies)values.push(`dependențe comune: ${impact.common_dependencies}`);
  if(impact.responsibilities)values.push(`responsabilități: ${impact.responsibilities}`);
  if(impact.inventory_changes)values.push(`modificări inventar: ${impact.inventory_changes}`);
  return values.length?values.map(v=>`• ${v}`).join('\n'):'• nu sunt legături funcționale importante identificate';
}
async function deleteVMPermanent(id,afterDelete){
  try{
    const impact=await api(`/api/v1/vms/${id}/delete-impact`);
    if(impact.present_in_vcenter){toast('VM-ul este încă prezent în vCenter. Șterge-l din vCenter și rulează Sync înainte.',true);return}
    const message=`Ștergi DEFINITIV VM-ul ${impact.name}?\n\nAceastă operație nu folosește arhivare și nu poate fi anulată.\n${vmDeleteImpactText(impact)}\n\nÎnregistrările dependente ale VM-ului vor fi eliminate; agentul asociat rămâne în pagina Agenți.`;
    if(!confirm(message))return;
    await api(`/api/v1/vms/${id}`,{method:'DELETE'});
    toast(`VM ${impact.name} ștearsă definitiv.`);
    if(afterDelete)await afterDelete();
  }catch(err){toast(err.message,true)}
}
async function deleteSelectedVMs(){
  const ids=[...document.querySelectorAll('.vm-delete-select:checked')].map(x=>Number(x.value)).filter(Boolean);
  if(!ids.length){toast('Selectează cel puțin o VM lipsă din vCenter.',true);return}
  if(!confirm(`Ștergi DEFINITIV ${ids.length} VM-uri selectate?\n\nSe șterg și legăturile/datele dependente ale acestor VM-uri. Targeturile de monitorizare rămân, dar devin necorelate. Agenții nu sunt șterși.`))return;
  try{const result=await api('/api/v1/vms/delete-bulk',{method:'POST',body:JSON.stringify({ids})});toast(`${result.count||ids.length} VM-uri șterse definitiv.`);await loadVMPage()}catch(err){toast(err.message,true)}
}
function bindVMDeleteActions(area){
  const selected=()=>[...area.querySelectorAll('.vm-delete-select:checked')].length;
  const refresh=()=>{const b=area.querySelector('#deleteSelectedVMs');if(b){const n=selected();b.disabled=!n;b.textContent=n?`Șterge definitiv selectate (${n})`:'Șterge definitiv selectate'}};
  area.querySelectorAll('.vm-delete-one').forEach(button=>button.addEventListener('click',()=>deleteVMPermanent(Number(button.dataset.id),loadVMPage)));
  area.querySelectorAll('.vm-delete-select').forEach(input=>input.addEventListener('change',refresh));
  area.querySelector('#selectMissingVMs')?.addEventListener('change',event=>{area.querySelectorAll('.vm-delete-select').forEach(input=>input.checked=event.target.checked);refresh()});
  area.querySelector('#deleteSelectedVMs')?.addEventListener('click',deleteSelectedVMs);
  refresh();
}

// Sortare pentru întregul inventar: cererea ajunge în SQL înainte de LIMIT/OFFSET.
// Celelalte tabele păstrează sortarea locală; aceasta este exclusă explicit din mecanismul generic.
const vmSortLabels={name:'VM',presence:'vCenter',power:'Power',cpu:'CPU / RAM',os:'OS',ip:'IP',agent:'Agent',services:'Servicii',publication:'Publicare',outline_date:'Outline',completion:'Completare',inventory_date:'Ultimul JSON'};
function vmSortParts(sort){if(sort==='completion_asc')return ['completion','asc'];const match=/^([a-z_]+):(asc|desc)$/.exec(sort||'');return match?[match[1],match[2]]:['','']}
function vmSortAria(column){const [active,direction]=vmSortParts(state.vmFilters.sort);return active===column?(direction==='desc'?'descending':'ascending'):'none'}
function bindVMGlobalSorting(area){
  const activate=th=>{
    const column=th.dataset.vmSort;if(!vmSortLabels[column])return;
    const [current,direction]=vmSortParts(state.vmFilters.sort);
    state.vmFilters.sort=`${column}:${current===column&&direction==='asc'?'desc':'asc'}`;
    state.vmFilters.page=1;updateVMActiveFilters();loadVMPage();
  };
  area.querySelectorAll('th[data-vm-sort]').forEach(th=>{
    th.title='Sortează toate VM-urile (înainte de paginare)';
    th.addEventListener('click',()=>activate(th));
    th.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();activate(th)}});
  });
}
function renderVMPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există VM-uri pentru filtrele selectate.');
  const deletable=items.filter(v=>!v.present_in_vcenter);
  const rows=items.map(v=>{const completion=Math.max(0,Math.min(100,Number(v.completion_percent||0))),version=v.agent_version?`<span class="vm-agent-inline-version mono">${e(v.agent_version)}</span>`:'';return `<tr><td class="vm-select-col">${!v.present_in_vcenter&&can('vms.manage')?`<input class="vm-delete-select" type="checkbox" value="${v.id}" aria-label="Selectează ${e(v.name)} pentru ștergere">`:''}</td><td><a href="#vms/${v.id}/overview"><strong>${e(v.name)}</strong></a></td><td>${vmVCenterState(v)}</td><td>${powerShortBadge(v.power_state)}</td><td>${v.cpu_count||'—'} / ${memory(v.memory_mib)}</td><td>${e(shortOS(v))}</td><td class="mono">${e(v.inventory_primary_ip||v.primary_ip||'—')}</td><td><div class="vm-agent-status-line">${badge(v.agent_status)}${version}</div><div class="muted">${e(v.agent_name||'Fără agent')}</div></td><td>${vmServiceNamesHTML(v.service_names)}</td><td>${v.outline_documentation_disabled?'<span class="badge disabled">NU</span>':'<span class="badge active">DA</span>'}</td><td>${v.outline_last_synced_at?dt(v.outline_last_synced_at):'—'}</td><td><div class="completion-cell"><strong>${completion}%</strong><div class="completion-progress"><i style="width:${completion}%"></i></div></div></td><td>${dt(v.inventory_received_at)}</td><td>${!v.present_in_vcenter&&can('vms.manage')?`<button class="small danger vm-delete-one" data-id="${v.id}">Șterge definitiv</button>`:'—'}</td></tr>`}).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||10),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  const cleanup=can('vms.manage')&&deletable.length?`<div class="vm-cleanup-toolbar"><label><input id="selectMissingVMs" type="checkbox"> Selectează VM-urile lipsă de pe această pagină</label><span class="muted">Ștergerea este permisă numai după ce VM-ul nu mai este prezent în vCenter.</span><button id="deleteSelectedVMs" class="danger" type="button" disabled>Șterge definitiv selectate</button></div>`:'';
  return `${cleanup}<div class="table-wrap vm-table-wrap"><table data-sortable="false" class="vm-global-sort-table"><thead><tr><th class="vm-select-col"></th><th data-vm-sort="name" tabindex="0" role="button" aria-label="Sortează global după VM" aria-sort="${vmSortAria('name')}">VM</th><th data-vm-sort="presence" tabindex="0" role="button" aria-label="Sortează global după vCenter" aria-sort="${vmSortAria('presence')}">vCenter</th><th data-vm-sort="power" tabindex="0" role="button" aria-label="Sortează global după Power" aria-sort="${vmSortAria('power')}">Power</th><th data-vm-sort="cpu" tabindex="0" role="button" aria-label="Sortează global după CPU / RAM" aria-sort="${vmSortAria('cpu')}">CPU / RAM</th><th data-vm-sort="os" tabindex="0" role="button" aria-label="Sortează global după OS" aria-sort="${vmSortAria('os')}">OS</th><th data-vm-sort="ip" tabindex="0" role="button" aria-label="Sortează global după IP" aria-sort="${vmSortAria('ip')}">IP</th><th data-vm-sort="agent" tabindex="0" role="button" aria-label="Sortează global după Agent" aria-sort="${vmSortAria('agent')}">Agent</th><th data-vm-sort="services" tabindex="0" role="button" aria-label="Sortează global după Servicii" aria-sort="${vmSortAria('services')}">Servicii</th><th data-vm-sort="publication" tabindex="0" role="button" aria-label="Sortează global după Publicare" aria-sort="${vmSortAria('publication')}">Publicare</th><th data-vm-sort="outline_date" tabindex="0" role="button" aria-label="Sortează global după Outline" aria-sort="${vmSortAria('outline_date')}">Outline</th><th data-vm-sort="completion" tabindex="0" role="button" aria-label="Sortează global după Completare" aria-sort="${vmSortAria('completion')}">Completare</th><th data-vm-sort="inventory_date" tabindex="0" role="button" aria-label="Sortează global după Ultimul JSON" aria-sort="${vmSortAria('inventory_date')}">Ultimul JSON</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons">${paginationButtons(page,Number(result.pages||1))}</div></div>`;
}

function paginationButtons(page,pages,buttonClass='vm-page'){
  if(pages<=1)return '';
  const values=new Set([1,pages,page-2,page-1,page,page+1,page+2]);const valid=[...values].filter(n=>n>=1&&n<=pages).sort((a,b)=>a-b);let previous=0,html=`<button class="small secondary ${buttonClass}" data-page="${page-1}" ${page<=1?'disabled':''}>Anterior</button>`;
  valid.forEach(n=>{if(previous&&n>previous+1)html+='<span class="pagination-gap">…</span>';html+=`<button class="small ${n===page?'':'secondary'} ${buttonClass}" data-page="${n}" ${n===page?'disabled':''}>${n}</button>`;previous=n});
  return html+`<button class="small secondary ${buttonClass}" data-page="${page+1}" ${page>=pages?'disabled':''}>Următor</button>`;
}
function pageSizeOptions(selected,values=[10,20,50,100]){return values.map(value=>`<option value="${value}" ${Number(selected)===value?'selected':''}>${value}</option>`).join('')}

function nomenclaturePageInfo(code,total){
  const stored=Number(localStorage.getItem(`vm-doc:nomenclature-page-size:${code}`)||0);
  const current=state.nomenclaturePaging[code]||{page:1,pageSize:[10,20,50,100,200].includes(stored)?stored:10};
  current.pageSize=[10,20,50,100,200].includes(Number(current.pageSize))?Number(current.pageSize):10;
  const pages=Math.max(1,Math.ceil(total/current.pageSize));
  current.page=Math.min(Math.max(1,Number(current.page)||1),pages);
  state.nomenclaturePaging[code]=current;
  const offset=(current.page-1)*current.pageSize;
  return {page:current.page,pageSize:current.pageSize,pages,total,offset,end:Math.min(offset+current.pageSize,total)};
}
function nomenclaturePagination(code,info){
  if(!info.total)return '';
  const start=info.offset+1;
  return `<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${info.end.toLocaleString('ro-RO')} din ${info.total.toLocaleString('ro-RO')}</span><div class="pagination-buttons">${paginationButtons(info.page,info.pages,'nomenclature-page')}</div></div>`;
}

function openVCenter(source=null){
  document.getElementById('vcenterDialogTitle').textContent=source?'Editare sursă vCenter':'Sursă vCenter nouă';document.getElementById('vcenterId').value=source?.id||'';document.getElementById('vcenterName').value=source?.name||'';document.getElementById('vcenterURL').value=source?.base_url||'';document.getElementById('vcenterUsername').value=source?.username||'';document.getElementById('vcenterPassword').value='';document.getElementById('vcenterPassword').required=!source;document.getElementById('vcenterSyncTime').value=source?.daily_sync_time||'05:00';document.getElementById('vcenterTLSServerName').value=source?.tls_server_name||'';document.getElementById('vcenterEnabled').checked=source?.enabled??true;document.getElementById('vcenterVerifyTLS').checked=source?.verify_tls??true;document.getElementById('vcenterDailySync').checked=source?.daily_sync_enabled??true;vcenterDialog.showModal();
}

// Use MoRef/parent MoRef from vCenter; names alone are not unique across clusters.
function vcenterPoolTree(pools){
  const byId=new Map(pools.map(x=>[String(x.resource_pool_moid),x]));
  const children=new Map(pools.map(x=>[String(x.resource_pool_moid),[]]));
  const roots=[];
  for(const pool of pools){
    const id=String(pool.resource_pool_moid),parent=String(pool.parent_resource_pool_moid||'');
    if(parent && parent!==id && byId.has(parent))children.get(parent).push(pool);
    else roots.push(pool);
  }
  const compare=(a,b)=>String(a.name||'').localeCompare(String(b.name||''),'ro')||String(a.resource_pool_moid).localeCompare(String(b.resource_pool_moid));
  roots.sort(compare);children.forEach(nodes=>nodes.sort(compare));
  const flat=[],seen=new Set();
  function walk(pool,level){
    const id=String(pool.resource_pool_moid);
    if(seen.has(id))return;
    seen.add(id);flat.push({pool,level,childCount:(children.get(id)||[]).length});
    for(const child of children.get(id)||[])walk(child,level+1);
  }
  roots.forEach(x=>walk(x,0));
  // Malformed/cyclic legacy data must remain accessible, never disappear.
  pools.filter(x=>!seen.has(String(x.resource_pool_moid))).sort(compare).forEach(x=>walk(x,0));
  return {flat,children};
}

async function openVCenterPools(sourceId,source){
  let dlg=document.getElementById('vcenterPoolDialog');
  if(!dlg){
    dlg=document.createElement('dialog');dlg.id='vcenterPoolDialog';dlg.className='vc-pool-dialog';
    dlg.innerHTML=`<div class="vc-pool-shell"><div class="dialog-title vc-pool-heading"><div><h2>Resource pool-uri vCenter</h2><p class="muted" id="vcPoolIntro"></p></div><button type="button" class="icon-button" id="vcPoolClose" aria-label="Închide">×</button></div><div class="vc-pool-summary" id="vcPoolSummary" aria-live="polite"></div><div class="vc-pool-tree-head"><span>Resource pool / Se importă</span><span>VM-uri</span><span>Power ON</span></div><div id="vcPoolTable" class="vc-pool-tree" role="tree" aria-label="Resource pool-uri vCenter"></div><div id="vcPoolNotice" class="vc-pool-notice" role="status" aria-live="polite"></div><div class="vc-pool-footer"><div class="vc-pool-tools"><button type="button" class="secondary" id="vcPoolScan">Descoperă / actualizează</button><button type="button" class="secondary" id="vcPoolAll">Bifează toate</button><button type="button" class="secondary" id="vcPoolNone">Debifează toate</button></div><button type="button" id="vcPoolSave">Salvează selecția</button></div></div>`;
    document.body.appendChild(dlg);dlg.querySelector('#vcPoolClose').onclick=()=>dlg.close();
  }
  dlg.querySelector('h2').textContent=`Resource pool-uri · ${source?.name||sourceId}`;
  dlg.querySelector('#vcPoolIntro').textContent='Bifate = importate în VM-DOC. Bifarea unui părinte selectează și copiii; fiecare pool poate fi ajustat separat. Numerele sunt pentru VM-urile alocate direct fiecărui pool.';
  const table=dlg.querySelector('#vcPoolTable'),notice=dlg.querySelector('#vcPoolNotice'),summary=dlg.querySelector('#vcPoolSummary');
  let pools=[],collapsed=new Set(),loading=false;
  const warnings=()=>{
    const excluded=pools.filter(x=>!x.include_in_docs&&x.present_in_vcenter);
    const powered=excluded.reduce((n,x)=>n+Number(x.powered_on_count||0),0);
    const count=excluded.reduce((n,x)=>n+Number(x.vm_count||0),0);
    const active=pools.filter(x=>x.present_in_vcenter).length;
    summary.innerHTML=`<span><strong>${active-excluded.length}</strong> din ${active} pool-uri incluse</span><span><strong>${count}</strong> VM-uri excluse</span><span class="${powered?'vc-pool-danger':''}"><strong>${powered}</strong> VM-uri pornite în pool-uri excluse</span>`;
    notice.classList.toggle('vc-pool-warning',powered>0);
    notice.textContent=powered?`⚠ ${powered} VM-uri POWERED_ON sunt în ${excluded.filter(x=>Number(x.powered_on_count||0)>0).length} pool-uri nebifate. Acest lucru va fi semnalat și în Audit după sincronizare.`:excluded.length?`${count} VM-uri sunt în ${excluded.length} pool-uri excluse. Salvarea păstrează datele istorice.`:'';
  };
  const render=()=>{
    const {flat,children}=vcenterPoolTree(pools);
    const hidden=new Set();
    // Collapsing only changes the tree display, never the saved selection.
    for(const {pool} of flat){
      const id=String(pool.resource_pool_moid);
      if(hidden.has(String(pool.parent_resource_pool_moid||'')))hidden.add(id);
      if(collapsed.has(String(pool.parent_resource_pool_moid||'')))hidden.add(id);
    }
    table.innerHTML=pools.length?flat.filter(x=>!hidden.has(String(x.pool.resource_pool_moid))).map(({pool:x,level,childCount})=>{
      const id=String(x.resource_pool_moid),isOn=Number(x.powered_on_count||0)>0,warning=!x.include_in_docs&&isOn;
      return `<div class="vc-pool-node ${!x.include_in_docs?'vc-pool-excluded':''}" role="treeitem" aria-level="${level+1}" ${childCount?`aria-expanded="${!collapsed.has(id)}"`:''} data-pool="${e(id)}"><div class="vc-pool-main" style="--vc-tree-depth:${Math.min(level,12)}">${childCount?`<button type="button" class="vc-pool-expand" data-toggle="${e(id)}" aria-label="${collapsed.has(id)?'Extinde':'Restrânge'} ${e(x.name)}" aria-expanded="${!collapsed.has(id)}">${collapsed.has(id)?'▸':'▾'}</button>`:'<span class="vc-pool-expand-placeholder" aria-hidden="true"></span>'}<input type="checkbox" class="vc-pool-select" aria-label="Importă pool-ul ${e(x.name)}" data-pool-select="${e(id)}" ${x.include_in_docs?'checked':''} ${!x.present_in_vcenter?'disabled':''}><span class="vc-pool-icon" aria-hidden="true">${childCount?'▣':'▤'}</span><span class="vc-pool-name"><strong>${e(x.name)}</strong><small class="muted mono">${e(id)}${!x.present_in_vcenter?' · absent în vCenter':''}</small></span></div><span class="vc-pool-number">${Number(x.vm_count||0)}</span><span class="vc-pool-number ${warning?'vc-pool-danger':''}">${isOn?`${Number(x.powered_on_count)} ON`:'0'}</span></div>`;
    }).join(''):'<div class="vc-pool-empty">Nu există pool-uri salvate. Folosește „Descoperă / actualizează”.</div>';
    table.querySelectorAll('[data-toggle]').forEach(el=>el.onclick=()=>{const id=el.dataset.toggle;collapsed.has(id)?collapsed.delete(id):collapsed.add(id);render()});
    table.querySelectorAll('[data-pool-select]').forEach(el=>el.onchange=()=>{
      const id=el.dataset.poolSelect,value=el.checked,byId=new Map(pools.map(x=>[String(x.resource_pool_moid),x]));
      const visit=(key,seen=new Set())=>{if(seen.has(key))return;seen.add(key);const pool=byId.get(key);if(pool?.present_in_vcenter)pool.include_in_docs=value;for(const child of children.get(key)||[])visit(String(child.resource_pool_moid),seen)};
      visit(id);render();
    });
    warnings();
  };
  const load=async()=>{pools=await api(`/api/v1/vcenter/sources/${sourceId}/pools`);collapsed.clear();render()};
  dlg.querySelector('#vcPoolAll').onclick=()=>{pools.forEach(x=>{if(x.present_in_vcenter)x.include_in_docs=true});render()};
  dlg.querySelector('#vcPoolNone').onclick=()=>{pools.forEach(x=>{if(x.present_in_vcenter)x.include_in_docs=false});render()};
  dlg.querySelector('#vcPoolScan').onclick=async()=>{if(loading)return;loading=true;const b=dlg.querySelector('#vcPoolScan');b.disabled=true;notice.textContent='Se citesc ierarhia pool-urilor și VM-urile din vCenter…';try{pools=await api(`/api/v1/vcenter/sources/${sourceId}/pools/scan`,{method:'POST'});collapsed.clear();render();toast('Arborele pool-urilor a fost actualizat.')}catch(err){notice.textContent=err.message}finally{loading=false;b.disabled=false}};
  dlg.querySelector('#vcPoolSave').onclick=async()=>{
    const visible=pools.filter(x=>x.present_in_vcenter),on=visible.filter(x=>!x.include_in_docs).reduce((n,x)=>n+Number(x.powered_on_count||0),0);
    if(on&&!confirm(`Atenție: excluzi ${on} VM-uri PORNITE. Continui?`))return;
    const b=dlg.querySelector('#vcPoolSave');b.disabled=true;
    try{await api(`/api/v1/vcenter/sources/${sourceId}/pools`,{method:'PUT',body:JSON.stringify({pools:visible.map(x=>({resource_pool_moid:x.resource_pool_moid,include_in_docs:x.include_in_docs}))})});dlg.close();toast('Selecția a fost salvată și auditată. Sincronizează pentru a verifica VM-urile pornite din pool-urile excluse.');vmsPage('sources')}catch(err){notice.textContent=err.message}finally{b.disabled=false}
  };
  dlg.showModal();try{await load()}catch(err){notice.textContent=err.message}
}
async function vcenterAction(action,id){
  const source=state.sources.find(s=>s.id===id);
  try{
    if(action==='pools'){await openVCenterPools(id,source);return}
    if(action==='edit'){openVCenter(source);return}
    if(action==='delete'){if(!confirm(`Ștergi sursa ${source.name} și VM-urile sincronizate din ea?`))return;await api(`/api/v1/vcenter/sources/${id}`,{method:'DELETE'});toast('Sursă vCenter ștearsă.');vmsPage('sources');return}
    if(action==='test'){const r=await api(`/api/v1/vcenter/sources/${id}/test`,{method:'POST'});toast(`Conexiune reușită: ${r.vm_count} VM-uri vizibile.`);return}
    if(action==='sync'){const r=await api(`/api/v1/vcenter/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea ${r.id} a fost pornită.`);setTimeout(()=>vmsPage('sources'),1200)}
  }catch(err){toast(err.message,true)}
}
vcenterForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('vcenterId').value||0);const body={name:document.getElementById('vcenterName').value.trim(),base_url:document.getElementById('vcenterURL').value.trim(),username:document.getElementById('vcenterUsername').value.trim(),password:document.getElementById('vcenterPassword').value,enabled:document.getElementById('vcenterEnabled').checked,verify_tls:document.getElementById('vcenterVerifyTLS').checked,tls_server_name:document.getElementById('vcenterTLSServerName').value.trim(),daily_sync_enabled:document.getElementById('vcenterDailySync').checked,daily_sync_time:document.getElementById('vcenterSyncTime').value};if(id&&!body.password)delete body.password;
  try{await api(id?`/api/v1/vcenter/sources/${id}`:'/api/v1/vcenter/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});vcenterDialog.close();toast(id?'Sursă actualizată.':'Sursă creată.');vmsPage('sources')}catch(err){toast(err.message,true)}
});


function veeamIntervalLabel(minutes){
  const value=Number(minutes||0);if(!value)return 'Manual';if(value%1440===0)return `La ${value/1440} ${value===1440?'zi':'zile'}`;if(value%60===0)return `La ${value/60} ${value===60?'oră':'ore'}`;return `La ${value} minute`;
}
function openVeeam(source=null){
  document.getElementById('veeamDialogTitle').textContent=source?'Editare sursă Veeam':'Sursă Veeam nouă';document.getElementById('veeamId').value=source?.id||'';document.getElementById('veeamName').value=source?.name||'';document.getElementById('veeamURL').value=source?.base_url||'';document.getElementById('veeamUsername').value=source?.username||'';document.getElementById('veeamPassword').value='';document.getElementById('veeamPassword').required=!source;document.getElementById('veeamAPIVersion').value=source?.api_version||'1.1-rev1';document.getElementById('veeamSyncInterval').value=source?.sync_interval_minutes||1440;document.getElementById('veeamTLSServerName').value=source?.tls_server_name||'';document.getElementById('veeamEnabled').checked=source?.enabled??true;document.getElementById('veeamVerifyTLS').checked=source?.verify_tls??true;veeamDialog.showModal();
}
async function veeamAction(action,id){
  const source=state.veeamSources.find(s=>Number(s.id)===Number(id));
  try{
    if(action==='edit'){openVeeam(source);return}
    if(action==='delete'){if(!confirm(`Ștergi sursa Veeam ${source?.name||id}? Datele Veeam colectate de la această sursă vor fi eliminate din fișele VM.`))return;await api(`/api/v1/veeam/sources/${id}`,{method:'DELETE'});toast('Sursa Veeam a fost ștearsă.');backupPage('sources');return}
    if(action==='test'){const r=await api(`/api/v1/veeam/sources/${id}/test`,{method:'POST'});toast(`Conectare reușită: ${r.server_name||source?.name||'Veeam'} · ${r.build_version||'versiune necunoscută'} · ${Number(r.backup_objects||0)} obiecte backup.`);return}
    if(action==='sync'){const r=await api(`/api/v1/veeam/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea Veeam ${r.id} a fost pornită.`);[1200,3500,7000].forEach(delay=>setTimeout(()=>{if((location.hash||'').startsWith('#backup'))backupPage('sources')},delay))}
  }catch(err){toast(err.message,true)}
}
function renderVeeamRuns(result){
  const items=Array.isArray(result?.items)?result.items:[],paging=state.veeamRunPaging;paging.page=Number(result?.page||1);paging.pageSize=Number(result?.page_size||paging.pageSize||10);
  const rows=items.map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.veeam_source_name||'—')}</td><td>${badge(r.status)}</td><td>${Number(r.backup_object_count||0)}</td><td>${Number(r.matched_vm_count||0)}</td><td>${Number(r.protected_vm_count||0)}</td><td>${Number(r.unprotected_vm_count||0)}</td><td>${Number(r.ambiguous_count||0)}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');
  const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total),pager=total?`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="veeamRunPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result?.pages||1),'veeam-run-page')}</div></div>`:'';
  return rows?`<div class="table-wrap"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Obiecte</th><th>VM corelate</th><th>Protejate</th><th>Neprotejate</th><th>Neasociate / ambigue</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>${pager}`:empty('Nu există sincronizări Veeam.');
}
function veeamStateBadge(value){
  switch(String(value||'')){
    case 'protected':return '<span class="badge protected">Protejată</span>';
    case 'waiting':return '<span class="badge waiting">Așteaptă primul backup</span>';
    case 'job_disabled':return '<span class="badge job-disabled">Job dezactivat · fără backup</span>';
    case 'stale':return '<span class="badge stale">Backup existent · în afara jobului</span>';
    case 'unprotected':return '<span class="badge unprotected">Neprotejată</span>';
    default:return '<span class="muted">Neverificată</span>';
  }
}
function veeamStateText(value){
  return {protected:'Protejată · restore point disponibil',waiting:'În job · așteaptă primul backup',job_disabled:'În job · job dezactivat · fără restore point',stale:'Backup existent · nu mai este în job',unprotected:'Neprotejată · nu este în job',never:'Neverificată'}[String(value||'')]||'—';
}
function veeamVMQuery(){
  const f=state.veeamVMFilters,p=new URLSearchParams();if(f.q)p.set('q',f.q);if(f.status)p.set('status',f.status);if(f.power)p.set('power',f.power);if(f.environment)p.set('environment',f.environment);if(f.result)p.set('result',f.result);p.set('page',String(f.page));p.set('page_size',String(f.pageSize));return p.toString();
}
function renderVeeamVMs(result){
  const f=state.veeamVMFilters,items=Array.isArray(result?.items)?result.items:[];f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
  const filters=`<div class="filterbar veeam-filterbar"><label class="veeam-search-field"><span>Caută</span><input id="veeamVMSearch" type="search" value="${e(f.q)}" placeholder="VM, job, storage, sursă sau power state"></label><label><span>Stare backup</span><select id="veeamVMStatus"><option value="" ${!f.status?'selected':''}>Toate</option><option value="protected" ${f.status==='protected'?'selected':''}>Protejate</option><option value="configured" ${f.status==='configured'?'selected':''}>În job Veeam</option><option value="waiting" ${f.status==='waiting'?'selected':''}>Așteaptă primul backup</option><option value="stale" ${f.status==='stale'?'selected':''}>Backup existent, în afara jobului</option><option value="unprotected" ${f.status==='unprotected'?'selected':''}>Neprotejate</option><option value="never" ${f.status==='never'?'selected':''}>Neverificate</option></select></label><label><span>Power state</span><select id="veeamVMPower"><option value="" ${!f.power?'selected':''}>Toate</option><option value="POWERED_ON" ${f.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${f.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${f.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label><label><span>Mediu</span><select id="veeamVMEnvironment">${environmentFilterOptions(f.environment)}</select></label><label><span>Rezultat backup</span><select id="veeamVMResult"><option value="" ${!f.result?'selected':''}>Toate</option><option value="success" ${f.result==='success'?'selected':''}>Success</option><option value="warning" ${f.result==='warning'?'selected':''}>Warning</option><option value="failed" ${f.result==='failed'?'selected':''}>Failed</option><option value="none" ${f.result==='none'?'selected':''}>Fără rezultat</option></select></label><button id="clearVeeamVMFilters" type="button" class="secondary">Resetează</button></div>`;
  const rows=items.map(v=>{const protection=`${veeamStateBadge(v.veeam_state)}${v.cron_backup_enabled&&!v.protected?'<div class="muted">+ backup cron declarat</div>':''}`;const inJob=v.veeam_in_job?(v.veeam_job_enabled?'<span class="badge configured">Da</span>':'<span class="badge job-disabled">Da · dezactivat</span>'):'<span class="muted">Nu</span>';const storage=[v.primary_repository_name||v.repository_name,v.secondary_repository_names?`Secundar: ${v.secondary_repository_names}`:''].filter(Boolean).map((x,i)=>i?`<div class="muted">${e(x)}</div>`:e(x)).join('');return `<tr><td><a href="#vms/${v.vm_id}/backup"><strong>${e(v.vm_name)}</strong></a><div class="muted">${e(v.source_name||'—')}</div></td><td>${v.power_state?badge(v.power_state):'—'}</td><td>${protection}</td><td>${inJob}</td><td>${v.last_result?badge(v.last_result):'—'}</td><td>${e(v.job_name||'—')}</td><td>${storage||'—'}</td><td>${e(v.schedule_text||v.cron_backup_schedule||'—')}</td><td>${v.restore_points??'—'}</td><td>${dt(v.last_backup_at)}</td><td>${dt(v.next_run_at)}</td><td>${dt(v.synced_at)}</td><td class="error-text">${e(v.error_message||'—')}</td></tr>`}).join('');
  const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total),pager=total?`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="veeamVMPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result?.pages||1),'veeam-vm-page')}</div></div>`:'';
  return `${filters}${rows?`<div class="table-wrap veeam-vm-table"><table><thead><tr><th>VM / sursă</th><th>Power state</th><th>Stare Veeam</th><th>În job</th><th>Rezultat</th><th>Job</th><th>Storage</th><th>Programare</th><th>Restore points</th><th>Ultimul backup</th><th>Next run</th><th>Sync vm-doc</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există VM-uri pentru filtrele selectate.')}${pager}`;
}
function updateVeeamSummaryCards(result){
  const total=Number(result?.total||0),protectedCount=Number(result?.protected_count||0),configured=Number(result?.configured_count||0),waiting=Number(result?.waiting_count||0),stale=Number(result?.stale_count||0),unprotected=Number(result?.unprotected_count||0),never=Number(result?.never_synchronized_count||0),failed=Number(result?.failed_count||0),warning=Number(result?.warning_count||0),pct=v=>total?`${(Number(v)*100/total).toFixed(1)}%`:'0%';
  const set=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=value};set('backupTotal',total);set('backupProtected',protectedCount);set('backupProtectedPct',pct(protectedCount));set('backupConfigured',configured);set('backupConfiguredPct',pct(configured));set('backupWaiting',waiting);set('backupWaitingPct',pct(waiting));set('backupUnprotected',unprotected);set('backupUnprotectedPct',pct(unprotected));set('backupStale',stale);set('backupStalePct',pct(stale));set('backupNever',never);set('backupNeverPct',pct(never));set('backupFailedWarning',`${failed} / ${warning}`);
}

async function loadVeeamVMs(focusPosition=null){
  const area=document.getElementById('veeamVMTableArea');if(!area)return;area.classList.add('is-loading');
  try{const result=await api(`/api/v1/veeam/vms?${veeamVMQuery()}`);updateVeeamSummaryCards(result);area.innerHTML=renderVeeamVMs(result);bindVeeamVMControls();updateBackupExportLink();if(focusPosition!==null){const input=document.getElementById('veeamVMSearch');if(input){input.focus();const pos=Math.min(Number(focusPosition)||0,input.value.length);input.setSelectionRange(pos,pos)}}}catch(err){toast(err.message,true)}finally{area.classList.remove('is-loading')}
}
function bindVeeamVMControls(){
  const search=document.getElementById('veeamVMSearch');let timer;search?.addEventListener('input',event=>{clearTimeout(timer);const input=event.currentTarget,value=input.value,pos=input.selectionStart??value.length;timer=setTimeout(()=>{state.veeamVMFilters.q=value.trim();state.veeamVMFilters.page=1;loadVeeamVMs(pos)},300)});
  const bindSelect=(id,key)=>document.getElementById(id)?.addEventListener('change',event=>{state.veeamVMFilters[key]=event.target.value;state.veeamVMFilters.page=1;loadVeeamVMs()});bindSelect('veeamVMStatus','status');bindSelect('veeamVMPower','power');bindSelect('veeamVMEnvironment','environment');bindSelect('veeamVMResult','result');
  document.getElementById('clearVeeamVMFilters')?.addEventListener('click',()=>{state.veeamVMFilters={q:'',status:'',power:'POWERED_ON',environment:'PROD',result:'',page:1,pageSize:10};loadVeeamVMs(0)});document.querySelectorAll('.veeam-vm-page').forEach(b=>b.addEventListener('click',()=>{const page=Number(b.dataset.page);if(page>0&&page!==state.veeamVMFilters.page){state.veeamVMFilters.page=page;loadVeeamVMs()}}));document.getElementById('veeamVMPageSize')?.addEventListener('change',event=>{state.veeamVMFilters.pageSize=Number(event.target.value);state.veeamVMFilters.page=1;loadVeeamVMs()});
}




veeamForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('veeamId').value||0);const body={name:document.getElementById('veeamName').value.trim(),base_url:document.getElementById('veeamURL').value.trim(),username:document.getElementById('veeamUsername').value.trim(),password:document.getElementById('veeamPassword').value,api_version:document.getElementById('veeamAPIVersion').value.trim(),sync_interval_minutes:Number(document.getElementById('veeamSyncInterval').value),enabled:document.getElementById('veeamEnabled').checked,verify_tls:document.getElementById('veeamVerifyTLS').checked,tls_server_name:document.getElementById('veeamTLSServerName').value.trim()};if(id&&!body.password)delete body.password;
  try{await api(id?`/api/v1/veeam/sources/${id}`:'/api/v1/veeam/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});veeamDialog.close();toast(id?'Sursa Veeam a fost actualizată.':'Sursa Veeam a fost creată.');backupPage('sources')}catch(err){toast(err.message,true)}
});


function monitoringCurrentSection(){
  const parts=(location.hash||'#monitoring/overview').slice(1).split('/');
  return parts[0]==='monitoring'&&parts[1]==='sources'?'sources':'overview';
}
function monitoringSectionNavigation(selected){
  const items=[['overview','Stare monitorizare','VM-uri, targeturi și corelare'],['sources','Surse & sincronizări','Prometheus, Blackbox și istoric']];
  return `<nav class="monitoring-section-tabs" aria-label="Secțiuni monitorizare">${items.map(([code,label,help])=>`<a href="#monitoring/${code}" class="${selected===code?'active':''}"><span>${e(label)}</span><small>${e(help)}</small></a>`).join('')}</nav>`;
}
function openPrometheus(source=null){
  document.getElementById('prometheusDialogTitle').textContent=source?'Editare sursă Prometheus':'Sursă Prometheus nouă';
  document.getElementById('prometheusId').value=source?.id||'';
  document.getElementById('prometheusName').value=source?.name||'';
  document.getElementById('prometheusType').value=source?.source_type||'metrics';
  document.getElementById('prometheusURL').value=source?.base_url||'';
  const agentSelect=document.getElementById('prometheusAgent'),agentOptions=Array.isArray(state.prometheusAgentOptions)?state.prometheusAgentOptions:[];
  agentSelect.innerHTML='<option value="">— Fără agent asociat —</option>'+agentOptions.map(a=>`<option value="${a.id}" ${Number(source?.agent_id||0)===Number(a.id)?'selected':''}>${e(a.name)}${a.agent_version?` · ${e(a.agent_version)}`:''}${a.enabled?'':' · inactiv'}</option>`).join('');
  document.getElementById('prometheusAuthMode').value=source?.auth_mode||'none';
  document.getElementById('prometheusUsername').value=source?.username||'';
  document.getElementById('prometheusSecret').value='';
  document.getElementById('prometheusVMLabel').value=source?.vm_label||'vm_fqdn';
  document.getElementById('prometheusTargetLabel').value=source?.target_label||'instance';
  document.getElementById('prometheusSyncInterval').value=source?.sync_interval_minutes||15;
  document.getElementById('prometheusTLSServerName').value=source?.tls_server_name||'';
  document.getElementById('prometheusEnabled').checked=source?.enabled??true;
  document.getElementById('prometheusVerifyTLS').checked=source?.verify_tls??true;
  prometheusDialog.showModal();
}
async function prometheusAction(action,id){
  const source=state.prometheusSources.find(s=>Number(s.id)===Number(id));
  try{
    if(action==='edit'){openPrometheus(source);return}
    if(action==='delete'){
      if(!confirm(`Ștergi sursa ${source?.name||id} și targeturile sincronizate din ea?`))return;
      await api(`/api/v1/monitoring/sources/${id}`,{method:'DELETE'});toast('Sursa Prometheus a fost ștearsă.');monitoringPage('sources');return;
    }
    if(action==='test'){
      const r=await api(`/api/v1/monitoring/sources/${id}/test`,{method:'POST'});
      toast(`Prometheus OK · ${r.version||'versiune necunoscută'} · ${Number(r.target_count||0)} targeturi active${r.agent_associated?` · agent ${r.agent_name||''} · hosts ${r.hosts_available?Number(r.hosts_entry_count||0)+' intrări':'indisponibil'}`:' · fără agent asociat'}.`);return;
    }
    if(action==='sync'){
      const r=await api(`/api/v1/monitoring/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea ${r.id} a fost pornită.`);
      [1000,3000,6000].forEach(delay=>setTimeout(()=>{if((location.hash||'').startsWith('#monitoring'))monitoringPage(monitoringCurrentSection())},delay));
    }
  }catch(err){toast(err.message,true)}
}
function monitoringVMQuery(){const f=state.monitoringVMFilters,p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize)});if(f.q)p.set('q',f.q);if(f.state)p.set('state',f.state);if(f.power)p.set('power',f.power);if(f.environment)p.set('environment',f.environment);return p.toString()}
function monitoringTargetQuery(){const f=state.monitoringTargetFilters,p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize)});if(f.q)p.set('q',f.q);if(f.sourceType)p.set('source_type',f.sourceType);if(f.health)p.set('health',f.health);if(f.matched)p.set('matched',f.matched);return p.toString()}
function pct(value,total){return total?`${Math.round(Number(value||0)*100/total)}%`:'0%'}
function monitoringStateBadge(value){const labels={monitored:'Monitorizată',down:'Target DOWN',exporter_only:'Exporter fără target',exporter_stopped:'Exporter oprit',unmonitored:'Nemontorizată'};return `<span class="badge monitoring-${e(value||'unknown')}">${e(labels[value]||value||'—')}</span>`}
function renderMonitoringVMs(result){
  const f=state.monitoringVMFilters;f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
  const filters=`<div class="filterbar monitoring-filterbar"><label class="monitoring-search-field"><span>Caută</span><input id="monitoringVMSearch" type="search" value="${e(f.q)}" placeholder="VM, job, target, sursă sau exporter"></label><label><span>Stare</span><select id="monitoringVMState"><option value="" ${!f.state?'selected':''}>Toate</option><option value="monitored" ${f.state==='monitored'?'selected':''}>Monitorizate</option><option value="up" ${f.state==='up'?'selected':''}>Target UP</option><option value="down" ${f.state==='down'?'selected':''}>Target DOWN</option><option value="exporter_only" ${f.state==='exporter_only'?'selected':''}>Exporter fără target</option><option value="unmonitored" ${f.state==='unmonitored'?'selected':''}>Fără Prometheus</option><option value="no_exporter" ${f.state==='no_exporter'?'selected':''}>Fără Node Exporter</option></select></label><label><span>Power</span><select id="monitoringVMPower"><option value="" ${!f.power?'selected':''}>Toate</option><option value="POWERED_ON" ${f.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${f.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${f.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label><label><span>Mediu</span><select id="monitoringVMEnvironment">${environmentFilterOptions(f.environment)}</select></label><button id="clearMonitoringVMFilters" class="secondary monitoring-reset-filter" type="button">Resetează</button></div>`;
  const items=Array.isArray(result?.items)?result.items:[],rows=items.map(v=>`<tr><td><a href="#vms/${v.vm_id}/monitoring"><strong>${e(v.vm_name)}</strong></a></td><td>${powerShortBadge(v.power_state)}</td><td>${v.exporter_installed?(v.exporter_running?badge('running'):badge('stopped')):badge('absent')}<div class="muted">${e(v.exporter_version||'')}${v.exporter_endpoint?` · ${e(v.exporter_endpoint)}`:''}</div></td><td>${monitoringStateBadge(v.monitoring_state)}</td><td>${v.metrics_monitored?(v.metrics_up?badge('up'):badge('down')):'—'}<div class="muted">${e(v.metrics_source||'')} ${e(v.metrics_job||'')}</div></td><td class="mono">${e(v.metrics_target||'—')}</td><td>${e(v.metrics_match||'—')}</td><td>${v.blackbox_monitored?(v.blackbox_up?badge('up'):badge('down')):'—'}<div class="muted">${Number(v.blackbox_targets||0)} probe</div></td></tr>`).join('');
  const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total),pager=`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="monitoringVMPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result?.pages||1),'monitoring-vm-page')}</div></div>`;
  return `${filters}${rows?`<div class="table-wrap monitoring-vm-table"><table><thead><tr><th>VM</th><th>Power</th><th>Node Exporter</th><th>Stare</th><th>Prometheus</th><th>Target</th><th>Corelare</th><th>Blackbox</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există VM-uri pentru filtrele selectate.')}${pager}`;
}
function updateMonitoringCards(r){const total=Number(r.total||0),set=(id,v)=>{const n=document.getElementById(id);if(n)n.textContent=v};set('monTotal',total);set('monExporter',Number(r.exporter_running_count||0));set('monExporterPct',pct(r.exporter_running_count,total));set('monMetrics',Number(r.metrics_monitored_count||0));set('monMetricsPct',pct(r.metrics_monitored_count,total));set('monUp',Number(r.metrics_up_count||0));set('monDown',Number(r.metrics_down_count||0));set('monBlackbox',Number(r.blackbox_monitored_count||0));set('monBlackboxPct',pct(r.blackbox_monitored_count,total))}
function renderMonitoringTargets(result){
  const f=state.monitoringTargetFilters;f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
  const filters=`<div class="filterbar monitoring-target-filterbar"><label class="monitoring-search-field"><span>Caută target</span><input id="monitoringTargetSearch" type="search" value="${e(f.q)}" placeholder="instance, URL, job, VM"></label><label><span>Tip</span><select id="monitoringTargetType"><option value="" ${!f.sourceType?'selected':''}>Toate</option><option value="metrics" ${f.sourceType==='metrics'?'selected':''}>Metrics</option><option value="blackbox" ${f.sourceType==='blackbox'?'selected':''}>Blackbox</option></select></label><label><span>Health</span><select id="monitoringTargetHealth"><option value="" ${!f.health?'selected':''}>Toate</option><option value="up" ${f.health==='up'?'selected':''}>UP</option><option value="down" ${f.health==='down'?'selected':''}>DOWN</option></select></label><label><span>Corelare VM</span><select id="monitoringTargetMatched"><option value="" ${!f.matched?'selected':''}>Toate</option><option value="yes" ${f.matched==='yes'?'selected':''}>Corelate</option><option value="no" ${f.matched==='no'?'selected':''}>Necorelate</option></select></label><button id="clearMonitoringTargetFilters" class="secondary monitoring-reset-filter" type="button">Resetează</button></div>`;
  const items=Array.isArray(result?.items)?result.items:[],rows=items.map(t=>`<tr><td>${badge(t.source_type)}</td><td><strong>${e(t.prometheus_source_name)}</strong><div class="muted">${e(t.job_name||'—')}</div></td><td class="mono">${e(t.target_url||t.instance||'—')}</td><td>${targetVisualStatus(t)}</td><td>${t.http_status_code??'—'}</td><td>${t.probe_duration_seconds!=null?`${(Number(t.probe_duration_seconds)*1000).toFixed(0)} ms`:'—'}</td><td>${t.tls_expiry_at?dt(t.tls_expiry_at):'—'}</td><td>${t.matched_vm_id?`<a href="#vms/${t.matched_vm_id}/monitoring">${e(t.matched_vm_name)}</a>`:'<span class="muted">Necorelat</span>'}<div class="muted">${e(t.match_method||'')}${t.match_value?` · <span class="mono">${e(t.match_value)}</span>`:''}</div></td><td class="error-text">${e(t.last_error||'—')}</td></tr>`).join('');
  const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total);
  return `${filters}<div class="target-summary-line"><span>UP <strong>${Number(result.up_count||0)}</strong></span><span>DOWN <strong>${Number(result.down_count||0)}</strong></span><span>Corelate <strong>${Number(result.matched_count||0)}</strong></span><span>Necorelate <strong>${Number(result.unmatched_count||0)}</strong></span></div>${rows?`<div class="table-wrap monitoring-target-table"><table><thead><tr><th>Tip</th><th>Sursă / job</th><th>Target</th><th>Stare</th><th>HTTP</th><th>Durată</th><th>TLS expiră</th><th>VM / corelare</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există targeturi pentru filtrele selectate.')}<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="monitoringTargetPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result?.pages||1),'monitoring-target-page')}</div></div>`;
}
function targetVisualStatus(t){if(t.probe_success!==undefined&&t.probe_success!==null)return t.probe_success?badge('up'):badge('down');return badge(t.health||'unknown')}
function renderMonitoringRuns(result){const p=state.monitoringRunPaging;p.page=Number(result?.page||1);p.pageSize=Number(result?.page_size||p.pageSize||10);const items=Array.isArray(result?.items)?result.items:[],rows=items.map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.prometheus_source_name||'—')}</td><td>${badge(r.status)}</td><td>${Number(r.target_count||0)}</td><td>${Number(r.matched_vm_count||0)}</td><td>${Number(r.up_count||0)}</td><td>${Number(r.down_count||0)}</td><td>${Number(r.unmatched_count||0)}</td><td>${Number(r.ambiguous_count||0)}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');const total=Number(result?.total||0),page=Number(result?.page||1),pageSize=Number(result?.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total);return `${rows?`<div class="table-wrap monitoring-run-table"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Targeturi</th><th>VM corelate</th><th>UP</th><th>DOWN</th><th>Necorelate</th><th>Ambigue</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există sincronizări Prometheus.')}<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="monitoringRunPageSize">${pageSizeOptions(pageSize,[10,25,50,100])}</select></label>${paginationButtons(page,Number(result?.pages||1),'monitoring-run-page')}</div></div>`}
function bindMonitoringControls(){
  let timer;document.getElementById('monitoringVMSearch')?.addEventListener('input',ev=>{clearTimeout(timer);const value=ev.target.value,pos=ev.target.selectionStart??value.length;timer=setTimeout(()=>{state.monitoringVMFilters.q=value.trim();state.monitoringVMFilters.page=1;loadMonitoringVMs(pos)},250)});[['monitoringVMState','state'],['monitoringVMPower','power'],['monitoringVMEnvironment','environment']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{state.monitoringVMFilters[key]=ev.target.value;state.monitoringVMFilters.page=1;loadMonitoringVMs()}));document.getElementById('clearMonitoringVMFilters')?.addEventListener('click',()=>{state.monitoringVMFilters={q:'',state:'',power:'POWERED_ON',environment:'PROD',page:1,pageSize:10};loadMonitoringVMs(0)});document.querySelectorAll('.monitoring-vm-page').forEach(b=>b.onclick=()=>{state.monitoringVMFilters.page=Number(b.dataset.page);loadMonitoringVMs()});document.getElementById('monitoringVMPageSize')?.addEventListener('change',ev=>{state.monitoringVMFilters.pageSize=Number(ev.target.value);state.monitoringVMFilters.page=1;loadMonitoringVMs()});
  let tt;document.getElementById('monitoringTargetSearch')?.addEventListener('input',ev=>{clearTimeout(tt);const value=ev.target.value,pos=ev.target.selectionStart??value.length;tt=setTimeout(()=>{state.monitoringTargetFilters.q=value.trim();state.monitoringTargetFilters.page=1;loadMonitoringTargets(pos)},250)});[['monitoringTargetType','sourceType'],['monitoringTargetHealth','health'],['monitoringTargetMatched','matched']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{state.monitoringTargetFilters[key]=ev.target.value;state.monitoringTargetFilters.page=1;loadMonitoringTargets()}));document.getElementById('clearMonitoringTargetFilters')?.addEventListener('click',()=>{state.monitoringTargetFilters={q:'',sourceType:'',health:'',matched:'',page:1,pageSize:10};loadMonitoringTargets(0)});document.querySelectorAll('.monitoring-target-page').forEach(b=>b.onclick=()=>{state.monitoringTargetFilters.page=Number(b.dataset.page);loadMonitoringTargets()});document.getElementById('monitoringTargetPageSize')?.addEventListener('change',ev=>{state.monitoringTargetFilters.pageSize=Number(ev.target.value);state.monitoringTargetFilters.page=1;loadMonitoringTargets()});
}
async function loadMonitoringVMs(focusPosition=null){const area=document.getElementById('monitoringVMTableArea');if(!area)return;try{const r=await api(`/api/v1/monitoring/vms?${monitoringVMQuery()}`);updateMonitoringCards(r);area.innerHTML=renderMonitoringVMs(r);bindMonitoringControls();updateMonitoringExportLinks();if(focusPosition!==null){const input=document.getElementById('monitoringVMSearch');if(input){input.focus();const pos=Math.min(Number(focusPosition)||0,input.value.length);input.setSelectionRange(pos,pos)}}}catch(err){toast(err.message,true)}}
async function loadMonitoringTargets(focusPosition=null){const area=document.getElementById('monitoringTargetTableArea');if(!area)return;try{const r=await api(`/api/v1/monitoring/targets?${monitoringTargetQuery()}`);area.innerHTML=renderMonitoringTargets(r);bindMonitoringControls();updateMonitoringExportLinks();if(focusPosition!==null){const input=document.getElementById('monitoringTargetSearch');if(input){input.focus();const pos=Math.min(Number(focusPosition)||0,input.value.length);input.setSelectionRange(pos,pos)}}}catch(err){toast(err.message,true)}}
function monitoringSourceRows(){
  return state.prometheusSources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${badge(s.source_type)}</td><td>${s.agent_id?`<strong>${e(s.agent_name||('#'+s.agent_id))}</strong><div class="muted">${e(s.agent_version||'')}${s.agent_inventory_id?` · inventar #${s.agent_inventory_id}`:''}</div>`:'<span class="muted">Neasociat</span>'}</td><td>${e(s.auth_mode||'none')}${s.username?`<div class="muted">${e(s.username)}</div>`:''}</td><td><span class="mono">${e(s.vm_label||'—')}</span><div class="muted">target: ${e(s.target_label||'instance')}</div></td><td>${veeamIntervalLabel(s.sync_interval_minutes)}<div class="muted">${s.enabled?'Activ':'Dezactivat'}</div></td><td>${dt(s.last_success_at)}${s.last_sync_at?`<div class="muted">Încercare: ${dt(s.last_sync_at)}</div>`:''}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions monitoring-source-actions">${can('monitoring.manage')?`<button class="small secondary prometheus-action" data-action="test" data-id="${s.id}">Test</button><button class="small prometheus-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary prometheus-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger prometheus-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
}
async function monitoringPage(section='overview'){
  if(section!=='sources')await loadEnvironmentCatalogue();
  section=section==='sources'?'sources':'overview';
  if((location.hash||'')==='#monitoring')history.replaceState(null,'','#monitoring/overview');
  const nav=monitoringSectionNavigation(section);
  if(section==='sources'){
    pageMeta('Monitorizare','Surse Prometheus / Blackbox și istoricul sincronizărilor');
    const p=state.monitoringRunPaging||{page:1,pageSize:10};
    const [sources,agentOptions,runs]=await Promise.all([api('/api/v1/monitoring/sources'),api('/api/v1/monitoring/agent-options'),api(`/api/v1/monitoring/sync-runs?page=${p.page}&page_size=${p.pageSize}`)]);
    state.prometheusSources=Array.isArray(sources)?sources:[];state.prometheusAgentOptions=Array.isArray(agentOptions)?agentOptions:[];
    const sourceRows=monitoringSourceRows();
    const tools=can('monitoring.manage')?'<button id="syncAllPrometheus">Sincronizează toate</button><button id="newPrometheus" class="secondary">Adaugă sursă</button>':'';
    const hint='<div class="baseline-hint monitoring-source-hint"><strong>Corelare</strong><span>Prioritate: <b>label explicit</b> → FQDN → hostname → IP → <b>/etc/hosts al agentului asociat</b> → alias manual. IP-urile vCenter de pe toate interfețele guest sunt incluse în matching.</span></div>';
    content.innerHTML=`<div class="monitoring-workspace">${nav}${panel('Surse Prometheus',`${hint}${sourceRows?`<div class="table-wrap monitoring-source-table"><table><thead><tr><th>Sursă</th><th>Tip</th><th>Agent asociat</th><th>Auth</th><th>Corelare</th><th>Program</th><th>Ultimul sync</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse Prometheus configurate.')}`,tools)}${panel('Ultimele sincronizări',renderMonitoringRuns(runs))}</div>`;
    document.getElementById('newPrometheus')?.addEventListener('click',()=>openPrometheus());
    document.getElementById('syncAllPrometheus')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/monitoring/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări introduse în coadă.`);setTimeout(()=>monitoringPage('sources'),1200)}catch(err){toast(err.message,true)}});
    content.querySelectorAll('.prometheus-action').forEach(b=>b.onclick=()=>prometheusAction(b.dataset.action,Number(b.dataset.id)));
    document.querySelectorAll('.monitoring-run-page').forEach(b=>b.onclick=()=>{state.monitoringRunPaging.page=Number(b.dataset.page);monitoringPage('sources')});
    document.getElementById('monitoringRunPageSize')?.addEventListener('change',ev=>{state.monitoringRunPaging.pageSize=Number(ev.target.value);state.monitoringRunPaging.page=1;monitoringPage('sources')});
    return;
  }
  pageMeta('Monitorizare','Node Exporter → Prometheus → Blackbox · stare și corelare VM');
  const [vms,targets]=await Promise.all([api(`/api/v1/monitoring/vms?${monitoringVMQuery()}`),api(`/api/v1/monitoring/targets?${monitoringTargetQuery()}`)]);
  const cards=`<div class="cards monitoring-summary-cards"><div class="card"><div class="label">VM-uri</div><div id="monTotal" class="value">${Number(vms.total||0)}</div><div class="muted">Conform filtrelor curente</div></div><div class="card"><div class="label">Node Exporter pornit</div><div id="monExporter" class="value">0</div><div id="monExporterPct" class="backup-percent">0%</div></div><div class="card"><div class="label">În Prometheus</div><div id="monMetrics" class="value">0</div><div id="monMetricsPct" class="backup-percent">0%</div></div><div class="card"><div class="label">VM metrics UP / DOWN</div><div class="value compact"><span id="monUp">0</span> / <span id="monDown">0</span></div></div><div class="card"><div class="label">Cu Blackbox</div><div id="monBlackbox" class="value">0</div><div id="monBlackboxPct" class="backup-percent">0%</div></div></div>`;
  content.innerHTML=`<div class="monitoring-workspace">${nav}${cards}${panel('VM-uri și monitorizare',`<div id="monitoringVMTableArea">${renderMonitoringVMs(vms)}</div>`,`<a id="exportMonitoringVMs" class="button secondary" href="/api/v1/monitoring/vms/export">Export Excel</a>`)}${panel('Targeturi Prometheus / Blackbox',`<div id="monitoringTargetTableArea">${renderMonitoringTargets(targets)}</div>`,`<a id="exportMonitoringTargets" class="button secondary" href="/api/v1/monitoring/targets/export">Export Excel</a>`)}</div>`;
  updateMonitoringCards(vms);bindMonitoringControls();updateMonitoringExportLinks();
}
prometheusForm.addEventListener('submit',async event=>{
  event.preventDefault();
  const id=Number(document.getElementById('prometheusId').value||0),body={name:document.getElementById('prometheusName').value.trim(),base_url:document.getElementById('prometheusURL').value.trim(),source_type:document.getElementById('prometheusType').value,auth_mode:document.getElementById('prometheusAuthMode').value,username:document.getElementById('prometheusUsername').value.trim(),secret:document.getElementById('prometheusSecret').value,vm_label:document.getElementById('prometheusVMLabel').value.trim(),target_label:document.getElementById('prometheusTargetLabel').value.trim(),agent_id:Number(document.getElementById('prometheusAgent').value||0),sync_interval_minutes:Number(document.getElementById('prometheusSyncInterval').value),enabled:document.getElementById('prometheusEnabled').checked,verify_tls:document.getElementById('prometheusVerifyTLS').checked,tls_server_name:document.getElementById('prometheusTLSServerName').value.trim()};
  if(id&&!body.secret)delete body.secret;
  try{await api(id?`/api/v1/monitoring/sources/${id}`:'/api/v1/monitoring/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});prometheusDialog.close();toast(id?'Sursa Prometheus a fost actualizată.':'Sursa Prometheus a fost creată.');monitoringPage('sources')}catch(err){toast(err.message,true)}
});

function fieldLabel(key){
  const labels={hostname:'Hostname',fqdn:'FQDN',uuid:'UUID',product_uuid:'Product UUID',machine_id:'Machine ID',pretty_name:'Denumire OS',version_id:'Versiune',primary_ip:'IP principal',boot_time:'Pornire sistem',uptime_seconds:'Uptime',status:'Stare',name:'Nume',software_name:'Software',version:'Versiune',package_name:'Pachet',package_version:'Versiune pachet',version_source:'Sursă versiune',enabled:'Activ',active:'Activ',installed:'Instalat',service:'Serviciu',port:'Port',protocol:'Protocol',address:'Adresă',mount_point:'Mount point',username:'Username',command:'Comandă',classification:'Clasificare',classification_reason:'Motiv clasificare'};
  if(labels[key])return labels[key];
  return String(key||'').replaceAll('_',' ').replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase());
}
function humanUptimeSeconds(raw){
  let total=Math.max(0,Math.floor(Number(raw)||0));
  const units=[['an','ani',365*24*3600],['lună','luni',30*24*3600],['zi','zile',24*3600],['oră','ore',3600],['minut','minute',60]];
  const parts=[];
  for(const [one,many,size] of units){const value=Math.floor(total/size);if(value>0){parts.push(`${value} ${value===1?one:many}`);total-=value*size}if(parts.length>=4)break}
  return parts.length?parts.join(', '):'sub un minut';
}
function inventoryItemSummary(item,index,parentKey=''){
  if(item&&typeof item==='object'&&!Array.isArray(item)){
    if(item.mount_point!==undefined&&String(item.mount_point).trim()!=='')return String(item.mount_point);
    if(item.port!==undefined&&String(item.port).trim()!=='')return `${item.port}${item.protocol?` / ${item.protocol}`:''}`;
    if(item.username!==undefined&&String(item.username).trim()!=='')return String(item.username);
    if(item.command!==undefined&&String(item.command).trim()!=='')return String(item.command).length>90?String(item.command).slice(0,87)+'…':String(item.command);
    if(item.name!==undefined&&String(item.name).trim()!=='')return String(item.name);
    if(item.path!==undefined&&String(item.path).trim()!=='')return String(item.path);
    if(item.address!==undefined&&String(item.address).trim()!=='')return String(item.address);
  }
  return `Element ${index+1}`;
}
function serviceState(item,stale=false){
  if(stale||String(item?.active_state||'').toLowerCase()==='missing')return 'missing';
  return String(item?.active_state||'').toLowerCase()==='active'?'active':'inactive';
}
function serviceStateLabel(value){return value==='active'?'<span class="badge active">Activ</span>':value==='missing'?'<span class="badge missing">Nedetectat</span>':'<span class="badge disabled">Inactiv</span>'}
function serviceClassification(item){
  const value=String(item?.classification||'').trim().toLowerCase();
  return ['system','application','unknown'].includes(value)?value:'unknown';
}
function serviceClassificationLabel(value){
  const classification=String(value||'unknown').toLowerCase();
  if(classification==='application')return '<span class="badge active">Aplicație</span>';
  if(classification==='system')return '<span class="badge disabled">Sistem OS</span>';
  return '<span class="badge">Necunoscut</span>';
}
function guessSupportComponentName(serviceName,softwareName=''){
  const joined=`${serviceName||''} ${softwareName||''}`.toLowerCase();
  const known=[
    [['postgresql','postgres'],'PostgreSQL'],[['redis'],'Redis'],[['meilisearch'],'Meilisearch'],[['minio'],'MinIO'],[['docmosis'],'Docmosis'],[['sentry'],'Sentry'],[['keycloak'],'Keycloak'],
    [['mariadb'],'MariaDB'],[['mysql'],'MySQL'],[['mongodb','mongod'],'MongoDB'],[['rabbitmq'],'RabbitMQ'],[['elasticsearch'],'Elasticsearch'],[['opensearch'],'OpenSearch'],
    [['zookeeper'],'ZooKeeper'],[['kafka'],'Kafka'],[['graylog'],'Graylog'],[['vault'],'Vault'],[['consul'],'Consul'],[['prometheus'],'Prometheus'],[['grafana'],'Grafana'],
    [['haproxy'],'HAProxy'],[['nginx'],'Nginx'],[['httpd','apache'],'Apache HTTP Server'],[['tomcat'],'Tomcat'],[['solr'],'Solr']
  ];
  for(const [needles,name] of known)if(needles.some(v=>joined.includes(v)))return name;
  if(String(softwareName||'').trim())return String(softwareName).trim();
  let base=String(serviceName||'').trim().replace(/\.service$/i,'').replace(/@.*$/,'').replace(/^[-_.\s]+|[-_.\s]+$/g,'');
  return base?base.charAt(0).toUpperCase()+base.slice(1):'Componentă suport';
}
function supportComponentEditorHTML(name,support={},item={},canManage=true){
  const rawVersion=item?.version||item?.package_version||'',detectedVersion=String(support?.detected_version||shortVersionText(rawVersion)||cleanVersionText(rawVersion)||'').trim(),detectedPorts=String(support?.detected_ports||'').trim();
  const componentName=String(support?.component_name||guessSupportComponentName(name,item?.software_name||support?.software_name||'')).trim();
  const effectiveVersion=String(support?.version||support?.version_override||detectedVersion||'').trim(),effectivePorts=String(support?.ports||support?.port_override||detectedPorts||'').trim();
  return `<div class="support-component-editor" data-service="${e(name)}"><div><strong>Componentă suport</strong><small>Modifică aici propunerea de componentă. Versiunea și porturile manuale sunt opționale și au prioritate față de valorile detectate automat.</small></div><label>Componentă propusă<input class="support-component-name" value="${e(componentName)}" maxlength="255"></label><label>Versiune manuală <span class="muted">(opțional)</span><input class="support-component-version" value="${e(support?.version_override||'')}" placeholder="Auto: ${e(detectedVersion||'nedetectată')}" maxlength="255"></label><label>Port(uri) manual <span class="muted">(opțional)</span><input class="support-component-ports" value="${e(support?.port_override||'')}" placeholder="Auto: ${e(detectedPorts||'nedetectat')}" maxlength="255"></label>${canManage?'<button type="button" class="small secondary save-support-component">Salvează componenta</button>':''}<div class="support-component-auto muted">Detectat automat: versiune <strong>${e(detectedVersion||'—')}</strong> · port(uri) <strong>${e(detectedPorts||'—')}</strong></div><span class="muted support-component-effective">Folosit în raport: <strong>${e(effectiveVersion||'versiune —')}</strong> · <strong>${e(effectivePorts||'port —')}</strong></span></div>`;
}

function serviceInventoryList(value,context={}){
  const selected=new Set((context.primaryServices||[]).map(item=>String(item.service_name||'').toLowerCase()));
  const supportByService=new Map((context.supportComponents||[]).map(item=>[String(item.service_name||'').toLowerCase(),item]));
  const observed=new Set((value||[]).map(item=>String(item?.name||'').toLowerCase()));
  const staleMap=new Map();
  for(const item of (context.primaryServices||[]))if(!observed.has(String(item.service_name||'').toLowerCase()))staleMap.set(String(item.service_name||'').toLowerCase(),{name:item.service_name,active_state:'missing',description:'Serviciu principal nedetectat în inventarul curent',classification:item.classification||'unknown',classification_reason:item.classification_reason||''});
  for(const item of (context.supportComponents||[]))if(!observed.has(String(item.service_name||'').toLowerCase()))staleMap.set(String(item.service_name||'').toLowerCase(),{name:item.service_name,software_name:item.software_name||'',version:item.version||'',active_state:'missing',description:'Componentă suport nedetectată în inventarul curent',classification:'application'});
  const rows=[...(value||[]).map(item=>({item,stale:false})),...[...staleMap.values()].map(item=>({item,stale:true}))]
    .sort((a,b)=>{const ak=String(a.item?.name||'').toLowerCase(),bk=String(b.item?.name||'').toLowerCase(),ap=(selected.has(ak)||supportByService.has(ak))?0:1,bp=(selected.has(bk)||supportByService.has(bk))?0:1;return ap-bp||String(a.item?.name||'').localeCompare(String(b.item?.name||''),'ro')});
  const reviewChecked=!!context.servicesReviewed;
  const reviewControl=context.canManage?`<div class="agent-services-review"><label><input id="vmAgentServicesReviewed" type="checkbox" ${reviewChecked?'checked':''}><span><strong>Servicii verificate</strong><small>Bifează după verificarea categoriei. Dacă nu există niciun serviciu marcat Principal, această confirmare satisface criteriul de completare.</small></span></label></div>`:(reviewChecked?'<div class="agent-services-review readonly"><strong>Servicii verificate</strong><small>Categoria a fost verificată manual.</small></div>':'');
  if(!rows.length)return `${reviewControl}<span class="muted">Listă goală</span>`;
  const filter=`<div class="filterbar service-inventory-filterbar"><label><span>Caută serviciu</span><input id="vmAgentServiceSearch" type="search" placeholder="tomcat, solr, postgres…"></label><label><span>Stare</span><select id="vmAgentServiceStatus"><option value="active" selected>Active</option><option value="inactive">Inactive</option><option value="missing">Nedetectate</option><option value="all">Toate</option></select></label><label><span>Tip serviciu</span><select id="vmAgentServiceClassification"><option value="non-system" selected>Aplicație + necunoscut</option><option value="application">Aplicație</option><option value="unknown">Necunoscut</option><option value="system">Sistem OS</option><option value="all">Toate</option></select></label><span id="vmAgentServiceCount" class="muted"></span></div>`;
  return `${reviewControl}${filter}<div class="structured-list service-inventory-list">${rows.map(({item,stale})=>{
    const name=String(item?.name||'Serviciu'),key=name.toLowerCase(),checked=selected.has(key),support=supportByService.get(key),supportChecked=!!support;
    const rawVersion=item?.version||item?.package_version||'',version=shortVersionText(rawVersion)||cleanVersionText(rawVersion),status=serviceState(item,stale),classification=serviceClassification(item);
    const search=[name,item?.software_name,item?.description,version,item?.package_name,classification,item?.classification_reason,support?.component_name].filter(Boolean).join(' ').toLowerCase();
    const controls=context.canManage?`<span class="service-row-controls"><label class="primary-service-check" title="Include ca serviciu software principal în documentație"><input type="checkbox" class="primary-agent-service-toggle" data-service="${e(name)}" ${checked?'checked':''}><span>Principal</span></label><label class="support-service-check" title="Include în raportul Componente suport"><input type="checkbox" class="support-agent-service-toggle" data-service="${e(name)}" data-software="${e(item?.software_name||'')}" ${supportChecked?'checked':''}><span>Componentă suport</span></label></span>`:`${checked?'<span class="badge primary">Principal</span>':''}${supportChecked?'<span class="badge active">Componentă suport</span>':''}`;
    const supportEditor=supportChecked?supportComponentEditorHTML(name,support,item,context.canManage):'';
    return `<details class="service-inventory-row ${stale?'stale-primary-service':''}" data-service-status="${status}" data-service-classification="${classification}" data-service-primary="${checked?'true':'false'}" data-service-support="${supportChecked?'true':'false'}" data-service-search="${e(search)}"><summary><span class="inventory-summary-main"><strong>${e(name)}</strong> ${serviceStateLabel(status)} ${serviceClassificationLabel(classification)}${version?` <span class="muted">· ${e(version)}</span>`:''}</span>${controls}</summary>${supportEditor}${structuredValue(item,1,{...context,parentKey:'services'})}</details>`;
  }).join('')}</div>`;
}
function applyServiceInventoryFilters(){
  const search=document.getElementById('vmAgentServiceSearch'),status=document.getElementById('vmAgentServiceStatus'),classification=document.getElementById('vmAgentServiceClassification'),rows=[...document.querySelectorAll('.service-inventory-row')];if(!rows.length)return;
  const q=String(search?.value||'').trim().toLowerCase(),wanted=status?.value||'active',wantedClass=classification?.value||'non-system';let shown=0;
  rows.forEach(row=>{const highlighted=row.dataset.servicePrimary==='true'||row.dataset.serviceSupport==='true',actualClass=row.dataset.serviceClassification||'unknown',okStatus=highlighted||wanted==='all'||row.dataset.serviceStatus===wanted,okClass=highlighted||wantedClass==='all'||(wantedClass==='non-system'&&actualClass!=='system')||actualClass===wantedClass,okSearch=!q||String(row.dataset.serviceSearch||'').includes(q);row.hidden=!(okStatus&&okClass&&okSearch);if(!row.hidden)shown++});
  const count=document.getElementById('vmAgentServiceCount');if(count)count.textContent=`${shown} din ${rows.length}`;
}
function bindServiceInventoryFilters(){
  const search=document.getElementById('vmAgentServiceSearch'),status=document.getElementById('vmAgentServiceStatus'),classification=document.getElementById('vmAgentServiceClassification');let timer;
  search?.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(applyServiceInventoryFilters,120)});status?.addEventListener('change',applyServiceInventoryFilters);classification?.addEventListener('change',applyServiceInventoryFilters);applyServiceInventoryFilters();
}
function primaryPortKey(protocol,port,processName){return `${String(protocol||'').trim().toLowerCase()}/${Number(port||0)}/${String(processName||'').trim().toLowerCase()}`}
function normalizedListeningPorts(value){
  const merged=new Map();
  for(const endpoint of (Array.isArray(value)?value:[])){
    const protocol=String(endpoint?.protocol||'').trim().toLowerCase(),port=Number(endpoint?.port||0),address=String(endpoint?.address||endpoint?.local_address||endpoint?.listen||'').trim();
    if(!protocol||!port)continue;
    let processes=Array.isArray(endpoint?.processes)?endpoint.processes:[];
    if(!processes.length)processes=[{name:endpoint?.name||endpoint?.process_name||'',pid:endpoint?.pid||'',executable:endpoint?.executable||endpoint?.exec||''}];
    for(const process of processes){
      const processName=String(process?.name||process?.process||process?.process_name||process?.service||process?.program||'').trim();
      const executable=String(process?.executable||process?.exec||process?.exec_path||process?.binary||process?.path||process?.command||'').trim();
      const pid=Number(process?.pid||process?.process_id||0),key=primaryPortKey(protocol,port,processName);
      const current=merged.get(key)||{protocol,port,process_name:processName,pids:[],executable:'',addresses:[],detected:true};
      if(pid>0&&!current.pids.includes(pid))current.pids.push(pid);
      if(address&&!current.addresses.includes(address))current.addresses.push(address);
      if(!current.executable&&executable)current.executable=executable;
      merged.set(key,current);
    }
  }
  return [...merged.values()].map(item=>({...item,pids:item.pids.sort((a,b)=>a-b),addresses:item.addresses.sort((a,b)=>a.localeCompare(b,'ro'))}));
}
function portInventoryList(value,context={}){
  const selectedValues=Array.isArray(context.primaryPorts)?context.primaryPorts:[],selected=new Set(selectedValues.map(item=>primaryPortKey(item.protocol,item.port,item.process_name)));
  const observed=normalizedListeningPorts(value),observedKeys=new Set(observed.map(item=>primaryPortKey(item.protocol,item.port,item.process_name)));
  const stale=selectedValues.filter(item=>!observedKeys.has(primaryPortKey(item.protocol,item.port,item.process_name))).map(item=>({...item,detected:false,pids:[],addresses:[]}));
  const rows=[...observed,...stale].sort((a,b)=>{const ap=selected.has(primaryPortKey(a.protocol,a.port,a.process_name))?0:1,bp=selected.has(primaryPortKey(b.protocol,b.port,b.process_name))?0:1;return ap-bp||Number(a.port)-Number(b.port)||String(a.protocol).localeCompare(String(b.protocol))||String(a.process_name||'').localeCompare(String(b.process_name||''),'ro')});
  if(!rows.length)return '<span class="muted">Listă goală</span>';
  const filter=`<div class="filterbar service-inventory-filterbar"><label><span>Caută port / proces</span><input id="vmAgentPortSearch" type="search" placeholder="8100, soffice.bin, java, solr…"></label><label><span>Afișare</span><select id="vmAgentPortStatus"><option value="all" selected>Toate</option><option value="selected">Principale</option><option value="detected">Detectate</option><option value="missing">Nedetectate</option></select></label><span id="vmAgentPortCount" class="muted"></span></div>`;
  const html=rows.map(item=>{const key=primaryPortKey(item.protocol,item.port,item.process_name),checked=selected.has(key),detected=item.detected!==false,processName=String(item.process_name||'').trim(),search=[item.port,item.protocol,processName,item.executable,...(item.addresses||[])].filter(Boolean).join(' ').toLowerCase(),status=!detected?'missing':checked?'selected':'detected';const checkbox=context.canManage?`<label class="primary-service-check" title="Include portul/procesul ca principal în documentația VM"><input type="checkbox" class="primary-agent-port-toggle" data-protocol="${e(item.protocol)}" data-port="${e(item.port)}" data-process="${e(processName)}" ${checked?'checked':''}><span>Principal</span></label>`:(checked?'<span class="badge primary">Principal</span>':'');const processLabel=processName?` · ${e(processName)}`:'';return `<details class="service-inventory-row port-inventory-row ${!detected?'stale-primary-service':''}" data-port-status="${status}" data-port-search="${e(search)}"><summary><span class="inventory-summary-main"><strong>${e(item.port)} / ${e(String(item.protocol||'').toUpperCase())}</strong>${processLabel} ${!detected?'<span class="badge missing">Nedetectat</span>':''}</span>${checkbox}</summary><dl class="inventory-kv"><div><dt>Proces</dt><dd>${e(processName||'—')}</dd></div><div><dt>PID</dt><dd>${(item.pids||[]).length?e(item.pids.join(', ')):'—'}</dd></div><div><dt>Executabil</dt><dd class="mono pre-wrap">${e(item.executable||'—')}</dd></div><div><dt>Adresă listen</dt><dd class="mono">${(item.addresses||[]).length?e(item.addresses.join(', ')):'—'}</dd></div></dl></details>`}).join('');
  return `${filter}<div class="structured-list service-inventory-list port-inventory-list">${html}</div>`;
}
function applyPortInventoryFilters(){
  const search=document.getElementById('vmAgentPortSearch'),status=document.getElementById('vmAgentPortStatus'),rows=[...document.querySelectorAll('.port-inventory-row')];if(!rows.length)return;
  const q=String(search?.value||'').trim().toLowerCase(),wanted=status?.value||'all';let shown=0;
  rows.forEach(row=>{const actual=row.dataset.portStatus||'detected',okStatus=wanted==='all'||actual===wanted||(wanted==='detected'&&actual!=='missing'),okSearch=!q||String(row.dataset.portSearch||'').includes(q);row.hidden=!(okStatus&&okSearch);if(!row.hidden)shown++});
  const count=document.getElementById('vmAgentPortCount');if(count)count.textContent=`${shown} din ${rows.length}`;
}
function bindPortInventoryFilters(){const search=document.getElementById('vmAgentPortSearch'),status=document.getElementById('vmAgentPortStatus');let timer;search?.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(applyPortInventoryFilters,120)});status?.addEventListener('change',applyPortInventoryFilters);applyPortInventoryFilters()}
function primaryPortsSummary(primaryPorts=[]){
  const rows=Array.isArray(primaryPorts)?primaryPorts:[];
  if(!rows.length)return empty('Nu sunt marcate porturi sau procese principale.');
  return `<div class="table-wrap"><table><thead><tr><th>Port / protocol</th><th>Proces</th><th>Adresă listen</th><th>Stare</th></tr></thead><tbody>${rows.map(item=>`<tr><td class="mono">${e(item.port||'—')}/${e(String(item.protocol||'tcp').toUpperCase())}</td><td>${e(item.process_name||'—')}</td><td class="mono">${e((item.addresses||[]).join(', ')||'—')}</td><td>${item.detected===false?badge('missing'):badge('active')}</td></tr>`).join('')}</tbody></table></div>`;
}

function routesInventoryTable(value){
  const rows=Array.isArray(value)?value:[];if(!rows.length)return '<span class="muted">Nu sunt rute raportate.</span>';
  return `<div class="table-wrap inventory-table"><table><thead><tr><th>Familie</th><th>Destinație</th><th>Gateway</th><th>Interfață</th><th>Protocol</th><th>Sursă</th><th>Default</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${e(r?.family||'—')}</td><td class="mono">${e(r?.destination||'—')}</td><td class="mono">${e(r?.gateway||'—')}</td><td>${e(r?.interface||'—')}</td><td>${e(r?.protocol||'—')}</td><td class="mono">${e(r?.source||'—')}</td><td>${r?.default?badge('Da'):'Nu'}</td></tr>`).join('')}</tbody></table></div>`;
}
function firewallRuleTable(rules){
  const rows=Array.isArray(rules)?rules:[];if(!rows.length)return '<span class="muted">Nu există reguli.</span>';
  return `<div class="table-wrap inventory-table"><table><thead><tr><th>Backend</th><th>Familie</th><th>Tabel</th><th>Chain</th><th>Acțiune</th><th>Regulă</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${e(r?.backend||'—')}</td><td>${e(r?.family||'—')}</td><td>${e(r?.table||'—')}</td><td>${e(r?.chain||'—')}</td><td>${e(r?.action||'—')}</td><td class="mono pre-wrap">${e(r?.rule||'—')}</td></tr>`).join('')}</tbody></table></div>`;
}
function firewallManagedBackends(data,rules=[]){
  const managed=new Set();const mark=value=>{const v=String(value||'').trim().toLowerCase();if(v==='ufw')managed.add('ufw');else if(v==='firewalld')managed.add('firewalld');else if(v==='susefirewall2'||v==='susefirewall')managed.add('susefirewall2')};
  (Array.isArray(data?.backends)?data.backends:[]).forEach(mark);
  (Array.isArray(data?.config_files)?data.config_files:[]).forEach(cfg=>{const v=String(cfg||'').toLowerCase();if(v.includes('ufw'))managed.add('ufw');else if(v.includes('firewalld'))managed.add('firewalld');else if(v.includes('susefirewall'))managed.add('susefirewall2')});
  rules.forEach(r=>{mark(r?.backend);const probe=[r?.table,r?.chain,r?.rule,r?.raw,r?.expression,r?.line].map(v=>String(v||'').toLowerCase()).join(' ');if(probe.includes('ufw-')||probe.includes('ufw '))managed.add('ufw');if(probe.includes('firewalld'))managed.add('firewalld');if(probe.includes('sfw2-')||probe.includes('susefirewall'))managed.add('susefirewall2')});
  return managed;
}
function firewallUFWUserRule(rule){const chain=String(rule?.chain||'').toLowerCase(),action=String(rule?.action||rule?.decision||rule?.target||'').toLowerCase(),text=String(rule?.rule||rule?.raw||rule?.expression||rule?.line||'').toLowerCase();if(action==='jump'||action==='goto'||text.includes(' jump ufw-')||text.includes(' goto ufw-'))return false;return chain.includes('ufw-user-')}
function firewallInventory(value,context={}){
  const data=value&&typeof value==='object'?value:{},backends=Array.isArray(data.backends)?data.backends:[],rules=Array.isArray(data.rules)?data.rules:[],managed=firewallManagedBackends(data,rules),explicit=managed.size?rules.filter(r=>managed.has(String(r?.backend||'').toLowerCase())||(managed.has('ufw')&&firewallUFWUserRule(r))):rules;
  const policies=Object.entries(data.default_policies||{});const zones=Array.isArray(data.zones)?data.zones:[];
  const summary=`<div class="detail-grid firewall-summary">${detail('Detectat',data.detected?'Da':'Nu')}${detail('Activ',data.active?'Da':'Nu')}${detail('Backend-uri',backends.length?backends.map(e).join(', '):'—')}${detail('Reguli configurate',String(explicit.length))}</div>`;
  const policyHTML=policies.length?`<div class="table-wrap inventory-table"><table><thead><tr><th>Backend / chain</th><th>Politică</th></tr></thead><tbody>${policies.map(([k,v])=>`<tr><td class="mono">${e(k)}</td><td>${e(v)}</td></tr>`).join('')}</tbody></table></div>`:'<span class="muted">Nu sunt raportate politici implicite.</span>';
  const explicitHTML=explicit.length?firewallRuleTable(explicit):empty(managed.has('firewalld')?'Regulile firewalld sunt documentate prin zone, servicii și porturi.':'Nu există reguli configurate identificate.');
  const zoneHTML=zones.length?`<details class="firewall-extra"><summary>Zone firewalld (${zones.length})</summary>${structuredValue(zones,1,{...context,parentKey:'zones'})}</details>`:'';
  const configs=Array.isArray(data.config_files)&&data.config_files.length?`<details class="firewall-extra"><summary>Fișiere configurare (${data.config_files.length})</summary>${structuredValue(data.config_files,1,{...context,parentKey:'config_files'})}</details>`:'';
  return `${summary}<h4>Politici implicite</h4>${policyHTML}<h4>Reguli configurate</h4>${explicitHTML}${zoneHTML}${configs}`;
}
function firewallLocalRules(documentView){
  const section=(Array.isArray(documentView?.sections)?documentView.sections:[]).find(x=>String(x?.key||'').toLowerCase()==='firewall');
  const data=section?.data||{};const rules=Array.isArray(data.rules)?data.rules:[];const managed=firewallManagedBackends(data,rules);
  return managed.size?rules.filter(r=>managed.has(String(r?.backend||'').toLowerCase())||(managed.has('ufw')&&firewallUFWUserRule(r))):rules;
}
function firewallLocalReviewCell(item,vmId,vmName=''){
 const review=item.review||{},label=`${item.action||'Regulă'} · ${String(item.rule||'').slice(0,100)}`;
 const button=can('vms.manage')?`<button type="button" class="small secondary security-review" data-vm="${Number(vmId)}" data-type="firewall_local" data-key="${e(item.resource_key||'')}" data-vm-name="${e(vmName)}" data-resource-name="${e(label)}" data-interval="${Number(review.interval_months||6)}" data-justified="${review.reviewed_at?(review.justified?'yes':'no'):''}" data-notes="${e(review.notes||'')}">Revizuiește</button>`:'';
 return review.resource_key?securityReviewCell(vmId,'firewall_local',review.resource_key,review,6,{vmName,resource:label}):securityReviewNotApplicable();
}
function firewallLocalServerTable(data){
 const rows=data?.rules||[],vmId=Number(data?.vm_id),vmName=data?.vm_name||'';
 return rows.length?`<div class="table-wrap firewall-local-table" tabindex="0"><table data-sortable="false"><thead><tr><th>Acțiune</th><th>Regulă</th><th>Review</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${e(r.action||'—')}</td><td class="mono pre-wrap">${e(r.rule||'—')}</td><td>${firewallLocalReviewCell(r,vmId,vmName)}</td></tr>`).join('')}</tbody></table></div>`:empty('Agentul nu a raportat reguli locale configurate.');
}
async function loadVMLocalFirewall(vmId){
 const host=document.getElementById('vmFirewallLocalContent');if(!host)return;
 host.innerHTML='<div class="muted">Se încarcă regulile locale…</div>';
 try{const data=await api(`/api/v1/security/firewall/local?vm_id=${Number(vmId)}`);if(!host.isConnected)return;host.innerHTML=firewallReviewedBar(data.rules||[])+firewallLocalServerTable(data);const bulk=document.getElementById('vmFirewallLocalBulk');if(bulk){bulk.dataset.count=(data.rules||[]).length;bulk.disabled=!(data.rules||[]).length;}bindSecurityReviewButtons(host)}catch(err){host.textContent=err.message||'Nu am putut încărca firewall-ul local.'}
}
function firewallLocalCompact(documentView){
  const rules=firewallLocalRules(documentView);
  return rules.length?`<div class="table-wrap firewall-local-table" tabindex="0"><table data-sortable="false"><thead><tr><th>Acțiune</th><th>Regulă</th></tr></thead><tbody>${rules.map(r=>`<tr><td>${e(r.action||'—')}</td><td class="mono pre-wrap">${e(r.rule||'—')}</td></tr>`).join('')}</tbody></table></div>`:empty('Nu există reguli configurate raportate de agent.');
}
function vmHostFirewallPanel(documentView){
  const section=(Array.isArray(documentView?.sections)?documentView.sections:[]).find(item=>String(item?.key||'').toLowerCase()==='firewall');
  if(!section?.data)return empty('Agentul nu a raportat informații despre firewall-ul local pentru această VM.');
  return firewallInventory(section.data,{sectionKey:'firewall'});
}

function structuredValue(value,depth=0,context={}){
  if(value===null||value===undefined||value==='')return '<span class="muted">—</span>';
  if(context.sectionKey==='firewall'&&depth===0&&value&&typeof value==='object'&&!Array.isArray(value))return firewallInventory(value,context);
  if(typeof value==='boolean')return value?badge('active'):badge('disabled');
  if(typeof value==='number'){
    if(context.parentKey==='uptime_seconds')return `<span>${e(humanUptimeSeconds(value))}</span>`;
    return `<span>${e(value)}</span>`;
  }
  if(typeof value==='string'){
    if(context.parentKey==='uptime_seconds'&&!Number.isNaN(Number(value)))return `<span>${e(humanUptimeSeconds(value))}</span>`;
    if(context.parentKey==='version'){const cleaned=shortVersionText(value)||cleanVersionText(value);return cleaned?`<span>${e(cleaned)}</span>`:'<span class="muted">—</span>'}
    if(context.parentKey==='package_version'){const cleaned=cleanVersionText(value);return cleaned?`<span>${e(cleaned)}</span>`:'<span class="muted">—</span>'}
    const low=value.toLowerCase();
    if(['ok','active','enabled','running','installed','success','succeeded','online','configured'].includes(low))return badge(low);
    if(['error','failed','disabled','stopped','missing','offline','not_installed','unconfigured','timeout'].includes(low))return badge(low);
    return `<span class="${value.length>70?'pre-wrap':''}">${e(value)}</span>`;
  }
  if(Array.isArray(value)){
    if(!value.length)return '<span class="muted">Listă goală</span>';
    if(context.sectionKey==='services'&&depth===0)return serviceInventoryList(value,context);
    if(context.sectionKey==='listening_ports'&&depth===0)return portInventoryList(value,context);
    if(context.sectionKey==='network'&&context.parentKey==='routes')return routesInventoryTable(value);
    const primitives=value.every(item=>item===null||['string','number','boolean'].includes(typeof item));
    if(primitives)return `<div class="value-list">${value.map(item=>`<span>${structuredValue(item,depth+1,context)}</span>`).join('')}</div>`;
    return `<div class="structured-list">${value.map((item,index)=>`<details><summary>${e(inventoryItemSummary(item,index,context.parentKey))}</summary>${structuredValue(item,depth+1,context)}</details>`).join('')}</div>`;
  }
  const entries=Object.entries(value);
  if(!entries.length)return '<span class="muted">Fără date</span>';
  return `<dl class="inventory-kv ${depth>1?'nested':''}">${entries.map(([key,item])=>`<div><dt>${e(fieldLabel(key))}</dt><dd>${structuredValue(item,depth+1,{...context,parentKey:key})}</dd></div>`).join('')}</dl>`;
}
function structuredInventory(documentView,{vmID=0,primaryServices=[],primaryPorts=[],supportComponents=[],servicesReviewed=false,canManage=false}={}){
  const sections=Array.isArray(documentView?.sections)?documentView.sections:[];
  if(!sections.length)return empty('Agentul nu a furnizat încă date structurate.');
  return `<div class="inventory-sections">${sections.map(section=>`<details class="inventory-section" data-inventory-section-key="${e(section.key||'')}"><summary><span>${e(section.title||fieldLabel(section.key))}</span>${section.status?badge(section.status):''}</summary><div class="inventory-section-body">${structuredValue(section.data,0,{sectionKey:section.key,vmID,primaryServices,primaryPorts,supportComponents,servicesReviewed,canManage})}</div></details>`).join('')}</div>`;
}
function categoryItems(categories,code){return (categories||[]).find(item=>item.code===code)?.items||[]}
function selectOptions(items,selected,placeholder='— Neselectat —',label=value=>value.name){return `<option value="">${e(placeholder)}</option>${(items||[]).filter(item=>item.active||Number(item.id)===Number(selected)).map(item=>`<option value="${item.id}" ${Number(selected)===Number(item.id)?'selected':''}>${e(label(item))}${item.active?'':' (inactiv)'}</option>`).join('')}`}
function multiSelectOptions(items,selected=[]){const selectedSet=new Set((selected||[]).map(Number));return (items||[]).filter(item=>item.active||selectedSet.has(Number(item.id))).map(item=>`<option value="${item.id}" ${selectedSet.has(Number(item.id))?'selected':''}>${e(item.name)}${item.active?'':' (inactiv)'}</option>`).join('')}
function selectDropdownPortalHost(anchor){return anchor.closest('dialog')||document.body}
function positionSelectDropdown(anchor,dropdown){
  if(!anchor?.isConnected||!dropdown?.isConnected)return;
  const rect=anchor.getBoundingClientRect(),gap=5,viewportGap=10,maxAllowed=300;
  const availableBelow=Math.max(0,window.innerHeight-rect.bottom-gap-viewportGap),availableAbove=Math.max(0,rect.top-gap-viewportGap);
  // Measure the rendered list. Using its real height prevents a filtered list
  // from staying suspended too high when the dropdown is placed above the field.
  const previousMax=dropdown.style.maxHeight;dropdown.style.maxHeight=`${maxAllowed}px`;
  const naturalHeight=Math.min(maxAllowed,Math.max(1,dropdown.scrollHeight||dropdown.getBoundingClientRect().height||1));
  dropdown.style.maxHeight=previousMax;
  const locked=dropdown.dataset.lockedPlacement;
  const useAbove=locked?locked==='above':availableBelow<naturalHeight&&availableAbove>availableBelow;
  if(!locked)dropdown.dataset.lockedPlacement=useAbove?'above':'below';
  const available=useAbove?availableAbove:availableBelow;
  const maxHeight=Math.max(80,Math.min(maxAllowed,available||maxAllowed));
  const renderedHeight=Math.min(naturalHeight,maxHeight);
  const top=useAbove?Math.max(viewportGap,rect.top-gap-renderedHeight):Math.min(window.innerHeight-viewportGap-renderedHeight,rect.bottom+gap);
  const width=Math.min(Math.max(190,rect.width),Math.max(190,window.innerWidth-2*viewportGap));
  const left=Math.min(Math.max(viewportGap,rect.left),Math.max(viewportGap,window.innerWidth-width-viewportGap));
  Object.assign(dropdown.style,{position:'fixed',left:`${left}px`,right:'auto',top:`${Math.max(viewportGap,top)}px`,width:`${width}px`,maxHeight:`${maxHeight}px`,zIndex:'10050'});
  dropdown.dataset.placement=useAbove?'above':'below';
}
function scheduleSelectDropdownPosition(anchor,dropdown){
  cancelAnimationFrame(Number(dropdown.dataset.positionFrame||0));
  dropdown.dataset.positionFrame=String(requestAnimationFrame(()=>{delete dropdown.dataset.positionFrame;positionSelectDropdown(anchor,dropdown)}));
}
function mountSelectDropdown(anchor,dropdown){const host=selectDropdownPortalHost(anchor);if(dropdown.parentElement!==host)host.appendChild(dropdown);dropdown.classList.add('select-dropdown-portal');scheduleSelectDropdownPosition(anchor,dropdown)}
const enhancedMultiSelects=new WeakMap();
function destroyEnhancedMultiSelect(select){
  const current=enhancedMultiSelects.get(select);if(!current)return;
  current.cleanup?.();current.wrapper.remove();select.hidden=false;select.classList.remove('select2-lite-source');enhancedMultiSelects.delete(select);
}
function enhanceMultiSelect(select,{placeholder='Alege valorile'}={}){
  destroySearchableSelect(select);destroyEnhancedMultiSelect(select);if(!select.multiple)return;
  select.hidden=true;select.classList.add('select2-lite-source');
  const wrapper=document.createElement('div');wrapper.className='select2-lite';
  wrapper.innerHTML=`<button type="button" class="select2-lite-control" aria-haspopup="listbox" aria-expanded="false"><span class="select2-lite-values"></span><span class="select2-lite-arrow" aria-hidden="true"></span></button><div class="select2-lite-dropdown" hidden><input type="search" class="select2-lite-search" placeholder="Caută layer…" autocomplete="off"><div class="select2-lite-options" role="listbox" aria-multiselectable="true"></div></div>`;
  select.insertAdjacentElement('afterend',wrapper);
  const control=wrapper.querySelector('.select2-lite-control'),values=wrapper.querySelector('.select2-lite-values'),dropdown=wrapper.querySelector('.select2-lite-dropdown'),search=wrapper.querySelector('.select2-lite-search'),optionsArea=wrapper.querySelector('.select2-lite-options');
  function selectedOptions(){return [...select.options].filter(option=>option.selected)}
  function renderValues(){const selected=selectedOptions();values.innerHTML=selected.length?selected.map(option=>`<span class="select2-lite-chip">${e(option.textContent)}</span>`).join(''):`<span class="select2-lite-placeholder">${e(placeholder)}</span>`}
  function renderOptions(){const query=search.value.trim().toLocaleLowerCase('ro');const options=[...select.options].filter(option=>!query||option.textContent.toLocaleLowerCase('ro').includes(query));optionsArea.innerHTML=options.length?options.map(option=>`<label class="select2-lite-option"><input type="checkbox" value="${e(option.value)}" ${option.selected?'checked':''} ${option.disabled?'disabled':''}><span>${e(option.textContent)}</span></label>`).join(''):'<div class="select2-lite-empty">Niciun rezultat</div>';if(!dropdown.hidden)scheduleSelectDropdownPosition(control,dropdown)}
  const reposition=()=>{if(!dropdown.hidden)scheduleSelectDropdownPosition(control,dropdown)};
  function setOpen(open){if(open===!dropdown.hidden)return;dropdown.hidden=!open;control.setAttribute('aria-expanded',String(open));wrapper.classList.toggle('open',open);if(open){delete dropdown.dataset.lockedPlacement;mountSelectDropdown(control,dropdown);renderOptions();setTimeout(()=>search.focus({preventScroll:true}),0)}else delete dropdown.dataset.lockedPlacement}
  control.addEventListener('click',()=>setOpen(dropdown.hidden));
  search.addEventListener('input',renderOptions);
  search.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();setOpen(false);control.focus({preventScroll:true})}});
  optionsArea.addEventListener('change',event=>{const checkbox=event.target.closest('input[type="checkbox"]');if(!checkbox)return;const option=[...select.options].find(item=>item.value===checkbox.value);if(option)option.selected=checkbox.checked;renderValues();select.dispatchEvent(new Event('change',{bubbles:true}))});
  const outsideClick=event=>{if(!wrapper.contains(event.target)&&!dropdown.contains(event.target))setOpen(false)};document.addEventListener('click',outsideClick);window.addEventListener('resize',reposition);document.addEventListener('scroll',reposition,true);
  renderValues();enhancedMultiSelects.set(select,{wrapper,cleanup(){document.removeEventListener('click',outsideClick);window.removeEventListener('resize',reposition);document.removeEventListener('scroll',reposition,true);dropdown.remove()},refresh(){renderValues();renderOptions()}});
}


/* 0.16.2 · all single-value listboxes are searchable without changing their underlying values/events. */
const enhancedSearchableSelects=new WeakMap();
function destroySearchableSelect(select){
  const current=enhancedSearchableSelects.get(select);if(!current)return;
  current.cleanup?.();current.wrapper.remove();select.classList.remove('search-select-source');select.removeAttribute('aria-hidden');enhancedSearchableSelects.delete(select);
}
function refreshSearchableSelect(select){
  const current=enhancedSearchableSelects.get(select);if(!current)return;
  const option=select.options[select.selectedIndex]||null;
  if(document.activeElement!==current.input)current.input.value=option?.textContent||'';
  current.input.disabled=select.disabled;current.wrapper.classList.toggle('disabled',select.disabled);
  if(current.wrapper.classList.contains('open'))current.renderOptions();
}
function enhanceSearchableSelect(select){
  if(!(select instanceof HTMLSelectElement)||select.multiple||select.classList.contains('select2-lite-source')||select.dataset.searchable==='off'||select.closest('.filterbar,.vm-filter-shell,.service-filter-shell,.ui-filter-shell,.pagination,.audit-filters,.nomenclature-filters')||enhancedSearchableSelects.has(select))return;
  const wrapper=document.createElement('div');wrapper.className='search-select';
  wrapper.innerHTML='<input type="search" class="search-select-input" autocomplete="off" role="combobox" aria-expanded="false"><span class="search-select-arrow" aria-hidden="true"></span><div class="search-select-dropdown" role="listbox" hidden></div>';
  select.insertAdjacentElement('afterend',wrapper);select.classList.add('search-select-source');select.setAttribute('aria-hidden','true');
  const input=wrapper.querySelector('.search-select-input'),dropdown=wrapper.querySelector('.search-select-dropdown');
  function renderOptions(queryValue=input.value){
    const query=String(queryValue||'').trim().toLocaleLowerCase('ro');
    const options=[...select.options].filter(option=>!option.hidden&&(!query||option.textContent.toLocaleLowerCase('ro').includes(query)));
    dropdown.innerHTML=options.length?options.map(option=>`<button type="button" class="search-select-option${option.selected?' selected':''}" data-value="${e(option.value)}" ${option.disabled?'disabled':''}>${e(option.textContent)}</button>`).join(''):'<div class="search-select-empty">Niciun rezultat</div>';
    if(!dropdown.hidden)scheduleSelectDropdownPosition(input,dropdown);
  }
  const reposition=()=>{if(!dropdown.hidden)scheduleSelectDropdownPosition(input,dropdown)};
  function open(showAll=false){if(select.disabled)return;const wasOpen=!dropdown.hidden;wrapper.classList.add('open');dropdown.hidden=false;input.setAttribute('aria-expanded','true');if(!wasOpen)mountSelectDropdown(input,dropdown);renderOptions(showAll?'':input.value)}
  function close(sync=true){wrapper.classList.remove('open');dropdown.hidden=true;delete dropdown.dataset.lockedPlacement;input.setAttribute('aria-expanded','false');if(sync)refreshSearchableSelect(select)}
  input.addEventListener('focus',()=>{refreshSearchableSelect(select)});
  input.addEventListener('click',()=>{if(dropdown.hidden){input.select();open(true)}});
  input.addEventListener('input',()=>{if(dropdown.hidden)open(false);else renderOptions(input.value)});
  input.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();close();input.blur();return}if(event.key==='Enter'){event.preventDefault();const first=dropdown.querySelector('.search-select-option:not(:disabled)');if(first)first.click()}});
  dropdown.addEventListener('click',event=>{const button=event.target.closest('.search-select-option');if(!button||button.disabled)return;select.value=button.dataset.value;select.dispatchEvent(new Event('change',{bubbles:true}));close();input.focus({preventScroll:true});input.select()});
  select.addEventListener('invalid',event=>{event.preventDefault();input.focus();open()});
  window.addEventListener('resize',reposition);document.addEventListener('scroll',reposition,true);
  enhancedSearchableSelects.set(select,{wrapper,input,dropdown,renderOptions,close,cleanup(){window.removeEventListener('resize',reposition);document.removeEventListener('scroll',reposition,true);dropdown.remove()}});refreshSearchableSelect(select);
}
function enhanceSearchableSelects(root=document){
  if(root instanceof HTMLSelectElement)enhanceSearchableSelect(root);
  root.querySelectorAll?.('select').forEach(select=>{if(select.multiple){destroySearchableSelect(select);return}enhanceSearchableSelect(select)});
}
function refreshSearchableSelects(root=document){root.querySelectorAll?.('select').forEach(refreshSearchableSelect)}
function cleanupEnhancedSelects(root){
  if(root instanceof HTMLSelectElement){destroySearchableSelect(root);destroyEnhancedMultiSelect(root)}
  root.querySelectorAll?.('select').forEach(select=>{destroySearchableSelect(select);destroyEnhancedMultiSelect(select)})
}
document.addEventListener('click',event=>{document.querySelectorAll('.search-select.open').forEach(wrapper=>{const select=wrapper.previousElementSibling,current=select instanceof HTMLSelectElement?enhancedSearchableSelects.get(select):null;if(wrapper.contains(event.target)||current?.dropdown?.contains(event.target))return;current?.close()})});
document.addEventListener('change',event=>{if(event.target instanceof HTMLSelectElement)refreshSearchableSelect(event.target)});
const searchableSelectObserver=new MutationObserver(mutations=>{
  for(const mutation of mutations){
    if(mutation.type==='childList'){
      mutation.removedNodes.forEach(node=>{if(node.nodeType===1)cleanupEnhancedSelects(node)});
      mutation.addedNodes.forEach(node=>{if(node.nodeType===1)enhanceSearchableSelects(node)});
      const owner=mutation.target instanceof HTMLOptionElement?mutation.target.parentElement:mutation.target instanceof HTMLSelectElement?mutation.target:mutation.target.closest?.('select');if(owner instanceof HTMLSelectElement)refreshSearchableSelect(owner);
    }else if(mutation.type==='attributes'){
      const target=mutation.target;
      if(target instanceof HTMLSelectElement){if(target.multiple){destroySearchableSelect(target)}else enhanceSearchableSelect(target);refreshSearchableSelect(target)}
      if(target instanceof HTMLDialogElement&&target.open)refreshSearchableSelects(target);
    }
  }
});
function nomenclatureOptions(categories,code,selected){return selectOptions(categoryItems(categories,code),selected,'— Neselectat —',item=>code==='environment'?String(item.item_code||item.name||'').toLocaleUpperCase('ro-RO'):item.name)}
function resourceContextSelect(categories,code,id,placeholder,selectedID=null,mixed=false){return `<select id="${e(id)}" data-searchable="off">${selectOptions(categoryItems(categories,code),selectedID,mixed?'— Valori diferite —':`— ${placeholder} —`,item=>code==='environment'?String(item.item_code||item.name||'').toLocaleUpperCase('ro-RO'):item.name)}</select>`}
function resourceContextValue(id){const value=Number(document.getElementById(id)?.value||0);return value>0?value:null}
function resourceAssignmentMeta(a){const values=[a?.environment?environmentDisplay(a.environment):'',a?.operational_status,a?.solution_type].filter(Boolean).map(e);return values.length?`<small class="resource-context-meta">${values.join(' · ')}</small>`:''}
function resourceFilterAssignments(value){return (Array.isArray(value?.service_assignments)?value.service_assignments:[]).map(a=>({service:String(Number(a?.service_id||0)||''),environment:String(Number(a?.environment_id||0)||''),status:String(Number(a?.operational_status_id||0)||''),solution:String(Number(a?.solution_type_id||0)||'')}))}
function resourceFilterAttrs(value){const assignments=resourceFilterAssignments(value),complete=assignments.length>0&&assignments.every(a=>a.service&&a.environment&&a.status&&a.solution);return `data-resource-assignments="${e(JSON.stringify(assignments))}" data-resource-complete="${complete?'1':'0'}" data-documentation-exempt="${value?.documentation_exempt?'1':'0'}"`}
function resourceFilterOptions(resources,idKey,nameKey,formatter=value=>value){const values=new Map();for(const resource of (resources||[])){for(const a of (resource?.service_assignments||[])){const id=Number(a?.[idKey]||0);if(!id)continue;const raw=String(a?.[nameKey]||'').trim(),label=formatter(raw||`#${id}`);values.set(String(id),label)}}return [...values.entries()].sort((a,b)=>String(a[1]).localeCompare(String(b[1]),'ro')).map(([value,label])=>`<option value="${e(value)}">${e(label)}</option>`).join('')}
function resourceInventoryFilterBar(prefix,resources){const service=resourceFilterOptions(resources,'service_id','service_name'),environment=resourceFilterOptions(resources,'environment_id','environment',environmentDisplay),status=resourceFilterOptions(resources,'operational_status_id','operational_status'),solution=resourceFilterOptions(resources,'solution_type_id','solution_type');return `<div class="filterbar resource-inventory-filterbar"><label><span>Serviciu</span><select id="${prefix}ResourceServiceFilter" data-searchable="off"><option value="">Toate</option>${service}</select></label><label><span>Mediu</span><select id="${prefix}ResourceEnvironmentFilter" data-searchable="off"><option value="">Toate</option>${environment}</select></label><label><span>Status operațional</span><select id="${prefix}ResourceStatusFilter" data-searchable="off"><option value="">Toate</option>${status}</select></label><label><span>Tip soluție</span><select id="${prefix}ResourceSolutionFilter" data-searchable="off"><option value="">Toate</option>${solution}</select></label><label><span>Documentare</span><select id="${prefix}ResourceDocumentationFilter" data-searchable="off"><option value="">Toate</option><option value="required">Necesită documentare</option><option value="exempt">Nu necesită documentare</option></select></label><label><span>Configurare</span><select id="${prefix}ResourceUnsetFilter" data-searchable="off"><option value="">Toate</option><option value="unset">Nesetate</option><option value="complete">Complete</option></select></label><button type="button" class="secondary" id="${prefix}ResourceFiltersReset">Resetează</button><span class="muted resource-filter-count" id="${prefix}ResourceFilterCount"></span></div>`}
function bindResourceInventoryFilters(prefix,rowSelector){const ids={service:`${prefix}ResourceServiceFilter`,environment:`${prefix}ResourceEnvironmentFilter`,status:`${prefix}ResourceStatusFilter`,solution:`${prefix}ResourceSolutionFilter`,documentation:`${prefix}ResourceDocumentationFilter`,unset:`${prefix}ResourceUnsetFilter`},controls=Object.fromEntries(Object.entries(ids).map(([key,id])=>[key,document.getElementById(id)])),rows=[...document.querySelectorAll(rowSelector)];if(!rows.length)return;const apply=()=>{const selected={service:controls.service?.value||'',environment:controls.environment?.value||'',status:controls.status?.value||'',solution:controls.solution?.value||'',documentation:controls.documentation?.value||'',unset:controls.unset?.value||''};let visible=0;for(const row of rows){let assignments=[];try{assignments=JSON.parse(row.dataset.resourceAssignments||'[]')}catch{}const assignmentMatch=assignments.some(a=>(!selected.service||a.service===selected.service)&&(!selected.environment||a.environment===selected.environment)&&(!selected.status||a.status===selected.status)&&(!selected.solution||a.solution===selected.solution));const hasAssignmentFilters=!!(selected.service||selected.environment||selected.status||selected.solution),exempt=row.querySelector('.resource-exempt-label input')?.checked??row.dataset.documentationExempt==='1',complete=row.dataset.resourceComplete==='1';const docOK=!selected.documentation||(selected.documentation==='exempt'?exempt:!exempt),unsetOK=!selected.unset||(selected.unset==='unset'?!complete:complete),ok=(!hasAssignmentFilters||assignmentMatch)&&docOK&&unsetOK;row.hidden=!ok;if(ok)visible++}const count=document.getElementById(`${prefix}ResourceFilterCount`);if(count)count.textContent=`${visible} din ${rows.length} resurse`};Object.values(controls).forEach(control=>control?.addEventListener('change',apply));document.getElementById(`${prefix}ResourceFiltersReset`)?.addEventListener('click',()=>{Object.values(controls).forEach(control=>{if(control)control.value=''});apply()});apply()}
const responsibilityTypes={technical_admin:'Administrator tehnic',service_owner:'Responsabil serviciu',business_owner:'Responsabil business',application_owner:'Responsabil aplicație',infrastructure_owner:'Responsabil infrastructură',security_contact:'Contact securitate',backup_contact:'Contact backup',other:'Altă responsabilitate'};
function responsibilityTypeOptions(selected){return Object.entries(responsibilityTypes).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function peopleOptions(people,selected){return `<option value="">— Alege persoana —</option>${(people||[]).filter(person=>person.active||Number(person.id)===Number(selected)).map(person=>`<option value="${person.id}" ${Number(selected)===Number(person.id)?'selected':''}>${e(person.display_name)}${person.email?` · ${e(person.email)}`:''}${person.active?'':' (inactiv)'}</option>`).join('')}`}
function responsibilityRow(item,people,index){return `<div class="responsibility-row" data-index="${index}"><label>Persoană<select class="responsibility-person">${peopleOptions(people,item?.person_id)}</select></label><label>Rol<select class="responsibility-type">${responsibilityTypeOptions(item?.responsibility_type||'technical_admin')}</select></label><label class="responsibility-notes">Detalii<input class="responsibility-note" value="${e(item?.notes||'')}" placeholder="Opțional"></label><button type="button" class="small danger remove-responsibility">Elimină</button></div>`}
function vmOverviewResponsibilities(values){
 // Afișăm toate persoanele alese, inclusiv administratorii tehnici.
 // Ascundem doar numele rolurilor în rezumat, nu persoanele asociate.
 const unique=[...new Set((Array.isArray(values)?values:[]).map(item=>String(item.person_name||'').trim()).filter(Boolean))];
 return unique.length?e(unique.join(', ')):'—';
}
function vmOverviewBeneficiaries(values){
 const names=[...new Set((Array.isArray(values)?values:[]).map(item=>String(item.beneficiary_name||'').trim()).filter(Boolean))];
 return e(names.join(', ')||'—');
}
function vmOverviewExternalLink(url,label){
 const value=String(url||'').trim();
 if(!/^https?:\/\//i.test(value))return '—';
 return `<a href="${e(value)}" target="_blank" rel="noopener noreferrer" title="${e(value)}">${e(label||value)}</a>`;
}
function responsibilitySummary(values){if(!values?.length)return '—';return `<div class="responsibility-summary">${values.map(item=>`<div><strong>${e(item.person_name)}</strong><span>${e(responsibilityTypes[item.responsibility_type]||item.responsibility_type)}${item.person_email?` · ${e(item.person_email)}`:''}</span></div>`).join('')}</div>`}
function minutesText(value){if(value===null||value===undefined)return '—';if(value<60)return `${value} min`;if(value%1440===0)return `${value/1440} zile`;if(value%60===0)return `${value/60} ore`;return `${value} min`}
function backupRetentionLabel(backup){if(backup?.retention_quantity===null||backup?.retention_quantity===undefined)return backup?.retention_type||'—';return `${backup.retention_type||'Retenție'} · ${backup.retention_quantity}`}
function gfsLabel(value,unit,detail){return value===null||value===undefined?'—':`${value} ${unit}${detail?` · ${detail}`:''}`}
function backupSection(backup){
  const hasData=backup&&(backup.synced_at||backup.policy_name||backup.job_name||backup.source_name||backup.error_message||backup.provider==='manual'||backup.cron_backup_enabled);
  if(!hasData)return empty('Nu există încă date Veeam sau un backup cron declarat pentru această VM.');
  const effective=!!(backup.protected||backup.cron_backup_enabled);
  const inJob=backup.veeam_in_job?(backup.veeam_job_enabled?'<span class="badge configured">Da</span>':'<span class="badge job-disabled">Da · job dezactivat</span>'):'Nu';
  return `<div class="detail-grid">${detail('Furnizor',e(backup.provider||'veeam'))}${detail('Sursă Veeam',e(backup.source_name||'—'))}${detail('Stare Veeam',veeamStateBadge(backup.veeam_state))}${detail('În job Veeam',inJob)}${detail('Protecție efectivă',effective?badge(backup.cron_backup_enabled&&!backup.protected?'cron':'protected'):badge('unprotected'))}${detail('Ultimul rezultat',backup.last_result?badge(backup.last_result):'—')}${detail('Job',e(backup.job_name||'—'))}${detail('Politică',e(backup.policy_name||'—'))}${detail('Storage primar',e(backup.primary_repository_name||backup.repository_name||'—'))}${detail('Storage secundar',e(backup.secondary_repository_names||'—'))}${detail('Programare Veeam',e(backup.schedule_text||'—'))}${detail('Retenție',e(backupRetentionLabel(backup)))}${detail('GFS Weekly',e(gfsLabel(backup.gfs_weekly_weeks,'săptămâni',backup.gfs_weekly_day)))}${detail('GFS Monthly',e(gfsLabel(backup.gfs_monthly_months,'luni',backup.gfs_monthly_week)))}${detail('GFS Yearly',e(gfsLabel(backup.gfs_yearly_years,'ani',backup.gfs_yearly_month)))}${detail('Restore points',backup.restore_points??'—')}${detail('Ultimul backup',dt(backup.last_backup_at))}${detail('Următoarea rulare',dt(backup.next_run_at))}${detail('RPO',minutesText(backup.rpo_minutes))}${detail('RTO',minutesText(backup.rto_minutes))}${detail('Ultima sincronizare',dt(backup.synced_at))}${detail('Backup cron',backup.cron_backup_enabled?badge('enabled'):badge('disabled'))}${detail('Expresie cron',e(backup.cron_backup_schedule||'—'),true)}${detail('Comandă / script',e(backup.cron_backup_command||'—'),true)}${detail('Observații cron',e(backup.cron_backup_notes||'—'))}${detail('Eroare',e(backup.error_message||'—'))}</div>`;
}
function cronInventoryEntries(documentView){
  const sections=Array.isArray(documentView?.sections)?documentView.sections:[];
  const cronSection=sections.find(section=>String(section?.key||'').toLowerCase()==='cron');
  if(!cronSection)return [];
  const values=[];
  const pick=(obj,keys)=>{for(const key of keys){const value=obj?.[key];if(value!==undefined&&value!==null&&String(value).trim())return String(value).trim()}return ''};
  const visit=value=>{
    if(Array.isArray(value)){value.forEach(visit);return}
    if(!value||typeof value!=='object')return;
    const schedule=pick(value,['schedule','expression','cron','cron_expression','timer','when']);
    const command=pick(value,['command','cmd','script','exec','job']);
    const user=pick(value,['user','username','owner']);
    const source=pick(value,['source','file','path']);
    if(schedule||command){values.push({schedule,command,user,source});return}
    Object.values(value).forEach(visit);
  };
  visit(cronSection.data);
  const seen=new Set();
  return values.filter(item=>{const key=`${item.schedule}\u0000${item.command}\u0000${item.user}`;if(seen.has(key))return false;seen.add(key);return true});
}
function cronBackupForm(backup,documentView){
  if(!can('vms.manage'))return '';
  const detected=cronInventoryEntries(documentView);
  const currentSchedule=String(backup?.cron_backup_schedule||'').trim(),currentCommand=String(backup?.cron_backup_command||'').trim();
  const detectedHTML=detected.length?`<div class="cron-detected-list">${detected.map((item,index)=>{const selected=Boolean(backup?.cron_backup_enabled)&&item.schedule===currentSchedule&&item.command===currentCommand;return `<label class="cron-detected-row"><input type="radio" name="cronBackupDetected" value="${index}" ${selected?'checked':''}><span><strong>${e(item.schedule||'Program necunoscut')}</strong><code>${e(item.command||'—')}</code><small>${e([item.user?`user ${item.user}`:'',item.source].filter(Boolean).join(' · ')||'detectat de agent')}</small></span></label>`}).join('')}</div>`:`<p class="muted">Agentul nu a raportat sarcini cron pentru această VM. Poți completa manual mai jos.</p>`;
  return `<form id="cronBackupForm" class="operational-form cron-backup-form"><div class="form-section"><label class="check-row"><input id="cronBackupEnabled" type="checkbox" ${backup?.cron_backup_enabled?'checked':''}> VM-ul are și backup realizat prin cron / script local</label><div class="cron-detected"><h4>Cron-uri detectate de agent</h4><p class="muted">Selectează cron-ul care realizează backupul. Programul și comanda sunt completate automat și pot fi ajustate manual.</p>${detectedHTML}</div><div class="form-grid"><label>Expresie cron<input id="cronBackupSchedule" class="mono" value="${e(currentSchedule)}" placeholder="0 2 * * *"></label><label class="span-2">Comandă / script<input id="cronBackupCommand" class="mono" value="${e(currentCommand)}" placeholder="/usr/local/sbin/backup.sh"></label></div><label>Observații<textarea id="cronBackupNotes" rows="3">${e(backup?.cron_backup_notes||'')}</textarea></label><p class="muted">Această bifă documentează un backup existent. vm-doc nu execută și nu modifică jobul cron.</p></div><div class="form-actions"><button type="submit">Salvează backup cron</button></div></form>`
}

function backupCandidateDetails(details){
  const candidates=Array.isArray(details?.candidates)?details.candidates:[];
  if(!candidates.length)return empty('Nu există detalii brute Veeam pentru această VM. Rulează o sincronizare după upgrade.');
  const rows=candidates.map(item=>{const object=item.object||{},backup=item.backup||{},job=item.job||{},definition=item.job_definition||{},latest=item.latest_restore_point||{},storage=definition.storage||{},configured=!!item.configured_in_job;return `<tr><td>${configured?'<span class="badge configured">În job</span>':'<span class="muted">Doar backup existent</span>'}</td><td><strong>${e(backup.name||object.name||definition.name||'—')}</strong><div class="muted mono">${e(object.backupId||latest.backupId||backup.id||'—')}</div></td><td>${e(job.name||definition.name||'—')}</td><td>${job.lastResult?badge(job.lastResult):'—'}</td><td>${e(item.repository_name||backup.repositoryName||job.repositoryName||'—')}</td><td>${e(definition.schedule?JSON.stringify(definition.schedule):'—')}</td><td>${e(storage.retentionPolicy?`${storage.retentionPolicy.type||''} ${storage.retentionPolicy.quantity??''}`:'—')}</td><td>${object.restorePointsCount??'—'}</td><td>${dt(latest.creationTime||backup.creationTime)}</td><td>${dt(job.nextRun)}</td><td class="error-text">${e(item.restore_point_error||'—')}</td></tr>`}).join('');
  return `<div class="table-wrap backup-candidate-table"><table><thead><tr><th>Configurație</th><th>Backup chain</th><th>Job</th><th>Rezultat</th><th>Repository</th><th>Schedule brut</th><th>Retenție</th><th>Restore points</th><th>Ultimul RP</th><th>Next run</th><th>Eroare</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

function cleanVersionText(value){
  const lines=String(value||'').replace(/\r/g,'').split('\n').map(line=>line.trim()).filter(Boolean).filter(line=>!/^warning(?:\s|:)/i.test(line)&&!/(?:^|:\s*)\[warning\]/i.test(line));
  return lines.join(' ').trim();
}
function shortVersionText(value){
  const text=cleanVersionText(value);if(!text)return '';
  const distrib=text.match(/\bDistrib\s+v?([0-9]+(?:\.[0-9]+){1,3})/i);if(distrib)return distrib[1];
  const m=text.match(/(?:^|[^0-9])v?([0-9]+(?:\.[0-9]+){1,3})/i);return m?m[1]:text.split(' (')[0].split(',')[0].trim();
}
function bytesText(value){const size=Number(value||0);if(size<1024)return `${size} B`;if(size<1024*1024)return `${(size/1024).toFixed(1)} KB`;return `${(size/1024/1024).toFixed(1)} MB`}
function documentTemplateOptions(values){return (values||[]).filter(item=>item.active).map(item=>`<option value="${item.id}" ${item.is_default?'selected':''}>${e(item.name)}${item.is_default?' · implicit':''}</option>`).join('')}
function generatedDocumentRows(values,emptyMessage='Nu a fost generată încă nicio fișă pentru acest obiect.',servicePackage=false){
  if(!values?.length)return empty(emptyMessage);
  const rows=values.map(item=>`<tr><td><strong>${e(item.document_number)}</strong><div class="muted">${e(item.file_name)}</div></td><td>${e(item.template_name||'—')}</td><td>${dt(item.generated_at)}</td><td>${e(item.generated_by_name||'sistem')}</td><td>${bytesText(item.size_bytes)}</td><td><div class="actions"><a class="button-link small secondary" href="/api/v1/documents/${item.id}/download">DOCX</a>${servicePackage?`<a class="button-link small" href="/api/v1/documents/${item.id}/package">Pachet + anexe</a>`:''}</div></td></tr>`).join('');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Număr electronic document</th><th>Șablon</th><th>Data referință</th><th>Autor</th><th>Mărime</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function vmDocumentsPanel(vmID,templates,generated,assignments=[],outlineEnabled=false,outlineDisabled=false,environment=''){
  const active=(templates||[]).filter(item=>item.active),prodEnvironment=environmentKind(environment)==='prod',environmentLabel=environmentDisplay(environment);
  const outlineOptions=outlineEnabled?(outlineDisabled?`<div class="notice"><strong>Outline</strong><div>VM-ul este marcat <em>Nu se publică în Outline</em>.</div></div>`:!prodEnvironment?`<div class="notice"><strong>Outline</strong><div>VM-ul este în mediul <strong>${e(environmentLabel)}</strong>. Publicarea în Outline este disponibilă numai pentru VM-urile PROD.</div></div>`:`<div class="outline-inline-publish"><div><strong>Outline · Virtualizare</strong><div class="muted">Fișa VM este creată sau actualizată direct sub documentul părinte configurat pentru categoria Virtualizare.</div></div><div><button id="publishVMOutline" type="button" class="secondary">Trimite în Outline</button><div id="vmOutlinePublishProgress" class="muted"></div></div></div>`):'';
  const generator=can('documents.manage')?(active.length?`<form id="vmDocumentForm" class="document-generation-form"><label>Șablon DOCX<select id="vmDocumentTemplate">${documentTemplateOptions(active)}</select></label><div class="service-document-options"><label><input id="vmIncludeGeneratedBy" type="checkbox" checked> Include „Generat de”</label></div><div class="document-generation-actions"><button id="previewVMDocument" type="button" class="secondary">Previzualizează datele</button><button type="submit">Generează DOCX</button></div><p class="muted">Fișa este generată din datele vCenter, datele operaționale, servicii, responsabilități, backup și inventarul curent al agentului.</p></form>${outlineOptions}`:empty('Nu există niciun șablon DOCX activ. Activează sau încarcă un șablon din meniul Documente.')):'';
  return panel('Fișe tehnice generate',`${generator}<div class="generated-documents-history">${generatedDocumentRows(generated)}</div>`,can('documents.manage')?'<a class="button-link small secondary" href="#documents/templates">Administrează șabloanele</a>':'');
}

function serviceDocumentsPanel(service,templates,generated,outlineEnabled=false,outlineState={}){
  const serviceID=Number(service?.id||0),active=(templates||[]).filter(item=>item.active),documentationURL=String(service?.documentation_url||'').trim(),prodEligible=!!outlineState?.prod_eligible,prodVMCount=Number(outlineState?.prod_vm_count||0);
  let outline='';
  if(can('documents.manage')&&outlineEnabled){
    if(service?.retired)outline=`<div class="notice"><strong>Outline</strong><div>Serviciul este retras / scos din uz și nu se publică în Outline.</div></div>`;
    else if(service?.outline_documentation_disabled)outline=`<div class="notice"><strong>Outline</strong><div>Serviciul este marcat <em>Nu se documentează în Outline</em>.</div></div>`;
    else if(!prodEligible)outline=`<div class="notice"><strong>Outline</strong><div>Serviciul nu are nicio asociere VM în mediul PROD. Publicarea în Outline este disponibilă numai pentru servicii cu PROD.</div></div>`;
    else outline=documentationURL?`<div class="outline-inline-publish"><div><strong>Outline · pagina serviciului</strong><div class="muted">VM-DOC actualizează pagina indicată în <em>Link documentație</em> numai cu informațiile PROD (${prodVMCount} VM${prodVMCount===1?'':'-uri'} PROD); nu o creează și nu o mută.</div><a href="${e(documentationURL)}" target="_blank" rel="noopener">Deschide pagina Outline</a></div><button id="publishServiceOutline" type="button" class="secondary">Actualizează în Outline</button></div>`:`<div class="notice"><strong>Outline</strong><div>Completează <em>Link documentație</em> în Detalii cu URL-ul paginii Outline a serviciului. VM-DOC va actualiza exact acea pagină, numai cu informațiile PROD.</div></div>`;
  }
  const generator=can('documents.manage')?(active.length?`<form id="serviceDocumentForm" class="document-generation-form service-document-generation-form"><label>Șablon DOCX<select id="serviceDocumentTemplate">${documentTemplateOptions(active)}</select></label><div class="document-generation-actions"><button id="previewServiceDocument" type="button" class="secondary">Previzualizează datele</button><button id="downloadServiceMarkdown" type="button" class="secondary">Markdown pentru Outline</button><button type="submit">Generează fișa</button></div><div class="service-document-options"><label><input id="serviceIncludeVMAnnexes" type="checkbox" checked> Include fișele VM în pachetul ZIP</label><label><input id="serviceEmbedVMAnnexes" type="checkbox"> Lipește anexele A1, A2… în același document</label><label><input id="serviceRegenerateVMAnnexes" type="checkbox"> Regenerează fișele VM înainte de anexare</label><label><input id="serviceIncludeGeneratedBy" type="checkbox" checked> Include „Generat de”</label></div><p class="muted">Anexele integrate sunt inserate în același DOCX, fiecare pe pagină nouă. La exportul Markdown, aceeași bifă include conținutul complet al fișelor VM ca A1, A2… . Opțiunea ZIP păstrează și fișierele VM separat.</p></form>${outline}`:empty('Nu există niciun șablon DOCX activ pentru servicii interne.')):'';
  return panel('Fișe tehnice și operaționale generate',`${generator}<div class="generated-documents-history">${generatedDocumentRows(generated,'Nu a fost generată încă nicio fișă pentru acest serviciu.',true)}</div>`,can('documents.manage')?'<a class="button-link small secondary" href="#documents/templates">Administrează șabloanele</a>':'');
}
function serviceSupplementalDocumentsPanel(serviceID,values){
  const list=(values||[]).length?`<div class="table-wrap"><table class="compact-table"><thead><tr><th>Titlu</th><th>Fișier</th><th>Încărcat</th><th>Autor</th><th>Mărime</th><th></th></tr></thead><tbody>${values.map(item=>`<tr><td><strong>${e(item.title||item.file_name)}</strong></td><td>${e(item.file_name)}</td><td>${dt(item.created_at)}</td><td>${e(item.created_by_name||'sistem')}</td><td>${bytesText(item.size_bytes)}</td><td><div class="actions"><a class="button-link small secondary" href="/api/v1/services/${serviceID}/attachments/${item.id}">DOCX</a>${can('documents.manage')?`<button type="button" class="small danger delete-service-supplemental" data-id="${item.id}">Șterge</button>`:''}</div></td></tr>`).join('')}</tbody></table></div>`:empty('Nu a fost încărcată încă nicio procedură operațională.');
  const form=can('documents.manage')?`<form id="serviceSupplementalForm" class="document-generation-form"><label>Titlu document<input id="serviceSupplementalTitle" maxlength="255" placeholder="ex. Flux aprobare, Procedură operare curentă"></label><label>Document Word (.docx)<input id="serviceSupplementalFile" type="file" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required></label><div class="document-generation-actions"><button type="submit">Încarcă documentul</button></div><p class="muted">Documentul este anexat la finalul fișei ca B1, B2… și își păstrează formatarea Word. Fișierul original rămâne disponibil pentru descărcare.</p></form>`:'';
  return panel('Proceduri operaționale și fluxuri de lucru',`${form}${list}`);
}
function bindServiceSupplementalActions(serviceID){
  document.getElementById('serviceSupplementalForm')?.addEventListener('submit',async event=>{event.preventDefault();const input=document.getElementById('serviceSupplementalFile'),file=input?.files?.[0];if(!file){toast('Alege un fișier DOCX.',true);return}const form=new FormData();form.append('file',file);const titleValue=document.getElementById('serviceSupplementalTitle')?.value?.trim()||'';if(titleValue)form.append('title',titleValue);const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent='Se încarcă…';try{await api(`/api/v1/services/${serviceID}/attachments`,{method:'POST',body:form});toast('Procedura operațională a fost încărcată.');internalServiceDetail(serviceID,'documents')}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Încarcă documentul'}});
  document.querySelectorAll('.delete-service-supplemental').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi procedura operațională selectată?'))return;try{await api(`/api/v1/services/${serviceID}/attachments/${button.dataset.id}`,{method:'DELETE'});toast('Procedura operațională a fost ștearsă.');internalServiceDetail(serviceID,'documents')}catch(err){toast(err.message,true)}}));
}
function serviceDocumentPreviewHTML(preview){
  const warnings=(preview.warnings||[]).length?`<div class="notice warning"><strong>Observații înainte de generare</strong><ul>${preview.warnings.map(item=>`<li>${e(item)}</li>`).join('')}</ul></div>`:'';
  const sections=(preview.sections||[]).map(section=>`<section class="document-preview-section"><h3>${e(section.title)}</h3><div class="detail-grid">${(section.rows||[]).map(row=>detail(row.label,e(row.value||'—'))).join('')}</div></section>`).join('');
  return `${warnings}<div class="document-preview-meta">${detail('Serviciu',e(preview.internal_service_name))}${detail('Șablon',e(preview.template_name))}${detail('Număr electronic document',e(preview.document_number),true)}${detail('Data referință',dt(preview.generated_at))}</div>${sections}`;
}
function bindServiceDocumentActions(serviceID){
  const selected=()=>Number(document.getElementById('serviceDocumentTemplate')?.value||0);
  const requestBody=()=>({template_id:selected(),include_vm_annexes:!!document.getElementById('serviceIncludeVMAnnexes')?.checked,embed_vm_annexes:!!document.getElementById('serviceEmbedVMAnnexes')?.checked,regenerate_vm_annexes:!!document.getElementById('serviceRegenerateVMAnnexes')?.checked,include_generated_by:!!document.getElementById('serviceIncludeGeneratedBy')?.checked});
  document.getElementById('previewServiceDocument')?.addEventListener('click',async()=>{const body=requestBody();if(!body.template_id){toast('Alege un șablon DOCX.',true);return}try{const preview=await api(`/api/v1/services/${serviceID}/documents/preview`,{method:'POST',body:JSON.stringify(body)});document.querySelector('#documentPreviewDialog h2').textContent='Previzualizare fișă tehnică și operațională';document.getElementById('documentPreviewContent').innerHTML=serviceDocumentPreviewHTML(preview);documentPreviewDialog.showModal()}catch(err){toast(err.message,true)}});
  document.getElementById('downloadServiceMarkdown')?.addEventListener('click',async event=>{const body=requestBody();if(!body.template_id){toast('Alege un șablon DOCX.',true);return}const button=event.currentTarget;button.disabled=true;button.textContent='Se generează Markdown…';try{await postDownload(`/api/v1/services/${serviceID}/documents/markdown`,body,`serviciu-${serviceID}.md`);toast('Fișierul Markdown a fost generat.')}catch(err){toast(err.message,true)}finally{button.disabled=false;button.textContent='Markdown pentru Outline'}});
  document.getElementById('serviceDocumentForm')?.addEventListener('submit',async event=>{event.preventDefault();const body=requestBody();if(!body.template_id){toast('Alege un șablon DOCX.',true);return}const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent=body.regenerate_vm_annexes?'Se generează fișele VM…':'Se generează…';try{const generated=await api(`/api/v1/services/${serviceID}/documents`,{method:'POST',body:JSON.stringify(body)});toast(`Fișa ${generated.document_number} a fost generată.`);const link=document.createElement('a');link.href=body.include_vm_annexes?`/api/v1/documents/${generated.id}/package`:`/api/v1/documents/${generated.id}/download`;link.click();setTimeout(()=>internalServiceDetail(serviceID),700)}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Generează fișa'}});
  document.getElementById('publishServiceOutline')?.addEventListener('click',async event=>{const button=event.currentTarget;button.disabled=true;button.textContent='Se actualizează…';try{const result=await api(`/api/v1/services/${serviceID}/outline`,{method:'POST',body:'{}'});toast(result.changed?'Documentația serviciului a fost actualizată în Outline.':'Documentația Outline era deja la zi.');if(result.url){const link=document.createElement('a');link.href=result.url;link.target='_blank';link.rel='noopener';link.click()}}catch(err){toast(err.message,true)}finally{button.disabled=false;button.textContent='Actualizează în Outline'}});
}
function documentPreviewHTML(preview){
  const warnings=(preview.warnings||[]).length?`<div class="notice warning"><strong>Observații înainte de generare</strong><ul>${preview.warnings.map(item=>`<li>${e(item)}</li>`).join('')}</ul></div>`:'';
  const sections=(preview.sections||[]).map(section=>`<section class="document-preview-section vm-document-preview-section"><h3>${e(section.title)}</h3><div class="document-preview-rows">${(section.rows||[]).map(row=>`<div class="document-preview-row"><span>${e(row.label)}</span><div>${e(row.value||'—')}</div></div>`).join('')}</div></section>`).join('');
  return `<div class="vm-document-preview">${warnings}<div class="document-preview-meta">${detail('VM',e(preview.vm_name))}${detail('Șablon',e(preview.template_name))}${detail('Număr electronic document',e(preview.document_number),true)}${detail('Data referință',dt(preview.generated_at))}</div><div class="document-preview-sections">${sections}</div></div>`;
}
function selectedDocumentTemplateID(){return Number(document.getElementById('vmDocumentTemplate')?.value||0)}
function bindVMDocumentActions(vmID){
  document.getElementById('previewVMDocument')?.addEventListener('click',async()=>{const templateID=selectedDocumentTemplateID();if(!templateID){toast('Alege un șablon DOCX.',true);return}try{const preview=await api(`/api/v1/vms/${vmID}/documents/preview`,{method:'POST',body:JSON.stringify({template_id:templateID,include_generated_by:!!document.getElementById('vmIncludeGeneratedBy')?.checked})});document.querySelector('#documentPreviewDialog h2').textContent='Previzualizare fișă VM';document.getElementById('documentPreviewContent').innerHTML=documentPreviewHTML(preview);documentPreviewDialog.showModal()}catch(err){toast(err.message,true)}});
  document.getElementById('vmDocumentForm')?.addEventListener('submit',async event=>{event.preventDefault();const templateID=selectedDocumentTemplateID();if(!templateID){toast('Alege un șablon DOCX.',true);return}const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent='Se generează…';try{const generated=await api(`/api/v1/vms/${vmID}/documents`,{method:'POST',body:JSON.stringify({template_id:templateID,include_generated_by:!!document.getElementById('vmIncludeGeneratedBy')?.checked})});toast(`Fișa ${generated.document_number} a fost generată.`);const link=document.createElement('a');link.href=`/api/v1/documents/${generated.id}/download`;link.click();setTimeout(()=>vmDetail(vmID),500)}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Generează DOCX'}});
  document.getElementById('publishVMOutline')?.addEventListener('click',async event=>{const button=event.currentTarget,progress=document.getElementById('vmOutlinePublishProgress');button.disabled=true;button.textContent='Se pornește…';if(progress)progress.textContent='';try{const job=await api(`/api/v1/vms/${vmID}/outline`,{method:'POST',body:'{}'});pollSingleVMOutlineJob(job.id,button,progress)}catch(err){button.disabled=false;button.textContent='Trimite în Outline';toast(err.message,true)}});
}
function sortNomenclatureValues(values){return [...(values||[])].sort((left,right)=>Number(left.sort_order||0)-Number(right.sort_order||0)||String(left.name||'').localeCompare(String(right.name||''),'ro',{sensitivity:'base'}))}
const serviceUsageLabels={dedicated:'Dedicat',shared:'Partajat',dependency:'Dependență'};
function domainAssignmentOptions(categories,selected){return selectOptions(sortNomenclatureValues(categoryItems(categories,'architectural_domain')),selected,'— Alege domeniul —')}
function categoryAssignmentOptions(categories,domainID,selected){const values=sortNomenclatureValues(categoryItems(categories,'itil_category').filter(item=>Number(item.parent_id)===Number(domainID)));return selectOptions(values,selected,domainID?'— Alege categoria de serviciu —':'— Alege domeniul —')}
function serviceAssignmentOptions(services,selected){const values=[...(services||[])].sort((left,right)=>String(left.name||'').localeCompare(String(right.name||''),'ro',{sensitivity:'base'}));return `<option value="">— Alege serviciul intern —</option>${values.filter(service=>service.active||Number(service.id)===Number(selected)).map(service=>`<option value="${service.id}" ${Number(selected)===Number(service.id)?'selected':''}>${e(service.name)}${service.service_code?` · ${e(service.service_code)}`:''}${service.active?'':' (inactiv)'}</option>`).join('')}`}
function serviceUsageOptions(selected='dedicated'){return Object.entries(serviceUsageLabels).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function solutionTypeAssignmentOptions(categories,selected){return selectOptions(sortNomenclatureValues(categoryItems(categories,'solution_type')),selected,'— Alege tipul soluției —')}
function serviceAssignmentRow(item,services,categories,index){
  const domainID=item?.architectural_domain_id||'',categoryID=item?.itil_category_id||'';
  return `<article class="vm-service-assignment-card" data-index="${index}">
    <div class="vm-service-assignment-head"><div><span class="assignment-kicker">Încadrare ${index+1}</span><strong>${e(item?.internal_service_name||'Serviciu intern nou')}</strong></div><div class="assignment-head-actions"><label class="assignment-primary"><input class="assignment-primary-input" type="checkbox" ${item?.is_primary?'checked':''}><span>Asociere principală</span></label>${can('vms.manage')?'<button type="button" class="small danger remove-service-assignment">Elimină</button>':''}</div></div>
    <div class="assignment-section"><h4>Clasificare serviciu</h4><div class="assignment-grid classification-grid"><label>Domeniu arhitectural<select class="assignment-domain" required>${domainAssignmentOptions(categories,domainID)}</select></label><label>Categorie de serviciu<select class="assignment-category" required>${categoryAssignmentOptions(categories,domainID,categoryID)}</select></label><label>Serviciu intern<select class="assignment-service" required>${serviceAssignmentOptions(services,item?.internal_service_id)}</select></label></div></div>
    <div class="assignment-section"><h4>Arhitectură tehnică</h4><div class="assignment-grid technical-grid"><label>Layer arhitectural<select class="assignment-layer" required></select></label><label>Rol tehnic<select class="assignment-role" required></select></label><label>Tip soluție<select class="assignment-solution-type" required>${solutionTypeAssignmentOptions(categories,item?.solution_type_id)}</select></label></div></div>
    <div class="assignment-section assignment-context"><h4>Context</h4><div class="assignment-grid context-grid"><label>Utilizare<select class="assignment-usage">${serviceUsageOptions(item?.usage_type||'dedicated')}</select></label><label class="assignment-notes">Observații<input class="assignment-note" maxlength="1000" value="${e(item?.notes||'')}" placeholder="Rolul acestei VM în serviciu, particularități, dependențe…"></label></div></div>
  </article>`
}
function wireServiceAssignmentRow(row,services,categories,initial={}){
  const domain=row.querySelector('.assignment-domain'),category=row.querySelector('.assignment-category'),service=row.querySelector('.assignment-service'),layer=row.querySelector('.assignment-layer'),role=row.querySelector('.assignment-role');
  const layers=sortNomenclatureValues(categoryItems(categories,'layer'));
  const roles=categoryItems(categories,'technical_role');
  function fillCategories(selected=''){category.innerHTML=categoryAssignmentOptions(categories,domain.value,selected);category.disabled=!domain.value}
  function fillServices(selected=''){service.innerHTML=serviceAssignmentOptions(services,selected);service.disabled=!category.value}
  function fillLayers(selected=''){let values=layers;if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.layer_name)values=[...values,{id:Number(selected),name:`${initial.layer_name} · inactiv`,active:false}];layer.innerHTML=selectOptions(values,selected,'— Alege layer-ul —')}
  function fillRoles(selected=''){let values=sortNomenclatureValues(roles.filter(item=>(item.layer_ids||[]).some(id=>Number(id)===Number(layer.value))));if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.technical_role)values=[...values,{id:Number(selected),name:`${initial.technical_role} · nemapat`,active:false}];role.innerHTML=selectOptions(values,selected,layer.value?'— Alege rolul tehnic —':'— Alege layer-ul —');role.disabled=!layer.value}
  fillCategories(initial.itil_category_id);fillServices(initial.internal_service_id);fillLayers(initial.layer_id);fillRoles(initial.technical_role_id);
  domain.addEventListener('change',()=>{fillCategories();fillServices()});category.addEventListener('change',()=>fillServices());layer.addEventListener('change',()=>fillRoles());
  service.addEventListener('change',()=>{const title=row.querySelector('.vm-service-assignment-head strong');const selected=services.find(item=>Number(item.id)===Number(service.value));if(title)title.textContent=selected?.name||'Serviciu intern nou'});
}
function serviceAssignmentsSummary(values){
  if(!values?.length)return '<span class="muted">Niciun serviciu intern asociat.</span>';
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie</th><th>Layer / Rol tehnic</th><th>Tip soluție</th><th>Utilizare</th><th></th></tr></thead><tbody>${values.map(item=>`<tr><td><a href="#services/${item.internal_service_id}">${e(item.internal_service_name)}</a></td><td>${e(item.architectural_domain||'—')}<div class="muted">${e(item.itil_category||'—')}</div></td><td>${e(item.layer_name||'—')}<div class="muted">${e(item.technical_role||'—')}</div></td><td>${e(item.solution_type||'—')}</td><td>${e(serviceUsageLabels[item.usage_type]||item.usage_type||'—')}</td><td>${item.is_primary?badge('principal'):''}</td></tr>`).join('')}</tbody></table></div>`;
}

function vmCommonDependencies(vmID,values,services,categories){
  const commonServices=(services||[]).filter(item=>item.active&&item.is_common),types=categoryItems(categories,'dependency_type');
  const form=can('vms.manage')&&commonServices.length&&types.length?`<form id="vmDependencyForm" class="service-dependency-form vm-dependency-form"><label>Serviciu comun<select id="vmDependencyTarget" required><option value="">— Alege serviciul —</option>${commonServices.map(item=>`<option value="${item.id}">${e(item.name)}${item.implicit_global?' · GLOBAL':''}</option>`).join('')}</select></label><label>Tip dependență<select id="vmDependencyType" required>${selectOptions(types,'','— Alege tipul —')}</select></label><label>Detalii<input id="vmDependencyNotes" maxlength="1000" placeholder="Excepție specifică acestei VM"></label><button type="submit">Adaugă direct</button></form>`:'';
  const list=values?.length?`<div class="common-dependency-list">${values.map(dep=>`<div class="common-dependency-item ${dep.global?'global':''}">${nomenclatureIcon(dep.dependency_type_icon||'integration','small')}<div><a href="#services/${dep.target_service_id}"><strong>${e(dep.target_service_name)}</strong></a><span>${e(dep.dependency_type||'Serviciu comun')} · ${dep.global?'Global':dep.direct?'Direct VM':'Comun'}</span><small>${e(dep.source_label||dep.source_service_name||'Dependență directă')}${dep.protocol||dep.port?` · ${dependencyEndpointText(dep)}`:''}${dep.target_vm_names?` · Furnizat de: ${e(dep.target_vm_names)}`:''}${dep.notes?` · ${e(dep.notes)}`:''}</small></div><div class="common-dependency-actions"><b>${dep.target_vm_count||0} VM</b>${dep.direct&&dep.id&&can('vms.manage')?`<button type="button" class="small danger delete-vm-dependency" data-id="${dep.id}">Elimină</button>`:''}</div></div>`).join('')}</div>`:empty('Nu sunt identificate dependențe către infrastructura comună.');
  return `${form}${list}`;
}
function bindVMDependencyActions(vmID){
  document.getElementById('vmDependencyForm')?.addEventListener('submit',async event=>{event.preventDefault();const target=Number(document.getElementById('vmDependencyTarget').value||0),type=Number(document.getElementById('vmDependencyType').value||0),notes=document.getElementById('vmDependencyNotes').value.trim();if(!target||!type){toast('Alege serviciul comun și tipul dependenței.',true);return}try{await api(`/api/v1/vms/${vmID}/dependencies`,{method:'POST',body:JSON.stringify({target_service_id:target,dependency_type_id:type,notes})});toast('Dependența directă a VM-ului a fost adăugată.');vmDetail(vmID)}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.delete-vm-dependency').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Elimini dependența directă de pe această VM?'))return;try{await api(`/api/v1/vms/${vmID}/dependencies/${button.dataset.id}`,{method:'DELETE'});toast('Dependența directă a fost eliminată.');vmDetail(vmID)}catch(err){toast(err.message,true)}}));
}

function bindSupportComponentEditor(editor,vmID){
  if(!editor)return;
  const button=editor.querySelector('.save-support-component');
  if(!button||button.dataset.bound==='true')return;
  button.dataset.bound='true';
  button.addEventListener('click',async event=>{
    event.stopPropagation();
    const serviceName=editor.dataset.service||'',componentName=editor.querySelector('.support-component-name')?.value.trim()||'',versionOverride=editor.querySelector('.support-component-version')?.value.trim()||'',portOverride=editor.querySelector('.support-component-ports')?.value.trim()||'';
    if(!serviceName)return;
    if(!componentName){toast('Completează numele componentei suport.',true);return}
    button.disabled=true;
    try{
      const result=await api(`/api/v1/vms/${vmID}/support-components`,{method:'POST',body:JSON.stringify({service_name:serviceName,component_name:componentName,version_override:versionOverride,port_override:portOverride,enabled:true})});
      const component=result?.component||{service_name:serviceName,component_name:componentName,version_override:versionOverride,port_override:portOverride,version:versionOverride,ports:portOverride};
      const row=editor.closest('.service-inventory-row');
      editor.outerHTML=supportComponentEditorHTML(serviceName,component,{software_name:component.software_name||'',version:component.detected_version||''},true);
      bindSupportComponentEditor(row?.querySelector('.support-component-editor'),vmID);
      toast(`${componentName} salvată ca componentă suport.`);
    }catch(err){button.disabled=false;toast(err.message,true)}
  });
}

function bindPrimaryAgentServiceActions(vmID){
  bindServiceInventoryFilters();
  const reviewed=document.getElementById('vmAgentServicesReviewed');
  reviewed?.addEventListener('change',async()=>{
    try{
      await api(`/api/v1/vms/${vmID}/agent-services/reviewed`,{method:'PUT',body:JSON.stringify({reviewed:reviewed.checked})});
      toast(reviewed.checked?'Categoria Servicii a fost marcată ca verificată.':'Marcajul Servicii verificate a fost eliminat.');
      refreshVMCompletion(vmID);
    }catch(err){reviewed.checked=!reviewed.checked;toast(err.message,true)}
  });
  document.querySelectorAll('.primary-agent-service-toggle').forEach(input=>{
    input.addEventListener('click',event=>event.stopPropagation());
    input.addEventListener('change',async event=>{
      event.stopPropagation();
      const serviceName=input.dataset.service||'';
      try{
        await api(`/api/v1/vms/${vmID}/primary-services`,{method:'POST',body:JSON.stringify({service_name:serviceName,primary:input.checked})});
        toast(input.checked?`${serviceName} marcat ca principal.`:`${serviceName} nu mai este principal.`);refreshVMCompletion(vmID);
      }catch(err){input.checked=!input.checked;toast(err.message,true)}
    });
  });
  document.querySelectorAll('.support-agent-service-toggle').forEach(input=>{
    input.addEventListener('click',event=>event.stopPropagation());
    input.addEventListener('change',async event=>{
      event.stopPropagation();
      const serviceName=input.dataset.service||'',softwareName=input.dataset.software||'',enabled=input.checked,row=input.closest('.service-inventory-row');
      input.disabled=true;
      try{
        const result=await api(`/api/v1/vms/${vmID}/support-components`,{method:'POST',body:JSON.stringify({service_name:serviceName,component_name:guessSupportComponentName(serviceName,softwareName),enabled})});
        if(row){
          row.dataset.serviceSupport=enabled?'true':'false';
          if(enabled){
            row.open=true;
            row.querySelector('.support-component-editor')?.remove();
            const component=result?.component||{service_name:serviceName,component_name:guessSupportComponentName(serviceName,softwareName),software_name:softwareName};
            row.querySelector('summary')?.insertAdjacentHTML('afterend',supportComponentEditorHTML(serviceName,component,{software_name:softwareName,version:component.detected_version||''},true));
            bindSupportComponentEditor(row.querySelector('.support-component-editor'),vmID);
          }else{
            row.querySelector('.support-component-editor')?.remove();
          }
        }
        toast(enabled?`${serviceName} marcat ca componentă suport. Poți modifica acum componenta, versiunea sau portul chiar aici.`:`${serviceName} eliminat din componentele suport.`);
        applyServiceInventoryFilters();
      }catch(err){input.checked=!input.checked;toast(err.message,true)}
      finally{input.disabled=false}
    });
  });
  document.querySelectorAll('.support-component-editor').forEach(editor=>bindSupportComponentEditor(editor,vmID));
}

function bindPrimaryAgentPortActions(vmID){
  bindPortInventoryFilters();
  document.querySelectorAll('.primary-agent-port-toggle').forEach(input=>{
    input.addEventListener('click',event=>event.stopPropagation());
    input.addEventListener('change',async event=>{
      event.stopPropagation();
      const protocol=input.dataset.protocol||'',port=Number(input.dataset.port||0),processName=input.dataset.process||'',label=`${port}/${String(protocol).toUpperCase()}${processName?` · ${processName}`:''}`;
      try{
        await api(`/api/v1/vms/${vmID}/primary-ports`,{method:'POST',body:JSON.stringify({protocol,port,process_name:processName,primary:input.checked})});
        toast(input.checked?`${label} marcat ca principal.`:`${label} nu mai este principal.`);
        const row=input.closest('.port-inventory-row');if(row){if(!input.checked&&row.classList.contains('stale-primary-service'))row.remove();else row.dataset.portStatus=input.checked?'selected':'detected'}applyPortInventoryFilters();refreshVMCompletion(vmID);
      }catch(err){input.checked=!input.checked;toast(err.message,true)}
    });
  });
}

function dockerPortText(ports){
  if(!Array.isArray(ports)||!ports.length)return '—';
  return ports.map(p=>p.host_port?`${e(p.host_ip||'*')}:${p.host_port} → ${p.container_port}/${e(p.protocol||'tcp')}`:`${p.container_port}/${e(p.protocol||'tcp')}`).join('<br>');
}
function dockerAssignmentChips(container){
  const values=Array.isArray(container?.service_assignments)?container.service_assignments:[];
  if(!values.length)return '<span class="muted">Neasociat</span>';
  return `<div class="docker-service-chips">${values.map(a=>`<span class="docker-service-chip ${a.source==='label'?'from-label':''}"><a href="#services/${a.service_id}">${e(a.service_name)}</a>${resourceAssignmentMeta(a)}<small>${a.source==='label'?'label':'manual'}</small>${a.source==='manual'&&can('vms.manage')?`<button type="button" class="docker-remove-service" data-container="${container.id}" data-service="${a.service_id}" title="Elimină asocierea manuală">×</button>`:''}</span>`).join('')}</div>`;
}
function dockerSecurityFlags(c){const flags=[];if(c.privileged)flags.push(badge('privileged'));if(c.docker_socket_mounted)flags.push(badge('docker.sock'));if(c.network_mode==='host')flags.push(badge('host network'));if(c.readonly_rootfs)flags.push(badge('read-only'));return flags.length?flags.join(' '):'<span class="muted">standard</span>'}
function dockerServiceSelect(services,idSuffix,selectedID=null,mixed=false){
  return `<select class="docker-service-select" data-searchable="off" id="docker-service-${idSuffix}"><option value="">${mixed?'— Valori diferite —':'— Serviciu —'}</option>${(services||[]).filter(x=>x.active!==false||Number(x.id)===Number(selectedID)).map(x=>`<option value="${Number(x.id)}" ${Number(x.id)===Number(selectedID)?'selected':''}>${e(x.name)}${x.active===false?' (inactiv)':''}</option>`).join('')}</select>`;
}
// Compose is edited in bulk, but its fields must reflect a saved, common value.
// Mixed or partially configured containers do not pretend they share one assignment.
function composeProjectSavedAssignment(containers){
  const signatures=new Set();
  let populated=0;
  for(const container of containers||[]){
    const values=Array.isArray(container.service_assignments)?container.service_assignments:[];
    const manual=values.filter(a=>a.source==='manual');
    const considered=manual.length?manual:values;
    const unique=new Set(considered.filter(a=>Number(a.service_id)>0).map(a=>[
      Number(a.service_id||0),Number(a.environment_id||0),
      Number(a.operational_status_id||0),Number(a.solution_type_id||0)
    ].join(':')));
    if(unique.size)populated++;
    for(const signature of unique)signatures.add(signature);
  }
  if(!signatures.size)return {assignment:null,mixed:false};
  if(signatures.size!==1||populated!==containers.length)return {assignment:null,mixed:true};
  const [service_id,environment_id,operational_status_id,solution_type_id]=[...signatures][0].split(':').map(Number);
  return {assignment:{service_id,environment_id,operational_status_id,solution_type_id},mixed:false};
}
function resourceDocumentationToggle(cls,dataAttr,id,checked,label='Nu necesită documentare'){return can('vms.manage')?`<label class="resource-exempt-label"><input type="checkbox" class="${cls}" ${dataAttr}="${id}" ${checked?'checked':''}><span>${e(label)}</span></label>`:(checked?'<span class="muted">Nu necesită documentare</span>':'—')}
// 0.21.3 - One stable, readable cell per resource; edit only on demand.
function resourceAssignmentSummary(assignments,exempt){
 if(exempt)return '<span class="resource-documentation-state exempt">Nu necesită documentare</span>';
 if(!Array.isArray(assignments)||!assignments.length)return '<span class="resource-documentation-state missing">Nedocumentat</span>';
 // Keep the actual service as a navigable link; contextual fields are supplementary text.
 return `<div class="resource-summary-values">${assignments.map(a=>{
  const serviceName=String(a.service_name||'').trim(),serviceID=Number(a.service_id||0);
  const service=serviceName?(serviceID>0?`<a class="resource-service-link" href="#services/${serviceID}">${e(serviceName)}</a>`:`<strong>${e(serviceName)}</strong>`):'<span class="muted">Serviciu</span>';
  const context=[a.environment,a.operational_status,a.solution_type].filter(Boolean).map(e).join(' · ');
  return `<span class="resource-summary-assignment">${service}${context?`<span class="resource-summary-context"> · ${context}</span>`:''}</span>`;
 }).join('')}</div>`;
}
function resourceEditorCell(kind,id,item){
 const assignments=item?.service_assignments||[];
 // Instances do not have independent beneficiary assignments: aggregate the beneficiaries
 // of their logical databases, rather than leave a permanent loading placeholder.
 const catalogIDs=kind==='instance'?(Array.isArray(item?.catalogs)?item.catalogs:[]).map(c=>Number(c.id)).filter(id=>Number.isSafeInteger(id)&&id>0):[];
 const beneficiaryAttrs=kind==='instance'?` data-instance-catalog-ids="${catalogIDs.join(',')}"`:'';
 const beneficiaryPlaceholder=kind==='instance'&&!catalogIDs.length?'Beneficiari: —': 'Beneficiari: se încarcă…';
 return `<div class="resource-summary-cell" data-resource-summary="${e(kind)}:${Number(id)}"><div class="resource-summary-service">${resourceAssignmentSummary(assignments,!!item.documentation_exempt)}</div><div class="resource-inline-beneficiaries" data-resource-beneficiaries="${e(kind)}:${Number(id)}"${beneficiaryAttrs}><span class="muted">${beneficiaryPlaceholder}</span></div><button class="small secondary resource-open-editor" type="button" data-kind="${e(kind)}" data-id="${Number(id)}">${can('vms.manage')?'Configurează':'Detalii'}</button></div>`;
}
function resourceInventoryExportButton(kind,vmID){return `<a class="button-link small secondary resource-xlsx-export" href="/api/v1/vms/${Number(vmID)}/resources/export?type=${e(kind)}" download>Export Excel</a>`}
// Remember which Compose inventory section the operator expanded during this page session.
const composeExpandedVMs=new Set();
function bindDockerComposeCollapse(vmID){
 const section=document.getElementById('dockerComposeSection');
 if(!section)return;
 section.addEventListener('toggle',()=>{if(section.open)composeExpandedVMs.add(Number(vmID));else composeExpandedVMs.delete(Number(vmID))});
}
function dockerComposePathRow(path){
 const val=String(path||'').trim();
 return `<div class="docker-compose-path-item"><code title="${e(val)}">${e(val)}</code><button type="button" class="small secondary docker-compose-copy" data-path="${e(val)}" aria-label="Copiază calea" title="Copiază calea">⧉</button></div>`;
}
function dockerComposePathInfo(project){
 const base=String(project?.working_dir||'').trim(),files=[...new Set((Array.isArray(project?.config_files)?project.config_files:[]).map(x=>String(x||'').trim()).filter(Boolean))];
 return `<div class="docker-compose-paths"><div><strong>Director proiect</strong>${base?dockerComposePathRow(base):'<span class="muted">Nedetectat</span>'}</div><div><strong>Fișiere YAML Compose</strong>${files.length?`<div class="docker-compose-path-files">${files.map(dockerComposePathRow).join('')}</div>`:'<span class="muted">Nedetectate în etichetele Docker</span>'}</div></div>`;
}
function dockerObjectsList(items,label){
 const values=(Array.isArray(items)?items:[]).map(x=>String(x||'').trim()).filter(Boolean);
 return `<div class="docker-object-summary"><strong>${e(label)}</strong>${values.length?`<ul class="docker-object-list">${values.map(x=>`<li><span>${e(x)}</span></li>`).join('')}</ul>`:'<span class="muted">—</span>'}</div>`;
}
const dockerFilterStateByVM=new Map();
function dockerResourceFiltersBar(containers,vmID){
 const stateOptions=[...new Set((containers||[]).map(c=>String(c.state||'unknown').trim().toLowerCase()).filter(Boolean))].sort();
 const bar=resourceInventoryFilterBar('docker',containers);
 // Keep a common filter engine, but give Docker a two-row, collapsible presentation.
 const inner=bar.replace(/<div class="filterbar resource-inventory-filterbar">/,'').replace(/<\/div>$/,'');
 const withState=inner.replace('<button type="button" class="secondary" id="dockerResourceFiltersReset">Resetează</button>','').replace('<span class="muted resource-filter-count" id="dockerResourceFilterCount"></span>','')+`<label><span>Stare Docker</span><select id="dockerResourceStateFilter" data-searchable="off"><option value="">Toate</option>${stateOptions.map(x=>`<option value="${e(x)}">${e(x)}</option>`).join('')}</select></label>`;
 return `<section class="docker-filter-section" data-docker-vm="${Number(vmID)}"><div class="docker-filter-summary"><strong>Filtre:</strong><span id="dockerActiveFilterLabels" class="docker-active-filter-labels">Niciun filtru activ</span><button type="button" class="small secondary" id="dockerResourceFiltersReset">Resetează</button><button type="button" class="docker-filter-chevron" id="dockerToggleFilters" aria-label="Extinde filtrele Docker" aria-expanded="false">⌄</button></div><div class="docker-filter-fields" id="dockerFilterFields" hidden><div class="filterbar resource-inventory-filterbar">${withState}</div></div><div class="muted docker-filter-result" id="dockerResourceFilterCount"></div></section>`;
}
// Shared visual stacking contract for VM Docker, Database and Web pages.
function vmResourceSectionLayout(html){return `<div class="vm-resource-layout">${html}</div>`}
function dockerVMSection(view,services,categories){
  const host=view?.host,containers=Array.isArray(view?.containers)?view.containers:[],projects=Array.isArray(view?.compose_projects)?view.compose_projects:[];
  if(!host)return vmResourceSectionLayout(panel('Docker',empty('Nu există încă inventar Docker structurat. Este necesar vm-doc-agent 1.4.0+ și un snapshot Docker utilizabil.')));
  if(!host.installed)return vmResourceSectionLayout(panel('Docker',`<div class="notice docker-install-notice"><strong>Docker nu este instalat pe această VM.</strong><div class="muted">Ultima colectare: ${dt(host.observed_at)}</div></div>`));
  const docControl=can('vms.manage')?`<div class="resource-documentation-control docker-documentation-control"><label class="docker-documentation-check"><input id="dockerDocumentationExempt" type="checkbox" ${host.documentation_exempt?'checked':''}><span>Nu necesită documentare</span></label><span class="muted">Inventarul rămâne vizibil, dar Docker nu mai intră în calculul completitudinii sau în fișa VM.</span></div>`:'';
  const kpis=`<div class="resource-kpis resource-kpis-6"><div class="card"><div class="label">Engine</div><div class="value compact">${e(host.version||'—')}</div><div class="muted">${host.available?badge('running'):badge(host.service_state||'unavailable')}</div></div><div class="card"><div class="label">Containere</div><div class="value">${host.container_count||0}</div><div class="muted">${host.running_count||0} running</div></div><div class="card"><div class="label">Images</div><div class="value">${host.image_count||0}</div></div><div class="card"><div class="label">Networks</div><div class="value">${host.network_count||0}</div></div><div class="card"><div class="label">Volumes</div><div class="value">${host.volume_count||0}</div></div><div class="card"><div class="label">Compose</div><div class="value">${host.compose_project_count||0}</div></div></div>`;
  const projectHTML=projects.length?`<div class="docker-compose-projects">${projects.map((p,index)=>{
    const projectContainers=containers.filter(c=>String(c.compose_project||'').trim()===String(p.name||'').trim());
    const saved=composeProjectSavedAssignment(projectContainers);
    const selected=saved.assignment||{};
    return `<div class="docker-compose-card"><div class="docker-compose-card-main"><div class="docker-compose-project-info"><strong>${e(p.name)}</strong><span>${p.container_count} ${Number(p.container_count)===1?'container':'containere'} · ${e((p.services||[]).join(', ')||'fără servicii Compose')}</span></div>${can('vms.manage')?`<div class="docker-compose-assign resource-assignment"><label class="docker-compose-field"><span>Serviciu</span>${dockerServiceSelect(services,`project-${index}`,selected.service_id,saved.mixed)}</label><label class="docker-compose-field"><span>Mediu</span>${resourceContextSelect(categories,'environment',`docker-environment-project-${index}`,'Mediu',selected.environment_id,saved.mixed)}</label><label class="docker-compose-field"><span>Status operațional</span>${resourceContextSelect(categories,'operational_status',`docker-status-project-${index}`,'Status operațional',selected.operational_status_id,saved.mixed)}</label><label class="docker-compose-field"><span>Tip soluție</span>${resourceContextSelect(categories,'solution_type',`docker-solution-project-${index}`,'Tip soluție',selected.solution_type_id,saved.mixed)}</label><button type="button" class="small secondary docker-assign-project" data-project="${e(p.name)}" data-select="docker-service-project-${index}" data-environment="docker-environment-project-${index}" data-status="docker-status-project-${index}" data-solution="docker-solution-project-${index}">${selected.service_id?'Actualizează':'Asociază'}</button></div>`:''}</div><div class="docker-compose-card-meta">${dockerComposePathInfo(p)}<div class="docker-compose-beneficiaries"><div class="docker-compose-beneficiary-label"><strong>Beneficiari proiect</strong>${can('vms.manage')?`<button type="button" class="small secondary docker-compose-edit-beneficiaries" data-project="${e(p.name)}">Configurează beneficiari…</button>`:''}</div><div class="docker-compose-beneficiary-list" data-compose-beneficiaries="${e(p.name)}"><span class="muted">Se încarcă…</span></div></div></div></div>`;
  }).join('')}</div>`:empty('Nu au fost detectate proiecte Docker Compose.');
  const projectSection=`<details class="panel docker-compose-section" id="dockerComposeSection" ${composeExpandedVMs.has(Number(host.vm_id))?'open':''}><summary class="docker-compose-section-summary"><span class="docker-compose-section-title">Proiecte Docker Compose <span class="docker-compose-count">${projects.length}</span></span><span class="docker-compose-section-hint">${projects.length?'Asocierea unui proiect se aplică tuturor containerelor sale · Click pentru extindere/restrângere':'Niciun proiect detectat'}</span><span class="docker-compose-chevron" aria-hidden="true">⌄</span></summary><div class="docker-compose-section-body">${projectHTML}</div></details>`;
  const filters=dockerResourceFiltersBar(containers,host.vm_id);
  const rows=containers.map((c,index)=>`<tr class="docker-resource-filter-row" data-docker-state="${e(String(c.state||'unknown').toLowerCase())}" ${resourceFilterAttrs(c)}><td><strong>${e(c.name)}</strong> <div class="muted mono">${e((c.engine_container_id||'').slice(0,12))}</div></td><td><span class="mono">${e(c.image||'—')}</span></td><td>${badge(c.state||'unknown')}${c.health?`<div class="muted">health: ${e(c.health)}</div>`:''}</td><td>${c.compose_project?`<strong>${e(c.compose_project)}</strong><div class="muted">${e(c.compose_service||'')}</div>`:'—'}</td><td class="mono">${dockerPortText(c.ports)}</td><td>${dockerSecurityFlags(c)}</td><td class="resource-tools-cell">${resourceEditorCell('docker',c.id,c)}</td></tr>`).join('');
  const inventory=`<details class="docker-details"><summary>Engine și obiecte Docker</summary><div class="detail-grid">${detail('Executable',e(host.executable||'—'),true)}${detail('Service',e(host.service_state||'—'))}${detail('API',e(host.api_version||'—'))}${detail('Storage driver',e(host.storage_driver||'—'))}${detail('Logging driver',e(host.logging_driver||'—'))}${detail('Cgroup',e([host.cgroup_driver,host.cgroup_version].filter(Boolean).join(' / ')||'—'))}${detail('Docker root',e(host.docker_root_dir||'—'),true)}${detail('Ultima observație',dt(host.observed_at))}</div>${dockerObjectsList((view.images||[]).map(i=>(i.repo_tags||[])[0]||i.engine_id),'Images')}${dockerObjectsList((view.networks||[]).map(n=>`${n.name}${n.driver?` (${n.driver})`:''}`),'Networks')}${dockerObjectsList((view.volumes||[]).map(v=>v.name),'Volumes')}</details>`;
  return vmResourceSectionLayout(`${docControl}${kpis}${projectSection}${filters}${panel('Containere Docker',rows?`<div class="table-wrap"><table><thead><tr><th>Container</th><th>Imagine</th><th>Stare</th><th>Compose</th><th>Porturi</th><th>Indicatori</th><th>Documentare / Servicii / Beneficiari</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Docker este instalat, dar nu există containere.'),resourceInventoryExportButton('docker',host.vm_id))}${inventory}`);
}
function dockerManualAssignments(container){return (container?.service_assignments||[]).filter(a=>a.source==='manual').map(a=>({service_id:Number(a.service_id),environment_id:a.environment_id?Number(a.environment_id):null,operational_status_id:a.operational_status_id?Number(a.operational_status_id):null,solution_type_id:a.solution_type_id?Number(a.solution_type_id):null,component_name:a.component_name||'',role_name:a.role_name||'',notes:a.notes||''}))}
function bindDockerActions(vmID,view,services){
  const byID=new Map((view?.containers||[]).map(c=>[Number(c.id),c]));
  bindDockerResourceFilters(vmID);
  document.getElementById('dockerDocumentationExempt')?.addEventListener('change',async event=>{try{await api(`/api/v1/vms/${vmID}/docker/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:event.target.checked})});toast('Setarea de documentare Docker a fost salvată.');if(view?.host)view.host.documentation_exempt=event.target.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);event.target.checked=!event.target.checked}});
  document.querySelectorAll('.docker-container-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const id=Number(input.dataset.container);try{await api(`/api/v1/vms/${vmID}/docker/containers/${id}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare a containerului a fost salvată.');const item=byID.get(id);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  document.querySelectorAll('.docker-add-service').forEach(button=>button.addEventListener('click',async()=>{const cid=Number(button.dataset.container),select=document.getElementById(button.dataset.select),serviceID=Number(select?.value||0);if(!serviceID){toast('Alege un serviciu.',true);return}const environmentID=resourceContextValue(button.dataset.environment),statusID=resourceContextValue(button.dataset.status),solutionTypeID=resourceContextValue(button.dataset.solution);if(!environmentID||!statusID||!solutionTypeID){toast('Alege mediul, statusul operațional și tipul soluției.',true);return}const container=byID.get(cid),assignments=dockerManualAssignments(container),existing=assignments.find(a=>a.service_id===serviceID);if(existing){existing.environment_id=environmentID;existing.operational_status_id=statusID;existing.solution_type_id=solutionTypeID}else assignments.push({service_id:serviceID,environment_id:environmentID,operational_status_id:statusID,solution_type_id:solutionTypeID});try{await api(`/api/v1/vms/${vmID}/docker/containers/${cid}/services`,{method:'PUT',body:JSON.stringify({assignments})});toast('Container asociat serviciului.');vmDetail(vmID,'docker')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.docker-remove-service').forEach(button=>button.addEventListener('click',async()=>{const cid=Number(button.dataset.container),serviceID=Number(button.dataset.service),container=byID.get(cid),assignments=dockerManualAssignments(container).filter(a=>a.service_id!==serviceID);try{await api(`/api/v1/vms/${vmID}/docker/containers/${cid}/services`,{method:'PUT',body:JSON.stringify({assignments})});toast('Asocierea containerului a fost eliminată.');vmDetail(vmID,'docker')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.docker-compose-copy').forEach(button=>button.addEventListener('click',async()=>{
    const path=button.dataset.path||'';try{
      if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(path);
      else {const input=document.createElement('textarea');input.value=path;input.style.position='fixed';input.style.opacity='0';document.body.appendChild(input);input.select();const copied=document.execCommand('copy');input.remove();if(!copied)throw Error('Copiere indisponibilă')}
      toast('Calea a fost copiată.');
    }catch(err){toast(`Copiere eșuată: ${err.message}`,true)}
  }));
  loadDockerComposeBeneficiaries(vmID);
  document.querySelectorAll('.docker-compose-edit-beneficiaries').forEach(button=>button.addEventListener('click',()=>openDockerComposeBeneficiaries(vmID,button.dataset.project)));
  document.querySelectorAll('.docker-assign-project').forEach(button=>button.addEventListener('click',async()=>{const select=document.getElementById(button.dataset.select),serviceID=Number(select?.value||0);if(!serviceID){toast('Alege un serviciu.',true);return}const environmentID=resourceContextValue(button.dataset.environment),statusID=resourceContextValue(button.dataset.status),solutionTypeID=resourceContextValue(button.dataset.solution);if(!environmentID||!statusID||!solutionTypeID){toast('Alege mediul, statusul operațional și tipul soluției.',true);return}try{await api(`/api/v1/vms/${vmID}/docker/compose/${encodeURIComponent(button.dataset.project)}/services`,{method:'PUT',body:JSON.stringify({assignments:[{service_id:serviceID,environment_id:environmentID,operational_status_id:statusID,solution_type_id:solutionTypeID}]})});toast('Proiectul Compose a fost asociat serviciului.');vmDetail(vmID,'docker')}catch(err){toast(err.message,true)}}));
}

function bindDockerResourceFilters(vmID){
 const idMap={service:'dockerResourceServiceFilter',environment:'dockerResourceEnvironmentFilter',status:'dockerResourceStatusFilter',solution:'dockerResourceSolutionFilter',documentation:'dockerResourceDocumentationFilter',unset:'dockerResourceUnsetFilter',state:'dockerResourceStateFilter'};
 const controls=Object.fromEntries(Object.entries(idMap).map(([key,id])=>[key,document.getElementById(id)]));
 const rows=[...document.querySelectorAll('.docker-resource-filter-row')];
 const saved=dockerFilterStateByVM.get(Number(vmID))||{};
 for(const [key,control] of Object.entries(controls)){if(control&&saved[key]&&[...control.options].some(o=>o.value===saved[key]))control.value=saved[key]}
 const section=document.querySelector('.docker-filter-section'),fields=document.getElementById('dockerFilterFields'),arrow=document.getElementById('dockerToggleFilters');
 let opened=!!saved.open;
 const setOpen=(next)=>{opened=!!next;if(fields)fields.hidden=!opened;if(arrow){arrow.textContent=opened?'⌃':'⌄';arrow.setAttribute('aria-expanded',String(opened));arrow.setAttribute('aria-label',opened?'Restrânge filtrele Docker':'Extinde filtrele Docker')}};
 const apply=()=>{
  const selected=Object.fromEntries(Object.entries(controls).map(([key,c])=>[key,c?.value||'']));
  const relevant=['service','environment','status','solution'];
  const hasAssignmentFilters=relevant.some(key=>!!selected[key]);let visible=0;
  for(const row of rows){
   let assignments=[];try{assignments=JSON.parse(row.dataset.resourceAssignments||'[]')}catch{}
   const assignmentMatch=assignments.some(a=>relevant.every(key=>!selected[key]||a[key]===selected[key]));
   const exempt=row.dataset.documentationExempt==='1',complete=row.dataset.resourceComplete==='1';
   const docOK=!selected.documentation||(selected.documentation==='exempt'?exempt:!exempt);
   const confOK=!selected.unset||(selected.unset==='unset'?!complete:complete);
   const stateOK=!selected.state||row.dataset.dockerState===selected.state;
   row.hidden=!((!hasAssignmentFilters||assignmentMatch)&&docOK&&confOK&&stateOK);
   if(!row.hidden)visible++;
  }
  const selectedLabels=Object.entries(controls).filter(([key,c])=>c?.value).map(([key,c])=>{const label=c.closest('label')?.querySelector('span')?.textContent?.trim()||key;const option=c.options[c.selectedIndex]?.textContent?.trim()||c.value;return `<span class="docker-active-chip">${e(label)}: ${e(option)}</span>`});
  const summary=document.getElementById('dockerActiveFilterLabels');if(summary)summary.innerHTML=selectedLabels.length?selectedLabels.join(''):'Niciun filtru activ';
  const count=document.getElementById('dockerResourceFilterCount');if(count)count.textContent=`${visible} din ${rows.length} containere`;
  dockerFilterStateByVM.set(Number(vmID),{...selected,open:opened});
 };
 arrow?.addEventListener('click',()=>{setOpen(!opened);apply()});setOpen(opened);
 Object.values(controls).forEach(control=>control?.addEventListener('change',apply));
 document.getElementById('dockerResourceFiltersReset')?.addEventListener('click',()=>{Object.values(controls).forEach(c=>{if(c)c.value=''});apply()});
 apply();
}
function renderDockerComposeBeneficiaries(vmID,values){
 for(const node of document.querySelectorAll('[data-compose-beneficiaries]')){
  const entries=Array.isArray(values?.[node.dataset.composeBeneficiaries])?values[node.dataset.composeBeneficiaries]:[];
  node.innerHTML=entries.length?entries.map(x=>`<span class="docker-compose-beneficiary-chip" title="${e(String(x.source||'').toUpperCase())}">${e(x.name)}</span>`).join(''):'<span class="muted">Niciun beneficiar asociat</span>';
 }
}
async function loadDockerComposeBeneficiaries(vmID){
 try{const result=await api(`/api/v1/vms/${Number(vmID)}/docker/compose/beneficiaries`);
  if(!document.getElementById('dockerComposeSection'))return;
  renderDockerComposeBeneficiaries(vmID,result.projects||{});
 }catch(err){for(const node of document.querySelectorAll('[data-compose-beneficiaries]'))node.innerHTML='<span class="muted">Beneficiarii nu au putut fi încărcați.</span>'}
}
async function openDockerComposeBeneficiaries(vmID,project){
 const modal=beneficiaryDialog(`Beneficiari Compose · ${project}`,'<p class="muted">Se încarcă beneficiarii…</p>');
 try{
  const [projects,departments,people]=await Promise.all([
   api(`/api/v1/vms/${Number(vmID)}/docker/compose/beneficiaries`),
   api('/api/v1/beneficiaries?type=department'),api('/api/v1/beneficiaries?type=person')
  ]);
  if(!modal.open)return;
  const current=new Set((projects.projects?.[project]||[]).map(x=>`${x.beneficiary_type}:${Number(x.beneficiary_id)}`));
  const items=[...(departments||[]).map(x=>({...x,type:'department'})),...(people||[]).map(x=>({...x,type:'person'}))].filter(x=>x.active);
  const rows=items.map(x=>{const key=`${x.type}:${Number(x.id)}`;return `<label class="docker-compose-beneficiary-option" data-search="${e(`${x.name} ${x.type}`.toLowerCase())}"><input type="checkbox" value="${e(key)}" ${current.has(key)?'checked':''}><span><strong>${e(x.name)}</strong><small>${x.type==='department'?'Departament':'Persoană'} · ${e(String(x.source||'').toUpperCase())}</small></span></label>`}).join('');
  modal.querySelector('.beneficiary-modal-body').innerHTML=`<p class="muted">Asocierea aparține proiectului Compose, rămâne valabilă după recrearea containerelor și se propagă în raportarea beneficiarilor. Nu modifică beneficiarii individuali ai containerelor.</p><input id="dockerComposeBeneficiarySearch" type="search" placeholder="Caută departament sau persoană"><div class="docker-compose-beneficiary-options">${rows||'<span class="muted">Nu există beneficiari activi.</span>'}</div><div class="beneficiary-modal-actions"><button type="button" class="small secondary" id="dockerComposeBeneficiaryCancel">Anulează</button><button type="button" id="dockerComposeBeneficiarySave">Salvează beneficiarii</button></div>`;
  modal.querySelector('#dockerComposeBeneficiaryCancel')?.addEventListener('click',()=>modal.close());
  modal.querySelector('#dockerComposeBeneficiarySearch')?.addEventListener('input',ev=>{const needle=ev.target.value.toLowerCase().trim();modal.querySelectorAll('.docker-compose-beneficiary-option').forEach(row=>{row.hidden=!row.dataset.search.includes(needle)})});
  modal.querySelector('#dockerComposeBeneficiarySave')?.addEventListener('click',async ev=>{
   const selected=[...modal.querySelectorAll('.docker-compose-beneficiary-option input:checked')].map(x=>{const [beneficiary_type,id]=x.value.split(':');return {beneficiary_type,beneficiary_id:Number(id)}});
   const button=ev.currentTarget;button.disabled=true;
   try{await api(`/api/v1/vms/${Number(vmID)}/docker/compose/${encodeURIComponent(project)}/beneficiaries`,{method:'PUT',body:JSON.stringify({beneficiaries:selected})});modal.close();await loadDockerComposeBeneficiaries(vmID);toast('Beneficiarii proiectului Compose au fost salvați.');paintResourceBeneficiaries(vmID,['docker'])}
   catch(err){toast(err.message,true);button.disabled=false}
  });
 }catch(err){if(modal.open)modal.querySelector('.beneficiary-modal-body').textContent=err.message}
}

function databaseEndpointText(values){
  if(!Array.isArray(values)||!values.length)return '—';
  return values.map(x=>{const addr=x.address||'';const port=x.port||'';if(addr&&port)return `${e(addr)}:${port}`;if(port)return `port ${port}`;return e(addr||'—')}).join('<br>');
}
function databaseCatalogReasonLabel(reason){
  const labels={authentication_required:'Autentificare necesară',permission_denied:'Permisiuni insuficiente',socket_unavailable:'Socket local indisponibil',server_unavailable:'Server DB indisponibil',client_not_found:'Client DB lipsă',timeout:'Timeout la interogare',os_user_unavailable:'Utilizator OS indisponibil',user_switch_unavailable:'Schimbarea userului OS nu este disponibilă',maintenance_database_missing:'Baza tehnică postgres/template1 nu este disponibilă',query_failed:'Interogarea catalogului a eșuat',unsupported_engine:'Enumerare catalog nesuportată'};
  return labels[String(reason||'').trim()]||String(reason||'').trim();
}
function databaseCatalogDiscoveryCell(x){
  const discovered=x?.catalog_discovery_status==='discovered';
  if(discovered)return `${badge('discovered')}<div class="muted">${(x.catalogs||[]).length} baze</div>`;
  const reason=databaseCatalogReasonLabel(x?.catalog_discovery_reason);
  return `<span class="muted">metadata only</span>${reason?`<div class="muted"><strong>Motiv:</strong> ${e(reason)}</div>`:''}<div class="muted">${(x.catalogs||[]).length} baze</div>`;
}
function databaseScheduledJobDiscoveryCell(x){
  const jobs=Array.isArray(x?.scheduled_jobs)?x.scheduled_jobs:[],status=String(x?.scheduled_job_discovery_status||'').trim();
  if(status==='discovered')return `${badge('discovered')}<div class="muted">${jobs.length} joburi</div>`;
  if(status==='not_detected')return '<span class="muted">Nedetectat</span><div class="muted">0 joburi</div>';
  if(!status)return '<span class="muted">agent anterior 1.6.10</span>';
  const reason=databaseCatalogReasonLabel(x?.scheduled_job_discovery_reason),label=status==='partial'?'Parțial':'metadata only';
  return `<span class="muted">${e(label)}</span>${reason?`<div class="muted"><strong>Motiv:</strong> ${e(reason)}</div>`:''}<div class="muted">${jobs.length} joburi</div>`;
}
function databaseScheduledJobs(instances){
  return (Array.isArray(instances)?instances:[]).flatMap(instance=>(Array.isArray(instance.scheduled_jobs)?instance.scheduled_jobs:[]).map(job=>({...job,_instance:instance})));
}
function databaseScheduledJobState(job){
  if(job?.enabled===true)return badge('active');
  if(job?.enabled===false)return badge('disabled');
  return '<span class="muted">—</span>';
}
function databaseScheduledJobSummary(values){
  const jobs=Array.isArray(values)?values:[];if(!jobs.length)return '—';
  const schedulers=[...new Set(jobs.map(x=>x.scheduler).filter(Boolean))];
  return `<strong>${jobs.length}</strong><div class="muted">${e(schedulers.join(', ')||'PostgreSQL')}</div>`;
}
function databaseServiceSelect(services,idSuffix){return `<select class="database-service-select" id="database-service-${idSuffix}"><option value="">— Serviciu —</option>${(services||[]).filter(x=>x.active!==false).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('')}</select>`}
function databaseAssignments(value,type){
  const values=Array.isArray(value?.service_assignments)?value.service_assignments:[];
  if(!values.length)return '<span class="muted">Neasociat</span>';
  const attr=type==='catalog'?'catalog':'instance';
  return `<div class="docker-service-chips">${values.map(a=>`<span class="docker-service-chip"><a href="#services/${a.service_id}">${e(a.service_name)}</a>${resourceAssignmentMeta(a)}${can('vms.manage')?`<button type="button" class="database-remove-service" data-type="${attr}" data-object="${value.id}" data-service="${a.service_id}" title="Elimină asocierea">×</button>`:''}</span>`).join('')}</div>`;
}
// Database instance origin is reported by agent 1.7.16+ and kept distinct
// from the installation-wide engine inventory.
function databaseInstanceOriginCell(x,vmID){
  const origin=String(x.origin||'').trim().toLowerCase();
  if(origin==='docker'){
    const label=String(x.container_name||x.container_id||'container Docker');
    const shortID=String(x.container_id||'').slice(0,12);
    return `<span class="badge">Docker</span><div><a href="#vms/${Number(vmID)}/docker" title="Deschide inventarul Docker al VM">${e(label)}</a></div>${shortID?`<div class="muted mono">${e(shortID)}</div>`:''}${x.compose_project?`<div class="muted">Compose: ${e(x.compose_project)}</div>`:''}${x.container_image?`<div class="muted mono">${e(x.container_image)}</div>`:''}`;
  }
  if(origin==='native')return '<span class="badge">Nativ</span>';
  return '<span class="muted">Nespecificat (agent anterior)</span>';
}
function databaseInstanceReplicaCell(x){
  const fields=[x.replica_set?`Replica Set: ${e(x.replica_set)}`:'',x.replica_role?`Rol: ${e(x.replica_role)}`:'',x.replica_primary?`PRIMARY: ${e(x.replica_primary)}`:''].filter(Boolean);
  return fields.length?`<div class="database-replica-info">${fields.join('<br>')}</div>`:'';
}
// Database filtering uses the same collapsible, persistent UI contract as Docker.
const databaseFilterStateByVM=new Map();
function databaseResourceFiltersBar(instances,catalogs,vmID){
 const resources=[...instances,...catalogs];
 const original=resourceInventoryFilterBar('database',resources);
 const inner=original.replace(/<div class="filterbar resource-inventory-filterbar">/,'').replace(/<\/div>$/,'');
 const engineOptions=[...new Set(instances.map(x=>String(x.product||x.engine||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
 const stateOptions=[...new Set(instances.map(x=>String(x.status||'unknown').trim().toLowerCase()).filter(Boolean))].sort();
 const extra=`<label><span>Motor DB</span><select id="databaseResourceEngineFilter" data-searchable="off"><option value="">Toate</option>${engineOptions.map(v=>`<option value="${e(v)}">${e(v)}</option>`).join('')}</select></label><label><span>Stare instanță</span><select id="databaseResourceEngineStateFilter" data-searchable="off"><option value="">Toate</option>${stateOptions.map(v=>`<option value="${e(v)}">${e(v)}</option>`).join('')}</select></label>`;
 const controls=inner.replace('<button type="button" class="secondary" id="databaseResourceFiltersReset">Resetează</button>','').replace('<span class="muted resource-filter-count" id="databaseResourceFilterCount"></span>','')+extra;
 return `<section class="database-filter-section" data-database-vm="${Number(vmID)}"><div class="database-filter-summary"><strong>Filtre:</strong><span id="databaseActiveFilterLabels" class="database-active-filter-labels">Niciun filtru activ</span><button type="button" class="small secondary" id="databaseResourceFiltersReset">Resetează</button><button type="button" class="database-filter-chevron" id="databaseToggleFilters" aria-label="Extinde filtrele bazelor de date" aria-expanded="false">⌄</button></div><div class="database-filter-fields" id="databaseFilterFields" hidden><div class="filterbar resource-inventory-filterbar">${controls}</div></div><div class="muted database-filter-result" id="databaseResourceFilterCount"></div></section>`;
}
function bindDatabaseResourceFilters(vmID){
 const idMap={service:'databaseResourceServiceFilter',environment:'databaseResourceEnvironmentFilter',status:'databaseResourceStatusFilter',solution:'databaseResourceSolutionFilter',documentation:'databaseResourceDocumentationFilter',unset:'databaseResourceUnsetFilter',engine:'databaseResourceEngineFilter',engineState:'databaseResourceEngineStateFilter'};
 const controls=Object.fromEntries(Object.entries(idMap).map(([key,id])=>[key,document.getElementById(id)]));
 const rows=[...document.querySelectorAll('.database-resource-filter-row')];
 const saved=databaseFilterStateByVM.get(Number(vmID))||{};
 for(const [key,control] of Object.entries(controls))if(control&&saved[key]&&[...control.options].some(o=>o.value===saved[key]))control.value=saved[key];
 const fields=document.getElementById('databaseFilterFields'),arrow=document.getElementById('databaseToggleFilters');
 let opened=!!saved.open;
 const setOpen=(next)=>{opened=!!next;if(fields)fields.hidden=!opened;if(arrow){arrow.textContent=opened?'⌃':'⌄';arrow.setAttribute('aria-expanded',String(opened));arrow.setAttribute('aria-label',opened?'Restrânge filtrele bazelor de date':'Extinde filtrele bazelor de date')}};
 const apply=()=>{
  const selected=Object.fromEntries(Object.entries(controls).map(([key,c])=>[key,c?.value||'']));
  const relevant=['service','environment','status','solution'];
  const hasAssignmentFilters=relevant.some(key=>!!selected[key]);let instanceVisible=0,catalogVisible=0,instanceTotal=0,catalogTotal=0;
  for(const row of rows){
   let assignments=[];try{assignments=JSON.parse(row.dataset.resourceAssignments||'[]')}catch{}
   const assignmentMatch=assignments.some(a=>relevant.every(key=>!selected[key]||a[key]===selected[key]));
   // The checkbox may have been changed without a full VM reload.
   const exempt=row.querySelector('.resource-exempt-label input')?.checked??row.dataset.documentationExempt==='1';
   const complete=row.dataset.resourceComplete==='1';
   const docOK=!selected.documentation||(selected.documentation==='exempt'?exempt:!exempt);
   const confOK=!selected.unset||(selected.unset==='unset'?!complete:complete);
   const engineOK=!selected.engine||row.dataset.dbEngine===selected.engine;
   const stateOK=!selected.engineState||row.dataset.dbState===selected.engineState;
   row.hidden=!((!hasAssignmentFilters||assignmentMatch)&&docOK&&confOK&&engineOK&&stateOK);
   if(row.dataset.dbKind==='catalog'){catalogTotal++;if(!row.hidden)catalogVisible++}else{instanceTotal++;if(!row.hidden)instanceVisible++}
  }
  const labels=Object.entries(controls).filter(([key,c])=>c?.value).map(([key,c])=>{const label=c.closest('label')?.querySelector('span')?.textContent?.trim()||key;const option=c.options[c.selectedIndex]?.textContent?.trim()||c.value;return `<span class="docker-active-chip">${e(label)}: ${e(option)}</span>`});
  const summary=document.getElementById('databaseActiveFilterLabels');if(summary)summary.innerHTML=labels.length?labels.join(''):'Niciun filtru activ';
  const count=document.getElementById('databaseResourceFilterCount');if(count)count.textContent=`${instanceVisible} din ${instanceTotal} instanțe · ${catalogVisible} din ${catalogTotal} baze logice`;
  databaseFilterStateByVM.set(Number(vmID),{...selected,open:opened});
 };
 arrow?.addEventListener('click',()=>{setOpen(!opened);apply()});setOpen(opened);
 Object.values(controls).forEach(control=>control?.addEventListener('change',apply));
 document.getElementById('databaseResourceFiltersReset')?.addEventListener('click',()=>{Object.values(controls).forEach(control=>{if(control)control.value=''});apply()});
 apply();
}
function databaseVMSection(view,services,categories){
  const host=view?.host,engines=Array.isArray(view?.engines)?view.engines:[],instances=Array.isArray(view?.instances)?view.instances:[];
  if(!host)return vmResourceSectionLayout(panel('Baze de date',empty('Nu există încă inventar de baze de date structurat. Este necesar vm-doc-agent 1.5.0+ și un snapshot cu collectorul databases.')));
  const catalogs=instances.flatMap(i=>(i.catalogs||[]).filter(c=>!c.system).map(c=>({...c,_instance:i}))),scheduledJobs=databaseScheduledJobs(instances),filters=databaseResourceFiltersBar(instances,catalogs,host.vm_id);
  const products=[...new Set(engines.map(x=>x.product||x.engine).filter(Boolean))];
  const kpis=`<div class="resource-kpis ${scheduledJobs.length?'resource-kpis-6':'resource-kpis-5'}"><div class="card"><div class="label">Engine-uri</div><div class="value">${host.engine_count||0}</div></div><div class="card"><div class="label">Instanțe</div><div class="value">${host.instance_count||0}</div></div><div class="card"><div class="label">Baze aplicație</div><div class="value">${catalogs.length}</div></div>${scheduledJobs.length?`<div class="card"><div class="label">Joburi PostgreSQL</div><div class="value">${scheduledJobs.length}</div></div>`:''}<div class="card"><div class="label">Produse</div><div class="value compact">${e(products.join(', ')||'—')}</div></div><div class="card"><div class="label">Ultima observație</div><div class="value compact">${dt(host.observed_at)}</div></div></div>`;
  const engineRows=engines.map(x=>`<tr><td><strong>${e(x.product||x.engine)}</strong><div class="muted mono">${e(x.engine)}</div></td><td>${e(shortVersionText(x.version)||'—')}</td><td class="mono">${e(x.executable||'—')}</td><td>${(x.sources||[]).map(e).join('<br>')||'—'}</td></tr>`).join('');
  const instanceRows=instances.map((x,index)=>`<tr class="database-resource-filter-row" data-db-kind="instance" data-db-engine="${e(String(x.product||x.engine||'').trim())}" data-db-state="${e(String(x.status||'unknown').trim().toLowerCase())}" ${resourceFilterAttrs(x)}><td><strong>${e(x.product||x.engine)}</strong><div class="muted mono">${e(x.engine)}</div></td><td><strong>${e(x.instance_name||'implicit')}</strong><div class="muted">${e(x.service_name||'')}</div>${x.data_dir?`<div class="muted mono">${e(x.data_dir)}</div>`:''}</td><td>${databaseInstanceOriginCell(x,host.vm_id)}${databaseInstanceReplicaCell(x)}</td><td>${e(shortVersionText(x.version)||'—')}</td><td>${badge(x.status||'unknown')}</td><td class="mono">${databaseEndpointText(x.endpoints)}${(x.socket_paths||[]).length?`<div class="muted">socket: ${(x.socket_paths||[]).map(e).join('<br>')}</div>`:''}</td><td>${databaseCatalogDiscoveryCell(x)}</td>${scheduledJobs.length?`<td>${x.engine==='postgresql'?databaseScheduledJobDiscoveryCell(x):'—'}</td>`:''}<td class="resource-tools-cell">${resourceEditorCell('instance',x.id,x)}</td></tr>`).join('');
  const catalogRows=catalogs.map((c,index)=>`<tr class="database-resource-filter-row" data-db-kind="catalog" data-db-engine="${e(String(c._instance.product||c._instance.engine||'').trim())}" data-db-state="${e(String(c._instance.status||'unknown').trim().toLowerCase())}" ${resourceFilterAttrs(c)}><td><strong>${e(c.name)}</strong> ${c.system?' <span class="muted">(system)</span>':''}</td><td>${e(c._instance.product||c._instance.engine)}</td><td>${e(c._instance.instance_name||'implicit')}<div class="muted">${c._instance.origin==='docker'?`Docker: ${e(c._instance.container_name||c._instance.container_id||'container')}`:c._instance.origin==='native'?'Nativ':''}</div></td><td>${e(c.kind||'database')}</td><td class="resource-tools-cell">${resourceEditorCell('database',c.id,c)}</td></tr>`).join('');
  const jobRows=scheduledJobs.map(job=>{const x=job._instance||{},db=[job.database,job.username].filter(Boolean).map(e).join(' / ')||'—',times=[job.next_run?`Următoarea: ${e(job.next_run)}`:'',job.last_run?`Ultima: ${e(job.last_run)}`:''].filter(Boolean).join('<br>')||'—';return `<tr><td><strong>${e(job.scheduler||'PostgreSQL')}</strong></td><td><strong>${e(job.name||('job '+(job.job_id||''))||'—')}</strong>${job.job_id?`<div class="muted mono">ID ${e(job.job_id)}</div>`:''}</td><td>${e(x.instance_name||'implicit')}<div class="muted">${e(shortVersionText(x.version)||cleanVersionText(x.version)||'')}</div></td><td class="mono">${e(job.schedule||'—')}</td><td>${db}</td><td>${e(job.source_database||'—')}</td><td>${databaseScheduledJobState(job)}</td><td>${times}</td></tr>`}).join('');
  const engineSection=`<details class="docker-details database-engine-details"><summary>Engine-uri detectate <span class="muted">(${engines.length})</span></summary>${engineRows?`<div class="table-wrap"><table><thead><tr><th>Produs</th><th>Versiune</th><th>Executabil</th><th>Surse detecție</th></tr></thead><tbody>${engineRows}</tbody></table></div>`:empty('Nu au fost detectate engine-uri de baze de date.')}</details>`;
  const jobsSection=scheduledJobs.length?panel('Joburi programate PostgreSQL',`<div class="table-wrap"><table><thead><tr><th>Scheduler</th><th>Job</th><th>Instanță</th><th>Program</th><th>DB / user</th><th>Catalog sursă</th><th>Stare</th><th>Execuții</th></tr></thead><tbody>${jobRows}</tbody></table></div>`,'<span class="muted">Sunt inventariate numai metadatele schedulerului. SQL-ul, comenzile și scripturile joburilor nu sunt colectate.</span>'):'';
  return vmResourceSectionLayout(`${kpis}${filters}${panel('Instanțe baze de date',instanceRows?`<div class="table-wrap"><table><thead><tr><th>Engine</th><th>Instanță</th><th>Origine / cluster</th><th>Versiune</th><th>Stare</th><th>Endpoint / socket</th><th>Catalog</th>${scheduledJobs.length?'<th>Joburi DB</th>':''}<th>Documentare / Servicii</th></tr></thead><tbody>${instanceRows}</tbody></table></div>`:empty('Nu există instanțe active detectate.'),'<span class="muted">Instanțele PostgreSQL sunt tratate separat după port, data directory și socket.</span>')}${panel('Baze de date logice',catalogRows?`<div class="table-wrap"><table><thead><tr><th>Bază</th><th>Engine</th><th>Instanță</th><th>Tip</th><th>Documentare / Servicii / Beneficiari</th></tr></thead><tbody>${catalogRows}</tbody></table></div>`:empty('Numele bazelor nu au putut fi enumerate fără credențiale locale sau instanțele nu conțin baze vizibile.'),resourceInventoryExportButton('databases',host.vm_id))}${jobsSection}${engineSection}`);
}
function databaseAssignmentInputs(value){return (value?.service_assignments||[]).map(a=>({service_id:Number(a.service_id),environment_id:a.environment_id?Number(a.environment_id):null,operational_status_id:a.operational_status_id?Number(a.operational_status_id):null,solution_type_id:a.solution_type_id?Number(a.solution_type_id):null,component_name:a.component_name||'',role_name:a.role_name||'',notes:a.notes||''}))}
function bindDatabaseActions(vmID,view,services){
  const instances=new Map((view?.instances||[]).map(x=>[Number(x.id),x])),catalogs=new Map();
  bindDatabaseResourceFilters(vmID);(view?.instances||[]).forEach(i=>(i.catalogs||[]).forEach(c=>catalogs.set(Number(c.id),c)));
  document.querySelectorAll('.database-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const id=Number(input.dataset.instance);try{await api(`/api/v1/vms/${vmID}/databases/instances/${id}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare a instanței a fost salvată.');const item=instances.get(id);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  document.querySelectorAll('.database-catalog-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const id=Number(input.dataset.catalog);try{await api(`/api/v1/vms/${vmID}/databases/catalogs/${id}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare a bazei a fost salvată.');const item=catalogs.get(id);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  
  const target=(type,id)=>type==='catalog'?catalogs.get(Number(id)):instances.get(Number(id));
  const endpoint=(type,id)=>type==='catalog'?`/api/v1/vms/${vmID}/databases/catalogs/${id}/services`:`/api/v1/vms/${vmID}/databases/instances/${id}/services`;
  document.querySelectorAll('.database-add-service').forEach(button=>button.addEventListener('click',async()=>{const type=button.dataset.type,id=Number(button.dataset.object),select=document.getElementById(button.dataset.select),serviceID=Number(select?.value||0);if(!serviceID){toast('Alege un serviciu.',true);return}const environmentID=resourceContextValue(button.dataset.environment),statusID=resourceContextValue(button.dataset.status),solutionTypeID=resourceContextValue(button.dataset.solution);if(!environmentID||!statusID||!solutionTypeID){toast('Alege mediul, statusul operațional și tipul soluției.',true);return}const value=target(type,id),assignments=databaseAssignmentInputs(value),existing=assignments.find(a=>a.service_id===serviceID);if(existing){existing.environment_id=environmentID;existing.operational_status_id=statusID;existing.solution_type_id=solutionTypeID}else assignments.push({service_id:serviceID,environment_id:environmentID,operational_status_id:statusID,solution_type_id:solutionTypeID});try{await api(endpoint(type,id),{method:'PUT',body:JSON.stringify({assignments})});toast(type==='catalog'?'Baza a fost asociată serviciului.':'Instanța a fost asociată serviciului.');vmDetail(vmID,'databases')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.database-remove-service').forEach(button=>button.addEventListener('click',async()=>{const type=button.dataset.type,id=Number(button.dataset.object),serviceID=Number(button.dataset.service),value=target(type,id),assignments=databaseAssignmentInputs(value).filter(a=>a.service_id!==serviceID);try{await api(endpoint(type,id),{method:'PUT',body:JSON.stringify({assignments})});toast('Asocierea a fost eliminată.');vmDetail(vmID,'databases')}catch(err){toast(err.message,true)}}));
}
function serviceDatabasePanel(resources,serviceID){
  const values=Array.isArray(resources)?resources:[];if(!values.length)return empty('Nu există baze de date sau instanțe asociate acestui serviciu. Asocierea se face din fila Baze de date a VM-ului gazdă.');
  const rows=values.map(x=>{const assigned=(x.service_assignments||[]).filter(a=>Number(a.service_id)===Number(serviceID));const role=assigned.map(a=>[a.environment?environmentDisplay(a.environment):'',a.operational_status,a.solution_type,a.component_name,a.role_name].filter(Boolean).map(e).join(' · ')).filter(Boolean).join('<br>')||'—';return `<tr><td><a href="#vms/${x.vm_id}/databases"><strong>${e(x.vm_hostname||x.vm_name)}</strong></a></td><td>${e(x.product||x.engine)}</td><td>${e(x.instance_name||'implicit')}${x.origin==='docker'?`<div class="muted">Docker: ${e(x.container_name||String(x.container_id||'').slice(0,12)||'container')}</div>`:''}${x.replica_set?`<div class="muted">${e(x.replica_set)}${x.replica_role?` · ${e(x.replica_role)}`:''}</div>`:''}</td><td>${x.resource_type==='database'?`<strong>${e(x.database_name)}</strong>`:'<span class="muted">întreaga instanță</span>'}</td><td class="mono">${databaseEndpointText(x.endpoints)}</td><td>${badge(x.status||'unknown')}</td><td>${databaseScheduledJobSummary(x.scheduled_jobs)}</td><td>${role}</td></tr>`}).join('');
  return `<div class="table-wrap"><table><thead><tr><th>VM gazdă</th><th>Engine</th><th>Instanță</th><th>Bază</th><th>Endpoint</th><th>Stare</th><th>Joburi DB</th><th>Mediu / status / tip soluție / componentă / rol</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

function serviceDockerPanel(containers,serviceID){
  const values=Array.isArray(containers)?containers:[];if(!values.length)return empty('Nu există containere Docker asociate acestui serviciu. Asocierea se face din fila Docker a VM-ului gazdă sau prin labels vm-doc.service / vm-doc.services.');
  const rows=values.map(c=>{const related=(c.service_assignments||[]).filter(a=>Number(a.service_id)===Number(serviceID));const mine=related.map(a=>`${a.environment?`${e(environmentDisplay(a.environment))} · `:''}${a.operational_status?`${e(a.operational_status)} · `:''}${a.solution_type?`${e(a.solution_type)} · `:''}${e(a.component_name||'')}${a.role_name?` · ${e(a.role_name)}`:''}${a.source?` <span class="muted">(${e(a.source)})</span>`:''}`).filter(Boolean).join('<br>');return `<tr><td><a href="#vms/${c.vm_id}/docker"><strong>${e(c.vm_hostname||c.vm_name)}</strong></a></td><td><strong>${e(c.name)}</strong></td><td class="mono">${e(c.image||'—')}</td><td>${c.compose_project?`${e(c.compose_project)} / ${e(c.compose_service||'')}`:'—'}</td><td>${badge(c.state||'unknown')}${c.health?`<div class="muted">${e(c.health)}</div>`:''}</td><td>${dockerPortText(c.ports)}</td><td>${mine||'—'}</td></tr>`}).join('');return `<div class="table-wrap"><table><thead><tr><th>VM gazdă</th><th>Container</th><th>Imagine</th><th>Compose</th><th>Stare</th><th>Porturi</th><th>Mediu / status / tip soluție / componentă / rol</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

function webBindingText(values){
  if(!Array.isArray(values)||!values.length)return '—';
  return values.map(x=>{const address=x.address||'*',protocol=x.protocol||((x.tls)?'https':'http'),port=x.port?`:${x.port}`:'';return `${e(protocol)}://${e(address)}${port}`}).join('<br>');
}
function webAssignmentChips(site){
  const values=Array.isArray(site?.service_assignments)?site.service_assignments:[];
  if(!values.length)return '<span class="muted">Neasociat</span>';
  return `<div class="docker-service-chips">${values.map(a=>`<span class="docker-service-chip"><a href="#services/${a.service_id}">${e(a.service_name)}</a>${resourceAssignmentMeta(a)}${can('vms.manage')?`<button type="button" class="web-remove-service" data-site="${site.id}" data-service="${a.service_id}" title="Elimină asocierea">×</button>`:''}</span>`).join('')}</div>`;
}
function webServiceSelect(services,idSuffix){return `<select class="web-service-select" id="web-service-${idSuffix}"><option value="">— Serviciu —</option>${(services||[]).filter(x=>x.active!==false).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('')}</select>`}
function webSiteTarget(site){
  const values=[];
  if(site.document_root)values.push(`<strong>root:</strong> <span class="mono">${e(site.document_root)}</span>`);
  if(Array.isArray(site.backends)&&site.backends.length)values.push(`<strong>backend:</strong> ${site.backends.map(e).join(', ')}`);
  if(Array.isArray(site.proxy_targets)&&site.proxy_targets.length)values.push(`<strong>proxy:</strong> ${site.proxy_targets.map(x=>`<span class="mono">${e(x)}</span>`).join('<br>')}`);
  return values.length?values.join('<br>'):'—';
}
// Web uses the same persistent, collapsible filter contract as Docker and DB.
const webFilterStateByVM=new Map();
function webResourceFiltersBar(sites,vmID){
 const original=resourceInventoryFilterBar('web',sites);
 const inner=original.replace(/<div class="filterbar resource-inventory-filterbar">/,'').replace(/<\/div>$/,'');
 const products=[...new Set(sites.map(x=>String(x.product||x.engine||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
 const engine=`<label><span>Motor Web</span><select id="webResourceEngineFilter" data-searchable="off"><option value="">Toate</option>${products.map(x=>`<option value="${e(x)}">${e(x)}</option>`).join('')}</select></label>`;
 const enabled=`<label><span>Stare site</span><select id="webResourceStateFilter" data-searchable="off"><option value="">Toate</option><option value="active">Activ</option><option value="disabled">Inactiv</option></select></label>`;
 const controls=inner.replace('<button type="button" class="secondary" id="webResourceFiltersReset">Resetează</button>','').replace('<span class="muted resource-filter-count" id="webResourceFilterCount"></span>','')+engine+enabled;
 return `<section class="web-filter-section" data-web-vm="${Number(vmID)}"><div class="web-filter-summary"><strong>Filtre:</strong><span id="webActiveFilterLabels" class="web-active-filter-labels">Niciun filtru activ</span><button type="button" class="small secondary" id="webResourceFiltersReset">Resetează</button><button type="button" class="web-filter-chevron" id="webToggleFilters" aria-label="Extinde filtrele Web" aria-expanded="false">⌄</button></div><div class="web-filter-fields" id="webFilterFields" hidden><div class="filterbar resource-inventory-filterbar">${controls}</div></div><div class="muted web-filter-result" id="webResourceFilterCount"></div></section>`;
}
function bindWebResourceFilters(vmID){
 const ids={service:'webResourceServiceFilter',environment:'webResourceEnvironmentFilter',status:'webResourceStatusFilter',solution:'webResourceSolutionFilter',documentation:'webResourceDocumentationFilter',unset:'webResourceUnsetFilter',engine:'webResourceEngineFilter',siteState:'webResourceStateFilter'};
 const controls=Object.fromEntries(Object.entries(ids).map(([key,id])=>[key,document.getElementById(id)]));
 const rows=[...document.querySelectorAll('.web-resource-filter-row')],saved=webFilterStateByVM.get(Number(vmID))||{};
 for(const [key,c] of Object.entries(controls))if(c&&saved[key]&&[...c.options].some(o=>o.value===saved[key]))c.value=saved[key];
 const fields=document.getElementById('webFilterFields'),arrow=document.getElementById('webToggleFilters');let opened=!!saved.open;
 const setOpen=next=>{opened=!!next;if(fields)fields.hidden=!opened;if(arrow){arrow.textContent=opened?'⌃':'⌄';arrow.setAttribute('aria-expanded',String(opened));arrow.setAttribute('aria-label',opened?'Restrânge filtrele Web':'Extinde filtrele Web')}};
 const apply=()=>{
  const selected=Object.fromEntries(Object.entries(controls).map(([key,c])=>[key,c?.value||''])),keys=['service','environment','status','solution'];
  const hasAssignment=keys.some(key=>!!selected[key]);let visible=0;
  for(const row of rows){
   let assignments=[];try{assignments=JSON.parse(row.dataset.resourceAssignments||'[]')}catch{}
   const assignmentOK=!hasAssignment||assignments.some(a=>keys.every(key=>!selected[key]||a[key]===selected[key]));
   const exempt=row.querySelector('.resource-exempt-label input')?.checked??row.dataset.documentationExempt==='1';
   const complete=row.dataset.resourceComplete==='1';
   const docOK=!selected.documentation||(selected.documentation==='exempt'?exempt:!exempt);
   const configuredOK=!selected.unset||(selected.unset==='unset'?!complete:complete);
   const engineOK=!selected.engine||row.dataset.webEngine===selected.engine;
   const statusOK=!selected.siteState||row.dataset.webState===selected.siteState;
   row.hidden=!(assignmentOK&&docOK&&configuredOK&&engineOK&&statusOK);if(!row.hidden)visible++;
  }
  const labels=Object.entries(controls).filter(([key,c])=>c?.value).map(([key,c])=>{const label=c.closest('label')?.querySelector('span')?.textContent?.trim()||key;const value=c.options[c.selectedIndex]?.textContent?.trim()||c.value;return `<span class="docker-active-chip">${e(label)}: ${e(value)}</span>`});
  const summary=document.getElementById('webActiveFilterLabels');if(summary)summary.innerHTML=labels.length?labels.join(''):'Niciun filtru activ';
  const count=document.getElementById('webResourceFilterCount');if(count)count.textContent=`${visible} din ${rows.length} site-uri / frontends`;
  webFilterStateByVM.set(Number(vmID),{...selected,open:opened});
 };
 arrow?.addEventListener('click',()=>{setOpen(!opened);apply()});setOpen(opened);
 Object.values(controls).forEach(c=>c?.addEventListener('change',apply));
 document.getElementById('webResourceFiltersReset')?.addEventListener('click',()=>{Object.values(controls).forEach(c=>{if(c)c.value=''});apply()});apply();
}
function webVMSection(view,services,categories){
  const host=view?.host,servers=Array.isArray(view?.servers)?view.servers:[],sites=Array.isArray(view?.sites)?view.sites:[];
  if(!host)return vmResourceSectionLayout(panel('Web',empty('Nu există încă inventar Web structurat. Este necesar vm-doc-agent 1.6.0+ și un snapshot cu collectorul web.')));
  const products=[...new Set(servers.map(x=>x.product||x.engine).filter(Boolean))],filters=webResourceFiltersBar(sites,host.vm_id);
  const kpis=`<div class="resource-kpis resource-kpis-4"><div class="card"><div class="label">Servere web</div><div class="value">${host.server_count||0}</div></div><div class="card"><div class="label">Site-uri / frontends</div><div class="value">${host.site_count||0}</div></div><div class="card"><div class="label">Produse</div><div class="value compact">${e(products.join(', ')||'—')}</div></div><div class="card"><div class="label">Ultima observație</div><div class="value compact">${dt(host.observed_at)}</div></div></div>`;
  const serverRows=servers.map(x=>`<tr><td><strong>${e(x.product||x.engine)}</strong><div class="muted mono">${e(x.engine)}</div></td><td>${e(shortVersionText(x.version)||'—')}</td><td>${badge(x.status||'unknown')}</td><td>${e(x.service_name||'—')}</td><td class="mono">${(x.config_files||[]).map(e).join('<br>')||'—'}</td><td class="mono">${e(x.executable||'—')}</td><td class="resource-doc-cell">${resourceDocumentationToggle('web-documentation-exempt','data-server',x.id,x.documentation_exempt)}</td></tr>`).join('');
  const siteRows=sites.map((x,index)=>`<tr class="web-resource-filter-row" data-web-engine="${e(String(x.product||x.engine||'').trim())}" data-web-state="${x.enabled===false?'disabled':'active'}" ${resourceFilterAttrs(x)}><td><strong>${e(x.name||'—')}</strong> ${x.default?' <span class="muted">(default)</span>':''}<div class="muted">${e(x.site_type||'site')} · ${x.enabled?badge('active'):badge('disabled')}</div></td><td><strong>${e(x.product||x.engine)}</strong><div class="muted mono">${e(x.engine)}</div></td><td>${(x.server_names||[]).map(e).join('<br>')||'—'}</td><td class="mono">${webBindingText(x.bindings)}</td><td>${webSiteTarget(x)}</td><td class="mono">${e(x.config_file||'—')}</td><td class="resource-tools-cell">${resourceEditorCell('web',x.id,x)}</td></tr>`).join('');
  return vmResourceSectionLayout(`${kpis}${filters}${`<details class="docker-details web-server-details"><summary>Servere web detectate <span class="muted">(${servers.length})</span></summary>${serverRows?`<div class="table-wrap"><table><thead><tr><th>Produs</th><th>Versiune</th><th>Stare</th><th>Serviciu OS</th><th>Config</th><th>Executabil</th><th>Documentare</th></tr></thead><tbody>${serverRows}</tbody></table></div>`:empty('Nu au fost detectate Nginx, Apache HTTP Server sau HAProxy.')}</details>`}${panel('Site-uri web și frontends',siteRows?`<div class="table-wrap"><table><thead><tr><th>Site / frontend</th><th>Engine</th><th>Nume publice</th><th>Bind</th><th>Root / backend / proxy</th><th>Config</th><th>Documentare / Servicii / Beneficiari</th></tr></thead><tbody>${siteRows}</tbody></table></div>`:empty('Serverul web este detectat, dar nu au fost identificate site-uri, virtual hosts sau frontends.'),resourceInventoryExportButton('web',host.vm_id))}`);
}
function webAssignmentInputs(site){return (site?.service_assignments||[]).map(a=>({service_id:Number(a.service_id),environment_id:a.environment_id?Number(a.environment_id):null,operational_status_id:a.operational_status_id?Number(a.operational_status_id):null,solution_type_id:a.solution_type_id?Number(a.solution_type_id):null,component_name:a.component_name||'',role_name:a.role_name||'',notes:a.notes||''}))}
function bindWebActions(vmID,view){
  const sites=new Map((view?.sites||[]).map(x=>[Number(x.id),x]));
  bindWebResourceFilters(vmID);
  document.querySelectorAll('.web-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const serverID=Number(input.dataset.server);try{await api(`/api/v1/vms/${vmID}/web/servers/${serverID}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare Web a fost salvată.');const item=(view?.servers||[]).find(x=>Number(x.id)===serverID);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  document.querySelectorAll('.web-site-documentation-exempt').forEach(input=>input.addEventListener('change',async()=>{const siteID=Number(input.dataset.site);try{await api(`/api/v1/vms/${vmID}/web/sites/${siteID}/documentation-exempt`,{method:'PUT',body:JSON.stringify({exempt:input.checked})});toast('Setarea de documentare a configurației Web a fost salvată.');const item=sites.get(siteID);if(item)item.documentation_exempt=input.checked;refreshVMCompletion(vmID)}catch(err){toast(err.message,true);input.checked=!input.checked}}));
  const endpoint=id=>`/api/v1/vms/${vmID}/web/sites/${id}/services`;
  document.querySelectorAll('.web-add-service').forEach(button=>button.addEventListener('click',async()=>{const id=Number(button.dataset.site),select=document.getElementById(button.dataset.select),serviceID=Number(select?.value||0);if(!serviceID){toast('Alege un serviciu.',true);return}const environmentID=resourceContextValue(button.dataset.environment),statusID=resourceContextValue(button.dataset.status),solutionTypeID=resourceContextValue(button.dataset.solution);if(!environmentID||!statusID||!solutionTypeID){toast('Alege mediul, statusul operațional și tipul soluției.',true);return}const site=sites.get(id),assignments=webAssignmentInputs(site),existing=assignments.find(a=>a.service_id===serviceID);if(existing){existing.environment_id=environmentID;existing.operational_status_id=statusID;existing.solution_type_id=solutionTypeID}else assignments.push({service_id:serviceID,environment_id:environmentID,operational_status_id:statusID,solution_type_id:solutionTypeID});try{await api(endpoint(id),{method:'PUT',body:JSON.stringify({assignments})});toast('Site-ul web a fost asociat serviciului.');vmDetail(vmID,'web')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.web-remove-service').forEach(button=>button.addEventListener('click',async()=>{const id=Number(button.dataset.site),serviceID=Number(button.dataset.service),site=sites.get(id),assignments=webAssignmentInputs(site).filter(a=>a.service_id!==serviceID);try{await api(endpoint(id),{method:'PUT',body:JSON.stringify({assignments})});toast('Asocierea site-ului web a fost eliminată.');vmDetail(vmID,'web')}catch(err){toast(err.message,true)}}));
}
function serviceWebPanel(sites,serviceID){
  const values=Array.isArray(sites)?sites:[];if(!values.length)return empty('Nu există site-uri web sau frontends asociate acestui serviciu. Asocierea se face din fila Web a VM-ului gazdă.');
  const rows=values.map(x=>{const assigned=(x.service_assignments||[]).filter(a=>Number(a.service_id)===Number(serviceID));const role=assigned.map(a=>[a.environment?environmentDisplay(a.environment):'',a.operational_status,a.solution_type,a.component_name,a.role_name].filter(Boolean).map(e).join(' · ')).filter(Boolean).join('<br>')||'—';return `<tr><td><a href="#vms/${x.vm_id}/web"><strong>${e(x.vm_hostname||x.vm_name)}</strong></a></td><td><strong>${e(x.name||'—')}</strong><div class="muted">${e(x.site_type||'site')}</div></td><td>${e(x.product||x.engine)}</td><td>${(x.server_names||[]).map(e).join('<br>')||'—'}</td><td class="mono">${webBindingText(x.bindings)}</td><td>${webSiteTarget(x)}</td><td>${role}</td></tr>`}).join('');
  return `<div class="table-wrap"><table><thead><tr><th>VM gazdă</th><th>Site / frontend</th><th>Engine</th><th>Nume publice</th><th>Bind</th><th>Root / backend</th><th>Mediu / status / tip soluție / componentă / rol</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}


const changeCategoryLabels={system:'Sistem',storage:'Stocare',network:'Rețea',services:'Servicii OS',ports:'Porturi',firewall:'Firewall',accounts:'Conturi',identity:'Identitate',integrations:'Integrări',time:'Timp',databases:'Baze de date',db_security:'Acces baze de date / HBA',docker:'Docker',web:'Web',web_acl:'Web ACL',cron:'Cron / task-uri',software:'Programe instalate'};
const changeTypeLabels={added:'Adăugat',removed:'Eliminat',modified:'Modificat'};
const changeDocLabels={unset:'Nesetat',required:'Necesită documentație',not_required:'Nu necesită'};
const changeReviewLabels={new:'Nou',reviewed:'Revizuit',ignored:'Ignorat'};
function changeParsedValue(value){if(value===undefined||value===null||value==='')return undefined;try{return typeof value==='string'?JSON.parse(value):value}catch{return value}}
function changeJSONPreview(value){const parsed=changeParsedValue(value);if(parsed===undefined)return '—';return `<pre class="change-json">${e(typeof parsed==='string'?parsed:JSON.stringify(parsed,null,2))}</pre>`}
function changeValueText(value){if(value===undefined)return '—';if(value===null)return 'null';if(typeof value==='object')return JSON.stringify(value);return String(value)}
function changeValueEqual(a,b){try{return JSON.stringify(a)===JSON.stringify(b)}catch{return String(a)===String(b)}}
function changeDiffEntries(before,after,prefix=''){
  const plain=value=>value&&typeof value==='object'&&!Array.isArray(value);
  if(plain(before)&&plain(after)){const keys=[...new Set([...Object.keys(before),...Object.keys(after)])].sort((a,b)=>a.localeCompare(b,'ro'));return keys.flatMap(key=>changeDiffEntries(before[key],after[key],prefix?`${prefix}.${key}`:key))}
  return changeValueEqual(before,after)?[]:[{key:prefix||'valoare',before,after}];
}
function changeDetailsHTML(change){
  const before=changeParsedValue(change.old_json),after=changeParsedValue(change.new_json),all=changeDiffEntries(before,after),diffs=all.slice(0,80);
  // The three-column detail grid and full-width detail row mirror Security → Firewall.
  const metadata=`<div class="change-policy-detail-grid">
    <div><span class="muted">VM</span><strong>${e(change.vm_hostname||change.vm_name||'—')}</strong></div>
    <div><span class="muted">Categorie / obiect</span><strong>${e(changeCategoryLabels[change.category]||change.category)} · ${e(change.object_type)}</strong></div>
    <div><span class="muted">Operație</span><strong>${e(changeTypeLabels[change.change_type]||change.change_type)}</strong></div>
    <div><span class="muted">Detectat</span><strong>${dt(change.occurred_at)}</strong></div>
    <div><span class="muted">Identificator obiect</span><strong class="mono">${e(change.object_key||'—')}</strong></div>
    <div><span class="muted">Modificare</span><strong>${e(change.object_label||'—')}</strong></div>
  </div>`;
  const diffHTML=diffs.length?`<div class="change-diff-wrap"><table class="change-diff-table"><thead><tr><th>Câmp modificat</th><th>Anterior</th><th>Nou</th></tr></thead><tbody>${diffs.map(item=>`<tr><td class="mono">${e(item.key)}</td><td class="change-old-value">${e(changeValueText(item.before))}</td><td class="change-new-value">${e(changeValueText(item.after))}</td></tr>`).join('')}</tbody></table>${all.length>80?'<div class="muted">Primele 80 de diferențe.</div>':''}</div>`:'<div class="muted">Nu există diferențe semantice între valorile normalizate.</div>';
  const raw=`<details class="change-raw-details"><summary>JSON complet · pentru diagnostic</summary><div class="change-compare"><div><span>Anterior</span>${changeJSONPreview(change.old_json)}</div><div><span>Nou</span>${changeJSONPreview(change.new_json)}</div></div></details>`;
  return `${metadata}<div class="change-detail-caption">Diferențe detectate</div>${diffHTML}${raw}`;
}
function changeFilterQuery(f,vmID=0,includePage=true){const p=new URLSearchParams();if(vmID)p.set('vm_id',String(vmID));if(f.q)p.set('q',f.q);if(f.scope&&f.scope!=='all')p.set('search_scope',f.scope);if(f.category)p.set('category',f.category);if(f.changeType)p.set('change_type',f.changeType);if(f.doc)p.set('documentation_requirement',f.doc);if(f.review)p.set('review_status',f.review);if(includePage){p.set('page',String(f.page||1));p.set('page_size',String(f.pageSize||10))}return p.toString()}
const changeSearchScopes={all:'Peste tot',vm:'VM',service:'Serviciu',object:'Obiect / modificare'};
function changesFilterHTML(f,{vm=false}={}){
  const scope=Object.hasOwn(changeSearchScopes,f.scope)?f.scope:'vm';
  const active=[f.category,f.changeType,f.doc,f.review].filter(Boolean).length;
  return `<div class="changes-controls">
   <div class="changes-search-line">
     <label for="changeSearch" class="changes-search-label">Căutare</label>
     <div class="changes-search-tools"><select id="changeSearchScope" aria-label="Caută în">${Object.entries(changeSearchScopes).map(([v,l])=>`<option value="${v}" ${scope===v?'selected':''}>${e(l)}</option>`).join('')}</select><input id="changeSearch" type="search" autocomplete="off" value="${e(f.q||'')}" placeholder="${vm?'Obiect, utilizator, serviciu…':'Scrie numele VM-ului (ex: vm-db01)…'}" aria-label="Căutare modificări"><button id="changeSearchSubmit" type="button" class="changes-search-submit" aria-label="Caută modificări">Caută <span aria-hidden="true">→</span></button><a id="changeExport" class="button secondary changes-export" href="/api/v1/changes/export?${e(changeFilterQuery(f,vm?f.vmId:0,false))}" download>Export Excel</a></div>
     <div id="changeSearchFeedback" class="changes-search-feedback" role="status" aria-live="polite"></div>
   </div>
   <details class="changes-advanced-filter" ${f.filtersOpen?'open':''}><summary>Filtre avansate · Categorie, Tip, Documentație, Stare <span class="changes-filter-count">${active?`(${active} active)`:''}</span></summary>
      <div class="changes-advanced-grid">
        <label><span>Categorie</span><select id="changeCategory"><option value="">Toate</option>${Object.entries(changeCategoryLabels).map(([v,l])=>`<option value="${v}" ${f.category===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
        <label><span>Tip</span><select id="changeType"><option value="">Toate</option>${Object.entries(changeTypeLabels).map(([v,l])=>`<option value="${v}" ${f.changeType===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
        <label><span>Documentație <span title="Dacă modificarea necesită actualizarea fișei; nu indică finalizarea documentării." class="change-filter-help">ⓘ</span></span><select id="changeDoc"><option value="">Toate</option>${Object.entries(changeDocLabels).map(([v,l])=>`<option value="${v}" ${f.doc===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
        <label><span>Stare <span title="Etapa reviziei: Nou, Revizuit sau Ignorat. Revizuit nu înseamnă Documentat." class="change-filter-help">ⓘ</span></span><select id="changeReview"><option value="">Toate</option>${Object.entries(changeReviewLabels).map(([v,l])=>`<option value="${v}" ${f.review===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
        <button id="clearChangeFilters" class="secondary changes-reset" type="button">Resetează filtrele</button>
      </div>
      <p class="changes-filter-helptext"><b>Documentație</b>: este nevoie de actualizarea fișei? <b>Stare</b>: a fost analizată modificarea? „Revizuit” nu înseamnă „Documentat”.</p>
   </details>
 </div>`;
}
function changesTable(result,{vm=false}={}){
 const items=Array.isArray(result?.items)?result.items:[],f=vm?state.vmChanges:state.changes;
 f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||f.pageSize||10);
 const cols=vm?7:8;
 const rows=items.map(c=>{
   const detailId=`change-detail-${c.id}`;
   const name=`<strong>${e(c.object_label)}</strong><div class="muted">${e(c.summary)}</div><button type="button" class="change-detail-toggle" data-detail="${detailId}" aria-expanded="false" aria-controls="${detailId}"><span class="change-detail-arrow" aria-hidden="true">▸</span> Detalii</button>`;
   const entry=`<tr data-change-row="${c.id}">${vm?'':`<td><a href="#vms/${c.vm_id}/changes"><strong>${e(c.vm_hostname||c.vm_name)}</strong></a><div class="muted">${e(c.vm_name)}</div></td>`}<td>${dt(c.occurred_at)}</td><td>${e(changeCategoryLabels[c.category]||c.category)}<div class="muted">${e(c.object_type)}</div></td><td class="change-summary-cell">${name}</td><td>${badge(changeTypeLabels[c.change_type]||c.change_type)}</td><td><select class="change-doc-select" data-searchable="off">${Object.entries(changeDocLabels).map(([v,l])=>`<option value="${v}" ${c.documentation_requirement===v?'selected':''}>${e(l)}</option>`).join('')}</select></td><td><select class="change-review-select" data-searchable="off">${Object.entries(changeReviewLabels).map(([v,l])=>`<option value="${v}" ${c.review_status===v?'selected':''}>${e(l)}</option>`).join('')}</select></td><td class="change-save-cell"><button class="small secondary save-change" data-id="${c.id}" type="button">Salvează</button></td></tr>`;
   return entry+`<tr id="${detailId}" class="change-detail-row" hidden><td colspan="${cols}"><div class="change-detail-panel">${changeDetailsHTML(c)}</div></td></tr>`;
 }).join('');
 const total=Number(result?.total||0),pages=Number(result?.pages||0),start=total?(f.page-1)*f.pageSize+1:0,end=Math.min(f.page*f.pageSize,total);
 const pager=`<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="changePageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'change-page')}</div></div>`;
 const table=rows?`<div class="table-wrap changes-table-wrap"><table><thead><tr>${vm?'':'<th>VM</th>'}<th>Detectat</th><th>Categorie</th><th>Modificare</th><th>Tip</th><th title="Este necesară actualizarea documentației?">Documentație</th><th title="Modificarea a fost analizată?">Stare</th><th>Acțiune</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty(f.q?`Niciun rezultat pentru căutarea „${e(f.q)}”.`:'Nu există modificări pentru filtrele selectate.');
 return table+pager;
}
async function saveInventoryChange(button,reload){const row=button.closest('[data-change-row]'),id=Number(button.dataset.id);const body={documentation_requirement:row.querySelector('.change-doc-select').value,review_status:row.querySelector('.change-review-select').value};button.disabled=true;try{await api(`/api/v1/changes/${id}`,{method:'PATCH',body:JSON.stringify(body)});toast('Modificarea a fost actualizată.');reload()}catch(err){toast(err.message,true);button.disabled=false}}
function bindChangesArea(area,reload,f){
 area.querySelectorAll('.save-change').forEach(b=>b.onclick=()=>saveInventoryChange(b,reload));
 area.querySelectorAll('.change-detail-toggle').forEach(b=>b.onclick=()=>{const row=document.getElementById(b.dataset.detail);if(!row)return;const open=row.hidden;row.hidden=!open;b.setAttribute('aria-expanded',String(open));const arrow=b.querySelector('.change-detail-arrow');if(arrow)arrow.textContent=open?'▾':'▸'});
 area.querySelectorAll('.change-page').forEach(b=>b.onclick=()=>{const page=Number(b.dataset.page);if(page>0&&page!==f.page){f.page=page;reload()}});
 area.querySelector('#changePageSize')?.addEventListener('change',ev=>{f.pageSize=Number(ev.target.value);f.page=1;reload()});
}
function bindChangeFilters(reload,f){
 let timer;
 const field=document.getElementById('changeSearch'),scope=document.getElementById('changeSearchScope'),feedback=document.getElementById('changeSearchFeedback'),advanced=document.querySelector('.changes-advanced-filter');
 const updateExport=()=>{const link=document.getElementById('changeExport');if(link)link.href='/api/v1/changes/export?'+changeFilterQuery(f,f.vmId||0,false)};
 const applySearch=(force=false)=>{if(!field)return;const value=field.value.trim(),chosen=scope?.value||'vm';if(!force&&value===f.q&&chosen===(f.scope||'vm'))return;f.q=value;f.scope=chosen;f.page=1;updateExport();if(feedback)feedback.textContent=value?`Se caută „${value}” în ${changeSearchScopes[chosen]||'VM'}…`:'';reload()};
 const scheduleSearch=()=>{clearTimeout(timer);timer=setTimeout(()=>applySearch(),300)};
 field?.addEventListener('input',scheduleSearch);
 field?.addEventListener('search',()=>{clearTimeout(timer);applySearch()});
 field?.addEventListener('change',()=>{clearTimeout(timer);applySearch()});
 field?.addEventListener('keydown',ev=>{if(ev.key==='Enter'){ev.preventDefault();clearTimeout(timer);applySearch(true)}});
 scope?.addEventListener('change',()=>{clearTimeout(timer);applySearch(true)});
 document.getElementById('changeSearchSubmit')?.addEventListener('click',()=>{clearTimeout(timer);applySearch(true)});
 advanced?.addEventListener('toggle',()=>{f.filtersOpen=advanced.open});
 [['changeCategory','category'],['changeType','changeType'],['changeDoc','doc'],['changeReview','review']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{f[key]=ev.target.value;f.page=1;updateExport();reload()}));
 document.getElementById('clearChangeFilters')?.addEventListener('click',()=>{clearTimeout(timer);Object.assign(f,{q:'',scope:'vm',category:'',changeType:'',doc:'',review:'',page:1});if(field)field.value='';if(scope)scope.value='vm';for(const id of ['changeCategory','changeType','changeDoc','changeReview']){const select=document.getElementById(id);if(select)select.value=''}updateExport();reload()});
 return (total,error='')=>{if(feedback)feedback.textContent=error?`Eroare la căutare: ${error}`:f.q?`${Number(total||0).toLocaleString('ro-RO')} rezultate pentru „${f.q}”`:''};
}
let changeSearchResultFeedback=()=>{};
let changeSearchGlobalTicket=0;
async function loadGlobalChanges(){const area=document.getElementById('changesTableArea');if(!area)return;const request=changeFilterQuery(state.changes);const ticket=++changeSearchGlobalTicket;area.classList.add('is-loading');try{const result=await api(`/api/v1/changes?${request}`);if(ticket!==changeSearchGlobalTicket||!area.isConnected)return;document.getElementById('changeTotal').textContent=Number(result.total||0).toLocaleString('ro-RO');document.getElementById('changeNew').textContent=Number(result.new_count||0).toLocaleString('ro-RO');document.getElementById('changeUnset').textContent=Number(result.unset_count||0).toLocaleString('ro-RO');document.getElementById('changeRequired').textContent=Number(result.required_count||0).toLocaleString('ro-RO');area.innerHTML=changesTable(result);bindChangesArea(area,loadGlobalChanges,state.changes);changeSearchResultFeedback(Number(result.total||0))}catch(err){if(ticket===changeSearchGlobalTicket&&area.isConnected){area.innerHTML=empty(err.message);changeSearchResultFeedback(0,err.message);toast(err.message,true)}}finally{if(ticket===changeSearchGlobalTicket&&area.isConnected)area.classList.remove('is-loading')}}

async function changesPage(){pageMeta('Modificări','Diferențe semnificative apărute după baseline-ul acceptat');const f=state.changes;const baselineTools=can('vms.manage')?'<button id="setGlobalChangesBaseline" class="secondary">Stabilește inventarul curent ca baseline</button>':'';const baselineHint='<details class="changes-explain"><summary>Ce este baseline-ul?</summary><p>Modificările anterioare baseline-ului rămân în baza de date pentru audit, dar nu apar în lista curentă.</p></details>';const strictHint='<details class="changes-explain"><summary>Cum funcționează detectorul semantic?</summary><p>Urmărim schimbări semnificative de firewall, servicii, ACL, HBA, baze și cron. UDP, porturi dinamice și DNS autogenerat sunt ignorate dacă nu sunt marcate Principal. Comparăm două inventare consecutive reușite; inventarul brut rămâne complet.</p></details>';content.innerHTML=`<div class="cards changes-summary-cards"><div class="card"><div class="label">Modificări</div><div id="changeTotal" class="value">—</div></div><div class="card"><div class="label">Noi</div><div id="changeNew" class="value">—</div></div><div class="card"><div class="label">Documentație nesetată</div><div id="changeUnset" class="value">—</div></div><div class="card"><div class="label">Necesită documentație</div><div id="changeRequired" class="value">—</div></div></div>${panel('Modificări inventar',`${strictHint}${baselineHint}${changesFilterHTML(f)}<div id="changesTableArea" class="loading">Se încarcă modificările…</div>`,baselineTools)}`;changeSearchResultFeedback=bindChangeFilters(flag=>flag?changesPage():loadGlobalChanges(),f);document.getElementById('setGlobalChangesBaseline')?.addEventListener('click',async()=>{if(!confirm('Stabilești inventarul curent al tuturor VM-urilor ca baseline? Modificările existente vor rămâne în istoric, dar vor fi ascunse din trierea curentă.'))return;try{const r=await api('/api/v1/changes/baseline',{method:'POST',body:JSON.stringify({})});toast(`Baseline actualizat pentru ${Number(r.vm_count||0)} VM-uri.`);state.changes.page=1;loadGlobalChanges()}catch(err){toast(err.message,true)}});await loadGlobalChanges()}
let changeSearchVMTicket=0;
async function loadVMChanges(vmID){if(Number(state.vmChanges.vmId)!==Number(vmID))state.vmChanges={vmId:vmID,q:'',scope:'all',category:'',changeType:'',doc:'',review:'',page:1,pageSize:10};const f=state.vmChanges,area=document.getElementById('vmChangesArea');if(!area)return;const query=changeFilterQuery(f,vmID),ticket=++changeSearchVMTicket;area.classList.add('is-loading');try{const result=await api(`/api/v1/changes?${query}`);if(ticket!==changeSearchVMTicket||!area.isConnected)return;area.innerHTML=changesTable(result,{vm:true});bindChangesArea(area,()=>loadVMChanges(vmID),f);changeSearchResultFeedback(Number(result.total||0))}catch(err){if(ticket===changeSearchVMTicket&&area.isConnected){area.innerHTML=empty(err.message);changeSearchResultFeedback(0,err.message);toast(err.message,true)}}finally{if(ticket===changeSearchVMTicket&&area.isConnected)area.classList.remove('is-loading')}}
function vmChangesSection(vmID){const f=Number(state.vmChanges.vmId)===Number(vmID)?state.vmChanges:{vmId:vmID,q:'',scope:'all',category:'',changeType:'',doc:'',review:'',page:1,pageSize:10};state.vmChanges=f;return `<details class="changes-explain"><summary>Cum funcționează detectorul semantic?</summary><p>Două colectări consecutive reușite sunt comparate 1:1; UDP, porturile dinamice și DNS sunt urmărite numai dacă sunt marcate Principal.</p></details>${changesFilterHTML(f,{vm:true})}<div id="vmChangesArea" class="loading">Se încarcă modificările…</div>`}


function monitoringTargetTable(values,type){const items=Array.isArray(values)?values:[];if(!items.length)return empty(type==='blackbox'?'Nu există probe Blackbox corelate cu această VM.':'Nu există target Prometheus metrics corelat cu această VM.');const rows=items.map(t=>type==='blackbox'?`<tr><td><strong>${e(t.prometheus_source_name)}</strong><div class="muted">${e(t.job_name||'—')}</div></td><td class="mono">${e(t.target_url||t.instance||'—')}</td><td>${targetVisualStatus(t)}</td><td>${t.http_status_code??'—'}</td><td>${t.probe_duration_seconds!=null?`${(Number(t.probe_duration_seconds)*1000).toFixed(0)} ms`:'—'}</td><td>${t.tls_expiry_at?dt(t.tls_expiry_at):'—'}</td><td>${e(t.match_method||'—')}<div class="muted mono">${e(t.match_value||'')}</div></td></tr>`:`<tr><td><strong>${e(t.prometheus_source_name)}</strong></td><td>${e(t.job_name||'—')}</td><td class="mono">${e(t.instance||'—')}</td><td>${badge(t.health||'unknown')}</td><td>${dt(t.last_scrape_at)}</td><td>${t.scrape_duration_seconds!=null?`${(Number(t.scrape_duration_seconds)*1000).toFixed(0)} ms`:'—'}</td><td>${e(t.match_method||'—')}<div class="muted mono">${e(t.match_value||'')}</div></td><td class="error-text">${e(t.last_error||'—')}</td></tr>`).join('');return `<div class="table-wrap monitoring-vm-target-table"><table><thead><tr>${type==='blackbox'?'<th>Sursă / job</th><th>URL</th><th>Probe</th><th>HTTP</th><th>Durată</th><th>TLS expiră</th><th>Corelare</th>':'<th>Sursă</th><th>Job</th><th>Instance</th><th>Health</th><th>Ultimul scrape</th><th>Durată</th><th>Corelare</th><th>Eroare</th>'}</tr></thead><tbody>${rows}</tbody></table></div>`}
function vmMonitoringSection(m){
  m=m||{};
  const aliases=Array.isArray(m.aliases)?m.aliases:[],aliasText=aliases.map(a=>a.alias).join('\n'),vcenterIPs=Array.isArray(m.vcenter_ips)?m.vcenter_ips:[];
  const ipHTML=vcenterIPs.length?`<div class="monitoring-ip-list">${vcenterIPs.map(ip=>`<code>${e(ip)}</code>`).join('')}</div>`:'<span class="muted">—</span>';
  const node=`<div class="detail-grid monitoring-vm-summary-grid">${detail('Instalat / detectat',(m.exporter_installed||m.exporter_running)?badge('yes'):badge('no'))}${detail('Rulează',m.exporter_running?badge('running'):badge('stopped'))}${detail('Versiune',e(shortVersionText(m.exporter_version)||'—'))}${detail('Endpoint local',e(m.exporter_endpoint||'—'),true)}${detail('IP-uri vCenter',ipHTML)}${detail('Prometheus metrics',m.metrics_monitored?(m.metrics_up?badge('up'):badge('down')):badge('missing'))}${detail('Blackbox',m.blackbox_monitored?(m.blackbox_up?badge('up'):badge('down')):'—')}${detail('Stare',monitoringStateBadge(m.monitoring_state||'unmonitored'))}</div>`;
  const aliasPanel=can('monitoring.manage')?panel('Aliasuri corelare',`<form id="monitoringAliasForm" class="monitoring-vm-form"><label>Aliasuri Prometheus / hosts<textarea id="monitoringAliases" rows="5" class="mono" placeholder="prometheus-web-prod\nweb-prod">${e(aliasText)}</textarea><small>Un alias pe linie. Se folosește după label, FQDN, hostname, IP și /etc/hosts. După salvare rulează Sync Prometheus.</small></label><div class="form-actions"><button type="submit">Salvează aliasurile</button></div></form>`):'';
  return `<div class="vm-monitoring-workspace">${panel('Node Exporter și stare monitorizare',node,'<a class="button-link small secondary" href="#monitoring/overview">Monitorizare globală</a>')}${panel('Prometheus metrics',monitoringTargetTable(m.metrics_targets,'metrics'))}${panel('Blackbox HTTP / HTTPS',monitoringTargetTable(m.blackbox_targets,'blackbox'))}${aliasPanel}</div>`;
}


function softwareKindLabel(value){const labels={desktop:'Desktop',appx:'AppX / MSIX',windows_feature:'Windows Feature / Role'};return labels[String(value||'').toLowerCase()]||value||'—'}
function softwareVMSection(vmID,view){
  const items=Array.isArray(view?.items)?view.items:[];
  if(!view?.host||!items.length)return empty('Agentul nu a raportat software instalat pentru această VM.');
  const publishers=[...new Set(items.map(item=>String(item.publisher||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
  const rows=items.map(item=>`<tr class="software-row" data-search="${e([item.name,item.version,item.publisher,item.install_location].join(' ').toLowerCase())}" data-kind="${e(item.kind||'')}" data-arch="${e(item.architecture||'')}" data-publisher="${e(item.publisher||'')}" data-primary="${item.primary?'yes':'no'}" data-present="${item.present?'yes':'no'}"><td><strong>${e(item.name)}</strong>${item.install_location?`<div class="muted mono">${e(item.install_location)}</div>`:''}</td><td>${e(item.version||'—')}</td><td>${e(item.publisher||'—')}</td><td>${e(item.architecture||'—')}</td><td>${e(item.scope||'—')}</td><td>${e(softwareKindLabel(item.kind))}</td><td>${item.present?badge(item.state||'installed'):badge('missing')}</td><td>${can('vms.manage')?`<label class="inline-check"><input type="checkbox" class="software-primary-toggle" data-id="${item.id}" ${item.primary?'checked':''}> Principal</label>`:(item.primary?badge('primary'):'—')}</td></tr>`).join('');
  const filters=`<div class="filterbar software-filterbar"><label>Căutare<input id="vmSoftwareSearch" placeholder="Nume, versiune, publisher…"></label><label>Tip<select id="vmSoftwareKind"><option value="">Toate</option><option value="desktop">Desktop</option><option value="appx">AppX / MSIX</option><option value="windows_feature">Windows Feature / Role</option></select></label><label>Arhitectură<select id="vmSoftwareArch"><option value="">Toate</option><option value="x64">x64</option><option value="x86">x86</option></select></label><label>Publisher<select id="vmSoftwarePublisher"><option value="">Toți</option>${publishers.map(v=>`<option value="${e(v)}">${e(v)}</option>`).join('')}</select></label><label>Principal<select id="vmSoftwarePrimary"><option value="">Toate</option><option value="yes">Da</option><option value="no">Nu</option></select></label><label>Prezență<select id="vmSoftwarePresence"><option value="yes">Detectat</option><option value="">Toate</option><option value="no">Nedetectat</option></select></label></div>`;
  return `${filters}<div class="section-actions"><span id="vmSoftwareCount" class="muted"></span><a class="button-link small secondary" href="/api/v1/vms/${vmID}/software/export">Export Excel</a></div><div class="table-wrap"><table><thead><tr><th>Software</th><th>Versiune</th><th>Publisher</th><th>Arh.</th><th>Scope</th><th>Tip</th><th>Stare</th><th>Documentație</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function bindSoftwareActions(vmID,view){
  const apply=()=>{const q=String(document.getElementById('vmSoftwareSearch')?.value||'').trim().toLowerCase(),kind=document.getElementById('vmSoftwareKind')?.value||'',arch=document.getElementById('vmSoftwareArch')?.value||'',publisher=document.getElementById('vmSoftwarePublisher')?.value||'',primary=document.getElementById('vmSoftwarePrimary')?.value||'',present=document.getElementById('vmSoftwarePresence')?.value||'';let visible=0;document.querySelectorAll('.software-row').forEach(row=>{const ok=(!q||row.dataset.search.includes(q))&&(!kind||row.dataset.kind===kind)&&(!arch||row.dataset.arch===arch)&&(!publisher||row.dataset.publisher===publisher)&&(!primary||row.dataset.primary===primary)&&(!present||row.dataset.present===present);row.hidden=!ok;if(ok)visible++});const count=document.getElementById('vmSoftwareCount');if(count)count.textContent=`${visible} din ${document.querySelectorAll('.software-row').length} elemente`;};
  ['vmSoftwareSearch','vmSoftwareKind','vmSoftwareArch','vmSoftwarePublisher','vmSoftwarePrimary','vmSoftwarePresence'].forEach(id=>document.getElementById(id)?.addEventListener(id==='vmSoftwareSearch'?'input':'change',apply));
  document.querySelectorAll('.software-primary-toggle').forEach(input=>input.addEventListener('change',async()=>{try{await api(`/api/v1/vms/${vmID}/software/${input.dataset.id}/primary`,{method:'POST',body:JSON.stringify({primary:input.checked})});toast(input.checked?'Software marcat Principal.':'Marcaj Principal eliminat.');vmDetail(vmID,'software')}catch(err){input.checked=!input.checked;toast(err.message,true)}}));
  apply();
}

const vmDetailGroups=[
  {code:'summary',label:'Rezumat',help:'Identitate și stare',sections:[['overview','Rezumat']]},
  {code:'configuration',label:'Configurare',help:'Servicii și operare',sections:[['services','Servicii'],['operational','Operațional'],['infrastructure','Infrastructură']]},
  {code:'application',label:'Aplicație',help:'Docker, DB și Web',sections:[['docker','Docker'],['databases','Baze de date'],['web','Web']]},
  {code:'security',label:'Securitate',help:'Conturi, firewall și rețea',sections:[['security','Rezumat'],['security-accounts','Conturi'],['security-databases','Baze de date'],['security-web','Web ACL'],['security-firewall','Firewall'],['security-hardening','Hardening'],['network-map','Hartă rețea']]},
  {code:'inventory',label:'Inventar',help:'Agent și istoric',sections:[['inventory','Inventar agent'],['history','Istoric']]},
  {code:'backup',label:'Backup',help:'Veeam și cron',sections:[['backup','Backup']]},
  {code:'monitoring',label:'Monitorizare',help:'Prometheus și Blackbox',sections:[['monitoring','Monitorizare']]},
  {code:'documents',label:'Documentație',help:'Fișe VM',sections:[['continuity','Fișe și documente']]},
  {code:'changes',label:'Modificări',help:'Diferențe inventar',sections:[['changes','Modificări']]}
];
const vmDetailSections=[...vmDetailGroups.flatMap(group=>group.sections),['software','Software instalat']];
function vmDetailGroupsFor(hasSoftware=false){const groups=vmDetailGroups.map(group=>group.code==='inventory'&&hasSoftware?{...group,sections:[['software','Software instalat'],...group.sections]}:group);if(can('audit.read'))groups.push({code:'audit',label:'Audit',help:'Cine a schimbat ce',sections:[['audit','Audit']]});return groups}
function vmDetailGroupForSection(section,hasSoftware=false){const groups=vmDetailGroupsFor(hasSoftware);return groups.find(group=>group.sections.some(([code])=>code===section))||groups[0]}
function vmDetailNavigation(vmID,selected,hasSoftware=false){
  const groups=vmDetailGroupsFor(hasSoftware),activeGroup=vmDetailGroupForSection(selected,hasSoftware);
  const primary=`<nav class="vm-detail-tabs vm-detail-primary-tabs" aria-label="Zone VM">${groups.map(group=>{const target=group.sections[0][0];return `<a href="#vms/${vmID}/${target}" class="${activeGroup.code===group.code?'active':''}"><strong>${e(group.label)}</strong><small>${e(group.help)}</small></a>`}).join('')}</nav>`;
  const secondary=activeGroup.sections.length>1?`<nav class="vm-detail-subtabs" aria-label="Secțiuni ${e(activeGroup.label)}">${activeGroup.sections.map(([code,label])=>`<a href="#vms/${vmID}/${code}" class="${selected===code?'active':''}">${e(label)}</a>`).join('')}</nav>`:'';
  return `<div class="vm-detail-navigation">${primary}${secondary}</div>`;
}
function databaseOverviewNotice(view){
  const engines=Array.isArray(view?.engines)?view.engines:[],instances=Array.isArray(view?.instances)?view.instances:[];
  if(!engines.length)return '';
  const issues=[];
  for(const engine of engines){if(!instances.some(i=>i.engine===engine.engine))issues.push(`${engine.product||engine.engine}: engine detectat, dar instanța nu a putut fi determinată`)}
  for(const instance of instances){const status=String(instance.catalog_discovery_status||'').trim();if(status!=='discovered'&&(!(instance.catalogs||[]).length||status)){const reason=databaseCatalogReasonLabel(instance.catalog_discovery_reason)||status||'stare necunoscută';issues.push(`${instance.product||instance.engine} / ${instance.instance_name||'implicit'}: bazele nu au putut fi enumerate (${reason})`)}}
  if(!issues.length)return '';
  return `<div class="notice warning database-summary-warning"><strong>Inventar baze de date incomplet.</strong><div>${issues.map(e).map(x=>`<div>${x}</div>`).join('')}</div><a href="#vms/${view?.host?.vm_id||''}/databases">Vezi detalii Baze de date</a></div>`;
}

function inventorySectionValues(documentView,key){
  const section=(Array.isArray(documentView?.sections)?documentView.sections:[]).find(item=>String(item?.key||'').toLowerCase()===key);
  const data=section?.data;
  if(Array.isArray(data))return data;
  if(data&&typeof data==='object'){
    for(const candidate of [data.items,data.services,data.ports,data.listening_ports,data.entries])if(Array.isArray(candidate))return candidate;
    return Object.keys(data).length?[data]:[];
  }
  return [];
}
function resourceServiceRequirements(dockerView,databaseView,webView){
  const required=new Map();
  const add=(assignment,source)=>{const id=Number(assignment?.service_id||0);if(!id)return;const current=required.get(id)||{id,name:assignment?.service_name||`Serviciu #${id}`,sources:new Set()};if(assignment?.service_name)current.name=assignment.service_name;current.sources.add(source);required.set(id,current)};
  for(const container of (Array.isArray(dockerView?.containers)?dockerView.containers:[]))for(const assignment of (container.service_assignments||[]))add(assignment,'Docker');
  for(const instance of (Array.isArray(databaseView?.instances)?databaseView.instances:[])){
    for(const assignment of (instance.service_assignments||[]))add(assignment,'Baze de date');
    for(const catalog of (instance.catalogs||[])){if(catalog.system)continue;for(const assignment of (catalog.service_assignments||[]))add(assignment,'Baze de date')}
  }
  for(const site of (Array.isArray(webView?.sites)?webView.sites:[])){if(site.enabled===false)continue;for(const assignment of (site.service_assignments||[]))add(assignment,'Web')}
  return [...required.values()].sort((a,b)=>String(a.name).localeCompare(String(b.name),'ro'));
}
function directServiceAssignmentComplete(assignment){return !!(Number(assignment?.internal_service_id||0)&&Number(assignment?.architectural_domain_id||0)&&Number(assignment?.itil_category_id||0)&&Number(assignment?.layer_id||0)&&Number(assignment?.technical_role_id||0)&&Number(assignment?.solution_type_id||0))}
function resourceServiceConfigurationNotice(requirements,directServices){
  if(!requirements.length)return '';
  const configured=new Set((directServices||[]).filter(directServiceAssignmentComplete).map(item=>Number(item.internal_service_id)));
  const missing=requirements.filter(item=>!configured.has(Number(item.id)));
  if(!missing.length)return `<div class="notice success"><strong>Proiectele folosite în Docker/Baze/Web sunt configurate.</strong><span>${requirements.length} ${requirements.length===1?'proiect este legat':'proiecte sunt legate'} și în asocierile serviciilor și rolurilor tehnice.</span></div>`;
  return `<div class="notice warning"><strong>Necesită configurare pentru procentul VM.</strong><span>Proiectele selectate în Docker/Baze/Web trebuie să existe și aici cu domeniu, categorie, layer, rol tehnic și tip soluție.</span><div class="resource-service-requirements">${missing.map(item=>`<span><b>${e(item.name)}</b> · ${e([...item.sources].join(', '))}</span>`).join('')}</div></div>`;
}
function vmCompletion(vm,inventory,operational,dockerView,databaseView,webView,documentView,primaryServices=[],primaryPorts=[],servicesReviewed=false,vmBeneficiaryCount=0){
  const dockerContainers=Array.isArray(dockerView?.containers)?dockerView.containers:[];
  const dockerHostExempt=!!dockerView?.host?.documentation_exempt;
  const dbInstances=Array.isArray(databaseView?.instances)?databaseView.instances:[];
  const allDbCatalogs=dbInstances.flatMap(i=>(i.catalogs||[]).filter(c=>!c.system).map(c=>({...c,_instanceExempt:!!i.documentation_exempt})));
  const dbResources=allDbCatalogs.length?allDbCatalogs:dbInstances;
  const allWebSites=(Array.isArray(webView?.sites)?webView.sites:[]).filter(site=>site.enabled!==false);
  const webServers=Array.isArray(webView?.servers)?webView.servers:[];
  const serverExempt=site=>webServers.some(server=>server.engine===site.engine&&server.documentation_exempt);
  const directServices=Array.isArray(operational.service_assignments)?operational.service_assignments:[];
  const resourceServices=resourceServiceRequirements(dockerView,databaseView,webView);
  const configuredDirectServices=new Set(directServices.filter(directServiceAssignmentComplete).map(item=>Number(item.internal_service_id)));
  const hasResourceService=resourceServices.length>0;
  const osName=String(inventory.os_name||vm.guest_os||'').toLowerCase(),isWindows=osName.includes('windows');
  const serviceCriterion=isWindows?['Software principal',Number(vm.primary_software_count||0)>0]:['Serviciu documentat',directServices.length>0||hasResourceService];
  const checks=[
    ['Agent asociat',!!vm.agent_id],['Inventar agent',!!vm.current_inventory_id],['Hostname',!!(inventory.hostname||vm.guest_hostname)],['Sistem de operare',!!(inventory.os_name||vm.guest_os)],['IP principal',!!(operational.preferred_ip||inventory.primary_ip||vm.primary_ip)],
    ['Mediu',!!operational.environment_id],['Status operațional',!!operational.operational_status_id],['Clasificare',!!operational.classification_id],['Scop VM',!!String(operational.purpose||'').trim()],serviceCriterion,['Responsabilitate',Array.isArray(operational.responsibilities)&&operational.responsibilities.length>0],['Beneficiar VM',Number(vmBeneficiaryCount)>0]
  ];
  dockerContainers.forEach(x=>checks.push([`Docker: ${x.name||x.id}`,dockerHostExempt||!!x.documentation_exempt||(x.service_assignments||[]).length>0]));
  dbResources.forEach(x=>checks.push([`DB: ${x.name||x.instance_name||x.product||x.engine||x.id}`,!!x.documentation_exempt||!!x._instanceExempt||(x.service_assignments||[]).length>0]));
  allWebSites.forEach(x=>checks.push([`Web: ${x.name||x.id}`,!!x.documentation_exempt||serverExempt(x)||(x.service_assignments||[]).length>0]));
  resourceServices.forEach(item=>checks.push([`Configurare serviciu: ${item.name}`,configuredDirectServices.has(Number(item.id))]));
  if(vm.current_inventory_id){
    if(!isWindows)checks.push(['Serviciu software principal / servicii verificate',primaryServices.length>0||servicesReviewed]);
    checks.push(['Port / proces principal',!!vm.hide_listening_ports||primaryPorts.length>0]);
  }
  if(Number(vm.required_change_count||0)>0)checks.push(['Modificări ce necesită documentație',Number(vm.outstanding_required_changes||0)===0]);
  const done=checks.filter(([,ok])=>ok).length,percent=checks.length?Math.round(done*100/checks.length):0;return {percent,done,total:checks.length,missing:checks.filter(([,ok])=>!ok).map(([label])=>label)};
}

// Ruta este derivată din criteriul lipsă, fără comenzi sau adrese furnizate din inventar.
// Dacă o resursă este într-un tab separat, navigăm acolo și evidențiem controlul relevant.
function vmCompletionDestination(label,vmID){
 const fixed={
  'Agent asociat':['infrastructure','vmAgent'],
  'Inventar agent':['inventory',''],
  'Hostname':['infrastructure',''],
  'Sistem de operare':['infrastructure',''],
  'IP principal':['operational','opPreferredIP'],
  'Mediu':['operational','opEnvironment'],
  'Status operațional':['operational','opStatus'],
  'Clasificare':['operational','opClassification'],
  'Scop VM':['operational','opPurpose'],
  'Serviciu documentat':['services','vmServiceAssignmentRows'],
  'Software principal':['software','vmSoftwareSearch'],
  'Responsabilitate':['operational','vmResponsibilitiesSection'],
  'Beneficiar VM':['operational',`beneficiary-card-vm-${Number(vmID)}`],
  'Serviciu software principal / servicii verificate':['inventory','vmAgentServicesReviewed'],
  'Port / proces principal':['inventory','vmAgentPortSearch'],
  'Modificări ce necesită documentație':['changes','']
 };
 if(fixed[label])return {section:fixed[label][0],focus:fixed[label][1]};
 if(label.startsWith('Docker: '))return {section:'docker',focus:''};
 if(label.startsWith('DB: '))return {section:'databases',focus:''};
 if(label.startsWith('Web: '))return {section:'web',focus:''};
 if(label.startsWith('Configurare serviciu: '))return {section:'services',focus:'vmServiceAssignmentRows'};
 return {section:'overview',focus:''};
}
let pendingVMCompletionFocus=null;
function vmCompletionHTML(value,vmID){
 const missing=value.missing.length?`<div class="completion-missing"><strong>De completat</strong><div>${value.missing.map(label=>{
   const target=vmCompletionDestination(label,vmID);
   return `<a class="vm-completion-link" href="#vms/${Number(vmID)}/${target.section}" data-vm-completion-focus="${e(target.focus)}" data-vm-completion-section="${e(target.section)}" title="Deschide ${e(target.section)}">${e(label)}<span aria-hidden="true">↗</span></a>`;
 }).join('')}</div></div>`:`<div class="completion-complete">Fișa are toate câmpurile esențiale completate.</div>`;
 return `<div class="completion-detail"><div class="completion-score"><strong>${value.percent}%</strong><span>${value.done} din ${value.total} criterii esențiale</span></div><div class="completion-progress large"><i style="width:${value.percent}%"></i></div>${missing}</div>`;
}
function vmCompletionApplyFocus(vmID,section){
 const pending=pendingVMCompletionFocus;
 if(!pending||pending.vmID!==Number(vmID)||pending.section!==section)return;
 pendingVMCompletionFocus=null;
 const target=(pending.focus&&document.getElementById(pending.focus))||document.querySelector('.vm-detail-workspace');
 if(!target)return;
 for(let ancestor=target.closest('details');ancestor;ancestor=ancestor.parentElement?.closest('details'))ancestor.open=true;
 requestAnimationFrame(()=>{
  target.scrollIntoView({behavior:'smooth',block:'center'});
  if(pending.focus){target.classList.add('vm-completion-focus');setTimeout(()=>target.classList.remove('vm-completion-focus'),2200)}
 });
}
const vmCompletionRefreshTimers=new Map();let vmCompletionRefreshGeneration=0;
function paintVMCompletion(value,vmID){document.querySelectorAll('[data-vm-completion-percent]').forEach(node=>node.textContent=`${value.percent}%`);document.querySelectorAll('[data-vm-completion-progress]').forEach(node=>node.style.width=`${value.percent}%`);const detailNode=document.getElementById('vmCompletionDetail');if(detailNode)detailNode.innerHTML=vmCompletionHTML(value,vmID)}
function refreshVMCompletion(vmID,delay=250){const key=Number(vmID);const prior=vmCompletionRefreshTimers.get(key);if(prior)clearTimeout(prior);const timer=setTimeout(async()=>{vmCompletionRefreshTimers.delete(key);const generation=++vmCompletionRefreshGeneration;try{const [data,dockerView,databaseView,webView,vmBeneficiaries]=await Promise.all([api(`/api/v1/vms/${key}`),api(`/api/v1/vms/${key}/docker`).catch(()=>({host:null,containers:[]})),api(`/api/v1/vms/${key}/databases`).catch(()=>({host:null,instances:[]})),api(`/api/v1/vms/${key}/web`).catch(()=>({host:null,servers:[],sites:[]})),api(`/api/v1/beneficiaries/assignments?resource_type=vm&resource_id=${key}`).catch(()=>[])]);if(generation!==vmCompletionRefreshGeneration)return;const hashParts=(location.hash||'').slice(1).split('/');if(hashParts[0]!=='vms'||Number(hashParts[1])!==key)return;const vm=data.vm||{},inventory=data.inventory||{},operational=data.operational||{},documentView=data.inventory_document||{},primaryServices=Array.isArray(data.primary_agent_services)?data.primary_agent_services:[],primaryPorts=Array.isArray(data.primary_agent_ports)?data.primary_agent_ports:[],servicesReviewed=!!data.agent_services_reviewed;paintVMCompletion(vmCompletion(vm,inventory,operational,dockerView,databaseView,webView,documentView,primaryServices,primaryPorts,servicesReviewed,vmBeneficiaries.length),key)}catch(err){console.warn('completion refresh failed',err)}},delay);vmCompletionRefreshTimers.set(key,timer)}
function documentationGroupTypeLabel(value){return ({active_active:'Active / Active',active_standby:'Active / Standby',cluster:'Cluster'})[value]||'Cluster'}
function vmDocumentationInheritancePanel(vm,inheritance,vms){
  const value=inheritance||{},members=Array.isArray(value.members)?value.members:[];
  if(value.is_source){
    const memberRows=members.map(item=>`<tr><td><a href="#vms/${item.vm_id}/services"><strong>${e(item.vm_name)}</strong></a></td><td>${e(item.hostname||'—')}</td><td class="mono">${e(item.primary_ip||'—')}</td></tr>`).join('');
    return panel('Cluster / grup HA',`<div class="notice inheritance-source-notice inheritance-panel-notice"><strong>Acest VM este sursa documentației comune.</strong><p>Modificările de servicii, date operaționale și asocieri Docker/DB/Web sunt propagate către membrii care au moștenirea activă.</p><div class="detail-grid">${detail('Grup',e(value.group_name||'—'))}${detail('Tip',e(documentationGroupTypeLabel(value.group_type)))}</div></div>${memberRows?`<div class="table-wrap"><table><thead><tr><th>Membru</th><th>Hostname</th><th>IP</th></tr></thead><tbody>${memberRows}</tbody></table></div>`:empty('Nu există membri în grup.')}`,'<span class="muted">Pentru a schimba sursa, modifică relația din fișa VM-ului membru.</span>');
  }
  const sourceID=Number(value.source_vm_id||0),sourceOptions=(vms||[]).filter(item=>Number(item.id)!==Number(vm.id)).map(item=>`<option value="${item.id}" ${Number(item.id)===sourceID?'selected':''}>${e(item.name)}${item.primary_ip?` · ${e(item.primary_ip)}`:''}</option>`).join('');
  const inherited=sourceID>0,resourceSyncAction=inherited&&value.inherit_resource_assignments&&can('vms.manage')?'<button type="button" id="syncInheritedResources" class="small secondary inheritance-sync-resources">Sincronizează acum Docker / DB / Web</button>':'',help=inherited?`<div class="notice inheritance-member-notice inheritance-panel-notice"><strong>Documentație moștenită din ${e(value.source_vm_name||'VM sursă')}.</strong><p>Dezactivează sursa pentru a păstra valorile curente și a continua documentarea local.</p>${resourceSyncAction?`<div class="inheritance-notice-actions">${resourceSyncAction}<span class="muted">Folosește inventarul tehnic deja colectat. Resursele noi sunt sincronizate automat la următorul Colect.</span></div>`:''}</div>`:'<p class="muted inheritance-local-help">Alege un VM sursă pentru perechi LB, noduri Active/Active, Active/Standby sau alte clustere. Datele tehnice colectate rămân individuale.</p>';
  if(!can('vms.manage'))return panel('Cluster / grup HA',help);
  return panel('Cluster / grup HA',`${help}<form id="documentationInheritanceForm" class="inheritance-form"><div class="form-grid"><label>VM sursă<select id="documentationSourceVM"><option value="">— Documentație locală —</option>${sourceOptions}</select></label><label>Nume grup<input id="documentationGroupName" value="${e(value.group_name||'')}" placeholder="ex. LB-PROD"></label><label>Tip grup<select id="documentationGroupType"><option value="active_active" ${value.group_type==='active_active'?'selected':''}>Active / Active</option><option value="active_standby" ${value.group_type==='active_standby'?'selected':''}>Active / Standby</option><option value="cluster" ${!value.group_type||value.group_type==='cluster'?'selected':''}>Cluster</option></select></label></div><div class="inheritance-options"><label><input id="inheritServiceAssignments" type="checkbox" ${value.inherit_service_assignments!==false?'checked':''}> Moștenește servicii, clasificare, layer, rol și tip soluție</label><label><input id="inheritOperationalMetadata" type="checkbox" ${value.inherit_operational_metadata!==false?'checked':''}> Moștenește documentația operațională comună</label><label><input id="inheritResourceAssignments" type="checkbox" ${(!value.source_vm_id||value.inherit_resource_assignments)?'checked':''}> Moștenește asocierile și documentarea Docker / DB / Web</label></div><div class="form-actions"><button type="submit">Salvează grupul HA</button>${inherited?'<button type="button" id="clearDocumentationInheritance" class="secondary">Treci pe documentație locală</button>':''}</div></form>`,'<span class="muted">Hostname, IP, UUID, inventarul tehnic al resurselor, agentul, backupul și monitorizarea nu se moștenesc.</span>');
}

async function vmDetail(id,requestedSection=''){
  const detailID=++vmDetailGeneration;
  if(Number(state.vmHistory.vmId)!==Number(id))state.vmHistory={vmId:id,page:1,pageSize:10};
  const hashParts=(location.hash||'').slice(1).split('/');const hashSection=hashParts[0]==='vms'&&Number(hashParts[1])===Number(id)?hashParts[2]:'';
  const candidate=requestedSection||hashSection||'overview';let selectedSection=(vmDetailSections.some(([code])=>code===candidate)||(candidate==='audit'&&can('audit.read')))?candidate:'overview';if(candidate!==selectedSection)history.replaceState(null,'',`#vms/${id}/${selectedSection}`);
  const infrastructureFast=selectedSection==='infrastructure';
  if(infrastructureFast){
    pageMeta('VM','Infrastructură · se încarcă datele');
    content.innerHTML=`<div class="vm-detail-fast-shell">${vmDetailNavigation(id,selectedSection,false)}<div class="vm-detail-workspace"><section class="panel"><div class="panel-body loading" role="status">Se încarcă infrastructura VM…</div></section></div></div>`;
  }
  const [data,agents,categories,people,services,documentTemplates,generatedDocuments,externalSystems,externalConnections,dockerView,databaseView,webView,softwareView,monitoringView,outlineSettings,securityView,vmBeneficiaries]=await Promise.all([cachedVMRead(`/api/v1/vms/${id}`),Promise.resolve([]) /* Infrastructură: agenții se încarcă după afișarea formularului */,(infrastructureFast?Promise.resolve([]):cachedVMRead('/api/v1/nomenclatures?include_inactive=true')),selectedSection==='operational'?cachedVMRead('/api/v1/people?include_inactive=true'):Promise.resolve([]),(infrastructureFast?Promise.resolve([]):cachedVMRead('/api/v1/services?include_inactive=true')),selectedSection==='continuity'&&can('documents.read')?cachedVMRead('/api/v1/document-templates?object_type=vm'):Promise.resolve([]),selectedSection==='continuity'&&can('documents.read')?cachedVMRead(`/api/v1/vms/${id}/documents`):Promise.resolve([]),Promise.resolve([]) /* Infrastructură: sisteme externe încărcate după afișare */,Promise.resolve([]) /* Infrastructură: conexiuni externe încărcate după afișare */,(infrastructureFast?Promise.resolve({host:null,containers:[],images:[],networks:[],volumes:[],compose_projects:[]}):cachedVMRead(`/api/v1/vms/${id}/docker`)).catch(()=>({host:null,containers:[],images:[],networks:[],volumes:[],compose_projects:[]})),(infrastructureFast?Promise.resolve({host:null,engines:[],instances:[]}):cachedVMRead(`/api/v1/vms/${id}/databases`)).catch(()=>({host:null,engines:[],instances:[]})),(infrastructureFast?Promise.resolve({host:null,servers:[],sites:[]}):cachedVMRead(`/api/v1/vms/${id}/web`)).catch(()=>({host:null,servers:[],sites:[]})),(infrastructureFast?Promise.resolve({host:null,items:[]}):cachedVMRead(`/api/v1/vms/${id}/software`)).catch(()=>({host:null,items:[]})),selectedSection==='monitoring'&&can('monitoring.read')?cachedVMRead(`/api/v1/vms/${id}/monitoring`).catch(()=>({metrics_targets:[],blackbox_targets:[],aliases:[]})):Promise.resolve({metrics_targets:[],blackbox_targets:[],aliases:[]}),['overview','continuity'].includes(selectedSection)&&can('documents.read')?cachedVMRead('/api/v1/outline/settings').catch(()=>({enabled:false})):Promise.resolve({enabled:false}),selectedSection.startsWith('security')?cachedVMRead(`/api/v1/security?vm_id=${id}`).catch(()=>({summary:{},accounts:[],databases:[],web_sites:[]})):Promise.resolve({summary:{},accounts:[],databases:[],web_sites:[]}),(infrastructureFast?Promise.resolve([]):api(`/api/v1/beneficiaries/assignments?resource_type=vm&resource_id=${id}&effective=true`)).catch(()=>[])]);
  const hardeningVMData=selectedSection==='security-hardening'?await api(`/api/v1/vms/${id}/hardening`).catch(()=>null):null;
  const vmOutlineMapping=selectedSection==='overview'&&can('documents.read')?await cachedVMRead(`/api/v1/vms/${id}/outline`).catch(()=>({configured:false})):null;
  const hardeningProfiles=selectedSection==='security-hardening'?await api('/api/v1/hardening/catalog').then(x=>x.profiles||[]).catch(()=>[]):[];
  const networkMapView=selectedSection==='network-map'?await api(`/api/v1/vms/${id}/network-map`).catch(err=>({scope:'vm',scope_id:id,name:'',vms:[],components:[],declared:[],fortigate_rules:[],host_firewall:[],summary:{},warnings:[err.message]})):null;
  if(detailID!==vmDetailGeneration)return;
  const documentationVMs=selectedSection==='services'&&can('vms.manage')?await fetchAllVMsForSelect():[];if(detailID!==vmDetailGeneration)return;
  const vm=data.vm,v=data.inventory||{},op=data.operational||{},inheritance=data.documentation_inheritance||{},backup=data.backup||{},backupDetails=data.backup_details||{},documentView=data.inventory_document||{},commonDependencies=Array.isArray(data.common_dependencies)?data.common_dependencies:[],primaryServices=Array.isArray(data.primary_agent_services)?data.primary_agent_services:[],primaryPorts=Array.isArray(data.primary_agent_ports)?data.primary_agent_ports:[],supportComponents=Array.isArray(data.support_components)?data.support_components:[],servicesReviewed=!!data.agent_services_reviewed;
  const serviceInherited=!!inheritance.source_vm_id&&!!inheritance.inherit_service_assignments,operationalInherited=!!inheritance.source_vm_id&&!!inheritance.inherit_operational_metadata,resourceInherited=!!inheritance.source_vm_id&&!!inheritance.inherit_resource_assignments;
  const ipAddresses=[...new Set([...(Array.isArray(data.ip_addresses)?data.ip_addresses:[]),op.preferred_ip,v.primary_ip,vm.primary_ip].filter(Boolean))];const preferredIP=op.preferred_ip||v.primary_ip||vm.primary_ip||'';const ipOptions='<option value="">— automat —</option>'+ipAddresses.map(ip=>`<option value="${e(ip)}" ${ip===preferredIP?'selected':''}>${e(ip)}</option>`).join('');
  const warningLabels={agent_data_unavailable:'Datele agentului asociat nu au putut fi încărcate.',inventory_data_unavailable:'Inventarul curent nu a putut fi încărcat.',inventory_document_unavailable:'Inventarul curent există, dar vederea structurată nu a putut fi generată.',operational_data_unavailable:'Datele operaționale nu au putut fi încărcate.',backup_data_unavailable:'Datele de backup nu au putut fi încărcate.',backup_details_unavailable:'Detaliile brute Veeam nu au putut fi interpretate.',common_dependencies_unavailable:'Dependențele către infrastructura comună nu au putut fi încărcate.',primary_agent_services_unavailable:'Selecția serviciilor software principale nu a putut fi încărcată.',primary_agent_ports_unavailable:'Selecția porturilor și proceselor principale nu a putut fi încărcată.',support_components_unavailable:'Componentele suport ale VM-ului nu au putut fi încărcate.',agent_services_review_unavailable:'Marcajul Servicii verificate nu a putut fi încărcat.',documentation_inheritance_unavailable:'Configurația de moștenire HA / cluster nu a putut fi încărcată.'};
  const vmWarnings=(Array.isArray(data.warnings)?data.warnings:[]).map(code=>warningLabels[code]||code),assignments=Array.isArray(op.service_assignments)?op.service_assignments:[];
  const hasSoftware=!!softwareView?.host&&((softwareView.items||[]).length>0||Number(softwareView.host.item_count||0)>0);if(selectedSection==='software'&&!hasSoftware){selectedSection='inventory';if(pendingVMCompletionFocus?.vmID===Number(id)&&pendingVMCompletionFocus.section==='software'){pendingVMCompletionFocus.section='inventory';pendingVMCompletionFocus.focus='';}}
  const sectionLabel=vmDetailSections.find(([code])=>code===selectedSection)?.[1]||'Rezumat';pageMeta(vm.name,`${sectionLabel} · fișă tehnică VM`);
  const agentOptions=infrastructureFast?`<option value="${vm.agent_id?Number(vm.agent_id):''}">${e(vm.agent_name||'Se încarcă lista agenților…')}</option>`:`<option value="">Fără agent</option>${agents.map(x=>`<option value="${x.id}" ${vm.agent_id===x.id?'selected':''}>${e(x.name)} (${e(x.status)})</option>`).join('')}`;
  const initialResponsibilities=Array.isArray(op.responsibilities)?op.responsibilities:[],assignmentRows=assignments.map((item,index)=>serviceAssignmentRow(item,services,categories,index)).join(''),vmDocumentPanel=selectedSection==='continuity'&&can('documents.read')?vmDocumentsPanel(id,documentTemplates,generatedDocuments,assignments,!!outlineSettings?.enabled,!!vm.outline_documentation_disabled,op.environment):'';
  const completion=infrastructureFast?{percent:null}:vmCompletion(vm,v,op,dockerView,databaseView,webView,documentView,primaryServices,primaryPorts,servicesReviewed,vmBeneficiaries.length);
  const vmOutlinePublishState=!outlineSettings?.enabled?'Nu · integrarea Outline este dezactivată global':vm.outline_documentation_disabled?'Nu · exclus explicit':environmentKind(op.environment)!=='prod'?`Nu · numai PROD (${environmentDisplay(op.environment)})`:'Da';
  const vmOutlinePolicyPanel=panel('Publicare Outline',can('vms.manage')?`<form id="vmOutlinePolicyForm" class="vm-compact-config-form"><div class="vm-compact-config-state"><span>Se publică în Outline</span><strong>${e(vmOutlinePublishState)}</strong></div><label class="vm-compact-check"><input id="vmOutlineDisabled" type="checkbox" ${vm.outline_documentation_disabled?'checked':''}> Nu se publică în Outline</label><p class="muted">Exclude VM-ul din publicarea individuală și în masă; pagina existentă nu este ștearsă. Independent de această bifă, publicarea Outline este permisă numai pentru mediul PROD.</p><div class="form-actions"><button type="submit" class="small">Salvează</button></div></form>`:`<div class="vm-compact-config-readonly"><span>Se publică în Outline</span><strong>${e(vmOutlinePublishState)}</strong></div>`);
  const vmVaultURL=String(vm.vault_url||'').trim();
  const vmVaultLink=vmOverviewExternalLink(vmVaultURL,vmVaultURL);
  const vmVaultPanel=panel('Vault',can('vms.manage')?`<form id="vmVaultForm" class="vm-compact-config-form"><label>Link Vault<input id="vmVaultURL" type="url" maxlength="2048" value="${e(vmVaultURL)}" placeholder="https://vault.../ui/vault/secrets/..."></label><p class="muted">Strict intern VM-DOC; nu intră în fișe, exporturi de documentație sau Outline.</p><div class="form-actions"><button type="submit" class="small">Salvează</button></div></form>`:`<div class="vm-compact-config-readonly"><p class="muted">Strict intern VM-DOC.</p></div>`);
  const vmOutlineURL=vmOutlineMapping?.configured?String(vmOutlineMapping.url||'').trim():'';
  const vmDocumentationURL=vmOutlineURL;
  const vmDocumentationSource=vmOutlineURL?'Deschide în Outline':'—';
  const vmOutlineVaultRow=`<div class="vm-outline-vault-row"><div class="vm-outline-vault-panels">${vmOutlinePolicyPanel}${vmVaultPanel}</div><div class="vm-outline-vault-links"><div class="vm-outline-vault-link"><span>Documentație</span>${vmOverviewExternalLink(vmDocumentationURL,vmDocumentationSource)}</div><div class="vm-outline-vault-link"><span>Vault</span>${vmVaultLink}<small>Doar în VM-DOC, niciodată în documentele generate sau Outline.</small></div></div></div>`;
  const overview=selectedSection==='overview'?`${panel('Identificare și încadrare',`<div class="vm-overview-identity"><div class="detail-grid">${detail('Nume VM',e(vm.name))}${detail('Hostname',e(v.hostname||vm.guest_hostname||'—'),true)}${detail('IP principal',e(preferredIP||'—'),true)}${detail('Sistem de operare',`${e(v.os_name||vm.guest_os||'—')} ${e(v.os_version||'')}`)}${detail('Mediu',e(op.environment?environmentDisplay(op.environment):'—'))}${detail('Status operațional',op.operational_status?badge(op.operational_status):'—')}${detail('Clasificare',e(op.classification||'—'))}${detail('Beneficiari',vmOverviewBeneficiaries(vmBeneficiaries))}</div><div class="vm-overview-responsibilities"><span>Responsabilități</span><div>${vmOverviewResponsibilities(op.responsibilities)}</div></div></div>`)}${vmOutlineVaultRow}${databaseOverviewNotice(databaseView)}${panel('Completarea fișei',`<div id="vmCompletionDetail">${vmCompletionHTML(completion,id)}</div>`,'<span class="muted">Criterii tehnice și operaționale esențiale</span>')}`:'';
  const resourceRequirements=resourceServiceRequirements(dockerView,databaseView,webView),resourceRequirementsNotice=resourceServiceConfigurationNotice(resourceRequirements,assignments);
  const inheritancePanel=vmDocumentationInheritancePanel(vm,inheritance,documentationVMs);
  const inheritedServiceNotice=serviceInherited?`<div class="notice inheritance-member-notice"><strong>Asocierile sunt moștenite din ${e(inheritance.source_vm_name||'VM-ul sursă')}.</strong><p>Modifică serviciile pe sursă sau treci acest VM pe documentație locală.</p></div>`:'';
  const servicesSection=selectedSection==='services'?`${inheritancePanel}${panel('Servicii interne și roluri tehnice',`${resourceRequirementsNotice}${inheritedServiceNotice}<form id="serviceAssignmentsForm" class="service-assignments-form"><fieldset class="inheritance-fieldset" ${serviceInherited?'disabled':''}><p class="muted">Fiecare asociere descrie unde se încadrează VM-ul în serviciu: clasificare, rol tehnic, tipul soluției și modul de utilizare.</p><div id="vmServiceAssignmentRows" class="vm-service-assignment-rows">${assignmentRows}</div>${can('vms.manage')&&!serviceInherited?'<div class="form-actions"><button type="button" id="addServiceAssignment" class="secondary">Adaugă asociere</button><button type="submit">Salvează asocierile</button></div>':serviceInherited?'<div class="muted form-actions">Configurare moștenită; editarea locală este blocată.</div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}</fieldset></form>`)}${panel('Dependențe infrastructură comună',vmCommonDependencies(id,commonDependencies,services,categories),'<span class="muted">Moștenite din servicii, globale implicit sau adăugate direct pe VM</span>')}`:'';
  const operationalInheritedNotice=operationalInherited?`<div class="notice inheritance-member-notice"><strong>Date comune moștenite din ${e(inheritance.source_vm_name||'VM-ul sursă')}.</strong><p>Scopul, clasificarea, responsabilitățile, RPO/RTO și observațiile se actualizează de pe sursă. Mediul, statusul și IP-ul principal rămân locale.</p></div>`:'';
  const operationalSection=selectedSection==='operational'?panel('Date operaționale',`${operationalInheritedNotice}<form id="operationalForm" class="operational-form"><div class="form-section"><h3>Încadrare operațională</h3><div class="form-grid"><label>Mediu<select id="opEnvironment">${nomenclatureOptions(categories,'environment',op.environment_id)}</select></label><label>Status operațional<select id="opStatus">${nomenclatureOptions(categories,'operational_status',op.operational_status_id)}</select></label><label>Clasificare<select id="opClassification">${nomenclatureOptions(categories,'classification',op.classification_id)}</select></label></div><label>Scopul VM-ului<textarea id="opPurpose" rows="3">${e(op.purpose||'')}</textarea></label><div class="form-grid"><label>IP principal documentație<select id="opPreferredIP">${ipOptions}</select></label><label>RPO (minute)<input id="opRPO" type="number" min="0" value="${op.rpo_minutes??1440}" placeholder="1440"></label><label>RTO (minute)<input id="opRTO" type="number" min="0" value="${op.rto_minutes??240}" placeholder="240"></label></div><p class="muted">IP-ul selectat este folosit în liste și fișe. RPO/RTO sunt valori de continuitate documentate pentru VM.</p></div><div class="form-section" id="vmResponsibilitiesSection"><div class="section-heading"><h3>Responsabilități</h3>${can('vms.manage')?'<button type="button" id="addResponsibility" class="small secondary">Adaugă persoană</button>':''}</div><h4 class="vm-responsibility-people-label">Persoane</h4><div id="responsibilityRows" class="responsibility-rows">${initialResponsibilities.map((item,index)=>responsibilityRow(item,people,index)).join('')}</div>${!people.length?'<p class="muted">Adaugă mai întâi persoane din meniul Nomenclatoare.</p>':''}${vmResponsibilityBeneficiaries(id)}</div><div class="form-section"><h3>Observații</h3><label class="vm-visually-hidden" for="opNotes">Observații</label><textarea id="opNotes" rows="4" aria-label="Observații">${e(op.notes||'')}</textarea></div>${can('vms.manage')?'<div class="form-actions"><button type="submit">Salvează datele operaționale</button></div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}</form>`):'';
  const resourceInheritedNotice=resourceInherited?`<div class="notice inheritance-member-notice"><strong>Asocierile resurselor sunt moștenite din ${e(inheritance.source_vm_name||'VM-ul sursă')}.</strong><p>Inventarul tehnic rămâne local. Pentru resursele potrivite automat se sincronizează proiectul/serviciul, mediul, statusul, tipul soluției, componenta, rolul, observațiile și marcajele de documentare.</p></div>`:'';
  const dockerSection=selectedSection==='docker'?`${resourceInheritedNotice}${dockerVMSection(dockerView,services,categories)}`:'';
  const databaseSection=selectedSection==='databases'?`${resourceInheritedNotice}${databaseVMSection(databaseView,services,categories)}`:'';
  const webSection=selectedSection==='web'?`${resourceInheritedNotice}${webVMSection(webView,services,categories)}`:'';
  const softwareSection=selectedSection==='software'?softwareVMSection(id,softwareView):'';
  const vmSecurityOverviewSection=selectedSection==='security'?securityVMOverview(id,securityView):'';
  const vmSecurityAccountsSection=selectedSection==='security-accounts'?securityVMAccounts(id,securityView):'';
  const vmSecurityDatabasesSection=selectedSection==='security-databases'?securityVMDatabaseAccess(id,securityView):'';
  const vmSecurityWebSection=selectedSection==='security-web'?securityVMWebAccess(id,securityView):'';
  const fortigateVMView=selectedSection==='security-firewall'&&can('fortigate.read')?await api(`/api/v1/fortigate/rules?vm_id=${id}&page=1&page_size=500`).catch(()=>({items:[],total:0,source_matches:0,destination_matches:0,vip_matches:0,high_risk:0})):({items:[],total:0,source_matches:0,destination_matches:0,vip_matches:0,high_risk:0});
  const vmSecurityFirewallSection=selectedSection==='security-firewall'?securityVMFirewallAccess(id,fortigateVMView,documentView):'';
  const networkMapSection=selectedSection==='network-map'?panel('Hartă rețea · DECLARAT / OBSERVAT / PERMIS',networkMapPanel(networkMapView),'<a class="button-link small secondary" href="#security/firewall-analysis">Analiză reguli FortiGate</a>','network-map-panel'): '';
  const inventoryTools=[can('collections.run')&&vm.agent_id?'<button id="testVMAgent" class="secondary">Test</button><button id="collectVM">Colect</button>':'',v.id&&can('inventories.raw.read')?'<button id="latestRaw" class="secondary">Vezi JSON brut</button>':''].filter(Boolean).join('');
  const primaryPortsPanel=vm.hide_listening_ports&&primaryPorts.length?panel('Porturi și procese principale',primaryPortsSummary(primaryPorts),'<span class="muted">Doar selecțiile marcate Principal</span>'):'';
  const inventorySection=selectedSection==='inventory'?`${primaryPortsPanel}${panel('Date colectate de agent',structuredInventory(documentView,{vmID:id,primaryServices,primaryPorts,supportComponents,servicesReviewed,canManage:can('vms.manage')}),inventoryTools)}<section id="rawPanel"></section>`:'';
  const backupTabSection=selectedSection==='backup'?`${panel('Backup și restaurare · sumar',backupSection(backup),'<span class="muted">Veeam + backup cron declarat</span>')}${can('vms.manage')?panel('Backup cron / script local',cronBackupForm(backup,documentView),'<span class="muted">Detectat de agent sau completat manual</span>'):''}${panel('Detalii Veeam',backupCandidateDetails(backupDetails),'<span class="muted">Lanțurile, joburile și politicile corelate cu această VM</span>')}`:'';
  const monitoringSection=selectedSection==='monitoring'?vmMonitoringSection(monitoringView):'';
  const continuitySection=`${vmDocumentPanel}`;
  const deletePanel=!vm.present_in_vcenter&&can('vms.manage')?panel('Curățare înregistrare VM',`<div class="vm-delete-detail"><div><strong>VM-ul nu mai este prezent în vCenter.</strong><p>Verifică dacă dispariția a fost planificată. Recomandat: Retrage VM, apoi arhivează logic, cu păstrarea documentației și a istoricului.</p><span class="muted">Lipsă din vCenter: ${dt(vm.missing_since)}</span></div><a href="#archive" class="button-link secondary">Vezi arhiva</a></div>`):'';
  const listeningPortsVisibilityPanel=infrastructureFast?panel('Porturi ascultate',can('vms.manage')?`<form id="vmListeningPortsVisibilityForm" class="vm-compact-config-form"><label class="vm-compact-check"><input id="vmHideListeningPorts" type="checkbox" ${vm.hide_listening_ports?'checked':''}> Ascunde porturile ascultate</label><p class="muted">Ascunde lista completă de porturi detectate din interfață și documentație. Porturile marcate <strong>Principal</strong> rămân vizibile separat în secțiunea lor și continuă să apară în fișa VM / Outline.</p><div class="form-actions"><button type="submit" class="small">Salvează</button></div></form>`:`<div class="vm-compact-config-readonly"><strong>${vm.hide_listening_ports?'Ascunse':'Afișate'}</strong><p class="muted">Lista completă este ascunsă; porturile principale rămân vizibile separat.</p></div>`):'';
  const infrastructureSection=`${panel('Date vCenter',`<div class="detail-grid">${detail('Sursă',e(vm.vcenter_source_name))}${detail('MoID',e(vm.vcenter_moid),true)}${detail('BIOS UUID',e(vm.bios_uuid||'—'),true)}${detail('Instance UUID',e(vm.instance_uuid||'—'),true)}${detail('CPU',e(vm.cpu_count))}${detail('RAM',memory(vm.memory_mib))}${detail('Hardware',e(vm.hardware_version||'—'))}${detail('Ultima vedere',dt(vm.last_seen_at))}${detail('Guest hostname',e(vm.guest_hostname||'—'))}${detail('Guest OS',e(vm.guest_os||'—'))}${detail('IP vCenter',e(vm.primary_ip||'—'),true)}${detail('Prezentă în vCenter',boolText(vm.present_in_vcenter))}${detail('Lipsă din vCenter din',vm.missing_since?dt(vm.missing_since):'—')}</div>`)}${panel('Asociere agent',`<form id="vmManageForm" class="detail-grid"><label><span>Agent asociat</span><select id="vmAgent" ${infrastructureFast?'disabled aria-busy="true"':''}>${agentOptions}</select></label>${can('vms.manage')?'<label class="form-submit"><button type="submit">Salvează</button></label>':''}</form>`,can('collections.run')&&vm.agent_id?'<button id="testVMAgent" class="secondary">Testează agentul</button><button id="collectVM">Colectează acum</button>':'')}${listeningPortsVisibilityPanel}${can('external.read')?panel('Conexiuni către sisteme externe',(infrastructureFast?'<div id="vmExternalConnectionsAsync" class="muted" role="status">Se încarcă legăturile externe…</div>':scopedExternalConnectionPanel('vm',id,externalConnections,externalSystems)),'<a class="button-link small secondary" href="#external">Sisteme externe</a>'):''}${deletePanel}`;
  const changesTools=`<span class="muted">Câmpurile volatile sunt ignorate; sunt afișate doar modificările după baseline.</span>${can('vms.manage')?'<button id="setVMBaseline" class="small secondary" type="button">Stabilește baseline VM</button>':''}`;
  const changesSection=selectedSection==='changes'?panel('Modificări inventar',vmChangesSection(id),changesTools):'';
  const historySection=`${panel('Istoric inventare','<div id="inventoryHistoryArea" class="loading">Se încarcă istoricul…</div>')}<section id="rawPanel"></section>`;
  const auditSection='<div id="scopedAuditRoot" class="loading">Se încarcă auditul VM-ului…</div>';
  const sectionBodies={overview,services:servicesSection,operational:operationalSection,docker:dockerSection,databases:databaseSection,web:webSection,software:softwareSection,security:vmSecurityOverviewSection,'security-accounts':vmSecurityAccountsSection,'security-databases':vmSecurityDatabasesSection,'security-web':vmSecurityWebSection,'security-firewall':vmSecurityFirewallSection,'security-hardening':hardeningVMBody(hardeningVMData,id,hardeningProfiles),'network-map':networkMapSection,inventory:inventorySection,backup:backupTabSection,monitoring:monitoringSection,continuity:continuitySection,infrastructure:infrastructureSection,changes:changesSection,history:historySection,audit:auditSection};
  const warnings=vmWarnings.length?`<div class="notice warning"><strong>Fișa a fost încărcată parțial.</strong><ul>${vmWarnings.map(message=>`<li>${e(message)}</li>`).join('')}</ul><span class="muted">Detaliul tehnic este în jurnalul serviciului vm-doc-server.</span></div>`:'';
  const workspaceClass=vmDetailGroupForSection(selectedSection,hasSoftware).code==='configuration'?'vm-detail-workspace vm-detail-workspace-configuration':'vm-detail-workspace';
  content.innerHTML=`${warnings}<div class="cards ui-kpi-seven vm-summary-cards"><div class="card"><div class="label">Completare fișă</div><div class="value compact" data-vm-completion-percent>${completion.percent===null?'…':`${completion.percent}%`}</div><div class="completion-progress"><i data-vm-completion-progress style="width:${completion.percent===null?0:completion.percent}%"></i></div></div><div class="card"><div class="label">IP principal</div><div class="value compact mono">${e(preferredIP||'—')}</div></div><div class="card"><div class="label">Baseline</div><div class="value compact">${vm.baseline_established?badge('yes'):badge('no')}</div></div><div class="card"><div class="label">Power state</div><div class="value compact">${badge(vm.power_state||'unknown')}</div></div><div class="card"><div class="label">Agent</div><div class="value compact">${badge(vm.agent_status)}</div><div class="muted">${e(vm.agent_name||'Neasociat')}</div></div><div class="card"><div class="label">Mediu</div><div class="value compact">${e(op.environment?environmentDisplay(op.environment):'—')}</div></div><div class="card"><div class="label">Status operațional</div><div class="value compact">${op.operational_status?badge(op.operational_status):'—'}</div></div></div>${vmDetailNavigation(id,selectedSection,hasSoftware)}<div class="${workspaceClass}">${sectionBodies[selectedSection]}</div>`;
  if(selectedSection==='overview'||selectedSection==='infrastructure'){
    const action=vm.retired?'archived':'retired';
    const lifecyclePanel=`<div class="lifecycle-detail-actions"><a class="button-link small secondary" href="#archive">Arhivă VM / servicii</a>${can('vms.manage')?`<button type="button" class="small secondary lifecycle-quick" data-status="${action}">${vm.retired?'Arhivează VM':'Retrage VM'}</button>`:''}</div>`;
    content.querySelector('.vm-detail-workspace')?.insertAdjacentHTML('beforebegin',lifecyclePanel);
    content.querySelector('.lifecycle-quick')?.addEventListener('click',()=>openLifecycleModal({type:'vm',id:Number(id),name:vm.name,status:vm.retired?'retired':'active',power_state:vm.power_state,present_in_vcenter:vm.present_in_vcenter},action));
  }
  // Event delegation păstrează legăturile funcționale și după reîmprospătarea asincronă a completării.
  document.getElementById('vmCompletionDetail')?.addEventListener('click',event=>{
    const link=event.target.closest('a[data-vm-completion-section]');
    if(!link)return;
    const destination=link.dataset.vmCompletionSection,focus=link.dataset.vmCompletionFocus||'';
    pendingVMCompletionFocus={vmID:Number(id),section:destination,focus};
    // Dacă ruta este deja aceeași, hashchange nu se declanșează: aplicăm focusul imediat.
    if(location.hash===link.getAttribute('href')){event.preventDefault();vmCompletionApplyFocus(id,selectedSection)}
  });
  markLifecycleArchiveOnDetail('vm',id);
  vmCompletionApplyFocus(id,selectedSection);
  if(infrastructureFast){
    // Cererile de configurare secundare nu împiedică afișarea formularului.
    // Protejăm toate răspunsurile întârziate față de navigarea între VM-uri/taburi.
    const stillHere=()=>detailID===vmDetailGeneration&&location.hash.split('/')[0]==='#vms'&&Number(location.hash.split('/')[1])===Number(id)&&location.hash.split('/')[2]==='infrastructure';
    if(can('agents.read')){
      cachedVMRead('/api/v1/agents').then(items=>{
        if(!stillHere())return;
        const select=document.getElementById('vmAgent');if(!select)return;
        const rows=Array.isArray(items)?items:[];
        select.innerHTML=`<option value="">Fără agent</option>${rows.map(item=>`<option value="${Number(item.id)}">${e(item.name)} (${e(item.status)})</option>`).join('')}`;
        const selected=vm.agent_id?String(vm.agent_id):'';
        if(selected&&!rows.some(item=>String(item.id)===selected))select.add(new Option(`${vm.agent_name||'Agent'} (neasociat în lista curentă)`,selected));
        select.value=selected;select.disabled=!can('vms.manage');select.removeAttribute('aria-busy');
      }).catch(err=>{
        if(!stillHere())return;
        const select=document.getElementById('vmAgent');if(select){select.disabled=true;select.setAttribute('title','Lista agenților nu a putut fi încărcată');}
        console.warn('VM infrastructure agents:',err);
      });
    }
    if(can('external.read')){
      Promise.all([cachedVMRead('/api/v1/external-systems?active=active'),cachedVMRead(`/api/v1/external-connections?vm_id=${id}`)]).then(([systems,connections])=>{
        if(!stillHere())return;
        const placeholder=document.getElementById('vmExternalConnectionsAsync');if(!placeholder)return;
        placeholder.outerHTML=scopedExternalConnectionPanel('vm',id,connections,systems);
        bindScopedExternalConnectionActions('vm',id,()=>vmDetail(id,'infrastructure'));
      }).catch(err=>{
        if(!stillHere())return;
        const placeholder=document.getElementById('vmExternalConnectionsAsync');if(placeholder)placeholder.textContent='Conexiunile externe nu au putut fi încărcate.';
        console.warn('VM infrastructure external connections:',err);
      });
    }
  }
  if(infrastructureFast){
    // Completarea este exactă doar când sunt disponibile și resursele Docker/DB/Web.
    // Nu blocăm afișarea infrastructurii pentru aceste inventare secundare.
    Promise.all([
      cachedVMRead(`/api/v1/vms/${id}/docker`).catch(()=>({host:null,containers:[]})),
      cachedVMRead(`/api/v1/vms/${id}/databases`).catch(()=>({host:null,instances:[]})),
      cachedVMRead(`/api/v1/vms/${id}/web`).catch(()=>({host:null,servers:[],sites:[]})),
      cachedVMRead(`/api/v1/beneficiaries/assignments?resource_type=vm&resource_id=${id}&effective=true`).catch(()=>[])
    ]).then(([dockerDeferred,databaseDeferred,webDeferred,beneficiariesDeferred])=>{
      if(detailID!==vmDetailGeneration)return;
      paintVMCompletion(vmCompletion(vm,v,op,dockerDeferred,databaseDeferred,webDeferred,documentView,primaryServices,primaryPorts,servicesReviewed,beneficiariesDeferred.length),id);
    }).catch(error=>console.warn('VM completion deferred',error));
  }
  if(selectedSection==='operational')loadBeneficiaryResourceCard("vm",id);
  if(selectedSection.startsWith('security'))bindSecurityReviewButtons(content);
  if(selectedSection==='network-map')bindNetworkDiagramActions(content,networkMapView);
  if(selectedSection==='security-firewall'){bindVMFortigateCardFilters(id);if((state.vmFirewallMode?.[id]||'forti')==='local')loadVMLocalFirewall(id);document.querySelectorAll('[data-firewall-mode]').forEach(btn=>btn.addEventListener('click',()=>{state.vmFirewallMode=state.vmFirewallMode||{};state.vmFirewallMode[id]=btn.dataset.firewallMode;if(btn.dataset.firewallMode==='local')loadVMLocalFirewall(id);document.querySelectorAll('.firewall-vm-mode').forEach(section=>section.hidden=section.dataset.firewallVmMode!==btn.dataset.firewallMode);document.querySelectorAll('[data-firewall-overview-kpis]').forEach(group=>group.hidden=btn.dataset.firewallMode!=='forti');document.querySelectorAll('[data-firewall-mode]').forEach(b=>{b.classList.toggle('secondary',b.dataset.firewallMode!==btn.dataset.firewallMode);b.setAttribute('aria-pressed',String(b.dataset.firewallMode===btn.dataset.firewallMode))})}));document.querySelectorAll('.firewall-vm-mode').forEach(section=>{const btn=section.querySelector('.firewall-filter-toggle'),fields=section.querySelector('.firewall-filter-body');btn?.addEventListener('click',()=>{const open=fields.hidden;fields.hidden=!open;btn.textContent=open?'⌃':'⌄';btn.setAttribute('aria-expanded',String(open))})})}
  if(selectedSection==='security-hardening')bindHardeningVMControls(id);

  document.getElementById('documentationInheritanceForm')?.addEventListener('submit',async ev=>{ev.preventDefault();const sourceValue=document.getElementById('documentationSourceVM').value,sourceID=sourceValue?Number(sourceValue):null,inheritServices=document.getElementById('inheritServiceAssignments').checked,inheritOperational=document.getElementById('inheritOperationalMetadata').checked,inheritResources=document.getElementById('inheritResourceAssignments').checked,groupName=document.getElementById('documentationGroupName').value.trim(),groupType=document.getElementById('documentationGroupType').value;if(sourceID&&(!groupName)){toast('Completează numele grupului HA / cluster.',true);return}if(sourceID&&(inheritServices||inheritOperational||inheritResources)&&!confirm('Activarea moștenirii va înlocui pe acest VM valorile locale selectate cu cele de pe VM-ul sursă. Pentru Docker/DB/Web se copiază doar documentarea/asocierile resurselor potrivite, nu inventarul tehnic. Continui?'))return;try{await api(`/api/v1/vms/${id}/documentation-inheritance`,{method:'PUT',body:JSON.stringify({source_vm_id:sourceID,group_name:groupName,group_type:groupType,inherit_service_assignments:inheritServices,inherit_operational_metadata:inheritOperational,inherit_resource_assignments:inheritResources})});toast(sourceID?'Moștenirea documentației a fost activată.':'Documentația VM-ului este locală.');vmDetail(id,'services')}catch(err){toast(err.message,true)}});
  document.getElementById('clearDocumentationInheritance')?.addEventListener('click',async()=>{if(!confirm('Treci acest VM pe documentație locală? Valorile copiate până acum rămân și pot fi modificate independent.'))return;try{await api(`/api/v1/vms/${id}/documentation-inheritance`,{method:'PUT',body:JSON.stringify({source_vm_id:null,group_name:'',group_type:'cluster',inherit_service_assignments:false,inherit_operational_metadata:false,inherit_resource_assignments:false})});toast('Moștenirea a fost dezactivată; valorile curente au rămas locale.');vmDetail(id,'services')}catch(err){toast(err.message,true)}});
  document.getElementById('syncInheritedResources')?.addEventListener('click',async()=>{const button=document.getElementById('syncInheritedResources');if(button)button.disabled=true;try{const result=await api(`/api/v1/vms/${id}/documentation-inheritance/sync-resources`,{method:'POST'});const matched=Number(result.docker_matched||0)+Number(result.database_matched||0)+Number(result.database_catalogs_matched||0)+Number(result.web_matched||0),unmatched=Number(result.docker_unmatched||0)+Number(result.database_unmatched||0)+Number(result.web_unmatched||0);toast(`Sincronizare terminată: ${matched} resurse potrivite${unmatched?`, ${unmatched} fără corespondent`:''}.`);vmDetail(id,'services')}catch(err){toast(err.message,true);if(button)button.disabled=false}});
  if(operationalInherited){['opClassification','opPurpose','opRPO','opRTO','opNotes'].forEach(key=>{const el=document.getElementById(key);if(el)el.disabled=true});document.getElementById('addResponsibility')?.setAttribute('disabled','disabled');document.querySelectorAll('#responsibilityRows input,#responsibilityRows select,#responsibilityRows button').forEach(el=>el.disabled=true)}
  if(resourceInherited&&['docker','databases','web'].includes(selectedSection)){document.querySelectorAll('.vm-detail-workspace input,.vm-detail-workspace select,.vm-detail-workspace textarea,.vm-detail-workspace button').forEach(el=>el.disabled=true)}

  const assignmentContainer=document.getElementById('vmServiceAssignmentRows');
  assignmentContainer?.querySelectorAll('.vm-service-assignment-card').forEach((row,index)=>wireServiceAssignmentRow(row,services,categories,assignments[index]||{}));
  document.getElementById('addServiceAssignment')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=serviceAssignmentRow(null,services,categories,assignmentContainer.children.length);const row=wrapper.firstElementChild;assignmentContainer.appendChild(row);wireServiceAssignmentRow(row,services,categories,{})});
  assignmentContainer?.addEventListener('click',event=>{const button=event.target.closest('.remove-service-assignment');if(button)button.closest('.vm-service-assignment-card').remove()});
  assignmentContainer?.addEventListener('change',event=>{if(!event.target.classList.contains('assignment-primary-input')||!event.target.checked)return;assignmentContainer.querySelectorAll('.assignment-primary-input').forEach(input=>{if(input!==event.target)input.checked=false})});
  bindVMDependencyActions(id);bindPrimaryAgentServiceActions(id);bindPrimaryAgentPortActions(id);
  if(selectedSection==='docker'){bindDockerComposeCollapse(id);registerResourceEditor(id,'docker',dockerView,services,categories);paintResourceBeneficiaries(id,['docker'])}if(selectedSection==='docker'&&!resourceInherited)bindDockerActions(id,dockerView,services);
  if(selectedSection==='databases'){registerResourceEditor(id,'databases',databaseView,services,categories);paintResourceBeneficiaries(id,['database'])}if(selectedSection==='databases'&&!resourceInherited)bindDatabaseActions(id,databaseView,services);
  if(selectedSection==='web'){registerResourceEditor(id,'web',webView,services,categories);paintResourceBeneficiaries(id,['web'])}if(selectedSection==='web'&&!resourceInherited)bindWebActions(id,webView);
  if(selectedSection==='software')bindSoftwareActions(id,softwareView);
  document.getElementById('serviceAssignmentsForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const rows=[...assignmentContainer.querySelectorAll('.vm-service-assignment-card')];const values=rows.map((row,index)=>({architectural_domain_id:Number(row.querySelector('.assignment-domain').value||0),itil_category_id:Number(row.querySelector('.assignment-category').value||0),internal_service_id:Number(row.querySelector('.assignment-service').value||0),layer_id:Number(row.querySelector('.assignment-layer').value||0),technical_role_id:Number(row.querySelector('.assignment-role').value||0),solution_type_id:Number(row.querySelector('.assignment-solution-type').value||0),usage_type:row.querySelector('.assignment-usage').value,is_primary:row.querySelector('.assignment-primary-input').checked,notes:row.querySelector('.assignment-note').value.trim(),sort_order:index}));if(values.some(item=>!item.architectural_domain_id||!item.itil_category_id||!item.internal_service_id||!item.layer_id||!item.technical_role_id||!item.solution_type_id)){toast('Completează domeniul, categoria de serviciu, serviciul intern, layer-ul, rolul tehnic și tipul soluției pentru fiecare asociere.',true);return}try{await api(`/api/v1/vms/${id}/service-assignments`,{method:'PUT',body:JSON.stringify({assignments:values})});toast('Asocierile cu serviciile interne au fost salvate.');vmDetail(id,'services')}catch(err){toast(err.message,true)}});
  const responsibilityRows=document.getElementById('responsibilityRows');document.getElementById('addResponsibility')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=responsibilityRow(null,people,responsibilityRows.children.length);responsibilityRows.appendChild(wrapper.firstElementChild)});responsibilityRows?.addEventListener('click',event=>{const button=event.target.closest('.remove-responsibility');if(button)button.closest('.responsibility-row').remove()});
  document.getElementById('operationalForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const responsibilities=[...document.querySelectorAll('.responsibility-row')].map((row,index)=>({person_id:Number(row.querySelector('.responsibility-person').value||0),responsibility_type:row.querySelector('.responsibility-type').value,notes:row.querySelector('.responsibility-note').value.trim(),sort_order:index})).filter(item=>item.person_id>0);const selected=elementId=>{const value=document.getElementById(elementId).value;return value?Number(value):null};const body={environment_id:selected('opEnvironment'),operational_status_id:selected('opStatus'),purpose:document.getElementById('opPurpose').value.trim(),responsibilities,classification_id:selected('opClassification'),documentation_url:String(op.documentation_url||''),ticket_reference:String(op.ticket_reference||''),notes:document.getElementById('opNotes').value.trim(),preferred_ip:document.getElementById('opPreferredIP').value,rpo_minutes:document.getElementById('opRPO').value===''?1440:Number(document.getElementById('opRPO').value),rto_minutes:document.getElementById('opRTO').value===''?240:Number(document.getElementById('opRTO').value)};try{await api(`/api/v1/vms/${id}/operational`,{method:'PUT',body:JSON.stringify(body)});toast('Datele operaționale au fost salvate.');vmDetail(id,'operational')}catch(err){toast(err.message,true)}});
  document.getElementById('vmManageForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const selected=document.getElementById('vmAgent').value;const body={};if(selected)body.agent_id=Number(selected);else if(vm.agent_id)body.clear_agent=true;try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify(body)});toast('Asocierea agentului a fost actualizată.');vmDetail(id,'infrastructure')}catch(err){toast(err.message,true)}});
  document.getElementById('vmListeningPortsVisibilityForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const hidden=!!document.getElementById('vmHideListeningPorts')?.checked;try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify({hide_listening_ports:hidden})});toast(hidden?'Lista porturilor ascultate a fost ascunsă. Porturile principale rămân vizibile separat.':'Porturile ascultate vor fi afișate din nou.');vmDetail(id,'infrastructure')}catch(err){toast(err.message,true)}});
  document.getElementById('vmOutlinePolicyForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const disabled=!!document.getElementById('vmOutlineDisabled')?.checked;try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify({outline_documentation_disabled:disabled})});toast(disabled?'VM-ul nu va fi publicat în Outline.':'Publicarea Outline este permisă pentru VM.');vmDetail(id,selectedSection)}catch(err){toast(err.message,true)}});
  document.getElementById('vmVaultForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const vaultURL=document.getElementById('vmVaultURL')?.value?.trim()||'';try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify({vault_url:vaultURL})});toast(vaultURL?'Linkul Vault a fost salvat.':'Linkul Vault a fost eliminat.');vmDetail(id,selectedSection)}catch(err){toast(err.message,true)}});
  document.getElementById('deleteVMPermanent')?.addEventListener('click',()=>deleteVMPermanent(Number(id),async()=>{location.hash='#vms'}));
  document.getElementById('testVMAgent')?.addEventListener('click',()=>vmJob(id,'test-agent'));document.getElementById('collectVM')?.addEventListener('click',()=>vmJob(id,'collect'));bindVMDocumentActions(id);
  document.querySelectorAll('input[name="cronBackupDetected"]').forEach(input=>input.addEventListener('change',()=>{if(!input.checked)return;const entry=cronInventoryEntries(documentView)[Number(input.value)];if(!entry)return;document.getElementById('cronBackupEnabled').checked=true;document.getElementById('cronBackupSchedule').value=entry.schedule||'';document.getElementById('cronBackupCommand').value=entry.command||'';const notes=document.getElementById('cronBackupNotes');if(!notes.value.trim()&&entry.user)notes.value=`Cron detectat de agent · user ${entry.user}${entry.source?` · ${entry.source}`:''}`}));
  document.getElementById('cronBackupForm')?.addEventListener('submit',async ev=>{ev.preventDefault();const body={enabled:document.getElementById('cronBackupEnabled').checked,schedule:document.getElementById('cronBackupSchedule').value.trim(),command:document.getElementById('cronBackupCommand').value.trim(),notes:document.getElementById('cronBackupNotes').value.trim()};try{await api(`/api/v1/vms/${id}/backup-settings`,{method:'PUT',body:JSON.stringify(body)});toast('Backup-ul cron a fost salvat în documentație.');vmDetail(id,'backup')}catch(err){toast(err.message,true)}});
  document.getElementById('monitoringAliasForm')?.addEventListener('submit',async ev=>{ev.preventDefault();const aliases=document.getElementById('monitoringAliases').value.split(/\r?\n/).map(v=>v.trim()).filter(Boolean);try{await api(`/api/v1/vms/${id}/monitoring/aliases`,{method:'PUT',body:JSON.stringify({aliases})});toast('Aliasurile au fost salvate. Rulează Sync Prometheus pentru recorelare.');vmDetail(id,'monitoring')}catch(err){toast(err.message,true)}});
  if(can('external.read'))bindScopedExternalConnectionActions('vm',id,()=>vmDetail(id,'infrastructure'));
  document.getElementById('latestRaw')?.addEventListener('click',async()=>{try{const raw=await api(`/api/v1/inventories/${v.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${v.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}});
  if(selectedSection==='changes'){document.getElementById('setVMBaseline')?.addEventListener('click',async()=>{if(!confirm('Stabilești inventarul curent al acestei VM ca baseline? Modificările existente rămân în istoric, dar nu vor mai apărea în trierea curentă.'))return;try{await api('/api/v1/changes/baseline',{method:'POST',body:JSON.stringify({vm_id:Number(id)})});toast('Baseline-ul VM-ului a fost actualizat.');state.vmChanges.page=1;vmDetail(id,'changes')}catch(err){toast(err.message,true)}});changeSearchResultFeedback=bindChangeFilters(()=>loadVMChanges(id),state.vmChanges);await loadVMChanges(id)}
  if(selectedSection==='history')await loadInventoryHistory(id);
  if(selectedSection==='audit'&&can('audit.read'))await scopedAuditPage('vm',id);
}
function bindRawInventoryButtons(scope=document){scope.querySelectorAll('.show-raw').forEach(button=>button.onclick=async()=>{try{const raw=await api(`/api/v1/inventories/${button.dataset.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${button.dataset.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}})}
function renderInventoryHistoryPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există snapshoturi pentru această VM.');
  const rows=items.map(item=>`<tr><td>${dt(item.received_at)}</td><td>${e(item.hostname)}</td><td>${e(item.os_name)} ${e(item.os_version)}</td><td>${item.collector_ok}/${item.collector_total}</td><td>${item.changed_from_previous?badge('changed'):badge('same')}</td><td>${can('inventories.raw.read')?`<button class="small secondary show-raw" data-id="${item.id}">JSON</button>`:''}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||10),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Primit</th><th>Hostname</th><th>OS</th><th>Colectori</th><th>Schimbare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="inventoryHistoryPageSize">${pageSizeOptions(pageSize,[10,20,50,100])}</select></label>${paginationButtons(page,Number(result.pages||1),'inventory-history-page')}</div></div>`;
}
async function loadInventoryHistory(vmID){
  const area=document.getElementById('inventoryHistoryArea');if(!area)return;area.className='loading';area.textContent='Se încarcă istoricul…';
  try{const result=await api(`/api/v1/vms/${vmID}/inventories?page=${state.vmHistory.page}&page_size=${state.vmHistory.pageSize}`);state.vmHistory.page=Number(result?.page||1);state.vmHistory.pageSize=Number(result?.page_size||10);area.className='';area.innerHTML=renderInventoryHistoryPage(result);bindRawInventoryButtons(area);area.querySelectorAll('.inventory-history-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmHistory.page){state.vmHistory.page=page;loadInventoryHistory(vmID)}}));document.getElementById('inventoryHistoryPageSize')?.addEventListener('change',event=>{state.vmHistory.pageSize=Number(event.target.value);state.vmHistory.page=1;loadInventoryHistory(vmID)})}catch(err){area.className='';area.innerHTML=empty(err.message);changeSearchResultFeedback(0,err.message);toast(err.message,true)}
}
async function vmJob(id,action){try{const job=await api(`/api/v1/vms/${id}/${action}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(()=>vmDetail(id),1200)}catch(err){toast(err.message,true)}}

let internalServicesCache=[];
const criticalityLabels={low:'Scăzută',normal:'Normală',high:'Ridicată',critical:'Critică'};
const documentationStatusLabels={draft:'Draft',in_progress:'În lucru',review:'În verificare',approved:'Aprobată',obsolete:'Depășită'};
function criticalityBadge(value){return badge(value||'normal')}
function openInternalService(service=null){
  document.getElementById('internalServiceDialogTitle').textContent=service?'Editare serviciu intern':'Serviciu intern nou';
  document.getElementById('internalServiceId').value=service?.id||'';
  document.getElementById('internalServiceName').value=service?.name||'';
  document.getElementById('internalServiceCode').value=service?.service_code||'';
  document.getElementById('internalServiceShortDescription').value=service?.short_description||'';
  document.getElementById('internalServiceAuthentication').value=service?.authentication||'';
  document.getElementById('internalServiceURL').value=service?.service_url||'';
  document.getElementById('internalServiceTechnologies').value=service?.technologies||'';
  document.getElementById('internalServiceCriticality').value=service?.criticality||'normal';
  document.getElementById('internalServiceDocStatus').value=service?.documentation_status||'draft';
  setRichTextEditor('internalServiceDescriptionRich',service?.description_richtext,service?.description||'');
  setRichTextEditor('internalServicePurposeRich',service?.purpose_richtext,service?.purpose||'');
  setRichTextEditor('internalServiceObjectivesRich',service?.objectives_richtext,service?.objectives||'');
  document.getElementById('internalServiceDocumentationURL').value=service?.documentation_url||'';
  document.getElementById('internalServiceActive').checked=service?.active??true;
  document.getElementById('internalServiceRetired').checked=!!service?.retired;
  document.getElementById('internalServiceRetirementReason').innerHTML=selectOptions(categoryItems(nomenclatureCache,'service_retirement_reason'),service?.retirement_reason_id,'— Fără motiv —');
  document.getElementById('internalServiceRetiredAt').value=service?.retired_at?String(service.retired_at).slice(0,10):'';
  document.getElementById('internalServiceOutlineDisabled').checked=!!service?.outline_documentation_disabled;
  document.getElementById('internalServiceCommon').checked=!!service?.is_common;
  document.getElementById('internalServiceImplicitGlobal').checked=!!service?.implicit_global;
  const dependencyType=document.getElementById('internalServiceCommonDependencyType');dependencyType.innerHTML=selectOptions(categoryItems(nomenclatureCache,'dependency_type'),service?.common_dependency_type_id,'— Alege tipul dependenței —');
  dependencyType.disabled=!document.getElementById('internalServiceCommon').checked;
  syncInternalServiceLifecycle();
  internalServiceDialog.showModal();
}
function serviceClassificationSummary(values){
  if(!values?.length)return '<span class="muted">Neîncadrat încă</span>';
  return `<div class="service-classification-summary">${values.map(item=>`<div><strong>${e(item.architectural_domain)}</strong><span>${e(item.itil_category)} · ${item.vm_count||0} VM</span></div>`).join('')}</div>`;
}
function serviceSolutionSummary(values){
  if(!values?.length)return '<span class="muted">Nespecificat</span>';
  return `<div class="service-solution-summary">${values.map(item=>`<span>${e(item.solution_type)} <b>${item.vm_count||0}</b></span>`).join('')}</div>`;
}
function observedServiceClassifications(values){
  if(!values?.length)return empty('Domeniul și categoria de serviciu vor apărea automat după prima asociere făcută din fișa unui VM.');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Domeniu arhitectural</th><th>Categorie de serviciu</th><th>VM-uri</th><th>Asocieri</th></tr></thead><tbody>${values.map(item=>`<tr><td>${e(item.architectural_domain)}</td><td>${e(item.itil_category)}</td><td>${item.vm_count||0}</td><td>${item.assignment_count||0}</td></tr>`).join('')}</tbody></table></div>`;
}
function observedServiceRoles(values){
  if(!values?.length)return empty('Nu există încă layer-e și roluri tehnice. Acestea apar automat după asocierea VM-urilor.');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Layer</th><th>Rol tehnic</th><th>VM-uri</th><th>Stare</th></tr></thead><tbody>${values.map(mapping=>`<tr><td>${e(mapping.layer_name)}</td><td>${e(mapping.technical_role)}</td><td>${mapping.vm_count||0}</td><td>${mapping.active?badge('active'):badge('disabled')}</td></tr>`).join('')}</tbody></table></div>`;
}
function observedServiceSolutionTypes(values){
  if(!values?.length)return empty('Tipul soluției va apărea automat după ce este ales pe asocierile VM ale serviciului.');
  return `<div class="service-solution-cards">${values.map(item=>`<div class="service-solution-card"><span>${e(item.solution_type)}</span><strong>${item.vm_count||0} VM</strong><small>${item.assignment_count||0} asocieri</small></div>`).join('')}</div>`;
}
function environmentKind(value){const v=String(value||'').toLocaleLowerCase('ro-RO');if(v.includes('prod')||v.includes('produc'))return 'prod';if(v.includes('test')||v.includes('uat')||v.includes('qa'))return 'test';if(v.includes('dev')||v.includes('dezvolt'))return 'dev';return v?'other':'missing'}
function environmentDisplay(value){const raw=String(value||'').trim(),kind=environmentKind(raw);if(kind==='prod')return 'PROD';if(kind==='test')return 'TEST';if(kind==='dev')return 'DEV';return raw?raw.toLocaleUpperCase('ro-RO'):'Nespecificat'}
function environmentBadge(value){const kind=environmentKind(value),label=environmentDisplay(value);return `<span class="environment-badge ${kind}">${e(label)}</span>`}
function serviceEnvironmentStats(values){const unique=new Map();for(const item of values||[]){if(!unique.has(Number(item.id)))unique.set(Number(item.id),item)}const stats={prod:0,test:0,dev:0,other:0,missing:0,total:unique.size,groups:new Map()};for(const vm of unique.values()){const kind=environmentKind(vm.environment);stats[kind]=(stats[kind]||0)+1;const label=environmentDisplay(vm.environment);if(!stats.groups.has(label))stats.groups.set(label,[]);stats.groups.get(label).push(vm)}return stats}
function serviceEnvironmentPanel(values){const stats=serviceEnvironmentStats(values);if(!stats.total)return empty('Nu există VM-uri asociate.');const rows=[...stats.groups.entries()].sort((a,b)=>{const order={prod:1,test:2,dev:3,other:4,missing:5};return (order[environmentKind(a[0])]||9)-(order[environmentKind(b[0])]||9)||a[0].localeCompare(b[0],'ro')}).map(([env,vms])=>`<div class="service-environment-group"><div>${environmentBadge(env)}<strong>${vms.length} VM</strong></div><span>${vms.map(vm=>`<a href="#vms/${vm.id}">${e(vm.guest_hostname||vm.name)}</a>`).join(', ')}</span></div>`).join('');const kpis=[];if(stats.prod)kpis.push(`<div class="environment-kpi prod"><span>PROD</span><strong>${stats.prod}</strong></div>`);if(stats.test)kpis.push(`<div class="environment-kpi test"><span>TEST / UAT</span><strong>${stats.test}</strong></div>`);if(stats.dev)kpis.push(`<div class="environment-kpi dev"><span>DEV</span><strong>${stats.dev}</strong></div>`);if(stats.other+stats.missing)kpis.push(`<div class="environment-kpi other"><span>Altele / lipsă</span><strong>${stats.other+stats.missing}</strong></div>`);return `<div class="service-environment-summary">${kpis.length?`<div class="service-environment-kpis">${kpis.join('')}</div>`:''}<div class="service-environment-groups">${rows}</div></div>`}
function serviceTopCards(service){const stats=serviceEnvironmentStats(service.vms),serviceState=service.retired?badge('retired'):(service.active?badge('active'):badge('disabled')),cards=[`<div class="card"><div class="label">Criticitate</div><div class="value compact">${criticalityBadge(service.criticality)}</div></div>`,`<div class="card"><div class="label">Stare</div><div class="value compact">${serviceState}</div></div>`,`<div class="card"><div class="label">Documentație</div><div class="value compact">${badge(service.documentation_status||'draft')}</div></div>`,`<div class="card"><div class="label">VM-uri</div><div class="value">${service.vm_count||0}</div></div>`];if(service.is_common){cards.push(`<div class="card common-service-card"><div class="label">Serviciu comun</div><div class="value compact">${service.implicit_global?badge('global'):badge('common')}</div></div>`);cards.push(`<div class="card common-service-card"><div class="label">Servicii afectate</div><div class="value">${service.dependent_service_count||0}</div></div>`);if((service.direct_vm_dependents||[]).length)cards.push(`<div class="card common-service-card"><div class="label">VM direct afectate</div><div class="value">${service.direct_vm_dependents.length}</div></div>`)}if(stats.prod)cards.push(`<div class="card environment-card prod"><div class="label">PROD</div><div class="value">${stats.prod}</div></div>`);if(stats.test)cards.push(`<div class="card environment-card test"><div class="label">TEST / UAT</div><div class="value">${stats.test}</div></div>`);if(stats.dev)cards.push(`<div class="card environment-card dev"><div class="label">DEV</div><div class="value">${stats.dev}</div></div>`);return `<div class="cards service-summary-cards">${cards.join('')}</div>`}

const nomenclatureIconGlyphs={domain:'🧭',category:'🗂️',layers:'🧱',role:'⚙️',app:'🧩',database:'🗄️',web:'🌐',integration:'🔌',monitor:'📈',shield:'🛡️',package:'📦',code:'⌨️',store:'🏢',environment:'🌍',status:'●',tag:'🏷️',server:'🖥️'};
function nomenclatureIcon(key,size='normal'){
  const normalized=String(key||'').trim();const glyph=nomenclatureIconGlyphs[normalized]||'◆';
  return `<span class="nomenclature-icon ${e(size)}" title="${e(normalized||'implicit')}">${glyph}</span>`;
}
function nomenclatureItemByID(categories,id){
  const numeric=Number(id||0);for(const category of (categories||[])){const found=(category.items||[]).find(item=>Number(item.id)===numeric);if(found)return found}return null;
}
function serviceAllDependencies(service){return [...(service.dependencies||[]),...(service.global_dependencies||[])].filter(item=>item.active!==false)}
function dependencyCriticalityBadge(value){const v=String(value||'normal').toLowerCase();const labels={informational:'Informativă',normal:'Normală',critical:'Critică'};return `<span class="dependency-criticality ${e(v)}">${e(labels[v]||v)}</span>`}
function dependencyEnvironmentText(dep){const source=dep.source_environment||'Oricare',target=dep.target_environment||'Oricare';return `${e(source)} <span class="dependency-flow-arrow">→</span> ${e(target)}`}
function dependencyEndpointText(dep){const parts=[];if(dep.protocol)parts.push(e(dep.protocol));if(dep.port)parts.push(`<span class="mono">${Number(dep.port)}</span>`);return parts.length?parts.join(' / '):'—'}
function serviceDependencyStrip(service){const deps=serviceAllDependencies(service);if(!deps.length)return '';return `<section class="service-common-diagram"><header><strong>Dependențe către alte servicii</strong><span>${deps.length} fluxuri</span></header><div class="service-common-nodes">${deps.map(dep=>`<a href="#services/${dep.target_service_id}" class="service-common-node ${dep.global?'global':''}">${nomenclatureIcon(dep.dependency_type_icon||'integration','small')}<div><strong>${e(dep.target_service_name)}</strong><span>${e(dep.dependency_type)}${dep.source_environment||dep.target_environment?` · ${e(dep.source_environment||'Oricare')} → ${e(dep.target_environment||'Oricare')}`:''}${dep.protocol||dep.port?` · ${dependencyEndpointText(dep)}`:''}${dep.notes?` · ${e(dep.notes)}`:''}${dep.global?' · global':''}</span></div><b>${dependencyCriticalityBadge(dep.criticality)}</b></a>`).join('')}</div><div class="dependency-arrow">↓ fluxuri de integrare către servicii dependente</div></section>`}
function serviceDependenciesPanel(service,services,categories){
  const explicit=service.dependencies||[],global=service.global_dependencies||[],all=[...explicit,...global];
  const rows=all.map(dep=>`<tr class="${dep.active===false?'dependency-inactive':''}"><td><a href="#services/${dep.target_service_id}"><strong>${e(dep.target_service_name)}</strong></a>${dep.global?'<div class="muted">Serviciu global implicit</div>':''}</td><td>${nomenclatureIcon(dep.dependency_type_icon||'integration','tiny')} ${e(dep.dependency_type)}</td><td>${dependencyEnvironmentText(dep)}</td><td>${dependencyCriticalityBadge(dep.criticality)}</td><td>${dependencyEndpointText(dep)}</td><td>${dep.target_vm_count||0}${dep.target_vm_names?`<div class="muted">${e(dep.target_vm_names)}</div>`:''}</td><td>${dep.global?badge('global'):(dep.active===false?badge('disabled'):badge('active'))}</td><td>${e(dep.notes||'—')}</td><td>${dep.id&&can('services.manage')?`<div class="dependency-actions"><button class="small secondary toggle-service-dependency" data-id="${dep.id}" data-active="${dep.active===false?'0':'1'}">${dep.active===false?'Activează':'Dezactivează'}</button><button class="small danger delete-service-dependency" data-id="${dep.id}">Șterge</button></div>`:'—'}</td></tr>`).join('');
  const targetServices=(services||[]).filter(item=>item.active&&Number(item.id)!==Number(service.id));const types=categoryItems(categories,'dependency_type'),environments=categoryItems(categories,'environment');
  const form=can('services.manage')&&targetServices.length&&types.length?`<form id="serviceDependencyForm" class="service-dependency-form service-dependency-editor"><div class="muted span-3">Fiecare rând este un flux separat. Poți adăuga aceeași destinație și același tip de relație de mai multe ori, de exemplu pe porturi sau pentru scopuri diferite.</div><label class="span-2">Acest serviciu depinde de<select id="serviceDependencyTarget" required><option value="">— Alege serviciul —</option>${targetServices.map(item=>`<option value="${item.id}">${e(item.name)}${item.is_common?(item.implicit_global?' · GLOBAL':' · comun'):''}</option>`).join('')}</select></label><label>Tip relație<select id="serviceDependencyType" required>${selectOptions(types,'','— Alege tipul —')}</select></label><label>Criticitate<select id="serviceDependencyCriticality"><option value="informational">Informativă</option><option value="normal" selected>Normală</option><option value="critical">Critică</option></select></label><label>Mediu sursă<select id="serviceDependencySourceEnvironment">${selectOptions(environments,'','Oricare / nespecificat')}</select></label><label>Mediu destinație<select id="serviceDependencyTargetEnvironment">${selectOptions(environments,'','Oricare / nespecificat')}</select></label><label>Protocol<input id="serviceDependencyProtocol" maxlength="64" placeholder="HTTPS, LDAP, JDBC, TCP…"></label><label>Port<input id="serviceDependencyPort" type="number" min="1" max="65535" placeholder="443"></label><label class="span-3">Scop / detalii<input id="serviceDependencyNotes" maxlength="1000" placeholder="Ex. syslog, verificare clienți/update, endpoint sau alte particularități…"></label><label class="check-inline dependency-active-check"><input id="serviceDependencyActive" type="checkbox" checked> Activă</label><button type="submit">Adaugă dependență</button></form>`:'';
  return `<div class="dependency-direction-section"><div class="dependency-section-heading"><div><strong>Depinde de</strong><span>Relații ieșite din ${e(service.name)}</span></div><span class="muted">${all.filter(x=>x.active!==false).length} active</span></div>${form}${rows?`<div class="table-wrap"><table class="compact-table dependency-table"><thead><tr><th>Serviciu destinație</th><th>Tip</th><th>Medii</th><th>Criticitate</th><th>Protocol / port</th><th>VM-uri</th><th>Stare</th><th>Detalii</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există dependențe declarate. Serviciile marcate Global implicit vor apărea automat aici.')}</div>`
}
function bindServiceDependencyActions(serviceID){
  document.getElementById('serviceDependencyForm')?.addEventListener('submit',async event=>{event.preventDefault();const sourceEnv=document.getElementById('serviceDependencySourceEnvironment').value,targetEnv=document.getElementById('serviceDependencyTargetEnvironment').value,port=document.getElementById('serviceDependencyPort').value;const body={target_service_id:Number(document.getElementById('serviceDependencyTarget').value),dependency_type_id:Number(document.getElementById('serviceDependencyType').value),source_environment_id:sourceEnv?Number(sourceEnv):null,target_environment_id:targetEnv?Number(targetEnv):null,criticality:document.getElementById('serviceDependencyCriticality').value,protocol:document.getElementById('serviceDependencyProtocol').value.trim(),port:port?Number(port):null,notes:document.getElementById('serviceDependencyNotes').value.trim(),active:document.getElementById('serviceDependencyActive').checked};if(!body.target_service_id||!body.dependency_type_id){toast('Alege serviciul destinație și tipul relației.',true);return}try{await api(`/api/v1/services/${serviceID}/dependencies`,{method:'POST',body:JSON.stringify(body)});toast('Dependența a fost salvată.');internalServiceDetail(serviceID,'dependencies')}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.toggle-service-dependency').forEach(button=>button.addEventListener('click',async()=>{const active=button.dataset.active!=='1';try{await api(`/api/v1/services/${serviceID}/dependencies/${button.dataset.id}`,{method:'PATCH',body:JSON.stringify({active})});toast(active?'Dependența a fost activată.':'Dependența a fost dezactivată.');internalServiceDetail(serviceID,'dependencies')}catch(err){toast(err.message,true)}}));
  document.querySelectorAll('.delete-service-dependency').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi definitiv această dependență?'))return;try{await api(`/api/v1/services/${serviceID}/dependencies/${button.dataset.id}`,{method:'DELETE'});toast('Dependența a fost ștearsă.');internalServiceDetail(serviceID,'dependencies')}catch(err){toast(err.message,true)}}))
}

function serviceDependentsPanel(service){
  const rows=(service.dependents||[]).map(dep=>`<tr class="${dep.active===false?'dependency-inactive':''}"><td><a href="#services/${dep.source_service_id}"><strong>${e(dep.source_service_name)}</strong></a></td><td>${nomenclatureIcon(dep.dependency_type_icon||'integration','tiny')} ${e(dep.dependency_type)}</td><td>${dependencyEnvironmentText(dep)}</td><td>${dependencyCriticalityBadge(dep.criticality)}</td><td>${dependencyEndpointText(dep)}</td><td>${dep.active===false?badge('disabled'):badge('active')}</td><td>${e(dep.notes||'—')}</td></tr>`).join('');
  const directRows=(service.direct_vm_dependents||[]).map(dep=>`<tr><td><a href="#vms/${dep.vm_id}"><strong>${e(dep.vm_name)}</strong></a></td><td>${e(dep.dependency_type)}</td><td>${e(dep.notes||'—')}</td></tr>`).join('');
  const global=service.implicit_global?`<div class="notice info"><strong>Serviciu global implicit.</strong> Este considerat dependență pentru toate celelalte servicii active (${service.dependent_service_count||0}).</div>`:'';
  const serviceTable=rows?`<div class="table-wrap"><table class="compact-table dependency-table"><thead><tr><th>Serviciu sursă</th><th>Tip</th><th>Medii</th><th>Criticitate</th><th>Protocol / port</th><th>Stare</th><th>Detalii</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Niciun alt serviciu nu declară încă o dependență către acest serviciu.');
  const vmTable=directRows?`<div class="common-direct-impact"><h3>VM-uri dependente direct</h3><div class="table-wrap"><table class="compact-table"><thead><tr><th>VM</th><th>Tip dependență</th><th>Detalii</th></tr></thead><tbody>${directRows}</tbody></table></div></div>`:'';
  return `<div class="dependency-direction-section incoming"><div class="dependency-section-heading"><div><strong>Este utilizat de</strong><span>Relații care au ca destinație ${e(service.name)}</span></div><span class="muted">${(service.dependents||[]).filter(x=>x.active!==false).length} active</span></div>${global}${serviceTable}${vmTable}</div>`;
}

function networkMapKindLabel(kind){return ({docker:'Docker',database:'DB',web:'Web',port:'Port',service:'Serviciu',external:'Extern','host-firewall':'Firewall host','host-firewall-rule':'Regulă firewall host'})[kind]||kind||'Element'}
function networkMapEvidence(kind){const labels={DECLARAT:'DECLARAT',OBSERVAT:'OBSERVAT',PERMIS:'PERMIS'};return `<span class="network-evidence ${String(kind||'').toLowerCase()}">${labels[kind]||e(kind||'—')}</span>`}
function networkMapRuleLabel(rule){const direction=rule.direction==='source'?'IEȘIRE':rule.direction==='destination'?'INTRARE':'VIP/DNAT';const endpoints=rule.direction==='source'?`${(rule.srcaddr||[]).join(', ')||'—'} → ${(rule.dstaddr||[]).join(', ')||'—'}`:rule.direction==='destination'?`${(rule.srcaddr||[]).join(', ')||'—'} → ${(rule.dstaddr||[]).join(', ')||'—'}`:`${rule.extip||rule.vip_name||'VIP'} → ${rule.vm_ip||'VM'}`;return `<article class="network-policy-card ${rule.direction||''}"><header>${networkMapEvidence('PERMIS')}<strong>#${e(rule.policy_id)} ${e(rule.policy_name||'')}</strong><span>${e(direction)}</span></header><div>${e(endpoints)}</div><small>${e((rule.services||[]).join(', ')||'service —')} · ${e(rule.action||'—')}${rule.nat?' · NAT':''}</small><small class="muted">${e(rule.match_reason||rule.match_object||'')}</small>${(rule.risks||[]).length?`<div class="network-policy-risks">${rule.risks.map(x=>badge(x)).join(' ')}</div>`:''}</article>`}
function networkMapComponentCard(item){const endpoint=item.port?`${item.protocol||'tcp'}/${item.port}`:'';return `<div class="network-component-card"><span>${networkMapKindLabel(item.kind)}</span><strong>${e(item.name||'—')}</strong><small>${e([endpoint,item.detail].filter(Boolean).join(' · ')||'')}</small></div>`}
function networkMapVMCard(vm,components){const own=components.filter(c=>Number(c.vm_id)===Number(vm.id));const visible=own.slice(0,18);return `<article class="network-vm-card"><header><a href="#vms/${vm.id}/network-map"><strong>${e(vm.name)}</strong></a><span>${badge(vm.power_state||'unknown')}</span></header><div class="mono">${e(vm.ip||vm.hostname||'IP —')}</div>${(vm.services||[]).length?`<small>${e(vm.services.join(', '))}</small>`:''}<div class="network-vm-components">${visible.map(networkMapComponentCard).join('')}${own.length>visible.length?`<span class="muted">+${own.length-visible.length} elemente</span>`:''}</div></article>`}
function networkMapFlowLines(items,{empty='—',limit=4}={}){
  const values=networkDiagramUniqueStrings(items||[]);
  if(!values.length)return `<span class="network-flow-empty">${e(empty)}</span>`;
  const rows=list=>`<div class="network-flow-values">${list.map(value=>`<span>${e(value)}</span>`).join('')}</div>`;
  return `${rows(values.slice(0,limit))}${values.length>limit?`<details class="network-flow-more"><summary>+${values.length-limit} · Extinde</summary>${rows(values.slice(limit))}</details>`:''}`;
}
function networkMapFlowCard(flow){
  const srcVMs=flow.source_vms||[],dstVMs=flow.destination_vms||[],srcObj=flow.from||[],dstObj=flow.to||[],services=flow.services||[];
  const source=networkMapFlowLines(srcVMs.length?srcVMs:srcObj),destination=networkMapFlowLines(dstVMs.length?dstVMs:dstObj);
  return `<article class="network-flow-card"><div class="network-flow-side source"><span class="network-flow-caption">Sursă</span><strong>${source}</strong>${srcVMs.length?`<div class="network-flow-secondary"><span>Obiecte Forti</span>${networkMapFlowLines(srcObj)}</div>`:''}</div><div class="network-flow-policy"><strong>#${e(flow.policy_id)} ${e(flow.policy_name||'')}</strong><span>${e(flow.source_name||'FortiGate')} · ${e(flow.vdom||'root')}</span><div class="network-flow-services"><span>Servicii / porturi</span>${networkMapFlowLines(services,{empty:'service —'})}</div><small>${e(flow.action||'—')}${flow.nat?' · NAT':''}${flow.vip?' · VIP':''}</small></div><div class="network-flow-arrow" aria-hidden="true">→</div><div class="network-flow-side destination"><span class="network-flow-caption">Destinație</span><strong>${destination}</strong>${dstVMs.length?`<div class="network-flow-secondary"><span>Obiecte Forti</span>${networkMapFlowLines(dstObj)}</div>`:''}</div></article>`;
}
function networkMapFlowPanel(flows){if(!(flows||[]).length)return empty('Nu există fluxuri FortiGate corelate pentru acest context.');return `<div class="network-flow-list">${flows.map(networkMapFlowCard).join('')}</div>`}
function networkDiagramShort(value,max=30){const text=String(value??'').trim().replace(/\s+/g,' ');if(text.length<=max)return text;return `${text.slice(0,Math.max(1,max-1))}…`}
function networkDiagramLines(value,max=30,count=2){const text=String(value??'').trim().replace(/\s+/g,' ');if(!text)return [];const words=text.split(' '),out=[];let current='';for(const word of words){const next=current?`${current} ${word}`:word;if(next.length<=max){current=next;continue}if(current)out.push(current);current=word.length>max?`${word.slice(0,max-1)}…`:word;if(out.length>=count-1)break}if(out.length<count&&current)out.push(current);if(out.join(' ').length<text.length&&out.length)out[out.length-1]=networkDiagramShort(out[out.length-1],Math.max(8,max-1));return out.slice(0,count)}
function networkDiagramTspans(lines,x,y,lineHeight=15,cls=''){return (lines||[]).map((line,index)=>`<tspan x="${x}" y="${y+index*lineHeight}"${cls?` class="${cls}"`:''}>${e(line)}</tspan>`).join('')}
function networkDiagramPath(x1,y1,x2,y2,cls=''){const mid=Math.round((x1+x2)/2);return `<path class="network-diagram-edge ${cls}" d="M ${x1} ${y1} C ${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}"/>`}
function networkDiagramNode({x,y,w=210,h=64,title='',subtitle='',kind='peer',href='',meta=''}){const titleLines=networkDiagramLines(title,29,2),subLines=networkDiagramLines(subtitle,31,2),body=`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="12" class="network-diagram-node ${kind}"/><text x="${x+12}" y="${y+22}" class="network-diagram-node-title">${networkDiagramTspans(titleLines,x+12,y+22,15)}</text>${subLines.length?`<text x="${x+12}" y="${y+h-17-(subLines.length-1)*13}" class="network-diagram-node-sub">${networkDiagramTspans(subLines,x+12,y+h-17-(subLines.length-1)*13,13)}</text>`:''}${meta?`<text x="${x+w-10}" y="${y+16}" text-anchor="end" class="network-diagram-node-meta">${e(meta)}</text>`:''}`;return href?`<a href="${e(href)}"><title>${e([title,subtitle].filter(Boolean).join(' · '))}</title>${body}</a>`:`<g><title>${e([title,subtitle].filter(Boolean).join(' · '))}</title>${body}</g>`}
function networkDiagramVMInfo(vm,components,hostFW){const own=(components||[]).filter(item=>Number(item.vm_id)===Number(vm.id)),counts={web:0,database:0,docker:0,port:0};own.forEach(item=>{if(Object.prototype.hasOwnProperty.call(counts,item.kind))counts[item.kind]++});const fw=(hostFW||[]).filter(item=>Number(item.vm_id)===Number(vm.id)).length,parts=[];if(counts.web)parts.push(`Web ${counts.web}`);if(counts.database)parts.push(`DB ${counts.database}`);if(counts.docker)parts.push(`Docker ${counts.docker}`);if(counts.port)parts.push(`Porturi ${counts.port}`);if(fw)parts.push(`FW host ${fw}`);return parts.join(' · ')||'Fără componente observate'}
function networkDiagramUniqueStrings(values){const seen=new Set(),out=[];for(const raw of (values||[])){const value=String(raw||'').trim();if(!value)continue;const key=value.toLocaleLowerCase('ro-RO');if(seen.has(key))continue;seen.add(key);out.push(value)}return out}
function networkDiagramMatchedVMRefs(flow,side,scopeNames){const rawRefs=(side==='source'?flow.source_vm_refs:flow.destination_vm_refs)||[],fallback=(side==='source'?flow.source_vms:flow.destination_vms)||[],byName=new Map();for(const raw of rawRefs){const name=String(raw?.name||'').trim();if(!name||scopeNames.has(name.toLocaleLowerCase('ro-RO')))continue;const key=name.toLocaleLowerCase('ro-RO');if(!byName.has(key))byName.set(key,{name,ips:[]});const ref=byName.get(key);ref.ips=networkDiagramUniqueStrings([...(ref.ips||[]),...(raw?.ips||[])])}for(const raw of fallback){const name=String(raw||'').trim();if(!name||scopeNames.has(name.toLocaleLowerCase('ro-RO')))continue;const key=name.toLocaleLowerCase('ro-RO');if(!byName.has(key))byName.set(key,{name,ips:[]})}return [...byName.values()]}
function networkDiagramMatchedVMNames(flow,side,scopeNames){return networkDiagramMatchedVMRefs(flow,side,scopeNames).map(ref=>ref.name)}
function networkDiagramPeer(flow,side,scopeNames){const outside=networkDiagramMatchedVMNames(flow,side,scopeNames),objects=networkDiagramUniqueStrings((side==='source'?flow.from:flow.to)||[]);return outside.length?outside.join(', '):(objects.join(', ')||'—')}
function networkDiagramFlowKey(data,flow,side){return `${data?.scope||'network'}:${data?.scope_id||0}:${flow?.source_id||0}:${flow?.vdom||''}:${flow?.policy_id||0}:${side}`}
function networkDiagramWrapValue(value,maxChars){
  const source=String(value||'—'),width=Math.max(20,maxChars),result=[];
  let remaining=source;
  while(remaining.length>width){let split=remaining.lastIndexOf(' ',width);if(split<Math.floor(width*.55))split=width;result.push(remaining.slice(0,split).trim());remaining=remaining.slice(split).trim()}
  result.push(remaining||'—');return result;
}
function networkDiagramAddressInfo(data,flow,side,scopeNames,exportFull=false){
  const refs=scopeNames?networkDiagramMatchedVMRefs(flow,side,scopeNames):[],names=refs.map(ref=>ref.name),nameKeys=new Set(names.map(n=>n.toLocaleLowerCase('ro-RO')));
  const ips=networkDiagramUniqueStrings(refs.flatMap(ref=>ref.ips||[])),ipKeys=new Set(ips.flatMap(ip=>[ip.toLocaleLowerCase('ro-RO'),`${ip}/32`.toLocaleLowerCase('ro-RO')]));
  const objects=networkDiagramUniqueStrings((side==='source'?flow?.from:flow?.to)||[]).filter(value=>{const k=value.toLocaleLowerCase('ro-RO');return !nameKeys.has(k)&&!ipKeys.has(k)});
  const matched=refs.map(ref=>`${ref.name}${ref.ips.length?`(${ref.ips.join(', ')})`:''}`);
  const key=networkDiagramFlowKey(data,flow,side),selection=state.networkDiagramExpanded?.[key],page=selection&&typeof selection==='object'?selection:null;
  const expanded=!exportFull&&!!page,start=expanded?Math.max(0,Math.min(page.start||0,Math.max(0,objects.length-1))):0;
  const count=exportFull?objects.length:(expanded?16:4),visibleObjects=objects.slice(start,start+count);
  const rows=[...matched.map(text=>({text,kind:'vm'})),...(objects.length?[{text:'Obiecte FortiGate:',kind:'label'},...visibleObjects.map(text=>({text,kind:'object'}))]:[])];
  if(!rows.length)rows.push({text:'—',kind:'object'});
  const remaining=Math.max(0,objects.length-start-visibleObjects.length),controls=!exportFull&&objects.length>4;
  const maxChars=35;
  const rendered=rows.flatMap(row=>(exportFull?networkDiagramWrapValue(row.text,maxChars):[networkDiagramShort(row.text,maxChars)]).map(text=>({...row,text})));
  const height=Math.max(46,18+rendered.length*16+(controls?22:0)+10);
  return {all:[...matched,...objects],objects,key,rendered,remaining,expanded,controls,height,start,count};
}
function networkDiagramAddressNode({data,flow,side,scopeNames,x,y,w=220,exportFull=false}){
  const info=networkDiagramAddressInfo(data,flow,side,scopeNames,exportFull),lineY=y+21;
  const hover=info.all.join(' · ').slice(0,1500)||'—';
  let svg=`<g><title>${e(hover)}</title><rect x="${x}" y="${y}" width="${w}" height="${info.height}" rx="11" class="network-diagram-node peer"/>`;
  info.rendered.forEach((row,i)=>{const cls=row.kind==='label'?'network-diagram-address-caption':'network-diagram-address-list';svg+=`<text x="${x+12}" y="${lineY+i*16}" class="${cls}">${e(row.text)}</text>`});
  if(info.controls){
    const ty=y+info.height-11;
    const control=(action,bx,label,aria=label)=>`<g class="network-diagram-address-toggle" data-network-address-toggle="${e(info.key)}" data-network-address-action="${action}" role="button" tabindex="0" aria-label="${e(aria)}"><rect x="${bx}" y="${ty-11}" width="${Math.max(30,label.length*5.3+11)}" height="16" rx="6" class="network-diagram-toggle-hit"/><text x="${bx+5}" y="${ty}" class="network-diagram-toggle-text">${e(label)}</text></g>`;
    if(!info.expanded)svg+=control('more',x+9,`+${info.remaining} · Extinde`);
    else{
      svg+=control('collapse',x+9,'Restrânge');
      if(info.start>0)svg+=control('prev',x+87,'←','Obiectele anterioare');
      if(info.remaining)svg+=control('more',x+(info.start>0?126:97),`+${info.remaining} →`,'Următoarele obiecte');
    }
  }
  svg+='</g>';return {svg,height:info.height};
}
function networkDiagramIsDNSVM(vm,components){const services=(vm.services||[]).join(' ').toLowerCase();if(/(^|[^a-z0-9])dns([^a-z0-9]|$)|domain\s+name/.test(services))return true;let tcp53=false,udp53=false;for(const item of (components||[])){if(Number(item.vm_id)!==Number(vm.id)||item.kind!=='port'||Number(item.port||0)!==53)continue;const protocol=String(item.protocol||'').toLowerCase(),text=`${item.name||''} ${item.detail||''}`.toLowerCase();if(/(^|[^a-z0-9])dns([^a-z0-9]|$)|\bnamed\b|\bbind\b/.test(text))return true;if(protocol.startsWith('tcp'))tcp53=true;if(protocol.startsWith('udp'))udp53=true}return tcp53&&udp53}
function networkDiagramVMPorts(vm,components){const map=new Map(),dnsVM=networkDiagramIsDNSVM(vm,components);for(const item of (components||[])){if(Number(item.vm_id)!==Number(vm.id)||item.kind!=='port'||Number(item.port||0)<=0)continue;let protocol=String(item.protocol||'tcp').toLowerCase(),port=Number(item.port);if(protocol.startsWith('udp'))continue;if(dnsVM&&port===53)continue;if(protocol==='tcp6')protocol='tcp';const key=`${protocol}/${port}`;if(!map.has(key))map.set(key,{protocol,port,names:new Set(),details:new Set()});const row=map.get(key);if(item.name)row.names.add(String(item.name));if(item.detail)row.details.add(String(item.detail))}return [...map.values()].sort((a,b)=>a.port-b.port||a.protocol.localeCompare(b.protocol)).map(item=>{let name=[...item.names][0]||[...item.details][0]||'';if(/^(?:port\s+ascultat|listening\s+port|port\s+deschis)(?:\s*\(?tcp\)?)?$/i.test(name.trim()))name='';return {...item,name,search:[...item.names,...item.details].join(' ').toLowerCase()}})}
function networkDiagramIsUDPOnlyService(raw){const value=String(raw||'').toLowerCase();const hasUDP=/(^|[\s/_-])udp([\s/_-]|$)/.test(value),hasTCP=/(^|[\s/_-])tcp([\s/_-]|$)/.test(value);return hasUDP&&!hasTCP}
function networkDiagramServiceDisplay(raw){const value=String(raw||'').trim();if(!value||networkDiagramIsUDPOnlyService(value))return '';const lower=value.toLowerCase(),known={http:80,https:443,ssh:22,dns:53,smtp:25,smtps:465,submission:587,imap:143,imaps:993,pop3:110,pop3s:995,ldap:389,ldaps:636,rdp:3389,mysql:3306,mariadb:3306,postgres:5432,postgresql:5432,mssql:1433,oracle:1521,redis:6379,mongo:27017,mongodb:27017,elasticsearch:9200,kibana:5601};if(Object.prototype.hasOwnProperty.call(known,lower))return `${value} · TCP/${known[lower]}`;return value}
function networkDiagramPolicyServices(flow){return networkDiagramUniqueStrings((flow?.services||[]).map(networkDiagramServiceDisplay).filter(Boolean))}
function networkDiagramPolicyInfo(flow){
  const services=networkDiagramPolicyServices(flow),lineCount=Math.max(1,services.length);
  return {services,height:Math.max(91,75+lineCount*14)};
}
function networkDiagramPolicyContext(flow,prefix=''){return [prefix,flow?.vdom||'root',flow?.nat?'NAT':'FĂRĂ NAT',flow?.vip?'VIP':''].filter(Boolean).join(' · ')}
function networkDiagramPolicyNode({flow,x,y,w=168}){
  const info=networkDiagramPolicyInfo(flow),number=String(flow.policy_id??'—'),list=info.services.length?info.services:['—'];
  const tooltip=[`Policy #${number}`,flow.policy_name,networkDiagramPolicyContext(flow),...list].filter(Boolean).join(' · ');
  const labelY=y+22,serviceY=y+67;
  const svg=`<g><title>${e(tooltip)}</title><rect x="${x}" y="${y}" width="${w}" height="${info.height}" rx="11" class="network-diagram-node policy"/><text x="${x+12}" y="${labelY}" class="network-diagram-node-title">#${e(networkDiagramShort(number,20))}</text><line x1="${x+10}" y1="${y+34}" x2="${x+w-10}" y2="${y+34}" class="network-diagram-policy-divider"/><text x="${x+12}" y="${y+49}" class="network-diagram-policy-port-head">SERVICII / PORTURI</text><text x="${x+12}" y="${serviceY}" class="network-diagram-policy-service">${networkDiagramTspans(list.map(v=>networkDiagramShort(v,Math.max(20,Math.floor((w-24)/5.2)))),x+12,serviceY,14)}</text></g>`;
  return {svg,height:info.height};
}
function networkDiagramServicePortCandidates(flow){const out=new Set(),known={http:[80],https:[443],ssh:[22],dns:[53],smtp:[25],smtps:[465],submission:[587],imap:[143],imaps:[993],pop3:[110],pop3s:[995],ldap:[389],ldaps:[636],rdp:[3389],mysql:[3306],mariadb:[3306],postgres:[5432],postgresql:[5432],mssql:[1433],oracle:[1521],redis:[6379],mongo:[27017],mongodb:[27017],elasticsearch:[9200],kibana:[5601],graylog:[9000,12201]};for(const raw of (flow?.services||[])){const value=String(raw||'').toLowerCase();if(networkDiagramIsUDPOnlyService(value))continue;for(const match of value.matchAll(/(?:^|\D)(\d{1,5})(?=\D|$)/g)){const port=Number(match[1]);if(port>0&&port<=65535)out.add(port)}for(const [name,ports] of Object.entries(known))if(value.includes(name))ports.forEach(port=>out.add(port))}return [...out]}
function networkDiagramPortAnchor(pos,flow,edge='left'){if(!pos)return null;const candidates=networkDiagramServicePortCandidates(flow);for(const port of candidates){const point=pos.portPoints?.get(port);if(point)return {x:edge==='right'?pos.x+pos.w:pos.x,y:point.y,port}}const terms=(flow?.services||[]).filter(v=>!networkDiagramIsUDPOnlyService(v)).map(v=>String(v||'').toLowerCase()).filter(v=>v&&v!=='all');for(const entry of (pos.ports||[])){if(terms.some(term=>entry.search&&((entry.search.includes(term))||term.includes(entry.search))))return {x:edge==='right'?pos.x+pos.w:pos.x,y:entry.y,port:entry.port}}return {x:edge==='right'?pos.x+pos.w:pos.x,y:pos.cy,port:0}}
function networkDiagramVMNode(vm,components,hostFW,x,y,w=274){const ports=networkDiagramVMPorts(vm,components),serviceText=(vm.services||[]).length?networkDiagramShort((vm.services||[]).join(', '),44):'',headerH=58,portsStart=ports.length?79:0,portLineH=21,h=Math.max(98,ports.length?portsStart+ports.length*portLineH+18+(serviceText?17:0):98),portPoints=new Map();let svg=`<a href="#vms/${vm.id}/network-map"><title>${e([vm.name,vm.ip||vm.hostname,networkDiagramVMInfo(vm,components,hostFW)].filter(Boolean).join(' · '))}</title><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="13" class="network-diagram-node vm"/><text x="${x+12}" y="${y+22}" class="network-diagram-node-title">${e(networkDiagramShort(vm.name,37))}</text><text x="${x+12}" y="${y+41}" class="network-diagram-node-sub mono">${e(networkDiagramShort(vm.ip||vm.hostname||'IP —',37))}</text><circle cx="${x+w-14}" cy="${y+14}" r="5" class="network-diagram-power ${String(vm.power_state||'').toLowerCase()==='poweredon'||String(vm.power_state||'').toLowerCase()==='on'?'on':'off'}"/>`;if(ports.length){svg+=`<line x1="${x+10}" y1="${y+55}" x2="${x+w-10}" y2="${y+55}" class="network-diagram-vm-divider"/><text x="${x+12}" y="${y+69}" class="network-diagram-vm-port-head">PORTURI OBSERVATE · TCP</text>`;ports.forEach((entry,index)=>{const py=y+portsStart+index*portLineH;entry.y=py-4;portPoints.set(entry.port,{y:entry.y});svg+=`<g class="network-diagram-port-target" data-network-port="${e(`${vm.id}:${entry.port}`)}" tabindex="0" role="button" aria-label="Evidențiază conexiunile pentru portul ${e(entry.port)} TCP"><rect x="${x+8}" y="${py-12}" width="${w-16}" height="19" rx="4" class="network-diagram-port-hit"/><text x="${x+12}" y="${py}" class="network-diagram-vm-port"><tspan class="mono">${e(`${entry.port}/${entry.protocol}`)}</tspan>${entry.name?`<tspan>  ${e(networkDiagramShort(entry.name,30))}</tspan>`:''}</text></g>`});if(serviceText)svg+=`<text x="${x+12}" y="${y+h-10}" class="network-diagram-vm-service">${e(serviceText)}</text>`}else{svg+=`<text x="${x+12}" y="${y+63}" class="network-diagram-vm-components">${e(networkDiagramShort(networkDiagramVMInfo(vm,components,hostFW),35))}</text>${serviceText?`<text x="${x+12}" y="${y+82}" class="network-diagram-vm-service">${e(serviceText)}</text>`:''}`}svg+='</a>';return {svg,h,w,ports,portPoints}}

function networkMapVisioDiagram(data,{exportFull=false}={}){
  const allVMs=Array.isArray(data?.vms)?data.vms:[],vms=(exportFull?allVMs:allVMs.slice(0,12)),components=data?.components||[],hostFW=data?.host_firewall||[],declared=data?.declared||[],flows=(data?.flows||[]),scopeNames=new Set(allVMs.map(vm=>String(vm.name||'').toLocaleLowerCase('ro-RO')));
  const inbound=[],outbound=[],internal=[];for(const flow of flows){const src=(flow.source_vms||[]).some(name=>scopeNames.has(String(name).toLocaleLowerCase('ro-RO'))),dst=(flow.destination_vms||[]).some(name=>scopeNames.has(String(name).toLocaleLowerCase('ro-RO')));if(src&&dst)internal.push(flow);else if(dst)inbound.push(flow);else if(src)outbound.push(flow)}
  const declaredIn=(exportFull?declared.filter(item=>item.direction==='inbound'):declared.filter(item=>item.direction==='inbound').slice(0,6)),declaredOut=(exportFull?declared.filter(item=>item.direction==='outbound'):declared.filter(item=>item.direction==='outbound').slice(0,6)),membership=(exportFull?declared.filter(item=>!item.direction):declared.filter(item=>!item.direction).slice(0,5));
  const vmCols=vms.length>1?2:1,groupW=vmCols===1?380:610,groupX=430,vmW=274,vmGapX=12,vmGapY=12,groupTop=112,groupPadTop=56,vmRows=[];
  for(let row=0;row<Math.max(1,Math.ceil(Math.max(1,vms.length)/vmCols));row++){const items=[];for(let col=0;col<vmCols;col++){const index=row*vmCols+col;if(index>=vms.length)continue;const vm=vms[index],preview=networkDiagramVMNode(vm,components,hostFW,0,0,vmW);items.push({vm,col,h:preview.h})}vmRows.push({items,h:Math.max(98,...items.map(item=>item.h))})}
  let vmAreaH=0;vmRows.forEach((row,index)=>{vmAreaH+=row.h+(index<vmRows.length-1?vmGapY:0)});const groupH=groupPadTop+vmAreaH+32+(membership.length?32:0);
  const leftPeerX=12,leftPeerW=220,leftPolicyX=244,policyW=168,rightPolicyX=groupX+groupW+18,rightPeerX=rightPolicyX+policyW+14,rightPeerW=220,width=rightPeerX+rightPeerW+12,rowGap=14;
  const leftRows=[...declaredIn.map(item=>({type:'declared',item,height:60})),...inbound.map(flow=>({type:'flow',flow,height:Math.max(networkDiagramAddressInfo(data,flow,'source',scopeNames,exportFull).height,networkDiagramPolicyInfo(flow).height)}))],rightRows=[...declaredOut.map(item=>({type:'declared',item,height:60})),...outbound.map(flow=>({type:'flow',flow,height:Math.max(networkDiagramAddressInfo(data,flow,'destination',scopeNames,exportFull).height,networkDiagramPolicyInfo(flow).height)}))];
  const layoutRows=rows=>{let y=110;return rows.map(row=>{const placed={...row,y};y+=row.height+rowGap;return placed})};const leftLayout=layoutRows(leftRows),rightLayout=layoutRows(rightRows),leftBottom=leftLayout.length?leftLayout[leftLayout.length-1].y+leftLayout[leftLayout.length-1].height:104,rightBottom=rightLayout.length?rightLayout[rightLayout.length-1].y+rightLayout[rightLayout.length-1].height:104,sideBottom=Math.max(leftBottom,rightBottom),internalTop=Math.max(groupTop+groupH+18,sideBottom+18);
  const internalRows=[];let internalY=internalTop;for(const flow of internal){const info=networkDiagramPolicyInfo(flow);internalRows.push({flow,y:internalY,height:info.height});internalY+=info.height+20}const height=Math.max(350,(internalRows.length?internalY:internalTop)+28);
  const flowKeys=new Map(flows.map((flow,index)=>[flow,`flow-${index}`]));
  const vmPositions=new Map();let svg=`<svg class="network-visio-svg${exportFull?' network-visio-export':''}" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" role="img" aria-label="Diagramă rețea ${e(data?.name||'')}"><defs><marker id="networkArrow" markerWidth="2.7" markerHeight="2.7" refX="2.5" refY="1.35" orient="auto"><path d="M0,0 L2.7,1.35 L0,2.7 z" class="network-diagram-arrowhead"/></marker><marker id="networkArrowDeclared" markerWidth="2.7" markerHeight="2.7" refX="2.5" refY="1.35" orient="auto"><path d="M0,0 L2.7,1.35 L0,2.7 z" class="network-diagram-arrowhead declared"/></marker><marker id="networkArrowSelected" markerWidth="2.7" markerHeight="2.7" refX="2.5" refY="1.35" orient="auto"><path d="M0,0 L2.7,1.35 L0,2.7 z" class="network-diagram-arrowhead selected"/></marker></defs>`;
  if(exportFull)svg+=`<rect x="0" y="0" width="${width}" height="${height}" fill="#ffffff"/>`;
  svg+=`<rect x="${groupX}" y="${groupTop}" width="${groupW}" height="${groupH}" rx="18" class="network-diagram-scope"/><text x="${groupX+20}" y="${groupTop+26}" class="network-diagram-scope-title">${e(data?.scope==='service'?'SERVICIU':'VM')} · ${e(networkDiagramShort(data?.name||'—',45))}</text><text x="${groupX+20}" y="${groupTop+46}" class="network-diagram-scope-sub">OBSERVAT · ${vms.length}${allVMs.length>vms.length?` / ${allVMs.length}`:''} VM</text>`;
  if(!vms.length){svg+=networkDiagramNode({x:groupX+34,y:groupTop+86,w:groupW-68,h:68,title:'Fără VM-uri în context',subtitle:'Nu există noduri pentru diagramă.',kind:'vm'})}else{let rowY=groupTop+groupPadTop;vmRows.forEach(row=>{row.items.forEach(item=>{const x=vmCols===1?groupX+(groupW-vmW)/2:groupX+15+item.col*(vmW+vmGapX),y=rowY,node=networkDiagramVMNode(item.vm,components,hostFW,x,y,vmW),ports=node.ports.map(port=>({...port,y:port.y}));vmPositions.set(String(item.vm.name||'').toLocaleLowerCase('ro-RO'),{vmId:item.vm.id,x,y,w:vmW,h:node.h,cx:x+vmW/2,cy:y+node.h/2,ports,portPoints:node.portPoints});svg+=node.svg});rowY+=row.h+vmGapY})}
  if(membership.length){const text=membership.map(item=>item.name).join(' · ');svg+=`<text x="${groupX+20}" y="${groupTop+groupH-22}" class="network-diagram-membership">DECLARAT · ${e(networkDiagramShort(text,72))}</text>`}
  const scopeCenter={x:groupX+groupW/2,y:groupTop+groupH/2,w:0,h:0,cx:groupX+groupW/2,cy:groupTop+groupH/2,ports:[],portPoints:new Map()},vmPoint=name=>vmPositions.get(String(name||'').toLocaleLowerCase('ro-RO'))||scopeCenter;
  svg+=`<text x="${leftPeerX+12}" y="${groupTop-16}" class="network-diagram-column-label">SURSĂ</text><text x="${rightPeerX+12}" y="${groupTop-16}" class="network-diagram-column-label">DESTINAȚIE</text>`;
  for(const row of leftLayout){
    const y=row.y;
    if(row.type==='declared'){svg+=networkDiagramNode({x:leftPeerX,y,w:leftPeerW,h:60,title:row.item.name,subtitle:row.item.detail||networkMapKindLabel(row.item.kind),kind:'declared',meta:'DECLARAT'});svg+=networkDiagramPath(leftPeerX+leftPeerW,y+30,groupX,scopeCenter.y,'declared');continue}
    const flow=row.flow,key=flowKeys.get(flow),addressInfo=networkDiagramAddressInfo(data,flow,'source',scopeNames,exportFull),policyInfo=networkDiagramPolicyInfo(flow),addressY=y+(row.height-addressInfo.height)/2,policyY=y+(row.height-policyInfo.height)/2;
    const address=networkDiagramAddressNode({data,flow,side:'source',scopeNames,x:leftPeerX,y:addressY,w:leftPeerW,exportFull}),policy=networkDiagramPolicyNode({flow,x:leftPolicyX,y:policyY,w:policyW}),target=(flow.destination_vms||[]).find(name=>scopeNames.has(String(name).toLocaleLowerCase('ro-RO'))),targetPos=vmPoint(target),targetAnchor=networkDiagramPortAnchor(targetPos,flow,'left'),policyCY=policyY+policy.height/2;
    const portKey=targetAnchor.port&&targetPos.vmId?`${targetPos.vmId}:${targetAnchor.port}`:'';
    svg+=`<g data-network-flow="${key}" tabindex="0" role="button" aria-label="Evidențiază fluxul FortiGate ${e(flow.policy_id||'')}">${address.svg}${policy.svg}</g>`;
    svg+=`<g data-network-flow="${key}" class="network-diagram-flow-edge" tabindex="0" role="button">${networkDiagramPath(leftPeerX+leftPeerW,addressY+address.height/2,leftPolicyX,policyCY,'permitted')}</g>`;
    svg+=`<g data-network-flow="${key}" class="network-diagram-flow-edge"${portKey?` data-network-connected-port="${e(portKey)}"`:''} tabindex="0" role="button">${networkDiagramPath(leftPolicyX+policyW,policyCY,targetAnchor.x,targetAnchor.y,'permitted')}</g>`;
  }
  for(const row of rightLayout){
    const y=row.y;
    if(row.type==='declared'){svg+=networkDiagramNode({x:rightPeerX,y,w:rightPeerW,h:60,title:row.item.name,subtitle:row.item.detail||networkMapKindLabel(row.item.kind),kind:'declared',meta:'DECLARAT'});svg+=networkDiagramPath(groupX+groupW,scopeCenter.y,rightPeerX,y+30,'declared');continue}
    const flow=row.flow,key=flowKeys.get(flow),addressInfo=networkDiagramAddressInfo(data,flow,'destination',scopeNames,exportFull),policyInfo=networkDiagramPolicyInfo(flow),addressY=y+(row.height-addressInfo.height)/2,policyY=y+(row.height-policyInfo.height)/2;
    const address=networkDiagramAddressNode({data,flow,side:'destination',scopeNames,x:rightPeerX,y:addressY,w:rightPeerW,exportFull}),policy=networkDiagramPolicyNode({flow,x:rightPolicyX,y:policyY,w:policyW}),source=(flow.source_vms||[]).find(name=>scopeNames.has(String(name).toLocaleLowerCase('ro-RO'))),sourcePos=vmPoint(source),sourceAnchor={x:sourcePos.x+(sourcePos===scopeCenter?0:sourcePos.w),y:sourcePos.cy},policyCY=policyY+policy.height/2;
    svg+=`<g data-network-flow="${key}" tabindex="0" role="button" aria-label="Evidențiază fluxul FortiGate ${e(flow.policy_id||'')}">${policy.svg}${address.svg}</g>`;
    svg+=`<g data-network-flow="${key}" class="network-diagram-flow-edge" tabindex="0" role="button">${networkDiagramPath(sourceAnchor.x,sourceAnchor.y,rightPolicyX,policyCY,'permitted')}</g>`;
    svg+=`<g data-network-flow="${key}" class="network-diagram-flow-edge" tabindex="0" role="button">${networkDiagramPath(rightPolicyX+policyW,policyCY,rightPeerX,addressY+address.height/2,'permitted')}</g>`;
  }
  internalRows.forEach(row=>{
    const flow=row.flow,key=flowKeys.get(flow),y=row.y,srcName=(flow.source_vms||[]).find(name=>scopeNames.has(String(name).toLocaleLowerCase('ro-RO'))),dstName=(flow.destination_vms||[]).find(name=>scopeNames.has(String(name).toLocaleLowerCase('ro-RO'))),src=vmPoint(srcName),dst=vmPoint(dstName),srcAnchor={x:src.x+(src===scopeCenter?0:src.w),y:src.cy},dstAnchor=networkDiagramPortAnchor(dst,flow,'right'),policyX=groupX+groupW+20,policy=networkDiagramPolicyNode({flow,x:policyX,y,w:policyW}),policyCY=y+policy.height/2;
    const portKey=dstAnchor.port&&dst.vmId?`${dst.vmId}:${dstAnchor.port}`:'';
    svg+=`<g data-network-flow="${key}" tabindex="0" role="button">${policy.svg}</g>`;
    svg+=`<g data-network-flow="${key}" class="network-diagram-flow-edge" tabindex="0" role="button">${networkDiagramPath(srcAnchor.x,srcAnchor.y,policyX,policyCY,'permitted')}</g>`;
    svg+=`<g data-network-flow="${key}" class="network-diagram-flow-edge"${portKey?` data-network-connected-port="${e(portKey)}"`:''} tabindex="0" role="button">${networkDiagramPath(policyX+policyW,policyCY,dstAnchor.x,dstAnchor.y,'permitted')}</g>`;
  });
  if(allVMs.length>vms.length)svg+=`<text x="${groupX+groupW-18}" y="${groupTop+46}" text-anchor="end" class="network-diagram-truncated">+${allVMs.length-vms.length} VM neafișate</text>`;
  svg+='</svg>';return `<div class="network-visio-stage"><div class="network-visio-toolbar"><div><strong>Diagramă generată automat</strong><span>Obiectele sursă și destinație sunt afișate pe rânduri, cu Extinde / Restrânge pentru liste lungi. Sub numărul policy-ului apar serviciile și porturile permise. Click pe port sau linie evidențiază conexiunile corespunzătoare. UDP este omis; pe serverele DNS portul TCP/53 este ascuns.</span></div><div class="network-visio-legend"><span class="observed">VM / OBSERVAT</span><span class="permitted">Policy Forti / PERMIS</span><span class="declared">Dependență / DECLARAT</span></div></div><div class="network-visio-canvas">${svg}</div></div>`
}
function bindNetworkDiagramConnections(root){
  root.querySelectorAll('.network-visio-svg').forEach(svg=>{
    if(svg.dataset.networkInteractionBound==='1')return;
    svg.dataset.networkInteractionBound='1';
    const clear=()=>{svg.classList.remove('has-network-selection');svg.querySelectorAll('.is-network-selected').forEach(el=>el.classList.remove('is-network-selected'))};
    const select=(flows,ports)=>{
      clear();if(!flows.size&&!ports.size)return;
      svg.classList.add('has-network-selection');
      svg.querySelectorAll('[data-network-flow]').forEach(el=>{if(flows.has(el.dataset.networkFlow))el.classList.add('is-network-selected')});
      svg.querySelectorAll('[data-network-port]').forEach(el=>{if(ports.has(el.dataset.networkPort))el.classList.add('is-network-selected')});
    };
    const activate=target=>{
      const port=target.closest('[data-network-port]'),flow=target.closest('[data-network-flow]');
      if(!port&&!flow){clear();return false}
      const flows=new Set(),ports=new Set();
      if(port){const key=port.dataset.networkPort;ports.add(key);svg.querySelectorAll('[data-network-connected-port]').forEach(el=>{if(el.dataset.networkConnectedPort===key)flows.add(el.dataset.networkFlow)})}
      else if(flow){const key=flow.dataset.networkFlow;flows.add(key);svg.querySelectorAll('[data-network-connected-port]').forEach(el=>{if(el.dataset.networkFlow===key)ports.add(el.dataset.networkConnectedPort)})}
      const existingFlows=new Set([...svg.querySelectorAll('[data-network-flow].is-network-selected')].map(el=>el.dataset.networkFlow)),existingPorts=new Set([...svg.querySelectorAll('[data-network-port].is-network-selected')].map(el=>el.dataset.networkPort));
      const same=svg.classList.contains('has-network-selection')&&existingFlows.size===flows.size&&existingPorts.size===ports.size&&[...flows].every(key=>existingFlows.has(key))&&[...ports].every(key=>existingPorts.has(key));
      if(same)clear();else select(flows,ports);
      return true;
    };
    svg.addEventListener('click',event=>{if(activate(event.target)){event.preventDefault();event.stopPropagation()}});
    svg.addEventListener('keydown',event=>{if(event.key==='Escape'){clear();return}if(event.key!=='Enter'&&event.key!==' ')return;if(event.target.closest('[data-network-port],[data-network-flow]')){event.preventDefault();event.stopPropagation();activate(event.target)}});
  });
}
function bindNetworkDiagramToggleActions(root,data){
  root.querySelectorAll('[data-network-address-toggle]').forEach(button=>button.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();const key=button.dataset.networkAddressToggle;if(!key)return;state.networkDiagramExpanded=state.networkDiagramExpanded||{};const action=button.dataset.networkAddressAction||'more',current=state.networkDiagramExpanded[key],start=current&&typeof current==='object'?Number(current.start)||0:0;state.networkDiagramExpanded[key]=action==='collapse'?null:{start:action==='more'?(current?start+16:0):Math.max(0,start-12)};const stage=button.closest('.network-visio-stage');if(!stage)return;stage.outerHTML=networkMapVisioDiagram(data);bindNetworkDiagramToggleActions(root,data)}));
  root.querySelectorAll('[data-network-address-toggle]').forEach(button=>button.addEventListener('keydown',event=>{if(event.key!=='Enter'&&event.key!==' ')return;event.preventDefault();button.dispatchEvent(new Event('click'))}));
  bindNetworkDiagramConnections(root);
}
function bindNetworkDiagramActions(root=document,data=null){
  bindNetworkDiagramToggleActions(root,data);
  root.querySelectorAll('.network-diagram-export').forEach(button=>button.addEventListener('click',()=>{
    if(!data){toast('Datele diagramei nu sunt disponibile.',true);return}
    const holder=document.createElement('div');holder.innerHTML=networkMapVisioDiagram(data,{exportFull:true});
    const complete=holder.querySelector('.network-visio-svg');if(!complete){toast('Diagrama SVG nu este disponibilă.',true);return}
    const clone=complete.cloneNode(true);clone.setAttribute('xmlns','http://www.w3.org/2000/svg');
    // Standalone printable SVG: white boxes, no browser/theme-dependent dark background.
    const rules=[...document.styleSheets].map(sheet=>{try{return [...sheet.cssRules].filter(rule=>String(rule.selectorText||'').includes('network-diagram')||String(rule.selectorText||'').includes('network-visio')).map(rule=>rule.cssText).join('\n')}catch(_){return ''}}).join('\n');
    const style=document.createElementNS('http://www.w3.org/2000/svg','style');
    style.textContent=`svg{--panel:#ffffff;--panel2:#f8fafc;--accent:#2563eb;--border:#a8b5c5;--text:#172334;--muted:#526377;--ok:#16835a;font-family:Arial,sans-serif}\n${rules}\n.network-visio-export .network-diagram-node,.network-visio-export .network-diagram-node.vm,.network-visio-export .network-diagram-node.policy,.network-visio-export .network-diagram-node.peer,.network-visio-export .network-diagram-node.declared,.network-visio-export .network-diagram-scope{fill:#ffffff;stroke:#8595a7}\n.network-visio-export .network-diagram-node-title,.network-visio-export .network-diagram-node-sub,.network-visio-export .network-diagram-address-list,.network-visio-export .network-diagram-address-caption,.network-visio-export .network-diagram-vm-port,.network-visio-export .network-diagram-policy-service,.network-visio-export .network-diagram-column-label{fill:#172334}\n.network-visio-export .network-diagram-arrowhead{fill:#357452}\n.network-visio-export .network-diagram-edge{stroke:#357452}`;
    clone.insertBefore(style,clone.firstChild);
    const blob=new Blob([new XMLSerializer().serializeToString(clone)],{type:'image/svg+xml;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=`${String(button.dataset.name||'vm-doc-network').replace(/[^a-z0-9._-]+/gi,'-')}.svg`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),500);
  }));
}
function networkMapPanel(data){if(!data)return empty('Harta de rețea nu este disponibilă.');const summary=data.summary||{},declared=data.declared||[],components=data.components||[],vms=data.vms||[],rules=data.fortigate_rules||[],hostFW=data.host_firewall||[],flows=data.flows||[];const declaredCards=declared.length?declared.slice(0,60).map(item=>`<article class="network-declared-card"><header>${networkMapEvidence('DECLARAT')}<strong>${e(item.name)}</strong></header><div>${e(networkMapKindLabel(item.kind))}${item.direction?` · ${e(item.direction==='outbound'?'ieșire':item.direction==='inbound'?'intrare':item.direction)}`:''}</div><small>${e(item.detail||'')}</small></article>`).join(''):empty('Nu există relații declarate pentru acest context.');const observedCards=vms.length?vms.map(vm=>networkMapVMCard(vm,components)).join(''):empty('Nu există VM-uri în această hartă.');const permitted=[...hostFW.slice(0,80).map(item=>`<article class="network-policy-card host"><header>${networkMapEvidence('PERMIS')}<strong>${e(item.name)}</strong></header><div>${e(item.vm_name||'')}</div><small>${e(item.detail||'')}</small></article>`),...rules.slice(0,80).map(networkMapRuleLabel)].join('')||(empty('Nu există reguli FortiGate sau firewall host corelate.'));const details=`<div class="network-map-grid"><section><h3>1. DECLARAT</h3>${declaredCards}</section><div class="network-map-arrow">→</div><section><h3>2. OBSERVAT</h3>${observedCards}</section><div class="network-map-arrow">→</div><section><h3>3. PERMIS</h3>${permitted}${rules.length>80?`<p class="muted">Sunt afișate primele 80 din ${rules.length} corelări FortiGate.</p>`:''}${hostFW.length>80?`<p class="muted">Firewall host: primele 80 din ${hostFW.length} elemente.</p>`:''}</section></div>`;
  const accordions=`<div class="network-map-accordions"><details class="network-map-details"><summary><span>DECLARAT / OBSERVAT / PERMIS</span><small>${declared.length} relații · ${vms.length} VM · ${rules.length+hostFW.length} reguli</small></summary>${details}</details><details class="network-map-details network-map-flows"><summary><span>Fluxuri FortiGate corelate</span><small>${flows.length} fluxuri · Sursă → Policy/Servicii → Destinație</small></summary>${networkMapFlowPanel(flows)}</details></div>`;return `<div class="cards report-summary network-map-kpis">${securityKPI('VM-uri',summary.vms||0)}${securityKPI('Declarat',summary.declared||0)}${securityKPI('Porturi',summary.ports||0)}${securityKPI('Docker',summary.docker||0)}${securityKPI('DB',summary.databases||0)}${securityKPI('Web',summary.web||0)}${securityKPI('FortiGate',summary.fortigate||0)}${securityKPI('Fluxuri',summary.flows||0)}</div><div class="network-map-legend"><span>${networkMapEvidence('DECLARAT')} documentație / dependențe</span><span>${networkMapEvidence('OBSERVAT')} agent, Docker, DB, Web</span><span>${networkMapEvidence('PERMIS')} firewall host + FortiGate</span><button class="small secondary network-diagram-export" type="button" data-name="${e(`${data.scope||'network'}-${data.name||data.scope_id||'diagram'}`)}">Export SVG</button></div>${networkMapVisioDiagram(data)}${accordions}${(data.warnings||[]).length?`<div class="notice warning">${data.warnings.map(x=>`<div>${e(x)}</div>`).join('')}</div>`:''}<p class="muted network-map-interpretation">Interpretare: DECLARAT + OBSERVAT + PERMIS = flux bine documentat. PERMIS fără OBSERVAT este candidat de verificare; OBSERVAT fără relație declarată indică documentație posibil incompletă. O policy FortiGate necorelată cu VM-DOC nu este declarată automat inutilă.</p>`}

function serviceDiagram(service,categories){
  const assignments=service.vms||[],equipment=service.equipment||[];const dependencyStrip=serviceDependencyStrip(service);const equipmentStrip=equipment.length?`<section class="service-equipment-diagram"><header><strong>Echipamente / dispozitive</strong><span>${equipment.length} asocieri</span></header><div>${equipment.map(item=>`<a href="#equipment/${item.equipment_id}" class="service-equipment-node"><strong>${e(item.equipment_name)}</strong><span>${e([item.device_type,item.role_name,equipmentAssignmentEndpoint(item),item.ip_addresses].filter(Boolean).join(' · '))}</span></a>`).join('')}</div></section>`:'';if(!assignments.length)return dependencyStrip+equipmentStrip+(equipment.length?'':empty('Schema proprie va apărea după ce asociezi cel puțin un VM sau echipament serviciului.'));
  const byVM=new Map();
  for(const item of assignments){
    const key=Number(item.id);if(!byVM.has(key))byVM.set(key,{id:key,name:item.name,hostname:item.guest_hostname,ip:item.primary_ip,power_state:item.power_state,environment:item.environment,assignments:[]});
    byVM.get(key).assignments.push(item);
  }
  const groups=new Map();
  for(const vm of byVM.values()){
    const layers=[...new Map(vm.assignments.filter(a=>a.layer_id).map(a=>[Number(a.layer_id),{id:Number(a.layer_id),name:a.layer_name}])).values()];
    let groupKey,groupName,groupIcon;
    if(layers.length===1){groupKey=`layer-${layers[0].id}`;groupName=layers[0].name||'Layer';groupIcon=nomenclatureItemByID(categories,layers[0].id)?.icon_key||'layers'}
    else if(layers.length>1){groupKey='multi';groupName='Multi-layer';groupIcon='layers'}
    else{groupKey='none';groupName='Fără layer';groupIcon='layers'}
    if(!groups.has(groupKey))groups.set(groupKey,{name:groupName,icon:groupIcon,vms:[]});groups.get(groupKey).vms.push(vm);
  }
  const lanes=[...groups.values()].sort((a,b)=>a.name==='Multi-layer'?1:b.name==='Multi-layer'?-1:a.name.localeCompare(b.name,'ro'));
  const laneHTML=lanes.map(lane=>`<section class="service-diagram-lane"><header>${nomenclatureIcon(lane.icon)}<div><strong>${e(lane.name)}</strong><span>${lane.vms.length} VM</span></div></header><div class="service-diagram-nodes">${lane.vms.map(vm=>serviceDiagramVM(vm,categories)).join('')}</div></section>`).join('');
  return `${dependencyStrip}${equipmentStrip}<div class="service-diagram-toolbar"><div><strong>Schemă generată din asocierile VM și echipamente</strong><span>${byVM.size} VM unice · ${assignments.length} asocieri VM${equipment.length?` · ${equipment.length} echipamente`:''}</span></div><div class="service-diagram-legend">${nomenclatureIcon('server','small')} VM unic ${nomenclatureIcon('role','small')} rol ${nomenclatureIcon('database','small')} layer/rol specializat</div></div><div class="service-diagram">${laneHTML}</div>`;
}
function serviceDiagramVM(vm,categories){
  const associations=vm.assignments.map(a=>{
    const layer=nomenclatureItemByID(categories,a.layer_id);const role=nomenclatureItemByID(categories,a.technical_role_id);const solution=nomenclatureItemByID(categories,a.solution_type_id);
    const icon=role?.icon_key||layer?.icon_key||'role';
    return `<div class="service-diagram-association"><div class="service-diagram-role">${nomenclatureIcon(icon,'small')}<div><strong>${e(a.technical_role||'Rol nespecificat')}</strong><span>${e(a.layer_name||'Fără layer')}</span></div></div><div class="service-diagram-tags"><span>${nomenclatureIcon(solution?.icon_key||'package','tiny')}${e(a.solution_type||'—')}</span><span>${e(a.architectural_domain||'—')} / ${e(a.itil_category||'—')}</span>${a.is_primary?'<span class="primary-tag">principal</span>':''}</div></div>`;
  }).join('');
  return `<article class="service-diagram-vm ${environmentKind(vm.environment)}"><div class="service-diagram-vm-head">${nomenclatureIcon('server')}<div><a href="#vms/${vm.id}"><strong>${e(vm.name)}</strong></a><span>${e(vm.hostname||vm.ip||'—')}</span></div><div class="service-diagram-state">${environmentBadge(vm.environment)}${badge(vm.power_state||'unknown')}</div></div><div class="service-diagram-vm-meta"><span class="mono">${e(vm.ip||'IP —')}</span><span>${vm.assignments.length} ${vm.assignments.length===1?'asociere':'asocieri'}</span></div><div class="service-diagram-associations">${associations}</div></article>`;
}
function serviceVMRows(values){
  const grouped=new Map();for(const item of values||[]){const id=Number(item.id);if(!grouped.has(id))grouped.set(id,{...item,assignments:[]});grouped.get(id).assignments.push(item)}
  return [...grouped.values()].map(vm=>{const uniq=(items,key)=>[...new Set(items.map(key).filter(Boolean))];const classifications=uniq(vm.assignments,a=>[a.architectural_domain,a.itil_category].filter(Boolean).join(' / '));const roles=uniq(vm.assignments,a=>[a.layer_name,a.technical_role].filter(Boolean).join(' / '));const solutions=uniq(vm.assignments,a=>a.solution_type);const usages=uniq(vm.assignments,a=>serviceUsageLabels[a.usage_type]||a.usage_type);return `<tr><td><a href="#vms/${vm.id}"><strong>${e(vm.name)}</strong></a><div class="muted mono">${e(vm.guest_hostname||'—')}</div></td><td>${environmentBadge(vm.environment)}</td><td class="mono">${e(vm.primary_ip||'—')}</td><td>${classifications.map(e).join('<br>')||'—'}</td><td>${roles.map(e).join('<br>')||'—'}</td><td>${solutions.map(e).join('<br>')||'—'}</td><td>${usages.map(e).join('<br>')||'—'}</td><td>${vm.latest_document_id?`<a class="button-link tiny secondary" href="/api/v1/documents/${vm.latest_document_id}/download" title="${e(vm.latest_document_number||'Fișă VM')}">${e(vm.latest_document_number||'Fișă VM')}</a><div class="muted">${vm.latest_document_at?dt(vm.latest_document_at):''}</div>`:'<span class="muted">Fără fișă</span>'}</td><td>${vm.assignments.some(a=>a.is_primary)?badge('principal'):''}</td><td>${badge(vm.power_state||'unknown')}</td></tr>`}).join('');
}
function cropText(value,limit=150){const text=String(value||'').trim().replace(/\s+/g,' ');return text.length>limit?text.slice(0,limit-1).trimEnd()+'…':text}
function serviceMatchesFilters(service,f){const q=f.q.toLocaleLowerCase('ro');if(q&&!`${service.name} ${service.service_code||''} ${service.description||''}`.toLocaleLowerCase('ro').includes(q))return false;if(f.domain&&!(service.classifications||[]).some(x=>x.architectural_domain===f.domain))return false;if(f.category&&!(service.classifications||[]).some(x=>x.itil_category===f.category))return false;if(f.criticality&&service.criticality!==f.criticality)return false;if(f.docStatus&&service.documentation_status!==f.docStatus)return false;if(f.common==='common'&&(!service.is_common||service.implicit_global))return false;if(f.common==='global'&&!service.implicit_global)return false;if(f.common==='normal'&&service.is_common)return false;return true}
function serviceActiveFilterHTML(){const f=state.serviceFilters,items=[];if(f.q)items.push(`Căutare: ${f.q}`);const picks=[['serviceDomainFilter','domain'],['serviceCategoryFilter','category'],['serviceCriticalityFilter','criticality'],['serviceDocFilter','docStatus'],['serviceCommonFilter','common']];for(const [id,key] of picks){if(!f[key])continue;const select=document.getElementById(id),text=select?.options?.[select.selectedIndex]?.textContent?.trim();if(text)items.push(text)}return items.length?`<span class="vm-filter-caption">Filtre active</span>${items.map(v=>`<span class="vm-filter-chip">${e(v)}</span>`).join('')}`:'<span class="muted">Niciun filtru activ</span>'}


async function internalServicesPage(){pageMeta('Servicii','Catalog, filtre și dependențe comune');const [services,categories]=await Promise.all([api('/api/v1/services?include_inactive=true'),api('/api/v1/nomenclatures?include_inactive=true')]);internalServicesCache=services.filter(s=>!s.retired);nomenclatureCache=categories;renderInternalServicesCatalog()}


const equipmentDirectionLabels={unspecified:'Nespecificat',device_to_service:'Echipament → serviciu',service_to_device:'Serviciu → echipament',bidirectional:'Bidirecțional ↔'};
function equipmentDirectionOptions(selected='unspecified'){return Object.entries(equipmentDirectionLabels).map(([value,label])=>`<option value="${value}" ${value===selected?'selected':''}>${e(label)}</option>`).join('')}
function equipmentDeviceTypeOptions(categories,selected){const values=sortNomenclatureValues(categoryItems(categories,'device_type'));return `<option value="">— Nespecificat —</option>${values.map(item=>`<option value="${item.id}" ${Number(selected)===Number(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}`}
function equipmentPersonOptions(people,selected){return `<option value="">— Fără responsabil —</option>${(people||[]).filter(x=>x.active||Number(x.id)===Number(selected)).map(item=>`<option value="${item.id}" ${Number(selected)===Number(item.id)?'selected':''}>${e(item.display_name)}${item.department?` · ${e(item.department)}`:''}</option>`).join('')}`}
function equipmentDeviceForm(device,categories,people){return `<form id="equipmentDeviceForm" class="operational-form equipment-form"><div class="form-section"><h3>Identificare</h3><div class="form-grid"><label>Denumire<input id="equipmentName" required value="${e(device?.name||'')}" placeholder="Urilyzer 100"></label><label>Tip echipament<select id="equipmentType">${equipmentDeviceTypeOptions(categories,device?.device_type_id)}</select></label><label>Producător<input id="equipmentManufacturer" value="${e(device?.manufacturer||'')}"></label><label>Model<input id="equipmentModel" value="${e(device?.model||'')}"></label><label>Serie<input id="equipmentSerial" value="${e(device?.serial_number||'')}"></label><label>Responsabil<select id="equipmentResponsible">${equipmentPersonOptions(people,device?.responsible_person_id)}</select></label></div></div><div class="form-section"><h3>Rețea și locație</h3><div class="form-grid"><label>Hostname<input id="equipmentHostname" value="${e(device?.hostname||'')}"></label><label>IP / IP-uri<input id="equipmentIPs" value="${e(device?.ip_addresses||'')}" placeholder="172.20.10.35"></label><label>MAC<input id="equipmentMAC" value="${e(device?.mac_address||'')}"></label><label>Locație<input id="equipmentLocation" value="${e(device?.location||'')}" placeholder="Laborator urină"></label><label class="span-2">Link documentație<input id="equipmentDocumentationURL" type="url" value="${e(device?.documentation_url||'')}" placeholder="https://..."></label></div></div><div class="form-section"><h3>Detalii</h3><label>Descriere<textarea id="equipmentDescription" rows="3">${e(device?.description||'')}</textarea></label><label>Observații<textarea id="equipmentNotes" rows="3">${e(device?.notes||'')}</textarea></label><div class="checks"><label><input id="equipmentActive" type="checkbox" ${device?.active===false?'':'checked'}> Activ</label></div></div><div class="form-actions"><button type="submit">${device?'Salvează echipamentul':'Adaugă echipamentul'}</button></div></form>`}
function readEquipmentDeviceForm(){const type=document.getElementById('equipmentType')?.value,responsible=document.getElementById('equipmentResponsible')?.value;return {name:document.getElementById('equipmentName').value.trim(),device_type_id:type?Number(type):null,manufacturer:document.getElementById('equipmentManufacturer').value.trim(),model:document.getElementById('equipmentModel').value.trim(),serial_number:document.getElementById('equipmentSerial').value.trim(),hostname:document.getElementById('equipmentHostname').value.trim(),ip_addresses:document.getElementById('equipmentIPs').value.trim(),mac_address:document.getElementById('equipmentMAC').value.trim(),location:document.getElementById('equipmentLocation').value.trim(),responsible_person_id:responsible?Number(responsible):null,description:document.getElementById('equipmentDescription').value.trim(),notes:document.getElementById('equipmentNotes').value.trim(),documentation_url:document.getElementById('equipmentDocumentationURL').value.trim(),active:document.getElementById('equipmentActive').checked}}
function equipmentAssignmentForm(services,assignment=null,{fixedServiceID=0,equipmentOptions=''}={}){const serviceID=fixedServiceID||assignment?.internal_service_id||0;return `<form id="equipmentAssignmentForm" class="equipment-assignment-form">${equipmentOptions?`<label>Echipament<select id="equipmentAssignmentEquipment" required><option value="">— Alege echipamentul —</option>${equipmentOptions}</select></label>`:''}${fixedServiceID?'':`<label>Serviciu / proiect<select id="equipmentAssignmentService" required><option value="">— Alege serviciul —</option>${(services||[]).filter(x=>x.active||Number(x.id)===Number(serviceID)).map(item=>`<option value="${item.id}" ${Number(item.id)===Number(serviceID)?'selected':''}>${e(item.name)}</option>`).join('')}</select></label>`}<label>Rol în serviciu<input id="equipmentAssignmentRole" value="${e(assignment?.role_name||'')}" placeholder="Analizor urină"></label><label>Protocol<input id="equipmentAssignmentProtocol" value="${e(assignment?.protocol||'')}" placeholder="ASTM / TCP"></label><label>Port<input id="equipmentAssignmentPort" type="number" min="1" max="65535" value="${assignment?.port||''}"></label><label>Sens<select id="equipmentAssignmentDirection">${equipmentDirectionOptions(assignment?.direction||'unspecified')}</select></label><label class="span-2">Scop<input id="equipmentAssignmentPurpose" value="${e(assignment?.purpose||'')}" placeholder="Transmitere rezultate către LIS"></label><label class="span-2">Observații<input id="equipmentAssignmentNotes" value="${e(assignment?.notes||'')}"></label><div class="form-actions span-2"><button id="equipmentAssignmentSubmit" type="submit">${assignment?'Salvează asocierea':'Adaugă asocierea'}</button>${assignment?'<button id="equipmentAssignmentCancel" type="button" class="secondary">Renunță</button>':''}</div></form>`}
function readEquipmentAssignmentForm(fixedServiceID=0){const service=fixedServiceID||Number(document.getElementById('equipmentAssignmentService')?.value||0),port=document.getElementById('equipmentAssignmentPort')?.value;return {internal_service_id:service,role_name:document.getElementById('equipmentAssignmentRole')?.value.trim()||'',protocol:document.getElementById('equipmentAssignmentProtocol')?.value.trim()||'',port:port?Number(port):null,direction:document.getElementById('equipmentAssignmentDirection')?.value||'unspecified',purpose:document.getElementById('equipmentAssignmentPurpose')?.value.trim()||'',notes:document.getElementById('equipmentAssignmentNotes')?.value.trim()||'',active:true}}
function equipmentAssignmentEndpoint(item){const parts=[];if(item.protocol)parts.push(item.protocol);if(item.port)parts.push(String(item.port));return parts.join(' / ')||'—'}
function equipmentAssignmentsTable(values,{manage=false,deviceDetail=false}={}){if(!values?.length)return empty('Nu există servicii / proiecte asociate.');return `<div class="table-wrap"><table><thead><tr><th>${deviceDetail?'Serviciu':'Echipament'}</th><th>Rol</th><th>Protocol / port</th><th>Sens</th><th>Scop</th><th>Locație / IP</th>${manage?'<th></th>':''}</tr></thead><tbody>${values.map(item=>`<tr><td>${deviceDetail?`<a href="#services/${item.internal_service_id}/equipment"><strong>${e(item.internal_service_name)}</strong></a>`:`<a href="#equipment/${item.equipment_id}"><strong>${e(item.equipment_name)}</strong></a><div class="muted">${e(item.device_type||'—')}</div>`}</td><td>${e(item.role_name||'—')}</td><td class="mono">${e(equipmentAssignmentEndpoint(item))}</td><td>${e(equipmentDirectionLabels[item.direction]||item.direction||'—')}</td><td>${e(item.purpose||'—')}</td><td>${e(item.location||'—')}<div class="muted mono">${e(item.ip_addresses||'—')}</div></td>${manage?`<td><div class="actions"><button class="small secondary edit-equipment-assignment" data-id="${item.id}" data-equipment-id="${item.equipment_id}">Editează</button><button class="small danger delete-equipment-assignment" data-id="${item.id}" data-equipment-id="${item.equipment_id}">Șterge</button></div></td>`:''}</tr>`).join('')}</tbody></table></div>`}
function equipmentReadOnlyDetails(device){return `<div class="detail-grid">${detail('Denumire',e(device.name))}${detail('Tip',e(device.device_type||'—'))}${detail('Producător',e(device.manufacturer||'—'))}${detail('Model',e(device.model||'—'))}${detail('Serie',e(device.serial_number||'—'),true)}${detail('Hostname',e(device.hostname||'—'),true)}${detail('IP-uri',e(device.ip_addresses||'—'),true)}${detail('MAC',e(device.mac_address||'—'),true)}${detail('Locație',e(device.location||'—'))}${detail('Responsabil',e(device.responsible_person_name||'—'))}${detail('Stare',device.active?badge('active'):badge('disabled'))}</div><div class="service-text-block"><section><h3>Descriere</h3><p>${e(device.description||'—')}</p></section><section><h3>Observații</h3><p>${e(device.notes||'—')}</p></section></div>`}
async function equipmentPage(id=''){
  if(id&&/^\d+$/.test(String(id))){await equipmentDetail(Number(id));return}
  pageMeta('Echipamente','Dispozitive medicale, echipamente de laborator și alte resurse non-VM');
  const [items,categories,people]=await Promise.all([api('/api/v1/equipment?active=all'),api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true')]);nomenclatureCache=categories;
  const f=state.equipmentFilters||{q:'',type:'',status:'active'},types=sortNomenclatureValues(categoryItems(categories,'device_type'));
  const visible=(items||[]).filter(item=>{if(f.status==='active'&&!item.active)return false;if(f.status==='inactive'&&item.active)return false;if(f.type&&Number(item.device_type_id)!==Number(f.type))return false;const q=String(f.q||'').trim().toLocaleLowerCase('ro-RO');if(q&&!`${item.name} ${item.device_type||''} ${item.manufacturer||''} ${item.model||''} ${item.serial_number||''} ${item.hostname||''} ${item.ip_addresses||''} ${item.location||''}`.toLocaleLowerCase('ro-RO').includes(q))return false;return true});
  const filters=`<div class="filter-bar equipment-filters"><label>Caută<input id="equipmentSearch" value="${e(f.q||'')}" placeholder="nume, IP, model, serie..."></label><label>Tip<select id="equipmentTypeFilter"><option value="">Toate tipurile</option>${types.map(x=>`<option value="${x.id}" ${String(f.type)===String(x.id)?'selected':''}>${e(x.name)}</option>`).join('')}</select></label><label>Stare<select id="equipmentStatusFilter"><option value="active" ${f.status==='active'?'selected':''}>Active</option><option value="all" ${f.status==='all'?'selected':''}>Toate</option><option value="inactive" ${f.status==='inactive'?'selected':''}>Inactive</option></select></label><button id="equipmentReset" type="button" class="secondary">Reset</button></div>`;
  const rows=visible.map(item=>`<tr><td><a href="#equipment/${item.id}"><strong>${e(item.name)}</strong></a><div class="muted">${e(item.device_type||'—')}</div></td><td>${e([item.manufacturer,item.model].filter(Boolean).join(' · ')||'—')}<div class="muted mono">${e(item.serial_number||'')}</div></td><td class="mono">${e(item.hostname||'—')}<div class="muted">${e(item.ip_addresses||'—')}</div></td><td>${e(item.location||'—')}</td><td>${e(item.responsible_person_name||'—')}</td><td>${Number(item.service_count||0)}</td><td>${item.active?badge('active'):badge('disabled')}</td></tr>`).join('');
  const add=can('equipment.manage')?panel('Adaugă echipament',equipmentDeviceForm(null,categories,people),'<span class="muted">Doar denumirea este obligatorie; restul poate fi completat progresiv.</span>'):'';
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Echipamente</div><div class="value">${items.length}</div></div><div class="card"><div class="label">Active</div><div class="value">${items.filter(x=>x.active).length}</div></div><div class="card"><div class="label">Asociate serviciilor</div><div class="value">${items.filter(x=>Number(x.service_count||0)>0).length}</div></div><div class="card"><div class="label">Fără serviciu</div><div class="value">${items.filter(x=>x.active&&!Number(x.service_count||0)).length}</div></div></div>${add}${panel('Inventar echipamente',`${filters}${rows?`<div class="table-wrap"><table><thead><tr><th>Echipament</th><th>Producător / model</th><th>Hostname / IP</th><th>Locație</th><th>Responsabil</th><th>Servicii</th><th>Stare</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există echipamente pentru filtrele selectate.')}`)}`;
  document.getElementById('equipmentDeviceForm')?.addEventListener('submit',async event=>{event.preventDefault();try{const saved=await api('/api/v1/equipment',{method:'POST',body:JSON.stringify(readEquipmentDeviceForm())});toast('Echipamentul a fost adăugat.');location.hash=`#equipment/${saved.id}`}catch(err){toast(err.message,true)}});
  let timer=0;document.getElementById('equipmentSearch')?.addEventListener('input',event=>{clearTimeout(timer);f.q=event.target.value;timer=setTimeout(()=>equipmentPage(),180)});document.getElementById('equipmentTypeFilter')?.addEventListener('change',event=>{f.type=event.target.value;equipmentPage()});document.getElementById('equipmentStatusFilter')?.addEventListener('change',event=>{f.status=event.target.value;equipmentPage()});document.getElementById('equipmentReset')?.addEventListener('click',()=>{state.equipmentFilters={q:'',type:'',status:'active'};equipmentPage()});
}
async function equipmentDetail(id){
  const [device,categories,people,services]=await Promise.all([api(`/api/v1/equipment/${id}`),api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true'),api('/api/v1/services?include_inactive=true')]);pageMeta(device.name,'Echipament / dispozitiv non-VM');
  const ident=panel('Identificare și detalii',can('equipment.manage')?equipmentDeviceForm(device,categories,people):equipmentReadOnlyDetails(device),'<a class="button-link small secondary" href="#equipment">← Echipamente</a>');
  const assignmentPanel=panel('Servicii / proiecte asociate',`${can('equipment.manage')?equipmentAssignmentForm(services):''}<div id="equipmentAssignmentsTable">${equipmentAssignmentsTable(device.services,{manage:can('equipment.manage'),deviceDetail:true})}</div>`,'<span class="muted">Același echipament poate participa la mai multe servicii și poate avea mai multe fluxuri/porturi.</span>');
  const danger=can('equipment.manage')?panel('Administrare',`<button id="deleteEquipment" class="danger">Șterge echipamentul</button>`,'<span class="muted">Ștergerea elimină și asocierile la servicii.</span>'):'';
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Tip</div><div class="value compact">${e(device.device_type||'—')}</div></div><div class="card"><div class="label">IP</div><div class="value compact mono">${e(device.ip_addresses||'—')}</div></div><div class="card"><div class="label">Locație</div><div class="value compact">${e(device.location||'—')}</div></div><div class="card"><div class="label">Servicii</div><div class="value">${Number(device.service_count||0)}</div></div></div>${ident}${assignmentPanel}${danger}`;
  document.getElementById('equipmentDeviceForm')?.addEventListener('submit',async event=>{event.preventDefault();try{await api(`/api/v1/equipment/${id}`,{method:'PATCH',body:JSON.stringify(readEquipmentDeviceForm())});toast('Echipamentul a fost actualizat.');equipmentDetail(id)}catch(err){toast(err.message,true)}});
  const bindAssignmentForm=(assignment=null)=>{const holder=document.getElementById('equipmentAssignmentForm')?.parentElement;if(assignment&&holder){document.getElementById('equipmentAssignmentForm').outerHTML=equipmentAssignmentForm(services,assignment);setTimeout(()=>bindAssignmentForm(assignment),0);return}const form=document.getElementById('equipmentAssignmentForm');if(!form)return;form.dataset.assignmentId=assignment?.id||'';form.addEventListener('submit',async event=>{event.preventDefault();const assignmentID=Number(form.dataset.assignmentId||0),body=readEquipmentAssignmentForm();if(!body.internal_service_id){toast('Alege serviciul.',true);return}try{await api(assignmentID?`/api/v1/equipment/${id}/services/${assignmentID}`:`/api/v1/equipment/${id}/services`,{method:assignmentID?'PATCH':'POST',body:JSON.stringify(body)});toast(assignmentID?'Asocierea a fost actualizată.':'Asocierea a fost adăugată.');equipmentDetail(id)}catch(err){toast(err.message,true)}});document.getElementById('equipmentAssignmentCancel')?.addEventListener('click',()=>equipmentDetail(id))};
  bindAssignmentForm();
  document.querySelectorAll('.edit-equipment-assignment').forEach(button=>button.addEventListener('click',()=>{const assignment=(device.services||[]).find(x=>Number(x.id)===Number(button.dataset.id));if(!assignment)return;const form=document.getElementById('equipmentAssignmentForm');if(form){form.outerHTML=equipmentAssignmentForm(services,assignment);const next=document.getElementById('equipmentAssignmentForm');next.dataset.assignmentId=assignment.id;next.addEventListener('submit',async event=>{event.preventDefault();try{await api(`/api/v1/equipment/${id}/services/${assignment.id}`,{method:'PATCH',body:JSON.stringify(readEquipmentAssignmentForm())});toast('Asocierea a fost actualizată.');equipmentDetail(id)}catch(err){toast(err.message,true)}});document.getElementById('equipmentAssignmentCancel')?.addEventListener('click',()=>equipmentDetail(id));next.scrollIntoView({behavior:'smooth',block:'center'})}}));
  document.querySelectorAll('.delete-equipment-assignment').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi asocierea echipamentului la acest serviciu?'))return;try{await api(`/api/v1/equipment/${id}/services/${button.dataset.id}`,{method:'DELETE'});toast('Asocierea a fost ștearsă.');equipmentDetail(id)}catch(err){toast(err.message,true)}}));
  document.getElementById('deleteEquipment')?.addEventListener('click',async()=>{if(!confirm(`Ștergi definitiv echipamentul „${device.name}” și toate asocierile sale?`))return;try{await api(`/api/v1/equipment/${id}`,{method:'DELETE'});toast('Echipamentul a fost șters.');location.hash='#equipment'}catch(err){toast(err.message,true)}});
}
function serviceEquipmentPanel(service,equipment){
  const values=service.equipment||[],options=(equipment||[]).filter(x=>x.active).map(item=>`<option value="${item.id}">${e(item.name)}${item.ip_addresses?` · ${e(item.ip_addresses)}`:''}</option>`).join('');
  const form=can('equipment.manage')?equipmentAssignmentForm([],null,{fixedServiceID:service.id,equipmentOptions:options}):'';
  return `${form}${equipmentAssignmentsTable(values,{manage:can('equipment.manage'),deviceDetail:false})}`;
}
function bindServiceEquipmentActions(service,equipment){
  const bindCreate=()=>{const form=document.getElementById('equipmentAssignmentForm');form?.addEventListener('submit',async event=>{event.preventDefault();const equipmentID=Number(document.getElementById('equipmentAssignmentEquipment')?.value||0);if(!equipmentID){toast('Alege echipamentul.',true);return}try{await api(`/api/v1/equipment/${equipmentID}/services`,{method:'POST',body:JSON.stringify(readEquipmentAssignmentForm(service.id))});toast('Echipamentul a fost asociat serviciului.');internalServiceDetail(service.id,'equipment')}catch(err){toast(err.message,true)}})};
  bindCreate();
  document.querySelectorAll('.edit-equipment-assignment').forEach(button=>button.addEventListener('click',()=>{const assignment=(service.equipment||[]).find(x=>Number(x.id)===Number(button.dataset.id)),equipmentID=Number(button.dataset.equipmentId||0);if(!assignment||!equipmentID)return;const form=document.getElementById('equipmentAssignmentForm');if(!form)return;form.outerHTML=equipmentAssignmentForm([],assignment,{fixedServiceID:service.id});const next=document.getElementById('equipmentAssignmentForm');next.addEventListener('submit',async event=>{event.preventDefault();try{await api(`/api/v1/equipment/${equipmentID}/services/${assignment.id}`,{method:'PATCH',body:JSON.stringify(readEquipmentAssignmentForm(service.id))});toast('Asocierea a fost actualizată.');internalServiceDetail(service.id,'equipment')}catch(err){toast(err.message,true)}});document.getElementById('equipmentAssignmentCancel')?.addEventListener('click',()=>internalServiceDetail(service.id,'equipment'));next.scrollIntoView({behavior:'smooth',block:'center'})}));
  document.querySelectorAll('.delete-equipment-assignment').forEach(button=>button.addEventListener('click',async()=>{const equipmentID=Number(button.dataset.equipmentId||0);if(!equipmentID||!confirm('Ștergi asocierea echipamentului din acest serviciu?'))return;try{await api(`/api/v1/equipment/${equipmentID}/services/${button.dataset.id}`,{method:'DELETE'});toast('Asocierea a fost ștearsă.');internalServiceDetail(service.id,'equipment')}catch(err){toast(err.message,true)}}));
}

const externalTypeLabels={vm:'VM extern',server:'Server extern',endpoint:'Endpoint',network_service:'Serviciu de rețea'};
const externalDirectionLabels={outbound:'Ieșire → extern',inbound:'Intrare ← extern',bidirectional:'Bidirecțional ↔'};
const externalZoneTypeLabels={internet:'Internet',partner:'Partener',institution:'Altă instituție',cloud:'Cloud',external_dmz:'DMZ extern',other:'Altă rețea'};
const externalRiskLabels={unknown:'Necunoscut',low:'Scăzut',medium:'Mediu',high:'Ridicat',critical:'Critic'};
const externalTrustLabels={untrusted:'Untrusted',restricted:'Restricted',trusted:'Trusted'};
function safeExternalColor(value){const v=String(value||'').trim();return /^#[0-9a-fA-F]{6}$/.test(v)?v:'#6B7280'}
function externalNetworkBadge(item){const name=item.network_name||item.name||'Neclasificat',color=safeExternalColor(item.network_color||item.color),risk=item.network_risk_level||item.risk_level||'unknown';return `<span class="external-network-badge" style="--external-color:${color}"><i></i><span>${e(name)}</span><small>${e(externalRiskLabels[risk]||risk)}</small></span>`}
function externalRiskBadge(value){const v=String(value||'unknown');return `<span class="external-risk ${e(v)}">${e(externalRiskLabels[v]||v)}</span>`}
function externalDirectionBadge(value){const direction=String(value||'outbound');return `<span class="external-direction ${e(direction)}">${e(externalDirectionLabels[direction]||direction)}</span>`}
function externalConnectionEndpoint(item){const transport=[item.protocol||'tcp',item.port||''].filter(Boolean).join('/');return `<strong>${e(item.remote_service||'—')}</strong><div class="muted mono">${e(transport||'—')}${item.tls_enabled?' · TLS':''}</div>`}
function externalConnectionTable(values,{showSource=false,manage=false}={}){
  if(!values?.length)return empty('Nu există conexiuni externe definite.');
  const rows=values.map(item=>`<tr><td><a href="#external/${item.external_system_id}"><strong>${e(item.external_system_name)}</strong></a><div class="muted mono">${e(item.external_hostname||item.external_ip_addresses||'—')}</div>${externalNetworkBadge(item)}</td>${showSource?`<td>${item.internal_service_id?`Serviciu: <strong>${e(item.internal_service_name)}</strong>`:''}${item.internal_service_id&&item.vm_id?'<br>':''}${item.vm_id?`VM: <strong>${e(item.vm_name)}</strong>`:''}</td>`:''}<td>${externalDirectionBadge(item.direction)}</td><td>${externalConnectionEndpoint(item)}</td><td>${e(item.authentication||'—')}</td><td>${e(item.purpose||'—')}</td><td>${item.active?badge('active'):badge('disabled')}</td>${manage?`<td><button class="small danger delete-external-connection" data-id="${item.id}">Șterge</button></td>`:''}</tr>`).join('');
  return `<div class="table-wrap external-connections-table"><table><thead><tr><th>Sistem extern / rețea</th>${showSource?'<th>Sursă internă</th>':''}<th>Sens</th><th>Serviciu / port</th><th>Autentificare</th><th>Scop</th><th>Stare</th>${manage?'<th></th>':''}</tr></thead><tbody>${rows}</tbody></table></div>`;
}
function scopedExternalConnectionPanel(scopeType,scopeID,connections,systems){
  const sourceLabel=scopeType==='vm'?'VM':'serviciu intern';
  const form=can('external.manage')&&systems?.length?`<form id="scopedExternalConnectionForm" class="external-connection-form">
    <label>Sistem extern<select id="externalConnectionSystem" required><option value="">— Alege —</option>${systems.filter(x=>x.active).map(x=>`<option value="${x.id}">${e(x.name)} · ${e(x.network_name||'Neclasificat')}</option>`).join('')}</select></label>
    <label>Sens<select id="externalConnectionDirection"><option value="outbound">Ieșire → extern</option><option value="inbound">Intrare ← extern</option><option value="bidirectional">Bidirecțional ↔</option></select></label>
    <label>Serviciu destinație<input id="externalConnectionRemoteService" required placeholder="HTTPS API, SMTP, LDAP…"></label>
    <label>Protocol<input id="externalConnectionProtocol" value="tcp" placeholder="tcp"></label>
    <label>Port<input id="externalConnectionPort" type="number" min="1" max="65535" placeholder="443"></label>
    <label>Autentificare<input id="externalConnectionAuth" placeholder="mTLS, Basic, OAuth2…"></label>
    <label class="span-2">Scop<input id="externalConnectionPurpose" placeholder="De ce este necesară conexiunea"></label>
    <label class="check-inline"><input id="externalConnectionTLS" type="checkbox"> TLS</label>
    <button type="submit">Adaugă conexiune</button>
  </form>`:can('external.manage')?'<p class="muted">Definește mai întâi un sistem extern.</p>':'';
  return `<div class="external-connections-body">${form}${externalConnectionTable(connections,{manage:can('external.manage')})}<p class="muted panel-note">Sensul este privit din perspectiva infrastructurii noastre: „Ieșire” înseamnă că ${sourceLabel} inițiază conexiunea către sistemul extern.</p></div>`;
}
function bindScopedExternalConnectionActions(scopeType,scopeID,refresh){
  document.getElementById('scopedExternalConnectionForm')?.addEventListener('submit',async event=>{event.preventDefault();const portValue=document.getElementById('externalConnectionPort').value;const body={external_system_id:Number(document.getElementById('externalConnectionSystem').value),direction:document.getElementById('externalConnectionDirection').value,remote_service:document.getElementById('externalConnectionRemoteService').value.trim(),protocol:document.getElementById('externalConnectionProtocol').value.trim(),port:portValue?Number(portValue):null,tls_enabled:document.getElementById('externalConnectionTLS').checked,authentication:document.getElementById('externalConnectionAuth').value.trim(),purpose:document.getElementById('externalConnectionPurpose').value.trim()};body[scopeType==='vm'?'vm_id':'internal_service_id']=Number(scopeID);try{await api('/api/v1/external-connections',{method:'POST',body:JSON.stringify(body)});toast('Conexiunea externă a fost adăugată.');refresh()}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.delete-external-connection').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi această conexiune externă?'))return;try{await api(`/api/v1/external-connections/${button.dataset.id}`,{method:'DELETE'});toast('Conexiunea externă a fost ștearsă.');refresh()}catch(err){toast(err.message,true)}}));
}
async function fetchAllVMsForSelect(){let page=1,items=[];for(;;){const result=await api(`/api/v1/vms?page=${page}&page_size=200&retired=false`);items.push(...(result.items||[]));if(page>=Number(result.pages||1))break;page++}return items}
function externalNetworkForm(network){return `<form id="externalNetworkForm" class="external-system-form"><div class="form-grid">
  <label>Denumire<input id="externalNetworkName" required value="${e(network?.name||'')}"></label><label>Cod<input id="externalNetworkCode" value="${e(network?.code||'')}" placeholder="internet, partner_x"></label>
  <label>Culoare<div class="external-color-input"><input id="externalNetworkColor" type="color" value="${safeExternalColor(network?.color||'#6B7280')}"><input id="externalNetworkColorText" class="mono" value="${safeExternalColor(network?.color||'#6B7280')}" maxlength="7"></div></label>
  <label>Tip zonă<select id="externalNetworkZoneType">${Object.entries(externalZoneTypeLabels).map(([v,l])=>`<option value="${v}" ${(network?.zone_type||'other')===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
  <label>Nivel risc<select id="externalNetworkRisk">${Object.entries(externalRiskLabels).map(([v,l])=>`<option value="${v}" ${(network?.risk_level||'unknown')===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
  <label>Trust<select id="externalNetworkTrust">${Object.entries(externalTrustLabels).map(([v,l])=>`<option value="${v}" ${(network?.trust_level||'restricted')===v?'selected':''}>${e(l)}</option>`).join('')}</select></label>
  <label class="span-2">CIDR-uri / intervale IP<textarea id="externalNetworkCIDRs" rows="2" placeholder="203.0.113.0/24, 2001:db8::/32">${e(network?.cidrs||'')}</textarea></label>
  <label class="span-2">Organizație / proprietar<input id="externalNetworkOwner" value="${e(network?.owner_organization||'')}"></label>
  <label class="span-2">Descriere<textarea id="externalNetworkDescription" rows="3">${e(network?.description||'')}</textarea></label>
  <label class="span-2">Observații securitate<textarea id="externalNetworkSecurity" rows="3">${e(network?.security_notes||'')}</textarea></label>
  </div><div class="checks"><label><input id="externalNetworkActive" type="checkbox" ${network?.active===false?'':'checked'}> Activ</label></div><div class="form-actions"><button type="submit">${network?'Salvează rețeaua':'Adaugă rețea'}</button>${network?'<button id="cancelExternalNetworkEdit" type="button" class="secondary">Renunță</button>':''}</div></form>`}
function readExternalNetworkForm(){return {name:document.getElementById('externalNetworkName').value.trim(),code:document.getElementById('externalNetworkCode').value.trim(),color:document.getElementById('externalNetworkColorText').value.trim(),zone_type:document.getElementById('externalNetworkZoneType').value,risk_level:document.getElementById('externalNetworkRisk').value,trust_level:document.getElementById('externalNetworkTrust').value,cidrs:document.getElementById('externalNetworkCIDRs').value.trim(),owner_organization:document.getElementById('externalNetworkOwner').value.trim(),description:document.getElementById('externalNetworkDescription').value.trim(),security_notes:document.getElementById('externalNetworkSecurity').value.trim(),active:document.getElementById('externalNetworkActive').checked}}
function bindExternalNetworkForm(network){const color=document.getElementById('externalNetworkColor'),text=document.getElementById('externalNetworkColorText');color?.addEventListener('input',()=>text.value=color.value.toUpperCase());text?.addEventListener('input',()=>{if(/^#[0-9a-fA-F]{6}$/.test(text.value))color.value=text.value});document.getElementById('externalNetworkForm')?.addEventListener('submit',async event=>{event.preventDefault();try{await api(network?`/api/v1/external-networks/${network.id}`:'/api/v1/external-networks',{method:network?'PATCH':'POST',body:JSON.stringify(readExternalNetworkForm())});toast(network?'Rețeaua externă a fost actualizată.':'Rețeaua externă a fost adăugată.');state.externalNetworkEdit=0;externalSystemsPage('networks')}catch(err){toast(err.message,true)}});document.getElementById('cancelExternalNetworkEdit')?.addEventListener('click',()=>{state.externalNetworkEdit=0;externalSystemsPage('networks')})}
function externalSystemForm(system,networks){return `<form id="externalSystemForm" class="external-system-form">
  <div class="form-grid"><label>Denumire<input id="externalSystemName" required value="${e(system?.name||'')}"></label><label>Tip<select id="externalSystemType"><option value="vm" ${system?.system_type==='vm'?'selected':''}>VM extern</option><option value="server" ${system?.system_type==='server'?'selected':''}>Server extern</option><option value="endpoint" ${system?.system_type==='endpoint'?'selected':''}>Endpoint</option><option value="network_service" ${system?.system_type==='network_service'?'selected':''}>Serviciu de rețea</option></select></label><label>Rețea externă<select id="externalSystemNetwork"><option value="">Neclasificat</option>${networks.filter(n=>n.active||Number(n.id)===Number(system?.network_id)).map(n=>`<option value="${n.id}" ${Number(system?.network_id)===Number(n.id)?'selected':''}>${e(n.name)} · ${e(externalRiskLabels[n.risk_level]||n.risk_level)}</option>`).join('')}</select></label><label>Hostname / FQDN<input id="externalSystemHostname" value="${e(system?.hostname||'')}"></label><label class="span-2">IP-uri<input id="externalSystemIPs" value="${e(system?.ip_addresses||'')}" placeholder="10.10.10.5, 2001:db8::5"></label><label>Organizație / proprietar<input id="externalSystemOwner" value="${e(system?.owner_organization||'')}"></label><label>URL documentație<input id="externalSystemDocumentation" type="url" value="${e(system?.documentation_url||'')}"></label></div>
  <label>Descriere<textarea id="externalSystemDescription" rows="3">${e(system?.description||'')}</textarea></label><div class="checks"><label><input id="externalSystemActive" type="checkbox" ${system?.active===false?'':'checked'}> Activ</label></div><div class="form-actions"><button type="submit">${system?'Salvează modificările':'Adaugă sistemul'}</button></div></form>`}
function readExternalSystemForm(){const network=document.getElementById('externalSystemNetwork').value;return {name:document.getElementById('externalSystemName').value.trim(),system_type:document.getElementById('externalSystemType').value,network_id:network?Number(network):null,hostname:document.getElementById('externalSystemHostname').value.trim(),ip_addresses:document.getElementById('externalSystemIPs').value.trim(),owner_organization:document.getElementById('externalSystemOwner').value.trim(),documentation_url:document.getElementById('externalSystemDocumentation').value.trim(),description:document.getElementById('externalSystemDescription').value.trim(),active:document.getElementById('externalSystemActive').checked}}
function bindExternalSystemForm(system){document.getElementById('externalSystemForm')?.addEventListener('submit',async event=>{event.preventDefault();try{const saved=await api(system?`/api/v1/external-systems/${system.id}`:'/api/v1/external-systems',{method:system?'PATCH':'POST',body:JSON.stringify(readExternalSystemForm())});toast(system?'Sistemul extern a fost actualizat.':'Sistemul extern a fost adăugat.');location.hash=`#external/${saved.id}`;if(system)externalSystemsPage(String(saved.id))}catch(err){toast(err.message,true)}})}
function externalSourceOptions(type,services,vms){if(type==='service')return services.filter(x=>x.active).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('');return vms.filter(x=>!x.retired).map(x=>`<option value="${x.id}">${e(x.name)}${x.guest_hostname?` · ${e(x.guest_hostname)}`:''}</option>`).join('')}
async function externalSystemDetailPage(id){
  const [system,networks,services,vms]=await Promise.all([api(`/api/v1/external-systems/${id}`),api('/api/v1/external-networks?active=all'),api('/api/v1/services?include_inactive=true'),fetchAllVMsForSelect()]);pageMeta(system.name,'Sistem extern, rețea și conexiuni cu infrastructura internă');
  const connectionForm=can('external.manage')?`<form id="externalSystemConnectionForm" class="external-connection-form extended"><label>Sursă<select id="externalSourceType"><option value="service">Serviciu intern</option><option value="vm">VM specific</option></select></label><label id="externalSourceValueLabel">Serviciu intern<select id="externalSourceValue"></select></label><label>Sens<select id="externalSystemConnectionDirection"><option value="outbound">Ieșire → extern</option><option value="inbound">Intrare ← extern</option><option value="bidirectional">Bidirecțional ↔</option></select></label><label>Serviciu destinație<input id="externalSystemConnectionService" required placeholder="HTTPS API, SMTP, LDAP…"></label><label>Protocol<input id="externalSystemConnectionProtocol" value="tcp"></label><label>Port<input id="externalSystemConnectionPort" type="number" min="1" max="65535"></label><label>Autentificare<input id="externalSystemConnectionAuth"></label><label class="span-2">Scop<input id="externalSystemConnectionPurpose"></label><label class="check-inline"><input id="externalSystemConnectionTLS" type="checkbox"> TLS</label><button type="submit">Adaugă conexiune</button></form>`:'';
  content.innerHTML=`<div class="service-detail-toolbar"><a href="#external/systems" class="button-link secondary">← Înapoi la sisteme externe</a>${can('external.manage')?'<button id="deleteExternalSystem" class="danger">Șterge sistemul</button>':''}</div><div class="cards"><div class="card"><div class="label">Tip</div><div class="value compact">${e(externalTypeLabels[system.system_type]||system.system_type)}</div></div><div class="card"><div class="label">Rețea</div><div class="value compact">${externalNetworkBadge(system)}</div></div><div class="card"><div class="label">Conexiuni</div><div class="value">${system.connection_count||0}</div></div><div class="card"><div class="label">Stare</div><div class="value compact">${system.active?badge('active'):badge('disabled')}</div></div></div>${system.network_id?panel('Clasificare rețea',`<div class="detail-grid">${detail('Rețea',externalNetworkBadge(system))}${detail('Tip zonă',e(externalZoneTypeLabels[system.network_zone_type]||system.network_zone_type||'—'))}${detail('Risc',externalRiskBadge(system.network_risk_level))}${detail('Trust',e(externalTrustLabels[system.network_trust_level]||system.network_trust_level||'—'))}</div>`):''}${panel('Identificare',can('external.manage')?externalSystemForm(system,networks):`<div class="detail-grid">${detail('Denumire',e(system.name))}${detail('Hostname',e(system.hostname||'—'),true)}${detail('IP-uri',e(system.ip_addresses||'—'),true)}${detail('Organizație',e(system.owner_organization||'—'))}${detail('Rețea',externalNetworkBadge(system))}${detail('Descriere',e(system.description||'—'))}</div>`)}${panel('Conexiuni',`${connectionForm}${externalConnectionTable(system.connections,{showSource:true,manage:can('external.manage')})}`)}`;
  bindExternalSystemForm(system);const sourceType=document.getElementById('externalSourceType'),sourceValue=document.getElementById('externalSourceValue'),sourceLabel=document.getElementById('externalSourceValueLabel');const refreshSource=()=>{const type=sourceType.value;sourceLabel.firstChild.textContent=type==='service'?'Serviciu intern':'VM specific';sourceValue.innerHTML=externalSourceOptions(type,services,vms)};sourceType?.addEventListener('change',refreshSource);if(sourceType)refreshSource();
  document.getElementById('externalSystemConnectionForm')?.addEventListener('submit',async event=>{event.preventDefault();const type=sourceType.value,idValue=Number(sourceValue.value||0),port=document.getElementById('externalSystemConnectionPort').value;if(!idValue){toast('Alege sursa internă.',true);return}const body={external_system_id:Number(system.id),direction:document.getElementById('externalSystemConnectionDirection').value,remote_service:document.getElementById('externalSystemConnectionService').value.trim(),protocol:document.getElementById('externalSystemConnectionProtocol').value.trim(),port:port?Number(port):null,tls_enabled:document.getElementById('externalSystemConnectionTLS').checked,authentication:document.getElementById('externalSystemConnectionAuth').value.trim(),purpose:document.getElementById('externalSystemConnectionPurpose').value.trim()};body[type==='service'?'internal_service_id':'vm_id']=idValue;try{await api('/api/v1/external-connections',{method:'POST',body:JSON.stringify(body)});toast('Conexiunea a fost adăugată.');externalSystemDetailPage(system.id)}catch(err){toast(err.message,true)}});
  document.querySelectorAll('.delete-external-connection').forEach(button=>button.addEventListener('click',async()=>{if(!confirm('Ștergi conexiunea?'))return;try{await api(`/api/v1/external-connections/${button.dataset.id}`,{method:'DELETE'});externalSystemDetailPage(system.id)}catch(err){toast(err.message,true)}}));document.getElementById('deleteExternalSystem')?.addEventListener('click',async()=>{if(!confirm(`Ștergi sistemul extern ${system.name} și toate conexiunile lui?`))return;try{await api(`/api/v1/external-systems/${system.id}`,{method:'DELETE'});toast('Sistemul extern a fost șters.');location.hash='#external/systems'}catch(err){toast(err.message,true)}})
}
function externalSubnav(section){return `<nav class="subnav external-subnav"><a href="#external/systems" class="${section==='systems'?'active':''}">Sisteme externe</a><a href="#external/networks" class="${section==='networks'?'active':''}">Rețele externe</a></nav>`}

async function externalSystemsPage(id=''){
  if(id&&Number(id)>0){await externalSystemDetailPage(Number(id));return}const section=id==='networks'?'networks':'systems';const [systems,networks]=await Promise.all([api('/api/v1/external-systems?active=all'),api('/api/v1/external-networks?active=all')]);pageMeta(section==='networks'?'Rețele externe':'Sisteme externe','Conectivitate către infrastructuri și servicii din afara rețelelor proprii');content.innerHTML=externalSubnav(section);if(section==='networks')await renderExternalNetworks(networks);else await renderExternalSystems(systems,networks)
}


const serviceDetailGroupsBase=[
  {code:'summary',label:'Rezumat',help:'Stare și structură',sections:[['overview','Rezumat']]},
  {code:'details',label:'Detalii',help:'Date administrate',sections:[['details','General'],['description','Descriere'],['purpose','Scop și domeniu'],['objectives','Obiective'],['vault','Vault']]},
  {code:'architecture',label:'Arhitectură',help:'Medii și roluri',sections:[['environments','Medii'],['classification','Clasificare'],['diagram','Schemă'],['network','Rețea']]},
  {code:'components',label:'Componente',help:'VM, DB, Docker, Web și echipamente',sections:[['vms','VM-uri'],['databases','Baze de date'],['docker','Docker'],['web','Web'],['equipment','Echipamente']]},
  {code:'dependencies',label:'Dependențe',help:'Între servicii și externe',sections:[['dependencies','Între servicii'],['external','Sisteme externe']]},
  {code:'documents',label:'Documentație',help:'Fișe serviciu',sections:[['documents','Fișe și documente']]}
];
function serviceDetailGroups(service){
  const groups=[...serviceDetailGroupsBase];if(can('audit.read'))groups.push({code:'audit',label:'Audit',help:'Istoric și operații',sections:[['audit','Audit']]});return groups;
}
function serviceDetailSections(service){return serviceDetailGroups(service).flatMap(group=>group.sections)}
function serviceDetailGroupForSection(service,section){return serviceDetailGroups(service).find(group=>group.sections.some(([code])=>code===section))||serviceDetailGroups(service)[0]}
function serviceDetailNavigation(serviceID,service,selected){
  const groups=serviceDetailGroups(service),activeGroup=serviceDetailGroupForSection(service,selected);
  const primary=`<nav class="vm-detail-tabs vm-detail-primary-tabs service-detail-primary-tabs" aria-label="Zone serviciu">${groups.map(group=>{const target=group.sections[0][0];return `<a href="#services/${serviceID}/${target}" class="${activeGroup.code===group.code?'active':''}"><strong>${e(group.label)}</strong><small>${e(group.help)}</small></a>`}).join('')}</nav>`;
  const secondary=activeGroup.sections.length>1?`<nav class="vm-detail-subtabs service-detail-subtabs" aria-label="Secțiuni ${e(activeGroup.label)}">${activeGroup.sections.map(([code,label])=>`<a href="#services/${serviceID}/${code}" class="${selected===code?'active':''}">${e(label)}</a>`).join('')}</nav>`:'';
  return `<div class="vm-detail-navigation service-detail-navigation">${primary}${secondary}</div>`;
}
function serviceUpdateBody(service,changes={}){
  const base={name:service.name||'',service_code:service.service_code||'',short_description:service.short_description||'',authentication:service.authentication||'',service_url:service.service_url||'',technologies:service.technologies||'',description:service.description||'',description_richtext:normalizeRichTextDocument(service.description_richtext,service.description||''),purpose:service.purpose||'',purpose_richtext:normalizeRichTextDocument(service.purpose_richtext,service.purpose||''),objectives:service.objectives||'',objectives_richtext:normalizeRichTextDocument(service.objectives_richtext,service.objectives||''),criticality:service.criticality||'normal',documentation_status:service.documentation_status||'draft',documentation_url:service.documentation_url||'',vault_url:service.vault_url||'',active:service.active!==false,retired:!!service.retired,retirement_reason_id:service.retirement_reason_id?Number(service.retirement_reason_id):null,retired_at:service.retired_at?String(service.retired_at).slice(0,10):'',outline_documentation_disabled:!!service.outline_documentation_disabled,is_common:!!service.is_common,implicit_global:!!service.implicit_global,common_dependency_type_id:service.common_dependency_type_id?Number(service.common_dependency_type_id):null};return {...base,...changes}
}
function serviceRetirementReasonOptions(categories,selected){
  const values=sortNomenclatureValues(categoryItems(categories,'service_retirement_reason'));
  return `<option value="">— Motiv nespecificat —</option>${values.map(item=>`<option value="${item.id}" ${Number(selected)===Number(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}`;
}
function serviceLifecycleState(service){return service?.retired?'Retras / scos din uz':(service?.active===false?'Inactiv':'Activ')}
function serviceRetiredDateValue(service){return service?.retired_at?String(service.retired_at).slice(0,10):''}
function serviceGeneralPanel(service,categories){
  if(!can('services.manage'))return panel('Date generale',`<div class="detail-grid">${detail('Denumire',e(service.name))}${detail('Cod intern',e(service.service_code||'—'),true)}${detail('Descriere scurtă',e(service.short_description||'—'))}${detail('Autentificare',e(service.authentication||'—'))}${detail('Link serviciu',service.service_url?`<a href="${e(service.service_url)}" target="_blank" rel="noopener">${e(service.service_url)}</a>`:'—')}${detail('Tehnologii folosite',e(service.technologies||'—'))}${detail('Criticitate',criticalityLabels[service.criticality]||e(service.criticality))}${detail('Status documentație',documentationStatusLabels[service.documentation_status]||e(service.documentation_status))}${detail('Stare serviciu',e(serviceLifecycleState(service)))}${detail('Motiv retragere',e(service.retirement_reason||'—'))}${detail('Data retragerii',serviceRetiredDateValue(service)||'—')}${detail('Outline',service.outline_documentation_disabled?'Nu se documentează':'Permis')}${detail('Tip serviciu',service.is_common?(service.implicit_global?badge('global'):badge('common')):'Serviciu aplicație')}${detail('Tip dependență implicit',e(service.common_dependency_type||'—'))}${detail('Documentație existentă',service.documentation_url?`<a href="${e(service.documentation_url)}" target="_blank" rel="noopener">${e(service.documentation_url)}</a>`:'—')}${detail('Ultima actualizare',dt(service.updated_at))}</div>`);
  const types=categoryItems(categories,'dependency_type');
  return panel('Date generale',`<form id="serviceGeneralForm" class="operational-form service-inline-form"><div class="form-section"><h3>Identificare și stare</h3><div class="form-grid"><label>Denumire<input id="serviceDetailName" required value="${e(service.name||'')}"></label><label>Cod intern<input id="serviceDetailCode" value="${e(service.service_code||'')}" placeholder="ex. bi.metabase"></label><label class="span-2">Descriere scurtă<textarea id="serviceDetailShortDescription" rows="2" maxlength="2000" placeholder="Rezumat scurt pentru identificarea serviciului">${e(service.short_description||'')}</textarea></label><label class="span-2">Autentificare<textarea id="serviceDetailAuthentication" rows="2" maxlength="4000" placeholder="ex. OIDC prin Keycloak, LDAP/AD">${e(service.authentication||'')}</textarea></label><label class="span-2">Link serviciu<input id="serviceDetailServiceURL" type="url" value="${e(service.service_url||'')}" placeholder="https://..."></label><label class="span-2">Tehnologii folosite<textarea id="serviceDetailTechnologies" rows="3" maxlength="10000" placeholder="ex. Java 17, PostgreSQL, Nginx">${e(service.technologies||'')}</textarea></label><label>Criticitate<select id="serviceDetailCriticality">${Object.entries(criticalityLabels).map(([v,l])=>`<option value="${v}" ${service.criticality===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label>Status documentație<select id="serviceDetailDocStatus">${Object.entries(documentationStatusLabels).map(([v,l])=>`<option value="${v}" ${service.documentation_status===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label class="span-2">Link documentație<input id="serviceDetailDocumentationURL" type="url" value="${e(service.documentation_url||'')}" placeholder="https://..."></label></div></div><div class="form-section"><h3>Lifecycle serviciu</h3><div class="form-grid"><label>Motiv retragere<select id="serviceDetailRetirementReason">${serviceRetirementReasonOptions(categories,service.retirement_reason_id)}</select></label><label>Data retragerii<input id="serviceDetailRetiredAt" type="date" value="${e(serviceRetiredDateValue(service))}"></label></div><div class="checks"><label><input id="serviceDetailActive" type="checkbox" ${service.active?'checked':''}> Activ</label><label><input id="serviceDetailRetired" type="checkbox" ${service.retired?'checked':''}> Retras / scos din uz</label><label><input id="serviceDetailOutlineDisabled" type="checkbox" ${service.outline_documentation_disabled?'checked':''}> Nu se documentează în Outline</label></div><p class="muted">Marcarea ca retras dezactivează serviciul și îl exclude automat de la publicarea Outline. Bifa Outline poate fi folosită și pentru servicii active.</p></div><div class="form-section"><h3>Tip serviciu</h3><div class="form-grid common-service-config"><label>Tip dependență implicit pentru serviciul comun<select id="serviceDetailCommonDependencyType"><option value="">— Alege tipul dependenței —</option>${selectOptions(types,service.common_dependency_type_id,'— Alege tipul dependenței —').replace('<option value="">— Alege tipul dependenței —</option>','')}</select><small>Exemple: DNS / Name resolution, Directory / Identity, NTP / Time.</small></label></div><div class="checks"><label><input id="serviceDetailCommon" type="checkbox" ${service.is_common?'checked':''}> Serviciu comun / infrastructură partajată</label><label><input id="serviceDetailImplicitGlobal" type="checkbox" ${service.implicit_global?'checked':''}> Global implicit pentru toate serviciile</label></div></div><div class="form-actions"><button type="submit">Salvează datele generale</button></div></form>`)
}
function syncServiceLifecycle(){
  const retired=document.getElementById('serviceDetailRetired'),active=document.getElementById('serviceDetailActive'),reason=document.getElementById('serviceDetailRetirementReason'),date=document.getElementById('serviceDetailRetiredAt');if(!retired||!active)return;
  if(retired.checked){active.checked=false;active.disabled=true;if(reason)reason.disabled=false;if(date)date.disabled=false}else{active.disabled=false;if(reason){reason.disabled=true;reason.value=''}if(date){date.disabled=true;date.value=''}}
}
function serviceDescriptionPanel(service){const title='Descriere detaliată',editorID='serviceDetailDescriptionRich';if(!can('services.manage'))return panel(title,`<div class="service-text-block service-single-narrative"><section>${richTextView(service.description_richtext,service.description||'')}</section></div>`);return panel(title,`<form id="serviceDescriptionForm" class="operational-form service-inline-form"><div class="form-section">${richTextEditorHTML(editorID,title,'Descriere funcțională și tehnică a serviciului, structurată pe paragrafe și liste.') }<small>Descrierea formatată este folosită în fișa tehnică și operațională a serviciului.</small></div><div class="form-actions"><button type="submit">Salvează descrierea</button></div></form>`)}
function serviceRichDetailPanel(service,kind){const purpose=kind==='purpose',title=purpose?'Scop și domeniu':'Obiective',editorID=purpose?'serviceDetailPurposeRich':'serviceDetailObjectivesRich',placeholder=purpose?'Descrie scopul serviciului, aria funcțională acoperită, utilizatorii/beneficiarii și limitele serviciului.':'Descrie rezultatele urmărite, obiectivele operaționale și criteriile principale de succes.',value=purpose?service.purpose_richtext:service.objectives_richtext,fallback=purpose?service.purpose:service.objectives;if(!can('services.manage'))return panel(title,`<div class="service-text-block service-single-narrative"><section>${richTextView(value,fallback||'')}</section></div>`);return panel(title,`<form id="${purpose?'servicePurposeForm':'serviceObjectivesForm'}" class="operational-form service-inline-form"><div class="form-section">${richTextEditorHTML(editorID,title,placeholder)}</div><div class="form-actions"><button type="submit">Salvează ${purpose?'scopul și domeniul':'obiectivele'}</button></div></form>`)}
function syncServiceGeneralCommon(){const common=document.getElementById('serviceDetailCommon'),global=document.getElementById('serviceDetailImplicitGlobal'),type=document.getElementById('serviceDetailCommonDependencyType');if(!common||!global||!type)return;if(global.checked)common.checked=true;if(!common.checked){global.checked=false;type.value=''}type.disabled=!common.checked;refreshSearchableSelect(type)}
async function saveServiceInline(service,changes,section){try{const saved=await api(`/api/v1/services/${service.id}`,{method:'PATCH',body:JSON.stringify(serviceUpdateBody(service,changes))});toast('Serviciul a fost actualizat.');internalServiceDetail(saved.id,section)}catch(err){toast(err.message,true)}}
function serviceVaultPanel(service){
  const vaultURL=String(service?.vault_url||'').trim();
  const link=vaultURL?`<div class="vault-link-preview"><span class="muted">Link salvat</span><a href="${e(vaultURL)}" target="_blank" rel="noopener noreferrer">${e(vaultURL)}</a></div>`:`<div class="vault-link-preview muted">Nu este configurat niciun link Vault.</div>`;
  if(!can('services.manage'))return panel('Vault',`<div class="vault-app-only">${link}<p class="muted">Link intern VM-DOC. Nu este inclus în fișe, exporturi de documentație sau Outline.</p></div>`);
  return panel('Vault',`<form id="serviceVaultForm" class="operational-form vault-form"><label>Link Vault<input id="serviceVaultURL" type="url" maxlength="2048" value="${e(vaultURL)}" placeholder="https://vault.../ui/vault/secrets/..."></label>${link}<p class="muted">Metadată strict internă VM-DOC. Nu este inclusă în fișe, exporturi de documentație sau publicări Outline.</p><div class="form-actions"><button type="submit">Salvează linkul Vault</button></div></form>`);
}
function bindServiceInlineDetail(service,section){
  if(section==='details'){
    syncServiceGeneralCommon();syncServiceLifecycle();document.getElementById('serviceDetailCommon')?.addEventListener('change',syncServiceGeneralCommon);document.getElementById('serviceDetailImplicitGlobal')?.addEventListener('change',syncServiceGeneralCommon);document.getElementById('serviceDetailRetired')?.addEventListener('change',syncServiceLifecycle);
    document.getElementById('serviceGeneralForm')?.addEventListener('submit',event=>{event.preventDefault();const isCommon=document.getElementById('serviceDetailCommon').checked,implicit=document.getElementById('serviceDetailImplicitGlobal').checked,typeValue=document.getElementById('serviceDetailCommonDependencyType').value,retired=document.getElementById('serviceDetailRetired').checked,retirementReason=document.getElementById('serviceDetailRetirementReason').value;if((isCommon||implicit)&&!typeValue){toast('Alege tipul dependenței pentru serviciul comun.',true);return}saveServiceInline(service,{name:document.getElementById('serviceDetailName').value.trim(),service_code:document.getElementById('serviceDetailCode').value.trim(),short_description:document.getElementById('serviceDetailShortDescription').value.trim(),authentication:document.getElementById('serviceDetailAuthentication').value.trim(),service_url:document.getElementById('serviceDetailServiceURL').value.trim(),technologies:document.getElementById('serviceDetailTechnologies').value.trim(),criticality:document.getElementById('serviceDetailCriticality').value,documentation_status:document.getElementById('serviceDetailDocStatus').value,documentation_url:document.getElementById('serviceDetailDocumentationURL').value.trim(),active:retired?false:document.getElementById('serviceDetailActive').checked,retired,retirement_reason_id:retired&&retirementReason?Number(retirementReason):null,retired_at:retired?document.getElementById('serviceDetailRetiredAt').value:'',outline_documentation_disabled:document.getElementById('serviceDetailOutlineDisabled').checked,is_common:isCommon||implicit,implicit_global:implicit,common_dependency_type_id:typeValue?Number(typeValue):null},'details')});
  }
  if(section==='description'){setRichTextEditor('serviceDetailDescriptionRich',service.description_richtext,service.description||'');bindRichTextToolbars();document.getElementById('serviceDescriptionForm')?.addEventListener('submit',event=>{event.preventDefault();const rich=richTextDocumentFromEditor('serviceDetailDescriptionRich');saveServiceInline(service,{description:richTextPlain(rich),description_richtext:rich},'description')})}
  if(section==='purpose'){setRichTextEditor('serviceDetailPurposeRich',service.purpose_richtext,service.purpose||'');bindRichTextToolbars();document.getElementById('servicePurposeForm')?.addEventListener('submit',event=>{event.preventDefault();const rich=richTextDocumentFromEditor('serviceDetailPurposeRich');saveServiceInline(service,{purpose:richTextPlain(rich),purpose_richtext:rich},'purpose')})}
  if(section==='objectives'){setRichTextEditor('serviceDetailObjectivesRich',service.objectives_richtext,service.objectives||'');bindRichTextToolbars();document.getElementById('serviceObjectivesForm')?.addEventListener('submit',event=>{event.preventDefault();const rich=richTextDocumentFromEditor('serviceDetailObjectivesRich');saveServiceInline(service,{objectives:richTextPlain(rich),objectives_richtext:rich},'objectives')})}
  if(section==='vault'){document.getElementById('serviceVaultForm')?.addEventListener('submit',event=>{event.preventDefault();saveServiceInline(service,{vault_url:document.getElementById('serviceVaultURL').value.trim()},'vault')})}
}

function serviceImpactSummary(impact){
  const parts=[];if(Number(impact?.vm_assignments||0))parts.push(`${impact.vm_assignments} asocieri VM`);if(Number(impact?.docker_assignments||0))parts.push(`${impact.docker_assignments} Docker`);if(Number(impact?.database_instances||0)+Number(impact?.database_catalogs||0))parts.push(`${Number(impact.database_instances||0)+Number(impact.database_catalogs||0)} DB`);if(Number(impact?.web_sites||0))parts.push(`${impact.web_sites} Web/LB`);if(Number(impact?.equipment_assignments||0))parts.push(`${impact.equipment_assignments} echipamente`);if(Number(impact?.outgoing_dependencies||0)+Number(impact?.incoming_dependencies||0)+Number(impact?.vm_dependencies||0))parts.push(`${Number(impact.outgoing_dependencies||0)+Number(impact.incoming_dependencies||0)+Number(impact.vm_dependencies||0)} dependențe`);if(Number(impact?.generated_documents||0))parts.push(`${impact.generated_documents} documente`);if(Number(impact?.attachments||0))parts.push(`${impact.attachments} anexe`);return parts.join(', ')||'fără asocieri dependente';
}
function serviceAdministrationPanel(service,allServices){
  if(!can('services.manage'))return '';
  if(service.implicit_global)return panel('Administrare proiect / serviciu',`<div class="notice warning"><strong>Serviciu global implicit protejat.</strong><p>Dezactivează mai întâi opțiunea Global implicit dacă vrei să îl comasezi sau să îl ștergi.</p></div>`);
  const targets=(allServices||[]).filter(item=>Number(item.id)!==Number(service.id)&&item.active!==false).map(item=>`<option value="${item.id}">${e(item.name)}</option>`).join('');
  return panel('Administrare proiect / serviciu',`<p class="muted">Folosește <strong>Comasează</strong> când ai creat proiecte separate și vrei să le concentrezi într-un proiect mai mare. Asocierile tehnice, VM-urile, dependențele, documentele și anexele sunt mutate în proiectul destinație.</p><div class="service-management-actions"><label>Comasează în<select id="serviceMergeTarget"><option value="">— Alege proiectul destinație —</option>${targets}</select></label><button id="mergeInternalService" type="button" class="secondary" ${targets?'':'disabled'}>Comasează proiectul</button><button id="deleteInternalService" type="button" class="danger">Șterge definitiv</button></div>`,'<span class="muted">Ștergerea este permanentă. Comasarea păstrează proiectul destinație ca sursă principală.</span>');
}

async function internalServiceDetail(id,requestedSection=''){
  const [service,documentTemplates,generatedDocuments,serviceAttachments,diagramNomenclatures,allServices,externalSystems,externalConnections,allEquipment,outlineSettings,outlineServiceState]=await Promise.all([api(`/api/v1/services/${id}`),can('documents.read')?api('/api/v1/document-templates?object_type=service'):Promise.resolve([]),can('documents.read')?api(`/api/v1/services/${id}/documents`):Promise.resolve([]),can('documents.read')?api(`/api/v1/services/${id}/attachments`):Promise.resolve([]),api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/services?include_inactive=true'),can('external.read')?api('/api/v1/external-systems?active=active'):Promise.resolve([]),can('external.read')?api(`/api/v1/external-connections?service_id=${id}`):Promise.resolve([]),can('equipment.read')?api('/api/v1/equipment?active=active'):Promise.resolve([]),can('documents.read')?api('/api/v1/outline/settings').catch(()=>({enabled:false})):Promise.resolve({enabled:false}),can('documents.read')?api(`/api/v1/services/${id}/outline`).catch(()=>({configured:false,prod_eligible:false,prod_vm_count:0})):Promise.resolve({configured:false,prod_eligible:false,prod_vm_count:0})]);nomenclatureCache=diagramNomenclatures;internalServicesCache=allServices;
  const hashParts=(location.hash||'').slice(1).split('/');const hashSection=hashParts[0]==='services'&&Number(hashParts[1])===Number(id)?hashParts[2]:'';
  const sections=serviceDetailSections(service),candidate=requestedSection||hashSection||'overview',selectedSection=sections.some(([code])=>code===candidate)?candidate:'overview';if(candidate!==selectedSection)history.replaceState(null,'',`#services/${id}/${selectedSection}`);
  const serviceNetworkMap=selectedSection==='network'?await api(`/api/v1/services/${id}/network-map`).catch(err=>({scope:'service',scope_id:id,name:service.name,vms:[],components:[],declared:[],fortigate_rules:[],host_firewall:[],summary:{},warnings:[err.message]})):null;
  const sectionLabel=sections.find(([code])=>code===selectedSection)?.[1]||'Rezumat';
  const vmRows=serviceVMRows(service.vms);
  const serviceDocumentPanel=can('documents.read')?`${serviceDocumentsPanel(service,documentTemplates,generatedDocuments,!!outlineSettings?.enabled,outlineServiceState)}${serviceSupplementalDocumentsPanel(id,serviceAttachments)}`:empty('Nu ai acces la documentele serviciului.');
  pageMeta(service.name,`${sectionLabel} · serviciu intern`);
  const serviceOutlinePublishState=!outlineSettings?.enabled?'Nu · integrarea Outline este dezactivată global':service.retired?'Nu · serviciu retras':!service.active?'Nu · serviciu inactiv':service.outline_documentation_disabled?'Nu · exclus explicit':!outlineServiceState?.prod_eligible?'Nu · fără PROD':!String(service.documentation_url||'').trim()?'Nu · lipsește Link documentație':'Da · numai PROD';

  const summarySection=`${panel('Serviciu pe scurt',`<div class="detail-grid">${detail('Serviciu intern',e(service.name))}${detail('Cod intern',e(service.service_code||'—'),true)}${detail('Stare',service.retired?badge('retired'):(service.active?badge('active'):badge('disabled')))}${detail('Tip',service.is_common?(service.implicit_global?badge('global'):badge('common')):'Serviciu aplicație')}${detail('Documentație',documentationStatusLabels[service.documentation_status]||e(service.documentation_status))}${detail('Se publică în Outline',e(serviceOutlinePublishState))}${detail('Ultima actualizare',dt(service.updated_at))}</div><div class="service-summary-description"><strong>Descriere scurtă</strong><p>${e(service.short_description||'—')}</p></div>`)}${panel('Încadrare pe medii',serviceEnvironmentPanel(service.vms))}${panel('Încadrare arhitecturală',`<div class="service-summary-two-column"><section><h3>Domenii / categorii</h3>${serviceClassificationSummary(service.classifications)}</section><section><h3>Tipuri de soluție</h3>${serviceSolutionSummary(service.solution_types)}</section></div>`)}${serviceDependencyStrip(service)}${serviceAdministrationPanel(service,allServices)}`;
  const detailsSection=serviceGeneralPanel(service,diagramNomenclatures);
  const descriptionSection=serviceDescriptionPanel(service);
  const purposeSection=serviceRichDetailPanel(service,'purpose');
  const objectivesSection=serviceRichDetailPanel(service,'objectives');
  const vaultSection=serviceVaultPanel(service);
  const environmentsSection=panel('Încadrare pe medii',serviceEnvironmentPanel(service.vms));
  const classificationSection=`${panel('Domenii și categorii observate automat',`<p class="muted service-observed-note">Încadrarea este calculată exclusiv din fișele VM asociate serviciului.</p>${observedServiceClassifications(service.classifications)}`)}${panel('Tipuri de soluție observate automat',`<p class="muted service-observed-note">Open source, dezvoltată intern sau comercială, conform alegerii făcute pe fiecare asociere VM.</p>${observedServiceSolutionTypes(service.solution_types)}`)}${panel('Layer-e și roluri tehnice observate automat',`<p class="muted service-observed-note">Această vedere este calculată din asocierile VM-urilor. Nu se configurează manual la nivelul serviciului.</p>${observedServiceRoles(service.role_mappings)}`)}`;
  const diagramSection=panel('Schemă serviciu',serviceDiagram(service,diagramNomenclatures));
  const networkSection=panel('Hartă rețea serviciu · DECLARAT / OBSERVAT / PERMIS',networkMapPanel(serviceNetworkMap),'<a class="button-link small secondary" href="#security/firewall-analysis">Analiză reguli FortiGate</a>','network-map-panel');
  const vmsSection=panel('VM-uri asociate',vmRows?`<div class="table-wrap"><table><thead><tr><th>VM</th><th>Mediu</th><th>IP</th><th>Domeniu / Categorie</th><th>Layer / Rol</th><th>Tip soluție</th><th>Utilizare</th><th>Fișă VM</th><th></th><th>Power state</th></tr></thead><tbody>${vmRows}</tbody></table></div>`:empty('Niciun VM nu este asociat încă acestui serviciu. Asocierea se face din fișa VM.'));
  const databasesSection=panel('Baze de date asociate',serviceDatabasePanel(service.database_resources,service.id),'<span class="muted">Bazele pot fi găzduite pe VM-uri partajate și sunt asociate independent de VM</span>');
  const dockerSection=panel('Containere Docker asociate',serviceDockerPanel(service.docker_containers,service.id),'<span class="muted">Containerele pot fi găzduite pe VM-uri partajate care nu aparțin exclusiv acestui serviciu</span>');
  const webSection=panel('Site-uri web asociate',serviceWebPanel(service.web_sites,service.id),'<span class="muted">Site-urile Nginx/Apache și frontend-urile HAProxy pot fi găzduite pe VM-uri partajate și sunt asociate independent de VM</span>');
  const equipmentSection=can('equipment.read')?panel('Echipamente / dispozitive asociate',serviceEquipmentPanel(service,allEquipment),'<a class="button-link small secondary" href="#equipment">Inventar echipamente</a>'):empty('Nu ai acces la inventarul de echipamente.');
  const dependenciesSection=panel('Dependențe între servicii',`${serviceDependenciesPanel(service,allServices,diagramNomenclatures)}${serviceDependentsPanel(service)}`,service.is_common?'<span class="common-service-pill">Serviciu comun disponibil și pentru dependențe VM</span>':'<span class="muted">Orice serviciu activ poate fi sursă sau destinație a unei dependențe.</span>');
  const externalSection=can('external.read')?panel('Conexiuni către sisteme externe',scopedExternalConnectionPanel('service',id,externalConnections,externalSystems),'<a class="button-link small secondary" href="#external">Sisteme externe</a>'):empty('Nu ai acces la conexiunile externe.');
  const auditSection='<div id="scopedAuditRoot" class="loading">Se încarcă auditul serviciului…</div>';
  const sectionBodies={overview:summarySection,details:detailsSection,description:descriptionSection,purpose:purposeSection,objectives:objectivesSection,vault:vaultSection,environments:environmentsSection,classification:classificationSection,diagram:diagramSection,network:networkSection,vms:vmsSection,databases:databasesSection,docker:dockerSection,web:webSection,equipment:equipmentSection,dependencies:dependenciesSection,external:externalSection,documents:serviceDocumentPanel,audit:auditSection};

  content.innerHTML=`<div class="service-detail-toolbar"><a href="#services" class="button-link secondary">← Înapoi la servicii</a><span class="service-detail-context">${e(sectionLabel)}</span></div>${serviceTopCards(service)}${serviceDetailNavigation(id,service,selectedSection)}<div class="service-detail-workspace">${sectionBodies[selectedSection]||summarySection}</div>`;
  if(selectedSection==='overview'||selectedSection==='details'){
    const action=service.retired?'archived':'retired';
    content.querySelector('.service-detail-toolbar')?.insertAdjacentHTML('afterend',`<div class="lifecycle-detail-actions"><a href="#archive" class="button-link small secondary">Arhivă VM / servicii</a>${can('services.manage')?`<button class="small secondary lifecycle-service-quick" type="button">${service.retired?'Arhivează serviciul':'Retrage serviciul'}</button>`:''}</div>`);
    content.querySelector('.lifecycle-service-quick')?.addEventListener('click',()=>openLifecycleModal({type:'service',id:Number(id),name:service.name,status:service.retired?'retired':'active'},action));
  }
  content.querySelector(".service-detail-toolbar")?.insertAdjacentHTML("afterend",resourceBeneficiariesCard("service",id));
  loadBeneficiaryResourceCard("service",id);
  markLifecycleArchiveOnDetail('service',id);
  bindServiceInlineDetail(service,selectedSection);
  if(selectedSection==='network')bindNetworkDiagramActions(content,serviceNetworkMap);
  if(selectedSection==='documents'){bindServiceDocumentActions(id);bindServiceSupplementalActions(id);}
  if(selectedSection==='dependencies')bindServiceDependencyActions(id);
  if(selectedSection==='equipment'&&can('equipment.read'))bindServiceEquipmentActions(service,allEquipment);
  if(selectedSection==='external'&&can('external.read'))bindScopedExternalConnectionActions('service',id,()=>internalServiceDetail(id,'external'));
  if(selectedSection==='audit'&&can('audit.read'))await scopedAuditPage('service',id);
  document.getElementById('mergeInternalService')?.addEventListener('click',async()=>{const targetID=Number(document.getElementById('serviceMergeTarget')?.value||0);if(!targetID){toast('Alege proiectul destinație.',true);return}const target=allServices.find(item=>Number(item.id)===targetID);try{const impact=await api(`/api/v1/services/${id}/delete-impact`);if(!confirm(`Comasezi „${service.name}” în „${target?.name||targetID}”?\n\nSe vor muta: ${serviceImpactSummary(impact)}.\nProiectul „${service.name}” va fi șters la final.`))return;await api(`/api/v1/services/${id}/merge`,{method:'POST',body:JSON.stringify({target_service_id:targetID})});toast('Proiectele au fost comasate.');location.hash=`#services/${targetID}/overview`}catch(err){toast(err.message,true)}});
  document.getElementById('deleteInternalService')?.addEventListener('click',async()=>{try{const impact=await api(`/api/v1/services/${id}/delete-impact`);const related=serviceImpactSummary(impact);if(!confirm(`Ștergi definitiv proiectul „${service.name}”?\n\nImpact: ${related}.\nAceastă operație nu poate fi anulată.`))return;await api(`/api/v1/services/${id}`,{method:'DELETE'});toast('Proiectul a fost șters definitiv.');location.hash='#services'}catch(err){toast(err.message,true)}});
}

internalServiceForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('services.manage'))return;
  const id=Number(document.getElementById('internalServiceId').value||0);
  const descriptionRichText=richTextDocumentFromEditor('internalServiceDescriptionRich');const purposeRichText=richTextDocumentFromEditor('internalServicePurposeRich');const objectivesRichText=richTextDocumentFromEditor('internalServiceObjectivesRich');
  const isCommon=document.getElementById('internalServiceCommon').checked,implicitGlobal=document.getElementById('internalServiceImplicitGlobal').checked,commonTypeValue=document.getElementById('internalServiceCommonDependencyType').value;
  if((isCommon||implicitGlobal)&&!commonTypeValue){toast('Alege tipul dependenței pentru serviciul comun.',true);return}
  const retired=document.getElementById('internalServiceRetired').checked,retirementReason=document.getElementById('internalServiceRetirementReason').value;
  const body={name:document.getElementById('internalServiceName').value.trim(),service_code:document.getElementById('internalServiceCode').value.trim(),short_description:document.getElementById('internalServiceShortDescription').value.trim(),authentication:document.getElementById('internalServiceAuthentication').value.trim(),service_url:document.getElementById('internalServiceURL').value.trim(),technologies:document.getElementById('internalServiceTechnologies').value.trim(),criticality:document.getElementById('internalServiceCriticality').value,documentation_status:document.getElementById('internalServiceDocStatus').value,description:richTextPlain(descriptionRichText),description_richtext:descriptionRichText,purpose:richTextPlain(purposeRichText),purpose_richtext:purposeRichText,objectives:richTextPlain(objectivesRichText),objectives_richtext:objectivesRichText,documentation_url:document.getElementById('internalServiceDocumentationURL').value.trim(),active:retired?false:document.getElementById('internalServiceActive').checked,retired,retirement_reason_id:retired&&retirementReason?Number(retirementReason):null,retired_at:retired?document.getElementById('internalServiceRetiredAt').value:'',outline_documentation_disabled:document.getElementById('internalServiceOutlineDisabled').checked,is_common:isCommon||implicitGlobal,implicit_global:implicitGlobal,common_dependency_type_id:commonTypeValue?Number(commonTypeValue):null};
  try{const saved=await api(id?`/api/v1/services/${id}`:'/api/v1/services',{method:id?'PATCH':'POST',body:JSON.stringify(body)});internalServiceDialog.close();toast(id?'Serviciu actualizat.':'Serviciu creat.');const parts=(location.hash||'').slice(1).split('/'),section=id&&parts[0]==='services'&&Number(parts[1])===id?(parts[2]||'details'):'details',target=`#services/${saved.id}/${section}`;if(location.hash===target)internalServiceDetail(saved.id,section);else location.hash=target}catch(err){toast(err.message,true)}
});

function syncInternalServiceLifecycle(){
  const retired=document.getElementById('internalServiceRetired'),active=document.getElementById('internalServiceActive'),reason=document.getElementById('internalServiceRetirementReason'),date=document.getElementById('internalServiceRetiredAt');if(!retired||!active||!reason||!date)return;
  if(retired.checked){active.checked=false;active.disabled=true;reason.disabled=false;date.disabled=false}else{active.disabled=false;reason.disabled=true;date.disabled=true;reason.value='';date.value=''}
}
document.getElementById('internalServiceRetired')?.addEventListener('change',syncInternalServiceLifecycle);

function syncCommonServiceForm(){
  const common=document.getElementById('internalServiceCommon'),global=document.getElementById('internalServiceImplicitGlobal'),type=document.getElementById('internalServiceCommonDependencyType');if(!common||!global||!type)return;
  if(global.checked)common.checked=true;
  if(!common.checked){global.checked=false;type.value=''}
  type.disabled=!common.checked;
}
document.getElementById('internalServiceCommon')?.addEventListener('change',syncCommonServiceForm);
document.getElementById('internalServiceImplicitGlobal')?.addEventListener('change',syncCommonServiceForm);

let nomenclatureCache=[];
let peopleCache=[];
let beneficiaryDepartmentCount=null;
let directoryDepartmentCache=null;
let directoryUsersCache=[];
function updateNomenclatureParent(selected=[]){
  const category=document.getElementById('nomenclatureCategory').value;
  const parentLabel=document.getElementById('nomenclatureParentLabel');
  const parentText=document.getElementById('nomenclatureParentText');
  const parentHelp=document.getElementById('nomenclatureParentHelp');
  const orderText=document.getElementById('nomenclatureOrderText');
  const orderHelp=document.getElementById('nomenclatureOrderHelp');
  const parent=document.getElementById('nomenclatureParent');
  const isServiceCategory=category==='itil_category';
  const isTechnicalRole=category==='technical_role';
  destroyEnhancedMultiSelect(parent);
  parentLabel.hidden=!(isServiceCategory||isTechnicalRole);
  parent.required=isServiceCategory;
  parent.multiple=isTechnicalRole;
  parent.removeAttribute('size');
  orderText.textContent=isTechnicalRole?'Ordine în layer':'Ordine';
  orderHelp.textContent=isTechnicalRole?'Rolurile sunt afișate după ordinea layer-ului, apoi după această valoare.':'';
  if(isServiceCategory){
    parentText.textContent='Domeniu arhitectural';
    parentHelp.textContent='Categoria de serviciu aparține unui singur domeniu arhitectural.';
    const domains=sortNomenclatureValues(categoryItems(nomenclatureCache,'architectural_domain'));
    parent.innerHTML=selectOptions(domains,Array.isArray(selected)?selected[0]:selected,'— Alege domeniul arhitectural —');
  }else if(isTechnicalRole){
    parentText.textContent='Layer-e permise';
    parentHelp.textContent='Selectează unul sau mai multe layer-e. Rolul va fi disponibil numai în layer-ele alese.';
    const layers=sortNomenclatureValues(categoryItems(nomenclatureCache,'layer'));
    parent.innerHTML=multiSelectOptions(layers,Array.isArray(selected)?selected:[]);
    enhanceMultiSelect(parent,{placeholder:'Alege layer-ele'});
  }else{
    parentText.textContent='Relație';
    parentHelp.textContent='';
    parent.innerHTML='<option value="">— Nu se aplică —</option>';
  }
}
function openNomenclature(item=null,categoryCode='architectural_domain'){
  const selectedCategory=item?.category_code||categoryCode;
  const categoryOptions=nomenclatureCache.map(category=>`<option value="${e(category.code)}" ${selectedCategory===category.code?'selected':''}>${e(category.label)}</option>`).join('');
  document.getElementById('nomenclatureDialogTitle').textContent=item?'Editare valoare':'Valoare nouă';
  document.getElementById('nomenclatureId').value=item?.id||'';
  const category=document.getElementById('nomenclatureCategory');
  category.innerHTML=categoryOptions;
  category.disabled=Boolean(item);
  const osUnsupported=selectedCategory==='unsupported_os';
  document.getElementById('nomenclatureNameText').textContent=osUnsupported?'Sistem / familie OS':'Denumire';
  document.getElementById('nomenclatureCodeText').textContent=osUnsupported?'Versiune / familie':'Cod intern';
  document.getElementById('nomenclatureCodeHelp').textContent=osUnsupported?'Exemple: 7, 20.04, 2008-r2. Gol = toate versiunile familiei.':'';
  document.getElementById('nomenclatureName').placeholder=osUnsupported?'ex. CentOS, Ubuntu, Windows Server 2008':'';
  document.getElementById('nomenclatureName').value=item?.name||'';
  document.getElementById('nomenclatureCode').placeholder=osUnsupported?'ex. 7 sau 20.04':'opțional';
  document.getElementById('nomenclatureCode').value=item?.item_code||'';
  document.getElementById('nomenclatureIcon').value=item?.icon_key||'';
  document.getElementById('nomenclatureDescription').value=item?.description||'';
  document.getElementById('nomenclatureOrder').value=item?.sort_order??0;
  document.getElementById('nomenclatureActive').checked=item?.active??true;
  updateNomenclatureParent(selectedCategory==='technical_role'?(item?.layer_ids||[]):(item?.parent_id||''));
  nomenclatureDialog.showModal();
}
document.getElementById('nomenclatureCategory').addEventListener('change',()=>updateNomenclatureParent([]));
function openPerson(person=null){
  document.getElementById('personDialogTitle').textContent=person?'Editare persoană':'Persoană nouă';
  document.getElementById('personId').value=person?.id||'';
  document.getElementById('personName').value=person?.display_name||'';
  document.getElementById('personEmail').value=person?.email||'';
  document.getElementById('personPhone').value=person?.phone||'';
  document.getElementById('personDepartment').value=person?.department||'';
  const beneficiaryOU=document.getElementById('personBeneficiaryDepartment');
  beneficiaryOU.innerHTML='<option value="">Fără OU asociat</option>'+(state.personOUOptions||[]).filter(x=>x.active).map(x=>`<option value="${Number(x.id)}" ${Number(person?.beneficiary_department_id||0)===Number(x.id)?'selected':''}>${e(x.name)} · ${e(String(x.source).toUpperCase())}</option>`).join('');
  document.getElementById('personActive').checked=person?.active??true;
  personDialog.showModal();
}
const nomenclatureNavigationGroups=[
  {label:'Catalog servicii',codes:['architectural_domain','itil_category']},
  {label:'Arhitectură tehnică',codes:['layer','technical_role','solution_type']},
  {label:'Dependențe între servicii',codes:['dependency_type']},
  {label:'Operare VM',codes:['environment','operational_status','classification','unsupported_os']},
  {label:'Lifecycle servicii',codes:['service_retirement_reason']},
  {label:'Echipamente',codes:['device_type']},
  {label:'Responsabilități',codes:['people','beneficiaries']},
  {label:'Inventar tehnic',codes:['database_engine_visibility']},
  {label:'Securitate',codes:['hardening']}
];
const nomenclatureDescriptions={
  architectural_domain:'Domeniile arhitecturale grupează categoriile de serviciu și serviciile interne.',
  itil_category:'Categoriile de serviciu aparțin unui domeniu arhitectural și grupează serviciile interne.',
  layer:'Layer-ele descriu zona arhitecturală în care o VM îndeplinește o funcție.',
  technical_role:'Rolurile tehnice sunt legate de layer-ele în care pot fi selectate.',
  solution_type:'Tipul soluției indică natura tehnologiei folosite de o asociere VM–serviciu: open source, dezvoltată intern sau comercială.',
  dependency_type:'Tipurile de dependență descriu relația dintre două servicii: autentificare, DNS, baze de date, API, mesagerie, storage, backup și altele.',
  environment:'Mediile separă utilizarea VM-urilor, de exemplu producție, test sau dezvoltare.',
  operational_status:'Statusurile operaționale descriu starea curentă a unei VM în exploatare.',
  classification:'Clasificările permit marcarea nivelului sau tipului de informație gestionată.',
  unsupported_os:'Reguli pentru sisteme de operare nesuportate. Sistemul/familia se caută în numele OS; Versiunea se potrivește ca prefix. Dacă versiunea este goală, toate versiunile familiei sunt considerate nesuportate.',
  service_retirement_reason:'Motivele de retragere explică de ce un serviciu a fost scos din uz, înlocuit sau închis.',
  device_type:'Tipurile de echipamente grupează dispozitive medicale, aparatură de laborator, appliance-uri și alte resurse non-VM.',
  people:'Registru unic de persoane: responsabili VM și beneficiari, importate din AD sau introduse manual.'
};
function nomenclatureFilterState(code){
  if(!state.nomenclatureFilters[code])state.nomenclatureFilters[code]={q:'',status:'all',parent:'',layer:'',department:'',source:''};
  return state.nomenclatureFilters[code];
}
function normalizedFilterText(value){return String(value||'').trim().toLocaleLowerCase('ro-RO')}
function nomenclatureValueMatches(item,categoryCode,filter){
  if(filter.status==='active'&&!item.active)return false;
  if(filter.status==='inactive'&&item.active)return false;
  if(categoryCode==='itil_category'&&filter.parent&&Number(item.parent_id)!==Number(filter.parent))return false;
  if(categoryCode==='technical_role'&&filter.layer&&!(item.layer_ids||[]).some(id=>Number(id)===Number(filter.layer)))return false;
  const query=normalizedFilterText(filter.q);
  if(!query)return true;
  const haystack=[item.name,item.item_code,item.icon_key,item.description,item.parent_name,...(item.layer_names||[])].join(' ').toLocaleLowerCase('ro-RO');
  return haystack.includes(query);
}
function nomenclatureFilterForm(category,visibleCount,totalCount,pageSize){
  const filter=nomenclatureFilterState(category.code);
  const parentField=category.code==='itil_category'?`<label>Domeniu arhitectural<select name="parent"><option value="">Toate domeniile</option>${sortNomenclatureValues(categoryItems(nomenclatureCache,'architectural_domain')).map(item=>`<option value="${item.id}" ${String(filter.parent)===String(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}</select></label>`:'';
  const layerField=category.code==='technical_role'?`<label>Layer<select name="layer"><option value="">Toate layer-ele</option>${sortNomenclatureValues(categoryItems(nomenclatureCache,'layer')).map(item=>`<option value="${item.id}" ${String(filter.layer)===String(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}</select></label>`:'';
  return `<form id="nomenclatureFilters" class="nomenclature-filters">
    <label class="nomenclature-filter-search">Caută<input name="q" type="search" value="${e(filter.q)}" placeholder="Denumire, cod sau descriere"></label>
    ${parentField}${layerField}
    <label>Stare<select name="status"><option value="all" ${filter.status==='all'?'selected':''}>Toate</option><option value="active" ${filter.status==='active'?'selected':''}>Active</option><option value="inactive" ${filter.status==='inactive'?'selected':''}>Inactive</option></select></label>
    <label>Pe pagină<select name="page_size" id="nomenclatureTopPageSize">${pageSizeOptions(pageSize,[10,20,50,100,200])}</select></label>
    <div class="nomenclature-filter-actions"><button type="submit" class="small">Aplică filtre</button><button type="button" id="clearNomenclatureFilters" class="small secondary">Resetează</button></div>
    <span class="nomenclature-filter-summary">${visibleCount.toLocaleString('ro-RO')} rezultate din ${totalCount.toLocaleString('ro-RO')}</span>
  </form>`;
}
function nomenclaturePanel(category){
  const hasParent=category.code==='itil_category';
  const hasLayerLinks=category.code==='technical_role';
  const osUnsupported=category.code==='unsupported_os';
  const relationHead=hasParent?'<th>Domeniu arhitectural</th>':hasLayerLinks?'<th>Layer-e permise</th>':'';
  const head=`<tr><th>${osUnsupported?'Sistem / familie OS':'Denumire'}</th>${relationHead}<th>${osUnsupported?'Versiune / familie':'Cod'}</th><th>Pictogramă</th><th>Ordine</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  const filter=nomenclatureFilterState(category.code);
  const filteredItems=category.items.filter(item=>nomenclatureValueMatches(item,category.code,filter));
  const info=nomenclaturePageInfo(category.code,filteredItems.length);
  const visibleItems=filteredItems.slice(info.offset,info.end);
  const rows=visibleItems.map(item=>{
    const relation=hasParent?`<td>${e(item.parent_name||'—')}</td>`:hasLayerLinks?`<td>${item.layer_names?.length?e(item.layer_names.join(', ')):'<span class="muted">Nemapate</span>'}</td>`:'';
    return `<tr><td><strong>${e(item.name)}</strong>${item.description?`<div class="muted">${e(item.description)}</div>`:''}</td>${relation}<td class="mono">${e(item.item_code||'—')}</td><td>${nomenclatureIcon(item.icon_key,'small')} <span class="muted mono">${e(item.icon_key||'—')}</span></td><td>${item.sort_order}</td><td>${item.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-nomenclature" data-id="${item.id}">Editează</button></td>`:''}</tr>`;
  }).join('');
  const result=rows?`<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>${nomenclaturePagination(category.code,info)}`:empty(category.items.length?'Nu există valori pentru filtrele selectate.':'Nu există valori definite.');
  const body=`${nomenclatureFilterForm(category,filteredItems.length,category.items.length,info.pageSize)}${result}`;
  const tools=`<a class="button-link small secondary" href="/api/v1/nomenclatures/export?category=${encodeURIComponent(category.code)}&include_inactive=true">Export Excel</a>${can('nomenclatures.manage')?`<button class="small add-nomenclature" data-category="${e(category.code)}">Adaugă</button>`:''}`;
  return panel(e(category.label),body,tools);
}
async function loadDirectoryDepartments(force=false){
  if(directoryDepartmentCache&&!force)return directoryDepartmentCache;
  try{directoryDepartmentCache=await api('/api/v1/directory/departments')}
  catch(err){directoryDepartmentCache={enabled:false,departments:[],default_department:'',error:err.message}}
  return directoryDepartmentCache;
}
function directoryUserMatches(user,query){
  if(!query)return true;
  const haystack=[user.display_name,user.username,user.email,user.department,...(user.ou_path||[])].join(' ').toLocaleLowerCase('ro-RO');
  return haystack.includes(query.toLocaleLowerCase('ro-RO'));
}
function directoryUserRow(user){
  const imported=peopleCache.some(person=>person.source==='ldap'&&person.directory_username&&String(person.directory_username).toLocaleLowerCase('ro-RO')===String(user.username||'').toLocaleLowerCase('ro-RO'));
  return `<label class="directory-user"><input type="checkbox" class="directory-user-check" value="${e(user.distinguished_name)}"><span><strong>${e(user.display_name||user.username)}</strong><small>${e(user.username||'')}${user.email?` · ${e(user.email)}`:''}</small></span>${imported?'<em>importat</em>':''}</label>`;
}
function directoryTreeHTML(users){
  const root={children:new Map(),users:[]};
  for(const user of users){let node=root;for(const segment of (user.ou_path||[])){if(!node.children.has(segment))node.children.set(segment,{children:new Map(),users:[]});node=node.children.get(segment)}node.users.push(user)}
  const renderNode=(name,node,rootNode=false)=>{
    const childHTML=[...node.children.entries()].sort((a,b)=>a[0].localeCompare(b[0],'ro')).map(([childName,child])=>renderNode(childName,child)).join('');
    const userHTML=node.users.map(directoryUserRow).join('');
    const body=`${userHTML}${childHTML}`||'<div class="directory-empty muted">Fără utilizatori</div>';
    if(rootNode)return body;
    const count=(node.users?.length||0)+[...node.children.values()].reduce((sum,child)=>sum+directoryNodeCount(child),0);
    return `<details class="directory-ou" open><summary><span>${e(name)}</span><b>${count}</b></summary><div>${body}</div></details>`;
  };
  return renderNode('',root,true);
}
function directoryNodeCount(node){return (node.users?.length||0)+[...(node.children?.values?.()||[])].reduce((sum,child)=>sum+directoryNodeCount(child),0)}
function renderDirectoryUsers(){
  const query=document.getElementById('directorySearch').value.trim();
  const visible=directoryUsersCache.filter(user=>directoryUserMatches(user,query));
  document.getElementById('directorySummary').textContent=`${visible.length} utilizatori afișați din ${directoryUsersCache.length}`;
  document.getElementById('directoryUsers').innerHTML=visible.length?directoryTreeHTML(visible):empty('Nu există utilizatori pentru filtrul ales.');
}
async function loadDirectoryUsers(){
  const department=document.getElementById('directoryDepartment').value;
  const target=document.getElementById('directoryUsers');
  directoryUsersCache=[];
  target.innerHTML='<div class="loading">Se încarcă utilizatorii…</div>';
  document.getElementById('directorySummary').textContent='';
  if(!department){target.innerHTML=empty('Nu există departamente disponibile.');return}
  try{directoryUsersCache=await api(`/api/v1/directory/users?department=${encodeURIComponent(department)}`);renderDirectoryUsers()}
  catch(err){target.innerHTML=empty(err.message);toast(err.message,true)}
}
async function openDirectoryImport(){
  const info=await loadDirectoryDepartments();
  if(!info.enabled){toast(info.error||'Importul din Active Directory nu este activat.',true);return}
  const department=document.getElementById('directoryDepartment');
  department.innerHTML=(info.departments||[]).map(value=>`<option value="${e(value)}" ${value===info.default_department?'selected':''}>${e(value)}</option>`).join('');
  document.getElementById('directorySearch').value='';
  directoryDialog.showModal();
  await loadDirectoryUsers();
}
function personMatchesFilters(person,filter){
  if(filter.status==='active'&&!person.active)return false;
  if(filter.status==='inactive'&&person.active)return false;
  if(filter.department&&person.department!==filter.department)return false;
  if(filter.source&&person.source!==filter.source)return false;
  const query=normalizedFilterText(filter.q);
  if(!query)return true;
  return [person.display_name,person.department,person.email,person.phone,person.directory_username].join(' ').toLocaleLowerCase('ro-RO').includes(query);
}
function peopleFilterForm(visibleCount,totalCount,pageSize){
  const filter=nomenclatureFilterState('people');
  const departments=[...new Set(peopleCache.map(person=>String(person.department||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro',{sensitivity:'base'}));
  return `<form id="nomenclatureFilters" class="nomenclature-filters">
    <label class="nomenclature-filter-search">Caută<input name="q" type="search" value="${e(filter.q)}" placeholder="Nume, departament, email sau telefon"></label>
    <label>Departament<select name="department"><option value="">Toate departamentele</option>${departments.map(value=>`<option value="${e(value)}" ${filter.department===value?'selected':''}>${e(value)}</option>`).join('')}</select></label>
    <label>Sursă<select name="source"><option value="" ${!filter.source?'selected':''}>Toate</option><option value="ldap" ${filter.source==='ldap'?'selected':''}>Active Directory</option><option value="manual" ${filter.source==='manual'?'selected':''}>Manual</option></select></label>
    <label>Stare<select name="status"><option value="all" ${filter.status==='all'?'selected':''}>Toate</option><option value="active" ${filter.status==='active'?'selected':''}>Active</option><option value="inactive" ${filter.status==='inactive'?'selected':''}>Inactive</option></select></label>
    <label>Pe pagină<select name="page_size" id="nomenclatureTopPageSize">${pageSizeOptions(pageSize,[10,20,50,100,200])}</select></label>
    <div class="nomenclature-filter-actions"><button type="submit" class="small">Aplică filtre</button><button type="button" id="clearNomenclatureFilters" class="small secondary">Resetează</button></div>
    <span class="nomenclature-filter-summary">${visibleCount.toLocaleString('ro-RO')} rezultate din ${totalCount.toLocaleString('ro-RO')}</span>
  </form>`;
}
function peopleNomenclaturePanel(directoryInfo){
  const filter=nomenclatureFilterState('people');
  const filteredPeople=peopleCache.filter(person=>personMatchesFilters(person,filter));
  const info=nomenclaturePageInfo('people',filteredPeople.length);
  const visiblePeople=filteredPeople.slice(info.offset,info.end);
  const rows=visiblePeople.map(person=>`<tr><td><strong>${e(person.display_name)}</strong><div class="muted">${e(person.department||'')}</div></td><td>${e(person.email||'—')}</td><td>${e(person.phone||'—')}</td><td>${person.source==='ldap'||person.source==='ad'?badge('AD'):badge('manual')}</td><td>${person.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-person" data-id="${person.id}">Editează</button></td>`:''}</tr>`).join('');
  const head=`<tr><th>Persoană</th><th>Email</th><th>Telefon</th><th>Sursă</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  const result=rows?`<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>${nomenclaturePagination('people',info)}`:empty(peopleCache.length?'Nu există persoane pentru filtrele selectate.':'Nu există persoane definite.');
  let body=`${peopleFilterForm(filteredPeople.length,peopleCache.length,info.pageSize)}${result}`;
  if(directoryInfo?.error)body=`<div class="notice warning">Active Directory nu a putut fi interogat: ${e(directoryInfo.error)}</div>${body}`;
  const tools=`<a class="button-link small secondary" href="/api/v1/nomenclatures/export?category=people&include_inactive=true">Export Excel</a>${can('nomenclatures.manage')?`<button id="addPerson" class="small secondary">Adaugă manual</button>${directoryInfo?.enabled?'<button id="importDirectoryPeople" class="small">Importă din AD</button>':''}`:''}`;
  return panel('Persoane · responsabili și beneficiari',body,tools);
}
function nomenclatureNavigation(selectedCode){
  const categories=new Map(nomenclatureCache.map(category=>[category.code,category]));
  const rendered=new Set();
  const groups=nomenclatureNavigationGroups.map(group=>{
    const links=group.codes.map(code=>{
      if(code==='hardening'){
        rendered.add(code);
        return `<a href="#nomenclatures/hardening" class="${selectedCode==='hardening'?'active':''}"><span>Hardening · reguli și profiluri</span></a>`;
      }
      if(code==='database_engine_visibility'){
        rendered.add(code);
        return `<a href="#nomenclatures/database_engine_visibility" class="${selectedCode==='database_engine_visibility'?'active':''}"><span>Motoare DB ignorate</span></a>`;
      }
      if(code==='people'){
        rendered.add(code);
        return `<a href="#nomenclatures/people" class="${selectedCode==='people'?'active':''}"><span>Persoane</span><b>${peopleCache.length}</b></a>`;
      }
      if(code==='beneficiaries'){
        rendered.add(code);
        return `<a href="#nomenclatures/beneficiaries" class="${selectedCode==='beneficiaries'?'active':''}"><span>Beneficiari</span>${Number.isInteger(beneficiaryDepartmentCount)?`<b>${beneficiaryDepartmentCount}</b>`:''}</a>`;
      }
      const category=categories.get(code);if(!category)return '';
      rendered.add(code);
      return `<a href="#nomenclatures/${e(code)}" class="${selectedCode===code?'active':''}"><span>${e(category.label)}</span><b>${category.items.length}</b></a>`;
    }).join('');
    return links?`<section><h3>${e(group.label)}</h3>${links}</section>`:'';
  }).join('');
  const other=[...categories.values()].filter(category=>!rendered.has(category.code));
  const otherGroup=other.length?`<section><h3>Altele</h3>${other.map(category=>`<a href="#nomenclatures/${e(category.code)}" class="${selectedCode===category.code?'active':''}"><span>${e(category.label)}</span><b>${category.items.length}</b></a>`).join('')}</section>`:'';
  return `<aside class="nomenclature-submenu"><div class="nomenclature-submenu-title">Nomenclatoare</div>${groups}${otherGroup}</aside>`;
}
function refreshNomenclatureSection(code){
  const target=`#nomenclatures/${code}`;
  if(location.hash===target)nomenclaturesPage(code);else location.hash=target;
}
async function nomenclaturesPage(requestedCode=''){
  if(requestedCode==='hardening'){await hardeningCatalogPage();return}
  if(requestedCode==='beneficiaries'){await beneficiaryCatalogPage();return}
  if(requestedCode==='database_engine_visibility'){await databaseEngineVisibilityPage();return}
  const [loadedCategories,loadedPeople,loadedDepartments]=await Promise.all([
    api('/api/v1/nomenclatures?include_inactive=true'),
    api('/api/v1/people?include_inactive=true'),
    api('/api/v1/beneficiaries?type=department&include_inactive=true').catch(()=>null)
  ]);
  nomenclatureCache=loadedCategories;peopleCache=loadedPeople;
  if(Array.isArray(loadedDepartments))beneficiaryDepartmentCount=loadedDepartments.length;
  const allowedCodes=new Set([...nomenclatureCache.map(category=>category.code),'people']);
  const selectedCode=allowedCodes.has(requestedCode)?requestedCode:(nomenclatureCache[0]?.code||'people');
  if(requestedCode!==selectedCode)history.replaceState(null,'',`#nomenclatures/${selectedCode}`);
  const category=nomenclatureCache.find(value=>value.code===selectedCode);
  const label=selectedCode==='people'?'Persoane':category?.label||'Nomenclatoare';
  const description=nomenclatureDescriptions[selectedCode]||'Listă controlată folosită în fișele VM.';
  pageMeta('Nomenclatoare',`${label} · ${description}`);
  const directoryInfo=selectedCode==='people'?await loadDirectoryDepartments():null;
  if(selectedCode==='people')state.personOUOptions=await api('/api/v1/beneficiaries?type=department').catch(()=>[]);
  const selectedPanel=selectedCode==='people'?peopleNomenclaturePanel(directoryInfo):nomenclaturePanel(category);
  content.innerHTML=`<div class="nomenclature-layout">
    ${nomenclatureNavigation(selectedCode)}
    <div class="nomenclature-workspace">
      <div class="nomenclature-context"><span>${e(label)}</span><p>${e(description)}</p></div>
      ${selectedPanel}
    </div>
  </div>`;
  content.querySelectorAll('.add-nomenclature').forEach(button=>button.onclick=()=>openNomenclature(null,button.dataset.category));
  content.querySelectorAll('.edit-nomenclature').forEach(button=>button.onclick=()=>{const item=nomenclatureCache.flatMap(value=>value.items).find(value=>value.id===Number(button.dataset.id));openNomenclature(item)});
  document.getElementById('addPerson')?.addEventListener('click',()=>openPerson());
  document.getElementById('importDirectoryPeople')?.addEventListener('click',openDirectoryImport);
  content.querySelectorAll('.edit-person').forEach(button=>button.onclick=()=>openPerson(peopleCache.find(person=>person.id===Number(button.dataset.id))));
  document.getElementById('nomenclatureFilters')?.addEventListener('submit',event=>{
    event.preventDefault();
    const values=Object.fromEntries(new FormData(event.currentTarget).entries());
    state.nomenclatureFilters[selectedCode]={q:String(values.q||'').trim(),status:String(values.status||'all'),parent:String(values.parent||''),layer:String(values.layer||''),department:String(values.department||''),source:String(values.source||'')};
    const requestedSize=Number(values.page_size||10),pageSize=[10,20,50,100,200].includes(requestedSize)?requestedSize:10;const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize};paging.page=1;paging.pageSize=pageSize;state.nomenclaturePaging[selectedCode]=paging;localStorage.setItem(`vm-doc:nomenclature-page-size:${selectedCode}`,String(pageSize));
    nomenclaturesPage(selectedCode);
  });
  document.getElementById('clearNomenclatureFilters')?.addEventListener('click',()=>{
    state.nomenclatureFilters[selectedCode]={q:'',status:'all',parent:'',layer:'',department:'',source:''};
    const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize:10};paging.page=1;state.nomenclaturePaging[selectedCode]=paging;
    nomenclaturesPage(selectedCode);
  });
  content.querySelectorAll('.nomenclature-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize:10};if(page>0&&page!==paging.page){paging.page=page;state.nomenclaturePaging[selectedCode]=paging;nomenclaturesPage(selectedCode)}}));
  document.getElementById('nomenclatureTopPageSize')?.addEventListener('change',event=>{const pageSize=Number(event.target.value);state.nomenclaturePaging[selectedCode]={page:1,pageSize};localStorage.setItem(`vm-doc:nomenclature-page-size:${selectedCode}`,String(pageSize));nomenclaturesPage(selectedCode)});
}

nomenclatureForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('nomenclatureId').value||0);
  const categoryCode=document.getElementById('nomenclatureCategory').value;
  const parent=document.getElementById('nomenclatureParent');
  const parentValue=parent.value;
  const layerIDs=categoryCode==='technical_role'?[...parent.selectedOptions].map(option=>Number(option.value)).filter(Boolean):[];
  if(categoryCode==='technical_role'&&!layerIDs.length){toast('Selectează cel puțin un layer pentru rolul tehnic.',true);return}
  const body={category_code:categoryCode,name:document.getElementById('nomenclatureName').value.trim(),item_code:document.getElementById('nomenclatureCode').value.trim(),description:document.getElementById('nomenclatureDescription').value.trim(),icon_key:document.getElementById('nomenclatureIcon').value.trim(),sort_order:Number(document.getElementById('nomenclatureOrder').value||0),active:document.getElementById('nomenclatureActive').checked,parent_id:categoryCode==='itil_category'&&parentValue?Number(parentValue):null,layer_ids:layerIDs};
  try{await api(id?`/api/v1/nomenclatures/items/${id}`:'/api/v1/nomenclatures/items',{method:id?'PATCH':'POST',body:JSON.stringify(body)});nomenclatureDialog.close();toast(id?'Valoare actualizată.':'Valoare creată.');refreshNomenclatureSection(categoryCode)}catch(err){toast(err.message,true)}
});
personForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('personId').value||0);const body={display_name:document.getElementById('personName').value.trim(),email:document.getElementById('personEmail').value.trim(),phone:document.getElementById('personPhone').value.trim(),department:document.getElementById('personDepartment').value.trim(),beneficiary_department_id:Number(document.getElementById('personBeneficiaryDepartment').value||0),active:document.getElementById('personActive').checked};
  try{await api(id?`/api/v1/people/${id}`:'/api/v1/people',{method:id?'PATCH':'POST',body:JSON.stringify(body)});personDialog.close();toast(id?'Persoană actualizată.':'Persoană creată.');refreshNomenclatureSection('people')}catch(err){toast(err.message,true)}
});

document.getElementById('directoryDepartment').addEventListener('change',loadDirectoryUsers);
document.getElementById('directorySearch').addEventListener('input',renderDirectoryUsers);
document.getElementById('directoryToggleAll').addEventListener('click',()=>{
  const checks=[...document.querySelectorAll('#directoryUsers .directory-user-check')];
  const select=checks.some(check=>!check.checked);checks.forEach(check=>check.checked=select);
});
directoryForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const distinguishedNames=[...document.querySelectorAll('#directoryUsers .directory-user-check:checked')].map(check=>check.value);
  if(!distinguishedNames.length){toast('Selectează cel puțin un utilizator din Active Directory.',true);return}
  try{const imported=await api('/api/v1/people/import-directory',{method:'POST',body:JSON.stringify({distinguished_names:distinguishedNames})});directoryDialog.close();toast(`${imported.length} persoane importate sau actualizate din AD.`);refreshNomenclatureSection('people')}catch(err){toast(err.message,true)}
});


function documentObjectTypeLabel(value){return value==='service'?'Serviciu intern':'VM'}
function updateDocumentTemplateHelp(){
  const type=document.getElementById('documentTemplateObjectType')?.value||'vm';
  const help=document.getElementById('documentTemplateFileHelp');
  if(help)help.textContent=`Șablonul trebuie să conțină placeholderul ${type==='service'?'{{SERVICE_DOCUMENT_BODY}}':'{{VM_DOCUMENT_BODY}}'} într-un paragraf separat.`;
}
function openDocumentTemplate(template=null){
  document.getElementById('documentTemplateDialogTitle').textContent=template?'Editare șablon DOCX':'Șablon DOCX nou';
  document.getElementById('documentTemplateId').value=template?.id||'';
  document.getElementById('documentTemplateName').value=template?.name||'';
  document.getElementById('documentTemplateCode').value=template?.code||'';
  document.getElementById('documentTemplateDescription').value=template?.description||'';
  const objectType=document.getElementById('documentTemplateObjectType');objectType.value=template?.object_type||'vm';objectType.disabled=Boolean(template);
  document.getElementById('documentTemplateActive').checked=template?.active??true;
  document.getElementById('documentTemplateDefault').checked=template?.is_default??false;
  const file=document.getElementById('documentTemplateFile');file.value='';file.required=!template;
  document.getElementById('documentTemplateFileLabel').hidden=Boolean(template);
  updateDocumentTemplateHelp();
  documentTemplateDialog.showModal();
}
function documentTemplateRows(values){
  if(!values?.length)return empty('Nu există șabloane DOCX.');
  const rows=values.map(item=>`<tr><td><strong>${e(item.name)}</strong>${item.description?`<div class="muted">${e(item.description)}</div>`:''}</td><td>${badge(documentObjectTypeLabel(item.object_type))}</td><td class="mono">${e(item.code)}</td><td>${e(item.file_name)}</td><td>${bytesText(item.size_bytes)}</td><td>${item.is_default?badge('implicit'):''}</td><td>${item.active?badge('active'):badge('disabled')}</td><td><div class="actions"><a class="button-link small secondary" href="/api/v1/document-templates/${item.id}/download">Descarcă</a>${can('documents.manage')?`<button class="small secondary edit-document-template" data-id="${item.id}">Editează</button>`:''}</div></td></tr>`).join('');
  return `<div class="table-wrap"><table><thead><tr><th>Șablon</th><th>Tip fișă</th><th>Cod</th><th>Fișier</th><th>Mărime</th><th>Implicit</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function bulkDocumentExportPanel(){
  const link=(href,label,kind='secondary')=>`<a class="button-link ${kind}" href="${href}" target="_blank" rel="noopener">${e(label)}</a>`;
  const vmDocx=can('documents.manage')?`<button id="bulkExportVMDocx" type="button">Export arhivă DOCX</button>`:link('/api/v1/documents/export/vms/docx','Export arhivă DOCX');
  const serviceDocx=can('documents.manage')?`<button id="bulkExportServiceDocx" type="button">Export arhivă DOCX</button>`:link('/api/v1/documents/export/services/docx','Export arhivă DOCX');
  return `<div class="bulk-document-export-grid">
    <article><div><h3>Fișele tuturor VM-urilor</h3><p>Descarcă într-o singură arhivă ZIP ultima fișă pentru VM-urile selectate.</p>${can('documents.manage')?`<div class="service-document-options bulk-document-options"><label><input id="bulkVMPoweredOnOnly" type="checkbox" checked> Doar VM-uri pornite</label><label><input id="bulkVMRegenerate" type="checkbox"> Regenerează toate fișele VM înainte de export</label></div><p class="muted">Implicit sunt incluse numai VM-urile <code>POWERED_ON</code>. Debifează pentru toate VM-urile active/neretrase. Dacă bifezi regenerarea, se folosește șablonul VM implicit și fișele nou generate nu conțin câmpul „Generat de”.</p>`:''}</div><div class="actions">${vmDocx}</div></article>
    <article><div><h3>Fișele tuturor proiectelor</h3><p>Descarcă într-o singură arhivă ZIP ultima fișă tehnică și operațională pentru fiecare proiect/serviciu activ.</p>${can('documents.manage')?`<div class="service-document-options bulk-document-options"><label><input id="bulkServiceRegenerate" type="checkbox"> Regenerează toate fișele proiectelor înainte de export</label><label><input id="bulkServiceGenerateMissing" type="checkbox"> Generează fișa proiectului dacă nu există</label><label><input id="bulkServiceIncludeVMDocuments" type="checkbox"> Include și fișele VM asociate proiectelor</label></div><p class="muted">Toate opțiunile proiectelor sunt implicit nebifate. „Regenerează” are prioritate și creează o fișă nouă pentru fiecare proiect activ; documentele generate/regenerate nu conțin „Generat de”. Fișele VM sunt adăugate separat în directorul <code>VM-uri/</code> din arhivă.</p>`:''}</div><div class="actions">${serviceDocx}</div></article>
  </div><p class="muted bulk-document-export-note">La VM-uri, <strong>Doar VM-uri pornite</strong> este bifat implicit; celelalte opțiuni DOCX sunt implicit nebifate. Exporturile PDF sunt ascunse temporar din interfață; endpoint-urile existente rămân disponibile pentru o versiune ulterioară. Fiecare ZIP conține <code>_manifest.csv</code> și <code>_sumar.txt</code>.</p>`;
}
function bindBulkDocumentExportActions(){
  document.getElementById('bulkExportVMDocx')?.addEventListener('click',async event=>{
    const button=event.currentTarget,poweredOnOnly=!!document.getElementById('bulkVMPoweredOnOnly')?.checked,regenerate=!!document.getElementById('bulkVMRegenerate')?.checked;button.disabled=true;button.textContent=regenerate?'Se regenerează și se arhivează…':'Se pregătește arhiva…';
    try{await postDownload('/api/v1/documents/export/vms/docx',{powered_on_vms_only:poweredOnOnly,regenerate_vm_documents:regenerate},'vm-doc-vm-docx.zip');toast(regenerate?'Arhiva DOCX VM a fost creată după regenerarea fișelor.':'Arhiva DOCX VM a fost creată.')}catch(err){toast(err.message,true)}finally{button.disabled=false;button.textContent='Export arhivă DOCX'}
  });
  document.getElementById('bulkExportServiceDocx')?.addEventListener('click',async event=>{
    const button=event.currentTarget,regenerate=!!document.getElementById('bulkServiceRegenerate')?.checked,generateMissing=!!document.getElementById('bulkServiceGenerateMissing')?.checked,includeVM=!!document.getElementById('bulkServiceIncludeVMDocuments')?.checked;button.disabled=true;button.textContent=(regenerate||generateMissing)?'Se generează și se arhivează…':'Se pregătește arhiva…';
    try{await postDownload('/api/v1/documents/export/services/docx',{regenerate_service_documents:regenerate,generate_missing_services:generateMissing,include_service_vm_documents:includeVM},'vm-doc-proiecte-docx.zip');toast(regenerate?'Arhiva DOCX a proiectelor a fost creată după regenerarea fișelor.':'Arhiva DOCX a proiectelor a fost creată.')}catch(err){toast(err.message,true)}finally{button.disabled=false;button.textContent='Export arhivă DOCX'}
  });
}
function outlineIntegrationPanel(settings={},targets=[],mode='all'){
  const enabled=!!settings.enabled,keyConfigured=!!settings.api_key_configured,targetList=Array.isArray(targets)?targets:[],vmInventoryTarget=targetList.find(item=>item.code==='vm_inventory')||{},supportComponentsTarget=targetList.find(item=>item.code==='support_components')||{};
  const form=can('documents.manage')?`<form id="outlineSettingsForm" class="document-generation-form outline-settings-form"><div class="form-grid"><label class="check-row span-2"><input id="outlineEnabled" type="checkbox" ${enabled?'checked':''}> Activează integrarea Outline</label><label class="span-2">URL Outline<input id="outlineBaseURL" type="url" value="${e(settings.base_url||'')}" placeholder="https://outline.exemplu.ro"></label><label>Collection ID <span class="muted">(opțional)</span><input id="outlineCollectionID" class="mono" value="${e(settings.collection_id||'')}" placeholder="UUID colecție"></label><label>Virtualizare · Document / URL<input id="outlineVirtualizationParentID" class="mono" value="${e(settings.virtualization_parent_document_id||'')}" placeholder="UUID, slug sau URL Outline"></label><label class="span-2">API key<input id="outlineAPIKey" type="password" autocomplete="new-password" placeholder="${keyConfigured?'Configurată · lasă gol pentru a o păstra':'ol_api_…'}"></label><label><input id="outlineVerifyTLS" type="checkbox" ${settings.verify_tls!==false?'checked':''}> Verifică certificatul TLS</label><label><input id="outlineAllowHTTP" type="checkbox" ${settings.allow_http?'checked':''}> Permite HTTP</label><label>Timeout API (sec)<input id="outlineTimeout" type="number" min="5" max="300" value="${Number(settings.request_timeout_seconds||30)}"></label></div><div class="form-actions"><button type="submit">Salvează Outline</button><button id="testOutlineConnection" type="button" class="secondary" ${enabled?'':'disabled'}>Testează conexiunea</button></div><p class="muted">La salvare, VM-DOC rezolvă automat documentul Virtualizare la UUID-ul Outline real. VM-urile sunt gestionate sub Virtualizare; serviciile folosesc propriul <strong>Link documentație</strong> și nu sunt mutate de VM-DOC.</p></form>`:`<div class="detail-grid">${detail('Stare',enabled?badge('active'):badge('disabled'))}${detail('URL',e(settings.base_url||'—'))}${detail('Collection ID',e(settings.collection_id||'—'),true)}${detail('Virtualizare · Document ID',e(settings.virtualization_parent_document_id||'—'),true)}${detail('API key',keyConfigured?'Configurată':'—')}</div>`;
  const vmTarget=can('documents.manage')?`<form id="outlineVMInventoryTargetForm" class="outline-target-form"><div class="form-grid"><label>Destinație<input value="Inventar VM" disabled></label><label class="span-2">Inventar VM · Link / document Outline<input id="outlineVMInventoryTargetReference" class="mono" value="${e(vmInventoryTarget.document_reference||'')}" placeholder="https://outline.exemplu.ro/doc/inventar-vm-…"></label><label class="check-row"><input id="outlineVMInventoryTargetActive" type="checkbox" ${vmInventoryTarget.active!==false?'checked':''}> Activă</label></div><div class="form-actions"><button type="submit">Salvează destinația</button>${vmInventoryTarget.document_url?`<a class="button-link secondary" href="${e(vmInventoryTarget.document_url)}" target="_blank" rel="noopener">Deschide pagina</a>`:''}</div><p class="muted">Publicarea din lista VM actualizează exact această pagină și păstrează titlul ei.${vmInventoryTarget.last_published_at?` Ultima publicare: <strong>${dt(vmInventoryTarget.last_published_at)}</strong>.`:''}</p></form>`:`<div class="detail-grid">${detail('Inventar VM',vmInventoryTarget.document_url?`<a href="${e(vmInventoryTarget.document_url)}" target="_blank" rel="noopener">${e(vmInventoryTarget.document_url)}</a>`:'—')}</div>`;
  const supportTarget=can('documents.manage')?`<form id="outlineSupportComponentsTargetForm" class="outline-target-form"><div class="form-grid"><label>Destinație<input value="Componente suport" disabled></label><label class="span-2">Componente suport · Link / document părinte Outline<input id="outlineSupportComponentsTargetReference" class="mono" value="${e(supportComponentsTarget.document_reference||'')}" placeholder="https://outline.exemplu.ro/doc/componente-suport-…"></label><label class="check-row"><input id="outlineSupportComponentsTargetActive" type="checkbox" ${supportComponentsTarget.active!==false?'checked':''}> Activă</label></div><div class="form-actions"><button type="submit">Salvează destinația</button>${supportComponentsTarget.document_url?`<a class="button-link secondary" href="${e(supportComponentsTarget.document_url)}" target="_blank" rel="noopener">Deschide pagina părinte</a>`:''}</div><p class="muted">Aceasta este pagina <strong>părinte</strong>. Din raportul Componente software, VM-DOC creează sau actualizează sub ea câte o pagină <code>comp-...</code> pentru fiecare componentă care există pe VM-uri PROD. Pagina părinte nu este rescrisă.</p></form>`:`<div class="detail-grid">${detail('Componente suport',supportComponentsTarget.document_url?`<a href="${e(supportComponentsTarget.document_url)}" target="_blank" rel="noopener">${e(supportComponentsTarget.document_url)}</a>`:'—')}</div>`;
  const targetConfig=`<div class="outline-publication-targets"><h3>Destinații publicare</h3><p class="muted">Pagini Outline existente folosite ca destinații sau părinți pentru rapoarte publicate automat.</p>${vmTarget}${supportTarget}</div>`;
  const bulk=can('documents.manage')&&enabled?`<div class="outline-bulk-grid"><article class="outline-bulk-publish"><h3>VM-uri → Virtualizare</h3><p>Publică sau actualizează numai VM-urile din mediul PROD. Titlul paginii începe cu <code>vm-</code>. VM-urile TEST/DEV/fără mediu și cele marcate „Nu se publică în Outline” sunt sărite și afișate separat.</p><div class="service-document-options"><label><input id="outlineBulkPoweredOn" type="checkbox" checked> Doar VM-uri pornite</label></div><div class="actions"><button id="publishAllOutline" type="button">Publică VM-urile</button></div><div id="outlineBulkProgress" class="muted"></div><div id="outlineBulkSkipped"></div></article><article class="outline-bulk-publish"><h3>Servicii PROD → paginile configurate</h3><p>Înainte de publicare, VM-DOC verifică numai serviciile care au cel puțin o asociere VM în PROD. Conținutul publicat este filtrat strict la PROD; serviciile fără PROD sunt omise. Paginile nu sunt create, redenumite sau mutate.</p><div class="actions"><button id="previewServicesOutline" type="button">Verifică serviciile</button></div><div id="outlineServicePreview" class="outline-service-preview"></div><div id="outlineServiceBulkProgress" class="muted"></div></article></div>`:'';
  if(mode==='config')return `${form}${targetConfig}`;
  if(mode==='publish')return bulk||`<div class="notice"><strong>Outline</strong><div>Integrarea Outline este dezactivată. Configureaz-o din <a href="#documents/outline-config">Configurare Outline</a>.</div></div>`;
  return `${form}${targetConfig}${bulk}`;
}
const outlineServicePreviewState={page:1,pageSize:Number(localStorage.getItem('vm-doc:outline-service-preview-page-size')||25)||25,filter:'all',jobID:''};
function outlineServicePreviewMatches(row,filter){
  if(filter==='eligible')return !!row.eligible;
  if(filter==='missing_link')return row.reason_code==='missing_link';
  if(filter==='outline_disabled')return row.reason_code==='outline_disabled';
  if(filter==='inactive_or_retired')return row.reason_code==='inactive'||row.reason_code==='retired';
  if(filter==='link_error')return row.reason_code==='link_error';
  if(filter==='content_error')return row.reason_code==='content_error';
  return true;
}
function outlineServicePreviewHTML(data={},jobID=''){
  const services=Array.isArray(data.services)?data.services:[],filter=outlineServicePreviewState.filter||'all';
  const stateBadge=row=>row.retired?'<span class="badge missing">Retras</span>':!row.active?'<span class="badge">Inactiv</span>':'<span class="badge active">Activ</span>';
  const card=(label,value,key,extra='')=>`<button type="button" class="outline-preview-stat-card ${extra} ${filter===key?'active':''}" data-filter="${e(key)}"><span>${e(label)}</span><strong>${Number(value||0)}</strong></button>`;
  const stats=`<div class="outline-preview-stats">${card('Total PROD',data.total,'all')}${card('Eligibile',data.eligible,'eligible','eligible')}${card('Fără link',data.missing_link,'missing_link')}${card('Excluse Outline',data.excluded_outline,'outline_disabled')}${card('Inactive / retrase',data.inactive_or_retired,'inactive_or_retired')}${card('Erori link',data.link_errors,'link_error',Number(data.link_errors||0)?'warning':'')}${card('Erori conținut',data.content_errors,'content_error',Number(data.content_errors||0)?'warning':'')}</div>${Number(data.omitted_non_prod||0)?`<p class="muted">${Number(data.omitted_non_prod).toLocaleString('ro-RO')} servicii fără nicio asociere PROD au fost omise din verificarea Outline.</p>`:''}`;
  const rows=services.map(row=>`<tr class="outline-service-preview-row" data-reason="${e(row.reason_code||'')}" data-eligible="${row.eligible?'yes':'no'}"><td><a href="#services/${row.id}/details"><strong>${e(row.name)}</strong></a></td><td>${stateBadge(row)}</td><td>${row.documentation_url?`<a href="${e(row.documentation_url)}" target="_blank" rel="noopener">${e(row.documentation_url)}</a>`:'—'}</td><td>${row.eligible?'<span class="badge active">DA</span>':'<span class="badge missing">NU</span>'}</td><td>${e(row.reason||'—')}${row.resolved_document_id?`<div class="muted mono">Document: ${e(row.resolved_document_id)}</div>`:''}</td></tr>`).join('');
  const table=rows?`<div class="table-wrap outline-preview-table"><table><thead><tr><th>Serviciu</th><th>Stare</th><th>Link Outline</th><th>Publică</th><th>Verificare</th></tr></thead><tbody>${rows}</tbody></table></div><div id="outlineServicePreviewPagination" class="pagination"></div>`:empty('Nu există servicii de verificat.');
  const eligibleIDs=Array.isArray(data.eligible_ids)?data.eligible_ids:[];
  const exportLink=jobID?`<a id="outlineServicePreviewExport" class="button-link small secondary" href="/api/v1/documents/outline/jobs/${encodeURIComponent(jobID)}/services-export">Export Excel</a>`:'';
  const actions=`<div class="outline-preview-actions"><span class="muted">Verificare: ${data.generated_at?dt(data.generated_at):'—'}</span><div class="actions">${exportLink}${eligibleIDs.length?`<button id="publishServicesOutline" type="button">Publică cele ${eligibleIDs.length} servicii PROD eligibile</button>`:'<span class="badge missing">Nu există servicii PROD eligibile</span>'}</div></div>`;
  return `${stats}${table}${actions}`;
}
function applyOutlineServicePreviewView(){
  const data=outlineServicePreviewState.data||{},rows=[...document.querySelectorAll('.outline-service-preview-row')],filter=outlineServicePreviewState.filter||'all';
  const matching=rows.filter(row=>{
    if(filter==='eligible')return row.dataset.eligible==='yes';
    if(filter==='inactive_or_retired')return ['inactive','retired'].includes(row.dataset.reason);
    return filter==='all'||row.dataset.reason===filter;
  });
  const pageSize=Math.max(10,Number(outlineServicePreviewState.pageSize||25)),pages=Math.max(1,Math.ceil(matching.length/pageSize));
  outlineServicePreviewState.page=Math.min(Math.max(1,Number(outlineServicePreviewState.page||1)),pages);
  const start=(outlineServicePreviewState.page-1)*pageSize,end=start+pageSize,visible=new Set(matching.slice(start,end));
  rows.forEach(row=>row.hidden=!visible.has(row));
  document.querySelectorAll('.outline-preview-stat-card').forEach(card=>card.classList.toggle('active',card.dataset.filter===filter));
  const pager=document.getElementById('outlineServicePreviewPagination');
  if(pager){
    const shownStart=matching.length?start+1:0,shownEnd=Math.min(end,matching.length);
    pager.innerHTML=`<span>Afișate ${shownStart.toLocaleString('ro-RO')}–${shownEnd.toLocaleString('ro-RO')} din ${matching.length.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="outlineServicePreviewPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(outlineServicePreviewState.page,pages,'outline-service-preview-page')}</div>`;
    pager.querySelectorAll('.outline-service-preview-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0){outlineServicePreviewState.page=page;applyOutlineServicePreviewView()}}));
    document.getElementById('outlineServicePreviewPageSize')?.addEventListener('change',event=>{outlineServicePreviewState.pageSize=Number(event.target.value)||25;outlineServicePreviewState.page=1;localStorage.setItem('vm-doc:outline-service-preview-page-size',String(outlineServicePreviewState.pageSize));applyOutlineServicePreviewView()});
  }
  const exportLink=document.getElementById('outlineServicePreviewExport');
  if(exportLink&&outlineServicePreviewState.jobID){
    const params=new URLSearchParams();if(filter!=='all')params.set('filter',filter);
    exportLink.href=`/api/v1/documents/outline/jobs/${encodeURIComponent(outlineServicePreviewState.jobID)}/services-export${params.toString()?`?${params}`:''}`;
  }
}
function bindOutlineServicePublishPreview(data,jobID=''){
  outlineServicePreviewState.data=data||{};
  outlineServicePreviewState.jobID=jobID||'';
  outlineServicePreviewState.page=1;
  document.querySelectorAll('.outline-preview-stat-card').forEach(card=>card.addEventListener('click',()=>{outlineServicePreviewState.filter=card.dataset.filter||'all';outlineServicePreviewState.page=1;applyOutlineServicePreviewView()}));
  applyOutlineServicePreviewView();
  const eligibleIDs=Array.isArray(data?.eligible_ids)?data.eligible_ids.map(Number).filter(Boolean):[];
  document.getElementById('publishServicesOutline')?.addEventListener('click',async event=>{
    if(!eligibleIDs.length)return;
    if(!window.confirm(`Publici ${eligibleIDs.length} servicii PROD eligibile în paginile Outline verificate?`))return;
    const button=event.currentTarget,progress=document.getElementById('outlineServiceBulkProgress');button.disabled=true;button.textContent='Se pornește publicarea…';
    try{const job=await api('/api/v1/documents/outline/publish-services',{method:'POST',body:JSON.stringify({service_ids:eligibleIDs})});pollOutlineJob(job.id,'service',button,progress)}
    catch(err){button.disabled=false;button.textContent=`Publică cele ${eligibleIDs.length} servicii PROD eligibile`;toast(err.message,true)}
  });
}
function pollSingleVMOutlineJob(jobID,button,progress){
  const poll=async()=>{
    const state=await api(`/api/v1/documents/outline/jobs/${jobID}`);
    if(progress)progress.textContent=`${state.status} · VM ${state.processed_vms||0}/${state.total_vms||1}${state.last_object?` · ${state.last_object}`:''}`;
    if(state.status==='success'){
      button.disabled=false;button.textContent='Trimite în Outline';
      if(progress)progress.textContent=state.published_vms?`Publicare finalizată · ${state.result_created?'pagină creată':'pagină actualizată'}`:'VM sărită';
      if(state.published_vms){toast(state.result_created?'Fișa VM a fost creată în Outline / Virtualizare.':'Fișa VM a fost actualizată în Outline / Virtualizare.');if(state.result_url){const link=document.createElement('a');link.href=state.result_url;link.target='_blank';link.rel='noopener';link.click()}}else toast('VM-ul nu a fost publicat în Outline.',true);
      return;
    }
    if(state.status==='failed'||state.status==='partial'){
      const message=(state.errors||[]).join(' · ')||'Publicarea VM în Outline a eșuat.';
      button.disabled=false;button.textContent='Trimite în Outline';if(progress)progress.textContent='Publicarea a eșuat.';toast(message,true);return;
    }
    setTimeout(()=>poll().catch(err=>{button.disabled=false;button.textContent='Trimite în Outline';if(progress)progress.textContent='';toast(err.message,true)}),1000);
  };
  poll().catch(err=>{button.disabled=false;button.textContent='Trimite în Outline';if(progress)progress.textContent='';toast(err.message,true)});
}
function pollOutlineServicePreviewJob(jobID,button,area,progress){
  const poll=async()=>{
    const state=await api(`/api/v1/documents/outline/jobs/${jobID}`);
    const total=Number(state.total_services||0),processed=Number(state.processed_services||0);
    if(progress)progress.textContent=`Verificare ${state.status} · servicii ${processed}/${total}${state.last_object?` · ${state.last_object}`:''}`;
    if(state.status==='success'){
      const preview=state.preview||{};
      outlineServicePreviewState.filter='all';
      if(area)area.innerHTML=outlineServicePreviewHTML(preview,jobID);
      bindOutlineServicePublishPreview(preview,jobID);
      button.disabled=false;
      button.textContent='Verifică din nou';
      if(progress)progress.textContent=`Verificare finalizată · ${preview.eligible||0} eligibile din ${preview.total||0}`;
      toast(`${preview.eligible||0} servicii PROD eligibile din ${preview.total||0}.`);
      return;
    }
    if(state.status==='failed'){
      const message=(state.errors||[]).join(' · ')||'Verificarea serviciilor a eșuat.';
      if(area)area.innerHTML=empty(message);
      if(progress)progress.textContent='Verificarea a eșuat.';
      button.disabled=false;
      button.textContent='Verifică din nou';
      toast(message,true);
      return;
    }
    setTimeout(()=>poll().catch(err=>{
      button.disabled=false;
      button.textContent='Verifică din nou';
      if(area)area.innerHTML=empty(err.message);
      if(progress)progress.textContent='';
      toast(err.message,true);
    }),1000);
  };
  poll().catch(err=>{
    button.disabled=false;
    button.textContent='Verifică din nou';
    if(area)area.innerHTML=empty(err.message);
    if(progress)progress.textContent='';
    toast(err.message,true);
  });
}
function outlineSkippedVMsHTML(rows=[]){
  if(!rows.length)return '';
  return `<div class="outline-service-preview"><h4>VM-uri sărite (${rows.length})</h4><div class="table-wrap"><table><thead><tr><th>VM</th><th>Mediu</th><th>Motiv</th></tr></thead><tbody>${rows.map(row=>`<tr><td><a href="#vms/${row.id}/overview"><strong>${e(row.name||`VM ${row.id}`)}</strong></a></td><td>${row.environment?environmentBadge(row.environment):'<span class="muted">Nespecificat</span>'}</td><td>${e(row.reason||'—')}</td></tr>`).join('')}</tbody></table></div></div>`;
}
function pollOutlineJob(jobID,kind,button,progress){
  const idleLabel=kind==='service'?'Publică serviciile eligibile':'Publică VM-urile';
  const poll=async()=>{const state=await api(`/api/v1/documents/outline/jobs/${jobID}`);if(kind==='vm'){const skipped=document.getElementById('outlineBulkSkipped');if(skipped)skipped.innerHTML=outlineSkippedVMsHTML(state.skipped_vm_details||[])}if(progress){progress.textContent=kind==='service'?`${state.status} · servicii ${state.processed_services||0}/${state.total_services||0} · publicate ${state.published_services||0} · sărite ${state.skipped_services||0}${state.last_object?` · ${state.last_object}`:''}`:`${state.status} · VM ${state.processed_vms||0}/${state.total_vms||0} · publicate ${state.published_vms||0} · sărite ${state.skipped_vms||0}${state.last_object?` · ${state.last_object}`:''}`;}if(['success','partial','failed'].includes(state.status)){const errors=state.errors?.length||0;const message=kind==='service'?`Outline servicii: ${state.published_services||0} actualizate, ${state.skipped_services||0} sărite${errors?`, ${errors} erori`:''}.`:`Outline VM: ${state.published_vms||0} publicate, ${state.skipped_vms||0} sărite${errors?`, ${errors} erori`:''}.`;if(kind==='service'){button.disabled=true;button.textContent='Verifică din nou înainte de republicare'}else{button.disabled=false;button.textContent=idleLabel}toast(message,state.status==='failed');return}setTimeout(()=>poll().catch(err=>{button.disabled=false;button.textContent=idleLabel;toast(err.message,true)}),1200)};
  poll().catch(err=>{button.disabled=false;button.textContent=idleLabel;toast(err.message,true)});
}
function pollSoftwareComponentOutlineJob(jobID,button,progress,label='componentele'){
  const poll=async()=>{
    const state=await api(`/api/v1/documents/outline/jobs/${jobID}`),total=Number(state.total_components||0),processed=Number(state.processed_components||0),published=Number(state.published_components||0);
    if(progress)progress.textContent=`${state.status} · componente ${processed}/${total} · publicate ${published}${state.last_object?` · ${state.last_object}`:''}`;
    if(['success','partial','failed'].includes(state.status)){
      const errors=state.errors?.length||0;
      button.disabled=false;button.textContent=button.dataset.idleLabel||'Publică PROD în Outline';
      if(progress)progress.textContent=`Publicare finalizată · ${published}/${total} componente${errors?` · ${errors} erori`:''}`;
      toast(`Outline ${label}: ${published}/${total} pagini publicate${errors?`, ${errors} erori`:''}.`,state.status==='failed');
      if(total===1&&published===1&&state.result_url){const link=document.createElement('a');link.href=state.result_url;link.target='_blank';link.rel='noopener';link.click()}
      return;
    }
    setTimeout(()=>poll().catch(err=>{button.disabled=false;button.textContent=button.dataset.idleLabel||'Publică PROD în Outline';if(progress)progress.textContent='';toast(err.message,true)}),1200);
  };
  poll().catch(err=>{button.disabled=false;button.textContent=button.dataset.idleLabel||'Publică PROD în Outline';if(progress)progress.textContent='';toast(err.message,true)});
}
function bindOutlineIntegrationActions(){
  document.getElementById('outlineEnabled')?.addEventListener('change',event=>{const test=document.getElementById('testOutlineConnection');if(test)test.disabled=!event.target.checked});
  document.getElementById('outlineSettingsForm')?.addEventListener('submit',async event=>{event.preventDefault();const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent='Se salvează…';const parent=document.getElementById('outlineVirtualizationParentID')?.value?.trim()||'';const body={enabled:!!document.getElementById('outlineEnabled')?.checked,base_url:document.getElementById('outlineBaseURL')?.value?.trim()||'',collection_id:document.getElementById('outlineCollectionID')?.value?.trim()||'-',virtualization_parent_document_id:parent||'-',api_key:document.getElementById('outlineAPIKey')?.value?.trim()||'',verify_tls:!!document.getElementById('outlineVerifyTLS')?.checked,allow_http:!!document.getElementById('outlineAllowHTTP')?.checked,request_timeout_seconds:Number(document.getElementById('outlineTimeout')?.value||30)};try{await api('/api/v1/outline/settings',{method:'PUT',body:JSON.stringify(body)});toast('Setările Outline au fost salvate.');documentsPage('outline-config')}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Salvează Outline'}});
  document.getElementById('testOutlineConnection')?.addEventListener('click',async event=>{const button=event.currentTarget;if(!document.getElementById('outlineEnabled')?.checked){toast('Activează integrarea Outline și salvează setările înainte de test.',true);return}button.disabled=true;button.textContent='Se testează…';try{const result=await api('/api/v1/outline/test',{method:'POST',body:'{}'});toast(`Outline OK · Virtualizare: ${result.parent_document_title||result.parent_document_id||'document valid'}`)}catch(err){toast(err.message,true)}finally{button.disabled=false;button.textContent='Testează conexiunea'}});
  document.getElementById('outlineVMInventoryTargetForm')?.addEventListener('submit',async event=>{event.preventDefault();const button=event.currentTarget.querySelector('button[type="submit"]');button.disabled=true;button.textContent='Se salvează…';const body={name:'Inventar VM',document_reference:document.getElementById('outlineVMInventoryTargetReference')?.value?.trim()||'',active:!!document.getElementById('outlineVMInventoryTargetActive')?.checked};try{await api('/api/v1/outline/publication-targets/vm_inventory',{method:'PUT',body:JSON.stringify(body)});toast('Destinația Outline pentru Inventar VM a fost salvată.');documentsPage('outline-config')}catch(err){toast(err.message,true)}finally{button.disabled=false;button.textContent='Salvează destinația'}});
  document.getElementById('outlineSupportComponentsTargetForm')?.addEventListener('submit',async event=>{event.preventDefault();const button=event.currentTarget.querySelector('button[type="submit"]');button.disabled=true;button.textContent='Se salvează…';const body={name:'Componente suport',document_reference:document.getElementById('outlineSupportComponentsTargetReference')?.value?.trim()||'',active:!!document.getElementById('outlineSupportComponentsTargetActive')?.checked};try{await api('/api/v1/outline/publication-targets/support_components',{method:'PUT',body:JSON.stringify(body)});toast('Părintele Outline pentru Componente suport a fost salvat.');documentsPage('outline-config')}catch(err){toast(err.message,true)}finally{button.disabled=false;button.textContent='Salvează destinația'}});
  document.getElementById('publishAllOutline')?.addEventListener('click',async event=>{const button=event.currentTarget,progress=document.getElementById('outlineBulkProgress'),skipped=document.getElementById('outlineBulkSkipped');button.disabled=true;button.textContent='Se pornește…';if(skipped)skipped.innerHTML='';try{const job=await api('/api/v1/documents/outline/publish-all',{method:'POST',body:JSON.stringify({powered_on_only:!!document.getElementById('outlineBulkPoweredOn')?.checked})});pollOutlineJob(job.id,'vm',button,progress)}catch(err){button.disabled=false;button.textContent='Publică VM-urile';toast(err.message,true)}});
  document.getElementById('previewServicesOutline')?.addEventListener('click',async event=>{const button=event.currentTarget,area=document.getElementById('outlineServicePreview'),progress=document.getElementById('outlineServiceBulkProgress');button.disabled=true;button.textContent='Se pornește verificarea…';if(area)area.innerHTML='<div class="loading">Pregătesc verificarea serviciilor…</div>';if(progress)progress.textContent='';try{const job=await api('/api/v1/documents/outline/services-preview',{method:'POST',body:'{}'});pollOutlineServicePreviewJob(job.id,button,area,progress)}catch(err){button.disabled=false;button.textContent='Verifică serviciile';if(area)area.innerHTML=empty(err.message);changeSearchResultFeedback(0,err.message);toast(err.message,true)}});
}
function documentsSectionNavigation(selected){
  const items=[['export','Export / Publică','Arhive DOCX și publicare Outline'],['outline-config','Configurare Outline','Conexiune și destinații de publicare'],['templates','Șabloane','Șabloane DOCX și placeholdere']];
  return `<nav class="vm-section-tabs documents-section-tabs" aria-label="Secțiuni documente">${items.map(([code,label,help])=>`<a href="#documents/${code}" class="${selected===code?'active':''}"><span>${e(label)}</span><small>${e(help)}</small></a>`).join('')}</nav>`;
}
async function documentsPage(section='export'){
  section=['templates','outline-config'].includes(section)?section:'export';
  if((location.hash||'')==='#documents')history.replaceState(null,'','#documents/export');
  pageMeta('Documente',section==='templates'?'Șabloane DOCX pentru fișele VM și serviciile interne':section==='outline-config'?'Configurarea integrării și destinațiilor Outline':'Export în masă și publicare în Outline');
  const nav=documentsSectionNavigation(section);
  if(section==='export'){
    const outlineSettings=await api('/api/v1/outline/settings').catch(()=>({enabled:false}));
    content.innerHTML=`${nav}${panel('Export în masă',bulkDocumentExportPanel(),'<span class="muted">DOCX cu opțiuni de generare</span>')}${panel('Publică în Outline',outlineIntegrationPanel(outlineSettings,[],'publish'),'<a class="button-link small secondary" href="#documents/outline-config">Configurare Outline</a>')}`;
    bindBulkDocumentExportActions();bindOutlineIntegrationActions();return;
  }
  if(section==='outline-config'){
    const [outlineSettings,outlineTargets]=await Promise.all([api('/api/v1/outline/settings').catch(()=>({enabled:false})),api('/api/v1/outline/publication-targets').catch(()=>[])]);
    content.innerHTML=`${nav}${panel('Configurare Outline',outlineIntegrationPanel(outlineSettings,outlineTargets,'config'),'<span class="muted">Conexiune, Virtualizare și destinații reutilizabile pentru rapoarte</span>')}`;
    bindOutlineIntegrationActions();return;
  }
  const templates=await api(`/api/v1/document-templates${can('documents.manage')?'?include_inactive=true':''}`);state.documentTemplates=templates;
  const active=state.documentTemplates.filter(item=>item.active).length,vmDefault=state.documentTemplates.find(item=>item.object_type==='vm'&&item.is_default),serviceDefault=state.documentTemplates.find(item=>item.object_type==='service'&&item.is_default);
  content.innerHTML=`${nav}<div class="cards"><div class="card"><div class="label">Șabloane</div><div class="value">${state.documentTemplates.length}</div></div><div class="card"><div class="label">Șabloane active</div><div class="value">${active}</div></div><div class="card"><div class="label">Implicit VM</div><div class="value compact">${e(vmDefault?.name||'—')}</div></div><div class="card"><div class="label">Implicit serviciu</div><div class="value compact">${e(serviceDefault?.name||'—')}</div></div></div>${panel('Șabloane DOCX',documentTemplateRows(state.documentTemplates),can('documents.manage')?'<button id="newDocumentTemplate">Încarcă șablon</button>':'')}${panel('Placeholdere acceptate',`<div class="document-placeholders"><code>{{VM_DOCUMENT_BODY}}</code><span>corp obligatoriu pentru fișa VM</span><code>{{SERVICE_DOCUMENT_BODY}}</code><span>corp obligatoriu pentru fișa tehnică și operațională a serviciului</span><code>{{document.number}}</code><span>numărul fișei</span><code>{{document.generated_at}}</code><span>data referință</span><code>{{document.generated_by}}</code><span>utilizatorul care generează</span><code>{{vm.name}}</code><span>numele VM-ului</span><code>{{vm.hostname}}</code><span>hostname</span><code>{{vm.ip}}</code><span>IP principal</span><code>{{vm.os}}</code><span>sistemul de operare</span><code>{{vm.environment}}</code><span>mediul</span><code>{{vm.status}}</code><span>status operațional</span><code>{{vm.classification}}</code><span>clasificarea</span><code>{{vm.purpose}}</code><span>scopul VM-ului</span><code>{{service.name}}</code><span>numele serviciului intern</span><code>{{service.code}}</code><span>codul serviciului</span><code>{{service.criticality}}</code><span>criticitatea serviciului</span><code>{{service.status}}</code><span>statusul documentației</span><code>{{service.retired}}</code><span>Da/Nu pentru serviciu retras</span><code>{{service.retirement_reason}}</code><span>motivul retragerii</span><code>{{service.retired_at}}</code><span>data retragerii</span><code>{{service.description}}</code><span>descrierea serviciului</span><code>{{service.purpose}}</code><span>Scop și domeniu (compatibilitate)</span><code>{{service.scope_domain}}</code><span>Scop și domeniu</span><code>{{service.objectives}}</code><span>Obiectivele serviciului</span></div>`)}`;
  document.getElementById('newDocumentTemplate')?.addEventListener('click',()=>openDocumentTemplate());
  content.querySelectorAll('.edit-document-template').forEach(button=>button.addEventListener('click',()=>openDocumentTemplate(state.documentTemplates.find(item=>item.id===Number(button.dataset.id)))));
}
document.getElementById('documentTemplateObjectType')?.addEventListener('change',updateDocumentTemplateHelp);
documentTemplateForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('documents.manage'))return;
  const id=Number(document.getElementById('documentTemplateId').value||0);
  const name=document.getElementById('documentTemplateName').value.trim();
  const code=document.getElementById('documentTemplateCode').value.trim();
  const objectType=document.getElementById('documentTemplateObjectType').value;
  const description=document.getElementById('documentTemplateDescription').value.trim();
  const active=document.getElementById('documentTemplateActive').checked;
  const isDefault=document.getElementById('documentTemplateDefault').checked;
  try{
    if(id){await api(`/api/v1/document-templates/${id}`,{method:'PATCH',body:JSON.stringify({name,code,description,active,is_default:isDefault})})}
    else{const file=document.getElementById('documentTemplateFile').files[0];if(!file){toast('Alege fișierul DOCX.',true);return}const body=new FormData();body.set('name',name);body.set('code',code);body.set('object_type',objectType);body.set('description',description);body.set('active',String(active));body.set('is_default',String(isDefault));body.set('file',file);await api('/api/v1/document-templates',{method:'POST',body})}
    documentTemplateDialog.close();toast(id?'Șablon actualizat.':'Șablon încărcat.');documentsPage('templates');
  }catch(err){toast(err.message,true)}
});

const reportPalette=['var(--accent)','var(--ok)','var(--warn)','var(--bad)','#8b5cf6','#06b6d4','var(--muted)','var(--text)'];
function reportSeriesPoints(points){return (points||[]).filter(item=>Number(item.value||0)>0)}
function reportDonut(title,points){const data=reportSeriesPoints(points);const total=data.reduce((s,p)=>s+Number(p.value||0),0);if(!total)return `<article class="report-chart">${empty('Fără date pentru '+title)}</article>`;let cursor=0;const stops=data.map((p,i)=>{const start=cursor;cursor+=Number(p.value)/total*100;return `${reportPalette[i%reportPalette.length]} ${start.toFixed(2)}% ${cursor.toFixed(2)}%`}).join(',');return `<article class="report-chart"><header><h3>${e(title)}</h3><strong>${total.toLocaleString('ro-RO')}</strong></header><div class="report-donut-wrap"><div class="report-donut" style="background:conic-gradient(${stops})"><span>${total.toLocaleString('ro-RO')}</span></div><div class="report-legend">${data.map((p,i)=>`<div><i style="background:${reportPalette[i%reportPalette.length]}"></i><span>${e(p.label)}</span><strong>${Number(p.value).toLocaleString('ro-RO')}</strong></div>`).join('')}</div></div></article>`}
function reportBars(title,points,limit=15){const data=reportSeriesPoints(points).slice(0,limit),max=Math.max(1,...data.map(p=>Number(p.value)));return `<article class="report-chart report-bar-chart"><header><h3>${e(title)}</h3></header>${data.length?`<div class="report-bars">${data.map(p=>`<div class="report-bar-row"><span title="${e(p.label)}">${e(p.label)}</span><div><i style="width:${Math.max(2,Number(p.value)/max*100)}%"></i></div><strong>${Number(p.value).toLocaleString('ro-RO')}</strong></div>`).join('')}</div>`:empty('Fără date.')}</article>`}
function reportTimeline(title,points){const data=points||[],max=Math.max(1,...data.map(p=>Number(p.vm||0)+Number(p.service||0)));return `<article class="report-chart report-timeline"><header><h3>${e(title)}</h3><span>ultimele 30 zile</span></header>${data.length?`<div class="timeline-bars">${data.map(p=>{const vm=Number(p.vm||0),sv=Number(p.service||0);return `<div class="timeline-day" title="${e(p.date)} · VM ${vm} · Servicii ${sv}"><div><i class="timeline-vm" style="height:${vm/max*100}%"></i><i class="timeline-service" style="height:${sv/max*100}%"></i></div><span>${e(p.date.slice(5))}</span></div>`}).join('')}</div><div class="timeline-legend"><span><i class="timeline-vm"></i> Fișe VM</span><span><i class="timeline-service"></i> Fișe servicii</span></div>`:empty('Nu au fost generate documente în ultimele 30 de zile.')}</article>`}
function reportSummaryCard(label,value,kind=''){return `<div class="card report-summary-card ${e(kind)}"><div class="label">${e(label)}</div><div class="value">${Number(value||0).toLocaleString('ro-RO')}</div></div>`}
function reportFilterCard(label,value,field,filterValue='',kind=''){return `<div class="card report-summary-card report-filter-card ${e(kind)}" role="button" tabindex="0" data-filter-field="${e(field)}" data-filter-value="${e(filterValue)}"><div class="label">${e(label)}</div><div class="value">${Number(value||0).toLocaleString('ro-RO')}</div></div>`}
function reportPowerFilterValue(value){const v=String(value||'').toLowerCase();if(['poweredon','on','running','powered_on'].includes(v))return 'on';if(['poweredoff','off','stopped','powered_off'].includes(v))return 'off';return 'other'}
function reportServiceIssues(rows){if(!rows?.length)return empty('Nu sunt identificate probleme de documentare la servicii.');return `<div class="table-wrap"><table><thead><tr><th>Serviciu</th><th>Criticitate</th><th>Status documentație</th><th>VM-uri</th><th>De completat</th></tr></thead><tbody>${rows.map(r=>`<tr><td><a href="#services/${r.id}"><strong>${e(r.name)}</strong></a></td><td>${criticalityBadge(r.criticality)}</td><td>${badge(r.documentation_status)}</td><td>${r.vm_count}</td><td class="warning-text">${e(r.issue)}</td></tr>`).join('')}</tbody></table></div>`}
function reportVMIssues(rows){if(!rows?.length)return empty('Nu sunt identificate probleme de documentare la VM-uri.');return `<div class="table-wrap"><table><thead><tr><th>VM</th><th>Mediu</th><th>Power</th><th>De completat</th></tr></thead><tbody>${rows.map(r=>`<tr><td><a href="#vms/${r.id}"><strong>${e(r.name)}</strong></a><div class="muted mono">${e(r.hostname||'—')}</div></td><td>${environmentBadge(r.environment)}</td><td>${badge(r.power_state||'unknown')}</td><td class="warning-text">${e(r.issue)}</td></tr>`).join('')}</tbody></table></div>`}
function supportComponentReportGroups(rows){
  if(!rows?.length)return empty('Nu există componente suport marcate pe VM-uri.');
  const componentGroups=new Map();
  for(const row of rows){
    const component=String(row.component_name||'Nespecificat'),version=String(row.version||'Nedetectată'),environment=String(row.environment||'Nespecificat');
    if(!componentGroups.has(component))componentGroups.set(component,new Map());const versions=componentGroups.get(component);
    if(!versions.has(version))versions.set(version,new Map());const environments=versions.get(version);
    if(!environments.has(environment))environments.set(environment,[]);environments.get(environment).push(row);
  }
  return `<div class="support-report-groups">${[...componentGroups.entries()].map(([component,versions])=>`<section class="support-component-group" data-component="${e(component.toLowerCase())}"><header><div><span class="assignment-kicker">Componentă suport</span><h3>${e(component)}</h3></div><strong>${[...versions.values()].reduce((n,m)=>n+[...m.values()].reduce((x,a)=>x+a.length,0),0)} instalări</strong></header>${[...versions.entries()].map(([version,environments])=>`<div class="support-version-group" data-version="${e(version.toLowerCase())}"><h4>Versiune ${e(version)}</h4>${[...environments.entries()].map(([environment,items])=>`<div class="support-environment-group" data-environment="${e(environment.toLowerCase())}"><div class="support-environment-heading">${environment==='Nespecificat'?'<span class="badge">Mediu nespecificat</span>':environmentBadge(environment)}<span>${items.length} ${items.length===1?'instalare':'instalări'}</span></div><div class="table-wrap"><table class="compact-table"><thead><tr><th>Amplasare / VM</th><th>IP</th><th>Port(uri)</th><th>Servicii / proiecte</th><th>Serviciu agent</th><th>Stare</th></tr></thead><tbody>${items.map(row=>`<tr class="support-report-row" data-search="${e([row.component_name,row.version,row.environment,row.vm_name,row.hostname,row.ip,row.ports,row.services,row.agent_service,row.software_name].join(' ').toLowerCase())}" data-component="${e(String(row.component_name||'').toLowerCase())}" data-version="${e(String(row.version||'').toLowerCase())}" data-environment="${e(String(row.environment||'').toLowerCase())}"><td><a href="#vms/${row.vm_id}/inventory"><strong>${e(row.vm_name)}</strong></a><div class="muted mono">${e(row.hostname||'—')}</div></td><td class="mono">${e(row.ip||'—')}</td><td class="mono">${e(row.ports||'—')}</td><td>${e(row.services||'—')}</td><td><strong>${e(row.agent_service||'—')}</strong>${row.software_name?`<div class="muted">${e(row.software_name)}</div>`:''}</td><td>${row.detected?badge('active'):'<span class="badge missing">Nedetectat</span>'}</td></tr>`).join('')}</tbody></table></div></div>`).join('')}</div>`).join('')}</section>`).join('')}</div>`;
}
function supportComponentReportBody(data){
  const rows=Array.isArray(data.support_components)?data.support_components:[],s=data.summary||{};
  const components=[...new Set(rows.map(r=>r.component_name).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
  const versions=[...new Set(rows.map(r=>r.version).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro',{numeric:true}));
  const environments=[...new Set(rows.map(r=>r.environment).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
  const filters=`<div class="filterbar report-table-filters support-report-filters"><label>Căutare<input id="supportReportSearch" type="search" placeholder="PostgreSQL, serviciu, VM, IP…"></label><label>Componentă<select id="supportReportComponent"><option value="">Toate</option>${components.map(v=>`<option value="${e(v.toLowerCase())}">${e(v)}</option>`).join('')}</select></label><label>Versiune<select id="supportReportVersion"><option value="">Toate</option>${versions.map(v=>`<option value="${e(v.toLowerCase())}">${e(v)}</option>`).join('')}</select></label><label>Mediu<select id="supportReportEnvironment"><option value="">Toate</option>${environments.map(v=>`<option value="${e(v.toLowerCase())}">${e(environmentDisplay(v))}</option>`).join('')}</select></label></div>`;
  const actions=`<div class="section-actions"><span id="supportReportCount" class="muted"></span><a id="supportReportExport" class="button-link small secondary" href="/api/v1/reports/support-components/export">Export Excel</a></div>`;
  return `<div class="cards report-summary">${reportSummaryCard('Componente',s.components)}${reportSummaryCard('Versiuni',s.versions)}${reportSummaryCard('Instalări',s.installations)}${reportSummaryCard('VM-uri',s.vms)}</div>${panel('Componente suport',`${filters}${actions}${supportComponentReportGroups(rows)}`,'<span class="muted">Grupare: Componentă → Versiune → Mediu. IP-ul folosește IP-ul preferat al VM-ului, apoi inventarul agentului/vCenter.</span>')}`;
}

function softwareComponentStatusBadge(status){
  const value=String(status||'').toLowerCase();
  if(['active','running','up','started','online'].some(token=>value.includes(token)))return '<span class="badge active">Activ</span>';
  if(['inactive','stopped','down','failed','dead','disabled'].some(token=>value.includes(token)))return `<span class="badge missing">${e(status||'Inactiv')}</span>`;
  return status?`<span class="badge">${e(status)}</span>`:'—';
}
function softwareComponentPowerBadge(value){
  const state=reportPowerFilterValue(value);
  if(state==='on')return '<span class="badge active">ON</span>';
  if(state==='off')return '<span class="badge missing">OFF</span>';
  return `<span class="badge">${e(String(value||'—').toUpperCase())}</span>`;
}
function softwareComponentVMLink(row){
  const label=`<strong>${e(row.vm_name)}</strong>`;
  const link=row.vm_outline_url?`<a href="${e(row.vm_outline_url)}" target="_blank" rel="noopener" title="Deschide fișa VM în Outline">${label}</a>`:`<a href="#vms/${row.vm_id}/inventory">${label}</a>`;
  return `${link}<div class="muted mono">${e(row.hostname||'—')}</div>`;
}
function softwareComponentServiceLinks(row){
  const links=Array.isArray(row.service_links)?row.service_links:[];
  if(links.length)return links.map(item=>item.url?`<a href="${e(item.url)}" target="_blank" rel="noopener">${e(item.name)}</a>`:e(item.name)).join('<br>');
  return e(row.services||'—');
}
function softwareComponentReportBody(data){
  const rows=Array.isArray(data.rows)?data.rows:[],s=data.summary||{},componentCounts=Array.isArray(data.components)?data.components:[],outline=data.outline||{},outlineTarget=outline.target||{};
  const components=[...new Map(rows.map(r=>[r.component_key,{key:r.component_key,name:r.component_name}])).values()].sort((a,b)=>a.name.localeCompare(b.name,'ro'));
  const categories=[...new Set(rows.map(r=>r.category).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
  const versions=[...new Set(rows.flatMap(r=>Array.isArray(r.versions)?r.versions:[]).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro',{numeric:true}));
  const environments=[...new Set(rows.map(r=>r.environment).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
  const filters=`<div class="filterbar report-table-filters software-component-filters"><label><span>Căutare</span><input id="softwareComponentSearch" type="search" placeholder="PostgreSQL, Mongo, Java 8, VM, IP…"></label><label><span>Componentă</span><select id="softwareComponentName"><option value="">Toate</option>${components.map(v=>`<option value="${e(v.key)}">${e(v.name)}</option>`).join('')}</select></label><label><span>Categorie</span><select id="softwareComponentCategory"><option value="">Toate</option>${categories.map(v=>`<option value="${e(v.toLowerCase())}">${e(v)}</option>`).join('')}</select></label><label><span>Versiune</span><select id="softwareComponentVersion"><option value="">Toate</option>${versions.map(v=>`<option value="${e(v.toLowerCase())}">${e(v)}</option>`).join('')}</select></label><label><span>Mediu</span><select id="softwareComponentEnvironment"><option value="">Toate</option>${environments.map(v=>`<option value="${e(v.toLowerCase())}">${e(environmentDisplay(v))}</option>`).join('')}</select></label><div class="filter-actions"><button type="button" id="softwareComponentApply">Caută / Aplică</button><button type="button" id="softwareComponentReset" class="secondary">Resetează</button></div></div>`;
  const componentCards=componentCounts.length?`<div id="softwareComponentCards" class="cards report-summary software-component-cards">${componentCounts.map(item=>reportFilterCard(item.name,item.vms,'component',item.key)).join('')}</div>`:'';
  const table=rows.length?`<div id="softwareComponentTableWrap" class="table-wrap"><table><thead><tr><th>Componentă</th><th>Versiune</th><th>VM</th><th>Power</th><th>Mediu</th><th>IP</th><th>Servicii / proiecte</th><th>Detectat din</th><th>Dovadă / stare</th></tr></thead><tbody>${rows.map(row=>`<tr class="software-component-row" data-search="${e([row.component_name,row.category,row.version,row.environment,row.vm_name,row.hostname,row.ip,row.power_state,row.status,row.source,(row.evidence||[]).join(' '),row.services].join(' ').toLowerCase())}" data-component="${e(String(row.component_key||'').toLowerCase())}" data-category="${e(String(row.category||'').toLowerCase())}" data-versions="${e((row.versions||[]).map(v=>String(v).toLowerCase()).join('|'))}" data-environment="${e(String(row.environment||'').toLowerCase())}"><td><strong>${e(row.component_name)}</strong><div class="muted">${e(row.category||'—')}</div></td><td class="mono">${e(row.version||'—')}</td><td>${softwareComponentVMLink(row)}</td><td>${softwareComponentPowerBadge(row.power_state)}</td><td>${row.environment?environmentBadge(row.environment):'—'}</td><td class="mono">${e(row.ip||'—')}</td><td>${softwareComponentServiceLinks(row)}</td><td>${(row.sources||[]).map(value=>`<span class="badge">${e(value)}</span>`).join(' ')||'—'}</td><td>${softwareComponentStatusBadge(row.status)}${row.evidence?.length?`<div class="muted software-component-evidence">${e(row.evidence.join(' · '))}</div>`:''}</td></tr>`).join('')}</tbody></table></div><div id="softwareComponentEmpty" hidden>${empty('Nu există componente pentru filtrele selectate.')}</div><div id="softwareComponentPagination" class="pagination"></div>`:empty('Nu există componente software detectate automat.');
  const outlineReady=outline.enabled===true&&outlineTarget.active!==false&&String(outlineTarget.document_reference||'').trim()!=='';
  const publishAction=can('documents.manage')?(outlineReady?`<button id="softwareComponentPublishOutline" type="button" class="small">Publică PROD în Outline</button>`:`<a class="button-link small secondary" href="#documents/outline-config">Configurează Outline / Componente suport</a>`):'';
  const actions=`<div class="section-actions"><span id="softwareComponentCount" class="muted"></span><div class="actions"><a id="softwareComponentExport" class="button-link small secondary" href="/api/v1/reports/software-components/export">Export Excel</a>${publishAction}</div></div>${outlineReady?`<div id="softwareComponentOutlineProgress" class="muted"></div>`:''}`;
  const summary=`<div class="cards report-summary">${reportSummaryCard('Componente',s.components)}${reportSummaryCard('Versiuni',s.versions)}${reportSummaryCard('VM–componentă',s.installations)}${reportSummaryCard('VM-uri',s.vms)}</div>`;
  return `${summary}${panel('Filtre',filters,'<span class="muted">Inventarul este automat: colectoarele DB/Web/Docker au prioritate, apoi imaginile containerelor, serviciile agentului și software-ul instalat.</span>')}${componentCards?panel('Componente detectate',componentCards,'<span class="muted">Cardurile sunt clicabile și filtrează direct lista de VM-uri pentru componenta aleasă.</span>'):''}${panel('Inventar componente software',`${actions}${table}`,'<span class="muted">Un rând reprezintă o componentă detectată pe o VM. VM-urile și serviciile folosesc linkurile Outline când acestea există. Publicarea Outline include exclusiv asocierile de pe VM-uri PROD și creează pagini cu prefix <code>comp-</code>; cardurile, filtrele și exportul Excel rămân inventarul complet.</span>')}`;
}

function osSupportStatusLabel(status){return status==='unsupported'?'Nesuportat':status==='supported'?'Suportat':'Nedeterminat'}
function osSupportStatusBadge(status){return status==='unsupported'?'<span class="badge missing">Nesuportat</span>':status==='supported'?'<span class="badge active">Suportat</span>':'<span class="badge">Nedeterminat</span>'}
function osSupportReportBody(data){
  const s=data.summary||{},rows=Array.isArray(data.rows)?data.rows:[];
  const environments=[...new Set(rows.map(r=>r.environment).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
  const filters=`<div class="filterbar report-table-filters os-support-filters"><label><span>Căutare</span><input id="osSupportSearch" type="search" placeholder="VM, hostname, OS, IP, serviciu…"></label><label><span>Stare suport</span><select id="osSupportStatus"><option value="">Toate</option><option value="supported">Suportat</option><option value="unsupported">Nesuportat</option><option value="undetermined">Nedeterminat</option></select></label><label><span>VM pornit/oprit</span><select id="osSupportPower"><option value="">Toate</option><option value="on" selected>Pornit</option><option value="off">Oprit</option><option value="other">Altă stare</option></select></label><label><span>Mediu</span><select id="osSupportEnvironment">${environmentFilterOptions('PROD')}</select></label><label><span>Outline</span><select id="osSupportOutline"><option value="">Toate</option><option value="yes">Se publică</option><option value="no">Nu se publică</option></select></label><div class="filter-actions"><button type="button" id="osSupportApply">Caută / Aplică</button><button type="button" id="osSupportReset" class="secondary">Resetează</button></div></div>`;
  const table=rows.length?`<div id="osSupportTableWrap" class="table-wrap"><table><thead><tr><th>VM</th><th>Power</th><th>Mediu</th><th>Stare suport</th><th>Sistem de operare</th><th>IP</th><th>Servicii</th><th>Regulă / observații</th><th>Outline</th></tr></thead><tbody>${rows.map(row=>`<tr class="os-support-row" data-search="${e([row.vm_name,row.hostname,row.environment,row.ip,row.os_name,row.os_version,row.services,row.matched_rule,row.matched_rule_note].join(' ').toLowerCase())}" data-status="${e(row.status||'')}" data-power="${e(reportPowerFilterValue(row.power_state))}" data-environment="${e(environmentReportKey(row.environment))}" data-environment-label="${e(row.environment||'Nespecificat')}" data-outline="${row.outline_publish?'yes':'no'}" data-os-label="${e([row.os_name,row.os_version].filter(Boolean).join(' ')||'Nespecificat')}"><td><a href="#vms/${row.vm_id}/overview"><strong>${e(row.vm_name)}</strong></a><div class="muted mono">${e(row.hostname||'—')}</div></td><td>${badge(row.power_state||'unknown')}</td><td>${row.environment?environmentBadge(row.environment):'—'}</td><td>${osSupportStatusBadge(row.status)}</td><td><strong>${e(row.os_name||'—')}</strong><div class="muted">${e(row.os_version||'—')}</div></td><td class="mono">${e(row.ip||'—')}</td><td>${e(row.services||'—')}</td><td>${row.matched_rule?`<strong>${e(row.matched_rule)}</strong>${row.matched_rule_note?`<div class="muted">${e(row.matched_rule_note)}</div>`:''}`:'—'}</td><td>${row.outline_publish?'<span class="badge active">Se publică</span>':'<span class="badge missing">Nu se publică</span>'}</td></tr>`).join('')}</tbody></table></div><div id="osSupportEmpty" hidden>${empty('Nu există VM-uri pentru filtrele selectate.')}</div><div id="osSupportPagination" class="pagination"></div>`:empty('Nu există VM-uri active.');
  const cards=`<div id="osSupportCards" class="cards report-summary os-support-cards">${reportFilterCard('VM-uri',s.total,'status','')}${reportFilterCard('Suportate',s.supported,'status','supported')}${reportFilterCard('Nesuportate',s.unsupported,'status','unsupported','danger')}${reportFilterCard('Nedeterminat',s.undetermined,'status','undetermined','warning')}</div>`;
  const charts=`<details class="panel collapsible-panel os-support-charts-panel"><summary><span><strong>Grafice</strong><small>Închise implicit · valorile urmăresc căutarea și filtrele generale</small></span><span class="collapse-indicator">▾</span></summary><div class="collapsible-panel-body"><div id="osSupportCharts" class="report-grid">${reportDonut('Stare suport sisteme de operare',data.status_chart)}${reportDonut('VM nesuportate pe medii',data.unsupported_environment_chart)}${reportDonut('Sisteme de operare nesuportate',data.unsupported_os_chart)}</div></div></details>`;
  const actions=`<div class="section-actions os-support-actions"><span id="osSupportCount" class="muted"></span><a id="osSupportExport" class="button-link small secondary" href="/api/v1/reports/os-support/export">Export Excel</a><a class="button-link small secondary" href="#nomenclatures/unsupported_os">Nomenclator OS nesuportate</a></div>`;
  return `${panel('Filtre',filters,'<span class="muted">Căutarea și filtrele recalculează cardurile. Implicit sunt afișate VM-urile pornite din PROD.</span>')}<div class="os-support-filter-gap">${cards}</div>${charts}<div class="os-support-table-gap">${panel('VM-uri · suport sisteme de operare',`${actions}${table}`,'<span class="muted">Tabelul este paginat. Exportul Excel respectă filtrele selectate, independent de pagina curentă.</span>')}</div>`;
}

function outlineVMReportBody(data){
  const rows=Array.isArray(data.rows)?data.rows:[],yes=rows.filter(r=>r.publish).length,no=rows.length-yes,on=rows.filter(r=>reportPowerFilterValue(r.power_state)==='on').length,off=rows.filter(r=>reportPowerFilterValue(r.power_state)==='off').length;
  const environments=[...new Set(rows.map(r=>r.environment).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
  const reasons=[...new Map(rows.map(r=>[r.reason_code,r.reason])).entries()].filter(([k])=>k).sort((a,b)=>String(a[1]).localeCompare(String(b[1]),'ro'));
  const filters=`<div class="filterbar report-table-filters"><label><span>Căutare</span><input id="outlineVMSearch" type="search" placeholder="VM, hostname, motiv…"></label><label><span>Publicare Outline</span><select id="outlineVMPublish"><option value="">Toate</option><option value="yes">Se publică</option><option value="no">Nu se publică</option></select></label><label><span>VM pornit/oprit</span><select id="outlineVMPower"><option value="">Toate</option><option value="on" selected>Pornit</option><option value="off">Oprit</option><option value="other">Altă stare</option></select></label><label><span>Mediu</span><select id="outlineVMEnvironment">${environmentFilterOptions('PROD')}</select></label><label><span>Motiv</span><select id="outlineVMReason"><option value="">Toate</option>${reasons.map(([k,v])=>`<option value="${e(k)}">${e(v)}</option>`).join('')}</select></label><div class="filter-actions"><button type="button" id="outlineVMApply">Caută / Aplică</button><button type="button" id="outlineVMReset" class="secondary">Resetează</button></div></div>`;
  const table=rows.length?`<div class="table-wrap"><table><thead><tr><th>VM</th><th>Power</th><th>Mediu</th><th>Se publică</th><th>Motiv</th></tr></thead><tbody>${rows.map(row=>`<tr class="outline-vm-row" data-search="${e([row.name,row.hostname,row.environment,row.power_state,row.reason].join(' ').toLowerCase())}" data-publish="${row.publish?'yes':'no'}" data-power="${e(reportPowerFilterValue(row.power_state))}" data-environment="${e(environmentReportKey(row.environment))}" data-reason="${e(row.reason_code||'')}"><td><a href="#vms/${row.id}/overview"><strong>${e(row.name)}</strong></a><div class="muted mono">${e(row.hostname||'—')}</div></td><td>${badge(row.power_state||'unknown')}</td><td>${row.environment?environmentBadge(row.environment):'—'}</td><td>${row.publish?'<span class="badge active">Da</span>':'<span class="badge missing">Nu</span>'}</td><td>${e(row.reason||'—')}</td></tr>`).join('')}</tbody></table></div>`:empty('Nu există VM-uri active.');
  const cards=`<div class="cards report-summary">${reportFilterCard('VM-uri',rows.length,'reset')}${reportFilterCard('Se publică',yes,'publish','yes')}${reportFilterCard('Nu se publică',no,'publish','no','danger')}${reportFilterCard('Pornite',on,'power','on')}${reportFilterCard('Oprite',off,'power','off')}</div>`;
  const actions=`<div class="section-actions"><span>${data.integration_enabled?'<span class="badge active">Integrare Outline activă</span>':'<span class="badge missing">Integrare Outline dezactivată global</span>'}</span><span id="outlineVMCount" class="muted"></span><a id="outlineVMExport" class="button-link small secondary" href="/api/v1/reports/outline-publication/vms/export">Export Excel</a></div>`;
  return `${cards}${panel('Publicare Outline · VM-uri',`${reportDonut('Stare publicare VM-uri',data.chart)}${filters}${actions}${table}`,'<span class="muted">Cardurile sunt clicabile și aplică filtre. Exportul Excel folosește exact filtrele curente.</span>')}`;
}

function outlineServiceReportBody(data){
  const rows=Array.isArray(data.rows)?data.rows:[],yes=rows.filter(r=>r.publish).length,no=rows.length-yes,active=rows.filter(r=>r.state==='active').length,inactive=rows.filter(r=>r.state==='inactive').length,retired=rows.filter(r=>r.state==='retired').length;
  const criticalities=[...new Set(rows.map(r=>r.criticality).filter(Boolean))].sort();
  const documentationStatuses=[...new Set(rows.map(r=>r.documentation_status).filter(Boolean))].sort();
  const reasons=[...new Map(rows.map(r=>[r.reason_code,r.reason])).entries()].filter(([k])=>k).sort((a,b)=>String(a[1]).localeCompare(String(b[1]),'ro'));
  const filters=`<div class="filterbar report-table-filters"><label><span>Căutare</span><input id="outlineServiceSearch" type="search" placeholder="Serviciu, link, motiv…"></label><label><span>Publicare Outline</span><select id="outlineServicePublish"><option value="">Toate</option><option value="yes">Se publică</option><option value="no">Nu se publică</option></select></label><label><span>Stare serviciu</span><select id="outlineServiceState"><option value="">Toate</option><option value="active">Activ</option><option value="inactive">Inactiv</option><option value="retired">Retras</option></select></label><label><span>Criticitate</span><select id="outlineServiceCriticality"><option value="">Toate</option>${criticalities.map(v=>`<option value="${e(v.toLowerCase())}">${e(v)}</option>`).join('')}</select></label><label><span>Status documentație</span><select id="outlineServiceDocumentation"><option value="">Toate</option>${documentationStatuses.map(v=>`<option value="${e(v.toLowerCase())}">${e(v)}</option>`).join('')}</select></label><label><span>Motiv</span><select id="outlineServiceReason"><option value="">Toate</option>${reasons.map(([k,v])=>`<option value="${e(k)}">${e(v)}</option>`).join('')}</select></label><div class="filter-actions"><button type="button" id="outlineServiceApply">Caută / Aplică</button><button type="button" id="outlineServiceReset" class="secondary">Resetează</button></div></div>`;
  const table=rows.length?`<div class="table-wrap"><table><thead><tr><th>Serviciu</th><th>Stare</th><th>Criticitate</th><th>Status documentație</th><th>Link documentație</th><th>Se publică</th><th>Motiv</th></tr></thead><tbody>${rows.map(row=>`<tr class="outline-service-row" data-search="${e([row.name,row.documentation_url,row.criticality,row.documentation_status,row.reason].join(' ').toLowerCase())}" data-publish="${row.publish?'yes':'no'}" data-state="${e(row.state||'')}" data-criticality="${e(String(row.criticality||'').toLowerCase())}" data-documentation="${e(String(row.documentation_status||'').toLowerCase())}" data-reason="${e(row.reason_code||'')}"><td><a href="#services/${row.id}/details"><strong>${e(row.name)}</strong></a></td><td>${row.state==='retired'?'<span class="badge missing">Retras</span>':row.state==='inactive'?'<span class="badge">Inactiv</span>':'<span class="badge active">Activ</span>'}</td><td>${criticalityBadge(row.criticality)}</td><td>${badge(row.documentation_status||'—')}</td><td>${row.documentation_url?`<a href="${e(row.documentation_url)}" target="_blank" rel="noopener">${e(row.documentation_url)}</a>`:'—'}</td><td>${row.publish?'<span class="badge active">Da</span>':'<span class="badge missing">Nu</span>'}</td><td>${e(row.reason||'—')}</td></tr>`).join('')}</tbody></table></div>`:empty('Nu există servicii.');
  const cards=`<div class="cards report-summary">${reportFilterCard('Servicii',rows.length,'reset')}${reportFilterCard('Se publică',yes,'publish','yes')}${reportFilterCard('Nu se publică',no,'publish','no','danger')}${reportFilterCard('Active',active,'state','active')}${reportFilterCard('Inactive',inactive,'state','inactive')}${reportFilterCard('Retrase',retired,'state','retired')}</div>`;
  const actions=`<div class="section-actions"><span>${data.integration_enabled?'<span class="badge active">Integrare Outline activă</span>':'<span class="badge missing">Integrare Outline dezactivată global</span>'}</span><span id="outlineServiceCount" class="muted"></span><a id="outlineServiceExport" class="button-link small secondary" href="/api/v1/reports/outline-publication/services/export">Export Excel</a></div>`;
  return `${cards}${panel('Publicare Outline · Servicii',`${reportDonut('Stare publicare servicii',data.chart)}${filters}${actions}${table}`,'<span class="muted">Cardurile sunt clicabile și aplică filtre. Pentru servicii sunt verificate lifecycle-ul, bifa Outline și Link documentație.</span>')}`;
}
function reportInventoryStorage(stats){stats=stats||{};const agents=stats.top_agents||[];const rows=agents.map(a=>`<tr><td><strong>${e(a.agent_name||`Agent #${a.agent_id}`)}</strong></td><td>${Number(a.snapshots||0).toLocaleString('ro-RO')}</td><td>${bytesText(a.payload_bytes||0)}</td><td>${a.oldest_snapshot?dt(a.oldest_snapshot):'—'}</td><td>${a.newest_snapshot?dt(a.newest_snapshot):'—'}</td></tr>`).join('');return `<div class="cards inventory-storage-summary"><div class="card"><div class="label">Snapshot-uri</div><div class="value">${Number(stats.snapshots||0).toLocaleString('ro-RO')}</div></div><div class="card"><div class="label">Payload JSON</div><div class="value compact">${bytesText(stats.payload_bytes||0)}</div></div><div class="card"><div class="label">Date tabelă</div><div class="value compact">${bytesText(stats.table_data_bytes||0)}</div></div><div class="card"><div class="label">Indexuri</div><div class="value compact">${bytesText(stats.table_index_bytes||0)}</div></div></div><div class="inventory-storage-range"><span>Cel mai vechi: <strong>${stats.oldest_snapshot?dt(stats.oldest_snapshot):'—'}</strong></span><span>Cel mai nou: <strong>${stats.newest_snapshot?dt(stats.newest_snapshot):'—'}</strong></span></div>${rows?`<div class="table-wrap"><table><thead><tr><th>Agent</th><th>Snapshot-uri</th><th>Payload</th><th>Cel mai vechi</th><th>Cel mai nou</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există snapshot-uri de inventar.')}`}
const reportCategories=[
  {id:'beneficiaries',label:'Beneficiari · departamente și persoane'},
  {id:'overview',label:'Prezentare generală'},
  {id:'vms',label:'VM & resurse'},
  {id:'agents',label:'Agenți & inventar'},
  {id:'services',label:'Servicii & arhitectură'},
  {id:'people',label:'Persoane & responsabilități'},
  {id:'operations',label:'Lipsuri operaționale'},
  {id:'security-reviews',label:'Revizii securitate'},
  {id:'hardening',label:'Hardening · verificări interne'},
  {id:'software',label:'Software principal'},
  {id:'software-components',label:'Componente software'},
  {id:'support-components',label:'Componente suport'},
  {id:'os-support',label:'Suport sisteme de operare'},
  {id:'outline-vms',label:'Outline · VM-uri'},
  {id:'outline-services',label:'Outline · Servicii'},
  {id:'dependencies',label:'Dependențe & impact'},
  {id:'documents',label:'Documentație'}
];
function releaseDate(value){
  const match=String(value||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);return match?`${match[3]}.${match[2]}.${match[1]}`:e(value||'—');
}
function releaseDetailsHTML(item,currentVersion){
  const current=String(item.version||'')===String(currentVersion||''),details=Array.isArray(item.details)?item.details:[];
  return `<details class="release-history-row ${current?'current':''}"><summary><span class="release-version"><strong>${e(item.version)}</strong>${current?'<span class="badge online">Curentă</span>':''}</span><time datetime="${e(item.date||'')}">${releaseDate(item.date)}</time><span class="release-main-change">${e(item.summary||'—')}</span><span class="release-chevron" aria-hidden="true">⌄</span></summary><div class="release-history-details">${details.length?`<ul>${details.map(detail=>`<li>${e(detail)}</li>`).join('')}</ul>`:'<p class="muted">Nu sunt detalii suplimentare pentru această versiune.</p>'}</div></details>`;
}
async function releasesPage(){
  pageMeta('Releasuri','Ce aduce nou fiecare versiune VM-DOC');
  const [history,build]=await Promise.all([fetch('/static/releases.json?v=0.21.23',{headers:{Accept:'application/json'}}).then(async response=>{if(!response.ok)throw new Error(`Istoricul releasurilor nu poate fi încărcat (HTTP ${response.status}).`);return response.json()}),api('/version').catch(()=>({version:''}))]);
  const releases=Array.isArray(history?.releases)?history.releases:[],currentVersion=build?.version||'';
  const rows=releases.map(item=>releaseDetailsHTML(item,currentVersion)).join('');
  content.innerHTML=`<section class="release-history-shell"><div class="release-history-intro"><div><strong>Istoric versiuni</strong><span>${releases.length.toLocaleString('ro-RO')} versiuni documentate${currentVersion?` · server ${e(currentVersion)}`:''}</span></div></div><div class="release-history-head"><span>Versiune</span><span>Data</span><span>Modificarea principală</span><span></span></div><div class="release-history-list">${rows||empty('Nu există releasuri documentate.')}</div></section>`;
}

function reportSubmenu(active){return `<aside class="nomenclature-submenu report-submenu"><div class="nomenclature-submenu-title">Rapoarte</div><section>${reportCategories.map(item=>`<a href="#reports/${item.id}" class="${active===item.id?'active':''}"><span>${e(item.label)}</span></a>`).join('')}</section></aside>`}
function securityReviewReportParams(includePage=true){
  const f=state.securityReviewReport,p=new URLSearchParams();
  if(f.q)p.set('q',f.q);if(f.vmId)p.set('vm_id',f.vmId);if(f.agentVersion)p.set('agent_version',f.agentVersion);if(f.category)p.set('category',f.category);if(f.status)p.set('status',f.status);if(f.period)p.set('period',f.period);if(f.reviewer)p.set('reviewer',f.reviewer);if(f.justified)p.set('justified',f.justified);if(f.risk)p.set('risk',f.risk);if(f.lastFrom)p.set('last_from',f.lastFrom);if(f.lastTo)p.set('last_to',f.lastTo);if(f.nextFrom)p.set('next_from',f.nextFrom);if(f.nextTo)p.set('next_to',f.nextTo);if(f.daysMin!==''&&f.daysMin!=null)p.set('days_min',String(f.daysMin));if(f.daysMax!==''&&f.daysMax!=null)p.set('days_max',String(f.daysMax));
  if(includePage){p.set('page',String(f.page||1));p.set('page_size',String(f.pageSize||50))}
  return p;
}
function securityReviewCategoryLabel(value){return ({vm_account:'Cont VM',database:'Bază de date',database_principal:'DB · Users',database_grants:'DB · Grants',database_hba:'DB · HBA',web:'Web ACL',firewall:'Firewall FortiGate',firewall_local:'Firewall local'})[value]||value||'—'}
function securityReviewStatusBadge(value){if(value==='unreviewed')return '<span class="badge missing">Nerevizuit</span>';if(value==='overdue')return '<span class="badge failed">Expirat</span>';if(value==='today')return '<span class="badge unknown">Astăzi</span>';if(value==='due_30')return '<span class="badge review">În 30 zile</span>';return '<span class="badge active">La zi</span>'}
function securityReviewRiskBadge(value){if(value==='high')return '<span class="badge failed">Ridicat</span>';if(value==='attention')return '<span class="badge unknown">Atenție</span>';return '<span class="badge active">Normal</span>'}
function securityReviewDaysHTML(row){if(row.days_until_review==null)return '<span class="badge missing">Review inițial</span>';const days=Number(row.days_until_review);if(days<0)return `<span class="badge failed">depășit cu ${Math.abs(days)} zile</span>`;if(days===0)return '<span class="badge unknown">astăzi</span>';if(days<=7)return `<span class="badge unknown">în ${days} zile</span>`;if(days<=30)return `<span class="badge review">în ${days} zile</span>`;return `<span class="muted">în ${days} zile</span>`}
function securityReviewResourceLink(row){const section=row.resource_type==='vm_account'?'security-accounts':['database','database_principal','database_grants','database_hba'].includes(row.resource_type)?'security-databases':row.resource_type==='firewall'?'security-firewall':'security-web';return `<a href="#vms/${row.vm_id}/${section}"><strong>${e(row.resource_name||'—')}</strong></a>`}
function securityReviewReportBody(data){
  const s=data.summary||{},facets=data.facets||{},f=state.securityReviewReport,items=Array.isArray(data.items)?data.items:[];
  const cards=`<div class="cards report-summary" id="securityReviewQuickCards">${reportFilterCard('Nerevizuite',s.unreviewed,'status','unreviewed','warning')}${reportFilterCard('Expirate',s.overdue,'status','overdue','danger')}${reportFilterCard('Astăzi',s.due_today,'period','today','warning')}${reportFilterCard('Săptămâna aceasta',s.this_week,'period','this_week')}${reportFilterCard('Săptămâna viitoare',s.next_week,'period','next_week')}${reportFilterCard('Luna aceasta',s.this_month,'period','this_month')}${reportFilterCard('Luna viitoare',s.next_month,'period','next_month')}${reportFilterCard('Următoarele 30 zile',s.next_30_days,'period','next_30_days')}${reportFilterCard('Risc ridicat',s.high_risk,'risk','high','danger')}${reportFilterCard('Nejustificate',s.unjustified,'justified','no','danger')}</div>`;
  const vmOptions=(facets.vms||[]).map(v=>`<option value="${v.id}" ${String(f.vmId)===String(v.id)?'selected':''}>${e(v.name)}</option>`).join('');
  const agentOptions=(facets.agent_versions||[]).map(v=>`<option value="${e(v)}" ${f.agentVersion===v?'selected':''}>${e(v)}</option>`).join('');
  const reviewerOptions=(facets.reviewers||[]).map(v=>`<option value="${e(v)}" ${f.reviewer===v?'selected':''}>${e(v)}</option>`).join('');
  const filters=`<div class="filterbar report-table-filters ui-filter-shell"><label><span>Caută</span><input id="securityReviewSearch" type="search" value="${e(f.q||'')}" placeholder="VM, user, DB, vhost, policy, indicator…"></label><label><span>VM</span><select id="securityReviewVM"><option value="">Toate</option>${vmOptions}</select></label><label><span>Agent versiune</span><select id="securityReviewAgent"><option value="">Toate</option><option value="__none__" ${f.agentVersion==='__none__'?'selected':''}>Fără agent / versiune</option>${agentOptions}</select></label><label><span>Categorie</span><select id="securityReviewCategory"><option value="">Toate</option><option value="vm_account" ${f.category==='vm_account'?'selected':''}>Conturi</option><option value="database" ${f.category==='database'?'selected':''}>Baze de date (toate)</option><option value="database_principal" ${f.category==='database_principal'?'selected':''}>DB · Users</option><option value="database_grants" ${f.category==='database_grants'?'selected':''}>DB · Grants</option><option value="database_hba" ${f.category==='database_hba'?'selected':''}>DB · HBA</option><option value="web" ${f.category==='web'?'selected':''}>Web</option><option value="firewall" ${f.category==='firewall'?'selected':''}>Firewall</option></select></label><label><span>Status</span><select id="securityReviewStatus"><option value="">Toate</option><option value="due" ${f.status==='due'?'selected':''}>Necesită acțiune ≤30 zile</option><option value="unreviewed" ${f.status==='unreviewed'?'selected':''}>Nerevizuit</option><option value="overdue" ${f.status==='overdue'?'selected':''}>Expirat</option><option value="today" ${f.status==='today'?'selected':''}>Astăzi</option><option value="due_30" ${f.status==='due_30'?'selected':''}>În 30 zile</option><option value="current" ${f.status==='current'?'selected':''}>La zi &gt;30 zile</option></select></label><label><span>Calendar</span><select id="securityReviewPeriod"><option value="">Oricând</option><option value="this_week" ${f.period==='this_week'?'selected':''}>Săptămâna aceasta</option><option value="next_week" ${f.period==='next_week'?'selected':''}>Săptămâna viitoare</option><option value="this_month" ${f.period==='this_month'?'selected':''}>Luna aceasta</option><option value="next_month" ${f.period==='next_month'?'selected':''}>Luna viitoare</option><option value="next_30_days" ${f.period==='next_30_days'?'selected':''}>Următoarele 30 zile</option><option value="today" ${f.period==='today'?'selected':''}>Astăzi</option><option value="overdue" ${f.period==='overdue'?'selected':''}>Expirate</option><option value="unreviewed" ${f.period==='unreviewed'?'selected':''}>Fără review</option></select></label><label><span>Revizuit de</span><select id="securityReviewReviewer"><option value="">Toți</option>${reviewerOptions}</select></label><label><span>Justificat</span><select id="securityReviewJustified"><option value="">Toate</option><option value="yes" ${f.justified==='yes'?'selected':''}>Da</option><option value="no" ${f.justified==='no'?'selected':''}>Nu</option><option value="unknown" ${f.justified==='unknown'?'selected':''}>Nerevizuit</option></select></label><label><span>Risc</span><select id="securityReviewRisk"><option value="">Toate</option><option value="high" ${f.risk==='high'?'selected':''}>Ridicat</option><option value="attention" ${f.risk==='attention'?'selected':''}>Atenție</option><option value="normal" ${f.risk==='normal'?'selected':''}>Normal</option></select></label><label><span>Last review de la</span><input id="securityReviewLastFrom" type="date" value="${e(f.lastFrom||'')}"></label><label><span>Last review până la</span><input id="securityReviewLastTo" type="date" value="${e(f.lastTo||'')}"></label><label><span>Next review de la</span><input id="securityReviewNextFrom" type="date" value="${e(f.nextFrom||'')}"></label><label><span>Next review până la</span><input id="securityReviewNextTo" type="date" value="${e(f.nextTo||'')}"></label><label><span>Zile minim</span><input id="securityReviewDaysMin" type="number" step="1" value="${e(f.daysMin??'')}" placeholder="ex. 0"></label><label><span>Zile maxim</span><input id="securityReviewDaysMax" type="number" step="1" value="${e(f.daysMax??'')}" placeholder="ex. 30"></label><button id="securityReviewReset" class="secondary" type="button">Resetează</button></div>`;
  const rows=items.map(row=>`<tr><td><a href="#vms/${row.vm_id}/security"><strong>${e(row.vm_name)}</strong></a></td><td><strong>${e(row.agent_version||'—')}</strong>${row.agent_name?`<div class="muted">${e(row.agent_name)}</div>`:''}</td><td>${e(securityReviewCategoryLabel(row.resource_type))}</td><td>${securityReviewResourceLink(row)}</td><td>${securityReviewRiskBadge(row.risk)}<div class="muted">${e((row.indicators||[]).join(' · ')||'—')}</div></td><td>${row.reviewed_at?dt(row.reviewed_at):'—'}</td><td>${row.next_review_at?dt(row.next_review_at):'<span class="muted">review inițial</span>'}</td><td>${securityReviewDaysHTML(row)}</td><td>${row.interval_months?`${Number(row.interval_months)} luni`:'—'}</td><td>${row.justified==null?'—':row.justified?'<span class="badge active">Da</span>':'<span class="badge failed">Nu</span>'}</td><td>${e(row.reviewed_by||'—')}${row.notes?`<div class="muted">${e(row.notes)}</div>`:''}</td><td>${securityReviewStatusBadge(row.status)}</td><td><div class="actions"><a class="button-link small secondary" href="#vms/${row.vm_id}/${row.resource_type==='vm_account'?'security-accounts':['database','database_principal','database_grants','database_hba'].includes(row.resource_type)?'security-databases':row.resource_type==='firewall'?'security-firewall':'security-web'}">Deschide</a>${can('vms.manage')?`<button type="button" class="small secondary security-review" data-vm="${row.vm_id}" data-type="${e(row.resource_type)}" data-key="${e(row.resource_key)}" data-vm-name="${e(row.vm_name||'')}" data-resource-name="${e(row.resource_name||row.username||row.resource_key||'')}" data-interval="${Number(row.interval_months||12)}" data-justified="${row.reviewed_at?(row.justified===true?'yes':'no'):''}" data-notes="${e(row.notes||'')}">Revizuiește</button>`:''}</div></td></tr>`).join('');
  const table=rows?`<div class="table-wrap"><table class="security-review-report-table"><thead><tr><th>VM</th><th>Agent versiune</th><th>Categorie</th><th>Resursă</th><th>Indicatori</th><th>Last review</th><th>Next review</th><th>Peste câte zile</th><th>Interval</th><th>Justificat</th><th>Revizuit de</th><th>Status</th><th>Acțiune</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există acțiuni de review pentru filtrele selectate.');
  const pages=Math.max(1,Number(data.pages||1)),page=Math.max(1,Number(data.page||1)),total=Number(data.total||0),pageSize=Number(data.page_size||50);
  const prev=Math.max(1,page-1),next=Math.min(pages,page+1),pager=`<div class="pagination"><span>${total.toLocaleString('ro-RO')} acțiuni · pagina ${page} / ${pages}</span><label class="pagination-size">Pe pagină<select id="securityReviewPageSize">${[25,50,100,200].map(v=>`<option value="${v}" ${pageSize===v?'selected':''}>${v}</option>`).join('')}</select></label><button type="button" class="secondary security-review-page" data-page="${prev}" ${page<=1?'disabled':''}>‹</button><button type="button" class="secondary security-review-page" data-page="${next}" ${page>=pages?'disabled':''}>›</button></div>`;
  const exportURL=`/api/v1/reports/security-reviews/export${securityReviewReportParams(false).toString()?`?${securityReviewReportParams(false)}`:''}`;
  const actions=`<div class="section-actions"><span class="muted">${total.toLocaleString('ro-RO')} acțiuni pentru filtrele curente</span><a id="securityReviewExport" class="button-link small secondary" href="${e(exportURL)}">Export Excel</a></div>`;
  const note=`<div class="notice info"><strong>Plan de lucru pentru Access Review.</strong><span>„Săptămâna aceasta” înseamnă de azi până duminică; „Luna aceasta” de azi până la sfârșitul lunii. Cardurile calendaristice se pot suprapune intenționat. Conturile system fără valoare de review sunt excluse implicit, cu excepția celor deja revizuite.</span></div>`;
  return `${cards}${note}${panel('Calendar revizii securitate',`${filters}${actions}${table}${pager}`,'<span class="muted">Ordinea implicită prioritizează nerevizuitele, expiratele și apoi următoarele scadențe. Click pe coloane sortează pagina afișată.</span>')}`;
}
async function reloadSecurityReviewReport(){await reportsPage('security-reviews')}
function bindSecurityReviewReportControls(){
  const f=state.securityReviewReport;
  const setAndReload=(key,value)=>{f[key]=value;f.page=1;reloadSecurityReviewReport()};
  let timer;document.getElementById('securityReviewSearch')?.addEventListener('input',event=>{clearTimeout(timer);const value=event.currentTarget.value;timer=setTimeout(()=>setAndReload('q',value.trim()),220)});
  [['securityReviewVM','vmId'],['securityReviewAgent','agentVersion'],['securityReviewCategory','category'],['securityReviewStatus','status'],['securityReviewPeriod','period'],['securityReviewReviewer','reviewer'],['securityReviewJustified','justified'],['securityReviewRisk','risk'],['securityReviewLastFrom','lastFrom'],['securityReviewLastTo','lastTo'],['securityReviewNextFrom','nextFrom'],['securityReviewNextTo','nextTo'],['securityReviewDaysMin','daysMin'],['securityReviewDaysMax','daysMax']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>setAndReload(key,event.target.value)));
  document.getElementById('securityReviewReset')?.addEventListener('click',()=>{Object.assign(f,{q:'',vmId:'',agentVersion:'',category:'',status:'',period:'',reviewer:'',justified:'',risk:'',lastFrom:'',lastTo:'',nextFrom:'',nextTo:'',daysMin:'',daysMax:'',page:1,pageSize:50});reloadSecurityReviewReport()});
  document.querySelectorAll('#securityReviewQuickCards .report-filter-card').forEach(card=>card.addEventListener('click',()=>{const field=card.dataset.filterField,value=card.dataset.filterValue||'';if(field==='status'){f.status=f.status===value?'':value;f.period=''}else if(field==='period'){f.period=f.period===value?'':value;f.status=''}else if(field==='risk'){f.risk=f.risk===value?'':value}else if(field==='justified'){f.justified=f.justified===value?'':value}f.page=1;reloadSecurityReviewReport()}));
  document.querySelectorAll('.security-review-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==f.page){f.page=page;reloadSecurityReviewReport()}}));
  document.getElementById('securityReviewPageSize')?.addEventListener('change',event=>{f.pageSize=Number(event.target.value)||50;f.page=1;reloadSecurityReviewReport()});
  bindSecurityReviewButtons(content);
}

function reportCategoryBody(category,data){
  const s=data.summary||{},c=data.charts||{},topServicePoints=(data.top_services||[]).map(r=>({label:r.name,value:r.vm_count}));
  if(category==='vms')return `${panel('VM & resurse',`<div class="report-grid">${reportDonut('Power state',c.vm_power_state)}${reportDonut('Medii PROD / TEST / DEV',c.vm_environment)}${reportDonut('Status operațional',c.vm_operational_status)}${reportDonut('Dimensionare vCPU',c.vm_cpu_size)}${reportDonut('Dimensionare RAM',c.vm_memory_size)}${reportBars('Sisteme de operare',c.vm_os,12)}${reportBars('Distribuție pe vCenter',c.vm_source,12)}${reportBars('Versiuni hardware VM',c.vm_hardware_version,15)}</div>`)}`;
  if(category==='agents')return `${panel('Agenți & inventar',`<div class="report-grid">${reportDonut('Acoperire agent',c.agent_coverage)}${reportDonut('Prospețime inventar',c.inventory_freshness)}${reportDonut('Protecție backup',c.backup_protection)}</div>`)}${panel('Stocare inventory_snapshots',reportInventoryStorage(data.inventory_storage),'<span class="muted">Retenția implicită păstrează maximum 30 snapshot-uri/agent și maximum 90 zile; snapshot-urile curente și cele referite de documente generate sunt protejate.</span>')}`;
  if(category==='services')return `${panel('Servicii & arhitectură',`<div class="report-grid">${reportDonut('Criticitate servicii',c.service_criticality)}${reportDonut('Tip soluție',c.solution_type)}${reportDonut('Soluții omogene / mixte',c.service_solution_mix)}${reportDonut('Dimensiune servicii după VM-uri',c.service_vm_size)}${reportDonut('Tip utilizare asociere',c.assignment_usage)}${reportDonut('Asocieri principale / secundare',c.assignment_primary)}${reportDonut('Completitudine asocieri',c.assignment_completeness)}${reportBars('Servicii prezente pe medii',c.service_environment_presence,15)}${reportBars('Servicii pe domeniu',c.service_domain,15)}${reportBars('Servicii pe categorie',c.service_category,15)}${reportBars('VM-uri pe layer',c.layer_usage,15)}${reportBars('Roluri tehnice utilizate',c.technical_role_usage,20)}${reportBars('Servicii cu cele mai multe VM-uri',topServicePoints,20)}</div>`)}`;
  if(category==='people'){
    const rows=Array.isArray(data.people_assignments)?data.people_assignments:[],departments=[...new Set(rows.map(r=>r.department).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro')),environments=[...new Set(rows.map(r=>r.environment).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro'));
    const filters=`<div class="filterbar report-table-filters"><label>Căutare<input id="peopleReportSearch" type="search" placeholder="Persoană, VM, serviciu…"></label><label>Rol<select id="peopleReportRole"><option value="">Toate</option>${Object.entries(responsibilityTypes).map(([v,l])=>`<option value="${e(v)}">${e(l)}</option>`).join('')}</select></label><label>Departament<select id="peopleReportDepartment"><option value="">Toate</option>${departments.map(v=>`<option value="${e(v)}">${e(v)}</option>`).join('')}</select></label><label>Mediu<select id="peopleReportEnvironment"><option value="">Toate</option>${environments.map(v=>`<option value="${e(v)}">${e(environmentDisplay(v))}</option>`).join('')}</select></label></div>`;
    const table=rows.length?`<div class="section-actions"><span id="peopleReportCount" class="muted"></span><a id="peopleReportExport" class="button-link small secondary" href="/api/v1/reports/people/export">Export Excel</a></div><div class="table-wrap"><table><thead><tr><th>Persoană</th><th>Departament</th><th>Responsabilitate</th><th>VM</th><th>Mediu</th><th>Servicii</th></tr></thead><tbody>${rows.map(r=>`<tr class="people-report-row" data-search="${e([r.person_name,r.email,r.department,r.vm_name,r.services].join(' ').toLowerCase())}" data-role="${e(r.responsibility_type||'')}" data-department="${e(r.department||'')}" data-environment="${e(r.environment||'')}"><td><strong>${e(r.person_name)}</strong><div class="muted">${e(r.email||'—')}</div></td><td>${e(r.department||'—')}</td><td>${e(responsibilityTypes[r.responsibility_type]||r.responsibility_type)}</td><td><a href="#vms/${r.vm_id}/overview"><strong>${e(r.vm_name)}</strong></a></td><td>${r.environment?environmentBadge(r.environment):'—'}</td><td>${e(r.services||'—')}</td></tr>`).join('')}</tbody></table></div>`:empty('Nu există responsabilități VM definite.');
    return `<div class="cards report-summary">${reportSummaryCard('Persoane active',s.people_active)}${reportSummaryCard('Persoane cu VM-uri',s.people_with_vms)}${reportSummaryCard('VM fără responsabil',s.vms_without_responsibility,'warning')}${reportSummaryCard('VM cu mai mulți responsabili',s.vms_multi_responsibility)}</div>${panel('Persoane → VM-uri',`${filters}${table}`,'<span class="muted">Un rând reprezintă o persoană, o VM și un tip de responsabilitate; exportul Excel păstrează aceeași structură filtrabilă.</span>')}`;
  }
  if(category==='security-reviews')return securityReviewReportBody(data);
  if(category==='operations'){
    const rows=Array.isArray(data.operational_gaps)?data.operational_gaps:[];
    const filters=`<div class="filterbar report-table-filters"><label>Căutare<input id="gapReportSearch" type="search" placeholder="VM, hostname, problemă…"></label><label>Problemă<select id="gapReportIssue"><option value="">Toate</option><option value="responsibility">Fără responsabil</option><option value="service">Fără serviciu</option><option value="environment">Fără mediu</option><option value="agent">Fără agent</option><option value="agent_offline">Agent offline</option><option value="inventory">Inventar lipsă / vechi</option><option value="backup">Backup neacoperit</option><option value="monitoring">Fără monitorizare</option><option value="baseline">Fără baseline</option><option value="document">Fără fișă VM</option><option value="documentation">Documentație incompletă</option></select></label></div>`;
    const table=rows.length?`<div class="section-actions"><span id="gapReportCount" class="muted"></span><a id="gapReportExport" class="button-link small secondary" href="/api/v1/reports/operational-gaps/export">Export Excel</a></div><div class="table-wrap"><table><thead><tr><th>VM</th><th>Mediu</th><th>Power</th><th>Probleme</th></tr></thead><tbody>${rows.map(r=>`<tr class="gap-report-row" data-search="${e([r.name,r.hostname,r.environment,r.issue].join(' ').toLowerCase())}" data-responsibility="${r.no_responsibility?'1':'0'}" data-service="${r.no_service?'1':'0'}" data-environment="${r.no_environment?'1':'0'}" data-agent="${r.no_agent?'1':'0'}" data-agent_offline="${r.agent_offline?'1':'0'}" data-inventory="${r.inventory_stale?'1':'0'}" data-backup="${r.backup_gap?'1':'0'}" data-monitoring="${r.monitoring_gap?'1':'0'}" data-baseline="${r.no_baseline?'1':'0'}" data-document="${r.no_document?'1':'0'}" data-documentation="${(r.no_responsibility||r.no_service||r.no_environment||r.no_baseline||r.no_document)?'1':'0'}"><td><a href="#vms/${r.id}/overview"><strong>${e(r.name)}</strong></a><div class="muted mono">${e(r.hostname||'—')}</div></td><td>${r.environment?environmentBadge(r.environment):'—'}</td><td>${badge(r.power_state||'unknown')}</td><td class="warning-text">${e(r.issue)}</td></tr>`).join('')}</tbody></table></div>`:empty('Nu sunt identificate lipsuri operaționale.');
    return `${panel('Listă de lucru operațională',`${filters}${table}`,'<span class="muted">Raportul combină responsabilități, servicii, agent/inventar, backup, monitorizare, baseline și existența fișei VM.</span>')}`;
  }
  if(category==='software-components')return softwareComponentReportBody(data);
  if(category==='support-components')return supportComponentReportBody(data);
  if(category==='os-support')return osSupportReportBody(data);
  if(category==='outline-vms')return outlineVMReportBody(data);
  if(category==='outline-services')return outlineServiceReportBody(data);
  if(category==='software')return `${panel('Software principal',`<div class="report-grid">${reportBars('Servicii software marcate principal',c.primary_agent_software,30)}</div><p class="muted report-note">Selecțiile provin din serviciile observate de agent și marcate Principal pe fiecare VM.</p>`)}`;
  if(category==='dependencies')return `${panel('Servicii comune și analiză de impact',`<div class="report-grid">${reportDonut('Servicii comune / globale',c.common_service_kind)}${reportDonut('Tipuri de dependență declarate',c.dependency_type_usage)}${reportBars('Servicii dependente per serviciu comun',c.common_service_impact,20)}${reportBars('VM-uri potențial afectate',c.common_service_vm_impact,20)}${reportDonut('Sisteme externe pe rețele',c.external_network_usage)+reportDonut('Sisteme externe după risc',c.external_network_risk)}</div>`,'<span class="muted">Impactul global include serviciile active; conexiunile externe moștenesc rețeaua, riscul și nivelul de trust.</span>')}`;
  if(category==='documents')return `${panel('Documentație',`<div class="report-grid">${reportDonut('Fișe tehnice VM',c.vm_documentation)}${reportDonut('Status documentație servicii',c.service_documentation_status)}${reportDonut('Fișe servicii',c.service_documentation)}</div>`)}${panel('Activitate documentație',reportTimeline('Documente generate',data.document_timeline))}${panel('Servicii care necesită completări',reportServiceIssues(data.service_issues))}${panel('VM-uri care necesită completări',reportVMIssues(data.vm_issues))}`;
  return `<div class="cards report-summary">${reportSummaryCard('VM-uri active',s.vms_present)}${reportSummaryCard('VM-uri pornite',s.vms_powered_on)}${reportSummaryCard('Servicii active',s.services_active)}${reportSummaryCard('Servicii critice',s.services_critical,'danger')}${reportSummaryCard('Servicii comune',s.services_common)}${reportSummaryCard('Globale implicite',s.services_global)}${reportSummaryCard('Dependențe declarate',s.service_dependencies)}${reportSummaryCard('Rețele externe',s.external_networks)}${reportSummaryCard('Sisteme externe',s.external_systems)}${reportSummaryCard('Conexiuni externe',s.external_connections)}${reportSummaryCard('VM fără mediu',s.vms_without_environment,'warning')}${reportSummaryCard('VM fără serviciu',s.vms_without_service,'warning')}${reportSummaryCard('VM fără fișă',s.vms_without_document,'warning')}${reportSummaryCard('Servicii fără fișă',s.services_without_document,'warning')}</div>${panel('Indicatori cheie',`<div class="report-grid">${reportDonut('Power state',c.vm_power_state)}${reportDonut('Acoperire agent',c.agent_coverage)}${reportDonut('Criticitate servicii',c.service_criticality)}${reportDonut('Fișe tehnice VM',c.vm_documentation)}</div>`)}`;
}
async function reportsPage(category='overview',preset=''){
  if(category==='beneficiaries'){await beneficiaryReportPage();return}
  if(category==='hardening'){await hardeningReportPage('reports');return}
  if(category==='outline-publication')category='outline-vms';
  if(category==='os-support'||category==='outline-vms')await loadEnvironmentCatalogue();
  if(!reportCategories.some(item=>item.id===category))category='overview';
  pageMeta('Rapoarte',reportCategories.find(item=>item.id===category)?.label||'Indicatori');
  let data;if(category==='software-components'){const [report,outlineSettings,outlineTargets]=await Promise.all([api('/api/v1/reports/software-components'),api('/api/v1/outline/settings').catch(()=>({enabled:false})),api('/api/v1/outline/publication-targets').catch(()=>[])]);report.outline={enabled:outlineSettings?.enabled===true,target:(Array.isArray(outlineTargets)?outlineTargets:[]).find(item=>item?.code==='support_components')||{}};data=report}else if(category==='support-components')data=await api('/api/v1/reports/support-components');else if(category==='os-support')data=await api('/api/v1/reports/os-support');else if(category==='outline-vms')data=await api('/api/v1/reports/outline-publication/vms');else if(category==='outline-services')data=await api('/api/v1/reports/outline-publication/services');else if(category==='security-reviews'){if(preset&&['this_week','next_week','this_month','next_month','next_30_days','today','overdue','unreviewed'].includes(preset)){state.securityReviewReport.period=preset;state.securityReviewReport.page=1}const params=securityReviewReportParams(true);data=await api(`/api/v1/reports/security-reviews?${params}`)}else{if(!state.reportsData)state.reportsData=await api('/api/v1/reports/overview');data=state.reportsData;}
  content.innerHTML=`<div class="nomenclature-layout report-layout">${reportSubmenu(category)}<div class="nomenclature-workspace"><div class="report-header"><div><strong>${e(reportCategories.find(item=>item.id===category)?.label||'Rapoarte')}</strong><span>Generat ${dt(data.generated_at)}</span></div><button id="refreshReports" class="secondary">Reîncarcă</button></div>${reportCategoryBody(category,data)}</div></div>`;
  document.getElementById('refreshReports')?.addEventListener('click',async()=>{if(!['software-components','support-components','os-support','outline-vms','outline-services','security-reviews'].includes(category))state.reportsData=null;await reportsPage(category,preset)});
  bindReportTableFilters(category,preset);
}

function bindReportFilterCards(controlMap,apply){
  const runCard=card=>{const field=card.dataset.filterField,value=card.dataset.filterValue||'';if(field==='reset'){Object.values(controlMap).forEach(control=>{if(control)control.value=''})}else if(controlMap[field])controlMap[field].value=value;apply()};
  document.querySelectorAll('.report-filter-card').forEach(card=>{card.addEventListener('click',()=>runCard(card));card.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();runCard(card)}})});
}
function updateReportFilterCards(controlMap){document.querySelectorAll('.report-filter-card').forEach(card=>{const field=card.dataset.filterField,value=card.dataset.filterValue||'';let active=false;if(field==='reset')active=Object.values(controlMap).every(control=>!control?.value);else active=controlMap[field]?.value===value;card.classList.toggle('active-filter',active)})}

function bindReportTableFilters(category,preset=''){
  if(category==='security-reviews'){bindSecurityReviewReportControls();return}
  if(category==='people'){
    const searchInput=document.getElementById('peopleReportSearch');if(searchInput&&preset){try{searchInput.value=decodeURIComponent(preset)}catch{searchInput.value=preset}}
    const apply=()=>{const q=String(document.getElementById('peopleReportSearch')?.value||'').trim().toLowerCase(),role=document.getElementById('peopleReportRole')?.value||'',department=document.getElementById('peopleReportDepartment')?.value||'',environment=document.getElementById('peopleReportEnvironment')?.value||'';let visible=0;document.querySelectorAll('.people-report-row').forEach(row=>{const ok=(!q||row.dataset.search.includes(q))&&(!role||row.dataset.role===role)&&(!department||row.dataset.department===department)&&(!environment||row.dataset.environment===environment);row.hidden=!ok;if(ok)visible++});const count=document.getElementById('peopleReportCount');if(count)count.textContent=`${visible} din ${document.querySelectorAll('.people-report-row').length} asocieri`;const params=new URLSearchParams();if(q)params.set('q',q);if(role)params.set('responsibility',role);if(department)params.set('department',department);if(environment)params.set('environment',environment);const link=document.getElementById('peopleReportExport');if(link)link.href=`/api/v1/reports/people/export${params.toString()?`?${params}`:''}`};['peopleReportSearch','peopleReportRole','peopleReportDepartment','peopleReportEnvironment'].forEach(id=>document.getElementById(id)?.addEventListener(id==='peopleReportSearch'?'input':'change',apply));apply();
  }
  if(category==='software-components'){
    const controls={q:document.getElementById('softwareComponentSearch'),component:document.getElementById('softwareComponentName'),category:document.getElementById('softwareComponentCategory'),version:document.getElementById('softwareComponentVersion'),environment:document.getElementById('softwareComponentEnvironment')};
    if(controls.q&&preset){try{controls.q.value=decodeURIComponent(preset)}catch{controls.q.value=preset}}
    const stored=Number(localStorage.getItem('vm-doc:software-components-page-size')||25);let page=1,pageSize=[10,25,50,100,200].includes(stored)?stored:25;
    const allRows=[...document.querySelectorAll('.software-component-row')];
    const values=()=>({q:String(controls.q?.value||'').trim().toLowerCase(),component:controls.component?.value||'',category:controls.category?.value||'',version:controls.version?.value||'',environment:controls.environment?.value||''});
    const matches=(row,f)=>{const versions=String(row.dataset.versions||'').split('|').filter(Boolean);return (!f.q||row.dataset.search.includes(f.q))&&(!f.component||row.dataset.component===f.component)&&(!f.category||row.dataset.category===f.category)&&(!f.version||versions.includes(f.version)||versions.some(v=>v.startsWith(f.version)))&&(!f.environment||row.dataset.environment===f.environment)};
    const updatePublishButton=()=>{const button=document.getElementById('softwareComponentPublishOutline');if(!button)return;const key=controls.component?.value||'',option=controls.component?.selectedOptions?.[0],name=key?(option?.textContent||key):'';button.dataset.component=key;button.dataset.idleLabel=key?`Publică ${name} PROD în Outline`:'Publică PROD în Outline';if(!button.disabled)button.textContent=button.dataset.idleLabel};
    const renderPager=(total)=>{const pages=Math.max(1,Math.ceil(total/pageSize));if(page>pages)page=pages;const start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total),pager=document.getElementById('softwareComponentPagination');if(!pager)return;pager.innerHTML=`<span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="softwareComponentPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,pages,'software-component-page')}</div>`;pager.hidden=total===0;document.querySelectorAll('.software-component-page').forEach(button=>button.addEventListener('click',()=>{const next=Number(button.dataset.page);if(next>0&&next!==page){page=next;apply(false)}}));document.getElementById('softwareComponentPageSize')?.addEventListener('change',event=>{pageSize=Number(event.target.value)||25;localStorage.setItem('vm-doc:software-components-page-size',String(pageSize));page=1;apply(false)})};
    const apply=(resetPage=true)=>{if(resetPage)page=1;const f=values(),filtered=allRows.filter(row=>matches(row,f)),pages=Math.max(1,Math.ceil(filtered.length/pageSize));if(page>pages)page=pages;const offset=(page-1)*pageSize,visible=new Set(filtered.slice(offset,offset+pageSize));allRows.forEach(row=>row.hidden=!visible.has(row));const table=document.getElementById('softwareComponentTableWrap'),emptyBox=document.getElementById('softwareComponentEmpty');if(table)table.hidden=filtered.length===0;if(emptyBox)emptyBox.hidden=filtered.length!==0;const count=document.getElementById('softwareComponentCount');if(count)count.textContent=`${filtered.length.toLocaleString('ro-RO')} din ${allRows.length.toLocaleString('ro-RO')} asocieri VM–componentă`;const params=new URLSearchParams();if(f.q)params.set('q',f.q);if(f.component)params.set('component',f.component);if(f.category)params.set('category',f.category);if(f.version)params.set('version',f.version);if(f.environment)params.set('environment',f.environment);const link=document.getElementById('softwareComponentExport');if(link)link.href=`/api/v1/reports/software-components/export${params.toString()?`?${params}`:''}`;updateReportFilterCards(controls);updatePublishButton();renderPager(filtered.length)};
    ['softwareComponentName','softwareComponentCategory','softwareComponentVersion','softwareComponentEnvironment'].forEach(id=>document.getElementById(id)?.addEventListener('change',()=>apply(true)));
    document.getElementById('softwareComponentSearch')?.addEventListener('input',()=>apply(true));
    document.getElementById('softwareComponentSearch')?.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();apply(true)}});
    document.getElementById('softwareComponentApply')?.addEventListener('click',()=>apply(true));
    document.getElementById('softwareComponentReset')?.addEventListener('click',()=>{Object.values(controls).forEach(control=>{if(control)control.value=''});page=1;apply(false)});
    document.getElementById('softwareComponentPublishOutline')?.addEventListener('click',async event=>{const button=event.currentTarget,component=controls.component?.value||'',label=component?(controls.component?.selectedOptions?.[0]?.textContent||component):'toate componentele',progress=document.getElementById('softwareComponentOutlineProgress');button.disabled=true;button.textContent='Se pornește publicarea…';if(progress)progress.textContent='';try{const job=await api('/api/v1/reports/software-components/outline',{method:'POST',body:JSON.stringify({component})});pollSoftwareComponentOutlineJob(job.id,button,progress,label)}catch(err){button.disabled=false;updatePublishButton();toast(err.message,true)}});
    bindReportFilterCards(controls,()=>apply(true));apply(false);
  }
  if(category==='support-components'){
    const apply=()=>{const q=String(document.getElementById('supportReportSearch')?.value||'').trim().toLowerCase(),component=document.getElementById('supportReportComponent')?.value||'',version=document.getElementById('supportReportVersion')?.value||'',environment=document.getElementById('supportReportEnvironment')?.value||'';let visible=0;document.querySelectorAll('.support-report-row').forEach(row=>{const ok=(!q||row.dataset.search.includes(q))&&(!component||row.dataset.component===component)&&(!version||row.dataset.version===version)&&(!environment||row.dataset.environment===environment);row.hidden=!ok;if(ok)visible++});document.querySelectorAll('.support-environment-group').forEach(group=>group.hidden=![...group.querySelectorAll('.support-report-row')].some(row=>!row.hidden));document.querySelectorAll('.support-version-group').forEach(group=>group.hidden=![...group.querySelectorAll('.support-environment-group')].some(child=>!child.hidden));document.querySelectorAll('.support-component-group').forEach(group=>group.hidden=![...group.querySelectorAll('.support-version-group')].some(child=>!child.hidden));const count=document.getElementById('supportReportCount');if(count)count.textContent=`${visible} din ${document.querySelectorAll('.support-report-row').length} instalări`;const params=new URLSearchParams();if(q)params.set('q',q);if(component)params.set('component',component);if(version)params.set('version',version);if(environment)params.set('environment',environment);const link=document.getElementById('supportReportExport');if(link)link.href=`/api/v1/reports/support-components/export${params.toString()?`?${params}`:''}`};['supportReportSearch','supportReportComponent','supportReportVersion','supportReportEnvironment'].forEach(id=>document.getElementById(id)?.addEventListener(id==='supportReportSearch'?'input':'change',apply));apply();
  }
  if(category==='os-support'){
    const controls={status:document.getElementById('osSupportStatus'),power:document.getElementById('osSupportPower'),environment:document.getElementById('osSupportEnvironment'),outline:document.getElementById('osSupportOutline'),q:document.getElementById('osSupportSearch')};
    const stored=Number(localStorage.getItem('vm-doc:os-support-page-size')||25);let page=1,pageSize=[10,25,50,100,200].includes(stored)?stored:25;
    const allRows=[...document.querySelectorAll('.os-support-row')];
    const values=()=>({q:String(controls.q?.value||'').trim().toLowerCase(),status:controls.status?.value||'',power:controls.power?.value||'',environment:controls.environment?.value||'',outline:controls.outline?.value||''});
    const baseMatches=(row,f)=> (!f.q||row.dataset.search.includes(f.q))&&(!f.power||row.dataset.power===f.power)&&environmentReportMatches(row.dataset.environment,f.environment)&&(!f.outline||row.dataset.outline===f.outline);
    const countPoints=(rows,key,labeler=value=>value)=>{const counts=new Map();rows.forEach(row=>{const raw=row.dataset[key]||'';const label=labeler(raw,row)||'Nespecificat';counts.set(label,(counts.get(label)||0)+1)});return [...counts.entries()].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0],'ro')).map(([label,value])=>({label,value}))};
    const updateCardsAndCharts=(baseRows)=>{
      const counts={reset:baseRows.length,supported:0,unsupported:0,undetermined:0};baseRows.forEach(row=>{counts[row.dataset.status]=(counts[row.dataset.status]||0)+1});
      document.querySelectorAll('#osSupportCards .report-filter-card').forEach(card=>{const key=card.dataset.filterValue||'reset';const value=card.querySelector('.value');if(value)value.textContent=Number(counts[key]||0).toLocaleString('ro-RO')});
      const chart=document.getElementById('osSupportCharts');if(chart){const unsupported=baseRows.filter(row=>row.dataset.status==='unsupported');chart.innerHTML=`${reportDonut('Stare suport sisteme de operare',[{label:'Suportate',value:counts.supported},{label:'Nesuportate',value:counts.unsupported},{label:'Nedeterminat',value:counts.undetermined}])}${reportDonut('VM nesuportate pe medii',countPoints(unsupported,'environmentLabel'))}${reportDonut('Sisteme de operare nesuportate',countPoints(unsupported,'osLabel'))}`}
    };
    const renderPager=(total)=>{const pages=Math.max(1,Math.ceil(total/pageSize));if(page>pages)page=pages;const start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total),pager=document.getElementById('osSupportPagination');if(!pager)return;pager.innerHTML=`<span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="osSupportPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,pages,'os-support-page')}</div>`;pager.hidden=total===0;document.querySelectorAll('.os-support-page').forEach(button=>button.addEventListener('click',()=>{const next=Number(button.dataset.page);if(next>0&&next!==page){page=next;apply(false)}}));document.getElementById('osSupportPageSize')?.addEventListener('change',event=>{pageSize=Number(event.target.value)||25;localStorage.setItem('vm-doc:os-support-page-size',String(pageSize));page=1;apply(false)})};
    const apply=(resetPage=true)=>{if(resetPage)page=1;const f=values(),baseRows=allRows.filter(row=>baseMatches(row,f)),filtered=baseRows.filter(row=>!f.status||row.dataset.status===f.status);const pages=Math.max(1,Math.ceil(filtered.length/pageSize));if(page>pages)page=pages;const offset=(page-1)*pageSize;const visiblePage=new Set(filtered.slice(offset,offset+pageSize));allRows.forEach(row=>row.hidden=!visiblePage.has(row));const tableWrap=document.getElementById('osSupportTableWrap'),emptyBox=document.getElementById('osSupportEmpty');if(tableWrap)tableWrap.hidden=filtered.length===0;if(emptyBox)emptyBox.hidden=filtered.length!==0;const count=document.getElementById('osSupportCount');if(count)count.textContent=`${filtered.length.toLocaleString('ro-RO')} din ${allRows.length.toLocaleString('ro-RO')} VM-uri`;const params=new URLSearchParams();if(f.q)params.set('q',f.q);if(f.status)params.set('status',f.status);if(f.power)params.set('power',f.power);if(f.environment)params.set('environment',f.environment);if(f.outline)params.set('outline',f.outline);const link=document.getElementById('osSupportExport');if(link)link.href=`/api/v1/reports/os-support/export${params.toString()?`?${params}`:''}`;updateCardsAndCharts(baseRows);updateReportFilterCards(controls);renderPager(filtered.length)};
    ['osSupportStatus','osSupportPower','osSupportEnvironment','osSupportOutline'].forEach(id=>document.getElementById(id)?.addEventListener('change',()=>apply(true)));
    document.getElementById('osSupportSearch')?.addEventListener('input',()=>apply(true));
    document.getElementById('osSupportApply')?.addEventListener('click',()=>apply(true));
    document.getElementById('osSupportSearch')?.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();apply(true)}});
    document.getElementById('osSupportReset')?.addEventListener('click',()=>{Object.values(controls).forEach(control=>{if(control)control.value=''});if(controls.power)controls.power.value='on';if(controls.environment)controls.environment.value='PROD';page=1;apply(false)});
    bindReportFilterCards(controls,()=>apply(true));apply(false);
  }

  if(category==='outline-vms'){
    const controls={publish:document.getElementById('outlineVMPublish'),power:document.getElementById('outlineVMPower'),environment:document.getElementById('outlineVMEnvironment'),reason:document.getElementById('outlineVMReason'),q:document.getElementById('outlineVMSearch')};
    const apply=()=>{const q=String(controls.q?.value||'').trim().toLowerCase(),publish=controls.publish?.value||'',power=controls.power?.value||'',environment=controls.environment?.value||'',reason=controls.reason?.value||'';let visible=0;document.querySelectorAll('.outline-vm-row').forEach(row=>{const ok=(!q||row.dataset.search.includes(q))&&(!publish||row.dataset.publish===publish)&&(!power||row.dataset.power===power)&&environmentReportMatches(row.dataset.environment,environment)&&(!reason||row.dataset.reason===reason);row.hidden=!ok;if(ok)visible++});const count=document.getElementById('outlineVMCount');if(count)count.textContent=`${visible} din ${document.querySelectorAll('.outline-vm-row').length} VM-uri`;const params=new URLSearchParams();if(q)params.set('q',q);if(publish)params.set('publish',publish);if(power)params.set('power',power);if(environment)params.set('environment',environment);if(reason)params.set('reason',reason);const link=document.getElementById('outlineVMExport');if(link)link.href=`/api/v1/reports/outline-publication/vms/export${params.toString()?`?${params}`:''}`;updateReportFilterCards(controls)};
    ['outlineVMSearch','outlineVMPublish','outlineVMPower','outlineVMEnvironment','outlineVMReason'].forEach(id=>document.getElementById(id)?.addEventListener(id==='outlineVMSearch'?'input':'change',apply));
    document.getElementById('outlineVMApply')?.addEventListener('click',apply);
    document.getElementById('outlineVMSearch')?.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();apply()}});
    document.getElementById('outlineVMReset')?.addEventListener('click',()=>{Object.values(controls).forEach(control=>{if(control)control.value=''});controls.power.value='on';controls.environment.value='PROD';apply()});
    bindReportFilterCards(controls,apply);apply();
  }
  if(category==='outline-services'){
    const controls={publish:document.getElementById('outlineServicePublish'),state:document.getElementById('outlineServiceState'),criticality:document.getElementById('outlineServiceCriticality'),documentation:document.getElementById('outlineServiceDocumentation'),reason:document.getElementById('outlineServiceReason'),q:document.getElementById('outlineServiceSearch')};
    const apply=()=>{const q=String(controls.q?.value||'').trim().toLowerCase(),publish=controls.publish?.value||'',stateValue=controls.state?.value||'',criticality=controls.criticality?.value||'',documentation=controls.documentation?.value||'',reason=controls.reason?.value||'';let visible=0;document.querySelectorAll('.outline-service-row').forEach(row=>{const ok=(!q||row.dataset.search.includes(q))&&(!publish||row.dataset.publish===publish)&&(!stateValue||row.dataset.state===stateValue)&&(!criticality||row.dataset.criticality===criticality)&&(!documentation||row.dataset.documentation===documentation)&&(!reason||row.dataset.reason===reason);row.hidden=!ok;if(ok)visible++});const count=document.getElementById('outlineServiceCount');if(count)count.textContent=`${visible} din ${document.querySelectorAll('.outline-service-row').length} servicii`;const params=new URLSearchParams();if(q)params.set('q',q);if(publish)params.set('publish',publish);if(stateValue)params.set('state',stateValue);if(criticality)params.set('criticality',criticality);if(documentation)params.set('documentation_status',documentation);if(reason)params.set('reason',reason);const link=document.getElementById('outlineServiceExport');if(link)link.href=`/api/v1/reports/outline-publication/services/export${params.toString()?`?${params}`:''}`;updateReportFilterCards(controls)};
    ['outlineServiceSearch','outlineServicePublish','outlineServiceState','outlineServiceCriticality','outlineServiceDocumentation','outlineServiceReason'].forEach(id=>document.getElementById(id)?.addEventListener(id==='outlineServiceSearch'?'input':'change',apply));
    document.getElementById('outlineServiceApply')?.addEventListener('click',apply);
    document.getElementById('outlineServiceSearch')?.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();apply()}});
    document.getElementById('outlineServiceReset')?.addEventListener('click',()=>{Object.values(controls).forEach(control=>{if(control)control.value=''});apply()});
    bindReportFilterCards(controls,apply);apply();
  }
  if(category==='operations'){
    const issueSelect=document.getElementById('gapReportIssue');if(issueSelect&&preset)issueSelect.value=preset;
    const apply=()=>{const q=String(document.getElementById('gapReportSearch')?.value||'').trim().toLowerCase(),issue=document.getElementById('gapReportIssue')?.value||'';let visible=0;document.querySelectorAll('.gap-report-row').forEach(row=>{const ok=(!q||row.dataset.search.includes(q))&&(!issue||row.dataset[issue]==='1');row.hidden=!ok;if(ok)visible++});const count=document.getElementById('gapReportCount');if(count)count.textContent=`${visible} din ${document.querySelectorAll('.gap-report-row').length} VM-uri`;const params=new URLSearchParams();if(q)params.set('q',q);if(issue)params.set('issue',issue);const link=document.getElementById('gapReportExport');if(link)link.href=`/api/v1/reports/operational-gaps/export${params.toString()?`?${params}`:''}`};['gapReportSearch','gapReportIssue'].forEach(id=>document.getElementById(id)?.addEventListener(id==='gapReportSearch'?'input':'change',apply));apply();
  }
}

function scopedAuditState(scope,id){
  const key=scope==='vm'?'vmAudit':'serviceAudit',idKey=scope==='vm'?'vmId':'serviceId';let f=state[key];if(Number(f[idKey])!==Number(id)){f={...f,[idKey]:Number(id),page:1,q:'',area:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:null};state[key]=f}return f;
}
function scopedAuditQuery(scope,id){return scope==='vm'?['vm_id',id]:['service_id',id]}
function scopedAuditFiltersHTML(f,facets){return `<form id="scopedAuditFilters" class="audit-filters"><label class="span-2"><span>Caută</span><input id="scopedAuditSearch" type="search" value="${e(f.q||'')}" placeholder="actor, acțiune, resursă sau detalii"></label><label><span>Zonă</span><select id="scopedAuditArea"><option value="">Toate</option>${[['configuration','Configurare'],['docker','Docker'],['database','Baze de date'],['web','Web'],['equipment','Echipamente'],['documents','Documente'],['operations','Operații / sistem']].map(([v,l])=>auditOption(v,l,f.area)).join('')}</select></label><label><span>Actor</span><select id="scopedAuditActor"><option value="">Toți</option>${(facets.actors||[]).map(v=>auditOption(v,v,f.actor)).join('')}</select></label><label><span>Sursă</span><select id="scopedAuditSource"><option value="">Toate</option>${(facets.sources||[]).map(v=>auditOption(v,v,f.source)).join('')}</select></label><label><span>Acțiune</span><select id="scopedAuditAction"><option value="">Toate</option>${(facets.actions||[]).map(v=>auditOption(v,v,f.action)).join('')}</select></label><label><span>Resursă</span><select id="scopedAuditResourceType"><option value="">Toate</option>${(facets.resource_types||[]).map(v=>auditOption(v,auditResourceTypeLabel(v),f.resourceType)).join('')}</select></label><label><span>Rezultat</span><select id="scopedAuditOutcome"><option value="">Toate</option>${(facets.outcomes||[]).map(v=>auditOption(v,v,f.outcome)).join('')}</select></label><label><span>De la</span><input id="scopedAuditFrom" type="date" value="${e(f.from||'')}"></label><label><span>Până la</span><input id="scopedAuditTo" type="date" value="${e(f.to||'')}"></label><div class="filter-actions"><button type="submit">Aplică</button><button type="button" id="scopedAuditReset" class="secondary">Resetează</button></div></form>`}
async function scopedAuditPage(scope,id){
  const root=document.getElementById('scopedAuditRoot');if(!root)return;const f=scopedAuditState(scope,id),[scopeKey,scopeValue]=scopedAuditQuery(scope,id);
  if(!f.facets){try{f.facets=await api(`/api/v1/audit/facets?${scopeKey}=${scopeValue}`)}catch{f.facets={sources:[],actors:[],actions:[],resource_types:[],outcomes:[]}}}
  root.className='scoped-audit-shell';root.innerHTML=`${panel(scope==='vm'?'Filtre audit VM':'Filtre audit serviciu',scopedAuditFiltersHTML(f,f.facets),'<span class="muted">Audit contextual: include obiectul principal și resursele tehnice care pot fi legate de el.</span>')}${panel('Evenimente','<div id="scopedAuditTableArea" class="loading">Se încarcă evenimentele…</div>')}`;
  document.getElementById('scopedAuditFilters')?.addEventListener('submit',event=>{event.preventDefault();Object.assign(f,{q:document.getElementById('scopedAuditSearch').value.trim(),area:document.getElementById('scopedAuditArea').value,source:document.getElementById('scopedAuditSource').value,actor:document.getElementById('scopedAuditActor').value,action:document.getElementById('scopedAuditAction').value,resourceType:document.getElementById('scopedAuditResourceType').value,outcome:document.getElementById('scopedAuditOutcome').value,from:document.getElementById('scopedAuditFrom').value,to:document.getElementById('scopedAuditTo').value,page:1});loadScopedAudit(scope,id)});
  document.getElementById('scopedAuditReset')?.addEventListener('click',()=>{Object.assign(f,{page:1,q:'',area:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:''});scopedAuditPage(scope,id)});
  await loadScopedAudit(scope,id);
}
async function loadScopedAudit(scope,id){
  const area=document.getElementById('scopedAuditTableArea');if(!area)return;const f=scopedAuditState(scope,id),[scopeKey,scopeValue]=scopedAuditQuery(scope,id),p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize),[scopeKey]:String(scopeValue)});[['q',f.q],['area',f.area],['source',f.source],['actor',f.actor],['action',f.action],['resource_type',f.resourceType],['outcome',f.outcome],['from',f.from],['to',f.to]].forEach(([k,v])=>{if(v)p.set(k,v)});area.className='loading';area.textContent='Se încarcă evenimentele…';
  try{const result=await api(`/api/v1/audit/events?${p}`);f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||10);area.className='';area.innerHTML=renderAuditPage(result);area.querySelectorAll('.audit-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==f.page){f.page=page;loadScopedAudit(scope,id)}}));document.getElementById('auditPageSize')?.addEventListener('change',event=>{f.pageSize=Number(event.target.value);f.page=1;loadScopedAudit(scope,id)});bindAuditToggles(area)}catch(err){area.className='';area.innerHTML=empty(err.message);changeSearchResultFeedback(0,err.message);toast(err.message,true)}
}
function auditResourceTypeLabel(value){return ({virtual_machine:'VM',internal_service:'Serviciu',docker_container:'Container Docker',docker_compose_project:'Proiect Compose',database_instance:'Instanță DB',database_catalog:'Catalog DB',web_site:'Site / frontend Web',web_server:'Server Web',software_item:'Software',generated_document:'Document',inventory_change:'Modificare inventar',internal_service_attachment:'Anexă serviciu',agent:'Agent',person:'Persoană',equipment_device:'Echipament',equipment_service_assignment:'Asociere echipament'})[value]||value||'Resursă'}
function auditResourceHTML(record){const label=record.resource_label||auditResourceTypeLabel(record.resource_type),main=record.resource_url?`<a href="${e(record.resource_url)}"><strong>${e(label)}</strong></a>`:`<strong>${e(label)}</strong>`,id=record.resource_id?`<span class="muted mono">#${e(record.resource_id)}</span>`:'',vm=record.vm_id&&record.resource_type!=='virtual_machine'?`<div class="muted">VM: <a href="#vms/${record.vm_id}/overview">${e(record.vm_name||`#${record.vm_id}`)}</a></div>`:'',services=(record.service_names||[]).length&&record.resource_type!=='internal_service'?`<div class="muted">Serviciu: ${(record.service_names||[]).map((name,index)=>{const sid=(record.service_ids||[])[index];return sid?`<a href="#services/${sid}/overview">${e(name)}</a>`:e(name)}).join(', ')}</div>`:'';return `<div class="audit-resource-context">${main} ${id}<div class="muted">${e(auditResourceTypeLabel(record.resource_type))}</div>${vm}${services}</div>`}
function bindAuditToggles(area){area?.querySelectorAll('.audit-toggle').forEach(button=>button.addEventListener('click',()=>{const row=area.querySelector(`[data-detail-id="${button.dataset.id}"]`);if(!row)return;row.hidden=!row.hidden;button.textContent=row.hidden?'Detalii':'Închide'}))}

function auditOption(value,label,current){return `<option value="${e(value)}" ${String(current||'')===String(value)?'selected':''}>${e(label||value)}</option>`}
function auditOperationBadge(operation){const labels={created:'Adăugat',updated:'Modificat',deleted:'Șters',operation:'Operație'};return `<span class="audit-operation ${e(operation||'operation')}">${e(labels[operation]||'Operație')}</span>`}
function auditDetailsObject(raw){if(raw==null)return {};if(typeof raw==='object'&&!Array.isArray(raw))return raw;try{return JSON.parse(raw)||{}}catch{return {raw:String(raw)}}}
function auditSimpleValue(value){if(value==null||value==='')return '—';if(typeof value==='boolean')return value?'Da':'Nu';if(typeof value==='object')return JSON.stringify(value);return String(value)}
function auditChangedFields(before,after){before=(before&&typeof before==='object')?before:{};after=(after&&typeof after==='object')?after:{};const keys=[...new Set([...Object.keys(before),...Object.keys(after)])].filter(k=>!['updated_at','created_at','connections'].includes(k)).sort();return keys.filter(k=>JSON.stringify(before[k])!==JSON.stringify(after[k])).map(k=>({key:k,before:before[k],after:after[k]}))}
function auditChangeDetails(record){const details=auditDetailsObject(record.details),operation=record.operation||'operation';if(operation==='updated'&&details.before&&details.after){const changes=auditChangedFields(details.before,details.after);if(!changes.length)return `<p class="muted">Eveniment de modificare fără diferențe de câmp identificabile în payload-ul de audit.</p>`;return `<div class="table-wrap audit-change-table"><table><thead><tr><th>Câmp</th><th>Înainte</th><th>După</th></tr></thead><tbody>${changes.map(c=>`<tr><td class="mono">${e(c.key)}</td><td>${e(auditSimpleValue(c.before))}</td><td>${e(auditSimpleValue(c.after))}</td></tr>`).join('')}</tbody></table></div>`}
  const subject=details.created||details.deleted;if(subject&&typeof subject==='object'){const title=operation==='deleted'?'Date șterse':'Date adăugate';const rows=Object.entries(subject).filter(([k])=>!['created_at','updated_at','connections'].includes(k)).map(([k,v])=>`<tr><td class="mono">${e(k)}</td><td>${e(auditSimpleValue(v))}</td></tr>`).join('');return `<strong>${title}</strong><div class="table-wrap audit-change-table"><table><tbody>${rows}</tbody></table></div>`}
  const entries=Object.entries(details);if(!entries.length)return `<p class="muted">Acest eveniment vechi nu conține detalii suplimentare.</p>`;return `<details class="audit-raw"><summary>Detalii tehnice</summary><pre>${e(JSON.stringify(details,null,2))}</pre></details>`}
async function auditPage(){
  pageMeta('Audit','Cine a schimbat ce, când și cu ce rezultat');
  if(!state.audit.facets){try{state.audit.facets=await api('/api/v1/audit/facets')}catch{state.audit.facets={sources:[],actors:[],actions:[],resource_types:[],outcomes:[]}}}
  const f=state.audit,facets=state.audit.facets||{},filters=`<form id="auditFilters" class="audit-filters"><label class="span-2"><span>Caută</span><input id="auditSearch" type="search" value="${e(f.q)}" placeholder="actor, acțiune, resursă, IP sau detalii"></label><label><span>Actor</span><select id="auditActor"><option value="">Toți</option>${(facets.actors||[]).map(v=>auditOption(v,v,f.actor)).join('')}</select></label><label><span>Sursă</span><select id="auditSource"><option value="">Toate</option>${(facets.sources||[]).map(v=>auditOption(v,v,f.source)).join('')}</select></label><label><span>Acțiune</span><select id="auditAction"><option value="">Toate</option>${(facets.actions||[]).map(v=>auditOption(v,v,f.action)).join('')}</select></label><label><span>Resursă</span><select id="auditResourceType"><option value="">Toate</option>${(facets.resource_types||[]).map(v=>auditOption(v,auditResourceTypeLabel(v),f.resourceType)).join('')}</select></label><label><span>Rezultat</span><select id="auditOutcome"><option value="">Toate</option>${(facets.outcomes||[]).map(v=>auditOption(v,v,f.outcome)).join('')}</select></label><label><span>De la</span><input id="auditFrom" type="date" value="${e(f.from)}"></label><label><span>Până la</span><input id="auditTo" type="date" value="${e(f.to)}"></label><div class="filter-actions"><button type="submit">Aplică</button><button type="button" id="auditReset" class="secondary">Resetează</button></div></form>`;
  content.innerHTML=`${panel('Filtre audit',filters,'<span class="muted">Evenimentele noi de adăugare/modificare/ștergere pot păstra valorile înainte și după. Evenimentele istorice afișează numai datele care au fost salvate la momentul respectiv.</span>')}${panel('Evenimente de audit','<div id="auditTableArea" class="loading">Se încarcă evenimentele…</div>')}`;
  document.getElementById('auditFilters')?.addEventListener('submit',event=>{event.preventDefault();Object.assign(f,{q:document.getElementById('auditSearch').value.trim(),actor:document.getElementById('auditActor').value,source:document.getElementById('auditSource').value,action:document.getElementById('auditAction').value,resourceType:document.getElementById('auditResourceType').value,outcome:document.getElementById('auditOutcome').value,from:document.getElementById('auditFrom').value,to:document.getElementById('auditTo').value,page:1});loadAuditPage()});
  document.getElementById('auditReset')?.addEventListener('click',()=>{state.audit={page:1,pageSize:f.pageSize||10,q:'',source:'',actor:'',action:'',resourceType:'',outcome:'',from:'',to:'',facets:state.audit.facets};auditPage()});
  await loadAuditPage()
}
function renderAuditPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există evenimente pentru filtrele selectate.');
  const rows=items.map(record=>`<tr class="audit-row"><td>${dt(record.occurred_at)}</td><td>${e(record.actor_username||'sistem')}<div class="muted mono">${e(record.ip_address||'')}</div></td><td><strong>${e(record.action_label||record.action)}</strong><div class="muted">${e(record.action_description||record.action)}</div><div class="muted mono">${e(record.action)}</div></td><td>${auditOperationBadge(record.operation)}${auditResourceHTML(record)}</td><td>${badge(record.outcome)}</td><td><button class="small secondary audit-toggle" data-id="${record.id}">Detalii</button></td></tr><tr class="audit-detail-row" data-detail-id="${record.id}" hidden><td colspan="6"><div class="audit-detail-card"><div class="detail-grid compact">${detail('Sursă',e(record.source||'—'))}${detail('Acțiune',e(record.action))}${detail('Resursă',auditResourceHTML(record))}${record.request_id?detail('Request ID',e(record.request_id),true):''}${detail('IP',e(record.ip_address||'—'),true)}</div>${auditChangeDetails(record)}</div></td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||10),start=total?(page-1)*pageSize+1:0,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Data</th><th>Actor</th><th>Acțiune</th><th>Resursă / operație</th><th>Rezultat</th><th></th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="auditPageSize">${pageSizeOptions(pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(page,Number(result.pages||1),'audit-page')}</div></div>`;
}
async function loadAuditPage(){
  const area=document.getElementById('auditTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă evenimentele…';const f=state.audit,p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize)});[['q',f.q],['source',f.source],['actor',f.actor],['action',f.action],['resource_type',f.resourceType],['outcome',f.outcome],['from',f.from],['to',f.to]].forEach(([k,v])=>{if(v)p.set(k,v)});
  try{const result=await api(`/api/v1/audit/events?${p}`);f.page=Number(result?.page||1);f.pageSize=Number(result?.page_size||10);area.className='';area.innerHTML=renderAuditPage(result);area.querySelectorAll('.audit-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==f.page){f.page=page;loadAuditPage()}}));document.getElementById('auditPageSize')?.addEventListener('change',event=>{f.pageSize=Number(event.target.value);f.page=1;loadAuditPage()});bindAuditToggles(area)}catch(err){area.className='';area.innerHTML=empty(err.message);changeSearchResultFeedback(0,err.message);toast(err.message,true)}
}

async function accessPage(){pageMeta('Acces','Mapări grupuri LDAP/OIDC către roluri');const [roles,maps]=await Promise.all([api('/api/v1/rbac/roles'),api('/api/v1/rbac/group-mappings')]);content.innerHTML=`${panel('Adaugă mapare',`<form id="mappingForm" class="detail-grid"><label>Provider<select id="mapProvider"><option value="ldap">LDAP</option><option value="oidc">OIDC</option><option value="any">Oricare</option></select></label><label>Grup<input id="mapGroup" required placeholder="VM-DOC-Operators"></label><label>Rol<select id="mapRole">${roles.map(r=>`<option value="${e(r.name)}">${e(r.name)}</option>`).join('')}</select></label><label class="form-submit"><button type="submit">Adaugă</button></label></form>`)}${panel('Mapări existente',maps.length?`<div class="table-wrap"><table><thead><tr><th>Provider</th><th>Grup</th><th>Rol</th><th></th></tr></thead><tbody>${maps.map(m=>`<tr><td>${e(m.provider)}</td><td class="mono">${e(m.group_name)}</td><td>${badge(m.role)}</td><td><button class="small danger del-map" data-id="${m.id}">Șterge</button></td></tr>`).join('')}</tbody></table></div>`:empty('Nu există mapări.'))}`;
  document.getElementById('mappingForm').onsubmit=async ev=>{ev.preventDefault();await api('/api/v1/rbac/group-mappings',{method:'POST',body:JSON.stringify({provider:document.getElementById('mapProvider').value,group_name:document.getElementById('mapGroup').value.trim(),role:document.getElementById('mapRole').value})});toast('Mapare creată.');accessPage()};content.querySelectorAll('.del-map').forEach(b=>b.onclick=async()=>{await api(`/api/v1/rbac/group-mappings/${b.dataset.id}`,{method:'DELETE'});toast('Mapare ștearsă.');accessPage()})
}


// 0.20.17 · generic table sorting for rendered UI tables.
const tableSortCollator=new Intl.Collator('ro',{numeric:true,sensitivity:'base'});
const tableSortActionHeaders=new Set(['acțiuni','actiuni','actions']);
function tableSortHeaderLabel(th){return String(th?.textContent||'').replace(/\s+/g,' ').trim()}
function tableSortIsEligible(th){
  if(!th||th.dataset.sortable==='false'||th.closest('table')?.dataset.sortable==='false')return false;
  const label=tableSortHeaderLabel(th);if(!label||tableSortActionHeaders.has(label.toLocaleLowerCase('ro')))return false;
  if(th.classList.contains('vm-select-col')||th.querySelector('input[type="checkbox"],button,select'))return false;
  return true;
}
function tableSortCellText(cell){
  if(!cell)return '';
  if(cell.dataset.sortValue!=null)return String(cell.dataset.sortValue).trim();
  const select=cell.querySelector('select');if(select)return String(select.options[select.selectedIndex]?.text||select.value||'').trim();
  const input=cell.querySelector('input');if(input){if(input.type==='checkbox')return input.checked?'1':'0';return String(input.value||'').trim()}
  return String(cell.textContent||'').replace(/\s+/g,' ').trim();
}
function tableSortComparable(raw){
  const text=String(raw??'').trim();if(!text||text==='—'||text==='-')return {kind:'empty',value:''};
  const dateMatch=text.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})(?:[, ]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if(dateMatch){const [,d,m,y,hh='0',mm='0',ss='0']=dateMatch;return {kind:'number',value:Date.UTC(Number(y),Number(m)-1,Number(d),Number(hh),Number(mm),Number(ss))}}
  if(/^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2})?/.test(text)){const parsed=Date.parse(text);if(Number.isFinite(parsed))return {kind:'number',value:parsed}}
  const sizeMatch=text.match(/^(-?[\d.,]+)\s*(B|KB|MB|GB|TB|KIB|MIB|GIB|TIB)$/i);
  if(sizeMatch){const units={B:1,KB:1e3,MB:1e6,GB:1e9,TB:1e12,KIB:1024,MIB:1048576,GIB:1073741824,TIB:1099511627776},n=Number(sizeMatch[1].replace(/\.(?=\d{3}(?:\D|$))/g,'').replace(',','.'));if(Number.isFinite(n))return {kind:'number',value:n*units[sizeMatch[2].toUpperCase()]}}
  const compact=text.replace(/\s/g,'');
  if(/^-?\d{1,3}(?:\.\d{3})*(?:,\d+)?%?$/.test(compact)){const n=Number(compact.replace('%','').replace(/\./g,'').replace(',','.'));if(Number.isFinite(n))return {kind:'number',value:n}}
  if(/^-?\d+(?:[.,]\d+)?%?$/.test(compact)){const n=Number(compact.replace('%','').replace(',','.'));if(Number.isFinite(n))return {kind:'number',value:n}}
  return {kind:'text',value:text};
}
function tableSortCompare(a,b){
  if(a.kind==='empty'&&b.kind==='empty')return 0;if(a.kind==='empty')return 1;if(b.kind==='empty')return -1;
  if(a.kind==='number'&&b.kind==='number')return a.value-b.value;
  return tableSortCollator.compare(String(a.value),String(b.value));
}
function tableSortGroups(tbody){
  const rows=[...tbody.rows],groups=[];
  for(let i=0;i<rows.length;i++){
    const row=rows[i];if(row.classList.contains('audit-detail-row'))continue;
    const group=[row];while(i+1<rows.length&&rows[i+1].classList.contains('audit-detail-row'))group.push(rows[++i]);groups.push(group);
  }
  return groups;
}
function sortTableByHeader(th){
  const table=th.closest('table'),tbody=table?.tBodies?.[0];if(!table||!tbody)return;
  const headerRow=th.parentElement,index=[...headerRow.children].indexOf(th);if(index<0)return;
  const currentColumn=Number(table.dataset.sortColumn),currentDirection=table.dataset.sortDirection||'';
  const direction=currentColumn===index&&currentDirection==='asc'?'desc':'asc',factor=direction==='asc'?1:-1;
  const groups=tableSortGroups(tbody).map((group,original)=>({group,original,key:tableSortComparable(tableSortCellText(group[0].cells[index]))}));
  groups.sort((a,b)=>{const cmp=tableSortCompare(a.key,b.key);return cmp?cmp*factor:a.original-b.original});
  const fragment=document.createDocumentFragment();groups.forEach(({group})=>group.forEach(row=>fragment.appendChild(row)));tbody.appendChild(fragment);
  table.dataset.sortColumn=String(index);table.dataset.sortDirection=direction;
  [...table.tHead.querySelectorAll('th')].forEach(header=>{header.classList.remove('sort-asc','sort-desc');if(header.classList.contains('sortable-column'))header.setAttribute('aria-sort','none')});
  th.classList.add(direction==='asc'?'sort-asc':'sort-desc');th.setAttribute('aria-sort',direction==='asc'?'ascending':'descending');
  th.title=direction==='asc'?'Sortat crescător · click pentru descrescător':'Sortat descrescător · click pentru crescător';
}
function enhanceSortableTables(root=document){
  const tables=[];if(root?.matches?.('table'))tables.push(root);root?.querySelectorAll?.('table').forEach(table=>tables.push(table));
  tables.forEach(table=>{if(!table.tHead||!table.tBodies.length||table.dataset.sortable==='false')return;const row=table.tHead.rows[table.tHead.rows.length-1];if(!row)return;[...row.cells].forEach(th=>{if(!tableSortIsEligible(th))return;th.classList.add('sortable-column');th.setAttribute('tabindex','0');th.setAttribute('aria-sort',th.getAttribute('aria-sort')||'none');th.title=th.title||'Sortează rândurile afișate'});});
}
function initSortableTables(){
  enhanceSortableTables(document);
  document.addEventListener('click',event=>{const th=event.target.closest?.('th.sortable-column');if(!th)return;if(event.target.closest('button,a,input,select,label')&&event.target!==th)return;sortTableByHeader(th)});
  document.addEventListener('keydown',event=>{const th=event.target.closest?.('th.sortable-column');if(!th||!['Enter',' '].includes(event.key))return;event.preventDefault();sortTableByHeader(th)});
  const observer=new MutationObserver(mutations=>mutations.forEach(mutation=>mutation.addedNodes.forEach(node=>{if(node.nodeType===1)enhanceSortableTables(node)})));observer.observe(document.body,{childList:true,subtree:true});
}
initSortableTables();

document.getElementById('logoutButton').onclick=async()=>{await api('/api/v1/auth/logout',{method:'POST'});location.href='/login'};
document.getElementById('themeButton').onclick=()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;localStorage.setItem('vm-doc-theme',next)};
const savedTheme=localStorage.getItem('vm-doc-theme');if(savedTheme)document.documentElement.dataset.theme=savedTheme;
bindRichTextToolbars();
enhanceSearchableSelects(document);searchableSelectObserver.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['open','disabled','multiple']});
window.addEventListener('hashchange',route);
document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
init();

// --- 0.19.9 UI consistency overrides ---
function queryWithoutPaging(query){const p=new URLSearchParams(query||'');p.delete('page');p.delete('page_size');return p.toString()}
function updateBackupExportLink(){const link=document.getElementById('exportVeeamVMs');if(!link)return;const q=queryWithoutPaging(veeamVMQuery());link.href=`/api/v1/veeam/vms/export${q?`?${q}`:''}`}
function updateMonitoringExportLinks(){const vm=document.getElementById('exportMonitoringVMs'),target=document.getElementById('exportMonitoringTargets');if(vm){const q=queryWithoutPaging(monitoringVMQuery());vm.href=`/api/v1/monitoring/vms/export${q?`?${q}`:''}`}if(target){const q=queryWithoutPaging(monitoringTargetQuery());target.href=`/api/v1/monitoring/targets/export${q?`?${q}`:''}`}}
function backupSectionNavigation(selected){const items=[['backup','Backup','Protecție și stare pe VM'],['sources','Surse & sincronizări','Veeam și istoric sincronizare']];return `<nav class="monitoring-section-tabs backup-section-tabs" aria-label="Secțiuni backup">${items.map(([code,label,help])=>`<a href="#backup/${code}" class="${selected===code?'active':''}"><span>${e(label)}</span><small>${e(help)}</small></a>`).join('')}</nav>`}
async function backupPage(section='backup'){
  section=section==='sources'?'sources':'backup';pageMeta('Backup','Veeam Backup & Replication · protecție, retenție, GFS, storage și sincronizare');
  if((location.hash||'')==='#backup')history.replaceState(null,'','#backup/backup');
  const nav=backupSectionNavigation(section);
  if(section==='sources'){
    const paging=state.veeamRunPaging||{page:1,pageSize:10};const [sources,runs]=await Promise.all([api('/api/v1/veeam/sources'),api(`/api/v1/veeam/sync-runs?page=${paging.page}&page_size=${paging.pageSize}`)]);state.veeamSources=Array.isArray(sources)?sources:[];
    const sourceRows=state.veeamSources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${e(s.username)}</td><td class="mono">${e(s.api_version||'—')}</td><td>${veeamIntervalLabel(s.sync_interval_minutes)}<div class="muted">${s.enabled?'Activ':'Dezactivat'}</div></td><td>${dt(s.last_success_at)}${s.last_sync_at?`<div class="muted">Încercare: ${dt(s.last_sync_at)}</div>`:''}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions">${can('veeam.manage')?`<button class="small secondary veeam-action" data-action="test" data-id="${s.id}">Test</button><button class="small veeam-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary veeam-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger veeam-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
    const tools=can('veeam.manage')?'<button id="syncAllVeeam">Sincronizează toate</button><button id="newVeeam" class="secondary">Adaugă sursă</button>':'';
    const hint=`<div class="baseline-hint"><strong>Corelare:</strong><span>vm-doc corelează după <b>numele exact al VM-ului</b> și citește atât obiectele de backup, cât și VM-urile configurate în <b>virtualMachines.includes</b>. Storage-ul, programarea, retenția și politicile GFS sunt păstrate separat de declarațiile cron administrate manual.</span></div>`;
    content.innerHTML=`<div class="backup-workspace">${nav}${panel('Surse Veeam',`${hint}${sourceRows?`<div class="table-wrap"><table><thead><tr><th>Sursă</th><th>Utilizator</th><th>REST API</th><th>Program</th><th>Ultima sincronizare</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse Veeam configurate.')}`,tools)}${panel('Ultimele sincronizări',renderVeeamRuns(runs))}</div>`;
    document.getElementById('newVeeam')?.addEventListener('click',()=>openVeeam());document.getElementById('syncAllVeeam')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/veeam/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări Veeam introduse în coadă.`);setTimeout(()=>backupPage('sources'),1200)}catch(err){toast(err.message,true)}});content.querySelectorAll('.veeam-action').forEach(b=>b.addEventListener('click',()=>veeamAction(b.dataset.action,Number(b.dataset.id))));content.querySelectorAll('.veeam-run-page').forEach(b=>b.addEventListener('click',()=>{const page=Number(b.dataset.page);if(page>0&&page!==state.veeamRunPaging.page){state.veeamRunPaging.page=page;backupPage('sources')}}));document.getElementById('veeamRunPageSize')?.addEventListener('change',event=>{state.veeamRunPaging.pageSize=Number(event.target.value);state.veeamRunPaging.page=1;backupPage('sources')});return;
  }
  await loadEnvironmentCatalogue();
  const vmBackups=await api(`/api/v1/veeam/vms?${veeamVMQuery()}`);
  const cards=`<div class="cards backup-summary-cards"><div class="card"><div class="label">Toate VM-urile</div><div id="backupTotal" class="value">${Number(vmBackups.total||0)}</div><div class="muted">Conform filtrelor curente</div></div><div class="card"><div class="label">VM protejate</div><div id="backupProtected" class="value">0</div><div id="backupProtectedPct" class="backup-percent">0%</div></div><div class="card"><div class="label">În job Veeam</div><div id="backupConfigured" class="value">0</div><div id="backupConfiguredPct" class="backup-percent">0%</div></div><div class="card"><div class="label">Așteaptă primul backup</div><div id="backupWaiting" class="value">0</div><div id="backupWaitingPct" class="backup-percent">0%</div></div><div class="card"><div class="label">VM neprotejate</div><div id="backupUnprotected" class="value">0</div><div id="backupUnprotectedPct" class="backup-percent">0%</div></div><div class="card"><div class="label">Backup în afara jobului</div><div id="backupStale" class="value">0</div><div id="backupStalePct" class="backup-percent">0%</div></div><div class="card"><div class="label">Neverificate</div><div id="backupNever" class="value">0</div><div id="backupNeverPct" class="backup-percent">0%</div></div><div class="card"><div class="label">Failed / Warning</div><div id="backupFailedWarning" class="value compact">0 / 0</div></div></div>`;
  content.innerHTML=`<div class="backup-workspace">${nav}${cards}${panel('Backup pe VM-uri',`<div id="veeamVMTableArea">${renderVeeamVMs(vmBackups)}</div>`,`<a id="exportVeeamVMs" class="button secondary" href="/api/v1/veeam/vms/export">Export Excel</a>`)}</div>`;updateVeeamSummaryCards(vmBackups);bindVeeamVMControls();updateBackupExportLink();
}

function serviceExportQuery(){const f=state.serviceFilters,p=new URLSearchParams();if(f.q)p.set('q',f.q);if(f.domain)p.set('domain',f.domain);if(f.category)p.set('category',f.category);if(f.criticality)p.set('criticality',f.criticality);if(f.docStatus)p.set('doc_status',f.docStatus);if(f.common)p.set('common',f.common);return p.toString()}
function renderInternalServicesCatalog(){
  const f=state.serviceFilters;f.page=Number(f.page||1);f.pageSize=Number(f.pageSize||10);const filtered=internalServicesCache.filter(service=>serviceMatchesFilters(service,f)),total=filtered.length,pages=Math.max(1,Math.ceil(total/f.pageSize));if(f.page>pages)f.page=pages;const startIndex=(f.page-1)*f.pageSize,visible=filtered.slice(startIndex,startIndex+f.pageSize);
  const active=internalServicesCache.filter(service=>service.active).length,linkedVMs=internalServicesCache.reduce((sum,service)=>sum+Number(service.vm_count||0),0),configured=internalServicesCache.filter(service=>Number(service.role_mapping_count||0)>0).length;
  const domains=[...new Set(internalServicesCache.flatMap(s=>(s.classifications||[]).map(c=>c.architectural_domain)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro')),categories=[...new Set(internalServicesCache.flatMap(s=>(s.classifications||[]).map(c=>c.itil_category)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro')),option=(v,current)=>`<option value="${e(v)}" ${v===current?'selected':''}>${e(v)}</option>`;
  const rows=visible.map(service=>`<tr><td><a href="#services/${service.id}"><strong>${e(service.name)}</strong></a>${service.is_common?` <span class="common-service-pill ${service.implicit_global?'global':''}">${service.implicit_global?'GLOBAL':'COMUN'}</span>`:''}${service.description?`<div class="muted service-description-crop" title="${e(service.description)}">${e(cropText(service.description))}</div>`:''}</td><td>${serviceClassificationSummary(service.classifications)}</td><td>${serviceSolutionSummary(service.solution_types)}</td><td class="mono">${e(service.service_code||'—')}</td><td>${criticalityBadge(service.criticality)}</td><td>${badge(service.documentation_status||'draft')}</td><td>${service.vm_count||0}</td><td>${service.dependency_count||0}</td><td>${service.retired?badge('retired'):(service.active?badge('active'):badge('disabled'))}</td></tr>`).join('');
  const filters=`<div class="service-filter-shell ui-filter-shell"><label class="service-search-field"><span>Căutare serviciu</span><input id="serviceSearch" type="search" value="${e(f.q)}" placeholder="Denumire, cod sau descriere"></label><div class="service-filter-grid"><label><span>Domeniu</span><select id="serviceDomainFilter"><option value="">Toate domeniile</option>${domains.map(v=>option(v,f.domain)).join('')}</select></label><label><span>Categorie</span><select id="serviceCategoryFilter"><option value="">Toate categoriile</option>${categories.map(v=>option(v,f.category)).join('')}</select></label><label><span>Criticitate</span><select id="serviceCriticalityFilter"><option value="">Toate</option>${Object.entries(criticalityLabels).map(([v,l])=>`<option value="${v}" ${f.criticality===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label><span>Documentație</span><select id="serviceDocFilter"><option value="">Toate</option>${Object.entries(documentationStatusLabels).map(([v,l])=>`<option value="${v}" ${f.docStatus===v?'selected':''}>${e(l)}</option>`).join('')}</select></label><label><span>Tip serviciu</span><select id="serviceCommonFilter"><option value="">Toate serviciile</option><option value="normal" ${f.common==='normal'?'selected':''}>Servicii aplicație</option><option value="common" ${f.common==='common'?'selected':''}>Servicii comune</option><option value="global" ${f.common==='global'?'selected':''}>Globale implicite</option></select></label></div><div class="service-filter-actions"><div id="serviceActiveFilters" class="vm-active-filters">${serviceActiveFilterHTML()}</div><button id="clearServiceFilters" type="button" class="secondary service-clear-filter">Resetează filtrele</button></div></div>`;
  const from=total?startIndex+1:0,to=Math.min(startIndex+f.pageSize,total),pager=`<div class="pagination"><span>Afișate ${from.toLocaleString('ro-RO')}–${to.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="servicePageSize">${pageSizeOptions(f.pageSize,[10,25,50,100,200])}</select></label>${paginationButtons(f.page,pages,'service-page')}</div></div>`;
  const exportQ=serviceExportQuery(),tools=`<a class="button secondary" href="/api/v1/services/export${exportQ?`?${exportQ}`:''}">Export Excel</a>${can('services.manage')?'<button id="newInternalService">Adaugă serviciu</button>':''}`;
  content.innerHTML=`<div class="service-page-workspace"><div class="cards vm-list-summary-cards"><div class="card"><div class="label">Servicii definite</div><div class="value">${internalServicesCache.length}</div></div><div class="card"><div class="label">Servicii active</div><div class="value">${active}</div></div><div class="card"><div class="label">VM-uri asociate</div><div class="value">${linkedVMs}</div></div><div class="card"><div class="label">Cu roluri observate</div><div class="value">${configured}</div></div></div>${panel('Catalog servicii interne',`${filters}<div class="service-filter-summary muted">${filtered.length} din ${internalServicesCache.length} servicii</div>${rows?`<div class="table-wrap service-catalog-table"><table><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie</th><th>Tip soluție</th><th>Cod</th><th>Criticitate</th><th>Documentație</th><th>VM-uri</th><th>Dependențe</th><th>Stare</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există servicii pentru filtrele selectate.')}${pager}`,tools)}${panel('Model de încadrare','<div class="service-flow"><span>Domeniu</span><b>→</b><span>Categorie</span><b>→</b><span>Serviciu intern</span><b>→</b><span>Layer</span><b>→</b><span>Rol tehnic</span><b>→</b><span>Tip soluție</span></div><p class="muted service-flow-note">Serviciile comune (AD, DNS, LDAP, NTP etc.) sunt modelate ca dependențe și pot fi globale implicit sau asociate explicit.</p>')}</div>`;
  document.getElementById('newInternalService')?.addEventListener('click',()=>openInternalService());let timer;document.getElementById('serviceSearch')?.addEventListener('input',event=>{clearTimeout(timer);const input=event.currentTarget,value=input.value,pos=input.selectionStart??value.length;timer=setTimeout(()=>{f.q=value.trim();f.page=1;renderInternalServicesCatalog();const search=document.getElementById('serviceSearch');if(search){search.focus({preventScroll:true});const p=Math.min(pos,search.value.length);search.setSelectionRange(p,p)}},250)});
  [['serviceDomainFilter','domain'],['serviceCategoryFilter','category'],['serviceCriticalityFilter','criticality'],['serviceDocFilter','docStatus'],['serviceCommonFilter','common']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{f[key]=event.target.value;f.page=1;renderInternalServicesCatalog()}));document.getElementById('clearServiceFilters')?.addEventListener('click',()=>{state.serviceFilters={q:'',domain:'',category:'',criticality:'',docStatus:'',common:'',page:1,pageSize:f.pageSize||10};renderInternalServicesCatalog()});document.querySelectorAll('.service-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==f.page){f.page=page;renderInternalServicesCatalog()}}));document.getElementById('servicePageSize')?.addEventListener('change',event=>{f.pageSize=Number(event.target.value);f.page=1;renderInternalServicesCatalog()});
}

function externalCollapsedPanel(title,body,open=false){return `<details class="panel collapsible-panel external-add-panel" ${open?'open':''}><summary class="collapsible-panel-summary"><span>${e(title)}</span><span class="muted">Click pentru ${open?'închidere':'adăugare'}</span></summary><div class="collapsible-panel-body">${body}</div></details>`}
async function renderExternalNetworks(networks){
  const edit=networks.find(x=>Number(x.id)===Number(state.externalNetworkEdit))||null,rows=networks.map(n=>`<tr><td>${externalNetworkBadge(n)}<div class="muted mono">${e(n.code)}</div></td><td>${e(externalZoneTypeLabels[n.zone_type]||n.zone_type)}</td><td>${externalRiskBadge(n.risk_level)}</td><td>${e(externalTrustLabels[n.trust_level]||n.trust_level)}</td><td class="mono">${e(n.cidrs||'—')}</td><td>${n.system_count||0}</td><td>${n.connection_count||0}</td><td>${n.active?badge('active'):badge('disabled')}</td>${can('external.manage')?`<td><div class="actions"><button class="small secondary edit-external-network" data-id="${n.id}">Editează</button><button class="small danger delete-external-network" data-id="${n.id}" ${Number(n.system_count||0)>0?'disabled title="Rețeaua are sisteme asociate"':''}>Șterge</button></div></td>`:''}</tr>`).join('');
  const editor=can('external.manage')?(edit?panel('Editează rețeaua externă',`<div class="external-edit-shell">${externalNetworkForm(edit)}</div>`):externalCollapsedPanel('Adaugă rețea externă',externalNetworkForm(null))):'';content.innerHTML+=`${editor}${panel('Rețele externe',rows?`<div class="table-wrap"><table><thead><tr><th>Rețea / culoare</th><th>Tip</th><th>Risc</th><th>Trust</th><th>CIDR</th><th>Sisteme</th><th>Conexiuni</th><th>Stare</th>${can('external.manage')?'<th></th>':''}</tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există rețele externe definite.'))}`;bindExternalNetworkForm(edit);document.querySelectorAll('.edit-external-network').forEach(b=>b.addEventListener('click',()=>{state.externalNetworkEdit=Number(b.dataset.id);externalSystemsPage('networks')}));document.querySelectorAll('.delete-external-network').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Ștergi această rețea externă?'))return;try{await api(`/api/v1/external-networks/${b.dataset.id}`,{method:'DELETE'});toast('Rețeaua externă a fost ștearsă.');externalSystemsPage('networks')}catch(err){toast(err.message,true)}}));
}
async function renderExternalSystems(systems,networks){
  const f=state.externalFilters,q=f.q.toLocaleLowerCase('ro'),filtered=systems.filter(item=>(!q||`${item.name} ${item.hostname} ${item.ip_addresses} ${item.owner_organization}`.toLocaleLowerCase('ro').includes(q))&&(!f.network||String(item.network_id||'')===String(f.network))&&(f.status==='all'||(f.status==='active'?item.active:!item.active))),internet=systems.filter(x=>x.active&&x.network_zone_type==='internet').length;
  const filters=`<div class="filterbar external-filterbar ui-filter-shell"><label><span>Caută</span><input id="externalSearch" type="search" value="${e(f.q)}" placeholder="Nume, hostname, IP, organizație"></label><label><span>Rețea</span><select id="externalNetworkFilter"><option value="">Toate</option>${networks.map(n=>`<option value="${n.id}" ${String(f.network)===String(n.id)?'selected':''}>${e(n.name)}</option>`).join('')}</select></label><label><span>Stare</span><select id="externalStatusFilter"><option value="active" ${f.status==='active'?'selected':''}>Active</option><option value="inactive" ${f.status==='inactive'?'selected':''}>Inactive</option><option value="all" ${f.status==='all'?'selected':''}>Toate</option></select></label><button id="externalReset" class="secondary" type="button">Resetează</button></div>`,rows=filtered.map(item=>`<tr><td><a href="#external/${item.id}"><strong>${e(item.name)}</strong></a><div class="muted">${e(externalTypeLabels[item.system_type]||item.system_type)}</div></td><td class="mono">${e(item.hostname||item.ip_addresses||'—')}</td><td>${externalNetworkBadge(item)}</td><td>${externalRiskBadge(item.network_risk_level)}</td><td>${e(item.owner_organization||'—')}</td><td>${item.connection_count||0}</td><td>${item.active?badge('active'):badge('disabled')}</td><td><a class="button-link small secondary" href="#external/${item.id}">Deschide</a></td></tr>`).join('');
  content.innerHTML+=`<div class="cards"><div class="card"><div class="label">Sisteme definite</div><div class="value">${systems.length}</div></div><div class="card"><div class="label">Active</div><div class="value">${systems.filter(x=>x.active).length}</div></div><div class="card"><div class="label">În Internet</div><div class="value">${internet}</div></div><div class="card"><div class="label">Conexiuni</div><div class="value">${systems.reduce((n,x)=>n+Number(x.connection_count||0),0)}</div></div></div>${can('external.manage')?externalCollapsedPanel('Adaugă sistem extern',externalSystemForm(null,networks)):''}${panel('Sisteme externe',`${filters}${rows?`<div class="table-wrap"><table><thead><tr><th>Sistem</th><th>Adresă</th><th>Rețea</th><th>Risc</th><th>Organizație</th><th>Conexiuni</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există sisteme pentru filtrele selectate.')}`)}`;bindExternalSystemForm(null);let timer;document.getElementById('externalSearch')?.addEventListener('input',event=>{clearTimeout(timer);const input=event.currentTarget,pos=input.selectionStart??input.value.length,value=input.value;timer=setTimeout(async()=>{f.q=value.trim();await externalSystemsPage('systems');const next=document.getElementById('externalSearch');if(next){next.focus();const p=Math.min(pos,next.value.length);next.setSelectionRange(p,p)}},200)});document.getElementById('externalNetworkFilter')?.addEventListener('change',event=>{f.network=event.target.value;externalSystemsPage('systems')});document.getElementById('externalStatusFilter')?.addEventListener('change',event=>{f.status=event.target.value;externalSystemsPage('systems')});document.getElementById('externalReset')?.addEventListener('click',()=>{state.externalFilters={q:'',network:'',status:'active'};externalSystemsPage('systems')});
}

// 0.21.31 — shared Security filter summary (same contract as Docker/DB/Web).
// Each control keeps its original ID so the existing data filters, RBAC and API stay unchanged.
const securityFilterNames={
  accounts:{q:'Căutare',type:'Conturi system',login:'Login',password:'Parolă',privileged:'Privilegiat',review:'Review'},
  databases:{q:'Căutare',engine:'Motor',indicator:'Indicator',review:'Review'},
  web:{q:'Căutare',engine:'Motor',coverage:'ACL',action:'Acțiune',warning:'ALLOW ALL',review:'Review'},
  firewall:{q:'Căutare',sourceId:'FortiGate',direction:'Rol VM',risk:'Risc',action:'Acțiune',status:'Status',service:'Serviciu',iface:'Interfață',vdom:'VDOM',review:'Review'},
  'firewall-analysis':{q:'Căutare',sourceId:'FortiGate',vdom:'VDOM',classification:'Clasificare',flag:'Indicator'}
};
function securityFilterValue(key,value){
  const options={yes:'Da',no:'Nu',due:'Necesită review',unreviewed:'Nerevizuit',current:'La zi',
    rules:'Cu reguli',none:'Fără ACL',allowall:'ALLOW ALL',all:'Toate',relevant:'Relevante',
    active:'Activă',locked:'Blocată',empty:'Goală',other:'Alta',source:'VM sursă',destination:'VM destinație',
    vip:'VIP',review:'Necesită verificare',uncorrelated:'Necorelate',correlated:'Corelate',broad:'Prea largi'};
  if(key==='sourceId'){
    const source=(state.fortigateSources||[]).find(x=>String(x.id)===String(value));
    return source?.name||String(value);
  }
  return options[String(value)]||String(value);
}
function securityFilterShell(raw,section,filter){
  const labels=[...raw.matchAll(/<label\b[^>]*>[\s\S]*?<\/label>/g)].map(m=>m[0]);
  if(!labels.length)return raw;
  const reset=(raw.match(/<button\b[^>]*\bid="[^"]*Reset"[^>]*>[\s\S]*?<\/button>/)||[])[0]||'';
  const searchable=labels.findIndex(x=>/type="search"/.test(x));
  const primary=searchable>=0?labels[searchable]:'';
  const advanced=labels.filter((_,i)=>i!==searchable).join('');
  const defaults=section==='accounts'?{type:'relevant'}:section==='firewall-analysis'?{classification:'review'}:{};
  const chips=Object.entries(securityFilterNames[section]||{}).filter(([key])=>{
    const value=filter[key];return value!=null&&String(value)!==''&&String(value)!==String(defaults[key]??'');
  }).map(([key,label])=>`<span class="security-filter-chip">${e(label)}: ${e(securityFilterValue(key,filter[key]))}</span>`).join('');
  const expanded=!!state.securityFilterExpanded?.[section],id=`securityFilters-${section}`;
  return `<div class="security-filter-block" data-security-filter="${e(section)}">
    ${primary?`<div class="security-filter-search">${primary}</div>`:''}
    <section class="security-filter-shell" aria-label="Filtre Securitate">
      <div class="security-filter-summary">
        <div class="security-filter-active"><strong>Filtre:</strong><span class="security-filter-chips">${chips||'<span class="muted">Niciun filtru activ</span>'}</span></div>
        <button type="button" class="security-filter-chevron" aria-controls="${id}" aria-expanded="${expanded}" aria-label="${expanded?'Restrânge':'Extinde'} filtrele" title="${expanded?'Restrânge':'Extinde'} filtrele">⌄</button>
        ${reset||'<span></span>'}
      </div>
      <div id="${id}" class="security-filter-fields" ${expanded?'':'hidden'}><div class="filterbar security-filter-grid">${advanced}</div></div>
    </section>
  </div>`;
}
function bindSecurityFilterShell(section){
  const root=document.querySelector(`[data-security-filter="${section}"]`);if(!root)return;
  const button=root.querySelector('.security-filter-chevron'),fields=root.querySelector('.security-filter-fields');
  button?.addEventListener('click',()=>{
    const open=button.getAttribute('aria-expanded')!=='true';
    state.securityFilterExpanded=state.securityFilterExpanded||{};
    state.securityFilterExpanded[section]=open;
    button.setAttribute('aria-expanded',String(open));
    button.setAttribute('aria-label',open?'Restrânge filtrele':'Extinde filtrele');
    button.title=open?'Restrânge filtrele':'Extinde filtrele';
    fields.hidden=!open;
  });
}

// --- 0.20.63 Security / Access Review ---
function securityNav(selected){const firewallSections=['firewall','firewall-sources','firewall-analysis'],firewallActive=firewallSections.includes(selected),items=[['overview','Dashboard'],['accounts','Conturi VM'],['databases','Database Access'],['web','Web Access Control'],['firewall','Firewall'],['hardening','Hardening']];const primary=`<nav class="monitoring-section-tabs" aria-label="Secțiuni securitate">${items.map(([id,label])=>`<a href="#security/${id}" class="${(id==='firewall'?firewallActive:selected===id)?'active':''}"><span>${e(label)}</span></a>`).join('')}</nav>`;const secondary=firewallActive?`<nav class="vm-detail-subtabs security-firewall-subtabs" aria-label="Secțiuni Firewall"><a href="#security/firewall" class="${selected==='firewall'?'active':''}">1. Caută</a><a href="#security/firewall-sources" class="${selected==='firewall-sources'?'active':''}">2. Surse &amp; Sync</a><a href="#security/firewall-analysis" class="${selected==='firewall-analysis'?'active':''}">3. Analiză Forti</a></nav>`:'';return primary+secondary}
function securityKPI(label,value,help=''){return `<article class="dashboard-kpi"><span>${e(label)}</span><strong>${Number(value||0).toLocaleString('ro-RO')}</strong>${help?`<small>${e(help)}</small>`:''}</article>`}
function securityReviewBadge(review={}){
  if(!review.reviewed_at)return '<span class="badge missing">Nerevizuit</span>';
  return review.due?'<span class="badge missing">Expirat</span>':'<span class="badge active">Revizuit</span>';
}
// 0.21.33 · Un singur contract vizual pentru review în Conturi, DB, Web ACL, Firewall, Rezumat și rapoarte.
// 0.21.34 — 3 coloane review, nu duplicam eticheta Revizuit.
// 0.21.34 — Review compact: 3 coloane reale in tabele, grid in panouri.
function securityReviewCell(vmId,type,key,review={},defaultInterval=12,display={}){
  review=review||{};
  const account=String(display.resource||key||'');
  const button=can('vms.manage')?`<button type="button" class="small secondary security-review" data-vm="${Number(vmId)}" data-type="${e(type)}" data-key="${e(key)}" data-vm-name="${e(display.vmName||'')}" data-resource-name="${e(account)}" data-interval="${Number(review.interval_months||defaultInterval)}" data-justified="${review.reviewed_at?(review.justified===true?'yes':'no'):''}" data-notes="${e(review.notes||'')}">Revizuiește</button>`:'';
  if(!review.reviewed_at){
    return `<div class="security-review-cell security-review-grid" data-security-review-layout="3" data-review-pending="1"><div class="security-review-pending">${button||'<span class="muted">Nerevizuit</span>'}</div></div>`;
  }
  const reviewed=dt(review.reviewed_at);
  const next=review.next_review_at?dt(review.next_review_at):'—';
  return `<div class="security-review-cell security-review-grid" data-security-review-layout="3" data-review-pending="0"><div class="security-review-part"><span class="security-review-part-label">Revizuit</span>${review.due?'<span class="badge missing">Expirat</span>':''}<span class="security-review-reviewed-at">${reviewed}</span></div><div class="security-review-part"><span class="security-review-part-label">De</span><strong>${e(review.reviewed_by||'—')}</strong></div><div class="security-review-part"><span class="security-review-part-label">Next review</span><span class="security-review-next-at">${next}</span>${button?`<span class="security-review-inline-action">${button}</span>`:''}</div></div>`;
}
function securityReviewNotApplicable(){return '<div class="security-review-grid" data-security-review-layout="3" data-review-pending="1"><div class="security-review-pending"><span class="muted">—</span></div></div>'}
function securityReviewContext(button){
  const vmId=Number(button.dataset.vm),type=button.dataset.type||'';
  const row=button.closest('tr');
  const link=[...(row?.querySelectorAll('a[href]')||[])].find(a=>(a.getAttribute('href')||'').startsWith(`#vms/${vmId}/`));
  const records=[...(state.securityData?.accounts||[]),...(state.securityData?.databases||[]),...(state.securityData?.web_sites||[])];
  const vmRecord=records.find(x=>Number(x.vm_id)===vmId&&x.vm_name);
  const vmName=String(button.dataset.vmName||link?.textContent||vmRecord?.vm_name||`VM #${vmId}`).trim();
  const visibleResource=row?.querySelector('td.mono strong, td.mono')?.textContent?.trim();
  const resource=String(button.dataset.resourceName||((type==='vm_account'||type==='database_principal')?visibleResource:'')||button.dataset.key||'—');
  return {vmName,resource,vmId};
}
// Rulata numai la randarea unei pagini Securitate, nu prin observarea intregii aplicatii.
// Mutarea nodurilor, nu recrearea lor, pastreaza datele si evenimentele atasate butoanelor.
function securityReviewExpandTableColumns(root=document){
  const wrappers=[...root.querySelectorAll('[data-security-review-layout="3"]:not([data-security-review-done])')];
  for(const wrapper of wrappers){
    const td=wrapper.parentElement;
    if(!td||td.tagName!=='TD'){wrapper.dataset.securityReviewDone='1';continue;}
    const table=td.closest('table'),head=table?.tHead?.rows?.[table.tHead.rows.length-1];
    if(!table||!head){wrapper.dataset.securityReviewDone='1';continue;}
    let column;
    if(table.dataset.securityReviewColumn===undefined){
      column=td.cellIndex;
      const oldHead=head.cells[column];
      if(!oldHead||oldHead.textContent.trim()!=='Review'){wrapper.dataset.securityReviewDone='1';continue;}
      const cells=['Revizuit','De','Next review'].map(label=>{const th=document.createElement('th');th.textContent=label;return th;});
      oldHead.replaceWith(...cells);
      table.dataset.securityReviewColumn=String(column);
      table.classList.add('security-review-three-columns');
    }
    if(wrapper.dataset.reviewPending==='1'){
      td.colSpan=3;td.classList.add('security-review-merged-td');
      td.replaceChildren(wrapper.querySelector('.security-review-pending')||wrapper);
    }else{
      const parts=[...wrapper.querySelectorAll(':scope > .security-review-part')];
      if(parts.length!==3){wrapper.dataset.securityReviewDone='1';continue;}
      const cells=parts.map((part,i)=>{const cell=document.createElement('td');cell.className=`security-review-table-td security-review-table-td-${i}`;cell.appendChild(part);return cell;});
      td.replaceWith(...cells);
    }
  }
}
function securityReviewDialog(button){
  document.getElementById('securityReviewDialog')?.remove();
  const typeLabels={vm_account:'Cont VM',database:'Instanță DB',database_principal:'Utilizator / rol DB',database_grants:'Granturi DB per utilizator',database_hba:'Regulă PostgreSQL HBA',web:'Web ACL',firewall:'Regulă FortiGate',firewall_local:'Regulă Firewall local'};
  const title=typeLabels[button.dataset.type]||'Resursă';
  const current=[6,12].includes(Number(button.dataset.interval))?Number(button.dataset.interval):12;
  const justified=button.dataset.justified||'';
  const reviewContext=securityReviewContext(button);
  const dialog=document.createElement('dialog');dialog.id='securityReviewDialog';dialog.className='beneficiary-modal security-review-dialog';
  dialog.innerHTML=`<div class="beneficiary-modal-head"><div><strong>Revizuire securitate</strong><div class="muted">${e(title)}</div><div class="security-review-dialog-resource"><span>VM: <strong data-review-vm-name>${e(reviewContext.vmName)}</strong></span><span>${button.dataset.type==='vm_account'?'Cont':'Resursă'}: <strong>${e(reviewContext.resource)}</strong></span></div></div><button type="button" class="small secondary" data-review-cancel aria-label="Închide">Închide</button></div><form id="securityReviewForm" class="beneficiary-modal-body"><p class="muted security-review-dialog-intro">Verifică accesul/configurația și documentează decizia. Persoana care revizuiește și data sunt preluate automat din sesiunea curentă.</p><div class="security-review-dialog-fields"><label><span>Interval până la următorul review</span><select name="interval_months" required><option value="6" ${current===6?'selected':''}>6 luni</option><option value="12" ${current===12?'selected':''}>12 luni</option></select></label><label><span>Accesul / configurația este justificată?</span><select name="justified" required><option value="" ${!justified?'selected':''} disabled>Alege o decizie</option><option value="yes" ${justified==='yes'?'selected':''}>Da</option><option value="no" ${justified==='no'?'selected':''}>Nu</option></select></label></div><label class="security-review-notes-label"><span>Observații</span><textarea name="notes" rows="4" maxlength="2000" placeholder="Motivul deciziei, constatările sau acțiunile necesare…">${e(button.dataset.notes||'')}</textarea></label><p class="security-review-dialog-error" role="alert" hidden></p><div class="beneficiary-modal-actions"><button type="button" class="secondary" data-review-cancel>Anulează</button><button type="submit" class="primary" id="securityReviewSave">Salvează revizia</button></div></form>`;
  document.body.appendChild(dialog);
  if(reviewContext.vmName===`VM #${reviewContext.vmId}`){
    Promise.resolve(api(`/api/v1/vms/${reviewContext.vmId}`)).then(payload=>{
      const vm=payload?.vm||payload;
      const name=vm?.name||vm?.display_name||vm?.hostname||vm?.fqdn;
      const field=dialog.querySelector('[data-review-vm-name]');
      if(name&&field)field.textContent=String(name);
    }).catch(()=>{});
  }

  dialog.querySelectorAll('[data-review-cancel]').forEach(cancel=>cancel.addEventListener('click',()=>dialog.close()));
  dialog.addEventListener('close',()=>dialog.remove(),{once:true});
  dialog.showModal();
  dialog.querySelector('select[name="justified"]')?.focus();
  return dialog;
}
async function submitSecurityReview(button){
  const dialog=securityReviewDialog(button),form=dialog.querySelector('#securityReviewForm');
  form.addEventListener('submit',async event=>{
    event.preventDefault();if(!form.reportValidity())return;
    const interval=Number(form.elements.interval_months.value),justified=form.elements.justified.value;
    if(![6,12].includes(interval)||!['yes','no'].includes(justified))return;
    const save=form.querySelector('#securityReviewSave'),error=form.querySelector('.security-review-dialog-error');
    save.disabled=true;save.textContent='Se salvează…';error.hidden=true;
    try{
      await api('/api/v1/security/review',{method:'PUT',body:JSON.stringify({vm_id:Number(button.dataset.vm),resource_type:button.dataset.type,resource_key:button.dataset.key,interval_months:interval,justified:justified==='yes',notes:form.elements.notes.value.trim()})});
      dialog.close();toast('Review salvat.');state.securityData=null;state.securityDataSection='';
      const parts=(location.hash||'').slice(1).split('/');
      if(parts[0]==='vms'&&/^\d+$/.test(parts[1]||''))await vmDetail(Number(parts[1]),parts[2]||'security');
      else if(parts[0]==='reports'&&parts[1]==='security-reviews')await reportsPage('security-reviews');
      else await securityPage(parts[1]||'overview',true);
    }catch(err){
      error.textContent=err.message||'Nu s-a putut salva revizia.';error.hidden=false;toast(error.textContent,true);
    }finally{save.disabled=false;save.textContent='Salvează revizia';}
  });
}
// Bulk operations always enumerate their targets server-side for a single VM or DB instance.
// A page filter is for navigation only; it never silently broadens the scope to all VMs.
function securityBulkButton(vmId,scope,label,count,instanceId=0,vmName=''){
  if(!can('vms.manage')||!Number(count))return '';
  return `<div class="security-bulk-bar"><span class="muted">${e(label)} · ${Number(count)} obiecte</span><button type="button" class="small secondary security-review-bulk" data-vm="${Number(vmId)}" data-scope="${e(scope)}" data-label="${e(label)}" data-count="${Number(count)}" data-instance="${Number(instanceId)||0}" data-vm-name="${e(vmName)}">Revizuiește secțiunea</button></div>`;
}
function securityBulkVMSelector(scope,rows){
  if(!can('vms.manage'))return '';
  const vmCount=new Map();
  for(const x of rows||[]){if(!x.vm_id)continue;const id=Number(x.vm_id);const n=scope==='database_principals'?(x.principals||[]).filter(p=>!securityDBBuiltInRole(x,p)).length:1;const found=vmCount.get(id)||{name:x.vm_name||`VM #${id}`,count:0};found.count+=n;vmCount.set(id,found);}
  if(!vmCount.size)return '';
  const options=[...vmCount].sort((a,b)=>a[1].name.localeCompare(b[1].name)).map(([id,x])=>`<option value="${id}">${e(x.name)} (${x.count})</option>`).join('');
  return `<div class="security-bulk-picker"><label><span>Revizie colectivă pe VM (inventarul complet al secțiunii)</span><select class="security-bulk-vm-select"><option value="">Alege VM…</option>${options}</select></label><button type="button" class="small secondary security-review-bulk" data-scope="${e(scope)}" data-label="${scope==='accounts'?'Conturi relevante':scope==='web'?'Web ACL':'Principali DB'}" data-vm="" data-count="0" disabled>Revizuiește secțiunea</button></div>`;
}
function submitSecurityBulkReview(button){
  const vmId=Number(button.dataset.vm),scope=button.dataset.scope,instanceId=Number(button.dataset.instance)||0;
  if(!vmId||!['accounts','database_principals','database_grants','database_hba','web','firewall','firewall_local'].includes(scope))return;
  document.getElementById('securityReviewDialog')?.remove();
  const dlg=document.createElement('dialog');dlg.id='securityReviewDialog';dlg.className='beneficiary-modal security-review-dialog';
  const vmName=String(button.dataset.vmName||button.closest('.security-bulk-picker')?.querySelector('select option:checked')?.textContent||button.closest('.security-db-card')?.querySelector('.security-db-title')?.textContent||'').trim();
  dlg.classList.add('security-review-dialog--bulk');
  const subject=String(button.dataset.label||scope);
  const instanceNote=instanceId?'în această instanță DB':'pe această VM';
  dlg.innerHTML=`<div class="beneficiary-modal-head security-bulk-modal-head"><div><strong>Revizuire colectivă</strong><div class="muted">${e(subject)} · ${e(vmName||`VM #${vmId}`)}</div></div><button type="button" class="small secondary" data-review-cancel>Închide</button></div><form class="security-bulk-form"><div class="security-bulk-scroll"><p class="security-bulk-warning"><strong>Aplicare pentru toate obiectele eligibile ${e(instanceNote)}.</strong> Reviziile existente ale obiectelor selectate vor fi înlocuite. Celelalte categorii și VM-uri nu sunt afectate.</p><div class="security-review-dialog-fields"><label><span>Următoarea revizie</span><select name="interval_months" required><option value="6">6 luni</option><option value="12">12 luni</option></select></label><label><span>Acces justificat pentru toate obiectele?</span><select name="justified" required><option value="" selected disabled>Alege o decizie</option><option value="yes">Da</option><option value="no">Nu</option></select></label></div><label class="security-review-notes-label"><span>Observații · obligatoriu, minimum 10 caractere</span><textarea name="notes" rows="3" maxlength="2000" minlength="10" required placeholder="Ce ai verificat și care este concluzia…"></textarea></label><label class="security-bulk-confirm"><input type="checkbox" name="confirmed" required><span>Confirm că am verificat toate obiectele vizate și accept înlocuirea reviziilor existente.</span></label></div><div class="security-bulk-footer"><p class="security-review-dialog-error" role="alert" hidden></p><div class="security-bulk-footer-actions"><button type="button" class="secondary" data-review-cancel>Anulează</button><button type="submit" class="primary">Aplică revizia</button></div></div></form>`;
  document.body.appendChild(dlg);dlg.querySelectorAll('[data-review-cancel]').forEach(b=>b.addEventListener('click',()=>dlg.close()));dlg.addEventListener('close',()=>dlg.remove(),{once:true});dlg.showModal();
  const form=dlg.querySelector('form');form.addEventListener('submit',async ev=>{
    ev.preventDefault();if(!form.reportValidity())return;
    const save=form.querySelector('button[type="submit"]'),errEl=form.querySelector('.security-review-dialog-error');save.disabled=true;save.textContent='Se salvează…';errEl.hidden=true;
    try{
      const result=await api('/api/v1/security/review/bulk',{method:'PUT',body:JSON.stringify({vm_id:vmId,scope,instance_id:instanceId,interval_months:Number(form.elements.interval_months.value),justified:form.elements.justified.value==='yes',notes:form.elements.notes.value.trim(),confirmed:true})});
      dlg.close();toast(`Revizie salvată pentru ${Number(result.updated||0)} obiecte.`);state.securityData=null;
      const parts=(location.hash||'').slice(1).split('/');if(parts[0]==='vms')await vmDetail(vmId,parts[2]||'security');else await securityPage(parts[1]||'overview',true);
    }catch(ex){errEl.textContent=ex.message||'Eroare la revizia colectivă';errEl.hidden=false;toast(errEl.textContent,true)}finally{save.disabled=false;save.textContent='Aplică revizia'}
  });
}
function bindSecurityReviewButtons(root=document){securityReviewExpandTableColumns(root);bindFirewallPolicyDetails(root);bindSecurityDatabaseCards(root);root.querySelectorAll('.security-review').forEach(button=>button.addEventListener('click',ev=>{if(button.closest('summary')){ev.preventDefault();ev.stopPropagation();}submitSecurityReview(button)}));root.querySelectorAll('.security-review-bulk').forEach(button=>button.addEventListener('click',()=>submitSecurityBulkReview(button)));root.querySelectorAll('.security-bulk-vm-select').forEach(select=>select.addEventListener('change',()=>{const btn=select.closest('.security-bulk-picker').querySelector('button.security-review-bulk');btn.dataset.vm=select.value;btn.disabled=!select.value;}));bindSecurityWebControls(root);}
function securityPasswordBadge(row){if(row.password_locked)return '<span class="badge missing">Locked</span>';if(row.password_status==='password_set'||row.password_status==='password_set_or_external'||row.password_status==='active')return '<span class="badge active">Parolă activă</span>';if(row.password_status==='empty')return '<span class="badge missing">Parolă goală</span>';return `<span class="badge">${e(row.password_status||'necunoscut')}</span>`}
function securityPasswordCategory(row){if(row.password_locked)return 'locked';if(row.password_status==='password_set'||row.password_status==='password_set_or_external'||row.password_status==='active')return 'active';if(row.password_status==='empty')return 'empty';return 'other'}
function securityAccountRelevant(row){if(String(row.username||'').toLowerCase()==='root')return true;if(!row.system_account)return true;const password=securityPasswordCategory(row);return !!row.login_capable||!!row.privileged||password==='active'||password==='empty'}
function securityReviewMatches(review={},filter=''){if(!filter)return true;if(filter==='due')return !!review.due;if(filter==='unreviewed')return !review.reviewed_at;if(filter==='current')return !!review.reviewed_at&&!review.due;return true}
function securityPageInfo(filter,total,values=[10,20,25,50,100,200]){const allowed=values.includes(Number(filter.pageSize))?Number(filter.pageSize):values[0];filter.pageSize=allowed;const pages=Math.max(1,Math.ceil(total/allowed));filter.page=Math.min(Math.max(1,Number(filter.page)||1),pages);const offset=(filter.page-1)*allowed;return {page:filter.page,pageSize:allowed,pages,total,offset,end:Math.min(offset+allowed,total)}}
function securityPager(info,prefix,values=[10,20,25,50,100,200]){if(!info.total)return '';const start=info.offset+1;return `<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${info.end.toLocaleString('ro-RO')} din ${info.total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="${e(prefix)}PageSize">${pageSizeOptions(info.pageSize,values)}</select></label>${paginationButtons(info.page,info.pages,`${prefix}-page`)}</div></div>`}
function securityAccountTypeMatches(row,type){if(type==='all')return true;if(type==='system')return !!row.system_account&&String(row.username||'').toLowerCase()!=='root';if(type==='users')return !row.system_account||String(row.username||'').toLowerCase()==='root';return securityAccountRelevant(row)}
function securityAccountSearch(row,q){if(!q)return true;return `${row.vm_name||''} ${row.username||''} ${row.uid??''} ${row.shell||''} ${(row.groups||[]).join(' ')}`.toLocaleLowerCase('ro').includes(q)}
function securityPolicyStatusBadge(status){const v=String(status||'unknown').toLowerCase();if(v==='enforced')return '<span class="badge active">Enforced</span>';if(v==='partial')return '<span class="badge missing">Partial</span>';if(v==='not_enforced'||v==='not_configured')return '<span class="badge failed">Not enforced</span>';if(v==='configured')return '<span class="badge">Configured</span>';return '<span class="badge">Unknown</span>'}
function securityPolicyCheck(policy,code){return (policy?.checks||[]).find(x=>String(x.code||'')===code)||null}
function securityPolicyCheckHTML(policy,code){const c=securityPolicyCheck(policy,code);if(!c)return '<span class="muted">—</span>';return `${securityPolicyStatusBadge(c.status)}${c.value?`<div class="muted mono">${e(c.value)}</div>`:''}`}
function securityPolicyChecksDetails(policy){const checks=policy?.checks||[];if(!checks.length)return '<span class="muted">—</span>';const rows=checks.map(c=>`<tr><td>${e(c.code||'—')}</td><td>${securityPolicyStatusBadge(c.status)}</td><td class="mono">${e(c.value||'—')}</td><td>${e(c.detail||'—')}${c.source?`<div class="muted mono">${e(c.source)}</div>`:''}</td></tr>`).join('');return `<details><summary>Detalii (${checks.length})</summary><div class="table-wrap"><table><thead><tr><th>Verificare</th><th>Status</th><th>Valoare</th><th>Detaliu / sursă</th></tr></thead><tbody>${rows}</tbody></table></div></details>`}
function securityPasswordPoliciesBody(data){const policies=data?.password_policies||[],s=data?.summary||{};const cards=`<div class="cards report-summary">${securityKPI('VM-uri cu policy',s.password_policies??policies.length)}${securityKPI('Enforced',s.password_enforced)}${securityKPI('Partial',s.password_partial)}${securityKPI('Not enforced',s.password_not_enforced)}${securityKPI('Unknown',s.password_unknown)}</div>`;if(!policies.length)return panel('Politici parole',`${cards}<div class="notice info"><strong>Nu există încă date de enforcement.</strong><span>Necesită vm-doc-agent 1.7.15+ sau un agent legacy compatibil și o colectare nouă pe VM.</span></div>`);const rows=policies.map(p=>`<tr><td><a href="#vms/${p.vm_id}/security-accounts"><strong>${e(p.vm_name)}</strong></a><div class="muted">${e(p.os_family||'—')}</div></td><td>${securityPolicyStatusBadge(p.enforcement_status)}</td><td>${securityPolicyCheckHTML(p,'complexity')}</td><td>${securityPolicyCheckHTML(p,'minimum_length')}</td><td>${securityPolicyCheckHTML(p,'history')}</td><td>${securityPolicyCheckHTML(p,'min_age')}</td><td>${securityPolicyCheckHTML(p,'max_age')}</td><td>${securityPolicyCheckHTML(p,'warning_age')}</td><td>${securityPolicyChecksDetails(p)}</td></tr>`).join('');return panel('Politici parole',`${cards}<div class="table-wrap"><table><thead><tr><th>VM</th><th>Status</th><th>Complexitate</th><th>Lungime minimă</th><th>History</th><th>Min age</th><th>Max age</th><th>Warn age</th><th>Verificări</th></tr></thead><tbody>${rows}</tbody></table></div>`,'<span class="muted">Politica efectivă: agent 1.7.15+ o raportează direct; pentru SLES9 legacy serverul 0.20.95 derivează verificările din login.defs, PAM și /etc/shadow.</span>')}
// 0.21.32: VM password policies: compact summary left, full checks table right,
// collapsed by default. The global security policies report keeps its existing layout.
function securityPasswordPolicyVMPanel(policy){
  const status=policy?securityPolicyStatusBadge(policy.enforcement_status):'<span class="badge">N/A</span>';
  const checks=policy?.checks||[];
  const issues=checks.filter(c=>!['enforced','configured'].includes(String(c.status||'').toLowerCase())).length;
  const stats=`<aside class="vm-password-policy-stats" aria-label="Sumar politică parole">
    <div class="vm-password-policy-stat"><span>Enforcement</span><strong>${status}</strong></div>
    <div class="vm-password-policy-stat"><span>Verificări</span><strong>${checks.length}</strong></div>
    <div class="vm-password-policy-stat"><span>Necesită atenție</span><strong>${issues}</strong></div>
  </aside>`;
  const rows=checks.map(c=>`<tr><td class="mono">${e(c.code||'—')}</td><td>${securityPolicyStatusBadge(c.status)}</td><td class="mono">${e(c.value||'—')}</td><td>${e(c.detail||'—')}${c.source?`<div class="muted mono">${e(c.source)}</div>`:''}</td></tr>`).join('');
  const checksTable=rows?`<div class="table-wrap"><table><thead><tr><th>Verificare</th><th>Status</th><th>Valoare</th><th>Detaliu / sursă</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există încă verificări colectate pentru politica de parole.');
  const effective=Object.entries(policy?.effective||{}).sort(([a],[b])=>a.localeCompare(b));
  const eff=effective.length?`<details class="vm-password-policy-effective"><summary>Valori efective (${effective.length})</summary><div class="table-wrap"><table><thead><tr><th>Setare</th><th>Valoare</th></tr></thead><tbody>${effective.map(([k,v])=>`<tr><td class="mono">${e(k)}</td><td class="mono">${e(v)}</td></tr>`).join('')}</tbody></table></div></details>`:'';
  const guidance=!policy?'<p class="muted">Politica nu a fost colectată. Folosește vm-doc-agent 1.7.15+ sau agentul SLES9 legacy compatibil și rulează o colectare.</p>':`<p class="muted">${e((policy.sources||[]).join(' · ')||'Surse neprecizate')}</p>`;
  return `<details class="panel vm-security-collapsible vm-password-policy" id="vmPasswordPolicy"><summary><strong>Politică parole</strong><span class="vm-security-collapse-meta">${status}</span></summary><div class="vm-password-policy-body"><div class="vm-password-policy-grid">${stats}<div class="vm-password-policy-results">${checksTable}${eff}</div></div>${guidance}</div></details>`;
}
function securityDatabasePrivileged(db){const p=(db.principals||[]).some(p=>p.superuser||p.create_role||p.create_db||p.replication||(p.roles||[]).some(r=>['sysadmin','securityadmin','serveradmin','db_owner','db_securityadmin'].includes(String(r||'').toLowerCase())));const g=(db.privileges||[]).some(x=>x.grantable||['ALL','CONTROL SERVER','ALTER ANY LOGIN','CREATE LOGIN','CREATE USER','CREATE ROLE'].includes(String(x.privilege||'').toUpperCase()));return p||g}

function securityDatabaseSearch(db,q){
 if(!q)return true;
 const has=(v)=>v!=null&&String(v).toLocaleLowerCase('ro').includes(q);
 if([db.vm_name,db.engine,db.product,db.instance_name,db.version].some(has))return true;
 for(const p of db.principals||[]){if([p.name,p.host,p.database].some(has)||(p.roles||[]).some(has))return true;}
 for(const g of db.privileges||[]){if([g.principal,g.host,g.scope,g.database,g.schema,g.object_type,g.object_name,g.privilege,g.state,g.source].some(has))return true;}
 for(const r of db.hba_rules||[]){if([r.type,r.address,r.method,r.source_file].some(has)||(r.databases||[]).some(has)||(r.users||[]).some(has))return true;}
 return false;
}
function securityWebSearch(site,q){if(!q)return true;const rules=(site.rules||[]).flatMap(r=>[r.action,r.source,r.scope,r.directive,r.source_file]);return [site.vm_name,site.engine,site.name,site.config_file,...(site.server_names||[]),...rules].join(' ').toLocaleLowerCase('ro').includes(q)}
function securityOverviewBody(data){const s=data.summary||{},hiddenDue=Math.max(0,Number(s.accounts_due_all||0)-Number(s.accounts_due||0));const cards=`<div class="cards report-summary">${securityKPI('Conturi relevante',s.accounts_relevant??s.accounts,`${s.accounts_privileged||0} privilegiate · ${s.accounts_system_hidden||0} system ascunse`)}${securityKPI('Review conturi restante',s.accounts_due,hiddenDue?`${hiddenDue} system ascunse`:'' )}${securityKPI('DB principals',s.database_principals,`${s.database_privileged||0} privilegiați · ${s.database_privileges||0} grants`)}${securityKPI('HBA warnings',s.hba_warnings)}${securityKPI('Web ACL rules',s.web_rules,`${s.web_allow_all||0} allow all`)}${securityKPI('Review total restant',s.total_due)}</div>`;const dueAccounts=(data.accounts||[]).filter(x=>securityAccountRelevant(x)&&x.review?.due).slice(0,15);const dueDB=(data.databases||[]).filter(x=>x.review?.due).slice(0,10);const dueWeb=(data.web_sites||[]).filter(x=>x.review?.due).slice(0,10);const rows=[...dueAccounts.map(x=>`<tr><td>Cont VM</td><td><a href="#vms/${x.vm_id}/security-accounts">${e(x.vm_name)}</a></td><td>${e(x.username)}</td><td>${x.privileged?'<span class="badge missing">Privilegiat</span>':'—'}</td><td>${securityReviewCell(x.vm_id,'vm_account',x.username,x.review,x.privileged?6:12,{vmName:x.vm_name,resource:x.username})}</td></tr>`),...dueDB.map(x=>`<tr><td>Bază</td><td><a href="#vms/${x.vm_id}/security-databases">${e(x.vm_name)}</a></td><td>${e(x.product)} · ${e(x.instance_name||'default')}</td><td>${x.hba_rules?.some(r=>r.warning)?'<span class="badge missing">HBA warning</span>':'—'}</td><td>${securityReviewCell(x.vm_id,'database',String(x.id),x.review,6,{vmName:x.vm_name,resource:`${x.product} · ${x.instance_name||'default'}`})}</td></tr>`),...dueWeb.map(x=>`<tr><td>Web</td><td><a href="#vms/${x.vm_id}/security-web">${e(x.vm_name)}</a></td><td>${e(x.name)}</td><td>${x.rules?.some(r=>r.warning)?'<span class="badge missing">ALLOW ALL</span>':'—'}</td><td>${securityReviewCell(x.vm_id,'web',String(x.id),x.review,12,{vmName:x.vm_name,resource:x.name})}</td></tr>`)].join('');return `${cards}${panel('Review-uri care necesită atenție',rows?`<div class="table-wrap"><table><thead><tr><th>Tip</th><th>VM</th><th>Resursă</th><th>Indicator</th><th>Review</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există review-uri restante pentru conturile relevante, bazele de date și Web ACL.'))}`}
function securityPasswordExpiryText(x){if(x.password_expires_at)return dt(x.password_expires_at);const max=Number(x.max_password_age_days);if(Number.isFinite(max)&&max>=99999)return 'Nu expiră';if(x.password_locked)return '—';return 'Necunoscut'}
function securityAccountRow(x,showVM=true,includeReview=true){return `<tr>${showVM?`<td><a href="#vms/${x.vm_id}/security-accounts"><strong>${e(x.vm_name)}</strong></a></td>`:''}<td class="mono"><strong>${e(x.username)}</strong><div class="muted">UID ${x.uid}${x.system_account&&String(x.username||'').toLowerCase()!=='root'?' · system':''}</div></td><td class="mono">${e(x.shell||'—')}</td><td>${x.login_capable?'<span class="badge active">Login</span>':'<span class="badge">No login</span>'}</td><td>${securityPasswordBadge(x)}</td><td>${x.password_last_set?dt(x.password_last_set):'—'}</td><td>${securityPasswordExpiryText(x)}${x.warning_days!=null?`<div class="muted">avertizare ${Number(x.warning_days)} zile</div>`:''}</td><td>${x.privileged?'<span class="badge missing">Da</span>':'Nu'}<div class="muted">${e((x.groups||[]).join(', ')||'—')}</div></td><td>${includeReview&&securityAccountRelevant(x)?securityReviewCell(x.vm_id,'vm_account',x.username,x.review,x.privileged?6:12,{vmName:x.vm_name,resource:x.username}):securityReviewNotApplicable()}</td></tr>`}

function securityAccountsBody(data){
  const f=state.securityFilters.accounts,q=String(f.q||'').trim().toLocaleLowerCase('ro');
  const filtered=(data.accounts||[]).filter(x=>securityAccountSearch(x,q)&&securityAccountTypeMatches(x,f.type)&&(!f.login||(f.login==='yes'?x.login_capable:!x.login_capable))&&(!f.password||securityPasswordCategory(x)===f.password)&&(!f.privileged||(f.privileged==='yes'?x.privileged:!x.privileged))&&securityReviewMatches(x.review,f.review));
  const info=securityPageInfo(f,filtered.length,[10,25,50,100,200]),items=filtered.slice(info.offset,info.end),hidden=(data.accounts||[]).filter(x=>!securityAccountRelevant(x)).length;
  const filters=`<div class="filterbar ui-filter-shell"><label><span>Caută</span><input id="securityAccountSearch" type="search" value="${e(f.q)}" placeholder="VM, user, shell, grup…"></label><label class="security-system-toggle"><span>Conturi system</span><span class="security-checkbox-control"><input id="securityShowSystemAccounts" type="checkbox" ${f.type==='all'?'checked':''}> Afișează conturile system</span></label><label><span>Login</span><select id="securityAccountLogin"><option value="">Toate</option><option value="yes" ${f.login==='yes'?'selected':''}>Login posibil</option><option value="no" ${f.login==='no'?'selected':''}>No login</option></select></label><label><span>Parolă</span><select id="securityAccountPassword"><option value="">Toate</option><option value="active" ${f.password==='active'?'selected':''}>Activă</option><option value="locked" ${f.password==='locked'?'selected':''}>Locked</option><option value="empty" ${f.password==='empty'?'selected':''}>Goală</option><option value="other" ${f.password==='other'?'selected':''}>Necunoscută / alta</option></select></label><label><span>Privilegiat</span><select id="securityAccountPrivileged"><option value="">Toate</option><option value="yes" ${f.privileged==='yes'?'selected':''}>Da</option><option value="no" ${f.privileged==='no'?'selected':''}>Nu</option></select></label><label><span>Review</span><select id="securityAccountReview"><option value="">Toate</option><option value="due" ${f.review==='due'?'selected':''}>Necesită review</option><option value="unreviewed" ${f.review==='unreviewed'?'selected':''}>Nerevizuit</option><option value="current" ${f.review==='current'?'selected':''}>La zi</option></select></label><button id="securityAccountReset" class="secondary" type="button">Resetează</button></div>`;
  const rows=items.map(x=>securityAccountRow(x,true)).join('');
  const note=f.type!=='all'&&hidden?`<div class="notice info"><strong>${hidden} conturi system sunt ascunse implicit.</strong><span>root rămâne vizibil; sunt păstrate conturile system cu login real, privilegii sau parolă ce necesită verificare. Bifează „Afișează conturile system” pentru inventarul complet.</span></div>`:'';
  const accountsBody=`${rows?`<div class="table-wrap"><table><thead><tr><th>VM</th><th>User</th><th>Shell</th><th>Login</th><th>Parolă</th><th>Ultima schimbare</th><th>Expiră</th><th>Privilegii / grupuri</th><th>Review</th></tr></thead><tbody>${rows}</tbody></table></div>${securityPager(info,'security-account',[10,25,50,100,200])}`:empty('Nu există conturi pentru filtrele selectate.')}`;
  return `${securityPasswordPoliciesBody(data)}${note}${securityFilterShell(filters,'accounts',f)}${securityBulkVMSelector('accounts',filtered.filter(securityAccountRelevant))}${panel('Conturi VM',accountsBody)}`;
}

// 0.21.35: secure per-instance navigation; default PostgreSQL NOLOGIN system roles remain
// in agent data but no longer obscure actual users. Custom NOLOGIN roles remain visible.
function securityDBBuiltInRole(db,p){return String(db.engine||'').toLowerCase()==='postgresql'&&!p.login&&/^pg_/i.test(String(p.name||''));}
function securityStackList(values,limit=4,render=x=>e(x)){
  const items=[...new Set((values||[]).map(x=>String(x).trim()).filter(Boolean))];
  if(!items.length)return '<span class="muted">—</span>';
  const visible=items.slice(0,limit).map(v=>`<div class="security-db-stack-item">${render(v)}</div>`).join('');
  if(items.length<=limit)return `<div class="security-db-stack">${visible}</div>`;
  return `<div class="security-db-stack">${visible}<details class="security-db-stack-more"><summary>+${items.length-limit} · Extinde</summary>${items.slice(limit).map(v=>`<div class="security-db-stack-item">${render(v)}</div>`).join('')}<span class="security-db-stack-collapse">Restrânge din titlu</span></details></div>`;
}
function securityDBPrivileges(p){
  const values=[];
  if(p.superuser)values.push('SUPERUSER');if(p.create_role)values.push('CREATEROLE');
  if(p.create_db)values.push('CREATEDB');if(p.replication)values.push('REPLICATION');
  return securityStackList(values,4,x=>`<span class="badge missing">${e(x)}</span>`);
}
// UI presentation grouping only: no privilege/grant is discarded or conflated.
// Granturile sunt grupate pe utilizator; nivelurile secundare se construiesc
// la cerere, astfel incat 20.000+ de granturi nu creeaza mii de noduri DOM.
const securityDBRenderCache=new Map();
function securityDBGrantGroups(privs=[]){
 const groups=new Map();
 for(const grant of privs){
  const key=JSON.stringify([grant.principal||'',grant.host||'']);
  if(!groups.has(key))groups.set(key,{principal:grant.principal||'',host:grant.host||'',items:[]});
  groups.get(key).items.push(grant);
 }
 return [...groups.values()].sort((a,b)=>b.items.length-a.items.length||a.principal.localeCompare(b.principal));
}
function securityDBGrantSubgroups(grants){
 const groups=new Map();
 for(const g of grants){
  const key=JSON.stringify([g.database||'',g.schema||'',g.scope||'',g.privilege||'',g.state||'',!!g.grantable]);
  if(!groups.has(key))groups.set(key,{grant:g,items:[]});
  groups.get(key).items.push(g);
 }
 return [...groups.values()].sort((a,b)=>b.items.length-a.items.length||String(a.grant.privilege||'').localeCompare(String(b.grant.privilege||'')));
}
// UI 0.21.38: un singur rand pe principal; grupurile tehnice raman accesibile
// in interior. Review-ul individual este in antet, nu in continutul colapsabil.
function securityDBGrantReviewButton(db,review,title){
 if(!review?.resource_key)return '<span class="muted">Fără identificator de revizie</span>';
 return securityReviewCell(db.vm_id,'database_grants',review.resource_key,review,6,{vmName:db.vm_name,resource:`Granturi · ${title}`});
}
function securityDBGrantsContent(db){
 const groups=securityDBGrantGroups(db.privileges||[]),all=(db.privileges||[]).length;
 if(!groups.length)return empty('Privilegiile nu au fost colectate sau agentul este mai vechi de 1.7.12.');
 const reviews=new Map((db.grant_reviews||[]).map(x=>[JSON.stringify([x.principal||'',x.host||'']),x.review]));
 return `<p class="muted security-db-grants-note"><strong>${all.toLocaleString('ro-RO')} granturi · ${groups.length.toLocaleString('ro-RO')} utilizatori/grupuri</strong>. Deschide un utilizator pentru grupurile tehnice; extinde un grup pentru lista completă de obiecte.</p><div class="security-db-grant-groups">${groups.map((group,i)=>{
  const review=reviews.get(JSON.stringify([group.principal,group.host]));
  const title=`${group.principal||'(fără principal)'}${group.host?'@'+group.host:''}`;
  // Calculare numai la deschiderea utilizatorului: nu procesam 20k granturi de doua ori.
  return `<div class="security-db-grant-group" data-grant-user="${i}"><div class="security-db-grant-head"><button type="button" class="security-db-grant-toggle" aria-expanded="false" aria-controls="security-grant-user-${Number(db.id)}-${i}"><span class="security-db-grant-chevron" aria-hidden="true">▸</span><strong class="security-db-grant-principal">${e(title)}</strong><span class="security-db-grant-count">${group.items.length.toLocaleString('ro-RO')} granturi</span></button><div class="security-db-grant-head-review">${securityDBGrantReviewButton(db,review,title)}</div></div><div class="security-db-grant-nested" data-grant-nested id="security-grant-user-${Number(db.id)}-${i}" hidden></div></div>`;
 }).join('')}</div>`;
}

function securityDBRenderGrantSubgroup(grants,root){
 const body=root.querySelector('[data-grant-rows]');if(!body)return;
 let shown=0;
 const table=document.createElement('div');table.className='table-wrap';
 table.innerHTML='<table><thead><tr><th>Tip obiect</th><th>Obiect</th><th>Sursă</th></tr></thead><tbody></tbody></table>';
 const tbody=table.querySelector('tbody');const more=document.createElement('button');more.type='button';more.className='small secondary security-grant-load-more';
 const append=()=>{
  const end=Math.min(shown+200,grants.length);
  tbody.insertAdjacentHTML('beforeend',grants.slice(shown,end).map(g=>`<tr><td>${e(g.object_type||g.scope||'—')}</td><td class="mono">${e(g.object_name||'—')}</td><td>${e(g.source||'—')}</td></tr>`).join(''));
  shown=end;more.hidden=shown>=grants.length;more.textContent=`Afișează încă ${Math.min(200,grants.length-shown)} · ${shown.toLocaleString('ro-RO')}/${grants.length.toLocaleString('ro-RO')}`;
 };
 append();more.addEventListener('click',append);body.replaceChildren(table,more);
}
function securityDBRenderGrantUser(db,details){
 const groups=securityDBGrantGroups(db.privileges||[]),index=Number(details.dataset.grantUser),group=groups[index];
 if(!group)return;
 const subs=securityDBGrantSubgroups(group.items);
 const content=details.querySelector('[data-grant-nested]');if(!content)return;
 content.innerHTML=`<p class="muted">${subs.length} grupuri tehnice · privilegii și obiecte distincte</p>${subs.map(({grant:g,items},i)=>`<details class="security-db-grant-subgroup" data-grant-subgroup="${i}"><summary><strong>${e(g.privilege||'—')}</strong><span>${e([g.database,g.schema,g.scope].filter(Boolean).join(' / ')||'Server')}</span>${String(g.state||'grant').toLowerCase()==='deny'?'<span class="badge missing">DENY</span>':''}${g.grantable?'<span class="badge missing">GRANT OPTION</span>':''}<span class="muted">${items.length.toLocaleString('ro-RO')} obiecte</span></summary><div data-grant-rows></div></details>`).join('')}`;
 content.querySelectorAll('[data-grant-subgroup]').forEach(item=>item.addEventListener('toggle',()=>{
   const body=item.querySelector('[data-grant-rows]');
   if(item.open&&!item.dataset.loaded){item.dataset.loaded='1';securityDBRenderGrantSubgroup(subs[Number(item.dataset.grantSubgroup)].items,item)}
   else if(!item.open&&item.dataset.loaded&&body){body.replaceChildren();delete item.dataset.loaded;}
  }));
}

function securityDBSectionTab(id,label,count,reviewed=null){return `<button type="button" class="small secondary security-db-section-tab" data-db-section="${e(id)}" aria-pressed="${id==='users'?'true':'false'}">${e(label)} <span class="muted">${Number(count)||0}</span>${reviewed==null?'':`<small class="security-db-tab-reviewed">Revizuite ${Number(reviewed)} din ${Number(count)}</small>`}</button>`;}
function securityDatabaseCard(db,showVM=true){
 securityDBRenderCache.set(Number(db.id),db);
 const visiblePrincipals=(db.principals||[]).filter(p=>!securityDBBuiltInRole(db,p));
 const suppressed=(db.principals||[]).length-visiblePrincipals.length;
 const postgres=String(db.engine||'').toLowerCase()==='postgresql';
  const grantGroupCount=new Set((db.privileges||[]).map(g=>JSON.stringify([g.principal||'',g.host||'']))).size;
 const grantReviewed=(db.grant_reviews||[]).filter(x=>x.review?.reviewed_at).length;
 const principals=visiblePrincipals.map(p=>`<tr><td class="mono"><strong>${e(p.name)}</strong>${p.host?`@${e(p.host)}`:''}</td><td>${e(p.database||'—')}</td><td>${p.login?'<span class="badge active">LOGIN</span>':'<span class="badge">NOLOGIN</span>'}</td><td>${securityDBPrivileges(p)}</td><td>${securityStackList(p.roles,4)}</td><td>${p.review?securityReviewCell(db.vm_id,'database_principal',p.review.resource_key,p.review,6,{vmName:db.vm_name,resource:`${p.name}${p.host?'@'+p.host:''}${p.database?' · '+p.database:''}`}):'<span class="muted">—</span>'}</td></tr>`).join('');
 const hba=(db.hba_rules||[]).map(r=>{
  const method=String(r.method||'—').toLowerCase();
  const extra=String(r.warning_text||'').split(',').map(v=>v.trim()).filter(v=>v&&v!=='md5'&&v!=='all/all').join(', ');
  const explain=(values,kind)=>securityStackList((values||[]).map(v=>v==='all'?`all · ${kind==='db'?'toate bazele':'toți utilizatorii'}`:v),4);
  return `<tr><td class="mono">${e(r.type||'—')}</td><td>${explain(r.databases,'db')}</td><td>${explain(r.users,'user')}</td><td class="mono">${e(r.address||'local')}</td><td>${method==='md5'?'<span class="badge">md5</span><span class="muted security-hba-method-hint">parolă · MD5/SCRAM</span>':e(r.method||'—')}${extra?`<div class="badge missing">${e(extra)}</div>`:''}</td><td class="mono">${e(r.source_file||'—')}${r.line?`:${Number(r.line)}`:''}</td><td>${r.review?securityReviewCell(db.vm_id,'database_hba',r.review.resource_key,r.review,6,{vmName:db.vm_name,resource:`HBA ${r.type||''} · ${(r.databases||[]).join(',')}/${(r.users||[]).join(',')} · ${r.address||'local'} · ${r.source_file||''}:${r.line||''}`}):'—'}</td></tr>`;
 }).join('');
 const vmLabel=showVM?`<a href="#vms/${db.vm_id}/security-databases">${e(db.vm_name)}</a><span class="security-db-title-separator">/</span>`:'';
 const header=`<span class="security-db-title">${vmLabel}<strong>${e(db.product||db.engine||'Bază de date')}</strong><span class="security-db-instance-name">${e(db.instance_name||'default')}</span></span><span class="security-db-summary-meta">${e(db.version||'')}${securityDatabasePrivileged(db)?'<span class="badge missing">Privilegii ridicate</span>':''}${postgres&&db.hba_rules?.some(r=>r.warning)?'<span class="badge missing">HBA</span>':''}<span class="badge">${(db.privileges||[]).length.toLocaleString('ro-RO')} grants</span></span>`;
 const bulk=(scope,label,count)=>securityBulkButton(db.vm_id,scope,label,count,db.id,db.vm_name);
 const usersPanel=`${bulk('database_principals','Users / Roles',visiblePrincipals.length)}${suppressed?`<p class="muted">${suppressed} roluri interne pg_* NOLOGIN ascunse; inventarul brut nu este modificat.</p>`:''}${principals?`<div class="table-wrap"><table><thead><tr><th>User / host</th><th>Database</th><th>Login</th><th>Privilegii server</th><th>Roluri</th><th>Review</th></tr></thead><tbody>${principals}</tbody></table></div>`:empty('Nu există utilizatori/roluri de afișat.')}`;
 const grantsPanel=`${bulk('database_grants','Grants · utilizatori',grantGroupCount)}<div data-security-db-grants-content></div>`;
 const hbaPanel=`${bulk('database_hba','Conectare / HBA',postgres?(db.hba_rules||[]).length:0)}<p class="muted">HBA stabilește cine se poate autentifica, din ce adresă și prin ce metodă. <strong>all / all</strong> = toate bazele / toți utilizatorii, nu toate adresele IP. <strong>md5</strong> cere parolă și poate negocia SCRAM când parola este stocată astfel.</p>${hba?`<div class="table-wrap"><table><thead><tr><th>Type</th><th>Database</th><th>User</th><th>Address</th><th>Method</th><th>Fișier sursă</th><th>Review</th></tr></thead><tbody>${hba}</tbody></table></div>`:empty('Nu există reguli HBA colectate.')}`;
 return `<details class="panel security-db-card" data-db-id="${Number(db.id)}" ${db.review?.due?'open':''}><summary class="security-db-card-summary">${header}</summary><div class="security-db-card-body"><div class="detail-grid">${showVM?detail('VM',`<a href="#vms/${db.vm_id}/security-databases">${e(db.vm_name)}</a>`):''}${detail('Stare colectare',badge(db.status||'necolectat'))}${detail('Utilizatori / roluri',String(visiblePrincipals.length))}${db.review?.reviewed_at?detail('Review istoric instanță',securityReviewBadge(db.review)):''}</div><nav class="security-db-sections" aria-label="Categorii acces bază de date">${securityDBSectionTab('users','1. Users / Roles',visiblePrincipals.length,visiblePrincipals.filter(p=>p.review?.reviewed_at).length)}${securityDBSectionTab('grants','2. Grants',grantGroupCount,grantReviewed)}${postgres?securityDBSectionTab('hba','3. Conectare / HBA',(db.hba_rules||[]).length,(db.hba_rules||[]).filter(r=>r.review?.reviewed_at).length):''}</nav><section class="security-db-pane" data-db-pane="users">${usersPanel}</section><section class="security-db-pane" data-db-pane="grants" hidden>${grantsPanel}</section>${postgres?`<section class="security-db-pane" data-db-pane="hba" hidden>${hbaPanel}</section>`:''}</div></details>`;
}

function securityDBBindGrantUsers(card,db){
 card.querySelectorAll('[data-grant-user]').forEach(group=>{
  if(group.dataset.bound==='1')return;
  group.dataset.bound='1';
  const toggle=group.querySelector('.security-db-grant-toggle'),nested=group.querySelector('[data-grant-nested]');
  if(!toggle||!nested)return;
  toggle.addEventListener('click',()=>{
   const expand=toggle.getAttribute('aria-expanded')!=='true';
   toggle.setAttribute('aria-expanded',String(expand));
   nested.hidden=!expand;
   if(expand&&!group.dataset.loaded&&db){group.dataset.loaded='1';securityDBRenderGrantUser(db,group)}
   else if(!expand&&group.dataset.loaded){nested.replaceChildren();delete group.dataset.loaded;}
  });
 });
}

function bindSecurityDatabaseCards(root=document){
 root.querySelectorAll('.security-db-card').forEach(card=>{
  const db=securityDBRenderCache.get(Number(card.dataset.dbId));
  card.querySelectorAll('.security-db-section-tab').forEach(btn=>btn.addEventListener('click',()=>{
   card.querySelectorAll('.security-db-section-tab').forEach(b=>b.setAttribute('aria-pressed',String(b===btn)));
   card.querySelectorAll('.security-db-pane').forEach(p=>p.hidden=p.dataset.dbPane!==btn.dataset.dbSection);
   if(btn.dataset.dbSection==='grants'){
    const host=card.querySelector('[data-security-db-grants-content]');
    if(host&&!host.dataset.loaded&&db){
     host.innerHTML=securityDBGrantsContent(db);host.dataset.loaded='1';
     // Review buttons created after the initial page bind must remain functional.
     bindSecurityReviewButtons(host);
     securityDBBindGrantUsers(card,db);
    }
   }
  }));
 });
}
function securityDatabasesBody(data){securityDBRenderCache.clear();const f=state.securityFilters.databases,q=String(f.q||'').trim().toLocaleLowerCase('ro'),engines=[...new Set((data.databases||[]).map(x=>x.engine).filter(Boolean))].sort();const filtered=(data.databases||[]).filter(db=>securityDatabaseSearch(db,q)&&(!f.engine||db.engine===f.engine)&&(!f.indicator||(f.indicator==='hba'?db.hba_rules?.some(r=>r.warning):f.indicator==='privileged'?securityDatabasePrivileged(db):f.indicator==='grantable'?(db.privileges||[]).some(x=>x.grantable):f.indicator==='deny'?(db.privileges||[]).some(x=>String(x.state||'').toLowerCase()==='deny'):(!db.hba_rules?.some(r=>r.warning)&&!securityDatabasePrivileged(db))))&&(f.review?(db.principals||[]).length?(db.principals||[]).some(p=>securityReviewMatches(p.review,f.review)):securityReviewMatches(db.review,f.review):true));const info=securityPageInfo(f,filtered.length,[10,20,50,100]),items=filtered.slice(info.offset,info.end);const filters=`<div class="filterbar ui-filter-shell"><label><span>Caută</span><input id="securityDBSearch" type="search" value="${e(f.q)}" placeholder="VM, DB, user, rol, privilegiu, obiect, HBA…"></label><label><span>Motor</span><select id="securityDBEngine"><option value="">Toate</option>${engines.map(v=>`<option value="${e(v)}" ${f.engine===v?'selected':''}>${e(v)}</option>`).join('')}</select></label><label><span>Indicator</span><select id="securityDBIndicator"><option value="">Toate</option><option value="hba" ${f.indicator==='hba'?'selected':''}>HBA warning</option><option value="privileged" ${f.indicator==='privileged'?'selected':''}>Privilegiu ridicat</option><option value="grantable" ${f.indicator==='grantable'?'selected':''}>GRANT OPTION</option><option value="deny" ${f.indicator==='deny'?'selected':''}>DENY explicit</option><option value="clean" ${f.indicator==='clean'?'selected':''}>Fără indicator</option></select></label><label><span>Review</span><select id="securityDBReview"><option value="">Toate</option><option value="due" ${f.review==='due'?'selected':''}>Necesită review</option><option value="unreviewed" ${f.review==='unreviewed'?'selected':''}>Nerevizuit</option><option value="current" ${f.review==='current'?'selected':''}>La zi</option></select></label><button id="securityDBReset" class="secondary" type="button">Resetează</button></div>`;const body=items.map(db=>securityDatabaseCard(db,true)).join('');return `${securityFilterShell(filters,'databases',f)}<div class="security-db-export-bar"><span class="muted">Exportă inventarul tuturor instanțelor: Users, Grants și HBA (dacă există PostgreSQL).</span><a class="button-link small secondary" href="/api/v1/security/databases/export">Export Excel</a></div>${body||empty('Nu există instanțe DB pentru filtrele selectate.')}${securityPager(info,'security-db',[10,20,50,100])}`}

// 0.21.39: ordonare dupa ACL, review compact in summary; site-uri fara reguli inchise.
function securityWebSiteOrder(a,b){
 const ar=(a.rules||[]).length,br=(b.rules||[]).length;
 if(!!ar!==!!br)return ar?-1:1;
 const aw=(a.rules||[]).some(r=>r.warning),bw=(b.rules||[]).some(r=>r.warning);
 if(aw!==bw)return aw?-1:1;
 return String(a.vm_name||'').localeCompare(String(b.vm_name||''),'ro',{numeric:true})||String(a.name||'').localeCompare(String(b.name||''),'ro',{numeric:true})||Number(a.id||0)-Number(b.id||0);
}
function securityWebReviewSummary(site){
 return `<div class="security-web-review-summary">${securityReviewCell(site.vm_id,'web',Number(site.id),site.review||{},12,{vmName:site.vm_name,resource:site.name})}</div>`;
}
function securityWebCard(site,showVM=true){
 const rules=site.rules||[];
 const rows=rules.map(r=>`<tr><td>${r.warning?'<span class="badge missing">ALLOW</span>':badge(String(r.action||'').toUpperCase())}</td><td class="mono">${e(r.source||'—')}</td><td>${e(r.scope||'—')}</td><td class="mono">${e(r.directive||'—')}</td><td class="mono">${e(r.source_file||'—')}</td></tr>`).join('');
 const coverage=rules.length?`<span class="badge">${rules.length} ${rules.length===1?'regulă ACL':'reguli ACL'}</span>`:'<span class="badge">Fără ACL explicit</span>';
 const warning=rules.some(r=>r.warning)?'<span class="badge missing">ALLOW ALL</span>':'';
 // Când nu există reguli explicite, evităm a doua alertă sub același mesaj din antet.
 const details=rules.length?`<div class="table-wrap"><table><thead><tr><th>Acțiune</th><th>Sursă</th><th>Scope</th><th>Directivă</th><th>Fișier sursă</th></tr></thead><tbody>${rows}</tbody></table></div>`:'';
 return `<details class="panel security-web-site" data-has-acl="${rules.length?'1':'0'}" ${rules.length?'open':''}><summary class="security-web-site-summary"><span class="security-web-site-title"><strong>${showVM?`${e(site.vm_name)} · `:''}${e(site.name)}</strong><span class="muted">${e(site.engine||'')}</span>${coverage}${warning}</span>${securityWebReviewSummary(site)}</summary><div class="detail-grid security-web-site-details">${showVM?detail('VM',`<a href="#vms/${Number(site.vm_id)}/security-web">${e(site.vm_name)}</a>`):''}${detail('VHost / server',e((site.server_names||[]).join(', ')||site.name))}${detail('Config principal',`<span class="mono">${e(site.config_file||'—')}</span>`)}${detail('ACL explicit',rules.length?`${rules.length} reguli`:'Nu')}</div>${details}</details>`;
}
// 0.21.40 — Un singur panou Filtre pentru Web ACL, cu actiunile permanente in antet.
// Revizia colectivă este întotdeauna per VM si acoperă toate site-urile acelei VM.
function securityWebControls(vmID,sites,filterFields,selectedVM=0){
 const isVM=Number(vmID)>0,id=isVM?`securityWebFilters-vm-${Number(vmID)}`:'securityWebFilters-global';
 const open=isVM?!!state.securityWebVMFilters?.expanded:!!state.securityWebCentralExpanded;
 const total=sites.length,withACL=sites.filter(site=>(site.rules||[]).length>0).length,reviewed=sites.filter(site=>site.review?.reviewed_at).length;
 const exportURL=`/api/v1/security/web/export${isVM?`?vm_id=${Number(vmID)}`:''}`;
 const vmTotals=new Map();
 if(!isVM){for(const site of sites){const key=Number(site.vm_id);if(!key)continue;const v=vmTotals.get(key)||{name:site.vm_name||`VM #${key}`,count:0};v.count++;vmTotals.set(key,v);}}
 const selection=Number(selectedVM),current=vmTotals.get(selection);
 const review=can('vms.manage')&&total?`<button type="button" class="small secondary security-review-bulk security-web-bulk-trigger" data-scope="web" data-vm="${isVM?Number(vmID):current?selection:0}" data-vm-name="${e(isVM?(sites[0]?.vm_name||''):current?.name||'')}" data-label="Web ACL / vhost-uri" data-count="${isVM?total:current?.count||0}">Revizuiește secțiunea</button>`:'';
 const vmPicker=!isVM&&review?`<label class="security-web-vm-picker"><span>VM pentru revizia colectivă</span><select class="security-web-vm-select"><option value="">Alege VM…</option>${[...vmTotals].sort((a,b)=>a[1].name.localeCompare(b[1].name,'ro')).map(([key,v])=>`<option value="${key}" ${selection===key?'selected':''}>${e(v.name)} (${v.count})</option>`).join('')}</select></label><p class="security-web-scope-note muted">Revizia se aplică tuturor site-urilor de pe VM-ul ales, nu numai celor filtrate.</p>`:'';
 return `<section class="security-web-controls" data-security-web-controls="${isVM?'vm':'global'}" data-vm="${Number(vmID)||0}">
  <div class="security-web-controls-head"><div class="security-web-controls-title"><strong>Filtre</strong><span class="muted">${total} site-uri · ${withACL} cu ACL · Revizuite ${reviewed} din ${total}${isVM?` · <span class="security-web-visible-count">${total} afișate</span>`:''}</span></div>
   <div class="security-web-controls-actions"><a class="button-link small secondary" href="${e(exportURL)}">Export Excel</a>${review}</div>
   <button type="button" class="security-web-controls-chevron" aria-controls="${e(id)}" aria-expanded="${open}" aria-label="${open?'Restrânge':'Extinde'} filtrele" title="${open?'Restrânge':'Extinde'} filtrele">⌄</button></div>
  <div id="${e(id)}" class="security-web-controls-fields" ${open?'':'hidden'}><div class="security-web-controls-grid">${filterFields}${vmPicker}</div></div>
 </section>`;
}
function bindSecurityWebControls(root=document){
 root.querySelectorAll('[data-security-web-controls]').forEach(panel=>{
  const isVM=panel.dataset.securityWebControls==='vm',chevron=panel.querySelector('.security-web-controls-chevron'),fields=panel.querySelector('.security-web-controls-fields');
  const expand=open=>{if(isVM){if(state.securityWebVMFilters)state.securityWebVMFilters.expanded=open;}else state.securityWebCentralExpanded=open;chevron.setAttribute('aria-expanded',String(open));chevron.setAttribute('aria-label',open?'Restrânge filtrele':'Extinde filtrele');chevron.title=open?'Restrânge filtrele':'Extinde filtrele';fields.hidden=!open;};
  chevron?.addEventListener('click',()=>expand(chevron.getAttribute('aria-expanded')!=='true'));
  const bulk=panel.querySelector('.security-web-bulk-trigger');
  if(!isVM){
    const select=panel.querySelector('.security-web-vm-select');
    select?.addEventListener('change',()=>{
      state.securityWebSelectedVM=Number(select.value)||0;
      const chosen=select.options[select.selectedIndex];
      if(bulk){bulk.dataset.vm=select.value||'0';bulk.dataset.vmName=selectedVMName(chosen);bulk.dataset.count=chosen?.textContent.match(/\((\d+)\)$/)?.[1]||'0';}
    });
    bulk?.addEventListener('click',event=>{
      if(Number(bulk.dataset.vm))return;
      event.preventDefault();event.stopImmediatePropagation();expand(true);select?.focus();
    },true);
  }else{
    const f=state.securityWebVMFilters;
    if(!f||Number(f.vmId)!==Number(panel.dataset.vm))return;
    const cards=[...panel.parentElement.querySelectorAll('.security-web-site')];
    const search=panel.querySelector('.security-web-vm-search'),onlyACL=panel.querySelector('.security-web-only-acl'),reset=panel.querySelector('.security-web-vm-reset');
    let timer;
    const apply=()=>{const q=(f.q||'').trim().toLocaleLowerCase('ro');let shown=0;for(const card of cards){const visible=(!f.onlyACL||card.dataset.hasAcl==='1')&&(!q||card.textContent.toLocaleLowerCase('ro').includes(q));card.hidden=!visible;if(visible)shown++;}const count=panel.querySelector('.security-web-visible-count');if(count)count.textContent=`${shown} afișate`;const emptyMessage=panel.parentElement.querySelector('.security-web-no-match');if(emptyMessage)emptyMessage.hidden=!!shown;};
    search?.addEventListener('input',event=>{f.q=event.target.value;clearTimeout(timer);timer=setTimeout(apply,120)});
    onlyACL?.addEventListener('change',event=>{f.onlyACL=event.target.checked;apply()});
    reset?.addEventListener('click',()=>{f.q='';f.onlyACL=false;if(search)search.value='';if(onlyACL)onlyACL.checked=false;apply()});
    apply();
  }
 });
}
function selectedVMName(option){return String(option?.textContent||'').replace(/\s*\(\d+\)\s*$/,'').trim()}

function securityWebBody(data){
 const f=state.securityFilters.web,q=String(f.q||'').trim().toLocaleLowerCase('ro'),source=data.web_sites||[],engines=[...new Set(source.map(x=>x.engine).filter(Boolean))].sort();
 const filtered=source.filter(site=>{const rules=site.rules||[],hasRules=rules.length>0,allowAll=rules.some(r=>r.warning);return securityWebSearch(site,q)&&(!f.engine||site.engine===f.engine)&&(!f.coverage||(f.coverage==='rules'?hasRules:f.coverage==='none'?!hasRules:f.coverage==='allowall'?allowAll:true))&&(!f.action||rules.some(r=>String(r.action||'').toLowerCase()===f.action))&&(!f.warning||(f.warning==='yes'?allowAll:!allowAll))&&securityReviewMatches(site.review,f.review)}).sort(securityWebSiteOrder);
 const info=securityPageInfo(f,filtered.length,[10,20,50,100]),items=filtered.slice(info.offset,info.end);
 const filters=`<label class="security-web-search-label"><span>Căutare generală</span><input id="securityWebSearch" type="search" value="${e(f.q)}" placeholder="VM, vhost, adresă, directivă, fișier…"></label><label class="security-web-check-label"><span>Reguli ACL</span><span class="security-web-check-inline"><input id="securityWebOnlyACL" type="checkbox" ${f.coverage==='rules'?'checked':''}> Doar cele cu ACL</span></label><label><span>Motor</span><select id="securityWebEngine"><option value="">Toate</option>${engines.map(v=>`<option value="${e(v)}" ${f.engine===v?'selected':''}>${e(v)}</option>`).join('')}</select></label><label><span>Tip ACL</span><select id="securityWebCoverage"><option value="" ${!f.coverage||f.coverage==='rules'?'selected':''}>Toate</option><option value="none" ${f.coverage==='none'?'selected':''}>Fără ACL explicit</option><option value="allowall" ${f.coverage==='allowall'?'selected':''}>ALLOW ALL</option></select></label><label><span>Acțiune</span><select id="securityWebAction"><option value="">Toate</option><option value="allow" ${f.action==='allow'?'selected':''}>ALLOW</option><option value="deny" ${f.action==='deny'?'selected':''}>DENY</option></select></label><label><span>ALLOW ALL</span><select id="securityWebWarning"><option value="">Toate</option><option value="yes" ${f.warning==='yes'?'selected':''}>Da</option><option value="no" ${f.warning==='no'?'selected':''}>Nu</option></select></label><label><span>Review</span><select id="securityWebReview"><option value="">Toate</option><option value="due" ${f.review==='due'?'selected':''}>Necesită review</option><option value="unreviewed" ${f.review==='unreviewed'?'selected':''}>Nerevizuit</option><option value="current" ${f.review==='current'?'selected':''}>La zi</option></select></label><button id="securityWebReset" class="small secondary security-web-vm-reset" type="button">Resetează</button>`;
 const selectedVM=Number(state.securityWebSelectedVM)||0;
 const controls=securityWebControls(0,source,filters,selectedVM);
 return `${controls}${items.map(site=>securityWebCard(site,true)).join('')||empty('Nu există vhost-uri pentru filtrele selectate.')}${securityPager(info,'security-web',[10,20,50,100])}`;
}
function bindSecurityGlobalControls(section){bindSecurityFilterShell(section);const rerender=()=>securityPage(section);const bindSearch=(id,filter)=>{let timer;document.getElementById(id)?.addEventListener('input',event=>{clearTimeout(timer);const input=event.currentTarget,value=input.value,pos=input.selectionStart??value.length;timer=setTimeout(()=>{filter.q=value;filter.page=1;rerender();const next=document.getElementById(id);if(next){next.focus({preventScroll:true});const p=Math.min(pos,next.value.length);next.setSelectionRange(p,p)}},180)})};if(section==='accounts'){const f=state.securityFilters.accounts;bindSearch('securityAccountSearch',f);[['securityAccountLogin','login'],['securityAccountPassword','password'],['securityAccountPrivileged','privileged'],['securityAccountReview','review']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{f[key]=ev.target.value;f.page=1;rerender()}));document.getElementById('securityShowSystemAccounts')?.addEventListener('change',ev=>{f.type=ev.target.checked?'all':'relevant';f.page=1;rerender()});document.getElementById('securityAccountReset')?.addEventListener('click',()=>{state.securityFilters.accounts={q:'',type:'relevant',login:'',password:'',privileged:'',review:'',page:1,pageSize:f.pageSize||25};rerender()});document.querySelectorAll('.security-account-page').forEach(b=>b.addEventListener('click',()=>{const page=Number(b.dataset.page);if(page>0&&page!==f.page){f.page=page;rerender()}}));document.getElementById('security-accountPageSize')?.addEventListener('change',ev=>{f.pageSize=Number(ev.target.value);f.page=1;rerender()})}else if(section==='databases'){const f=state.securityFilters.databases;bindSearch('securityDBSearch',f);[['securityDBEngine','engine'],['securityDBIndicator','indicator'],['securityDBReview','review']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{f[key]=ev.target.value;f.page=1;rerender()}));document.getElementById('securityDBReset')?.addEventListener('click',()=>{state.securityFilters.databases={q:'',engine:'',indicator:'',review:'',page:1,pageSize:f.pageSize||20};rerender()});document.querySelectorAll('.security-db-page').forEach(b=>b.addEventListener('click',()=>{const page=Number(b.dataset.page);if(page>0&&page!==f.page){f.page=page;rerender()}}));document.getElementById('security-dbPageSize')?.addEventListener('change',ev=>{f.pageSize=Number(ev.target.value);f.page=1;rerender()})}else if(section==='web'){const f=state.securityFilters.web;bindSearch('securityWebSearch',f);[['securityWebEngine','engine'],['securityWebCoverage','coverage'],['securityWebAction','action'],['securityWebWarning','warning'],['securityWebReview','review']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{f[key]=ev.target.value;f.page=1;rerender()}));document.getElementById('securityWebOnlyACL')?.addEventListener('change',ev=>{f.coverage=ev.target.checked?'rules':'';f.page=1;rerender()});document.getElementById('securityWebReset')?.addEventListener('click',()=>{state.securityFilters.web={q:'',engine:'',coverage:'',action:'',warning:'',review:'',page:1,pageSize:f.pageSize||20};rerender()});document.querySelectorAll('.security-web-page').forEach(b=>b.addEventListener('click',()=>{const page=Number(b.dataset.page);if(page>0&&page!==f.page){f.page=page;rerender()}}));document.getElementById('security-webPageSize')?.addEventListener('change',ev=>{f.pageSize=Number(ev.target.value);f.page=1;rerender()})}}
let securityPageRequestGeneration=0;
async function securityPage(section='overview',force=false){
 if(section==='hardening'){await hardeningReportPage('security');return}
 section=['overview','accounts','databases','web','firewall','firewall-sources','firewall-analysis'].includes(section)?section:'overview';
 if(section==='firewall'){await fortigateSecurityPage(force);return}
 if(section==='firewall-sources'){await fortigateSourcesPage(force);return}
 if(section==='firewall-analysis'){await fortigateAnalysisPage(force);return}
 pageMeta('Securitate','Access Review · conturi VM, acces baze de date și ACL web');
 if(section!=='databases')securityDBRenderCache.clear();
 const generation=++securityPageRequestGeneration;
 if(force||!state.securityData||state.securityDataSection!==section){
  state.securityData=null;state.securityDataSection='';
  const data=await api(`/api/v1/security?section=${encodeURIComponent(section)}`);
  if(generation!==securityPageRequestGeneration||!location.hash.startsWith('#security'))return;
  state.securityData=data;state.securityDataSection=section;
 }
 if(generation!==securityPageRequestGeneration)return;
 const data=state.securityData;
 const body=section==='accounts'?securityAccountsBody(data):section==='databases'?securityDatabasesBody(data):section==='web'?securityWebBody(data):securityOverviewBody(data);
 content.innerHTML=`<div class="monitoring-workspace security-workspace">${securityNav(section)}<div class="report-header"><div><strong>Security / Access Review</strong><span>Generat ${dt(data.generated_at)}</span></div><div class="actions"><a class="button-link small secondary" href="#reports/security-reviews">Calendar revizii</a><button id="refreshSecurity" class="secondary">Reîncarcă</button></div></div>${body}</div>`;
 document.getElementById('refreshSecurity')?.addEventListener('click',()=>securityPage(section,true));
 bindSecurityGlobalControls(section);bindSecurityReviewButtons(content);
}
function securityVMOverview(vmID,data){const s=data?.summary||{},hidden=Number(s.accounts_system_hidden||0),policy=(data?.password_policies||[])[0]||null;return `<div class="cards report-summary">${securityKPI('Conturi relevante',s.accounts_relevant??s.accounts,hidden?`${hidden} system ascunse`:'')}${securityKPI('Privilegiate',s.accounts_privileged)}<article class="dashboard-kpi"><span>Policy parole</span><strong>${policy?securityPolicyStatusBadge(policy.enforcement_status):'<span class="badge">N/A</span>'}</strong><small>${policy?'agent 1.7.15+':'necolectată'}</small></article>${securityKPI('DB principals',s.database_principals,`${s.database_privileges||0} grants`)}${securityKPI('HBA warnings',s.hba_warnings)}${securityKPI('Web ACL rules',s.web_rules,`${s.web_allow_all||0} allow all`)}${securityKPI('Review restant',s.total_due)}</div>${panel('Securitate VM',`<div class="detail-grid">${detail('Conturi',`<a href="#vms/${vmID}/security-accounts">Vezi conturile și politica de parole</a>`)}${detail('Acces DB',`<a href="#vms/${vmID}/security-databases">Vezi users / roles / privilegii / HBA</a>`)}${detail('Web ACL',`<a href="#vms/${vmID}/security-web">Vezi allow / deny</a>`)}${detail('Firewall',can('fortigate.read')?`<a href="#vms/${vmID}/security-firewall">Vezi reguli FortiGate</a>`:'—')}</div><p class="muted vm-security-overview-note">Conturile system fără login real, fără privilegii și fără parolă relevantă sunt ascunse implicit, dar rămân disponibile în inventarul complet.</p>`)}`}

function securityVMAccounts(vmID,data){
  const all=data?.accounts||[];
  const visible=all.filter(securityAccountRelevant),hidden=all.filter(x=>!securityAccountRelevant(x));
  const policy=(data?.password_policies||[])[0]||null;
  const columns='<th>User</th><th>Shell</th><th>Login</th><th>Parolă</th><th>Ultima schimbare</th><th>Expiră</th><th>Privilegii / grupuri</th>';
  const relevantRows=visible.map(x=>securityAccountRow(x,false,true)).join('');
  const main=panel('Conturi relevante',relevantRows?`<div class="table-wrap"><table><thead><tr>${columns}<th>Review</th></tr></thead><tbody>${relevantRows}</tbody></table></div>`:empty('Nu există conturi relevante colectate.'));
  const systemRows=hidden.map(x=>securitySystemAccountRow(x)).join('');
  const system=hidden.length?`<details class="panel vm-security-collapsible vm-security-system" id="vmSecuritySystem"><summary><strong>Conturi system</strong><span class="vm-security-collapse-meta">${hidden.length} conturi</span></summary><div class="vm-security-system-body"><div id="vmSystemAccounts"><div class="table-wrap"><table><thead><tr>${columns}</tr></thead><tbody>${systemRows}</tbody></table></div></div><p class="muted">Conturile daemon/service rămân în inventar, dar sunt ascunse implicit și nu necesită review individual cât timp nu au login real, privilegii sau parole relevante.</p></div></details>`:'';
  return `${securityPasswordPolicyVMPanel(policy)}${securityBulkButton(vmID,'accounts','Conturi relevante',visible.length,0,visible[0]?.vm_name||'')}${main}${system}`;
}
function securitySystemAccountRow(x){
  return `<tr><td class="mono"><strong>${e(x.username)}</strong><div class="muted">UID ${e(x.uid)}</div></td><td class="mono">${e(x.shell||'—')}</td><td>${x.login_capable?'<span class="badge active">Login</span>':'<span class="badge">No login</span>'}</td><td>${securityPasswordBadge(x)}</td><td>${x.password_last_set?dt(x.password_last_set):'—'}</td><td>${securityPasswordExpiryText(x)}</td><td>${x.privileged?'<span class="badge missing">Da</span>':'Nu'}<div class="muted">${e((x.groups||[]).join(', ')||'—')}</div></td></tr>`;
}

function securityVMDatabaseAccess(vmID,data){securityDBRenderCache.clear();const databases=data?.databases||[];const rows=databases.map(db=>securityDatabaseCard(db,false)).join('');return rows?`<div class="security-db-export-bar"><span class="muted">Toate instanțele acestei VM</span><a class="button-link small secondary" href="/api/v1/security/databases/export?vm_id=${Number(vmID)}">Export Excel</a></div>${rows}`:empty('Nu există date Database Access pentru această VM. Verifică agentul 1.7.12 și rulează o colectare noua.')}
function securityVMWebAccess(vmID,data){
 const sites=[...(data?.web_sites||[])].sort(securityWebSiteOrder);
 if(!sites.length)return empty('Nu există site-uri Web inventariate pentru această VM.');
 if(!state.securityWebVMFilters||Number(state.securityWebVMFilters.vmId)!==Number(vmID))state.securityWebVMFilters={vmId:Number(vmID),q:'',onlyACL:false,expanded:false};
 const f=state.securityWebVMFilters;
 const filters=`<label class="security-web-search-label"><span>Căutare generală</span><input type="search" class="security-web-vm-search" value="${e(f.q)}" placeholder="Site, adresă, ALLOW/DENY, directivă, fișier…"></label><label class="security-web-check-label"><span>Reguli ACL</span><span class="security-web-check-inline"><input type="checkbox" class="security-web-only-acl" ${f.onlyACL?'checked':''}> Doar cele cu ACL</span></label><button type="button" class="small secondary security-web-vm-reset">Resetează</button>`;
 return `${securityWebControls(vmID,sites,filters)}${sites.map(site=>securityWebCard(site,false)).join('')}<p class="muted security-web-no-match" hidden>Nu există site-uri pentru filtrele selectate.</p>`;
}

function fortigateDirectionBadge(value){const labels={source:'VM → destinație',destination:'Sursă → VM',vip:'VIP / DNAT → VM'};return `<span class="badge ${e(value||'unknown')}">${e(labels[value]||value||'—')}</span>`}
function fortigateRiskHTML(risks=[]){return risks.length?`<div class="vm-service-tags">${risks.map(r=>`<span class="badge missing">${e(r)}</span>`).join('')}</div>`:'<span class="muted">—</span>'}
function firewallLines(values,extra=''){
  const vals=Array.isArray(values)?values.filter(x=>String(x||'').trim()):[];
  return vals.length?`<div class="firewall-stacked">${vals.map(v=>`<div>${e(v)}</div>`).join('')}</div>`:'<span class="muted">—</span>';
}
// 0.21.42: consistent review in 3 table columns and expandable policy details.
function securityReviewedProgress(rows=[],noun='reguli'){
 const total=rows.length,reviewed=rows.filter(x=>Boolean(x?.review?.reviewed_at)).length;
 return `<span class="security-reviewed-progress" aria-label="Revizuite ${reviewed} din ${total} ${noun}">Revizuite <strong>${reviewed.toLocaleString('ro-RO')}</strong> din <strong>${total.toLocaleString('ro-RO')}</strong> ${e(noun)}</span>`;
}
function firewallOverviewRow(mode,cards=''){
 return `<div class="firewall-overview-row">${firewallViewSwitch(mode)}${cards?`<div class="firewall-overview-kpis" data-firewall-overview-kpis ${mode==='local'?'hidden':''}>${cards}</div>`:''}</div>`;
}
function firewallReviewedBar(rows=[],note='',noun='reguli'){
 return `<div class="firewall-reviewed-bar">${securityReviewedProgress(rows,noun)}${note}</div>`;
}
function firewallReviewCompact(row){
 const v=row.review||{};
 if(!v.resource_key)return securityReviewNotApplicable();
 return securityReviewCell(row.vm_id,'firewall',v.resource_key,v,6,{vmName:row.vm_name,resource:`Policy #${row.policy_id} · ${row.source_name||'FortiGate'}`});
}
function firewallPolicyDetailRow(r,columns=11){
 const parts=[
  ['Policy',r.policy_name||'—'],['FortiGate',r.source_name||'—'],['VDOM',r.vdom||'root'],
  ['Corelat prin',r.match_object||'—'],['Motiv corelare',r.match_reason||'—'],
  ['Schedule',r.schedule||'—'],['Stare',r.status||'—']
 ];
 const grid=parts.map(([label,value])=>`<div><span class="muted">${e(label)}</span><strong>${e(value)}</strong></div>`).join('');
 return `<tr class="firewall-rule-detail-row" data-firewall-detail-row hidden><td colspan="${columns}"><div class="firewall-policy-detail-grid">${grid}<div class="firewall-policy-detail-flags"><span class="muted">Indicatori</span>${fortigateRiskHTML(r.risks||[])}</div></div></td></tr>`;
}
function fortigateRuleRows(items=[],showVM=true){
 return items.map((r,i)=>`<tr class="fortigate-rule-row" data-direction="${e(r.direction||'')}" data-risk="${(r.risks||[]).length?'1':'0'}">
   <td>${showVM?`<a href="#vms/${Number(r.vm_id)}/security-firewall"><strong>${e(r.vm_name)}</strong></a><div class="muted mono">${e(r.vm_ip||'')}</div>`:`<strong class="mono">${e(r.vm_ip||'—')}</strong>`}</td>
   <td class="firewall-role" title="${e(r.direction==='source'?'VM sursă':r.direction==='destination'?'VM destinație':'VIP / DNAT')}">${e(r.direction==='source'?'Sursă':r.direction==='destination'?'Dest.':'VIP')}</td>
   <td class="firewall-policy"><button type="button" class="firewall-policy-toggle" aria-expanded="false" aria-label="Detalii policy #${Number(r.policy_id)}" title="Extinde detalii policy #${Number(r.policy_id)}"><span class="firewall-policy-chevron" aria-hidden="true">▸</span><strong>#${Number(r.policy_id)}</strong></button></td>
   <td><div class="firewall-interface"><small>Sursă</small>${firewallLines(r.srcintf)}</div><div class="firewall-interface"><small>Dest.</small>${firewallLines(r.dstintf)}</div></td>
   <td>${firewallLines(r.srcaddr)}</td>
   <td>${firewallLines(r.dstaddr)}${r.vip_name?`<div class="muted">VIP: ${e(r.vip_name)}</div>`:''}</td>
   <td>${firewallLines(r.services)}</td>
   <td>${badge(r.action||'—')}${r.nat?' <span class="badge">NAT</span>':''}</td>
   <td>${firewallReviewCompact(r)}</td>
 </tr>${firewallPolicyDetailRow(r)}`).join('');
}
function fortigateRulesTable(data,showVM=true,extraClass=''){
 const rows=fortigateRuleRows(data?.items||[],showVM);
 return rows?`<div class="table-wrap fortigate-table-wrap ${e(extraClass)}" tabindex="0" aria-label="Tabel firewall, derulare orizontală"><table class="fortigate-rules-table" data-sortable="false"><thead><tr><th>${showVM?'VM / IP':'IP VM'}</th><th>Rol</th><th>Policy #</th><th>Interfețe</th><th>Sursă</th><th>Destinație</th><th>Servicii</th><th>Acțiune</th><th>Review</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există reguli FortiGate corelate pentru selecția curentă.');
}
function bindFirewallPolicyDetails(root=document){
 root.querySelectorAll('.firewall-policy-toggle:not([data-fw-bound])').forEach(button=>{
   button.dataset.fwBound='1';
   button.addEventListener('click',()=>{
    const row=button.closest('tr')?.nextElementSibling;
    if(!row?.matches('[data-firewall-detail-row]'))return;
    const open=button.getAttribute('aria-expanded')!=='true';
    row.hidden=!open;button.setAttribute('aria-expanded',String(open));
    button.setAttribute('title',open?'Restrânge detaliile':'Extinde detaliile');
   });
 });
}
function fortigateSourceRows(sources=[]){return sources.map(src=>`<tr><td><strong>${e(src.name)}</strong><div class="muted mono">${e(src.base_url)}</div></td><td>${e(src.vdom||'root')}</td><td>${src.enabled?badge('active'):badge('disabled')}</td><td>${src.verify_tls?'Da':'Nu'}</td><td>${Number(src.sync_interval_minutes||15)} min</td><td>${dt(src.last_success_at)}${src.last_error?`<div class="warning-text">${e(src.last_error)}</div>`:''}</td><td>${can('fortigate.manage')?`<div class="actions fortigate-source-actions"><button class="small secondary fortigate-source-action" data-action="test" data-id="${src.id}">Test</button><button class="small secondary fortigate-source-action" data-action="sync" data-id="${src.id}">Sync</button><button class="small secondary fortigate-source-action" data-action="edit" data-id="${src.id}">Editează</button><button class="small danger fortigate-source-action" data-action="delete" data-id="${src.id}">Șterge</button></div>`:'—'}</td></tr>`).join('')}
function fortigateSourceForm(source=null){const create=!source;return `<form id="fortigateSourceForm" class="fortigate-source-form" data-id="${source?.id||''}"><div class="form-grid fortigate-source-form-grid"><label>Nume<input id="fortigateSourceName" required value="${e(source?.name||'FortiGate')}" placeholder="FW-PROD"></label><label class="span-2">URL FortiGate<input id="fortigateSourceURL" required value="${e(source?.base_url||'https://')}" placeholder="https://10.0.0.1"></label><label>VDOM<input id="fortigateSourceVDOM" value="${e(source?.vdom||'root')}" placeholder="root"></label><label>Interval sync (minute)<input id="fortigateSourceInterval" type="number" min="1" max="1440" value="${Number(source?.sync_interval_minutes||15)}"></label><label>TLS server name<input id="fortigateTLSServerName" value="${e(source?.tls_server_name||'')}" placeholder="opțional"></label><label class="span-2">API token<input id="fortigateSourceToken" type="password" ${create?'required':''} value="" autocomplete="new-password" placeholder="${create?'Token obligatoriu':'Gol = păstrează tokenul curent'}"></label></div><div class="fortigate-source-options"><label><input id="fortigateVerifyTLS" type="checkbox" ${source?.verify_tls!==false?'checked':''}> Verifică certificatul TLS</label><label><input id="fortigateSourceEnabled" type="checkbox" ${source?.enabled!==false?'checked':''}> Sursă activă</label></div><div class="form-actions"><button type="submit">${create?'Adaugă sursa':'Salvează modificările'}</button><button id="cancelFortigateSource" type="button" class="secondary">Renunță</button></div></form>`}
function fortigateRuleParams(){const f=state.fortigateFilters,p=new URLSearchParams({page:String(f.page||1),page_size:String(f.pageSize||50)});if(f.q)p.set('q',f.q);if(f.sourceId)p.set('source_id',f.sourceId);if(f.direction)p.set('direction',f.direction);if(f.risk)p.set('risk',f.risk);if(f.action)p.set('action',f.action);if(f.status)p.set('status',f.status);if(f.service)p.set('service',f.service);if(f.iface)p.set('interface',f.iface);if(f.vdom)p.set('vdom',f.vdom);if(f.review)p.set('review',f.review);return p.toString()}
function fortigateExportURL(extra={},useCurrent=true){const p=useCurrent?new URLSearchParams(fortigateRuleParams()):new URLSearchParams();p.delete('page');p.delete('page_size');Object.entries(extra).forEach(([k,v])=>{if(v)p.set(k,String(v));else p.delete(k)});return `/api/v1/fortigate/rules/export?${p.toString()}`}
function fortigateVMFilterKPI(label,value,filter){return `<button type="button" class="dashboard-kpi fortigate-vm-filter-card" data-filter="${e(filter)}"><span>${e(label)}</span><strong>${Number(value||0).toLocaleString('ro-RO')}</strong></button>`}
function bindVMFortigateCardFilters(vmID){let active='';const rows=[...document.querySelectorAll('.vm-fortigate-table .fortigate-rule-row')],cards=[...document.querySelectorAll('.fortigate-vm-filter-card')],count=document.getElementById('vmFortigateVisibleCount'),exportLink=document.getElementById('vmFortigateExport');const apply=()=>{let shown=0;rows.forEach(row=>{const ok=!active||(active==='risk'?row.dataset.risk==='1':row.dataset.direction===active);row.hidden=!ok;const detail=row.nextElementSibling;if(detail?.matches('[data-firewall-detail-row]')){detail.hidden=true;const toggle=row.querySelector('.firewall-policy-toggle');if(toggle)toggle.setAttribute('aria-expanded','false');}if(ok)shown++});cards.forEach(card=>card.classList.toggle('active-filter',card.dataset.filter===active));if(count)count.textContent=`${shown} din ${rows.length} corelări`;if(exportLink){const extra={vm_id:vmID};if(active==='risk')extra.risk='high';else if(active)extra.direction=active;exportLink.href=fortigateExportURL(extra,false)}};cards.forEach(card=>card.addEventListener('click',()=>{active=active===card.dataset.filter?'':card.dataset.filter;apply()}));apply()}
function bindFortigateSourceEditor(source=null){const form=document.getElementById('fortigateSourceForm');if(!form)return;document.getElementById('cancelFortigateSource')?.addEventListener('click',()=>{state.fortigateSourceEdit=0;securityPage('firewall-sources')});form.addEventListener('submit',async ev=>{ev.preventDefault();const create=!source,token=document.getElementById('fortigateSourceToken').value.trim();if(create&&!token){toast('API token este obligatoriu.',true);return}const body={name:document.getElementById('fortigateSourceName').value.trim(),base_url:document.getElementById('fortigateSourceURL').value.trim(),vdom:document.getElementById('fortigateSourceVDOM').value.trim()||'root',api_token:token,sync_interval_minutes:Number(document.getElementById('fortigateSourceInterval').value||15),verify_tls:document.getElementById('fortigateVerifyTLS').checked,enabled:document.getElementById('fortigateSourceEnabled').checked,tls_server_name:document.getElementById('fortigateTLSServerName').value.trim()};try{await api(source?`/api/v1/fortigate/sources/${source.id}`:'/api/v1/fortigate/sources',{method:source?'PATCH':'POST',body:JSON.stringify(body)});toast(source?'Sursa FortiGate a fost actualizată.':'Sursa FortiGate a fost creată.');state.fortigateSourceEdit=0;await securityPage('firewall-sources',true)}catch(err){toast(err.message,true)}})}
function firewallViewSwitch(mode='forti'){
 return `<div class="firewall-source-cards" role="group" aria-label="Tip Firewall"><button type="button" class="firewall-source-card ${mode==='forti'?'active':''}" data-firewall-mode="forti" aria-pressed="${mode==='forti'}"><span class="firewall-source-card-icon">🛡️</span><span><strong>FortiGate</strong><small>Reguli centralizate corelate</small></span></button><button type="button" class="firewall-source-card ${mode==='local'?'active':''}" data-firewall-mode="local" aria-pressed="${mode==='local'}"><span class="firewall-source-card-icon"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18m-13 5h3"/></svg></span><span><strong>Local</strong><small>Reguli colectate de agent</small></span></button></div>`;
}
let firewallFilterId=0;
function firewallFilterPanel(fields,actions,expanded=false){
 const id=`firewallUnifiedFields-${++firewallFilterId}`;return `<section class="firewall-filter-panel"><div class="firewall-filter-head"><strong>Filtre</strong><div class="firewall-filter-actions">${actions}</div><button type="button" class="small secondary firewall-filter-toggle" aria-controls="${id}" aria-expanded="${expanded}" aria-label="${expanded?'Restrânge':'Extinde'} filtrele" title="Filtre">${expanded?'⌃':'⌄'}</button></div><div id="${id}" class="firewall-filter-body" ${expanded?'':'hidden'}>${fields}</div></section>`;
}
function bindFirewallFilterPanel(){const btn=document.querySelector('.firewall-filter-toggle'),fields=document.querySelector('.firewall-filter-body');btn?.addEventListener('click',()=>{const open=btn.getAttribute('aria-expanded')!=='true';btn.setAttribute('aria-expanded',String(open));btn.setAttribute('aria-label',open?'Restrânge filtrele':'Extinde filtrele');btn.textContent=open?'⌃':'⌄';fields.hidden=!open;state.firewallFiltersOpen=open;});}
function firewallBulkVMSelect(items=[]){
 const map=new Map();for(const row of items){if(row.vm_id>0)map.set(Number(row.vm_id),String(row.vm_name||`VM #${row.vm_id}`));}
 const options=[...map].sort((a,b)=>a[1].localeCompare(b[1])).map(([id,name])=>`<option value="${id}">${e(name)}</option>`).join('');
 return can('vms.manage')?`<select id="firewallBulkVM" aria-label="VM pentru revizie colectivă"><option value="">Alege VM…</option>${options}</select><button type="button" id="firewallBulkReview" class="small secondary security-review-bulk" data-scope="firewall" data-label="Reguli FortiGate ale VM" data-vm="" data-count="0" disabled>Revizuiește secțiunea</button>`:'';
}
async function firewallLocalGlobalPage(){
 pageMeta('Securitate','Firewall local · reguli colectate de agent');const vmId=Number(state.firewallLocalVM||0),q=String(state.firewallLocalSearch||'');
 let vmData=null,err='';if(vmId){try{vmData=await api(`/api/v1/security/firewall/local?vm_id=${vmId}`)}catch(ex){err=ex.message||'VM negăsită';}}
 const vmName=vmData?.vm_name||'';const rules=vmData?firewallLocalServerTable(vmData):empty('Caută și selectează o VM pentru a vedea regulile locale colectate de agent.');
 const fields=`<div class="firewall-local-search"><label>Caută VM<input id="firewallLocalSearch" type="search" value="${e(q)}" placeholder="Nume VM, hostname sau IP…"></label><select id="firewallLocalVM" aria-label="Selectează VM"><option value="">Alege VM…</option>${vmId?`<option value="${vmId}" selected>${e(vmName||'VM selectată')}</option>`:''}</select><button id="firewallLocalFind" class="small secondary" type="button">Caută VM</button></div>`;
 const actions=`${vmId?`<a class="button-link small secondary" href="/api/v1/security/firewall/local/export?vm_id=${vmId}">Export Excel</a>${can('vms.manage')?`<button type="button" class="small secondary security-review-bulk" data-vm="${vmId}" data-scope="firewall_local" data-label="Reguli locale ale VM" data-count="${(vmData?.rules||[]).length}" ${(vmData?.rules||[]).length?'':'disabled'}>Revizuiește secțiunea</button>`:''}<a class="button-link small secondary" href="#vms/${vmId}/security-firewall">Fișa VM</a>`:'<span class="muted">Selectează VM pentru export</span>'}`;
 content.innerHTML=`<div class="monitoring-workspace security-workspace firewall-workspace">${securityNav('firewall')}<div class="report-header"><div><strong>Firewall</strong><span>Reguli locale din inventarul agentului; lista este limitată la VM-ul selectat.</span></div></div>${firewallOverviewRow('local')}${err?`<div class="notice warning">${e(err)}</div>`:''}${panel(vmId?`Firewall local · ${vmName}`:'Reguli locale',`<div class="firewall-local-inline-search">${fields}</div>${vmData?firewallReviewedBar(vmData.rules||[]):''}${rules}`,actions,'firewall-local-panel')}</div>`;
 document.querySelectorAll('[data-firewall-mode]').forEach(btn=>btn.onclick=()=>{state.firewallMode=btn.dataset.firewallMode;securityPage('firewall')});bindFirewallFilterPanel();
 const search=async()=>{const input=document.getElementById('firewallLocalSearch'),select=document.getElementById('firewallLocalVM');if(!input||!select)return;state.firewallLocalSearch=input.value.trim();try{const result=await api(`/api/v1/vms?page=1&page_size=50&q=${encodeURIComponent(state.firewallLocalSearch)}`);const items=result.items||[];select.innerHTML='<option value="">Alege VM…</option>'+items.map(x=>`<option value="${Number(x.id)}">${e(x.name||x.hostname||`VM #${x.id}`)}</option>`).join('');if(items.length===1)select.value=items[0].id;}catch(ex){toast(ex.message,true)}};
 document.getElementById('firewallLocalFind')?.addEventListener('click',search);
 document.getElementById('firewallLocalSearch')?.addEventListener('keydown',ev=>{if(ev.key==='Enter'){ev.preventDefault();search()}});
 document.getElementById('firewallLocalVM')?.addEventListener('change',ev=>{state.firewallLocalVM=Number(ev.target.value)||0;firewallLocalGlobalPage()});bindSecurityReviewButtons(content);
}
async function fortigateSecurityPage(force=false){if(state.firewallMode==='local')return firewallLocalGlobalPage();pageMeta('Securitate','Firewall · caută reguli corelate');const f=state.fortigateFilters;const [sources,data]=await Promise.all([api('/api/v1/fortigate/sources').catch(()=>[]),api(`/api/v1/fortigate/rules?${fortigateRuleParams()}`).catch(err=>({items:[],total:0,page:1,pages:0,page_size:f.pageSize,error:err.message}))]);state.fortigateSources=Array.isArray(sources)?sources:[];const sourceOptions=state.fortigateSources.map(x=>`<option value="${x.id}" ${String(f.sourceId)===String(x.id)?'selected':''}>${e(x.name)} · ${e(x.vdom||'root')}</option>`).join('');const filters=`<div class="filterbar fortigate-search-filters"><label class="fortigate-search-main"><span>Caută</span><input id="fortigateSearch" type="search" value="${e(f.q||'')}" placeholder="VM, IP, policy, obiect, serviciu…"></label><label><span>FortiGate</span><select id="fortigateSourceFilter"><option value="">Toate</option>${sourceOptions}</select></label><label><span>Rol VM</span><select id="fortigateDirection"><option value="">Toate</option><option value="source" ${f.direction==='source'?'selected':''}>VM sursă</option><option value="destination" ${f.direction==='destination'?'selected':''}>VM destinație</option><option value="vip" ${f.direction==='vip'?'selected':''}>VIP / DNAT</option></select></label><label><span>VDOM</span><select id="fortigateVDOM"><option value="">Toate</option>${[...new Set(state.fortigateSources.map(x=>x.vdom).filter(Boolean))].sort().map(v=>`<option value="${e(v)}" ${f.vdom===v?'selected':''}>${e(v)}</option>`).join('')}</select></label><label><span>Action</span><select id="fortigateAction"><option value="">Toate</option><option value="accept" ${f.action==='accept'?'selected':''}>ACCEPT</option><option value="deny" ${f.action==='deny'?'selected':''}>DENY</option></select></label><label><span>Policy</span><select id="fortigateStatus"><option value="">Doar active</option><option value="enable" ${f.status==='enable'?'selected':''}>Enabled explicit</option></select></label><label><span>Service</span><input id="fortigateService" value="${e(f.service||'')}" placeholder="HTTPS, ALL…"></label><label><span>Interfață</span><input id="fortigateInterface" value="${e(f.iface||'')}" placeholder="wan1, VLAN_APP…"></label><label><span>Indicator</span><select id="fortigateRisk"><option value="">Toate</option><option value="high" ${f.risk==='high'?'selected':''}>Necesită atenție</option><option value="source_all" ${f.risk==='source_all'?'selected':''}>source ALL</option><option value="destination_all" ${f.risk==='destination_all'?'selected':''}>destination ALL</option><option value="service_all" ${f.risk==='service_all'?'selected':''}>service ALL</option><option value="wan" ${f.risk==='wan'?'selected':''}>WAN → VM</option><option value="vip" ${f.risk==='vip'?'selected':''}>VIP / DNAT</option></select></label><label><span>Review</span><select id="fortigateReview"><option value="">Toate</option><option value="due" ${f.review==='due'?'selected':''}>Necesită review</option><option value="unreviewed" ${f.review==='unreviewed'?'selected':''}>Nerevizuite</option><option value="current" ${f.review==='current'?'selected':''}>La zi</option></select></label><button id="fortigateReset" class="secondary" type="button">Resetează</button></div>`;const cards=`<div class="cards report-summary fortigate-summary-cards">${securityKPI('Surse',data.sources??state.fortigateSources.filter(x=>x.enabled).length)}${securityKPI('VM sursă',data.source_matches)}${securityKPI('VM destinație',data.destination_matches)}${securityKPI('VIP / DNAT',data.vip_matches)}${securityKPI('Cu indicatori',data.high_risk)}</div>`;const pager=securityPager({page:data.page||1,pageSize:data.page_size||f.pageSize,pages:data.pages||1,total:data.total||0,offset:((data.page||1)-1)*(data.page_size||f.pageSize),end:Math.min((data.page||1)*(data.page_size||f.pageSize),data.total||0)},'fortigate',[25,50,100,200,500]);const tools=`<a class="button-link small secondary" href="${fortigateExportURL()}">Export Excel</a>${firewallBulkVMSelect(data.items||[])}<button id="refreshFortigate" class="small secondary">Reîncarcă</button>`;content.innerHTML=`<div class="monitoring-workspace security-workspace firewall-workspace">${securityNav('firewall')}<div class="report-header"><div><strong>Firewall · Caută</strong><span>Reguli corelate, cu detaliile tehnice disponibile la click.</span></div></div>${firewallOverviewRow('forti',cards)}${panel('Reguli corelate',`${firewallReviewedBar(data.items||[],data.total>data.items?.length?`<span class="muted firewall-page-review-note">(pagina curentă · ${Number(data.total||0)} corelări total)</span>`:'')}<details class="firewall-advanced-search"><summary>Căutare avansată</summary>${filters}</details>${fortigateRulesTable(data,true,'fortigate-global-table')}`,tools,'fortigate-wide-panel')}${pager}</div>`;let timer;document.getElementById('fortigateSearch')?.addEventListener('input',ev=>{clearTimeout(timer);const value=ev.target.value;timer=setTimeout(()=>{f.q=value;f.page=1;securityPage('firewall')},180)});[['fortigateSourceFilter','sourceId'],['fortigateDirection','direction'],['fortigateVDOM','vdom'],['fortigateAction','action'],['fortigateStatus','status'],['fortigateRisk','risk'],['fortigateReview','review']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{f[key]=ev.target.value;f.page=1;securityPage('firewall')}));['fortigateService','fortigateInterface'].forEach((id,idx)=>{let t;document.getElementById(id)?.addEventListener('input',ev=>{clearTimeout(t);t=setTimeout(()=>{if(idx===0)f.service=ev.target.value;else f.iface=ev.target.value;f.page=1;securityPage('firewall')},220)})});document.getElementById('fortigateReset')?.addEventListener('click',()=>{state.fortigateFilters={q:'',sourceId:'',direction:'',risk:'',action:'',status:'',service:'',iface:'',vdom:'',review:'',page:1,pageSize:f.pageSize||50};securityPage('firewall')});document.querySelectorAll('.fortigate-page').forEach(b=>b.addEventListener('click',()=>{f.page=Number(b.dataset.page);securityPage('firewall')}));document.getElementById('fortigatePageSize')?.addEventListener('change',ev=>{f.pageSize=Number(ev.target.value);f.page=1;securityPage('firewall')});document.getElementById('refreshFortigate')?.addEventListener('click',()=>securityPage('firewall',true));bindSecurityReviewButtons(content);bindFirewallFilterPanel();document.querySelectorAll('[data-firewall-mode]').forEach(b=>b.onclick=()=>{state.firewallMode=b.dataset.firewallMode;securityPage('firewall')});document.getElementById('firewallBulkVM')?.addEventListener('change',ev=>{const btn=document.getElementById('firewallBulkReview');btn.dataset.vm=ev.target.value;btn.disabled=!ev.target.value});}
async function fortigateSourcesPage(force=false){pageMeta('Securitate','Firewall · surse și sincronizare');const [sources,runs]=await Promise.all([api('/api/v1/fortigate/sources').catch(()=>[]),api('/api/v1/fortigate/sync-runs?page=1&page_size=20').catch(()=>({items:[]}))]);state.fortigateSources=Array.isArray(sources)?sources:[];const editID=state.fortigateSourceEdit,editSource=editID&&editID!=='new'?state.fortigateSources.find(x=>Number(x.id)===Number(editID)):null,editor=can('fortigate.manage')&&editID?panel(editID==='new'?'Adaugă sursă FortiGate':`Editează ${editSource?.name||'sursa FortiGate'}`,fortigateSourceForm(editSource||null)):'';const srcRows=fortigateSourceRows(state.fortigateSources),sourcePanel=panel('Surse FortiGate',srcRows?`<div class="table-wrap fortigate-source-table"><table><thead><tr><th>Sursă</th><th>VDOM</th><th>Stare</th><th>TLS</th><th>Interval</th><th>Ultimul sync</th><th></th></tr></thead><tbody>${srcRows}</tbody></table></div>`:empty('Nu este configurată nicio sursă FortiGate.'),can('fortigate.manage')?'<button id="newFortigate" class="small">Adaugă FortiGate</button><button id="syncAllFortigate" class="small secondary">Sync toate</button>':'');const runsRows=(runs.items||[]).map(r=>`<tr><td>${e(r.source_name||'—')}</td><td>${badge(r.status||'—')}</td><td>${dt(r.started_at||r.created_at)}</td><td>${r.policy_count||0}</td><td>${r.disabled_policy_count||0}</td><td>${r.match_count||0}</td><td>${e(r.error_message||'—')}</td></tr>`).join(''),runPanel=panel('Sincronizări recente',runsRows?`<div class="table-wrap fortigate-run-table"><table><thead><tr><th>Sursă</th><th>Status</th><th>Pornit</th><th>Policies active</th><th>Disabled ignorate</th><th>Corelări</th><th>Eroare</th></tr></thead><tbody>${runsRows}</tbody></table></div>`:empty('Nu există sincronizări FortiGate.'));content.innerHTML=`<div class="monitoring-workspace security-workspace">${securityNav('firewall-sources')}<div class="report-header"><div><strong>Firewall · Surse & Sync</strong><span>Configurare FortiGate într-o singură interfață, test și sincronizare.</span></div><div class="actions"><button id="refreshFortigateSources" class="secondary">Reîncarcă</button></div></div>${editor}${sourcePanel}${runPanel}</div>`;document.getElementById('newFortigate')?.addEventListener('click',()=>{state.fortigateSourceEdit='new';securityPage('firewall-sources')});document.getElementById('syncAllFortigate')?.addEventListener('click',async()=>{try{const v=await api('/api/v1/fortigate/sync',{method:'POST'});toast(`${Array.isArray(v)?v.length:0} sincronizări pornite.`);setTimeout(()=>securityPage('firewall-sources',true),1200)}catch(err){toast(err.message,true)}});document.querySelectorAll('.fortigate-source-action').forEach(b=>b.addEventListener('click',async()=>{const src=state.fortigateSources.find(x=>Number(x.id)===Number(b.dataset.id));try{if(b.dataset.action==='edit'){state.fortigateSourceEdit=Number(b.dataset.id);await securityPage('firewall-sources');return}if(b.dataset.action==='delete'){if(!confirm(`Ștergi sursa ${src?.name||''} și inventarul ei FortiGate?`))return;await api(`/api/v1/fortigate/sources/${b.dataset.id}`,{method:'DELETE'});toast('Sursa FortiGate a fost ștearsă.');if(Number(state.fortigateSourceEdit)===Number(b.dataset.id))state.fortigateSourceEdit=0;await securityPage('firewall-sources',true);return}if(b.dataset.action==='test'){const v=await api(`/api/v1/fortigate/sources/${b.dataset.id}/test`,{method:'POST'});toast(`Conectare reușită · ${v.policies||0} active + ${v.policies_disabled||0} disabled = ${v.policies_total??((v.policies||0)+(v.policies_disabled||0))} policies · ${v.addresses_matchable||0}/${v.addresses||0} adrese corelabile · ${v.groups||0} grupuri · ${v.vips||0} VIP.`);return}if(b.dataset.action==='sync'){await api(`/api/v1/fortigate/sources/${b.dataset.id}/sync`,{method:'POST'});toast('Sincronizarea FortiGate a fost pornită.');setTimeout(()=>securityPage('firewall-sources',true),1200)}}catch(err){toast(err.message,true)}}));document.getElementById('refreshFortigateSources')?.addEventListener('click',()=>securityPage('firewall-sources',true));bindFortigateSourceEditor(editSource||null)}

function fortigateAnalysisParams(){const f=state.fortigateAnalysisFilters,p=new URLSearchParams({page:String(f.page||1),page_size:String(f.pageSize||50)});if(f.q)p.set('q',f.q);if(f.sourceId)p.set('source_id',f.sourceId);if(f.vdom)p.set('vdom',f.vdom);if(f.classification)p.set('classification',f.classification);if(f.flag)p.set('flag',f.flag);return p.toString()}
function fortigateAnalysisTable(data){const rows=(data.items||[]).map(item=>{const flags=(item.flags||[]).map(x=>badge(x)).join(' ');const match=item.match_count>0?`<strong>${item.vm_count||0} VM · ${item.match_count} corelări</strong><small>${item.source_matches||0} src · ${item.destination_matches||0} dst · ${item.vip_matches||0} VIP</small>${(item.matched_vms||[]).length?`<small title="${e((item.matched_vms||[]).join(', '))}">${e((item.matched_vms||[]).slice(0,5).join(', '))}${(item.matched_vms||[]).length>5?' …':''}</small>`:''}`:'<strong>0</strong><small>fără VM corelat</small>';return `<tr><td><strong>${e(item.source_name)}</strong><small>${e(item.vdom)}</small></td><td><strong>#${e(item.policy_id)} ${e(item.policy_name||'')}</strong><small>${e(item.comments||'fără comentariu')}</small></td><td>${e((item.srcaddr||[]).join(', ')||'—')}<small>${e((item.srcintf||[]).join(', ')||'')}</small></td><td>${e((item.dstaddr||[]).join(', ')||'—')}<small>${e((item.dstintf||[]).join(', ')||'')}</small></td><td>${e((item.services||[]).join(', ')||'—')}<small>${e(item.action||'—')}${item.nat?' · NAT':''}</small></td><td class="network-analysis-match">${match}</td><td>${flags||badge(item.classification||'—')}</td></tr>`}).join('');return rows?`<div class="table-wrap fortigate-table-wrap fortigate-analysis-wrap"><table class="fortigate-analysis-table"><thead><tr><th>FortiGate</th><th>Policy</th><th>Sursă</th><th>Destinație</th><th>Service</th><th>Corelări VM</th><th>Indicatori</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nicio policy pentru filtrele selectate.')}
async function fortigateAnalysisPage(force=false){pageMeta('Securitate','Analiză policy FortiGate · corelare cu inventarul VM-DOC');const f=state.fortigateAnalysisFilters;const [sources,data]=await Promise.all([api('/api/v1/fortigate/sources').catch(()=>[]),api(`/api/v1/fortigate/analysis?${fortigateAnalysisParams()}`).catch(err=>({items:[],total:0,page:1,pages:0,page_size:f.pageSize,error:err.message}))]);state.fortigateSources=Array.isArray(sources)?sources:[];const sourceOptions=state.fortigateSources.map(x=>`<option value="${x.id}" ${String(f.sourceId)===String(x.id)?'selected':''}>${e(x.name)} · ${e(x.vdom||'root')}</option>`).join('');const filters=`<div class="filterbar fortigate-analysis-filters"><label class="fortigate-search-main"><span>Caută</span><input id="fortiAnalysisSearch" type="search" value="${e(f.q||'')}" placeholder="policy, obiect, service, comentariu…"></label><label><span>FortiGate</span><select id="fortiAnalysisSource"><option value="">Toate</option>${sourceOptions}</select></label><label><span>VDOM</span><input id="fortiAnalysisVDOM" value="${e(f.vdom||'')}" placeholder="root, INTRANET…"></label><label><span>Clasificare</span><select id="fortiAnalysisClass"><option value="" ${!f.classification?'selected':''}>Toate</option><option value="review" ${f.classification==='review'?'selected':''}>Necesită verificare</option><option value="uncorrelated" ${f.classification==='uncorrelated'?'selected':''}>Necorelate cu inventarul</option><option value="correlated" ${f.classification==='correlated'?'selected':''}>Corelate</option><option value="broad" ${f.classification==='broad'?'selected':''}>Prea largi</option></select></label><label><span>Indicator</span><select id="fortiAnalysisFlag"><option value="">Toate</option><option value="all" ${f.flag==='all'?'selected':''}>ALL</option><option value="fără vm" ${f.flag==='fără vm'?'selected':''}>Fără VM corelat</option><option value="comentariu" ${f.flag==='comentariu'?'selected':''}>Fără comentariu</option></select></label><button id="fortiAnalysisReset" class="secondary" type="button">Resetează</button></div>`;const cards=`<div class="cards report-summary fortigate-summary-cards">${securityKPI('Policies active',data.active_policies||0)}${securityKPI('Corelate',data.correlated||0)}${securityKPI('Necorelate',data.uncorrelated||0)}${securityKPI('Prea largi',data.broad||0)}${securityKPI('Necesită verificare',data.candidate_review||0)}</div>`;const pager=securityPager({page:data.page||1,pageSize:data.page_size||f.pageSize,pages:data.pages||1,total:data.total||0,offset:((data.page||1)-1)*(data.page_size||f.pageSize),end:Math.min((data.page||1)*(data.page_size||f.pageSize),data.total||0)},'forti-analysis',[25,50,100,200,500]);content.innerHTML=`<div class="monitoring-workspace security-workspace">${securityNav('firewall-analysis')}<div class="report-header"><div><strong>Firewall Hygiene</strong><span>Corelare configurație FortiGate ↔ inventar VM-DOC. O policy necorelată NU este declarată automat inutilă.</span></div><div class="actions"><a class="button-link small secondary" href="#security/firewall">Firewall central</a><button id="refreshFortiAnalysis" class="secondary">Reîncarcă</button></div></div><div class="notice"><strong>Regulă de interpretare.</strong> <span>„Necorelată” înseamnă doar că nu găsim VM-uri din VM-DOC în source/destination/VIP. Poate deservi stații, echipamente, rețele sau active neinventariate. Fără hit-count / last-used nu o marcăm drept „de șters”.</span></div>${cards}${securityFilterShell(filters,'firewall-analysis',f)}${panel('Analiză policies active',fortigateAnalysisTable(data),'','fortigate-wide-panel')}${pager}</div>`;bindSecurityFilterShell('firewall-analysis');let timer;document.getElementById('fortiAnalysisSearch')?.addEventListener('input',ev=>{clearTimeout(timer);timer=setTimeout(()=>{f.q=ev.target.value;f.page=1;securityPage('firewall-analysis')},180)});[['fortiAnalysisSource','sourceId'],['fortiAnalysisClass','classification'],['fortiAnalysisFlag','flag']].forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',ev=>{f[key]=ev.target.value;f.page=1;securityPage('firewall-analysis')}));let vt;document.getElementById('fortiAnalysisVDOM')?.addEventListener('input',ev=>{clearTimeout(vt);vt=setTimeout(()=>{f.vdom=ev.target.value;f.page=1;securityPage('firewall-analysis')},220)});document.getElementById('fortiAnalysisReset')?.addEventListener('click',()=>{state.fortigateAnalysisFilters={q:'',sourceId:'',vdom:'',classification:'review',flag:'',page:1,pageSize:f.pageSize||50};securityPage('firewall-analysis')});document.querySelectorAll('.forti-analysis-page').forEach(b=>b.addEventListener('click',()=>{f.page=Number(b.dataset.page);securityPage('firewall-analysis')}));document.getElementById('forti-analysisPageSize')?.addEventListener('change',ev=>{f.pageSize=Number(ev.target.value);f.page=1;securityPage('firewall-analysis')});document.getElementById('refreshFortiAnalysis')?.addEventListener('click',()=>securityPage('firewall-analysis',true))}

function securityVMFirewallAccess(vmID,data,documentView){
 const mode=state.vmFirewallMode?.[vmID]||'forti';
 const cards=`<div class="cards report-summary vm-fortigate-kpis">${fortigateVMFilterKPI('Ca sursă',data?.source_matches,'source')}${fortigateVMFilterKPI('Ca destinație',data?.destination_matches,'destination')}${fortigateVMFilterKPI('VIP / DNAT',data?.vip_matches,'vip')}${fortigateVMFilterKPI('Cu indicatori',data?.high_risk,'risk')}</div>`;
 const review=can('vms.manage')?`<button type="button" class="small secondary security-review-bulk" data-scope="firewall" data-vm="${vmID}" data-label="Reguli FortiGate ale VM" data-count="${Number(data?.total||0)}">Revizuiește secțiunea</button>`:'';
 const fortiActions=`<a id="vmFortigateExport" class="button-link small secondary" href="${fortigateExportURL({vm_id:vmID},false)}">Export Excel</a>${review}`;
 const localActions=`<a class="button-link small secondary" href="/api/v1/security/firewall/local/export?vm_id=${Number(vmID)}">Export Excel</a>${can('vms.manage')?`<button type="button" id="vmFirewallLocalBulk" class="small secondary security-review-bulk" data-vm="${Number(vmID)}" data-scope="firewall_local" data-label="Reguli locale ale VM" data-count="0" disabled>Revizuiește secțiunea</button>`:''}`;
 const forti=`<section class="firewall-vm-mode" data-firewall-vm-mode="forti" ${mode==='forti'?'':'hidden'}>${panel('Reguli FortiGate pentru VM',`${firewallReviewedBar(data?.items||[])}${fortigateRulesTable(data,false,'vm-fortigate-table')}`,fortiActions,'fortigate-wide-panel')}<div class="muted" id="vmFortigateVisibleCount"></div></section>`;
 const local=`<section class="firewall-vm-mode" data-firewall-vm-mode="local" ${mode==='local'?'':'hidden'}>${panel('Firewall local al VM-ului','<div id="vmFirewallLocalContent" class="muted">Regulile se încarcă la deschiderea acestui mod.</div>',localActions,'firewall-local-panel')}</section>`;
 return `<div class="firewall-workspace">${firewallOverviewRow(mode,cards)}${forti}${local}</div>`;
}
function registerResourceEditor(vmID,section,view,services,categories){
 vmResourceContexts.set(`${Number(vmID)}:${section}`,{vmID:Number(vmID),section,view,services,categories});
}
function resolveResourceContext(section){
 const hash=(location.hash||'').slice(1).split('/'),vmID=Number(hash[1]);
 return vmResourceContexts.get(`${vmID}:${section}`);
}
function resourceSectionForKind(kind){return kind==='docker'?'docker':kind==='web'?'web':'databases'}
function resourceContextItem(ctx,kind,id){
 if(kind==='docker')return (ctx.view?.containers||[]).find(x=>Number(x.id)===id);
 if(kind==='web')return (ctx.view?.sites||[]).find(x=>Number(x.id)===id);
 if(kind==='instance')return (ctx.view?.instances||[]).find(x=>Number(x.id)===id);
 return (ctx.view?.instances||[]).flatMap(x=>x.catalogs||[]).find(x=>Number(x.id)===id);
}
function resourceDocumentationEndpoint(ctx,kind,id){
 const prefix=`/api/v1/vms/${ctx.vmID}`;
 if(kind==='docker')return `${prefix}/docker/containers/${id}/documentation-exempt`;
 if(kind==='web')return `${prefix}/web/sites/${id}/documentation-exempt`;
 if(kind==='instance')return `${prefix}/databases/instances/${id}/documentation-exempt`;
 return `${prefix}/databases/catalogs/${id}/documentation-exempt`;
}
function resourceServicesEndpoint(ctx,kind,id){
 const prefix=`/api/v1/vms/${ctx.vmID}`;
 if(kind==='docker')return `${prefix}/docker/containers/${id}/services`;
 if(kind==='web')return `${prefix}/web/sites/${id}/services`;
 if(kind==='instance')return `${prefix}/databases/instances/${id}/services`;
 return `${prefix}/databases/catalogs/${id}/services`;
}
function resourceMutableAssignments(kind,item){
 const values=item?.service_assignments||[];
 return values.filter(x=>kind!=='docker'||x.source==='manual').map(a=>({service_id:Number(a.service_id),environment_id:a.environment_id?Number(a.environment_id):null,operational_status_id:a.operational_status_id?Number(a.operational_status_id):null,solution_type_id:a.solution_type_id?Number(a.solution_type_id):null,component_name:a.component_name||'',role_name:a.role_name||'',notes:a.notes||''}));
}
function resourceModalSelect(items,placeholder){return `<option value="">${e(placeholder)}</option>${(items||[]).filter(x=>x.active!==false).map(x=>`<option value="${Number(x.id)}">${e(x.name)}</option>`).join('')}`}
function refreshResourceSummaryCell(kind,id,item){
 const root=document.querySelector(`[data-resource-summary="${kind}:${id}"]`);
 if(!root)return;
 root.querySelector('.resource-summary-service').innerHTML=resourceAssignmentSummary(item.service_assignments||[],!!item.documentation_exempt);
 const row=root.closest('tr');if(!row)return;
 const values=resourceFilterAssignments(item),complete=values.length>0&&values.every(x=>x.service&&x.environment&&x.status&&x.solution);
 row.dataset.resourceAssignments=JSON.stringify(values);row.dataset.resourceComplete=complete?'1':'0';row.dataset.documentationExempt=item.documentation_exempt?'1':'0';
 const area=row.closest('.vm-detail-workspace');area?.querySelector('.resource-inventory-filterbar select')?.dispatchEvent(new Event('change'));
}
function replaceResourceContextView(ctx,result){
 if(result&&typeof result==='object'&&(result.containers||result.instances||result.sites))ctx.view=result;
}
async function paintResourceBeneficiaries(vmID,types){
 const pending=types.map(async type=>{
  const rootSelector=`[data-resource-beneficiaries^="${type}:"]`;
  // Database instances use the same catalog beneficiary response as logical databases.
  const instanceSelector=type==='database'?'[data-resource-beneficiaries^="instance:"]':null;
  if(!document.querySelector(rootSelector)&&!(instanceSelector&&document.querySelector(instanceSelector)))return;
  const vmIsCurrent=()=>Number((location.hash||'').match(/^#vms\/(\d+)/)?.[1])===Number(vmID);
  const nodes=()=>[...document.querySelectorAll(rootSelector),...(instanceSelector?[...document.querySelectorAll(instanceSelector)]:[])];
  try{
   const rows=await cachedVMRead(`/api/v1/vms/${Number(vmID)}/beneficiaries/resources?type=${type}`,10000);
   if(!vmIsCurrent())return;
   const grouped=new Map();
   for(const item of Array.isArray(rows)?rows:[]){const key=`${type}:${Number(item.resource_id)}`;if(!grouped.has(key))grouped.set(key,new Map());grouped.get(key).set(`${item.beneficiary_type}:${item.beneficiary_id}`,item)}
   for(const node of nodes()){
    let values;
    if(node.dataset.resourceBeneficiaries.startsWith('instance:')){
     const ids=(node.dataset.instanceCatalogIds||'').split(',').map(Number).filter(id=>Number.isSafeInteger(id)&&id>0);
     const dedup=new Map();
     for(const id of ids)for(const item of grouped.get(`database:${id}`)?.values()||[])dedup.set(`${item.beneficiary_type}:${item.beneficiary_id}`,item);
     values=[...dedup.values()];
    }else values=[...(grouped.get(node.dataset.resourceBeneficiaries)?.values()||[])];
    node.innerHTML=values.length?`<div class="resource-beneficiary-chips"><span class="muted">Beneficiari</span>${values.map(x=>`<span class="resource-beneficiary-chip" title="${e(x.direct?'Asociere directă':`Calculată din ${x.via_name||x.relation||''}`)}">${e(x.beneficiary_name)}</span>`).join('')}</div>`:'<span class="muted">Beneficiari: —</span>';
   }
  }catch(err){if(vmIsCurrent())for(const node of nodes())node.textContent=`Beneficiari: ${err.message}`}
 });
 await Promise.all(pending);
}
async function openResourceConfiguration(kind,rawID){
 const id=Number(rawID),section=resourceSectionForKind(kind),ctx=resolveResourceContext(section);
 if(!ctx||!id)return;
 const item=resourceContextItem(ctx,kind,id);if(!item){toast('Resursa nu mai există în inventarul curent.',true);return}
 const canEdit=can('vms.manage'),canBenefitEdit=can('nomenclatures.manage'),hasBeneficiaries=kind!=='instance';
 const name=item.name||item.instance_name||item.product||`${kind} #${id}`;
 const modal=beneficiaryDialog(`Configurare · ${name}`,'<p class="muted">Se încarcă beneficiarii…</p>');
 let departments=[],people=[],effective=[];
 const beneficiaryType=kind==='instance'?'':kind;
 if(hasBeneficiaries){try{
  [departments,people,effective]=await Promise.all([
   cachedVMRead('/api/v1/beneficiaries?type=department',12000),cachedVMRead('/api/v1/beneficiaries?type=person',12000),
   api(`/api/v1/beneficiaries/assignments?resource_type=${beneficiaryType}&resource_id=${id}&effective=true`)
  ]);
 }catch(err){if(modal.open)modal.querySelector('.beneficiary-modal-body').textContent=err.message;return}}
 const modalCurrent=()=>modal.open&&modal.isConnected;
 const draw=()=>{
  if(!modalCurrent())return;
  const current=resourceContextItem(ctx,kind,id)||item;
  const assignmentRows=(current.service_assignments||[]).map(a=>{
   const removable=kind!=='docker'||a.source==='manual';
   return `<tr><td><strong>${e(a.service_name)}</strong>${kind==='docker'&&a.source==='label'?'<div class="muted">Din label Docker, nu se poate șterge aici.</div>':''}</td><td>${e([a.environment,a.operational_status,a.solution_type].filter(Boolean).join(' · ')||'—')}</td><td>${removable&&canEdit?`<button type="button" class="small secondary resource-modal-remove-service" data-id="${Number(a.service_id)}">Elimină</button>`:''}</td></tr>`;
  }).join('');
  const beneficiaryRows=(effective||[]).map(b=>`<tr><td>${e(b.beneficiary_name)} <span class="muted">${b.beneficiary_type==='department'?'OU':'Persoană'}</span></td><td>${b.direct?'Direct':`Calculat · ${e(b.via_name||b.relation||'')}`}</td><td>${b.direct&&canBenefitEdit?`<button type="button" class="small secondary resource-modal-remove-beneficiary" data-id="${Number(b.assignment_id)}">Elimină</button>`:''}</td></tr>`).join('');
  const serviceOptions=resourceModalSelect(ctx.services,'Alege serviciul');
  // Preserve existing nomenclature select semantics, including inactive filtering.
  const nomenclatureField=(kindName,idName,label)=>`<label>${label}${resourceContextSelect(ctx.categories,kindName,idName,label)}</label>`;
  const possible=kind==='instance'?'Instanțele au beneficiarii documentați pe bazele logice asociate.':'Beneficiarii aleși rămân vizibili în tabel și în raport.';
  modal.querySelector('.beneficiary-modal-body').innerHTML=`<div class="resource-config-dialog">
   <section class="resource-config-section"><div class="resource-config-heading"><h3>Documentare</h3><span class="muted">${e(resourceDocumentationExportLabelJS(current))}</span></div><label class="resource-config-toggle"><input type="checkbox" id="resourceModalExempt" ${current.documentation_exempt?'checked':''} ${!canEdit?'disabled':''}> Nu necesită documentare</label></section>
   <section class="resource-config-section"><h3>Servicii interne</h3><div class="table-wrap"><table><thead><tr><th>Serviciu</th><th>Mediu / Status / Tip soluție</th><th></th></tr></thead><tbody>${assignmentRows||'<tr><td colspan="3" class="muted">Nedocumentat</td></tr>'}</tbody></table></div>
   ${canEdit?`<form id="resourceModalServiceForm" class="resource-modal-service-form"><label>Serviciu<select name="service_id" required>${serviceOptions}</select></label>${nomenclatureField('environment','resourceModalEnvironment','Mediu')}${nomenclatureField('operational_status','resourceModalStatus','Status operațional')}${nomenclatureField('solution_type','resourceModalSolution','Tip soluție')}<div><button type="submit" class="small">Adaugă / actualizează</button></div></form>`:''}</section>
   <section class="resource-config-section"><h3>Beneficiari</h3><p class="muted">${e(possible)}</p>${hasBeneficiaries?`<div class="table-wrap"><table><thead><tr><th>Beneficiar</th><th>Asociere</th><th></th></tr></thead><tbody>${beneficiaryRows||'<tr><td colspan="3" class="muted">Niciun beneficiar asociat.</td></tr>'}</tbody></table></div>${canBenefitEdit?`<form id="resourceModalBeneficiaryForm" class="resource-modal-beneficiary-form"><label>Tip<select name="type"><option value="department">Departament</option><option value="person">Persoană</option></select></label><label>Beneficiar<select name="id">${resourceModalSelect(departments,'Selectează beneficiarul')}</select></label><div><button type="submit" class="small">Asociază</button></div></form>`:''}`:''}</section>
  </div>`;
  const exempt=modal.querySelector('#resourceModalExempt');if(exempt)exempt.onchange=async()=>{exempt.disabled=true;try{await api(resourceDocumentationEndpoint(ctx,kind,id),{method:'PUT',body:JSON.stringify({exempt:exempt.checked})});current.documentation_exempt=exempt.checked;refreshResourceSummaryCell(kind,id,current);draw();refreshVMCompletion(ctx.vmID)}catch(err){exempt.checked=!exempt.checked;exempt.disabled=false;toast(err.message,true)}};
  const form=modal.querySelector('#resourceModalServiceForm');if(form)form.onsubmit=async event=>{
   event.preventDefault();const data=event.currentTarget.elements,serviceID=Number(data.service_id.value),environmentID=Number(document.getElementById('resourceModalEnvironment')?.value||0),statusID=Number(document.getElementById('resourceModalStatus')?.value||0),solutionID=Number(document.getElementById('resourceModalSolution')?.value||0);
   if(!serviceID||!environmentID||!statusID||!solutionID){toast('Completează serviciul, mediul, statusul și tipul soluției.',true);return}
   const values=resourceMutableAssignments(kind,current),existing=values.find(x=>x.service_id===serviceID),next={service_id:serviceID,environment_id:environmentID,operational_status_id:statusID,solution_type_id:solutionID};
   if(existing)Object.assign(existing,next);else values.push(next);
   try{const result=await api(resourceServicesEndpoint(ctx,kind,id),{method:'PUT',body:JSON.stringify({assignments:values})});replaceResourceContextView(ctx,result);const fresh=resourceContextItem(ctx,kind,id)||current;refreshResourceSummaryCell(kind,id,fresh);draw();refreshVMCompletion(ctx.vmID);toast('Asociere actualizată.')}catch(err){toast(err.message,true)}
  };
  modal.querySelectorAll('.resource-modal-remove-service').forEach(button=>button.onclick=async()=>{
   const values=resourceMutableAssignments(kind,current).filter(x=>x.service_id!==Number(button.dataset.id));
   try{const result=await api(resourceServicesEndpoint(ctx,kind,id),{method:'PUT',body:JSON.stringify({assignments:values})});replaceResourceContextView(ctx,result);refreshResourceSummaryCell(kind,id,resourceContextItem(ctx,kind,id)||current);draw();refreshVMCompletion(ctx.vmID)}catch(err){toast(err.message,true)}
  });
  const beneficiaryForm=modal.querySelector('#resourceModalBeneficiaryForm');if(beneficiaryForm){
   const type=beneficiaryForm.elements.type,beneficiary=beneficiaryForm.elements.id;
   type.onchange=()=>{beneficiary.innerHTML=resourceModalSelect(type.value==='person'?people:departments,'Selectează beneficiarul')};
   beneficiaryForm.onsubmit=async event=>{event.preventDefault();const beneficiaryID=Number(beneficiary.value);if(!beneficiaryID){toast('Selectează un beneficiar.',true);return}
    try{await api('/api/v1/beneficiaries/assignments',{method:'POST',body:JSON.stringify({resource_type:beneficiaryType,resource_id:id,beneficiary_type:type.value,beneficiary_id:beneficiaryID})});await refreshBenefits();toast('Beneficiar asociat.')}catch(err){toast(err.message,true)}
   };
  }
  modal.querySelectorAll('.resource-modal-remove-beneficiary').forEach(button=>button.onclick=async()=>{
   try{await api(`/api/v1/beneficiaries/assignments/${Number(button.dataset.id)}`,{method:'DELETE'});await refreshBenefits()}catch(err){toast(err.message,true)}
  });
 };
 async function refreshBenefits(){
  effective=await api(`/api/v1/beneficiaries/assignments?resource_type=${beneficiaryType}&resource_id=${id}&effective=true`);
  draw();await paintResourceBeneficiaries(ctx.vmID,[beneficiaryType]);
 }
 draw();
}
function resourceDocumentationExportLabelJS(item){return item.documentation_exempt?'Nu necesită documentare':(item.service_assignments||[]).length?'Documentat':'Nedocumentat'}
document.addEventListener('click',event=>{
 const button=event.target.closest('.resource-open-editor');if(!button)return;
 event.preventDefault();openResourceConfiguration(button.dataset.kind,button.dataset.id).catch(err=>toast(err.message,true));
});
// --- end 0.21.3 resource editor ---

// 0.21.0 · Beneficiari — reutilizează API-ul și permisiunile aplicației.
const beneficiaryTypeLabels={department:'Departament',person:'Persoană'};
const beneficiaryResourceLabels={vm:'VM',docker:'Docker',database:'Bază de date',web:'Web',service:'Serviciu',support_component:'Componentă suport',software_component:'Componentă software'};
function resourceBeneficiariesButton(type,id){return Number(id)>0?`<button type="button" class="small secondary edit-resource-beneficiaries" data-type="${e(type)}" data-id="${Number(id)}">Beneficiari</button>`:''}
function resourceBeneficiariesCard(type,id){return `<section class="panel" id="beneficiary-card-${e(type)}-${Number(id)}"><div class="panel-header"><h3>Beneficiari · departamente și persoane</h3>${resourceBeneficiariesButton(type,id)}</div><div class="beneficiary-resource-items muted">Se încarcă beneficiarii…</div></section>`}
function vmResponsibilityBeneficiaries(vmID){return `<div class="vm-responsibility-beneficiaries" id="beneficiary-card-vm-${Number(vmID)}"><div class="vm-responsibility-beneficiaries-heading"><div><h4>Beneficiari</h4><p class="muted">Departamente și persoane care folosesc resursele acestui VM; separate de rolurile de administrare.</p></div>${resourceBeneficiariesButton('vm',vmID)}</div><div class="beneficiary-resource-items muted">Se încarcă beneficiarii…</div></div>`}
async function loadBeneficiaryResourceCard(type,id){
 const node=document.getElementById(`beneficiary-card-${type}-${id}`);if(!node)return;
 try{
  const values=await api(`/api/v1/beneficiaries/assignments?resource_type=${encodeURIComponent(type)}&resource_id=${Number(id)}&effective=true`);
  if(!document.getElementById(`beneficiary-card-${type}-${id}`))return;
  const seen=new Set(),display=[];for(const v of values||[]){const key=`${v.beneficiary_type}:${v.beneficiary_id}`;if(seen.has(key))continue;seen.add(key);display.push(type==='vm'?`<span class="badge vm-beneficiary-badge"><strong class="vm-beneficiary-name">${e(v.beneficiary_name)}</strong><small class="vm-beneficiary-source">${e(String(v.source).toUpperCase())}</small></span>`:`<span class="badge">${e(v.beneficiary_name)} · ${e(String(v.source).toUpperCase())}</span>`)}
  node.querySelector('.beneficiary-resource-items').innerHTML=display.length?display.join(' '):'<span class="muted">Nu există beneficiari asociați sau calculați.</span>';
 }catch(err){node.querySelector('.beneficiary-resource-items').textContent=err.message}
}
function beneficiaryDialog(title,html){
 document.getElementById('beneficiaryModal')?.remove();const modal=document.createElement('dialog');modal.id='beneficiaryModal';modal.className='beneficiary-modal';
 modal.innerHTML=`<div class="beneficiary-modal-head"><strong>${e(title)}</strong><button type="button" class="small secondary" id="closeBeneficiaryModal">Închide</button></div><div class="beneficiary-modal-body">${html}</div>`;
 document.body.appendChild(modal);modal.querySelector('#closeBeneficiaryModal').onclick=()=>modal.close();modal.addEventListener('close',()=>modal.remove(),{once:true});modal.showModal();return modal;
}
async function openBeneficiaryResource(type,id){
 id=Number(id);if(!beneficiaryResourceLabels[type]||!Number.isSafeInteger(id)||id<=0)return;
 const modal=beneficiaryDialog(`Beneficiari · ${beneficiaryResourceLabels[type]} #${id}`,'<p>Se încarcă…</p>');
 async function draw(){
  const [direct,effective,departments,people]=await Promise.all([
   api(`/api/v1/beneficiaries/assignments?resource_type=${type}&resource_id=${id}`),
   api(`/api/v1/beneficiaries/assignments?resource_type=${type}&resource_id=${id}&effective=true`),
   api('/api/v1/beneficiaries?type=department'),api('/api/v1/beneficiaries?type=person')]);
  if(!modal.open)return;
  const directIDs=new Set((direct||[]).map(v=>`${v.beneficiary_type}:${v.beneficiary_id}`));
  const table=(effective||[]).map(v=>`<tr><td>${e(v.beneficiary_name)} <small class="muted">${e(v.beneficiary_type==='department'?'OU':'Persoană')}</small></td><td>${e(String(v.source).toUpperCase())}</td><td>${v.direct?'Directă':`Calculată · ${e(v.via_name||v.relation)}`}</td><td>${v.direct&&can('nomenclatures.manage')?`<button class="small danger beneficiary-remove" data-id="${Number(v.assignment_id)}">Elimină</button>`:''}</td></tr>`).join('');
  const options=(items)=>items.filter(x=>x.active).map(x=>`<option value="${Number(x.id)}">${e(x.name)} · ${e(String(x.source).toUpperCase())}</option>`).join('');
  modal.querySelector('.beneficiary-modal-body').innerHTML=`<p class="muted">Asocierile directe sunt editabile; beneficiarii calculați sunt afișați cu proveniența lor.</p>${can('nomenclatures.manage')?`<form id="beneficiaryAddResource" class="beneficiary-resource-form"><label>Tip beneficiar<select name="beneficiary_type"><option value="department">Departament</option><option value="person">Persoană</option></select></label><label>Beneficiar<select name="beneficiary_id">${options(departments)}</select></label><button type="submit" class="small">Asociază</button></form>`:''}<div class="table-wrap"><table><thead><tr><th>Beneficiar</th><th>Sursă</th><th>Tip asociere</th><th></th></tr></thead><tbody>${table||'<tr><td colspan="4">Nu există beneficiari.</td></tr>'}</tbody></table></div>`;
  const form=modal.querySelector('#beneficiaryAddResource');if(form){const typ=form.elements.beneficiary_type,person=form.elements.beneficiary_id;typ.onchange=()=>{person.innerHTML=options(typ.value==='person'?people:departments)};
   form.onsubmit=async ev=>{ev.preventDefault();try{await api('/api/v1/beneficiaries/assignments',{method:'POST',body:JSON.stringify({resource_type:type,resource_id:id,beneficiary_type:typ.value,beneficiary_id:Number(person.value)})});toast('Beneficiar asociat.');await draw();await loadBeneficiaryResourceCard(type,id);if(type==='vm')refreshVMCompletion(id,0)}catch(err){toast(err.message,true)}};
  }
  modal.querySelectorAll('.beneficiary-remove').forEach(b=>b.onclick=async()=>{try{await api(`/api/v1/beneficiaries/assignments/${Number(b.dataset.id)}`,{method:'DELETE'});await draw();await loadBeneficiaryResourceCard(type,id);if(type==='vm')refreshVMCompletion(id,0)}catch(err){toast(err.message,true)}});
 }
 try{await draw()}catch(err){if(modal.open)modal.querySelector('.beneficiary-modal-body').textContent=err.message}
}
document.addEventListener('click',event=>{const button=event.target.closest('.edit-resource-beneficiaries');if(button){event.preventDefault();openBeneficiaryResource(button.dataset.type,button.dataset.id)}});


// 0.21.8 — centralized, reversible DB engine visibility policy.
// These toggles affect normalized inventory projections, reports and documents;
// collected raw snapshots and historical assignments are never deleted.
async function databaseEngineVisibilityPage(){
 pageMeta('Nomenclatoare','Motoare DB ignorate · vizibilitate în inventar și documentație');
 const [categories,people,departments,engines]=await Promise.all([
  api('/api/v1/nomenclatures?include_inactive=true'),
  api('/api/v1/people?include_inactive=true'),
  api('/api/v1/beneficiaries?type=department&include_inactive=true').catch(()=>[]),
  api('/api/v1/database-engines/visibility')
 ]);
 nomenclatureCache=categories;peopleCache=people;
 beneficiaryDepartmentCount=departments.length;
 const allowed=can('nomenclatures.manage');
 const rows=(engines||[]).map(v=>`<tr><td><strong>${e(v.name||v.key)}</strong><div class="muted mono">${e(v.key)}</div></td><td>${Number(v.engine_count||0)}</td><td>${Number(v.instance_count||0)}</td><td>${v.ignored?badge('disabled'):badge('active')}</td><td><label class="db-engine-toggle"><input type="checkbox" class="db-engine-ignored" data-key="${e(v.key)}" ${v.ignored?'checked':''} ${allowed?'':'disabled'}><span>Ignoră</span></label></td></tr>`).join('');
 content.innerHTML=`<div class="nomenclature-layout">${nomenclatureNavigation('database_engine_visibility')}<main class="nomenclature-workspace"><section class="panel"><div class="panel-header"><div><h2>Motoare DB ignorate</h2><p class="muted">Motoarele bifate sunt ascunse din inventarul normalizat, rapoarte, documentație și calculul completitudinii. Datele colectate rămân stocate.</p></div></div><div class="notice"><strong>IBM Db2 este ignorat implicit.</strong> Poți dezactiva regula oricând; nu trebuie reinstalat agentul sau relansată colectarea.</div><div class="table-wrap"><table><thead><tr><th>Motor DB</th><th>Instalări</th><th>Instanțe</th><th>Vizibilitate</th><th>Excludere</th></tr></thead><tbody>${rows||'<tr><td colspan="5">Nu există motoare detectate.</td></tr>'}</tbody></table></div></section></main></div>`;
 content.querySelectorAll('.db-engine-ignored').forEach(input=>input.addEventListener('change',async()=>{
  const ignored=input.checked;input.disabled=true;
  try{
   await api(`/api/v1/database-engines/visibility/${encodeURIComponent(input.dataset.key)}`,{method:'PUT',body:JSON.stringify({ignored})});
   toast(ignored?'Motorul a fost exclus din inventarul vizibil.':'Motorul este din nou vizibil.');
   await databaseEngineVisibilityPage();
  }catch(err){input.checked=!ignored;toast(err.message,true)}finally{input.disabled=!allowed}
 }));
}
async function beneficiaryCatalogPage(){
 pageMeta('Nomenclatoare','Beneficiari · departamente Active Directory și persoane unificate');
 const [departments,people,ous,categories]=await Promise.all([
  api('/api/v1/beneficiaries?type=department&include_inactive=true'),
  api('/api/v1/people?include_inactive=true'),
  api('/api/v1/beneficiaries/ad/ous').catch(err=>({error:err.message,ous:[],selected_dns:[]})),
  api('/api/v1/nomenclatures?include_inactive=true')
 ]);
 // Keep the normal nomenclature navigation populated on direct links too.
 nomenclatureCache=categories;peopleCache=people;beneficiaryDepartmentCount=departments.length;
 // In-memory changes survive tab switches/rerenders. Saved OU selection survives reloads.
 if(!state.beneficiarySelectionDirty)state.beneficiarySelectedDNs=[...(ous.selected_dns||[])];
 const selectedDNs=new Set(state.beneficiarySelectedDNs||[]);
 const query=String(state.beneficiarySearch||'').trim().toLocaleLowerCase('ro-RO');
 const filtered=departments.filter(v=>[v.name,v.dn,v.source].join(' ').toLocaleLowerCase('ro-RO').includes(query));
 const departmentRows=filtered.map(v=>`<tr><td><strong>${e(v.name)}</strong><small>${e(v.dn||'Înregistrare manuală')}</small></td><td>${v.source==='ad'?badge('AD'):badge('manual')}</td><td>${v.active?badge('active'):badge('disabled')}</td><td>${e(departments.find(d=>Number(d.id)===Number(v.parent_id))?.name||'—')}</td><td>${v.source==='manual'&&can('nomenclatures.manage')?`<button type="button" class="small secondary beneficiary-edit" data-id="${Number(v.id)}">Editează</button>`:''}</td></tr>`).join('');
 const units=(ous.ous||[]).map(unit=>({name:unit.name,dn:unit.dn,parent:unit.dn?.split(/,(.+)/)[1]||''}));
 const rootRows=units.map((unit,index)=>`<tr class="beneficiary-ou-row" data-search="${e((unit.name+' '+unit.dn).toLocaleLowerCase('ro-RO'))}"><td class="beneficiary-check-cell"><input type="checkbox" class="beneficiary-root" aria-label="Selectează ${e(unit.name)}" value="${e(unit.dn)}" ${selectedDNs.has(unit.dn)?'checked':''}></td><td><strong>${e(unit.name)}</strong></td><td class="beneficiary-ou-path">${e(unit.parent)}</td><td class="beneficiary-ou-index">${index+1}</td></tr>`).join('');
 const syncMarkup=can('nomenclatures.manage')?`<section class="panel beneficiary-section"><div class="beneficiary-panel-heading"><div><h3>Sincronizare Active Directory</h3><p>OU-urile sunt afișate tabelar, fără ierarhie vizuală artificială. Se importă numai ramurile bifate.</p></div><span class="badge">${units.length} OU-uri</span></div><div class="beneficiary-sync-meta"><span class="muted">Base DN</span><code>${e(ous.base_dn||'—')}</code></div>${ous.error?`<p class="warning-text beneficiary-note">${e(ous.error)}</p>`:`<div class="beneficiary-ou-toolbar"><label class="beneficiary-ou-search-field">Caută OU<input type="search" id="beneficiaryOUSearch" placeholder="Nume OU sau DN" value="${e(state.beneficiaryOUSearch||'')}"></label><div class="beneficiary-ou-commands"><button type="button" id="beneficiarySelectVisible" class="small secondary">Bifează cele afișate</button><button type="button" id="beneficiaryClearVisible" class="small secondary">Debifează cele afișate</button></div></div><div class="beneficiary-ou-table-wrap"><table class="beneficiary-ou-table"><thead><tr><th class="beneficiary-check-cell">Selectat</th><th>Unitate organizațională</th><th>DN părinte / cale</th><th>#</th></tr></thead><tbody>${rootRows||'<tr><td colspan="4">Nu există OU-uri în Base DN.</td></tr>'}</tbody></table></div><div class="beneficiary-sync-footer"><div class="beneficiary-sync-summary"><strong id="beneficiaryOUCount">${selectedDNs.size} OU-uri selectate</strong><label class="beneficiary-inline-check"><input id="beneficiarySyncPeople" type="checkbox" ${state.beneficiarySyncPeople!==false?'checked':''}> Importă și persoanele din aceste OU-uri</label></div><div class="beneficiary-sync-actions"><button type="button" id="beneficiarySaveRoots" class="secondary">Salvează selecția</button><button type="button" id="beneficiarySyncRun">Sincronizează AD</button></div></div>`}</section>`:'';
 content.innerHTML=`<div class="nomenclature-layout beneficiary-workspace">${nomenclatureNavigation('beneficiaries')}<main class="nomenclature-workspace"><section class="panel beneficiary-section"><div class="beneficiary-panel-heading"><div><h2>Beneficiari</h2><p>Departamente din OU-urile Active Directory sau introduse manual. Persoanele folosesc nomenclatorul comun cu responsabilii VM.</p></div><a class="button-link small secondary" href="#reports/beneficiaries">Raport beneficiari</a></div><div class="beneficiary-type-links"><span class="beneficiary-tab-active">Departamente (${departments.length})</span><a href="#nomenclatures/people" class="beneficiary-tab-link">Persoane (${people.length}) · registru comun</a>${can('nomenclatures.manage')?'<button type="button" id="beneficiaryManualAdd" class="small secondary">+ Departament manual</button>':''}</div><div class="beneficiary-list-filter"><input id="beneficiaryCatalogSearch" type="search" placeholder="Caută nume, DN sau sursă" value="${e(state.beneficiarySearch||'')}"></div><div class="table-wrap beneficiary-department-table"><table><thead><tr><th>Departament</th><th>Sursă</th><th>Stare</th><th>OU părinte</th><th>Acțiuni</th></tr></thead><tbody>${departmentRows||'<tr><td colspan="5">Niciun departament pentru filtrul curent.</td></tr>'}</tbody></table></div></section>${syncMarkup}</main></div>`;
 const searchInput=document.getElementById('beneficiaryCatalogSearch');let timer;
 searchInput?.addEventListener('input',ev=>{state.beneficiarySearch=ev.target.value;clearTimeout(timer);timer=setTimeout(()=>beneficiaryCatalogPage(),300)});
 function edit(item){
  const modal=beneficiaryDialog(item?'Editează departamentul':'Adaugă departament manual',`<form id="beneficiaryManualForm" class="beneficiary-edit-form"><label>Nume departament<input name="name" maxlength="255" required value="${e(item?.name||'')}" placeholder="Ex.: Direcția IT"></label>${item?`<label class="beneficiary-inline-check"><input type="checkbox" name="active" ${item.active?'checked':''}> Activ</label>`:''}<div class="beneficiary-modal-actions"><button type="button" class="secondary beneficiary-cancel">Anulează</button><button type="submit">Salvează</button></div></form>`);
  modal.querySelector('.beneficiary-cancel').onclick=()=>modal.close();
  modal.querySelector('form').onsubmit=async ev=>{ev.preventDefault();const form=ev.currentTarget;const input={type:'department',name:form.elements.name.value};if(item)input.active=!!form.elements.active.checked;
   try{await api(item?`/api/v1/beneficiaries/${item.id}?type=department`:'/api/v1/beneficiaries',{method:item?'PUT':'POST',body:JSON.stringify(input)});modal.close();toast('Departament salvat.');beneficiaryCatalogPage()}catch(err){toast(err.message,true)}};
 }
 document.getElementById('beneficiaryManualAdd')?.addEventListener('click',()=>edit(null));
 content.querySelectorAll('.beneficiary-edit').forEach(b=>b.onclick=()=>edit(departments.find(x=>Number(x.id)===Number(b.dataset.id))));
 const ouSearch=document.getElementById('beneficiaryOUSearch');
 const allRows=[...content.querySelectorAll('.beneficiary-ou-row')];
 const rootCheckboxes=[...content.querySelectorAll('.beneficiary-root')];
 const updateCount=()=>{const target=document.getElementById('beneficiaryOUCount');if(target)target.textContent=`${rootCheckboxes.filter(x=>x.checked).length} OU-uri selectate${state.beneficiarySelectionDirty?' · modificări nesalvate':''}`};
 const filterOU=()=>{const q=String(ouSearch?.value||'').trim().toLocaleLowerCase('ro-RO');allRows.forEach(row=>{row.hidden=!!q&&!row.dataset.search.includes(q)})};
 ouSearch?.addEventListener('input',ev=>{state.beneficiaryOUSearch=ev.target.value;filterOU()});filterOU();
 // Persist debounced checkbox changes; a separate button allows immediate explicit save.
 let rootsAutosaveTimer;
 const persistRoots=async()=>{
  const roots=[...(state.beneficiarySelectedDNs||[])];
  try{await api('/api/v1/beneficiaries/ad/roots',{method:'PUT',body:JSON.stringify({root_dns:roots})});
   if(JSON.stringify(roots)===JSON.stringify(state.beneficiarySelectedDNs||[])){state.beneficiarySelectionDirty=false;updateCount()}
  }catch(err){toast(`Selecția OU nu a putut fi salvată: ${err.message}`,true)}
 };
 const recordSelection=()=>{state.beneficiarySelectedDNs=rootCheckboxes.filter(x=>x.checked).map(x=>x.value);state.beneficiarySelectionDirty=true;updateCount();clearTimeout(rootsAutosaveTimer);rootsAutosaveTimer=setTimeout(persistRoots,900)};
 rootCheckboxes.forEach(x=>x.addEventListener('change',recordSelection));
 document.getElementById('beneficiarySelectVisible')?.addEventListener('click',()=>{rootCheckboxes.forEach(x=>{if(!x.closest('tr').hidden)x.checked=true});recordSelection()});
 document.getElementById('beneficiaryClearVisible')?.addEventListener('click',()=>{rootCheckboxes.forEach(x=>{if(!x.closest('tr').hidden)x.checked=false});recordSelection()});
 document.getElementById('beneficiarySyncPeople')?.addEventListener('change',ev=>{state.beneficiarySyncPeople=ev.target.checked});
 document.getElementById('beneficiarySaveRoots')?.addEventListener('click',async ev=>{const btn=ev.currentTarget;clearTimeout(rootsAutosaveTimer);btn.disabled=true;try{await api('/api/v1/beneficiaries/ad/roots',{method:'PUT',body:JSON.stringify({root_dns:state.beneficiarySelectedDNs||[]})});state.beneficiarySelectionDirty=false;updateCount();toast('Selecția OU a fost salvată.')}catch(err){toast(err.message,true)}finally{btn.disabled=false}});
 document.getElementById('beneficiarySyncRun')?.addEventListener('click',async ev=>{
  const roots=[...rootCheckboxes.filter(x=>x.checked).map(x=>x.value)];
  if(!roots.length){toast('Selectează cel puțin un OU.',true);return}
  if(!confirm(`Sincronizezi ${roots.length} ramuri OU și subarborele lor din Active Directory?`))return;
  const btn=ev.currentTarget;clearTimeout(rootsAutosaveTimer);btn.disabled=true;
  try{const result=await api('/api/v1/beneficiaries/ad/sync',{method:'POST',body:JSON.stringify({root_dns:roots,include_people:state.beneficiarySyncPeople!==false})});state.beneficiarySelectedDNs=roots;state.beneficiarySelectionDirty=false;toast(`AD: ${result.departments} departamente, ${result.people} persoane.`);await beneficiaryCatalogPage()}catch(err){toast(err.message,true);btn.disabled=false}
 });
}

async function beneficiaryReportPage(){
 pageMeta('Rapoarte','Beneficiari · resurse și componente software');
 const type=state.beneficiaryReportType||'department',id=Number(state.beneficiaryReportID||0),children=state.beneficiaryReportChildren!==false;
 const beneficiaries=await api(`/api/v1/beneficiaries?type=${type}`);
 const selectedID=type==='department'&&id===0?0:(beneficiaries.some(x=>Number(x.id)===id)?id:Number(beneficiaries[0]?.id||0));
 state.beneficiaryReportID=selectedID;
 const params=new URLSearchParams({type,id:String(selectedID),include_children:String(children)});
 const report=(selectedID||type==='department')?await api(`/api/v1/reports/beneficiaries?${params}`):{counts:{},resources:[]};
 const categories=[
  {code:'service',label:'Servicii',hint:'Servicii funcționale'},
  {code:'software_component',label:'Componente software',hint:'Detectate, inclusiv MariaDB'},
  {code:'database',label:'Baze de date',hint:'Baze logice'},
  {code:'web',label:'Web',hint:'Site-uri și vhost-uri'},
  {code:'docker',label:'Docker',hint:'Containere'},
  {code:'vm',label:'VM-uri',hint:'Mașini virtuale'}
 ];
 const links={service:val=>`#services/${val.resource_id}`,vm:val=>`#vms/${val.resource_id}/overview`,software_component:val=>`#vms/${val.vm_id}/databases`,docker:val=>val.vm_id?`#vms/${val.vm_id}/docker`:'',database:val=>val.vm_id?`#vms/${val.vm_id}/databases`:'',web:val=>val.vm_id?`#vms/${val.vm_id}/web`:''};
 const summary=categories.map(c=>`<div class="beneficiary-report-stat"><span class="beneficiary-report-stat-label">${e(c.label)}</span><strong>${Number(report.counts?.[c.code]||0).toLocaleString('ro-RO')}</strong><span class="muted">${e(c.hint)}</span></div>`).join('');
 const tables=categories.map(c=>{
  const values=(report.resources||[]).filter(v=>v.resource_type===c.code),seen=new Set();
  const rows=values.map(v=>{
   const uniqueKey=`${v.resource_id}:${v.component_key||''}:${v.component_version||''}`,first=!seen.has(uniqueKey);seen.add(uniqueKey);
   const href=links[c.code]?.(v),resName=first?(href?`<a href="${e(href)}"><strong>${e(v.name)}</strong></a>`:`<strong>${e(v.name)}</strong>`):'<span class="muted">↳ aceeași resursă</span>';
   const origin=v.direct?'<span class="beneficiary-report-pill direct">Directă</span>':`<span class="beneficiary-report-pill">Calculată</span><span class="beneficiary-report-relation">${e(v.relation||'')}</span>`;
   return `<tr class="${first?'':'beneficiary-report-continuation'}"><td>${resName}${first&&v.vm_id&&c.code==='software_component'?`<small class="muted">VM #${Number(v.vm_id)}</small>`:''}</td><td>${e(v.beneficiary_name)}</td><td><span class="beneficiary-report-source">${e(String(v.source||'').toUpperCase())}</span></td><td>${origin}</td><td>${v.direct?'<span class="muted">—</span>':e(v.via_name||'—')}</td></tr>`;
  }).join('');
  return `<section class="panel beneficiary-report-results"><div class="beneficiary-report-results-head"><div><h3>${e(c.label)}</h3><p>${e(c.hint)} · ${Number(report.counts?.[c.code]||0)} resurse distincte</p></div><span class="beneficiary-report-count">${Number(report.counts?.[c.code]||0)}</span></div><div class="table-wrap beneficiary-report-table"><table><thead><tr><th>Resursă</th><th>Beneficiar</th><th>Sursă</th><th>Tip asociere</th><th>Proveniență</th></tr></thead><tbody>${rows||'<tr><td colspan="5" class="beneficiary-report-empty">Nu există resurse în această categorie.</td></tr>'}</tbody></table></div></section>`;
 }).join('');
 content.innerHTML=`<div class="nomenclature-layout report-layout beneficiary-report-layout">${reportSubmenu('beneficiaries')}<main class="nomenclature-workspace beneficiary-report-workspace"><section class="panel beneficiary-report-intro"><div class="beneficiary-report-title"><div><h2>Raport beneficiari</h2><p>Servicii și resurse utilizate de un departament sau de o persoană. Asocierile directe și cele calculate sunt afișate separat.</p></div><a class="button-link small secondary" href="/api/v1/reports/beneficiaries/export?${params}">Export Excel</a></div><div class="beneficiary-report-filters"><label>Tip beneficiar<select id="beneficiaryReportType"><option value="department" ${type==='department'?'selected':''}>Departament</option><option value="person" ${type==='person'?'selected':''}>Persoană</option></select></label><label class="beneficiary-report-select">Beneficiar<select id="beneficiaryReportSelect">${type==='department'?`<option value="0" ${selectedID===0?'selected':''}>Toate departamentele</option>`:''}${beneficiaries.map(x=>`<option value="${Number(x.id)}" ${Number(x.id)===selectedID?'selected':''}>${e(x.name)} · ${e(String(x.source).toUpperCase())}</option>`).join('')}</select></label><label class="beneficiary-report-children"><input type="checkbox" id="beneficiaryReportChildren" ${children?'checked':''} ${type==='person'||selectedID===0?'disabled':''}> Include OU-uri copil</label><button type="button" id="beneficiaryReportReload" class="small secondary">Reîncarcă</button></div></section><div class="beneficiary-report-overview"><h3>Resurse identificate</h3><div class="beneficiary-report-stats">${summary}</div></div><div class="beneficiary-report-tables">${tables}</div></main></div>`;
 document.getElementById('beneficiaryReportType').onchange=ev=>{state.beneficiaryReportType=ev.target.value;state.beneficiaryReportID=0;beneficiaryReportPage()};
 document.getElementById('beneficiaryReportSelect').onchange=ev=>{state.beneficiaryReportID=Number(ev.target.value);beneficiaryReportPage()};
 document.getElementById('beneficiaryReportChildren').onchange=ev=>{state.beneficiaryReportChildren=ev.target.checked;beneficiaryReportPage()};
 document.getElementById('beneficiaryReportReload').onclick=()=>beneficiaryReportPage();
}

// VM-DOC 0.21.10 — hardening (read-only audit), CIS references are admin-reviewed only.
const hardeningUIState={profileId:0,q:'',page:1,pageSize:25};
function hardeningBeta(){return '<span class="hardening-beta" role="status" aria-label="Hardening BETA, în validare; scor intern, nu certificare CIS" title="În validare · evaluare internă VM-DOC, nu certificare CIS">BETA</span>'}
function hardeningBadge(status){const map={pass:['active','Conform'],fail:['failed','Neconform'],unknown:['missing','Neverificat'],no_profile:['missing','Fără profil'],pending:['missing','De validat'],reviewed:['active','Verificat intern']};const v=map[status]||['','—'];return `<span class="badge ${v[0]}">${v[1]}</span>`}
function hardeningProfileSelect(profiles,chosen){return (profiles||[]).map(p=>`<option value="${p.id}" ${Number(chosen)===Number(p.id)?'selected':''}>${e(p.name)} ${p.enabled?'':'(inactiv)'}</option>`).join('')}
function hardeningRuleRows(catalog,profileID){const q=(hardeningUIState.q||'').toLowerCase();return (catalog.rules||[]).filter(r=>Number(r.profile_id)===Number(profileID)).filter(r=>!q||[r.name,r.code,r.category,r.recommendation_id,r.control_id].join(' ').toLowerCase().includes(q)).map(r=>`<tr><td><strong class="mono">${e(r.code)}</strong><div class="muted">${e(r.category)}</div></td><td>${e(r.name)}<div class="muted">${e(r.check_key)} · Așteptat: ${e(r.expected)}</div></td><td>${r.recommendation_id?`<strong class="mono">${e(r.recommendation_id)}</strong>`:'<span class="muted">De validat</span>'}<div class="muted">Controls ${e(r.control_id||'—')}</div></td><td>${hardeningBadge(r.mapping_status)}<div class="muted">${e(r.mapping_note||'')}</div></td><td>${r.enabled?'Activă':'Inactivă'} · ${e(r.severity)}</td><td>${can('nomenclatures.manage')?`<button class="small secondary hardening-map-edit" data-profile="${r.profile_id}" data-code="${e(r.code)}">Editează</button>`:''}</td></tr>`).join('')}
// 0.21.15 — administrare extensibilă Hardening; acțiunile de mutație cer permisiune și CSRF server-side.
const hardeningAdmin={tab:'profiles'};
const hardeningProfileFields=[['code','Cod profil (unic)','text'],['name','Denumire profil','text'],['scope','Tip profil','select','os:OS,component:Componentă'],['technology','Tehnologie','text'],['os_match','Familie OS','select',':—,ubuntu:Ubuntu,debian:Debian,windows:Windows,linux:Linux generic'],['version_prefix','Versiune OS / prefix','text'],['level','Nivel / rol','text'],['benchmark','Benchmark de referință','text'],['benchmark_version','Versiune benchmark','text'],['benchmark_url','URL oficial HTTPS','text']];
const hardeningRuleFields=[['code','Cod regulă (unic)','text'],['name','Denumire regulă','text'],['category','Categorie','text'],['check_key','Cheie dovadă agent','text'],['operator','Operator','select','eq:Egal,ne:Diferit,in:În listă,not_in:Nu este în listă,gte:Mai mare sau egal,lte:Mai mic sau egal,gt:Mai mare,lt:Mai mic,exists:Există,not_exists:Nu există'],['expected','Valoare așteptată','text'],['severity','Severitate','select','low:Low,medium:Medium,high:High']];
function hardeningAdminFields(fields,data={}){return fields.map(([key,title,type,options])=>`<label>${e(title)}${type==='select'?`<select name="${key}">${options.split(',').map(x=>{const [v,t]=x.split(':');return `<option value="${e(v)}" ${String(data[key]??'')===v?'selected':''}>${e(t)}</option>`}).join('')}</select>`:`<input name="${key}" value="${e(data[key]||'')}" ${key==='code'&&data.lockCode?'readonly':''} maxlength="${key==='benchmark_url'?'1024':'255'}">`}</label>`).join('')}
function hardeningEditorOpen(mode,fields,initial={},title=''){const d=document.getElementById('hardeningAdminDialog'),form=document.getElementById('hardeningAdminForm');form.dataset.mode=mode;document.getElementById('hardeningAdminTitle').textContent=title||'Editor Hardening';document.getElementById('hardeningAdminFields').innerHTML=hardeningAdminFields(fields,initial);d.showModal();}
function hardeningAdminData(form){const x=Object.fromEntries(new FormData(form));return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,String(v).trim()]));}
async function hardeningCatalogPage(){
 pageMeta('Nomenclatoare','Hardening · benchmarkuri, profiluri și reguli configurabile');
 const cat=await api('/api/v1/hardening/catalog');
 const selected=(cat.profiles||[]).find(x=>Number(x.id)===Number(hardeningUIState.profileId))||cat.profiles?.[0];hardeningUIState.profileId=Number(selected?.id||0);
 const tab=hardeningAdmin.tab,allowed=can('nomenclatures.manage');
 const toolbar=`<div class="hardening-admin-toolbar">${['benchmarks','profiles','rules'].map((x,i)=>`<button type="button" data-tab="${x}" class="small ${x===tab?'':'secondary'} hardening-tab">${['Benchmarkuri','Profiluri','Bibliotecă reguli'][i]}</button>`).join('')}<span class="hardening-admin-spacer"></span>${allowed?`<button class="small" id="hardeningAdminAdd">${tab==='profiles'?'Profil nou':tab==='rules'?'Regulă nouă':'Benchmark nou'}</button>`:''}${allowed?'<button type="button" class="small secondary" id="hardeningImportOpen">Import profil JSON</button>':''}<a class="button-link small secondary" href="#reports/hardening">Raport</a></div>`;
 let pane='';
 if(tab==='profiles'){
  pane=`<div class="hardening-profiles">${(cat.profiles||[]).map(p=>`<article class="hardening-profile-card ${p.id===selected?.id?'active':''}"><a class="hardening-profile-open" href="#nomenclatures/hardening" data-id="${p.id}"><strong>${e(p.name)}</strong><span>${e(p.technology||p.os_match)} · ${e(p.version_prefix||'orice versiune')}</span><span>${e(p.benchmark)} ${e(p.benchmark_version)}</span></a><div class="hardening-profile-foot"><span class="badge">${e(p.lifecycle||'published')} · v${Number(p.revision||1)}</span><span class="badge">${e(p.scope||'os')}</span></div></article>`).join('')}</div>`;
  if(selected){let activeRules=(cat.rules||[]).filter(x=>Number(x.profile_id)===Number(selected.id));pane+=`<section class="hardening-detail-panel"><div class="report-header"><div><strong>${e(selected.name)}</strong><span>Profil ${e(selected.lifecycle)} · ${activeRules.length} reguli · versiune benchmark ${e(selected.benchmark_version)}</span></div><div class="actions">${selected.lifecycle==='draft'&&allowed?`<button class="small secondary" id="hardeningEditDraft">Editează</button><button class="small" id="hardeningPublish">Publică</button><button class="small secondary" id="hardeningAttachOpen">Adaugă regulă</button>`:''}${selected.lifecycle==='published'&&allowed?`<button class="small secondary" id="hardeningClone">Clonează</button><button class="small danger" id="hardeningArchive">Arhivează</button>`:''}<a class="button-link small secondary" href="/api/v1/hardening/profiles/${selected.id}/export">Export JSON</a></div></div><p class="muted">${selected.scope==='component'?'Profil tehnic: evaluarea automată per instanță necesită dovezile colectorului specializat. Până atunci rămâne catalog, nu scor automat.':'Profil OS: se evaluează pe dovezile colectate de agent, numai după publicare.'}</p><div class="table-wrap"><table><thead><tr><th>Cod</th><th>Regulă</th><th>Operator / prag</th><th>CIS</th><th>Acțiune</th></tr></thead><tbody>${activeRules.map(x=>`<tr><td class="mono">${e(x.code)}</td><td>${e(x.name)}<div class="muted">${e(x.check_key)}</div></td><td>${e(x.operator||'eq')} · ${e(x.expected)}</td><td>${e(x.recommendation_id||'De validat')} · ${e(x.mapping_status)}</td><td>${allowed?`<button class="small secondary hardening-map-edit" data-code="${e(x.code)}" data-profile="${selected.id}">CIS</button> ${selected.lifecycle==='draft'?`<button class="small danger hardening-detach" data-code="${e(x.code)}">Scoate</button>`:''}`:'—'}</td></tr>`).join('')||'<tr><td colspan="5">Nu există reguli. Adaugă din bibliotecă.</td></tr>'}</tbody></table></div></section>`}
 }else if(tab==='rules'){
  pane=`<div class="report-header"><div><strong>Bibliotecă reguli</strong><span>${(cat.library_rules||[]).length} definiții. Reguli noi folosesc numai chei din inventar și operatori permiși.</span></div></div><div class="table-wrap"><table><thead><tr><th>Cod</th><th>Regulă</th><th>Cheie dovadă</th><th>Operator / valoare</th><th>Severitate</th></tr></thead><tbody>${(cat.library_rules||[]).map(x=>`<tr><td class="mono">${e(x.code)}</td><td>${e(x.name)}<div class="muted">${e(x.category)}</div></td><td class="mono">${e(x.check_key)}</td><td>${e(x.operator||'eq')} ${e(x.expected)}</td><td>${e(x.severity)}</td></tr>`).join('')}</tbody></table></div>`;
 }else{
  pane=`<div class="report-header"><div><strong>Benchmarkuri de referință</strong><span>Referințe versionate. Importul nu reproduce conținutul licențiat CIS.</span></div></div><div class="table-wrap"><table><thead><tr><th>Benchmark</th><th>Tehnologie</th><th>Versiune</th><th>Link / observații</th></tr></thead><tbody>${(cat.benchmarks||[]).map(b=>`<tr><td><strong>${e(b.name)}</strong><div class="muted mono">${e(b.code)}</div></td><td>${e(b.technology)}</td><td>${e(b.benchmark_version)}</td><td>${b.benchmark_url?`<a href="${e(b.benchmark_url)}" target="_blank" rel="noopener">Oficial</a>`:'—'}<div class="muted">${e(b.notes||'')}</div></td></tr>`).join('')}</tbody></table></div>`;
 }
 const mappingDialog=`<dialog id="hardeningMappingDialog" class="hardening-mapping-dialog"><form id="hardeningMappingForm"><h3>Referință CIS</h3><p class="muted" id="hardeningMappingSubtitle"></p><div class="hardening-mapping-fields"><label>Recommendation ID<input id="hardeningRecommendation"></label><label>CIS Controls<input id="hardeningControl"></label><label>Stare<select id="hardeningMappingStatus"><option value="pending">De validat</option><option value="reviewed">Verificat intern</option></select></label><label>Notă de verificare<textarea id="hardeningMappingNote" rows="3"></textarea></label><p class="muted">Severitatea și criteriul de evaluare se schimbă prin clonarea profilului și o regulă nouă.</p></div><div class="form-actions"><button type="button" class="secondary" id="hardeningMappingCancel">Anulează</button><button type="submit">Salvează</button></div></form></dialog>`;
 content.innerHTML=`<div class="nomenclature-layout hardening-workspace">${nomenclatureNavigation('hardening')}<main class="nomenclature-workspace"><div class="report-header hardening-catalog-heading hardening-beta-host"><div><strong>Hardening · administrare extensibilă</strong><span>Profiluri Draft → Publicate → Arhivate. Modificările profilurilor publicate se fac prin clonare.</span></div>${hardeningBeta()}</div>${toolbar}${pane}<p class="muted">Mapările CIS rămân pending până la validarea manuală a versiunii exacte. Nu constituie evaluare CIS oficială.</p>${mappingDialog}<dialog id="hardeningAdminDialog" class="hardening-mapping-dialog hardening-admin-dialog"><form id="hardeningAdminForm"><h3 id="hardeningAdminTitle"></h3><div id="hardeningAdminFields" class="hardening-admin-form"></div><div class="form-actions"><button type="button" class="secondary" id="hardeningAdminCancel">Anulează</button><button type="submit">Salvează</button></div></form></dialog><dialog id="hardeningImportDialog" class="hardening-mapping-dialog"><h3>Import profil din JSON</h3><p class="muted">Numai formatul VM-DOC. Creează un profil nou Draft; referințele CIS sunt marcate pending.</p><textarea rows="12" id="hardeningImportJSON" style="width:100%;background:var(--field-bg);color:var(--text)"></textarea><div class="form-actions"><button type="button" class="secondary" id="hardeningImportCancel">Anulează</button><button type="button" id="hardeningImportSubmit">Importă</button></div></dialog></main></div>`;
 document.querySelectorAll('.hardening-tab').forEach(b=>b.onclick=()=>{hardeningAdmin.tab=b.dataset.tab;hardeningCatalogPage()});
 document.querySelectorAll('.hardening-profile-open').forEach(b=>b.onclick=ev=>{ev.preventDefault();hardeningUIState.profileId=Number(b.dataset.id);hardeningCatalogPage()});
 document.getElementById('hardeningAdminCancel')?.addEventListener('click',()=>document.getElementById('hardeningAdminDialog').close());
 document.getElementById('hardeningAdminAdd')?.addEventListener('click',()=>{if(tab==='profiles')hardeningEditorOpen('profile',hardeningProfileFields,{scope:'os',level:'L1',os_match:'ubuntu'},'Profil nou (Draft)');else if(tab==='rules')hardeningEditorOpen('rule',hardeningRuleFields,{operator:'eq',severity:'medium'},'Regulă nouă');else hardeningEditorOpen('benchmark',[['code','Cod','text'],['name','Denumire','text'],['technology','Tehnologie','text'],['benchmark_version','Versiune','text'],['benchmark_url','URL oficial','text'],['notes','Note','text']],{},'Benchmark nou')});
 document.getElementById('hardeningEditDraft')?.addEventListener('click',()=>hardeningEditorOpen('edit',hardeningProfileFields,{...selected,lockCode:true},'Editează profil Draft'));
 document.getElementById('hardeningClone')?.addEventListener('click',()=>hardeningEditorOpen('clone',[['code','Cod nou','text'],['name','Nume nou','text']],{name:selected.name+' — revizie nouă'},'Clonează profil'));
 document.getElementById('hardeningAttachOpen')?.addEventListener('click',()=>hardeningEditorOpen('attach',[['rule_code','Cod regulă din bibliotecă','select',(cat.library_rules||[]).filter(x=>!(cat.rules||[]).some(y=>y.profile_id===selected.id&&y.code===x.code)).map(x=>`${x.code}:${x.code}`).join(',')]],{},'Adaugă regulă la profil'));
 for(const [button,url,question] of [['hardeningPublish',`/api/v1/hardening/profiles/${selected?.id}/publish`,'Publicăm profilul? După publicare, modificările se fac prin clonare.'],['hardeningArchive',`/api/v1/hardening/profiles/${selected?.id}/archive`,'Arhivăm profilul? Nu se va mai aplica automat.']])document.getElementById(button)?.addEventListener('click',async()=>{if(!confirm(question))return;try{await api(url,{method:'POST',body:'{}'});toast('Profil actualizat');hardeningCatalogPage()}catch(err){toast(err.message,true)}});
 document.querySelectorAll('.hardening-detach').forEach(b=>b.onclick=async()=>{if(!confirm('Scoți regula din profilul Draft?'))return;try{await api(`/api/v1/hardening/profiles/${selected.id}/rules/${encodeURIComponent(b.dataset.code)}`,{method:'DELETE'});hardeningCatalogPage()}catch(err){toast(err.message,true)}});
 document.getElementById('hardeningAdminForm').onsubmit=async ev=>{ev.preventDefault();const form=ev.currentTarget,mode=form.dataset.mode,b=hardeningAdminData(form);let url='',method='POST';if(mode==='profile')url='/api/v1/hardening/profiles';if(mode==='edit'){url=`/api/v1/hardening/profiles/${selected.id}/draft`;method='PUT'}if(mode==='clone')url=`/api/v1/hardening/profiles/${selected.id}/clone`;if(mode==='attach')url=`/api/v1/hardening/profiles/${selected.id}/rules`;if(mode==='rule')url='/api/v1/hardening/rules';if(mode==='benchmark')url='/api/v1/hardening/benchmarks';try{const result=await api(url,{method,body:JSON.stringify(b)});document.getElementById('hardeningAdminDialog').close();if(result?.id)hardeningUIState.profileId=Number(result.id);hardeningAdmin.tab=mode==='rule'?'rules':mode==='benchmark'?'benchmarks':'profiles';toast('Salvat');hardeningCatalogPage()}catch(err){toast(err.message,true)}};
 document.getElementById('hardeningImportOpen')?.addEventListener('click',()=>document.getElementById('hardeningImportDialog').showModal());document.getElementById('hardeningImportCancel')?.addEventListener('click',()=>document.getElementById('hardeningImportDialog').close());document.getElementById('hardeningImportSubmit')?.addEventListener('click',async()=>{try{const payload=JSON.parse(document.getElementById('hardeningImportJSON').value);const result=await api('/api/v1/hardening/profiles/import',{method:'POST',body:JSON.stringify(payload)});hardeningUIState.profileId=result.id;hardeningAdmin.tab='profiles';toast('Importat în Draft');hardeningCatalogPage()}catch(err){toast(err.message,true)}});
 bindHardeningEditors(cat);
}
function bindHardeningEditors(cat){document.querySelectorAll('.hardening-map-edit').forEach(btn=>{btn.onclick=()=>{const r=(cat.rules||[]).find(x=>x.code===btn.dataset.code&&Number(x.profile_id)===Number(btn.dataset.profile));if(!r)return;const d=document.getElementById('hardeningMappingDialog'),form=document.getElementById('hardeningMappingForm');form.dataset.code=r.code;form.dataset.profile=r.profile_id;document.getElementById('hardeningMappingSubtitle').textContent=`${r.code} · ${r.name}`;document.getElementById('hardeningRecommendation').value=r.recommendation_id||'';document.getElementById('hardeningControl').value=r.control_id||'';document.getElementById('hardeningMappingStatus').value=r.mapping_status||'pending';document.getElementById('hardeningMappingNote').value=r.mapping_note||'';d.showModal()}});
 const dialog=document.getElementById('hardeningMappingDialog');document.getElementById('hardeningMappingCancel').onclick=()=>dialog.close();document.getElementById('hardeningMappingForm').onsubmit=async ev=>{ev.preventDefault();const f=ev.target;try{await api('/api/v1/hardening/mappings',{method:'PUT',body:JSON.stringify({profile_id:Number(f.dataset.profile),rule_code:f.dataset.code,recommendation_id:document.getElementById('hardeningRecommendation').value.trim(),control_id:document.getElementById('hardeningControl').value.trim(),status:document.getElementById('hardeningMappingStatus').value,note:document.getElementById('hardeningMappingNote').value.trim()})});dialog.close();toast('Regulă și mapare salvate.');await hardeningCatalogPage()}catch(err){toast(err.message,true)}};
}
function hardeningAssessmentRows(a){return (a.results||[]).map(r=>`<tr><td><strong class="mono">${e(r.code)}</strong><div class="muted">${e(r.category)}</div></td><td>${e(r.name)}</td><td>${hardeningBadge(r.status)}</td><td><span class="mono">${e(r.actual||'—')}</span><div class="muted">${e(r.source||r.note||'')}</div></td><td class="mono">${e(r.expected||'—')}</td><td>${r.recommendation_id?`<span class="mono">${e(r.recommendation_id)}</span>`:'<span class="muted">De validat</span>'}<div class="muted">${e(a.profile?.benchmark_version||'')}</div></td></tr>`).join('')}
function hardeningScore(a){if(!a.profile)return '<span class="muted">Profil indisponibil</span>';return `<strong>${Number(a.score||0)}%</strong><span class="muted"> · ${a.passed||0} conforme / ${a.failed||0} neconforme / ${a.unknown||0} neverificate</span>`}
function hardeningVMBody(a,vmID,profiles=[]){
 if(!a)return panel('Evaluare Hardening',empty('Nu s-au putut încărca rezultatele.'));
 const choices=(profiles||[]).filter(p=>p.enabled&&p.scope==='os'&&p.lifecycle==='published').map(p=>`<option value="${p.id}" ${p.id===a.profile?.id?'selected':''}>${e(p.name)}</option>`).join('');
 const profileCard=`<div class="hardening-vm-info-card"><span class="hardening-card-label">Profil de evaluare</span><strong>${e(a.profile?.name||'Niciun profil aplicabil')}</strong><div class="muted">${e([a.profile?.benchmark,a.profile?.benchmark_version].filter(Boolean).join(' ')||'Determinare după sistemul de operare')}</div></div>`;
 const scoreCard=`<div class="hardening-vm-info-card"><span class="hardening-card-label">Evaluare curentă</span><div class="hardening-vm-score">${hardeningScore(a)}</div></div>`;
 const settingCard=can('vms.manage')?`<div class="hardening-vm-setting"><label for="vmHardeningProfile" class="hardening-card-label">Profil aplicat</label><select id="vmHardeningProfile"><option value="0">Automat după OS</option>${choices}</select><button type="button" id="vmHardeningSaveProfile" class="small secondary">Salvează profilul</button></div>`:`<div class="hardening-vm-setting"><span class="hardening-card-label">Profil aplicat</span><strong>${e(a.profile?.name||'Automat după OS')}</strong><span class="muted">Vizualizare · fără drept de modificare</span></div>`;
 const rows=hardeningAssessmentRows(a);
 const exportAction=`<a class="button-link small secondary" href="/api/v1/reports/hardening/export?vm_id=${vmID}">Export Excel</a>`;
 const assessed=panel('Controale evaluate',rows?`<div class="table-wrap hardening-vm-assessment-table"><table data-sortable="false"><thead><tr><th>ID intern</th><th>Verificare</th><th>Rezultat</th><th>Valoare / dovadă</th><th>Prag</th><th>CIS ID</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Profilul nu are controale active sau nu există profil pentru acest OS.'),exportAction,'hardening-vm-assessment');
 return `<section class="hardening-vm-shell hardening-beta-host"><header class="hardening-vm-heading"><strong>Hardening VM · ${e(a.vm_name)}</strong></header>${hardeningBeta()}<div class="hardening-vm-profile">${profileCard}${scoreCard}${settingCard}</div>${assessed}<p class="hardening-beta-note"><strong>Hardening BETA · în validare.</strong> Verificări proprii din ultima colectare, fără remediere automată. Scorul este intern: controalele necunoscute intră în numitor, iar referințele CIS sunt specifice versiunii benchmarkului și necesită verificare. Nu reprezintă certificare CIS.</p></section>`;
}
function bindHardeningVMControls(vmID){document.getElementById('vmHardeningSaveProfile')?.addEventListener('click',async()=>{try{await api(`/api/v1/vms/${vmID}/hardening-profile`,{method:'PUT',body:JSON.stringify({profile_id:Number(document.getElementById('vmHardeningProfile').value)})});toast('Profil salvat.');vmDetail(vmID,'security-hardening')}catch(err){toast(err.message,true)}})}
// 0.21.44 — Hardening: uniform UI, explicit BETA, page-local filtering.
// Backend continues to page before this filter. No user-facing claim of cross-page search.
function hardeningApplyPageFilters(root=document){
 const scope=root.querySelector('#hardeningResults');if(!scope)return;
 const q=String(root.querySelector('#hardeningSearch')?.value||'').trim().toLocaleLowerCase('ro');
 const filter=root.querySelector('#hardeningStatus')?.value||'all';
 let count=0;
 scope.querySelectorAll('tr[data-hardening-row]').forEach(row=>{
  const matchQuery=!q||String(row.dataset.search||'').includes(q);
  const f=Number(row.dataset.failed||0),u=Number(row.dataset.unknown||0);
  const matchStatus=filter==='all'||(filter==='failed'&&f>0)||(filter==='unknown'&&u>0)||(filter==='no_profile'&&row.dataset.hasProfile==='no')||(filter==='no_failures'&&f===0&&row.dataset.hasProfile==='yes');
  row.hidden=!(matchQuery&&matchStatus);
  if(!row.hidden)count++;
 });
 const counter=root.querySelector('#hardeningVisibleCount');if(counter)counter.textContent=`${count} din ${scope.querySelectorAll('tr[data-hardening-row]').length} VM-uri pe pagina curentă`;
 const emptyRow=root.querySelector('#hardeningFilteredEmpty');if(emptyRow)emptyRow.hidden=count!==0;
}
async function hardeningReportPage(mode='reports'){
 pageMeta(mode==='security'?'Securitate':'Rapoarte','Hardening · BETA — verificări interne, fără certificare CIS');
 const f=hardeningUIState,p=new URLSearchParams({page:String(f.page),page_size:String(f.pageSize)});
 const data=await api(`${mode==='security'?'/api/v1/security/hardening':'/api/v1/reports/hardening'}?${p}`);
 const items=data.items||[];
 const rows=items.map(a=>{
  const search=[a.vm_name,a.os_name,a.os_version,a.profile?.name,a.profile?.benchmark].filter(Boolean).join(' ').toLocaleLowerCase('ro');
  return `<tr data-hardening-row data-search="${e(search)}" data-failed="${Number(a.failed||0)}" data-unknown="${Number(a.unknown||0)}" data-has-profile="${a.profile?'yes':'no'}"><td><a href="#vms/${a.vm_id}/security-hardening"><strong>${e(a.vm_name)}</strong></a><div class="muted">${e(a.os_name||'—')} · ${e(a.os_version||'')}</div></td><td>${a.profile?`<strong>${e(a.profile.name)}</strong><div class="muted">${e(a.profile.benchmark)} v${e(a.profile.benchmark_version)}</div>`:'<span class="muted">Niciun profil compatibil</span>'}</td><td>${hardeningScore(a)}</td><td>${a.profile?`<details class="hardening-result-details"><summary>Vezi regulile (${(a.results||[]).length})</summary><div class="table-wrap"><table data-sortable="false"><thead><tr><th>Cod</th><th>Verificare</th><th>Rezultat</th><th>Observat</th><th>Prag</th><th>CIS</th></tr></thead><tbody>${hardeningAssessmentRows(a)}</tbody></table></div></details>`:'—'}</td></tr>`
 }).join('');
 const exportAction=can('reports.read')?'<a class="button-link small secondary" href="/api/v1/reports/hardening/export">Export Excel</a>':'';
 const catalogueAction=can('nomenclatures.read')?'<a class="button-link small secondary" href="#nomenclatures/hardening">Profiluri și reguli</a>':'';
 const prev=f.page>1?'<button id="hardeningPrev" class="small secondary">Anterior</button>':'';
 const next=f.page*f.pageSize<data.total?'<button id="hardeningNext" class="small secondary">Următor</button>':'';
 const cards=`<div class="hardening-report-summary"><article><span>VM-uri (total)</span><strong>${Number(data.total||0).toLocaleString('ro-RO')}</strong></article><article><span>VM-uri pe pagină</span><strong>${items.length}</strong></article><article><span>Reguli neconforme · pagina</span><strong>${items.reduce((n,x)=>n+Number(x.failed||0),0)}</strong></article><article><span>Reguli neverificate · pagina</span><strong>${items.reduce((n,x)=>n+Number(x.unknown||0),0)}</strong></article></div>`;
 const controls=`<div class="hardening-filters" role="search" aria-label="Filtre Hardening, pagina curentă"><label>Caută VM, OS sau profil (pagina curentă)<input id="hardeningSearch" type="search" placeholder="VM, sistem de operare sau profil…" autocomplete="off"></label><label>Stare (pagina curentă)<select id="hardeningStatus"><option value="all">Toate</option><option value="failed">Cu reguli neconforme</option><option value="unknown">Cu reguli neverificate</option><option value="no_profile">Fără profil</option><option value="no_failures">Fără reguli neconforme</option></select></label><button id="hardeningReset" type="button" class="small secondary">Resetează</button></div>`;
 const table=`<div class="table-wrap hardening-report-table" tabindex="0" aria-label="Evaluări Hardening, scroll orizontal la nevoie"><table data-sortable="false"><thead><tr><th>VM / OS</th><th>Profil de referință</th><th>Evaluare internă</th><th>Reguli</th></tr></thead><tbody id="hardeningResults">${rows}<tr id="hardeningFilteredEmpty" hidden><td colspan="4">Nicio VM pe această pagină nu corespunde filtrelor.</td></tr></tbody></table></div>`;
 const pager=`<div class="hardening-report-pager"><span>Pagina ${Number(data.page||1)} · ${Number(data.total||0)} VM-uri în total</span>${prev}${next}<label>Pe pagină <select id="hardeningPageSize">${[10,25,50,100].map(n=>`<option ${n===f.pageSize?'selected':''}>${n}</option>`).join('')}</select></label></div>`;
 const body=`<div class="hardening-report-shell hardening-beta-host"><section class="hardening-page-heading"><div class="hardening-heading-main"><strong>Hardening · evaluare internă</strong></div></section>${hardeningBeta()}${cards}<section class="panel hardening-evaluation-panel"><div class="panel-header"><div><strong>Evaluări VM</strong><div class="muted" id="hardeningVisibleCount">${items.length} din ${items.length} VM-uri pe pagina curentă</div></div><div class="toolbar">${catalogueAction}${exportAction}</div></div>${controls}${table}${pager}</section><p class="hardening-beta-note"><strong>Hardening BETA · în validare.</strong> Baseline VM-DOC din ultimul inventar; „Neverificat” nu înseamnă conformitate. Scorul este intern și nu reprezintă certificare CIS. Filtrarea este limitată la pagina curentă.</p></div>`;
 content.innerHTML=mode==='security'?`<div class="monitoring-workspace security-workspace hardening-security-page">${securityNav('hardening')}${body}</div>`:`<div class="nomenclature-layout report-layout">${reportSubmenu('hardening')}<div class="nomenclature-workspace hardening-security-page">${body}</div></div>`;
 const page=document.querySelector('.hardening-security-page');
 page?.querySelector('#hardeningSearch')?.addEventListener('input',()=>hardeningApplyPageFilters(page));
 page?.querySelector('#hardeningStatus')?.addEventListener('change',()=>hardeningApplyPageFilters(page));
 page?.querySelector('#hardeningReset')?.addEventListener('click',()=>{page.querySelector('#hardeningSearch').value='';page.querySelector('#hardeningStatus').value='all';hardeningApplyPageFilters(page)});
 page?.querySelector('#hardeningPrev')?.addEventListener('click',()=>{f.page--;hardeningReportPage(mode)});
 page?.querySelector('#hardeningNext')?.addEventListener('click',()=>{f.page++;hardeningReportPage(mode)});
 page?.querySelector('#hardeningPageSize')?.addEventListener('change',ev=>{f.pageSize=Number(ev.target.value);f.page=1;hardeningReportPage(mode)});
}

// 0.21.67 — lifecycle archive. All forms act on explicit user intent: no
// delete, no automatic archive when a vCenter VM disappears.
const lifecycleFilters={q:'',type:'all',status:'all',page:1,pageSize:25};
let lifecycleRows=[];
const lifecycleNames={active:'Activ',retired:'Retras',archived:'Arhivat'};
function markLifecycleArchiveOnDetail(kind,id){
 api(`/api/v1/lifecycle/${kind}/${id}`).then(value=>{
  const parts=(location.hash||'').slice(1).split('/');if(parts[0]!== (kind==='vm'?'vms':'services')||Number(parts[1])!==Number(id)||value.status!=='archived')return;
  const target=content.querySelector(kind==='vm'?'.vm-detail-workspace':'.service-detail-workspace');
  if(target&&!content.querySelector('.lifecycle-detail-banner'))target.insertAdjacentHTML('beforebegin',`<div class="notice info lifecycle-detail-banner"><strong>Fișă arhivată</strong><span>Această resursă este păstrată numai ca istoric. <a href="#archive">Arhivă VM & servicii</a></span></div>`);
 }).catch(()=>{});
}
function lifecycleRowState(row){return row.status==='active'&&!row.present_in_vcenter&&row.type==='vm'?'missing':row.status}
function lifecycleStateBadge(row){const status=lifecycleRowState(row);const labels={...lifecycleNames,missing:'Dispariție neconfirmată'};return `<span class="badge ${status==='missing'?'missing':status==='archived'?'disabled':status==='retired'?'powered-off':'active'}">${e(labels[status]||status)}</span>`}
function lifecycleActionButtons(row){if(!(row.type==='vm'?can('vms.manage'):can('services.manage')))return '';
 const buttons=[];
 if(row.status==='active')buttons.push(['retired','Retrage']);
 if(row.status==='retired')buttons.push(['archived','Arhivează'],['active','Reactivează']);
 if(row.status==='archived')buttons.push(['retired','Revino la retras'],['active','Reactivează']);
 return `<div class="actions">${buttons.map(([status,label])=>`<button type="button" class="small secondary lifecycle-action" data-kind="${row.type}" data-id="${row.id}" data-status="${status}">${label}</button>`).join('')}</div>`;
}
function lifecycleBeta(){
 return '<span class="hardening-beta" role="status" aria-label="Arhivă VM și servicii BETA, funcționalitate în validare" title="BETA · ciclu de viață și arhivare în validare">BETA</span>';
}
function lifecycleArchiveTable(rows){if(!rows.length)return empty('Nu există VM-uri sau servicii pentru filtrele selectate.');
 return `<div class="table-wrap lifecycle-table-wrap" role="region" aria-label="Registru VM și servicii" tabindex="0"><table class="lifecycle-table"><thead><tr><th>VM / Serviciu</th><th>Etapă</th><th>vCenter / Power</th><th>Date importante</th><th>Decizie / aprobare</th><th>Retenție</th><th>Acțiuni</th></tr></thead><tbody>${rows.map(row=>{
   const link=row.type==='vm'?`#vms/${row.id}/overview`:`#services/${row.id}/overview`;
   return `<tr class="lifecycle-table-row"><td class="lifecycle-name-cell"><a href="${link}" class="lifecycle-resource-name">${e(row.name)}</a><div class="lifecycle-resource-meta">${row.type==='vm'?'VM':'Serviciu'} #${row.id}</div>${row.service_names?`<div class="lifecycle-related" title="${e(row.service_names)}">Servicii: ${e(row.service_names)}</div>`:''}</td><td>${lifecycleStateBadge(row)}</td><td>${row.type==='vm'?`${badge(row.power_state||'unknown')}<div class="lifecycle-resource-meta">${row.present_in_vcenter?'În vCenter':'Lipsă din vCenter'}</div>`:'—'}</td><td class="lifecycle-dates"><span>Retras: ${dt(row.retired_at)}</span><span>Arhivat: ${dt(row.archived_at)}</span>${row.missing_since?`<span>Absent: ${dt(row.missing_since)}</span>`:''}</td><td class="lifecycle-decision"><strong>${e(row.reason||'—')}</strong>${row.approved_by?`<div class="lifecycle-resource-meta">De: ${e(row.approved_by)}</div>`:''}${row.notes?`<details class="lifecycle-notes"><summary>Observații</summary><div>${e(row.notes)}</div></details>`:''}</td><td class="lifecycle-retention">${row.retention_until?e(row.retention_until):'—'}</td><td class="lifecycle-row-actions">${lifecycleActionButtons(row)||'<span class="muted">—</span>'}</td></tr>`
 }).join('')}</tbody></table></div>`;
}
function renderLifecycleArchiveRows(){const f=lifecycleFilters;let rows=lifecycleRows.filter(row=>{
 const s=lifecycleRowState(row),q=f.q.toLocaleLowerCase('ro');
 return (f.type==='all'||f.type===row.type)&&(f.status==='all'||f.status===s)&&(!q||[row.name,row.reason,row.approved_by,row.service_names,row.notes].join(' ').toLocaleLowerCase('ro').includes(q));
 });
 const total=rows.length,pages=Math.max(1,Math.ceil(total/f.pageSize));f.page=Math.max(1,Math.min(f.page,pages));rows=rows.slice((f.page-1)*f.pageSize,f.page*f.pageSize);
 const root=document.getElementById('lifecycleArchiveList');if(!root)return;
 const pageStart=total?(f.page-1)*f.pageSize+1:0,pageEnd=Math.min(total,f.page*f.pageSize);
 const pagenav=`<div class="pagination lifecycle-pagination"><span>${pageStart}–${pageEnd} din ${total.toLocaleString('ro-RO')} înregistrări</span><div class="pagination-buttons"><button type="button" class="small secondary" id="lifecyclePrev" aria-label="Pagina precedentă" ${f.page===1?'disabled':''}>←</button><span>Pagina ${f.page} / ${pages}</span><button type="button" class="small secondary" id="lifecycleNext" aria-label="Pagina următoare" ${f.page>=pages?'disabled':''}>→</button></div></div>`;
 root.innerHTML=lifecycleArchiveTable(rows)+pagenav;
 const results=document.getElementById('lifecycleResultCount');if(results)results.textContent=`${total.toLocaleString('ro-RO')} rezultate`;
 document.querySelectorAll('.lifecycle-stat-card').forEach(b=>b.setAttribute('aria-pressed',String(f.type===b.dataset.type&&f.status===b.dataset.status)));
 root.querySelectorAll('.lifecycle-action').forEach(button=>button.addEventListener('click',()=>{
  const row=lifecycleRows.find(x=>x.type===button.dataset.kind&&Number(x.id)===Number(button.dataset.id));if(row)openLifecycleModal(row,button.dataset.status);
 }));
 root.querySelector('#lifecyclePrev')?.addEventListener('click',()=>{f.page--;renderLifecycleArchiveRows()});
 root.querySelector('#lifecycleNext')?.addEventListener('click',()=>{f.page++;renderLifecycleArchiveRows()});
}
async function lifecycleArchivePage(){
 pageMeta('Arhivă VM & servicii','Retragere, dezafectare și documentație istorică · BETA');
 lifecycleRows=await api('/api/v1/lifecycle/archive');
 const totalVM=lifecycleRows.filter(r=>r.type==='vm').length,services=lifecycleRows.filter(r=>r.type==='service').length,archived=lifecycleRows.filter(r=>r.status==='archived').length,missing=lifecycleRows.filter(r=>r.type==='vm'&&r.status==='active'&&!r.present_in_vcenter).length;
 const stat=(label,count,type,status,sub)=>`<button type="button" class="lifecycle-stat-card" data-type="${type}" data-status="${status}" aria-pressed="false"><span class="lifecycle-stat-label">${label}</span><strong class="lifecycle-stat-value">${count.toLocaleString('ro-RO')}</strong><span class="lifecycle-stat-help">${sub}</span></button>`;
 content.innerHTML=`<div class="lifecycle-workspace hardening-beta-host">
  <section class="lifecycle-page-heading"><div><strong>Arhivă VM & servicii</strong><p>Registrul retragerii, arhivării și al disparițiilor neconfirmate din vCenter.</p></div></section>${lifecycleBeta()}
  <div class="lifecycle-summary-cards" aria-label="Sumar arhivă">${stat('VM-uri în registru',totalVM,'vm','all','Retrase, arhivate sau absente')}${stat('Servicii în registru',services,'service','all','Servicii retrase sau arhivate')}${stat('Arhivate',archived,'all','archived','Fișe păstrate ca istoric')}${stat('Dispariții neconfirmate',missing,'vm','missing','Necesită verificare înainte de retragere')}</div>
  <section class="lifecycle-process" aria-label="Etapele ciclului de viață"><div class="lifecycle-process-title"><strong>Ciclu de viață</strong><span class="muted">Decizii explicite, fără ștergere automată</span></div><div class="lifecycle-steps"><span><b>1</b> Activă</span><i aria-hidden="true">→</i><span><b>2</b> Retrasă</span><i aria-hidden="true">→</i><span><b>3</b> Arhivată</span></div><p>VM-urile retrase pot rămâne 3–6 luni în vCenter. Arhivarea păstrează inventarul și relațiile istorice; retenția nu execută ștergeri.</p></section>
  <section class="panel lifecycle-registry-panel"><div class="panel-header"><div class="lifecycle-registry-heading"><h2>Registru VM și servicii</h2><span id="lifecycleResultCount" class="muted" aria-live="polite"></span></div><div class="lifecycle-registry-hint">Selectează o înregistrare pentru fișă sau schimbă etapa din coloana Acțiuni.</div></div>
   <div class="lifecycle-filters"><label class="lifecycle-search"><span>Caută</span><input id="lifecycleSearch" type="search" value="${e(lifecycleFilters.q)}" placeholder="VM, serviciu, motiv, aprobator" autocomplete="off"></label><label><span>Tip resursă</span><select id="lifecycleType"><option value="all">Toate</option><option value="vm">VM-uri</option><option value="service">Servicii</option></select></label><label><span>Etapă</span><select id="lifecycleStatus"><option value="all">Toate</option><option value="missing">Dispariții neconfirmate</option><option value="retired">Retrase</option><option value="archived">Arhivate</option></select></label><label class="lifecycle-page-size"><span>Rânduri/pagină</span><select id="lifecyclePageSize"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select></label><button type="button" class="secondary" id="lifecycleReset">Resetează</button></div>
   <div id="lifecycleArchiveList"></div>
  </section>
  <p class="hardening-beta-note lifecycle-beta-note"><strong>Arhivă BETA · în validare.</strong> Păstrează fișele și asocierile istorice; dispariția din vCenter nu confirmă dezafectarea. Verifică motivul și aprobatorul înainte de arhivare. Nu se șterge automat niciun document.</p>
 </div>`;
 const syncFilters=()=>{document.getElementById('lifecycleSearch').value=lifecycleFilters.q;document.getElementById('lifecycleType').value=lifecycleFilters.type;document.getElementById('lifecycleStatus').value=lifecycleFilters.status;document.getElementById('lifecyclePageSize').value=String(lifecycleFilters.pageSize)};
 syncFilters();
 let t;document.getElementById('lifecycleSearch')?.addEventListener('input',ev=>{const value=ev.target.value;clearTimeout(t);t=setTimeout(()=>{lifecycleFilters.q=value;lifecycleFilters.page=1;renderLifecycleArchiveRows()},170)});
 for(const [id,key] of [['lifecycleType','type'],['lifecycleStatus','status']])document.getElementById(id)?.addEventListener('change',ev=>{lifecycleFilters[key]=ev.target.value;lifecycleFilters.page=1;renderLifecycleArchiveRows()});
 document.getElementById('lifecyclePageSize')?.addEventListener('change',ev=>{lifecycleFilters.pageSize=Number(ev.target.value);lifecycleFilters.page=1;renderLifecycleArchiveRows()});
 document.getElementById('lifecycleReset')?.addEventListener('click',()=>{Object.assign(lifecycleFilters,{q:'',type:'all',status:'all',page:1,pageSize:25});syncFilters();renderLifecycleArchiveRows()});
 document.querySelectorAll('.lifecycle-stat-card').forEach(button=>button.addEventListener('click',()=>{lifecycleFilters.type=button.dataset.type;lifecycleFilters.status=button.dataset.status;lifecycleFilters.q='';lifecycleFilters.page=1;syncFilters();renderLifecycleArchiveRows();document.querySelector('.lifecycle-registry-panel')?.scrollIntoView({behavior:'smooth',block:'start'})}));
 renderLifecycleArchiveRows();
}
function lifecycleDialogNode(){let dialog=document.getElementById('lifecycleDecisionDialog');if(dialog)return dialog;
 dialog=document.createElement('dialog');dialog.id='lifecycleDecisionDialog';dialog.className='lifecycle-dialog';
 dialog.innerHTML=`<form id="lifecycleDecisionForm" class="operational-form"><h3 id="lifecycleDialogTitle">Actualizare ciclu de viață</h3><p id="lifecycleDialogNotice" class="muted"></p><label>Motivul deciziei<textarea name="reason" rows="3" maxlength="1000" placeholder="Închidere proiect, migrare, dezafectare…"></textarea></label><label>Aprobat de<input name="approved_by" maxlength="255" placeholder="Nume / funcție"></label><label>Retenție documentație până la<input type="date" name="retention_until"></label><label>Observații<textarea name="notes" rows="3" maxlength="4000" placeholder="Ticket / decizie / detalii"></textarea></label><div class="form-actions"><button type="button" class="secondary" id="lifecycleDialogCancel">Anulează</button><button type="submit">Confirmă</button></div></form>`;
 document.body.append(dialog);dialog.querySelector('#lifecycleDialogCancel').addEventListener('click',()=>dialog.close());return dialog;
}
function openLifecycleModal(row,status){
 if(status==='archived'&&row.type==='vm'&&row.present_in_vcenter!==false&&String(row.power_state||'').toUpperCase()==='POWERED_ON'){toast('VM este pornită. Oprește-o înainte de arhivare.',true);return}
 if(status==='archived'&&row.status!=='retired'){toast('Retrage întâi resursa, apoi arhiveaz-o.',true);return}
 const dialog=lifecycleDialogNode(),form=dialog.querySelector('form');
 form.reset();form.elements.reason.value=row.reason||'';form.elements.approved_by.value=row.approved_by||'';form.elements.notes.value=row.notes||'';
 const date=new Date();date.setFullYear(date.getFullYear()+2);const localISO=date.toISOString().slice(0,10);
 form.elements.retention_until.value=row.retention_until||((status==='archived')?localISO:'');
 dialog.querySelector('#lifecycleDialogTitle').textContent=(`${{active:'Reactivează',retired:'Retrage',archived:'Arhivează'}[status]} ${row.type==='vm'?'VM':'serviciul'} ${row.name}`);
 dialog.querySelector('#lifecycleDialogNotice').textContent=status==='archived'?'Păstrăm inventarul și documentele; se cere motiv și aprobator. Retenția nu șterge automat.':status==='active'?'Reactivarea este auditată. Verifică existența VM-ului în vCenter și dependențele înainte de reactivare.':'Înregistrăm retragerea din exploatare. VM-ul nu este șters din vCenter.';
 form.elements.reason.required=status==='archived';form.elements.approved_by.required=status==='archived';
 form.elements.retention_until.closest('label').hidden=status!=='archived';
 form.onsubmit=async ev=>{ev.preventDefault();if(status==='active'&&!confirm('Confirmi reactivarea? Verifică mai întâi starea reală a VM-ului/serviciului.'))return;
  const input={status,reason:form.elements.reason.value.trim(),approved_by:form.elements.approved_by.value.trim(),retention_until:status==='archived'?form.elements.retention_until.value:'',notes:form.elements.notes.value.trim()};
  const save=form.querySelector('[type="submit"]');save.disabled=true;
  try{await api(`/api/v1/lifecycle/${row.type}/${row.id}`,{method:'PUT',body:JSON.stringify(input)});dialog.close();toast('Etapa de viață a fost actualizată și auditată.');if(location.hash==='#archive')await lifecycleArchivePage();else location.hash='#archive'}catch(error){toast(error.message,true)}finally{save.disabled=false}
 };
 dialog.showModal();
}
