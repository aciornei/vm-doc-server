-- 0.21.8: presentation-only DB engine exclusions, without CREATE VIEW privileges. Keep normalized and raw collected data.
-- engine_key is canonical lowercase with spaces, underscores and dashes removed.
CREATE TABLE IF NOT EXISTS database_engine_exclusions (
  engine_key VARCHAR(64) NOT NULL PRIMARY KEY,
  ignored TINYINT(1) NOT NULL DEFAULT 1,
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default: ignore all commonly reported IBM Db2 spellings. INSERT IGNORE preserves
-- administrator overrides on re-running the migration.
INSERT IGNORE INTO database_engine_exclusions(engine_key,ignored) VALUES ('db2',1);

