#!/usr/bin/env python3
"""Offline regression test for the exclusion semantics (SQLite SQL subset).

The production backend uses MariaDB; run real integration tests in staging.
This test verifies the SQL engine-key predicate against representative data.
"""
import sqlite3

KEY = "REPLACE(REPLACE(REPLACE(LOWER(TRIM(i.engine)),' ',''),'_',''),'-','')"
CANONICAL = f"CASE WHEN {KEY} IN ('db2','ibmdb2','db2luw','ibmdb2luw') THEN 'db2' ELSE {KEY} END"
PREDICATE = f"NOT EXISTS(SELECT 1 FROM database_engine_exclusions x WHERE x.ignored=1 AND x.engine_key=({CANONICAL}))"

conn = sqlite3.connect(':memory:')
conn.executescript('''
CREATE TABLE database_instances(id INTEGER PRIMARY KEY, engine TEXT);
CREATE TABLE database_engine_exclusions(engine_key TEXT PRIMARY KEY,ignored INT NOT NULL);
INSERT INTO database_instances VALUES
(1,'Db2'),(2,'IBM Db2'),(3,'ibm_db2'),(4,'db2-luw'),(5,'MariaDB'),(6,'PostgreSQL');
INSERT INTO database_engine_exclusions VALUES ('db2',1);
''')
read = lambda: [r[0] for r in conn.execute(f'SELECT i.engine FROM database_instances i WHERE {PREDICATE} ORDER BY i.id')]
assert read() == ['MariaDB','PostgreSQL'], read()
assert conn.execute('SELECT COUNT(*) FROM database_instances').fetchone()[0] == 6
conn.execute("UPDATE database_engine_exclusions SET ignored=0 WHERE engine_key='db2'")
assert len(read()) == 6, read()
conn.execute("UPDATE database_engine_exclusions SET ignored=1 WHERE engine_key='db2'")
assert read() == ['MariaDB','PostgreSQL']
print('OK: Db2 aliases hidden; non-Db2 visible; policy reversible; raw rows preserved')
