# VM-DOC Server 0.21.7 → 0.21.8

**Important:** această versiune include **migrarea SQL 073**. Efectuați backup al bazei MariaDB înainte de actualizare și testați întâi în staging.

## Instalare offline

```bash
cd /usr/local/src
cp -a vm-doc-server-0.21.7 vm-doc-server-0.21.8
tar -xzf /cale/vm-doc-server-0.21.8-update.tar.gz -C /usr/local/src/vm-doc-server-0.21.8
cd /usr/local/src/vm-doc-server-0.21.8
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Instalați binarul folosind procedura internă și reporniți serviciul. Migrarea 073 se aplică automat la pornire, prin mecanismul existent `schema_migrations`. **Nu aplicați separat migrarea SQL dacă serverul o execută automat.** Verificați `/version` = `0.21.8` și reîncărcați interfața.

## Politica nouă

- În `Nomenclatoare → Inventar tehnic → Motoare DB ignorate`, IBM Db2 este bifat implicit.
- Excluderea se aplică motoarelor cu cod `db2` și `IBM Db2` (inclusiv `ibm_db2`, `ibm-db2`).
- Motorul ignorat nu mai apare în inventarul normalizat VM, în tabelele DB, fișe, Outline și rapoarte, nici în completitudinea documentării.
- Snapshoturile brute ale agentului și înregistrările stocate **nu sunt șterse**.
- Debifarea reactivează afișarea în baza ultimului inventar deja colectat.
- Se pot ignora și alte motoare detectate, fără recompilarea agentului.

## Verificări după instalare

1. `/version` returnează `0.21.8` și `schema_migrations` conține `073_database_engine_visibility.up.sql`.
2. `SELECT * FROM database_engine_exclusions;` indică `db2 = 1`.
3. Pentru o VM cu Db2 colectat: `database_instances` conține datele brute normalizate, dar `GET /api/v1/vms/{id}/databases` nu arată Db2.
4. `GET /api/v1/vms/{id}/databases`, Componente software, raportul Beneficiari și documentația nu afișează Db2.
5. Documentarea VM nu cere asocierea unei baze Db2 ignorate.
6. În Nomenclatoare, debifați Db2, verificați apariția fără colectare nouă, apoi bifați la loc.
7. Testați PostgreSQL/MariaDB/MySQL pentru a confirma că nu sunt afectate.

Fără actualizare de agent și fără schimbări de `vendor/`, `go.mod` sau `go.sum`.

### Limite ale validării locale

Testele MariaDB reale și compilarea Go cu dependințe externe necesită mediul de staging cu `vendor/` existent. Verificările statice ale arhivelor nu înlocuiesc testarea de integrare.
