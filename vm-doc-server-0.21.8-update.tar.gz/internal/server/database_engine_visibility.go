package server

import (
	"context"
	"errors"
	"net/http"
	"sort"
	"strings"
	"unicode"
)

// The policy controls the *presentation* of collected database engines.
// Normalized tables, snapshots, assignments and raw agent data are not erased.
type dbEngineVisibility struct {
	Key           string `json:"key"`
	Name          string `json:"name"`
	Ignored       bool   `json:"ignored"`
	EngineCount   int    `json:"engine_count"`
	InstanceCount int    `json:"instance_count"`
}

func dbEngineKey(value string) string {
	var b strings.Builder
	for _, r := range strings.ToLower(strings.TrimSpace(value)) {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			b.WriteRune(r)
		}
	}
	key := b.String()
	if key == "ibmdb2" || key == "db2luw" || key == "ibmdb2luw" {
		return "db2"
	}
	if len(key) > 64 {
		return ""
	}
	return key
}

func (a *App) dbEngineVisibilityRows(ctx context.Context) ([]dbEngineVisibility, error) {
	if a.DB == nil {
		return nil, errors.New("database unavailable")
	}
	byKey := make(map[string]*dbEngineVisibility)
	add := func(value string) *dbEngineVisibility {
		key := dbEngineKey(value)
		if key == "" {
			return nil
		}
		if x := byKey[key]; x != nil {
			return x
		}
		name := strings.TrimSpace(value)
		if key == "db2" {
			name = "IBM Db2"
		}
		x := &dbEngineVisibility{Key: key, Name: name}
		byKey[key] = x
		return x
	}
	rows, err := a.DB.QueryContext(ctx, `SELECT engine,COUNT(*) FROM database_engines WHERE present=1 GROUP BY engine`)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var v string
		var count int
		if err = rows.Scan(&v, &count); err != nil {
			break
		}
		if x := add(v); x != nil {
			x.EngineCount += count
		}
	}
	if err == nil {
		err = rows.Err()
	}
	rows.Close()
	if err != nil {
		return nil, err
	}
	rows, err = a.DB.QueryContext(ctx, `SELECT engine,COUNT(*) FROM database_instances WHERE present=1 GROUP BY engine`)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var v string
		var count int
		if err = rows.Scan(&v, &count); err != nil {
			break
		}
		if x := add(v); x != nil {
			x.InstanceCount += count
		}
	}
	if err == nil {
		err = rows.Err()
	}
	rows.Close()
	if err != nil {
		return nil, err
	}
	rows, err = a.DB.QueryContext(ctx, `SELECT engine_key,ignored FROM database_engine_exclusions`)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var key string
		var ignored bool
		if err = rows.Scan(&key, &ignored); err != nil {
			break
		}
		if x := add(key); x != nil {
			x.Ignored = ignored
		}
	}
	if err == nil {
		err = rows.Err()
	}
	rows.Close()
	if err != nil {
		return nil, err
	}
	out := make([]dbEngineVisibility, 0, len(byKey))
	for _, v := range byKey {
		out = append(out, *v)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Ignored != out[j].Ignored {
			return out[i].Ignored
		}
		return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name)
	})
	return out, nil
}

func (a *App) listDBEngineVisibility(w http.ResponseWriter, r *http.Request) {
	values, err := a.dbEngineVisibilityRows(r.Context())
	respond(w, values, err)
}

func (a *App) setDBEngineVisibility(w http.ResponseWriter, r *http.Request) {
	key := dbEngineKey(r.PathValue("engine"))
	if key == "" {
		badRequest(w, errors.New("invalid database engine"))
		return
	}
	var input struct {
		Ignored *bool `json:"ignored"`
	}
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	if input.Ignored == nil {
		badRequest(w, errors.New("ignored is required"))
		return
	}
	// Limit changes to engines actually collected or already configured.
	values, err := a.dbEngineVisibilityRows(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	found := false
	for _, v := range values {
		if v.Key == key {
			found = true
			break
		}
	}
	if !found {
		badRequest(w, errors.New("unknown database engine"))
		return
	}
	_, err = a.DB.ExecContext(r.Context(), `INSERT INTO database_engine_exclusions(engine_key,ignored) VALUES(?,?) ON DUPLICATE KEY UPDATE ignored=VALUES(ignored)`, key, *input.Ignored)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "database.engine.visibility.update", "database_engine", key, "success", map[string]any{"ignored": *input.Ignored})
	respond(w, map[string]any{"key": key, "ignored": *input.Ignored}, nil)
}
