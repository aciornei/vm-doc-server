# Upgrade VM-DOC Server 0.21.58 → 0.21.59

1. Verificați că serverul de pornire este **0.21.58**, că dispuneți de backup restaurabil MariaDB și că păstrați binarul + sursele precedente.
2. Aplicați **ori** update-ul `vm-doc-server-0.21.59-update.tar.gz` **ori** patch-ul `0.21.58-to-0.21.59.patch`, nu ambele. Pe serverul offline, păstrați directorul existent `vendor/`.
3. În staging, rulați `GOPROXY=off GOSUMDB=off go test ./internal/inventorychanges ./internal/domain ./openapi ./web` și `GOPROXY=off go test ./...`, apoi `make build`; instalați binarul numai după verificarea versiunii.
4. Testați un inventory nou cu guard `iptables raw/PREROUTING` în două variante `br-<12hex>` și confirmați că nu mai există `removed/added` în `inventory_changes`. Alte reguli trebuie să rămână urmărite.
5. Pentru curățarea istorică folosiți **numai** `scripts/preview-iptables-raw-docker-02159.sql`, apoi opriți VM-DOC și rulați **manual**, după verificări și backup, `scripts/cleanup-iptables-raw-docker-02159.sql`. Nu rulați cleanupul cumulativ pentru problema curentă.
6. Repoziționați aplicația și urmăriți evenimentele noi 2–3 zile.

**Rollback server:** restaurați binarul/sursele 0.21.58. **Rollback DELETE SQL:** doar din backup. Nu există migrare SQL automată sau update de agent (1.7.18).
