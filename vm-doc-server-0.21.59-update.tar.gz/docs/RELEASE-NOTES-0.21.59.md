# VM-DOC Server 0.21.59 — Docker iptables raw/PREROUTING

**Bază:** Server 0.21.58, Agent 1.7.18 neschimbat.

- Fix `inventory_changes`: reguli de izolare Docker `iptables` în `raw/PREROUTING` de tip `-A PREROUTING -d 172.18.0.7/32 ! -i br-<12hex> -j DROP` ignorate la generarea evenimentelor.
- Verificări restrictive pe backend=iptables, family=ipv4, table=raw, chain=PREROUTING, IP privat valid, /32, br-12hex și acțiune DROP fără opțiuni suplimentare.
- nftables, reguli administrate explicit, DOCKER-USER, firewall generic și inventarele brute NU sunt eliminate.
- SQL țintit PREVIEW/CLEANUP pentru evenimentele istorice, cu protecția reviziilor, deciziilor și observațiilor manuale; executare numai după backup+staging, manual.
- Fără migrare de schemă, modificări API/Swagger funcțional sau agent.
- Build Go complet (`vendor/`) și SQL/MariaDB live: **neverificate**, necesare în mediul offline înainte de PROD.
