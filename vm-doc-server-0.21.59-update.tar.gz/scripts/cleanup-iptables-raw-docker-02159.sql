-- VM-DOC 0.21.59 | Docker iptables raw/PREROUTING bridge guards.
-- Numai forma confirmata: -A PREROUTING -d IPv4-privat/32 ! -i br-<12hex> -j DROP.
-- NU elimina nftables, alte iptables, porturi, conturi, snapshoturi brute sau reguli de administrare.
-- Pastreaza review-urile, deciziile si notele manuale; nu modifica istoricul de audit separat.
-- Intai backup RESTAURABIL si testare MariaDB STAGING; ruleaza PREVIEW inainte de CLEANUP.
-- Nu folositi CLEANUP cumulativ pentru aceasta problema daca doriti strict regulile iptables.

-- Opreste serviciul vm-doc-server si reconfirma COUNT din PREVIEW.
START TRANSACTION;
DELETE c FROM inventory_changes c WHERE
  c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')=''
  AND c.category='firewall' AND c.object_type='rule'
  AND c.change_type IN ('added','removed')
  AND c.object_key LIKE 'firewall|rule|iptables|ipv4|raw|PREROUTING|%'
  AND JSON_VALID(COALESCE(c.new_json,c.old_json))
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.backend'))
      ELSE '' END = 'iptables'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.family'))
      ELSE '' END = 'ipv4'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.table'))
      ELSE '' END = 'raw'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.chain'))
      ELSE '' END = 'PREROUTING'
  AND TRIM(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule'))
      ELSE '' END)
      REGEXP '^-A PREROUTING -d (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}|172[.](1[6-9]|2[0-9]|3[01])[.][0-9]{1,3}[.][0-9]{1,3}|192[.]168[.][0-9]{1,3}[.][0-9]{1,3})/32 ! -i br-[0-9a-fA-F]{12} -j DROP$';
SELECT ROW_COUNT() AS sterse_iptables_raw_docker;
COMMIT;
SELECT COUNT(*) AS inventory_changes_ramase FROM inventory_changes;
-- Rollback pentru stergere se face numai prin RESTORE din backup.
