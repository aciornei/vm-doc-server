-- VM-DOC 0.21.59 | Docker iptables raw/PREROUTING bridge guards.
-- Numai forma confirmata: -A PREROUTING -d IPv4-privat/32 ! -i br-<12hex> -j DROP.
-- NU elimina nftables, alte iptables, porturi, conturi, snapshoturi brute sau reguli de administrare.
-- Pastreaza review-urile, deciziile si notele manuale; nu modifica istoricul de audit separat.
-- Intai backup RESTAURABIL si testare MariaDB STAGING; ruleaza PREVIEW inainte de CLEANUP.
-- Nu folositi CLEANUP cumulativ pentru aceasta problema daca doriti strict regulile iptables.

SELECT DATABASE() AS baza_curenta;
SELECT COUNT(*) AS candidati_iptables_raw_docker FROM inventory_changes c WHERE
  c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')=''
  AND c.category='firewall' AND c.object_type='rule'
  AND c.change_type IN ('added','removed')
  AND c.object_key LIKE 'firewall|rule|iptables|ipv4|raw|PREROUTING|%'
  AND JSON_VALID(COALESCE(c.new_json,c.old_json))
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.backend'))
      ELSE '' END = 'iptables'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.family'))
      ELSE '' END = 'ipv4'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.table'))
      ELSE '' END = 'raw'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.chain'))
      ELSE '' END = 'PREROUTING'
  AND TRIM(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule'))
      ELSE '' END)
      REGEXP '^-A PREROUTING -d (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}|172[.](1[6-9]|2[0-9]|3[01])[.][0-9]{1,3}[.][0-9]{1,3}|192[.]168[.][0-9]{1,3}[.][0-9]{1,3})/32 ! -i br-[0-9a-fA-F]{12} -j DROP$';

SELECT c.vm_id, c.change_type, COUNT(*) AS candidat_pe_vm
FROM inventory_changes c
WHERE c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')=''
  AND c.category='firewall' AND c.object_type='rule'
  AND c.change_type IN ('added','removed')
  AND c.object_key LIKE 'firewall|rule|iptables|ipv4|raw|PREROUTING|%'
  AND JSON_VALID(COALESCE(c.new_json,c.old_json))
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.backend'))
      ELSE '' END = 'iptables'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.family'))
      ELSE '' END = 'ipv4'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.table'))
      ELSE '' END = 'raw'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.chain'))
      ELSE '' END = 'PREROUTING'
  AND TRIM(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule'))
      ELSE '' END)
      REGEXP '^-A PREROUTING -d (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}|172[.](1[6-9]|2[0-9]|3[01])[.][0-9]{1,3}[.][0-9]{1,3}|192[.]168[.][0-9]{1,3}[.][0-9]{1,3})/32 ! -i br-[0-9a-fA-F]{12} -j DROP$'
GROUP BY c.vm_id,c.change_type ORDER BY candidat_pe_vm DESC LIMIT 50;

SELECT c.id,c.vm_id,c.occurred_at,c.change_type,c.object_label,c.object_key,
JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule')) AS rule_text
FROM inventory_changes c WHERE c.review_status='new'
  AND c.documentation_requirement='unset'
  AND c.reviewed_at IS NULL
  AND COALESCE(TRIM(c.notes),'')=''
  AND c.category='firewall' AND c.object_type='rule'
  AND c.change_type IN ('added','removed')
  AND c.object_key LIKE 'firewall|rule|iptables|ipv4|raw|PREROUTING|%'
  AND JSON_VALID(COALESCE(c.new_json,c.old_json))
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.backend'))
      ELSE '' END = 'iptables'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.family'))
      ELSE '' END = 'ipv4'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.table'))
      ELSE '' END = 'raw'
  AND CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.chain'))
      ELSE '' END = 'PREROUTING'
  AND TRIM(CASE WHEN JSON_VALID(COALESCE(c.new_json,c.old_json))
      THEN JSON_UNQUOTE(JSON_EXTRACT(COALESCE(c.new_json,c.old_json),'$.rule'))
      ELSE '' END)
      REGEXP '^-A PREROUTING -d (10[.]([0-9]{1,3}[.]){2}[0-9]{1,3}|172[.](1[6-9]|2[0-9]|3[01])[.][0-9]{1,3}[.][0-9]{1,3}|192[.]168[.][0-9]{1,3}[.][0-9]{1,3})/32 ! -i br-[0-9a-fA-F]{12} -j DROP$'
ORDER BY c.occurred_at DESC,c.id DESC LIMIT 40;

-- Toate evenimentele pentru aceasta familie, inclusiv cele PROTEJATE de review:
SELECT c.review_status,c.documentation_requirement,COUNT(*) AS total
FROM inventory_changes c WHERE c.category='firewall' AND c.object_type='rule'
AND c.object_key LIKE 'firewall|rule|iptables|ipv4|raw|PREROUTING|%'
AND c.object_key LIKE '%br-%' GROUP BY c.review_status,c.documentation_requirement;
