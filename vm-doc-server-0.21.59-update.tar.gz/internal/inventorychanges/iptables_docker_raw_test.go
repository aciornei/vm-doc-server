package inventorychanges

import (
	"encoding/json"
	"strings"
	"testing"
)

func iptablesDockerRawRule(ip, bridge string) map[string]any {
	return map[string]any{
		"backend": "iptables", "family": "ipv4", "table": "raw", "chain": "PREROUTING",
		"action": "DROP", "rule": "-A PREROUTING -d " + ip + "/32 ! -i " + bridge + " -j DROP",
	}
}

func TestDockerIptablesRawGuardSuppressed(t *testing.T) {
	for _, ip := range []string{"172.18.0.7", "172.18.0.6", "10.2.3.4", "192.168.1.2"} {
		for _, bridge := range []string{"br-f392b3fbdb12", "br-87894e600741"} {
			rule := iptablesDockerRawRule(ip, bridge)
			if !isGeneratedFirewallRule(rule) {
				t.Fatalf("generated iptables Docker guard not suppressed: %v", rule)
			}
		}
	}
}

func TestDockerIptablesRawGuardDoesNotHideAdminRules(t *testing.T) {
	cases := []struct {
		name   string
		mutate func(map[string]any)
	}{
		{"public address", func(r map[string]any) { r["rule"] = "-A PREROUTING -d 8.8.8.8/32 ! -i br-f392b3fbdb12 -j DROP" }},
		{"non-host destination", func(r map[string]any) { r["rule"] = "-A PREROUTING -d 172.18.0.0/24 ! -i br-f392b3fbdb12 -j DROP" }},
		{"manually named bridge", func(r map[string]any) { r["rule"] = "-A PREROUTING -d 172.18.0.7/32 ! -i br-production -j DROP" }},
		{"other action", func(r map[string]any) { r["rule"] = "-A PREROUTING -d 172.18.0.7/32 ! -i br-f392b3fbdb12 -j ACCEPT" }},
		{"extra condition", func(r map[string]any) {
			r["rule"] = "-A PREROUTING -d 172.18.0.7/32 ! -i br-f392b3fbdb12 -p tcp -j DROP"
		}},
		{"filter table", func(r map[string]any) { r["table"] = "filter" }},
		{"nat table", func(r map[string]any) { r["table"] = "nat" }},
		{"different chain", func(r map[string]any) { r["chain"] = "INPUT" }},
		{"Docker user", func(r map[string]any) { r["chain"] = "DOCKER-USER" }},
		{"nftables backend", func(r map[string]any) { r["backend"] = "nftables" }},
		{"ipv6", func(r map[string]any) { r["family"] = "ipv6" }},
		{"invalid IP", func(r map[string]any) { r["rule"] = "-A PREROUTING -d 172.18.0.999/32 ! -i br-f392b3fbdb12 -j DROP" }},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			r := iptablesDockerRawRule("172.18.0.7", "br-f392b3fbdb12")
			tc.mutate(r)
			if isGeneratedFirewallRule(r) {
				t.Fatalf("wrongly suppressed rule: %v", r)
			}
		})
	}
}

func TestDockerIptablesRawBridgeRotationDoesNotGenerateChanges(t *testing.T) {
	inv := func(bridge string) []byte {
		fw := map[string]any{"rules": []any{iptablesDockerRawRule("172.18.0.7", bridge),
			map[string]any{"backend": "iptables", "family": "ipv4", "table": "filter", "chain": "INPUT", "action": "ACCEPT", "rule": "-A INPUT -p tcp --dport 443 -j ACCEPT"},
		}}
		raw, _ := json.Marshal(map[string]any{"firewall": fw})
		return raw
	}
	a, err := extractTracked(inv("br-f392b3fbdb12"))
	if err != nil {
		t.Fatal(err)
	}
	b, err := extractTracked(inv("br-87894e600741"))
	if err != nil {
		t.Fatal(err)
	}
	if len(a) != 2 || len(b) != 2 {
		t.Fatalf("tracked counts %d/%d: %v %v", len(a), len(b), a, b)
	}
	for k, v := range a {
		if strings.Contains(k, "br-") {
			t.Fatalf("unstable Docker bridge tracked: %s", k)
		}
		vv, ok := b[k]
		if !ok || !canonicalEqual(v.Value, vv.Value) {
			t.Fatalf("changed tracked entry: %s", k)
		}
	}
}
