# Upgrade vm-doc-server 0.20.13 -> 0.20.14

Versiunea 0.20.14 nu introduce migrare SQL și nu necesită update de agent.

## Instalare

```bash
cd /usr/local/src
cp -a vm-doc-server-0.20.13 vm-doc-server-0.20.14

tar -xzf /cale/vm-doc-server-0.20.14-update.tar.gz \
  -C /usr/local/src/vm-doc-server-0.20.14

cd /usr/local/src/vm-doc-server-0.20.14
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Apoi instalați binarul conform procedurii curente și reporniți `vm-doc-server`.

## Verificări recomandate

1. Windows: marcați un element din Software instalat ca Principal. Procentul trebuie să considere criteriul `Software principal` și să nu mai ceară `Serviciu software principal`.
2. Linux: fără serviciu intern asociat și fără serviciu/daemon Principal, fișa trebuie să indice criteriile lipsă; după selectare procentul trebuie să crească.
3. VM cu baseline: cardul de sus trebuie să afișeze Baseline = Da.
4. Inventar VM: filtrați Baseline Da/Nu și verificați că exportul Excel păstrează același filtru.
5. Export Excel: verificați coloana nouă `Baseline`.

## Compatibilitate

- DB: neschimbată; folosește tabela existentă `inventory_change_baselines`.
- Agent: neschimbat.
