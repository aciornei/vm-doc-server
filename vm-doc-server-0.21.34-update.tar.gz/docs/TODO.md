# VM-DOC — TODO / backlog

> Actualizat: 2026-10-15, după VM-DOC Server 0.21.34. Acest fișier păstrează funcționalitățile **amânate**, nu descrie funcții implementate.

## Amânate explicit — reluăm după maturizarea aplicației

### 1. Integrare Wazuh prin API — AMÂNAT

- Scop: Wazuh ca sursă externă pentru Security Configuration Assessment (SCA), politici CIS-referenced și ulterior vulnerabilități.
- VM-DOC rămâne proprietarul inventarului de VM/servicii/beneficiari și al rapoartelor de impact; nu devine scanner de securitate complet.
- Corelare agenți Wazuh cu VM-DOC prin ID legat persistent, FQDN/hostname/IP cu rezolvare manuală a ambiguităților.
- API read-only pentru agenți, politici și rezultate SCA; sincronizare programată, stare sursă, erori/timeout, paginare, export și Swagger.
- Autentificare cu permisiuni minime, TLS verificat și secrete ținute numai în server (niciodată în exporturi, Outline sau documente).
- Raportarea distinge explicit **Wazuh SCA** de **VM-DOC Baseline**. Scorurile nu se adună ca și cum ar folosi același set de reguli.
- Fază separată pentru vulnerabilități/CVE și impact pe VM, servicii și departamente.
- **Nu se implementează acum.** Hardening-ul existent rămâne baseline pentru VM-uri fără agent Wazuh, inclusiv legacy. Șabloanele draft Apache/Nginx/DB rămân pentru viitor, fără pretenție de conformitate CIS completă.

### 2. Consolă shell SSH din fișa VM, chei prin Vault — AMÂNAT

- Scop: sesiune SSH interactivă către VM din interfața VM-DOC, folosind credențiale/chei gestionate în Vault.
- Design obligatoriu înainte de implementare: RBAC separat, permisiuni pe VM/mediu, MFA/reautentificare după caz, aprobare pentru acces privilegiat.
- Sesiuni proxy prin backend controlat; nici cheia SSH, nici tokenul Vault nu sunt expuse browserului, jurnalelor sau documentației exportate.
- Audit sesiune (cine, VM, timp, acțiuni și rezultat), limite de timp, revocare, izolare, rate-limit; gestiunea înregistrării sesiunii după politica de confidențialitate.
- Verificări anti-SSRF/host-key și control destinație; nu permite comenzi arbitrare prin funcția obișnuită de colectare agent.
- **Nu se implementează acum.** Necesită model de securitate, review și test de intruziune înainte de activare PROD.

## Următoarea direcție activă

1. [ ] Verifică vizual în staging **Securitate 0.21.34**, cu date reale: Dashboard, Conturi VM (politică parole și conturi system colapsabile fără checkbox, popup review), Database Access (revizii pe principal DB), Web ACL, Firewall/Caută, Surse & Sync, Analiză și Hardening. Verifică panourile la 1595/1024/390 px, selecțiile active, review-urile și resetarea filtrelor.
2. [ ] Testează în staging salvarea și raportarea review-urilor DB per principal: utilizatori omonimi pe instanțe diferite, user@host, reconciliere după colectare, date istorice de review pe instanță; verifică lipsa modificărilor de review ale conturilor system.
3. [ ] Confirmă `go test ./...` și `make build` cu `vendor/` pe serverul offline; optimizează eventualele ecrane lente pe date MariaDB reale.
4. [ ] Confirmă migrarea 078 și beneficiarii Compose, precum și afișarea beneficiarilor DB agregați; nu modifica retrospectiv asocierile existente.
5. [ ] Păstrează backlogurile Wazuh și Shell SSH prin Vault amânate până la maturizarea aplicației și aprobarea măsurilor de securitate.

- [ ] Validează în staging formularul popup de revizie pentru cont relevant, principal DB, Web ACL și Firewall: revizor/date server-side, precompletare, anulare, drepturi RBAC, afișare Next review și tratarea erorilor API.

- [ ] Validează UI 0.21.34: trei coloane Revizuit/De/Next review la Conturi VM (inclusiv system), DB principals, Web ACL, Firewall; data+ora pe un rând, rândurile nerevizuite colspan=3 și nume VM/cont corecte în popup. Testează salvarea cu RBAC și MariaDB real.
