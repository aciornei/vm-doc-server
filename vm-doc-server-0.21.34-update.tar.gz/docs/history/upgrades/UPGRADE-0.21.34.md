# VM-DOC Server 0.21.34 — 2026-10-15

## Scop

UI Securitate: trei coloane Revizuit / De / Next review în locul coloanei Review; data+ora pe un rând, data reviziei verde; nerevizuitele au doar butonul Revizuiește în celulă `colspan=3`. Dialogul arată numele VM și contul/resursa selectată. Filtrele, paginarea, drepturile, reviziile istorice și API-ul existente rămân.

## Compatibilitate

- Upgrade strict **0.21.33 → 0.21.34**; nu aplica peste versiuni mai vechi fără pașii intermediari.
- Agent modern **1.7.18**, XP/Windows legacy/SLES9 neschimbate.
- **Nu există migrare SQL nouă**, schimbare de model/rută API ori dependență Go nouă. OpenAPI are actualizată numai versiunea.
- `vendor/` nu se află în aceste arhive (nici în pachetul 0.21.33). Păstrează `vendor/` existent și folosește build offline.
- Nu sunt incluse binare Go precompilate. Recompilarea serverului/collectorului cu vendor-ul disponibil rămâne necesară.

## Upgrade recomandat (offline)

1. Salvează binarul 0.21.33, sursele curente, configurația și backup MariaDB.
2. Lucrează pe o copie a surselor serverului **0.21.33**. Pentru update incremental, în rădăcina **copiei**, extrage `vm-doc-server-0.21.34-update.tar.gz`; suprascrie numai fișierele din update, nu `vendor/`/`configs/`.
3. Verifică `cat VERSION` = `0.21.34` și `bash scripts/cleanup-source-tree.sh --check`.
4. În rețeaua offline, cu `vendor/` original: `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și `GOPROXY=off GOFLAGS=-mod=vendor make build`.
5. După build și teste pe staging, instalează binarul conform procedurii proprii, repornește serviciul și dă `Ctrl+F5` în browser.
6. Testează Conturi VM (relevante și system), DB principals, Web ACL, Firewall, rapoarte și popup-ul de review; validează drepturile și salvarea reală.

Alternativ: extrage `vm-doc-server-0.21.34-source.zip` într-un director nou și transferă directorul `vendor/` și configurația necesară într-o copie de build **fără** a modifica sursele vechi.

## Rollback

Oprește serviciul; restaurează binarul și sursele 0.21.33, repornește. Nu există migrare SQL nouă de anulat și nu trebuie schimbat agentul. Păstrează backup-ul DB pentru orice intervenție operațională.

## Validări și limite

- `node --check web/static/js/app.js` — OK.
- Go: pachete `openapi`, `web`, `internal/buildinfo`, `internal/domain`, `internal/xlsx`, `migrations` — OK folosind `GOPROXY=off GOFLAGS=-mod=mod` pentru subsetul fără dependențe externe.
- Chromium/Playwright la 1595/1024/390: antetele, 3 coloane, `colspan=3` și popup VM + cont — OK cu date simulate.
- **Nevalidate local:** `go test ./...` și `make build` cu `vendor/` complet, salvarea în MariaDB, UI conectată la datele reale.
