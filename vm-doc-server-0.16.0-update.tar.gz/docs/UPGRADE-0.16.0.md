# Upgrade vm-doc-server 0.15.0 → 0.16.0

Versiunea 0.16.0 introduce inventarul Web structurat pentru Nginx, Apache HTTP Server și HAProxy, plus îmbunătățiri de interfață și documente DOCX.

## 1. Backup

Faceți backup bazei de date și al directorului aplicației.

## 2. Actualizare surse

Aplicați `vm-doc-server-0.16.0-update.tar.gz` peste sursa 0.15.0 sau patch-ul `vm-doc-server-0.15.0-to-0.16.0.patch`.

## 3. Compilare

```bash
go build -o vm-doc-server ./cmd/vm-doc-server
```

Înlocuiți binarul folosit de systemd și reporniți `vm-doc-server`.

## 4. Migrare DB

La pornire se aplică `031_web_inventory.up.sql`. Verificați existența tabelelor `web_hosts`, `web_servers`, `web_sites` și `web_site_service_assignments`.

## 5. Agent

Pentru inventarul Web este necesar `vm-doc-agent 1.6.0`. Upgrade-ul de la 1.5.0 migrează aditiv `config.json` și adaugă `collectors.web=true`, `max_web_servers` și `max_web_sites`, păstrând valorile existente.

După upgrade-ul agentului, forțați o colectare. În fila **Web** a VM-ului trebuie să apară Nginx/Apache/HAProxy detectat și site-urile/frontends găsite în configurațiile locale.

## 6. Asocieri servicii

Pe un host Web partajat, asocierea VM → serviciu nu decide apartenența site-urilor. Asociați fiecare site/virtual host/frontend unuia sau mai multor servicii din fila **Web**.

## 7. Fișe DOCX

Capitolele Docker, Baze de date și Web sunt incluse numai dacă VM-ul are date relevante. Numerotarea capitolelor și a subsecțiunilor Inventar agent este recalculată automat.
