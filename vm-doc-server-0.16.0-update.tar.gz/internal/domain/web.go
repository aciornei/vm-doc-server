package domain

import "time"

type WebHostSummary struct {
	VMID               int64      `json:"vm_id"`
	CurrentInventoryID *int64     `json:"current_inventory_id,omitempty"`
	ServerCount        int        `json:"server_count"`
	SiteCount          int        `json:"site_count"`
	ObservedAt         *time.Time `json:"observed_at,omitempty"`
}

type WebBinding struct {
	Address  string `json:"address,omitempty"`
	Port     uint16 `json:"port,omitempty"`
	Protocol string `json:"protocol,omitempty"`
	TLS      bool   `json:"tls"`
	Wildcard bool   `json:"wildcard,omitempty"`
}

type WebServer struct {
	ID               int64    `json:"id"`
	VMID             int64    `json:"vm_id"`
	Engine           string   `json:"engine"`
	Product          string   `json:"product"`
	Installed        bool     `json:"installed"`
	Version          string   `json:"version,omitempty"`
	Executable       string   `json:"executable,omitempty"`
	ServiceName      string   `json:"service_name,omitempty"`
	Status           string   `json:"status,omitempty"`
	ConfigFiles      []string `json:"config_files,omitempty"`
	DetectionSources []string `json:"detection_sources,omitempty"`
}

type WebServiceAssignment struct {
	ID            int64  `json:"id"`
	ServiceID     int64  `json:"service_id"`
	ServiceName   string `json:"service_name"`
	ServiceCode   string `json:"service_code,omitempty"`
	ComponentName string `json:"component_name,omitempty"`
	RoleName      string `json:"role_name,omitempty"`
	Notes         string `json:"notes,omitempty"`
}

type WebSite struct {
	ID                 int64                  `json:"id"`
	VMID               int64                  `json:"vm_id"`
	VMName             string                 `json:"vm_name,omitempty"`
	VMHostname         string                 `json:"vm_hostname,omitempty"`
	IdentityKey        string                 `json:"identity_key"`
	Engine             string                 `json:"engine"`
	Product            string                 `json:"product"`
	SiteType           string                 `json:"site_type"`
	Name               string                 `json:"name"`
	ServerNames        []string               `json:"server_names,omitempty"`
	Bindings           []WebBinding           `json:"bindings,omitempty"`
	DocumentRoot       string                 `json:"document_root,omitempty"`
	ProxyTargets       []string               `json:"proxy_targets,omitempty"`
	Backends           []string               `json:"backends,omitempty"`
	Mode               string                 `json:"mode,omitempty"`
	ConfigFile         string                 `json:"config_file,omitempty"`
	Enabled            bool                   `json:"enabled"`
	Default            bool                   `json:"default,omitempty"`
	DetectionSources   []string               `json:"detection_sources,omitempty"`
	Present            bool                   `json:"present"`
	ServiceAssignments []WebServiceAssignment `json:"service_assignments,omitempty"`
}

type WebVMView struct {
	Host    *WebHostSummary `json:"host,omitempty"`
	Servers []WebServer     `json:"servers"`
	Sites   []WebSite       `json:"sites"`
}
