package main

import (
	"context"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"vm-doc-server/internal/agentclient"
	"vm-doc-server/internal/agents"
	"vm-doc-server/internal/agentupdates"
	"vm-doc-server/internal/audit"
	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/buildinfo"
	"vm-doc-server/internal/catalog"
	"vm-doc-server/internal/collection"
	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/database"
	"vm-doc-server/internal/databaseinventory"
	"vm-doc-server/internal/directory"
	"vm-doc-server/internal/dockerinventory"
	"vm-doc-server/internal/documents"
	"vm-doc-server/internal/external"
	"vm-doc-server/internal/inventory"
	"vm-doc-server/internal/nomenclature"
	"vm-doc-server/internal/registration"
	"vm-doc-server/internal/secrets"
	"vm-doc-server/internal/server"
	"vm-doc-server/internal/vcenter"
	"vm-doc-server/internal/webinventory"
	"vm-doc-server/migrations"
)

func main() {
	configPath := flag.String("config", "/etc/vm-doc-server/config.yaml", "configuration file")
	flag.Parse()
	cfg, err := config.Load(*configPath)
	if err != nil {
		fatal("load configuration", err)
	}
	logger := newLogger(cfg.Logging)
	master, err := cryptox.LoadMasterKey(cfg.Secrets.MasterKeyFile, cfg.Secrets.MasterKeyEnv)
	if err != nil {
		fatal("load master key", err)
	}
	box, err := cryptox.New(master)
	if err != nil {
		fatal("initialize encryption", err)
	}
	secretValues, err := secrets.Load(cfg.Secrets, box)
	if err != nil {
		fatal("load secrets", err)
	}
	db, err := database.Open(cfg.Database, secretValues.DatabasePassword)
	if err != nil {
		fatal("open database", err)
	}
	defer db.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	if err := database.Migrate(ctx, db, migrations.Files); err != nil {
		cancel()
		fatal("database migrations", err)
	}
	cancel()
	appCtx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	auditSvc := audit.Service{DB: db}
	authSvc, err := auth.New(appCtx, db, cfg, secretValues, auditSvc)
	if err != nil {
		fatal("initialize authentication", err)
	}
	agentClient, err := agentclient.New(cfg.Collector.AllowedNetworks, cfg.Collector.MaxInventorySize)
	if err != nil {
		fatal("initialize agent client", err)
	}
	agentSvc := agents.Service{DB: db, Box: box, Config: cfg.Collector}
	dockerSvc := dockerinventory.Service{DB: db}
	databaseSvc := databaseinventory.Service{DB: db}
	webSvc := webinventory.Service{DB: db}
	invSvc := inventory.Service{DB: db, Docker: &dockerSvc, Databases: &databaseSvc, Web: &webSvc}
	var agentUpdateSvc *agentupdates.Service
	if cfg.AgentUpdates.Enabled {
		svc := &agentupdates.Service{Directory: cfg.AgentUpdates.Directory}
		if err := svc.Validate(); err != nil {
			fatal("initialize agent update repository", err)
		}
		agentUpdateSvc = svc
	}
	var registrationSvc *registration.Service
	if cfg.AgentRegistration.Enabled {
		registrationSvc = &registration.Service{
			DB: db, Box: box, Inventory: invSvc, Token: secretValues.AgentRegistrationToken,
			AllowHTTPAgents:           cfg.Collector.AllowHTTP,
			DefaultCollectionInterval: cfg.Collector.DefaultCollectionInterval.Value(),
			DefaultRequestTimeout:     cfg.Collector.DefaultRequestTimeout.Value(),
			DefaultOfflineAfter:       cfg.Collector.DefaultOfflineAfter.Value(),
			AcceptedSchemaMajor:       cfg.Inventory.AcceptedSchemaMajor,
		}
		if err := registrationSvc.Validate(); err != nil {
			fatal("initialize agent registration", err)
		}
	}
	collectionSvc := collection.New(db, agentSvc, invSvc, auditSvc, agentClient, cfg, logger)
	vcenterSvc := vcenter.NewService(appCtx, db, box, cfg, logger)
	nomenclatureSvc := nomenclature.Service{DB: db}
	directorySvc := directory.Service{Config: cfg.Auth.LDAP, BindDN: secretValues.LDAPBindDN, BindPwd: secretValues.LDAPBindPassword}
	catalogSvc := catalog.Service{DB: db}
	documentSvc := documents.Service{DB: db}
	externalSvc := external.Service{DB: db}
	if err := documentSvc.EnsureDefault(appCtx); err != nil {
		fatal("initialize default document template", err)
	}
	go vcenterSvc.RunScheduler(appCtx)
	go runInventoryRetention(appCtx, invSvc, cfg.Inventory, logger)
	app := &server.App{Config: cfg, DB: db, Auth: authSvc, Agents: agentSvc, AgentUpdates: agentUpdateSvc, Collection: collectionSvc, Inventory: invSvc, VCenter: vcenterSvc, Nomenclatures: nomenclatureSvc, Directory: directorySvc, Documents: documentSvc, Catalog: catalogSvc, Docker: dockerSvc, Databases: databaseSvc, Web: webSvc, External: externalSvc, Registration: registrationSvc, Audit: auditSvc, Logger: logger, Version: buildinfo.Version}
	handler, err := app.Handler()
	if err != nil {
		fatal("build HTTP handler", err)
	}
	httpServer := &http.Server{Addr: cfg.Server.Listen, Handler: handler, ReadHeaderTimeout: cfg.Server.ReadHeaderTimeout.Value(), ReadTimeout: cfg.Server.ReadTimeout.Value(), WriteTimeout: cfg.Server.WriteTimeout.Value(), IdleTimeout: cfg.Server.IdleTimeout.Value()}
	go func() {
		logger.Info("vm-doc-server started", "version", buildinfo.Version, "listen", cfg.Server.Listen)
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			fatal("HTTP server", err)
		}
	}()
	<-appCtx.Done()
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer shutdownCancel()
	if err := httpServer.Shutdown(shutdownCtx); err != nil {
		logger.Error("HTTP shutdown", "error", err)
	}
	vcenterSvc.Wait()
	logger.Info("vm-doc-server stopped")
}

func runInventoryRetention(ctx context.Context, svc inventory.Service, cfg config.InventoryConfig, logger *slog.Logger) {
	run := func() {
		cleanupCtx, cancel := context.WithTimeout(ctx, 10*time.Minute)
		defer cancel()
		result, err := svc.CleanupRetention(cleanupCtx, cfg.RetainSnapshotsPerAgent, cfg.RetainDays)
		if err != nil {
			logger.Error("inventory retention cleanup failed", "error", err)
			return
		}
		logger.Info("inventory retention cleanup completed", "candidates", result.Candidates, "deleted", result.Deleted, "protected", result.Protected, "retain_per_agent", cfg.RetainSnapshotsPerAgent, "retain_days", cfg.RetainDays)
	}
	// Run shortly after startup so existing installations are cleaned without
	// waiting a full interval, then continue on the configured cadence.
	select {
	case <-ctx.Done():
		return
	case <-time.After(30 * time.Second):
		run()
	}
	ticker := time.NewTicker(cfg.CleanupInterval.Value())
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			run()
		}
	}
}

func newLogger(cfg config.LoggingConfig) *slog.Logger {
	level := slog.LevelInfo
	switch cfg.Level {
	case "debug":
		level = slog.LevelDebug
	case "warn":
		level = slog.LevelWarn
	case "error":
		level = slog.LevelError
	}
	opts := &slog.HandlerOptions{Level: level}
	if cfg.Format == "text" {
		return slog.New(slog.NewTextHandler(os.Stdout, opts))
	}
	return slog.New(slog.NewJSONHandler(os.Stdout, opts))
}
func fatal(message string, err error) { slog.Error(message, "error", err); os.Exit(1) }
