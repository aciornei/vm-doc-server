# Upgrade vm-doc-server 0.19.9 → 0.19.10

0.19.10 adaugă diagnosticul structurat pentru situațiile în care agentul detectează o instanță PostgreSQL/MySQL/MariaDB/MongoDB, dar nu poate enumera bazele fără credențiale.

## Pași

1. Aplicați update-ul server 0.19.10 peste sursa 0.19.9.
2. Compilați offline cu vendorul existent: `GOPROXY=off GOFLAGS=-mod=vendor go test ./...` și `GOPROXY=off GOFLAGS=-mod=vendor make build`.
3. Reporniți serverul; la pornire se aplică migrarea `043_database_catalog_discovery_reason.up.sql`.
4. Publicați vm-doc-agent 1.6.5 și actualizați serverele DB.
5. Forțați o colectare. În VM → Baze de date, instanțele cu `metadata only` vor afișa și motivul.

Agentul nu transmite stderr brut și nu stochează parole sau connection strings. Agenții mai vechi continuă să funcționeze; motivul va rămâne gol până la upgrade-ul agentului.
