-- 0.19.10 · motiv structurat pentru catalog discovery DB
ALTER TABLE database_instances
  ADD COLUMN catalog_discovery_reason VARCHAR(64) NOT NULL DEFAULT '' AFTER catalog_discovery_status;
