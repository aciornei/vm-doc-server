package domain

import "time"

type DatabaseHostSummary struct {
	VMID               int64      `json:"vm_id"`
	CurrentInventoryID *int64     `json:"current_inventory_id,omitempty"`
	EngineCount        int        `json:"engine_count"`
	InstanceCount      int        `json:"instance_count"`
	CatalogCount       int        `json:"catalog_count"`
	ObservedAt         *time.Time `json:"observed_at,omitempty"`
}

type DatabaseEngine struct {
	ID         int64    `json:"id"`
	VMID       int64    `json:"vm_id"`
	Engine     string   `json:"engine"`
	Product    string   `json:"product"`
	Installed  bool     `json:"installed"`
	Executable string   `json:"executable,omitempty"`
	Version    string   `json:"version,omitempty"`
	Sources    []string `json:"sources,omitempty"`
}

type DatabaseEndpoint struct {
	Protocol string `json:"protocol,omitempty"`
	Address  string `json:"address,omitempty"`
	Port     uint16 `json:"port,omitempty"`
	Wildcard bool   `json:"wildcard,omitempty"`
}

type DatabaseServiceAssignment struct {
	ID            int64  `json:"id"`
	ServiceID     int64  `json:"service_id"`
	ServiceName   string `json:"service_name"`
	ServiceCode   string `json:"service_code,omitempty"`
	ComponentName string `json:"component_name,omitempty"`
	RoleName      string `json:"role_name,omitempty"`
	Notes         string `json:"notes,omitempty"`
}

type DatabaseCatalog struct {
	ID                 int64                       `json:"id"`
	InstanceID         int64                       `json:"instance_id"`
	VMID               int64                       `json:"vm_id"`
	VMName             string                      `json:"vm_name,omitempty"`
	VMHostname         string                      `json:"vm_hostname,omitempty"`
	Engine             string                      `json:"engine,omitempty"`
	Product            string                      `json:"product,omitempty"`
	InstanceName       string                      `json:"instance_name,omitempty"`
	InstanceVersion    string                      `json:"instance_version,omitempty"`
	Name               string                      `json:"name"`
	Kind               string                      `json:"kind,omitempty"`
	System             bool                        `json:"system"`
	Present            bool                        `json:"present"`
	ServiceAssignments []DatabaseServiceAssignment `json:"service_assignments,omitempty"`
}

type DatabaseInstance struct {
	ID                     int64                       `json:"id"`
	VMID                   int64                       `json:"vm_id"`
	VMName                 string                      `json:"vm_name,omitempty"`
	VMHostname             string                      `json:"vm_hostname,omitempty"`
	IdentityKey            string                      `json:"identity_key"`
	Engine                 string                      `json:"engine"`
	Product                string                      `json:"product"`
	InstanceName           string                      `json:"instance_name,omitempty"`
	Version                string                      `json:"version,omitempty"`
	Edition                string                      `json:"edition,omitempty"`
	Status                 string                      `json:"status,omitempty"`
	ServiceName            string                      `json:"service_name,omitempty"`
	PID                    int                         `json:"pid,omitempty"`
	Executable             string                      `json:"executable,omitempty"`
	DataDir                string                      `json:"data_dir,omitempty"`
	ConfigFiles            []string                    `json:"config_files,omitempty"`
	Endpoints              []DatabaseEndpoint          `json:"endpoints,omitempty"`
	SocketPaths            []string                    `json:"socket_paths,omitempty"`
	CatalogDiscoveryStatus string                      `json:"catalog_discovery_status,omitempty"`
	CatalogDiscoveryReason string                      `json:"catalog_discovery_reason,omitempty"`
	DetectionSources       []string                    `json:"detection_sources,omitempty"`
	Present                bool                        `json:"present"`
	Catalogs               []DatabaseCatalog           `json:"catalogs,omitempty"`
	ServiceAssignments     []DatabaseServiceAssignment `json:"service_assignments,omitempty"`
}

type DatabaseVMView struct {
	Host      *DatabaseHostSummary `json:"host,omitempty"`
	Engines   []DatabaseEngine     `json:"engines"`
	Instances []DatabaseInstance   `json:"instances"`
}

type DatabaseServiceResource struct {
	ResourceType       string                      `json:"resource_type"` // database | instance
	VMID               int64                       `json:"vm_id"`
	VMName             string                      `json:"vm_name"`
	VMHostname         string                      `json:"vm_hostname,omitempty"`
	Engine             string                      `json:"engine"`
	Product            string                      `json:"product"`
	InstanceID         int64                       `json:"instance_id"`
	InstanceName       string                      `json:"instance_name,omitempty"`
	Version            string                      `json:"version,omitempty"`
	Status             string                      `json:"status,omitempty"`
	Endpoints          []DatabaseEndpoint          `json:"endpoints,omitempty"`
	CatalogID          int64                       `json:"catalog_id,omitempty"`
	DatabaseName       string                      `json:"database_name,omitempty"`
	DatabaseKind       string                      `json:"database_kind,omitempty"`
	System             bool                        `json:"system,omitempty"`
	ServiceAssignments []DatabaseServiceAssignment `json:"service_assignments,omitempty"`
}
