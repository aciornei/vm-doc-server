package inventorychanges

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"
)

type Service struct{ DB *sql.DB }

type Change struct {
	ID                       int64           `json:"id"`
	VMID                     int64           `json:"vm_id"`
	VMName                   string          `json:"vm_name"`
	VMHostname               string          `json:"vm_hostname,omitempty"`
	AgentID                  int64           `json:"agent_id"`
	PreviousInventoryID      *int64          `json:"previous_inventory_id,omitempty"`
	InventoryID              int64           `json:"inventory_id"`
	OccurredAt               time.Time       `json:"occurred_at"`
	Category                 string          `json:"category"`
	ObjectType               string          `json:"object_type"`
	ObjectKey                string          `json:"object_key"`
	ObjectLabel              string          `json:"object_label"`
	ChangeType               string          `json:"change_type"`
	Summary                  string          `json:"summary"`
	OldJSON                  json.RawMessage `json:"old_json,omitempty"`
	NewJSON                  json.RawMessage `json:"new_json,omitempty"`
	DocumentationRequirement string          `json:"documentation_requirement"`
	ReviewStatus             string          `json:"review_status"`
	Notes                    string          `json:"notes,omitempty"`
	ReviewedBy               *int64          `json:"reviewed_by,omitempty"`
	ReviewedAt               *time.Time      `json:"reviewed_at,omitempty"`
}

type Filter struct {
	VMID                     int64
	Query                    string
	Category                 string
	ChangeType               string
	DocumentationRequirement string
	ReviewStatus             string
	Page                     int
	PageSize                 int
}

type Page struct {
	Items         []Change `json:"items"`
	Page          int      `json:"page"`
	PageSize      int      `json:"page_size"`
	Total         int      `json:"total"`
	Pages         int      `json:"pages"`
	NewCount      int      `json:"new_count"`
	UnsetCount    int      `json:"unset_count"`
	RequiredCount int      `json:"required_count"`
}

type UpdateInput struct {
	DocumentationRequirement string `json:"documentation_requirement"`
	ReviewStatus             string `json:"review_status"`
	Notes                    string `json:"notes"`
}

type BaselineInput struct {
	VMID int64 `json:"vm_id,omitempty"`
}

type trackedObject struct {
	Category string
	Type     string
	Key      string
	Label    string
	Value    any
}

func (s Service) Capture(ctx context.Context, tx *sql.Tx, agentID, previousInventoryID, inventoryID int64, previousRaw, currentRaw []byte) (int64, error) {
	if previousInventoryID <= 0 || inventoryID <= 0 || len(previousRaw) == 0 || len(currentRaw) == 0 {
		return 0, nil
	}
	var vmID int64
	err := tx.QueryRowContext(ctx, `SELECT id FROM virtual_machines WHERE agent_id=? ORDER BY id LIMIT 1`, agentID).Scan(&vmID)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, nil
	}
	if err != nil {
		return 0, err
	}

	// The first inventory pair of a VM establishes a baseline automatically.
	// Existing installations are seeded by migration 033 with the current
	// snapshot, while new VMs use their first snapshot as the baseline.
	if _, err := tx.ExecContext(ctx, `INSERT IGNORE INTO inventory_change_baselines(vm_id,inventory_id,established_at,established_by,source) VALUES(?,?,UTC_TIMESTAMP(6),NULL,'automatic')`, vmID, previousInventoryID); err != nil {
		return 0, err
	}

	oldObjects, err := extractTracked(previousRaw)
	if err != nil {
		return 0, fmt.Errorf("extract previous inventory changes: %w", err)
	}
	newObjects, err := extractTracked(currentRaw)
	if err != nil {
		return 0, fmt.Errorf("extract current inventory changes: %w", err)
	}

	keys := make([]string, 0, len(oldObjects)+len(newObjects))
	seen := map[string]bool{}
	for k := range oldObjects {
		seen[k] = true
		keys = append(keys, k)
	}
	for k := range newObjects {
		if !seen[k] {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	var inserted int64
	now := time.Now().UTC()
	_ = tx.QueryRowContext(ctx, `SELECT received_at FROM inventory_snapshots WHERE id=?`, inventoryID).Scan(&now)
	for _, k := range keys {
		oldObj, hadOld := oldObjects[k]
		newObj, hasNew := newObjects[k]
		if hadOld && hasNew && canonicalEqual(oldObj.Value, newObj.Value) {
			continue
		}
		var typ, label, category, objectType string
		var oldJSON, newJSON []byte
		switch {
		case !hadOld && hasNew:
			typ, label, category, objectType = "added", newObj.Label, newObj.Category, newObj.Type
			newJSON, _ = json.Marshal(newObj.Value)
		case hadOld && !hasNew:
			typ, label, category, objectType = "removed", oldObj.Label, oldObj.Category, oldObj.Type
			oldJSON, _ = json.Marshal(oldObj.Value)
		default:
			typ, label, category, objectType = "modified", newObj.Label, newObj.Category, newObj.Type
			oldJSON, _ = json.Marshal(oldObj.Value)
			newJSON, _ = json.Marshal(newObj.Value)
		}
		summary := changeSummary(typ, label)
		hashInput := strings.Join([]string{strconv.FormatInt(vmID, 10), strconv.FormatInt(previousInventoryID, 10), strconv.FormatInt(inventoryID, 10), category, objectType, k, typ}, "\x00")
		h := sha256.Sum256([]byte(hashInput))
		changeHash := hex.EncodeToString(h[:])
		res, err := tx.ExecContext(ctx, `INSERT IGNORE INTO inventory_changes(vm_id,agent_id,previous_inventory_id,inventory_id,occurred_at,category,object_type,object_key,object_label,change_type,summary,old_json,new_json,change_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
			vmID, agentID, previousInventoryID, inventoryID, now, category, objectType, k, label, typ, summary, nullableJSON(oldJSON), nullableJSON(newJSON), changeHash)
		if err != nil {
			return inserted, err
		}
		n, _ := res.RowsAffected()
		inserted += n
	}
	return inserted, nil
}

func nullableJSON(v []byte) any {
	if len(v) == 0 {
		return nil
	}
	return string(v)
}

func changeSummary(changeType, label string) string {
	switch changeType {
	case "added":
		return label + " a apărut în inventar"
	case "removed":
		return label + " nu mai apare în inventar"
	default:
		return label + " s-a modificat"
	}
}

func canonicalEqual(a, b any) bool {
	aa, _ := json.Marshal(a)
	bb, _ := json.Marshal(b)
	return string(aa) == string(bb)
}

func extractTracked(raw []byte) (map[string]trackedObject, error) {
	dec := json.NewDecoder(strings.NewReader(string(raw)))
	dec.UseNumber()
	var root map[string]any
	if err := dec.Decode(&root); err != nil {
		return nil, err
	}
	out := map[string]trackedObject{}
	add := func(o trackedObject) {
		if strings.TrimSpace(o.Key) == "" {
			return
		}
		out[o.Category+"|"+o.Type+"|"+o.Key] = o
	}

	// Host and OS: useful documentation fields; volatile uptime/collection metadata are deliberately ignored.
	if h := asMap(root["host"]); h != nil {
		add(trackedObject{"system", "host", "host", "Identitate / hardware VM", pick(h, "hostname", "fqdn", "product_name", "product_vendor", "serial_number", "virtualization")})
	}
	if os := asMap(root["os"]); os != nil {
		add(trackedObject{"system", "os", "os", "Sistem de operare", pick(os, "family", "name", "pretty_name", "version", "version_id", "kernel", "architecture", "init_system")})
	}
	if st := asMap(root["storage"]); st != nil {
		for _, v := range asSlice(st["partitions"]) {
			p := asMap(v)
			key := first(p, "mount_point", "device")
			if key == "" {
				continue
			}
			add(trackedObject{"storage", "partition", key, "Partiție " + key, pick(p, "device", "mount_point", "filesystem", "total_bytes", "read_only", "remote")})
		}
	}
	if nw := asMap(root["network"]); nw != nil {
		for _, v := range asSlice(nw["interfaces"]) {
			n := asMap(v)
			name := first(n, "name")
			if name == "" {
				continue
			}
			add(trackedObject{"network", "interface", name, "Interfață " + name, pick(n, "name", "mac", "mtu", "addresses")})
		}
		add(trackedObject{"network", "resolver", "resolver", "DNS / gateway", pick(nw, "default_gateways", "dns_servers", "search_domains")})
	}
	for _, v := range asSlice(root["services"]) {
		svc := asMap(v)
		name := first(svc, "name")
		if name == "" {
			continue
		}
		add(trackedObject{"services", "service", name, "Serviciu " + name, pick(svc, "name", "manager", "active_state", "sub_state", "enabled_state", "software_name", "version", "package_name", "package_version")})
	}
	for _, v := range asSlice(root["listening_ports"]) {
		p := asMap(v)
		proto := first(p, "protocol")
		port := numberText(p["port"])
		procs := asSlice(p["processes"])
		procNames := []string{}
		procExec := []string{}
		for _, pv := range procs {
			pm := asMap(pv)
			if x := first(pm, "name"); x != "" {
				procNames = append(procNames, x)
			}
			if x := first(pm, "executable"); x != "" {
				procExec = append(procExec, x)
			}
		}
		sort.Strings(procNames)
		sort.Strings(procExec)
		key := proto + "/" + port + "/" + strings.Join(procNames, ",")
		if port == "" {
			continue
		}
		add(trackedObject{"ports", "listening_port", key, "Port " + strings.ToUpper(proto) + "/" + port, map[string]any{"protocol": proto, "port": p["port"], "process_names": unique(procNames), "executables": unique(procExec)}})
	}
	if fw := asMap(root["firewall"]); fw != nil {
		add(trackedObject{"firewall", "firewall", "firewall", "Firewall", pick(fw, "detected", "active", "backends", "default_policies", "zones", "config_files")})
		for _, v := range asSlice(fw["rules"]) {
			r := asMap(v)
			rule := first(r, "rule")
			if rule == "" {
				continue
			}
			key := strings.Join([]string{first(r, "backend"), first(r, "family"), first(r, "table"), first(r, "chain"), rule}, "|")
			add(trackedObject{"firewall", "rule", key, "Regulă firewall " + short(rule, 90), pick(r, "backend", "family", "table", "chain", "action", "rule")})
		}
	}
	if acc := asMap(root["accounts"]); acc != nil {
		for _, v := range asSlice(acc["local_users"]) {
			u := asMap(v)
			username := first(u, "username")
			uid := numberText(u["uid"])
			key := uid
			if key == "" {
				key = username
			}
			if key == "" {
				continue
			}
			label := "Utilizator local " + username
			if uid != "" {
				label += " (UID " + uid + ")"
			}
			add(trackedObject{"accounts", "local_user", key, label, pick(u, "username", "uid", "gid", "gecos", "home", "shell", "system_account", "password_status", "password_locked", "account_expires_at")})
		}
	}
	if sssd := asMap(root["sssd"]); sssd != nil {
		add(trackedObject{"identity", "sssd", "sssd", "Integrare SSSD", pick(sssd, "installed", "version", "service_active", "service_enabled", "config_present", "config_valid", "services", "domains")})
	}
	if ints := asMap(root["integrations"]); ints != nil {
		for _, name := range []string{"glpi_agent", "node_exporter", "auditbeat", "filebeat", "syslog"} {
			if v := asMap(ints[name]); v != nil {
				add(trackedObject{"integrations", "integration", name, "Integrare " + name, pickAllWithout(v, map[string]bool{"last_error": true})})
			}
		}
	}
	if ntp := asMap(root["ntp"]); ntp != nil {
		add(trackedObject{"time", "ntp", "ntp", "Sincronizare timp", pickAllWithout(ntp, nil)})
	}

	if db := asMap(root["databases"]); db != nil {
		for _, v := range asSlice(db["instances"]) {
			inst := asMap(v)
			engine := first(inst, "engine")
			name := first(inst, "instance_name")
			dataDir := first(inst, "data_dir")
			ep := endpointKey(asSlice(inst["endpoints"]))
			key := strings.Join([]string{engine, name, dataDir, ep}, "|")
			if key == "|||" {
				continue
			}
			label := "Instanță DB " + strings.TrimSpace(strings.Join([]string{first(inst, "product"), name}, " "))
			add(trackedObject{"databases", "database_instance", key, label, pick(inst, "engine", "product", "instance_name", "version", "edition", "status", "service_name", "executable", "data_dir", "config_files", "endpoints", "socket_paths", "catalog_discovery_status", "catalog_discovery_reason")})
			for _, cv := range asSlice(inst["catalogs"]) {
				c := asMap(cv)
				cn := first(c, "name")
				if cn == "" {
					continue
				}
				ck := key + "|" + cn
				add(trackedObject{"databases", "database", ck, "Bază de date " + cn, map[string]any{"engine": engine, "instance": name, "name": cn, "kind": c["kind"], "system": c["system"]}})
			}
		}
	}
	if docker := asMap(root["docker"]); docker != nil {
		for _, v := range asSlice(docker["containers"]) {
			c := asMap(v)
			name := first(c, "name")
			project := first(c, "compose_project")
			service := first(c, "compose_service")
			key := strings.Join([]string{project, service, name}, "|")
			if name == "" {
				continue
			}
			add(trackedObject{"docker", "container", key, "Container Docker " + name, pick(c, "name", "image", "image_digest", "compose_project", "compose_service", "ports", "mounts", "networks", "hostname", "privileged", "network_mode", "readonly_rootfs", "docker_socket_mounted")})
		}
	}
	if web := asMap(root["web"]); web != nil {
		for _, v := range asSlice(web["sites"]) {
			site := asMap(v)
			engine := first(site, "engine")
			name := first(site, "name")
			cfg := first(site, "config_file")
			binds := endpointKey(asSlice(site["bindings"]))
			key := strings.Join([]string{engine, cfg, name, binds}, "|")
			if name == "" {
				continue
			}
			add(trackedObject{"web", "web_site", key, "Site / frontend " + name, pick(site, "engine", "product", "site_type", "name", "server_names", "bindings", "document_root", "proxy_targets", "backends", "mode", "config_file", "enabled", "default")})
		}
	}
	return out, nil
}

func asMap(v any) map[string]any { m, _ := v.(map[string]any); return m }
func asSlice(v any) []any        { a, _ := v.([]any); return a }
func first(m map[string]any, keys ...string) string {
	for _, k := range keys {
		if s, ok := m[k].(string); ok && strings.TrimSpace(s) != "" {
			return strings.TrimSpace(s)
		}
	}
	return ""
}
func numberText(v any) string {
	switch x := v.(type) {
	case json.Number:
		return x.String()
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	case int:
		return strconv.Itoa(x)
	case int64:
		return strconv.FormatInt(x, 10)
	case string:
		return strings.TrimSpace(x)
	}
	return ""
}
func pick(m map[string]any, keys ...string) map[string]any {
	out := map[string]any{}
	for _, k := range keys {
		if v, ok := m[k]; ok {
			out[k] = v
		}
	}
	return out
}
func pickAllWithout(m map[string]any, excluded map[string]bool) map[string]any {
	out := map[string]any{}
	for k, v := range m {
		if excluded != nil && excluded[k] {
			continue
		}
		out[k] = v
	}
	return out
}
func endpointKey(values []any) string {
	parts := []string{}
	for _, v := range values {
		m := asMap(v)
		a := first(m, "address")
		p := numberText(m["port"])
		proto := first(m, "protocol")
		if a != "" || p != "" {
			parts = append(parts, proto+":"+a+":"+p)
		}
	}
	sort.Strings(parts)
	return strings.Join(parts, ",")
}
func unique(values []string) []string {
	if len(values) == 0 {
		return nil
	}
	sort.Strings(values)
	out := values[:0]
	last := ""
	for _, v := range values {
		if v != "" && v != last {
			out = append(out, v)
			last = v
		}
	}
	return out
}
func short(s string, n int) string {
	s = strings.TrimSpace(s)
	if len([]rune(s)) <= n {
		return s
	}
	r := []rune(s)
	return string(r[:n-1]) + "…"
}

func normalizeFilter(in Filter) Filter {
	in.Query = strings.TrimSpace(in.Query)
	in.Category = strings.TrimSpace(in.Category)
	in.ChangeType = strings.TrimSpace(in.ChangeType)
	in.DocumentationRequirement = strings.TrimSpace(in.DocumentationRequirement)
	in.ReviewStatus = strings.TrimSpace(in.ReviewStatus)
	if in.Page < 1 {
		in.Page = 1
	}
	if in.PageSize <= 0 {
		in.PageSize = 10
	}
	if in.PageSize > 200 {
		in.PageSize = 200
	}
	return in
}

func (s Service) List(ctx context.Context, filter Filter) (Page, error) {
	f := normalizeFilter(filter)
	clauses := []string{}
	args := []any{}
	if f.VMID > 0 {
		clauses = append(clauses, "c.vm_id=?")
		args = append(args, f.VMID)
	}
	if f.Query != "" {
		p := "%" + f.Query + "%"
		clauses = append(clauses, "(vm.name LIKE ? OR COALESCE(i.hostname,vm.guest_hostname,'') LIKE ? OR c.object_label LIKE ? OR c.summary LIKE ? OR c.notes LIKE ?)")
		for range 5 {
			args = append(args, p)
		}
	}
	if f.Category != "" {
		clauses = append(clauses, "c.category=?")
		args = append(args, f.Category)
	}
	if f.ChangeType != "" {
		clauses = append(clauses, "c.change_type=?")
		args = append(args, f.ChangeType)
	}
	if f.DocumentationRequirement != "" {
		clauses = append(clauses, "c.documentation_requirement=?")
		args = append(args, f.DocumentationRequirement)
	}
	if f.ReviewStatus != "" {
		clauses = append(clauses, "c.review_status=?")
		args = append(args, f.ReviewStatus)
	}
	// Changes at or before the current baseline remain stored for audit but are
	// hidden from normal triage and from documentation-completion calculations.
	clauses = append(clauses, "(b.inventory_id IS NULL OR c.inventory_id>b.inventory_id)")
	where := " WHERE " + strings.Join(clauses, " AND ")
	base := ` FROM inventory_changes c JOIN virtual_machines vm ON vm.id=c.vm_id LEFT JOIN inventory_snapshots i ON i.id=c.inventory_id LEFT JOIN inventory_change_baselines b ON b.vm_id=c.vm_id`
	var out Page
	out.Page = f.Page
	out.PageSize = f.PageSize
	out.Items = []Change{}
	summarySQL := `SELECT COUNT(*),COALESCE(SUM(c.review_status='new'),0),COALESCE(SUM(c.documentation_requirement='unset'),0),COALESCE(SUM(c.documentation_requirement='required'),0)` + base + where
	if err := s.DB.QueryRowContext(ctx, summarySQL, args...).Scan(&out.Total, &out.NewCount, &out.UnsetCount, &out.RequiredCount); err != nil {
		return out, err
	}
	if out.Total == 0 {
		return out, nil
	}
	out.Pages = (out.Total + out.PageSize - 1) / out.PageSize
	if out.Page > out.Pages {
		out.Page = out.Pages
	}
	offset := (out.Page - 1) * out.PageSize
	q := `SELECT c.id,c.vm_id,vm.name,COALESCE(NULLIF(i.hostname,''),vm.guest_hostname,''),c.agent_id,c.previous_inventory_id,c.inventory_id,c.occurred_at,c.category,c.object_type,c.object_key,c.object_label,c.change_type,c.summary,c.old_json,c.new_json,c.documentation_requirement,c.review_status,COALESCE(c.notes,''),c.reviewed_by,c.reviewed_at` + base + where + ` ORDER BY c.occurred_at DESC,c.id DESC LIMIT ? OFFSET ?`
	qargs := append(append([]any{}, args...), out.PageSize, offset)
	rows, err := s.DB.QueryContext(ctx, q, qargs...)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var c Change
		var prev, reviewedBy sql.NullInt64
		var oldS, newS sql.NullString
		var reviewedAt sql.NullTime
		if err := rows.Scan(&c.ID, &c.VMID, &c.VMName, &c.VMHostname, &c.AgentID, &prev, &c.InventoryID, &c.OccurredAt, &c.Category, &c.ObjectType, &c.ObjectKey, &c.ObjectLabel, &c.ChangeType, &c.Summary, &oldS, &newS, &c.DocumentationRequirement, &c.ReviewStatus, &c.Notes, &reviewedBy, &reviewedAt); err != nil {
			return out, err
		}
		if prev.Valid {
			v := prev.Int64
			c.PreviousInventoryID = &v
		}
		if reviewedBy.Valid {
			v := reviewedBy.Int64
			c.ReviewedBy = &v
		}
		if reviewedAt.Valid {
			v := reviewedAt.Time
			c.ReviewedAt = &v
		}
		if oldS.Valid {
			c.OldJSON = json.RawMessage(oldS.String)
		}
		if newS.Valid {
			c.NewJSON = json.RawMessage(newS.String)
		}
		out.Items = append(out.Items, c)
	}
	return out, rows.Err()
}

func (s Service) Update(ctx context.Context, id, userID int64, in UpdateInput) (Change, error) {
	req := strings.TrimSpace(in.DocumentationRequirement)
	if req == "" {
		req = "unset"
	}
	if req != "unset" && req != "required" && req != "not_required" {
		return Change{}, errors.New("invalid documentation_requirement")
	}
	status := strings.TrimSpace(in.ReviewStatus)
	if status == "" {
		status = "new"
	}
	if status != "new" && status != "reviewed" && status != "ignored" {
		return Change{}, errors.New("invalid review_status")
	}
	notes := strings.TrimSpace(in.Notes)
	var reviewer any = nil
	var reviewedAt any = nil
	if status != "new" {
		if userID > 0 {
			reviewer = userID
		}
		reviewedAt = time.Now().UTC()
	}
	res, err := s.DB.ExecContext(ctx, `UPDATE inventory_changes SET documentation_requirement=?,review_status=?,notes=?,reviewed_by=?,reviewed_at=? WHERE id=?`, req, status, notes, reviewer, reviewedAt, id)
	if err != nil {
		return Change{}, err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return Change{}, sql.ErrNoRows
	}
	return s.Get(ctx, id)
}

func (s Service) Get(ctx context.Context, id int64) (Change, error) {
	var c Change
	var prev, reviewedBy sql.NullInt64
	var oldS, newS sql.NullString
	var reviewedAt sql.NullTime
	err := s.DB.QueryRowContext(ctx, `SELECT c.id,c.vm_id,vm.name,COALESCE(NULLIF(i.hostname,''),vm.guest_hostname,''),c.agent_id,c.previous_inventory_id,c.inventory_id,c.occurred_at,c.category,c.object_type,c.object_key,c.object_label,c.change_type,c.summary,c.old_json,c.new_json,c.documentation_requirement,c.review_status,COALESCE(c.notes,''),c.reviewed_by,c.reviewed_at FROM inventory_changes c JOIN virtual_machines vm ON vm.id=c.vm_id LEFT JOIN inventory_snapshots i ON i.id=c.inventory_id WHERE c.id=?`, id).Scan(&c.ID, &c.VMID, &c.VMName, &c.VMHostname, &c.AgentID, &prev, &c.InventoryID, &c.OccurredAt, &c.Category, &c.ObjectType, &c.ObjectKey, &c.ObjectLabel, &c.ChangeType, &c.Summary, &oldS, &newS, &c.DocumentationRequirement, &c.ReviewStatus, &c.Notes, &reviewedBy, &reviewedAt)
	if err != nil {
		return c, err
	}
	if prev.Valid {
		v := prev.Int64
		c.PreviousInventoryID = &v
	}
	if reviewedBy.Valid {
		v := reviewedBy.Int64
		c.ReviewedBy = &v
	}
	if reviewedAt.Valid {
		v := reviewedAt.Time
		c.ReviewedAt = &v
	}
	if oldS.Valid {
		c.OldJSON = json.RawMessage(oldS.String)
	}
	if newS.Valid {
		c.NewJSON = json.RawMessage(newS.String)
	}
	return c, nil
}

// SetBaseline makes the current inventory snapshot the accepted starting
// point. Older changes are not deleted; normal listings simply hide them.
// vmID=0 applies the operation to every active VM that has an inventory.
func (s Service) SetBaseline(ctx context.Context, vmID, userID int64) (int64, error) {
	where := `vm.retired=0 AND vm.current_inventory_id IS NOT NULL`
	args := []any{}
	if vmID > 0 {
		where += ` AND vm.id=?`
		args = append(args, vmID)
	}
	var count int64
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM virtual_machines vm WHERE `+where, args...).Scan(&count); err != nil {
		return 0, err
	}
	if count == 0 {
		if vmID > 0 {
			return 0, sql.ErrNoRows
		}
		return 0, nil
	}
	reviewer := any(nil)
	if userID > 0 {
		reviewer = userID
	}
	query := `INSERT INTO inventory_change_baselines(vm_id,inventory_id,established_at,established_by,source)
SELECT vm.id,vm.current_inventory_id,UTC_TIMESTAMP(6),?,'manual' FROM virtual_machines vm WHERE ` + where + `
ON DUPLICATE KEY UPDATE inventory_id=VALUES(inventory_id),established_at=VALUES(established_at),established_by=VALUES(established_by),source='manual'`
	qargs := append([]any{reviewer}, args...)
	if _, err := s.DB.ExecContext(ctx, query, qargs...); err != nil {
		return 0, err
	}
	return count, nil
}

func (s Service) BackfillLatest(ctx context.Context) (int64, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT vm.id,vm.agent_id FROM virtual_machines vm WHERE vm.agent_id IS NOT NULL AND vm.retired=0 ORDER BY vm.id`)
	if err != nil {
		return 0, err
	}
	defer rows.Close()
	type pair struct{ vm, agent int64 }
	values := []pair{}
	for rows.Next() {
		var p pair
		if err := rows.Scan(&p.vm, &p.agent); err != nil {
			return 0, err
		}
		values = append(values, p)
	}
	if err := rows.Err(); err != nil {
		return 0, err
	}
	var total int64
	for _, p := range values {
		var currentID, prevID int64
		var currentRaw, prevRaw []byte
		err := s.DB.QueryRowContext(ctx, `SELECT id,raw_json FROM inventory_snapshots WHERE agent_id=? ORDER BY id DESC LIMIT 1`, p.agent).Scan(&currentID, &currentRaw)
		if err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				continue
			}
			return total, err
		}
		err = s.DB.QueryRowContext(ctx, `SELECT id,raw_json FROM inventory_snapshots WHERE agent_id=? AND id<? ORDER BY id DESC LIMIT 1`, p.agent, currentID).Scan(&prevID, &prevRaw)
		if err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				continue
			}
			return total, err
		}
		tx, err := s.DB.BeginTx(ctx, nil)
		if err != nil {
			return total, err
		}
		n, capErr := s.Capture(ctx, tx, p.agent, prevID, currentID, prevRaw, currentRaw)
		if capErr != nil {
			tx.Rollback()
			return total, capErr
		}
		if err := tx.Commit(); err != nil {
			return total, err
		}
		total += n
	}
	return total, nil
}
