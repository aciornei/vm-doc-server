package documents

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/external"
)

func ValidateTemplate(content []byte) error {
	return ValidateTemplateFor(content, "vm")
}

func ValidateTemplateFor(content []byte, objectType string) error {
	placeholder := VMBodyPlaceholder
	if normalizeObjectType(objectType) == "service" {
		placeholder = ServiceBodyPlaceholder
	}
	if len(content) == 0 {
		return errors.New("template is empty")
	}
	reader, err := zip.NewReader(bytes.NewReader(content), int64(len(content)))
	if err != nil {
		return errors.New("template is not a valid DOCX archive")
	}
	if err := validateArchiveSafety(reader); err != nil {
		return err
	}
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		data, err := readZipFile(file, 10<<20)
		if err != nil {
			return err
		}
		if !strings.Contains(string(data), placeholder) {
			return fmt.Errorf("template must contain %s in word/document.xml", placeholder)
		}
		return nil
	}
	return errors.New("template does not contain word/document.xml")
}

func validateArchiveSafety(reader *zip.Reader) error {
	if len(reader.File) > 500 {
		return errors.New("template contains too many DOCX parts")
	}
	var total uint64
	for _, file := range reader.File {
		if file.UncompressedSize64 > 64<<20 {
			return fmt.Errorf("DOCX part %s is too large", file.Name)
		}
		total += file.UncompressedSize64
		if total > 128<<20 {
			return errors.New("template expands beyond the 128 MiB safety limit")
		}
	}
	return nil
}

func DefaultTemplate() ([]byte, error) {
	files := map[string]string{
		"[Content_Types].xml":          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`,
		"_rels/.rels":                  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`,
		"word/_rels/document.xml.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
		"word/styles.xml":              stylesXML,
		"word/document.xml":            `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>Fișă tehnică VM</w:t></w:r></w:p><w:p><w:r><w:t>{{VM_DOCUMENT_BODY}}</w:t></w:r></w:p><w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`,
		"docProps/core.xml":            `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Fișă tehnică VM</dc:title><dc:creator>vm-doc-server</dc:creator><cp:lastModifiedBy>vm-doc-server</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">2026-01-01T00:00:00Z</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">2026-01-01T00:00:00Z</dcterms:modified></cp:coreProperties>`,
		"docProps/app.xml":             `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>vm-doc-server</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>0.13.1</AppVersion></Properties>`,
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	order := []string{"[Content_Types].xml", "_rels/.rels", "word/document.xml", "word/styles.xml", "word/_rels/document.xml.rels", "docProps/core.xml", "docProps/app.xml"}
	for _, name := range order {
		entry, err := writer.Create(name)
		if err != nil {
			return nil, err
		}
		if _, err := io.WriteString(entry, files[name]); err != nil {
			return nil, err
		}
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return output.Bytes(), nil
}

func BuildPreview(template Template, data GenerationData) Preview {
	preview := Preview{
		VMID:           data.VM.ID,
		VMName:         data.VM.Name,
		TemplateID:     template.ID,
		TemplateName:   template.Name,
		DocumentNumber: data.DocumentNumber,
		GeneratedAt:    data.GeneratedAt,
		Warnings:       make([]string, 0),
		Sections:       previewSections(data),
	}
	if data.Inventory != nil {
		id := data.Inventory.ID
		preview.SourceInventoryID = &id
	} else {
		preview.Warnings = append(preview.Warnings, "VM-ul nu are inventar curent; secțiunile agentului vor lipsi.")
	}
	if len(data.Operational.ServiceAssignments) == 0 {
		preview.Warnings = append(preview.Warnings, "VM-ul nu are servicii interne și roluri tehnice asociate.")
	}
	if len(data.Operational.Responsibilities) == 0 {
		preview.Warnings = append(preview.Warnings, "VM-ul nu are responsabilități definite.")
	}
	return preview
}

func RenderDOCX(template []byte, data GenerationData) ([]byte, error) {
	if err := ValidateTemplateFor(template, "vm"); err != nil {
		return nil, err
	}
	reader, err := zip.NewReader(bytes.NewReader(template), int64(len(template)))
	if err != nil {
		return nil, err
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	tokens := scalarTokens(data)
	body := documentBodyXML(data)
	bodyReplaced := false
	for _, source := range reader.File {
		content, err := readZipFile(source, 64<<20)
		if err != nil {
			writer.Close()
			return nil, err
		}
		if strings.HasSuffix(source.Name, ".xml") {
			text := string(content)
			for token, value := range tokens {
				text = strings.ReplaceAll(text, token, xmlText(value))
			}
			if source.Name == "word/document.xml" {
				if replaced, ok := replaceBodyParagraph(text, body); ok {
					text = replaced
					bodyReplaced = true
				}
			}
			if source.Name == "docProps/core.xml" {
				text = updateCoreProperties(text, data)
			}
			content = []byte(text)
		}
		header := source.FileHeader
		header.CRC32 = 0
		header.CompressedSize = 0
		header.CompressedSize64 = 0
		header.UncompressedSize = 0
		header.UncompressedSize64 = 0
		header.SetModTime(data.GeneratedAt)
		destination, err := writer.CreateHeader(&header)
		if err != nil {
			writer.Close()
			return nil, err
		}
		if _, err := destination.Write(content); err != nil {
			writer.Close()
			return nil, err
		}
	}
	if !bodyReplaced {
		writer.Close()
		return nil, fmt.Errorf("template placeholder %s was not found as a complete paragraph", BodyPlaceholder)
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return output.Bytes(), nil
}

func replaceBodyParagraph(documentXML, body string) (string, bool) {
	placeholder := strings.Index(documentXML, BodyPlaceholder)
	if placeholder < 0 {
		return documentXML, false
	}
	start := paragraphStart(documentXML[:placeholder])
	if start < 0 {
		return documentXML, false
	}
	endOffset := strings.Index(documentXML[placeholder:], "</w:p>")
	if endOffset < 0 {
		return documentXML, false
	}
	end := placeholder + endOffset + len("</w:p>")
	return documentXML[:start] + body + documentXML[end:], true
}

func paragraphStart(prefix string) int {
	for {
		index := strings.LastIndex(prefix, "<w:p")
		if index < 0 {
			return -1
		}
		after := index + len("<w:p")
		if after >= len(prefix) || prefix[after] == '>' || prefix[after] == ' ' || prefix[after] == '\t' || prefix[after] == '\r' || prefix[after] == '\n' {
			return index
		}
		prefix = prefix[:index]
	}
}

func scalarTokens(data GenerationData) map[string]string {
	inventoryHostname, inventoryIP, inventoryOS := "", "", ""
	if data.Inventory != nil {
		inventoryHostname = data.Inventory.Hostname
		inventoryIP = data.Inventory.PrimaryIP
		inventoryOS = strings.TrimSpace(data.Inventory.OSName + " " + data.Inventory.OSVersion)
	}
	return map[string]string{
		"{{document.number}}":       data.DocumentNumber,
		"{{document.generated_at}}": formatTime(data.GeneratedAt),
		"{{document.generated_by}}": firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username),
		"{{vm.name}}":               data.VM.Name,
		"{{vm.hostname}}":           firstNonEmpty(inventoryHostname, data.VM.GuestHostname),
		"{{vm.ip}}":                 firstNonEmpty(inventoryIP, data.VM.PrimaryIP),
		"{{vm.os}}":                 firstNonEmpty(inventoryOS, data.VM.GuestOS),
		"{{vm.environment}}":        data.Operational.Environment,
		"{{vm.status}}":             data.Operational.OperationalStatus,
		"{{vm.classification}}":     data.Operational.Classification,
		"{{vm.purpose}}":            data.Operational.Purpose,
	}
}

func previewSections(data GenerationData) []PreviewSection {
	sections := []PreviewSection{
		{Title: "Document", Rows: []PreviewRow{{Label: "Număr", Value: data.DocumentNumber}, {Label: "Generat la", Value: formatTime(data.GeneratedAt)}, {Label: "Generat de", Value: firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)}}},
		{Title: "Identificare și resurse", Rows: identityPreviewRows(data)},
		{Title: "Încadrare operațională", Rows: operationalPreviewRows(data)},
	}
	if rows := servicePreviewRows(data); len(rows) > 0 {
		sections = append(sections, PreviewSection{Title: "Servicii și roluri", Rows: rows})
	}
	if rows := commonDependencyPreviewRows(data.CommonDependencies); len(rows) > 0 {
		sections = append(sections, PreviewSection{Title: "Dependențe infrastructură comună", Rows: rows})
	}
	if rows := externalConnectionPreviewRows(data.ExternalConnections); len(rows) > 0 {
		sections = append(sections, PreviewSection{Title: "Conexiuni către sisteme externe", Rows: rows})
	}
	if rows := primaryAgentServicePreviewRows(data.PrimaryServices); len(rows) > 0 {
		sections = append(sections, PreviewSection{Title: "Componente software principale", Rows: rows})
	}
	if rows := primaryAgentPortPreviewRows(data.PrimaryPorts); len(rows) > 0 {
		sections = append(sections, PreviewSection{Title: "Porturi și procese principale", Rows: rows})
	}
	if rows := responsibilityPreviewRows(data); len(rows) > 0 {
		sections = append(sections, PreviewSection{Title: "Responsabilități", Rows: rows})
	}
	if rows := dockerPreviewRows(data.Docker); len(rows) > 0 {
		sections = append(sections, PreviewSection{Title: "Docker și containere", Rows: rows})
	}
	if rows := databasePreviewRows(data.Databases); len(rows) > 0 {
		sections = append(sections, PreviewSection{Title: "Baze de date", Rows: rows})
	}
	if rows := webPreviewRows(data.Web); len(rows) > 0 {
		sections = append(sections, PreviewSection{Title: "Site-uri web și frontends", Rows: rows})
	}
	sections = append(sections, PreviewSection{Title: "Backup și restaurare", Rows: backupPreviewRows(data)})
	if data.Inventory != nil {
		sections = append(sections, PreviewSection{Title: "Inventar agent", Rows: []PreviewRow{{Label: "Snapshot", Value: strconv.FormatInt(data.Inventory.ID, 10)}, {Label: "Primit la", Value: formatTime(data.Inventory.ReceivedAt)}, {Label: "Colectori", Value: fmt.Sprintf("%d/%d OK", data.Inventory.CollectorOK, data.Inventory.CollectorTotal)}, {Label: "Versiune agent", Value: data.Inventory.AgentVersion}}})
	}
	return sections
}

func identityPreviewRows(data GenerationData) []PreviewRow {
	hostname, ip, osName := data.VM.GuestHostname, data.VM.PrimaryIP, data.VM.GuestOS
	if data.Inventory != nil {
		hostname = firstNonEmpty(data.Inventory.Hostname, hostname)
		ip = firstNonEmpty(data.Inventory.PrimaryIP, ip)
		osName = firstNonEmpty(strings.TrimSpace(data.Inventory.OSName+" "+data.Inventory.OSVersion), osName)
	}
	return []PreviewRow{
		{Label: "Nume VM", Value: data.VM.Name},
		{Label: "Hostname", Value: hostname},
		{Label: "IP principal", Value: ip},
		{Label: "Sistem de operare", Value: osName},
		{Label: "CPU", Value: strconv.Itoa(data.VM.CPUCount)},
		{Label: "Memorie", Value: formatMemory(data.VM.MemoryMiB)},
		{Label: "Power state", Value: data.VM.PowerState},
		{Label: "Sursă vCenter", Value: data.VM.VCenterSourceName},
		{Label: "BIOS UUID", Value: data.VM.BIOSUUID},
	}
}

func operationalPreviewRows(data GenerationData) []PreviewRow {
	return []PreviewRow{
		{Label: "Mediu", Value: data.Operational.Environment},
		{Label: "Status operațional", Value: data.Operational.OperationalStatus},
		{Label: "Clasificare", Value: data.Operational.Classification},
		{Label: "Scop", Value: data.Operational.Purpose},
		{Label: "Documentație", Value: data.Operational.DocumentationURL},
		{Label: "Referință tichet", Value: data.Operational.TicketReference},
		{Label: "Observații", Value: data.Operational.Notes},
	}
}

func servicePreviewRows(data GenerationData) []PreviewRow {
	rows := make([]PreviewRow, 0, len(data.Operational.ServiceAssignments))
	for _, item := range data.Operational.ServiceAssignments {
		label := item.InternalServiceName
		if item.Primary {
			label += " · principal"
		}
		value := strings.Join(nonEmpty(item.ArchitecturalDomain, item.ITILCategory, item.LayerName, item.TechnicalRole, item.SolutionType, item.UsageType), " → ")
		rows = append(rows, PreviewRow{Label: label, Value: value})
	}
	return rows
}

func commonDependencyPreviewRows(values []domain.ServiceDependency) []PreviewRow {
	rows := make([]PreviewRow, 0, len(values))
	for _, item := range values {
		context := firstNonEmpty(item.SourceLabel, item.SourceServiceName)
		if item.TargetVMNames != "" {
			context = strings.TrimSpace(context + " · furnizat de: " + item.TargetVMNames)
		}
		if item.Global {
			context = strings.TrimSpace(context + " · global")
		}
		if item.Notes != "" {
			context = strings.TrimSpace(context + " · " + item.Notes)
		}
		rows = append(rows, PreviewRow{Label: item.TargetServiceName + " — " + item.DependencyType, Value: context})
	}
	return rows
}

func externalConnectionPreviewRows(values []external.Connection) []PreviewRow {
	rows := make([]PreviewRow, 0, len(values))
	for _, item := range values {
		endpoint := firstNonEmpty(item.ExternalHostname, item.ExternalIPAddresses, "adresă nespecificată")
		protocol := strings.ToUpper(strings.TrimSpace(item.Protocol))
		if item.Port != nil {
			protocol = strings.TrimSpace(protocol + "/" + strconv.Itoa(*item.Port))
		}
		context := strings.Join(nonEmpty(externalNetworkSummary(item), externalDirectionLabel(item.Direction), item.RemoteService, protocol), " · ")
		if item.TLSEnabled {
			context = strings.TrimSpace(context + " · TLS")
		}
		if item.Purpose != "" {
			context = strings.TrimSpace(context + " · " + item.Purpose)
		}
		rows = append(rows, PreviewRow{Label: item.ExternalSystemName + " — " + endpoint, Value: context})
	}
	return rows
}

func externalNetworkSummary(item external.Connection) string {
	name := firstNonEmpty(item.NetworkName, "Neclasificat")
	meta := strings.Join(nonEmpty(item.NetworkRiskLevel, item.NetworkTrustLevel), " / ")
	if meta != "" {
		return name + " (" + meta + ")"
	}
	return name
}

func externalDirectionLabel(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "inbound":
		return "Intrare ← extern"
	case "bidirectional":
		return "Bidirecțional ↔"
	default:
		return "Ieșire → extern"
	}
}

func externalConnectionsTableXML(values []external.Connection, showInternalSource bool) string {
	if len(values) == 0 {
		return paragraph("Nu sunt declarate conexiuni către sisteme externe.", "IntenseQuote")
	}
	head := []string{"Sistem extern", "Rețea / risc", "Sens", "Serviciu / port", "Securitate", "Scop"}
	widths := []int{1950, 1450, 1250, 1600, 1400, 1350}
	if showInternalSource {
		head = []string{"Sursă → sistem extern", "Rețea / risc", "Sens", "Serviciu / port", "Securitate", "Scop"}
		widths = []int{2350, 1450, 1100, 1500, 1250, 1350}
	}
	rows := make([][]string, 0, len(values))
	for _, item := range values {
		endpoint := firstNonEmpty(item.ExternalHostname, item.ExternalIPAddresses)
		name := item.ExternalSystemName
		if endpoint != "" {
			name += " · " + endpoint
		}
		protocol := strings.ToUpper(strings.TrimSpace(item.Protocol))
		if item.Port != nil {
			protocol = strings.TrimSpace(protocol + "/" + strconv.Itoa(*item.Port))
		}
		servicePort := strings.Join(nonEmpty(item.RemoteService, protocol), " · ")
		security := strings.Join(nonEmpty(map[bool]string{true: "TLS", false: ""}[item.TLSEnabled], item.Authentication), " · ")
		if security == "" {
			security = "—"
		}
		row := []string{name, externalNetworkSummary(item), externalDirectionLabel(item.Direction), servicePort, security, firstNonEmpty(item.Purpose, item.Notes)}
		if showInternalSource {
			source := firstNonEmpty(item.InternalServiceName, item.VMName, "—")
			row[0] = source + " → " + name
		}
		rows = append(rows, row)
	}
	return tableWithWidths(head, rows, widths)
}

func primaryAgentServicePreviewRows(values []domain.PrimaryAgentService) []PreviewRow {
	rows := make([]PreviewRow, 0, len(values))
	for _, item := range values {
		name := firstNonEmpty(item.SoftwareName, strings.TrimSuffix(item.ServiceName, ".service"), item.ServiceName)
		version := firstNonEmpty(item.Version, item.PackageVersion, "versiune necunoscută")
		state := strings.Join(nonEmpty(item.ActiveState, item.EnabledState), " · ")
		if !item.Detected {
			state = "Nedetectat în inventarul curent"
		}
		rows = append(rows, PreviewRow{Label: name + " — " + version, Value: strings.TrimSpace(state)})
	}
	return rows
}

func primaryAgentPortPreviewRows(values []domain.PrimaryAgentPort) []PreviewRow {
	rows := make([]PreviewRow, 0, len(values))
	for _, item := range values {
		label := strings.ToUpper(strings.TrimSpace(item.Protocol)) + "/" + strconv.Itoa(item.Port)
		if item.ProcessName != "" {
			label += " · " + item.ProcessName
		}
		details := make([]string, 0, 4)
		if len(item.PIDs) > 0 {
			pids := make([]string, 0, len(item.PIDs))
			for _, pid := range item.PIDs {
				pids = append(pids, strconv.Itoa(pid))
			}
			details = append(details, "PID "+strings.Join(pids, ", "))
		}
		if item.Executable != "" {
			details = append(details, item.Executable)
		}
		if len(item.Addresses) > 0 {
			details = append(details, "listen "+strings.Join(item.Addresses, ", "))
		}
		if !item.Detected {
			details = []string{"Nedetectat în inventarul curent"}
		}
		rows = append(rows, PreviewRow{Label: label, Value: firstNonEmpty(strings.Join(details, " · "), "—")})
	}
	return rows
}

func responsibilityPreviewRows(data GenerationData) []PreviewRow {
	rows := make([]PreviewRow, 0, len(data.Operational.Responsibilities))
	for _, item := range data.Operational.Responsibilities {
		value := strings.Join(nonEmpty(item.PersonDepartment, item.PersonEmail, item.PersonPhone, item.Notes), " · ")
		rows = append(rows, PreviewRow{Label: responsibilityLabel(item.ResponsibilityType) + " — " + item.PersonName, Value: value})
	}
	return rows
}

func backupPreviewRows(data GenerationData) []PreviewRow {
	backup := data.Backup
	protected := "Nu"
	if backup.Protected || backup.CronBackupEnabled {
		protected = "Da"
	}
	rows := []PreviewRow{
		{Label: "Furnizor", Value: backup.Provider}, {Label: "Protejată", Value: protected},
		{Label: "În job Veeam", Value: backupYesNo(backup.VeeamInJob)}, {Label: "Stare Veeam", Value: backupVeeamStateText(backup)},
		{Label: "Job", Value: backup.JobName}, {Label: "Politică", Value: backup.PolicyName},
		{Label: "Storage primar", Value: firstNonEmpty(backup.PrimaryRepositoryName, backup.RepositoryName)},
		{Label: "Storage secundar", Value: backup.SecondaryRepositoryNames}, {Label: "Programare Veeam", Value: backup.ScheduleText},
		{Label: "Retenție", Value: backupRetentionText(backup)}, {Label: "GFS Weekly", Value: backupGFSWeeklyText(backup)},
		{Label: "GFS Monthly", Value: backupGFSMonthlyText(backup)}, {Label: "GFS Yearly", Value: backupGFSYearlyText(backup)},
		{Label: "Ultimul rezultat", Value: backup.LastResult}, {Label: "Ultimul backup", Value: formatTimePtr(backup.LastBackupAt)},
		{Label: "Următoarea rulare", Value: formatTimePtr(backup.NextRunAt)}, {Label: "Restore points", Value: formatIntPtr(backup.RestorePoints)},
		{Label: "RPO", Value: formatMinutes(backup.RPOMinutes)}, {Label: "RTO", Value: formatMinutes(backup.RTOMinutes)},
	}
	if backup.CronBackupEnabled {
		rows = append(rows, PreviewRow{Label: "Backup cron declarat", Value: "Da"}, PreviewRow{Label: "Cron", Value: backup.CronBackupSchedule}, PreviewRow{Label: "Comandă cron", Value: backup.CronBackupCommand}, PreviewRow{Label: "Detalii cron", Value: backup.CronBackupNotes})
	}
	return rows
}

func backupYesNo(v bool) string {
	if v {
		return "Da"
	}
	return "Nu"
}

func backupVeeamStateText(b domain.VMBackupSummary) string {
	switch b.VeeamState {
	case "protected":
		return "Protejată · restore point disponibil"
	case "waiting":
		return "În job · așteaptă primul backup"
	case "job_disabled":
		return "În job · job dezactivat · fără restore point"
	case "stale":
		return "Backup existent · nu mai este în job"
	case "unprotected":
		return "Neprotejată · nu este în job"
	case "never":
		return "Neverificată"
	default:
		if b.Protected {
			return "Protejată"
		}
		if b.VeeamInJob {
			return "În job Veeam"
		}
		return ""
	}
}

func backupRetentionText(b domain.VMBackupSummary) string {
	if b.RetentionQuantity == nil {
		return b.RetentionType
	}
	return strings.TrimSpace(fmt.Sprintf("%s · %d", b.RetentionType, *b.RetentionQuantity))
}
func backupGFSWeeklyText(b domain.VMBackupSummary) string {
	if b.GFSWeeklyWeeks == nil {
		return ""
	}
	return strings.TrimSpace(fmt.Sprintf("%d săptămâni · %s", *b.GFSWeeklyWeeks, b.GFSWeeklyDay))
}
func backupGFSMonthlyText(b domain.VMBackupSummary) string {
	if b.GFSMonthlyMonths == nil {
		return ""
	}
	return strings.TrimSpace(fmt.Sprintf("%d luni · %s", *b.GFSMonthlyMonths, b.GFSMonthlyWeek))
}
func backupGFSYearlyText(b domain.VMBackupSummary) string {
	if b.GFSYearlyYears == nil {
		return ""
	}
	return strings.TrimSpace(fmt.Sprintf("%d ani · %s", *b.GFSYearlyYears, b.GFSYearlyMonth))
}

func databaseAssignmentNames(values []domain.DatabaseServiceAssignment) string {
	if len(values) == 0 {
		return "neasociat serviciu"
	}
	names := make([]string, 0, len(values))
	seen := map[string]bool{}
	for _, item := range values {
		name := strings.TrimSpace(item.ServiceName)
		if name != "" && !seen[name] {
			seen[name] = true
			names = append(names, name)
		}
	}
	sort.Strings(names)
	return strings.Join(names, ", ")
}

func databaseEndpointSummary(values []domain.DatabaseEndpoint) string {
	parts := make([]string, 0, len(values))
	for _, ep := range values {
		if ep.Port > 0 {
			if strings.TrimSpace(ep.Address) != "" {
				parts = append(parts, fmt.Sprintf("%s:%d", ep.Address, ep.Port))
			} else {
				parts = append(parts, fmt.Sprintf("port %d", ep.Port))
			}
		} else if strings.TrimSpace(ep.Address) != "" {
			parts = append(parts, ep.Address)
		}
	}
	return firstNonEmpty(strings.Join(parts, ", "), "—")
}

func databasePreviewRows(view domain.DatabaseVMView) []PreviewRow {
	if !hasDatabaseDocumentData(view) {
		return nil
	}
	rows := []PreviewRow{{Label: "Engine-uri detectate", Value: strconv.Itoa(view.Host.EngineCount)}, {Label: "Instanțe", Value: strconv.Itoa(view.Host.InstanceCount)}, {Label: "Baze logice descoperite", Value: strconv.Itoa(view.Host.CatalogCount)}}
	for _, instance := range view.Instances {
		label := firstNonEmpty(instance.Product, instance.Engine) + " · " + firstNonEmpty(instance.InstanceName, "implicit")
		value := strings.TrimSpace(strings.Join(nonEmpty(instance.Version, instance.Status, databaseEndpointSummary(instance.Endpoints), databaseAssignmentNames(instance.ServiceAssignments)), " · "))
		rows = append(rows, PreviewRow{Label: label, Value: value})
		for _, catalog := range instance.Catalogs {
			rows = append(rows, PreviewRow{Label: "  " + catalog.Name, Value: strings.TrimSpace(strings.Join(nonEmpty(firstNonEmpty(catalog.Kind, "database"), databaseAssignmentNames(catalog.ServiceAssignments)), " · "))})
		}
	}
	return rows
}

func databaseCatalogDiscoverySummary(instance domain.DatabaseInstance) string {
	status := firstNonEmpty(instance.CatalogDiscoveryStatus, "metadata_only")
	if strings.EqualFold(status, "discovered") || strings.TrimSpace(instance.CatalogDiscoveryReason) == "" {
		return status
	}
	labels := map[string]string{
		"authentication_required": "autentificare necesară",
		"permission_denied":       "permisiuni insuficiente",
		"socket_unavailable":      "socket local indisponibil",
		"server_unavailable":      "server DB indisponibil",
		"client_not_found":        "client DB lipsă",
		"timeout":                 "timeout la interogare",
		"os_user_unavailable":     "utilizator OS indisponibil",
		"query_failed":            "interogare catalog eșuată",
		"unsupported_engine":      "enumerare catalog nesuportată",
	}
	reason := strings.TrimSpace(instance.CatalogDiscoveryReason)
	if label, ok := labels[reason]; ok {
		reason = label
	}
	return status + " · " + reason
}

func databaseDocumentXML(view domain.DatabaseVMView) string {
	if view.Host == nil {
		return paragraph("Nu există inventar structurat de baze de date pentru această VM.", "IntenseQuote")
	}
	var out strings.Builder
	out.WriteString(keyValueTable([]PreviewRow{{Label: "Engine-uri detectate", Value: strconv.Itoa(view.Host.EngineCount)}, {Label: "Instanțe", Value: strconv.Itoa(view.Host.InstanceCount)}, {Label: "Baze logice descoperite", Value: strconv.Itoa(view.Host.CatalogCount)}}))
	if len(view.Instances) == 0 {
		out.WriteString(paragraph("Nu există instanțe active de baze de date detectate.", "IntenseQuote"))
		return out.String()
	}
	instanceRows := make([][]string, 0, len(view.Instances))
	for _, instance := range view.Instances {
		instanceRows = append(instanceRows, []string{firstNonEmpty(instance.Product, instance.Engine), firstNonEmpty(instance.InstanceName, "implicit"), firstNonEmpty(instance.Version, "—"), firstNonEmpty(instance.Status, "—"), databaseEndpointSummary(instance.Endpoints), databaseCatalogDiscoverySummary(instance), databaseAssignmentNames(instance.ServiceAssignments)})
	}
	out.WriteString(tableWithWidths([]string{"Engine", "Instanță", "Versiune", "Stare", "Endpoint", "Descoperire baze", "Servicii"}, instanceRows, []int{1450, 1300, 1500, 900, 1600, 1300, 1550}))
	catalogRows := [][]string{}
	for _, instance := range view.Instances {
		for _, catalog := range instance.Catalogs {
			system := "Nu"
			if catalog.System {
				system = "Da"
			}
			catalogRows = append(catalogRows, []string{firstNonEmpty(instance.Product, instance.Engine), firstNonEmpty(instance.InstanceName, "implicit"), catalog.Name, firstNonEmpty(catalog.Kind, "database"), system, databaseAssignmentNames(catalog.ServiceAssignments)})
		}
	}
	if len(catalogRows) > 0 {
		out.WriteString(tableWithWidths([]string{"Engine", "Instanță", "Bază", "Tip", "Sistem", "Servicii"}, catalogRows, []int{1500, 1400, 1800, 1100, 800, 2400}))
	}
	return out.String()
}

func dockerPreviewRows(view domain.DockerVMView) []PreviewRow {
	if !hasDockerDocumentData(view) {
		return nil
	}
	host := view.Host
	rows := []PreviewRow{
		{Label: "Docker Engine", Value: firstNonEmpty(host.Version, "versiune necunoscută")},
		{Label: "Stare", Value: firstNonEmpty(host.ServiceState, boolLabel(host.Available))},
		{Label: "Containere", Value: fmt.Sprintf("%d total · %d running", host.ContainerCount, host.RunningCount)},
		{Label: "Images / Networks / Volumes", Value: fmt.Sprintf("%d / %d / %d", host.ImageCount, host.NetworkCount, host.VolumeCount)},
		{Label: "Compose projects", Value: strconv.Itoa(host.ComposeProjectCount)},
	}
	for _, c := range view.Containers {
		label := c.Name
		if c.ComposeProject != "" {
			label = c.ComposeProject + " / " + firstNonEmpty(c.ComposeService, c.Name)
		}
		rows = append(rows, PreviewRow{Label: label, Value: strings.TrimSpace(strings.Join(nonEmpty(c.Image, c.State, dockerAssignmentNames(c.ServiceAssignments)), " · "))})
	}
	return rows
}

func hasDockerDocumentData(view domain.DockerVMView) bool {
	return view.Host != nil && view.Host.Installed
}

func hasDatabaseDocumentData(view domain.DatabaseVMView) bool {
	return view.Host != nil && (view.Host.EngineCount > 0 || view.Host.InstanceCount > 0 || view.Host.CatalogCount > 0 || len(view.Engines) > 0 || len(view.Instances) > 0)
}

func hasWebDocumentData(view domain.WebVMView) bool {
	return view.Host != nil && (view.Host.ServerCount > 0 || view.Host.SiteCount > 0 || len(view.Servers) > 0 || len(view.Sites) > 0)
}

func webAssignmentNames(values []domain.WebServiceAssignment) string {
	if len(values) == 0 {
		return "neasociat serviciu"
	}
	names := make([]string, 0, len(values))
	seen := make(map[string]bool)
	for _, item := range values {
		name := strings.TrimSpace(item.ServiceName)
		if name != "" && !seen[name] {
			seen[name] = true
			names = append(names, name)
		}
	}
	sort.Strings(names)
	return strings.Join(names, ", ")
}

func webBindingSummary(values []domain.WebBinding) string {
	parts := make([]string, 0, len(values))
	for _, binding := range values {
		protocol := firstNonEmpty(binding.Protocol, "http")
		if binding.TLS && binding.Protocol == "" {
			protocol = "https"
		}
		address := firstNonEmpty(binding.Address, "*")
		if binding.Port > 0 {
			parts = append(parts, fmt.Sprintf("%s://%s:%d", protocol, address, binding.Port))
		} else {
			parts = append(parts, protocol+"://"+address)
		}
	}
	return firstNonEmpty(strings.Join(parts, ", "), "—")
}

func webTargetSummary(site domain.WebSite) string {
	parts := make([]string, 0, 3)
	if strings.TrimSpace(site.DocumentRoot) != "" {
		parts = append(parts, "root="+site.DocumentRoot)
	}
	if len(site.Backends) > 0 {
		parts = append(parts, "backend="+strings.Join(site.Backends, ", "))
	}
	if len(site.ProxyTargets) > 0 {
		parts = append(parts, "proxy="+strings.Join(site.ProxyTargets, ", "))
	}
	return firstNonEmpty(strings.Join(parts, " · "), "—")
}

func webPreviewRows(view domain.WebVMView) []PreviewRow {
	if !hasWebDocumentData(view) {
		return nil
	}
	rows := []PreviewRow{{Label: "Servere web", Value: strconv.Itoa(view.Host.ServerCount)}, {Label: "Site-uri / frontends", Value: strconv.Itoa(view.Host.SiteCount)}}
	for _, site := range view.Sites {
		label := firstNonEmpty(site.Name, "site") + " · " + firstNonEmpty(site.Product, site.Engine)
		value := strings.TrimSpace(strings.Join(nonEmpty(strings.Join(site.ServerNames, ", "), webBindingSummary(site.Bindings), webTargetSummary(site), webAssignmentNames(site.ServiceAssignments)), " · "))
		rows = append(rows, PreviewRow{Label: label, Value: value})
	}
	return rows
}

func webDocumentXML(view domain.WebVMView) string {
	if !hasWebDocumentData(view) {
		return ""
	}
	var out strings.Builder
	out.WriteString(keyValueTable([]PreviewRow{{Label: "Servere web detectate", Value: strconv.Itoa(view.Host.ServerCount)}, {Label: "Site-uri / frontends", Value: strconv.Itoa(view.Host.SiteCount)}}))
	if len(view.Servers) > 0 {
		rows := make([][]string, 0, len(view.Servers))
		for _, server := range view.Servers {
			rows = append(rows, []string{firstNonEmpty(server.Product, server.Engine), firstNonEmpty(server.Version, "—"), firstNonEmpty(server.Status, "—"), firstNonEmpty(server.ServiceName, "—"), firstNonEmpty(strings.Join(server.ConfigFiles, ", "), "—")})
		}
		out.WriteString(tableWithWidths([]string{"Produs", "Versiune", "Stare", "Serviciu OS", "Config"}, rows, []int{1800, 1600, 1200, 1900, 2500}))
	}
	if len(view.Sites) > 0 {
		rows := make([][]string, 0, len(view.Sites))
		for _, site := range view.Sites {
			rows = append(rows, []string{firstNonEmpty(site.Name, "—"), firstNonEmpty(site.Product, site.Engine), firstNonEmpty(strings.Join(site.ServerNames, ", "), "—"), webBindingSummary(site.Bindings), webTargetSummary(site), webAssignmentNames(site.ServiceAssignments)})
		}
		out.WriteString(tableWithWidths([]string{"Site / frontend", "Engine", "Nume publice", "Bind", "Root / backend / proxy", "Servicii"}, rows, []int{1700, 1300, 1800, 1500, 2600, 1600}))
	}
	return out.String()
}

func dockerAssignmentNames(values []domain.DockerServiceAssignment) string {
	if len(values) == 0 {
		return "neasociat serviciu"
	}
	names := make([]string, 0, len(values))
	seen := make(map[string]bool)
	for _, item := range values {
		name := strings.TrimSpace(item.ServiceName)
		if name != "" && !seen[name] {
			seen[name] = true
			names = append(names, name)
		}
	}
	sort.Strings(names)
	return strings.Join(names, ", ")
}

func dockerPortSummary(values []domain.DockerPort) string {
	parts := make([]string, 0, len(values))
	for _, p := range values {
		proto := firstNonEmpty(p.Protocol, "tcp")
		if p.HostPort > 0 {
			parts = append(parts, fmt.Sprintf("%s:%d→%d/%s", firstNonEmpty(p.HostIP, "*"), p.HostPort, p.ContainerPort, proto))
		} else if p.ContainerPort > 0 {
			parts = append(parts, fmt.Sprintf("%d/%s", p.ContainerPort, proto))
		}
	}
	return firstNonEmpty(strings.Join(parts, ", "), "—")
}

func dockerDocumentXML(view domain.DockerVMView) string {
	if view.Host == nil {
		return paragraph("Nu există inventar Docker structurat pentru această VM.", "IntenseQuote")
	}
	host := view.Host
	if !host.Installed {
		return paragraph("Docker nu este instalat pe această VM.", "IntenseQuote")
	}
	var out strings.Builder
	out.WriteString(keyValueTable([]PreviewRow{
		{Label: "Docker Engine", Value: host.Version},
		{Label: "Stare serviciu", Value: host.ServiceState},
		{Label: "Storage driver", Value: host.StorageDriver},
		{Label: "Logging driver", Value: host.LoggingDriver},
		{Label: "Docker root", Value: host.DockerRootDir},
		{Label: "Containere", Value: fmt.Sprintf("%d total · %d running", host.ContainerCount, host.RunningCount)},
		{Label: "Compose projects", Value: strconv.Itoa(host.ComposeProjectCount)},
	}))
	if len(view.Containers) == 0 {
		out.WriteString(paragraph("Docker este instalat, dar nu există containere în inventarul curent.", "IntenseQuote"))
		return out.String()
	}
	rows := make([][]string, 0, len(view.Containers))
	for _, c := range view.Containers {
		compose := strings.Trim(strings.Join(nonEmpty(c.ComposeProject, c.ComposeService), " / "), " /")
		flags := make([]string, 0)
		if c.Privileged {
			flags = append(flags, "privileged")
		}
		if c.DockerSocketMounted {
			flags = append(flags, "docker.sock")
		}
		if c.NetworkMode == "host" {
			flags = append(flags, "host network")
		}
		if c.ReadonlyRootFS {
			flags = append(flags, "read-only")
		}
		rows = append(rows, []string{c.Name, c.Image, firstNonEmpty(compose, "—"), firstNonEmpty(c.State, c.Status, "—"), dockerPortSummary(c.Ports), dockerAssignmentNames(c.ServiceAssignments), firstNonEmpty(strings.Join(flags, ", "), "standard")})
	}
	out.WriteString(tableWithWidths([]string{"Container", "Imagine", "Compose", "Stare", "Porturi", "Servicii", "Indicatori"}, rows, []int{1450, 1750, 1300, 900, 1500, 1500, 1100}))
	return out.String()
}

func boolLabel(value bool) string {
	if value {
		return "activ"
	}
	return "inactiv"
}

func documentBodyXML(data GenerationData) string {
	var out strings.Builder
	out.WriteString(infoParagraph("Număr document", data.DocumentNumber))
	out.WriteString(infoParagraph("Generat la", formatTime(data.GeneratedAt)))
	out.WriteString(infoParagraph("Generat de", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)))
	out.WriteString(heading("1. Identificare și resurse", 1))
	out.WriteString(keyValueTable(identityPreviewRows(data)))
	out.WriteString(heading("2. Încadrare operațională", 1))
	out.WriteString(keyValueTable(operationalPreviewRows(data)))
	out.WriteString(heading("3. Servicii interne și roluri tehnice", 1))
	if len(data.Operational.ServiceAssignments) == 0 {
		out.WriteString(paragraph("Nu există servicii interne asociate.", "IntenseQuote"))
	} else {
		head := []string{"Domeniu", "Categorie", "Serviciu intern", "Layer", "Rol tehnic", "Tip soluție", "Utilizare", "Principal"}
		rows := make([][]string, 0, len(data.Operational.ServiceAssignments))
		for _, item := range data.Operational.ServiceAssignments {
			primary := "Nu"
			if item.Primary {
				primary = "Da"
			}
			rows = append(rows, []string{item.ArchitecturalDomain, item.ITILCategory, item.InternalServiceName, item.LayerName, item.TechnicalRole, item.SolutionType, item.UsageType, primary})
		}
		out.WriteString(table(head, rows))
	}
	out.WriteString(heading("4. Componente software principale", 1))
	if len(data.PrimaryServices) == 0 {
		out.WriteString(paragraph("Nu au fost marcate servicii software principale din inventarul agentului.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(data.PrimaryServices))
		for _, item := range data.PrimaryServices {
			software := firstNonEmpty(item.SoftwareName, strings.TrimSuffix(item.ServiceName, ".service"), item.ServiceName)
			version := firstNonEmpty(item.Version, "—")
			packageVersion := strings.TrimSpace(strings.Join(nonEmpty(item.PackageName, item.PackageVersion), " · "))
			state := strings.TrimSpace(strings.Join(nonEmpty(item.ActiveState, item.EnabledState), " · "))
			if !item.Detected {
				state = "Nedetectat în inventarul curent"
			}
			rows = append(rows, []string{software, item.ServiceName, version, packageVersion, state})
		}
		out.WriteString(tableWithWidths([]string{"Software", "Serviciu", "Versiune", "Pachet", "Stare"}, rows, []int{1900, 2100, 1500, 2200, 1300}))
	}
	out.WriteString(heading("4.1 Porturi și procese principale", 2))
	if len(data.PrimaryPorts) == 0 {
		out.WriteString(paragraph("Nu au fost marcate porturi sau procese principale din inventarul agentului.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(data.PrimaryPorts))
		for _, item := range data.PrimaryPorts {
			process := firstNonEmpty(item.ProcessName, "—")
			pids := make([]string, 0, len(item.PIDs))
			for _, pid := range item.PIDs {
				pids = append(pids, strconv.Itoa(pid))
			}
			addresses := strings.Join(item.Addresses, ", ")
			state := "Detectat"
			if !item.Detected {
				state = "Nedetectat în inventarul curent"
			}
			rows = append(rows, []string{strconv.Itoa(item.Port), strings.ToUpper(item.Protocol), process, firstNonEmpty(strings.Join(pids, ", "), "—"), firstNonEmpty(item.Executable, "—"), firstNonEmpty(addresses, "—"), state})
		}
		out.WriteString(tableWithWidths([]string{"Port", "Protocol", "Proces", "PID", "Executabil", "Adresă listen", "Stare"}, rows, []int{700, 850, 1450, 900, 2300, 1600, 1200}))
	}
	out.WriteString(heading("5. Dependențe infrastructură comună", 1))
	if len(data.CommonDependencies) == 0 {
		out.WriteString(paragraph("Nu sunt declarate dependențe comune sau globale pentru această VM.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(data.CommonDependencies))
		for _, item := range data.CommonDependencies {
			character := "Comun"
			if item.Global {
				character = "Global"
			}
			source := firstNonEmpty(item.SourceLabel, item.SourceServiceName, "—")
			provider := item.TargetVMNames
			if provider == "" {
				provider = fmt.Sprintf("%d VM", item.TargetVMCount)
			}
			rows = append(rows, []string{item.TargetServiceName, item.DependencyType, provider, character, source, item.Notes})
		}
		out.WriteString(tableWithWidths([]string{"Serviciu comun", "Tip dependență", "VM-uri furnizor", "Caracter", "Proveniență", "Detalii"}, rows, []int{1800, 1700, 1900, 950, 1550, 1700}))
	}
	out.WriteString(heading("5.1 Conexiuni către sisteme externe", 2))
	out.WriteString(externalConnectionsTableXML(data.ExternalConnections, false))
	out.WriteString(heading("6. Responsabilități", 1))
	if len(data.Operational.Responsibilities) == 0 {
		out.WriteString(paragraph("Nu există responsabilități definite.", "IntenseQuote"))
	} else {
		head := []string{"Rol", "Persoană", "Departament", "Email", "Telefon", "Detalii"}
		rows := make([][]string, 0, len(data.Operational.Responsibilities))
		for _, item := range data.Operational.Responsibilities {
			rows = append(rows, []string{responsibilityLabel(item.ResponsibilityType), item.PersonName, item.PersonDepartment, item.PersonEmail, item.PersonPhone, item.Notes})
		}
		out.WriteString(table(head, rows))
	}
	out.WriteString(heading("7. Backup și restaurare", 1))
	out.WriteString(keyValueTable(backupPreviewRows(data)))
	sectionNumber := 8
	if hasDockerDocumentData(data.Docker) {
		out.WriteString(heading(fmt.Sprintf("%d. Docker și containere", sectionNumber), 1))
		out.WriteString(dockerDocumentXML(data.Docker))
		sectionNumber++
	}
	if hasDatabaseDocumentData(data.Databases) {
		out.WriteString(heading(fmt.Sprintf("%d. Baze de date", sectionNumber), 1))
		out.WriteString(databaseDocumentXML(data.Databases))
		sectionNumber++
	}
	if hasWebDocumentData(data.Web) {
		out.WriteString(heading(fmt.Sprintf("%d. Site-uri web și frontends", sectionNumber), 1))
		out.WriteString(webDocumentXML(data.Web))
		sectionNumber++
	}
	out.WriteString(heading(fmt.Sprintf("%d. Inventar agent", sectionNumber), 1))
	if data.Inventory == nil {
		out.WriteString(paragraph("Nu există inventar curent pentru această VM.", "IntenseQuote"))
	} else {
		out.WriteString(keyValueTable([]PreviewRow{{Label: "Snapshot", Value: strconv.FormatInt(data.Inventory.ID, 10)}, {Label: "Hostname", Value: data.Inventory.Hostname}, {Label: "FQDN", Value: data.Inventory.FQDN}, {Label: "OS", Value: strings.TrimSpace(data.Inventory.OSName + " " + data.Inventory.OSVersion)}, {Label: "IP principal", Value: data.Inventory.PrimaryIP}, {Label: "Primit la", Value: formatTime(data.Inventory.ReceivedAt)}, {Label: "Colectori OK", Value: fmt.Sprintf("%d din %d", data.Inventory.CollectorOK, data.Inventory.CollectorTotal)}, {Label: "Versiune agent", Value: data.Inventory.AgentVersion}}))
	}
	if data.InventoryDocument != nil {
		out.WriteString(compactInventoryXML(data.InventoryDocument, strconv.Itoa(sectionNumber)))
	}
	out.WriteString(paragraph("Document generat automat de vm-doc-server. Datele trebuie validate conform procedurilor interne înainte de aprobare.", "IntenseQuote"))
	return out.String()
}

func flattenValue(value any, limit int) []PreviewRow {
	rows := make([]PreviewRow, 0)
	var walk func(path string, item any)
	walk = func(path string, item any) {
		if len(rows) >= limit {
			return
		}
		switch typed := item.(type) {
		case map[string]any:
			keys := make([]string, 0, len(typed))
			for key := range typed {
				keys = append(keys, key)
			}
			sort.Strings(keys)
			for _, key := range keys {
				child := key
				if path != "" {
					child = path + " / " + key
				}
				walk(child, typed[key])
			}
		case []any:
			if len(typed) == 0 {
				rows = append(rows, PreviewRow{Label: displayPath(path), Value: "Listă goală"})
				return
			}
			for index, child := range typed {
				walk(fmt.Sprintf("%s [%d]", path, index+1), child)
			}
		default:
			rows = append(rows, PreviewRow{Label: displayPath(path), Value: stringify(item)})
		}
	}
	walk("", value)
	if len(rows) >= limit {
		rows = append(rows, PreviewRow{Label: "Observație", Value: fmt.Sprintf("Secțiunea a fost limitată la %d poziții.", limit)})
	}
	return rows
}

func stringify(value any) string {
	switch typed := value.(type) {
	case nil:
		return "—"
	case string:
		return typed
	case bool:
		if typed {
			return "Da"
		}
		return "Nu"
	case json.Number:
		return typed.String()
	case float64:
		return strconv.FormatFloat(typed, 'f', -1, 64)
	default:
		encoded, err := json.Marshal(typed)
		if err == nil {
			return string(encoded)
		}
		return fmt.Sprint(typed)
	}
}

func displayPath(path string) string {
	path = strings.TrimSpace(path)
	if path == "" {
		return "Valoare"
	}
	parts := strings.Split(path, " / ")
	for index, part := range parts {
		parts[index] = strings.ReplaceAll(strings.ReplaceAll(part, "_", " "), "-", " ")
	}
	return strings.Join(parts, " / ")
}

func heading(text string, level int) string {
	if level > 1 {
		// Keep Heading2 semantics for TOC/styles, but make the hierarchy visible
		// even when the uploaded template defines Heading2 with no left indent.
		return `<w:p><w:pPr><w:pStyle w:val="Heading2"/><w:ind w:left="360"/></w:pPr><w:r><w:t xml:space="preserve">` + xmlText(text) + `</w:t></w:r></w:p>`
	}
	return paragraph(text, "Heading1")
}

func infoParagraph(label, value string) string {
	return `<w:p><w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">` + xmlText(label+": ") + `</w:t></w:r><w:r><w:t>` + xmlText(emptyDash(value)) + `</w:t></w:r></w:p>`
}

func paragraph(text, style string) string {
	var properties string
	if style != "" {
		properties = `<w:pPr><w:pStyle w:val="` + xmlText(style) + `"/></w:pPr>`
	}
	return `<w:p>` + properties + `<w:r><w:t xml:space="preserve">` + xmlText(text) + `</w:t></w:r></w:p>`
}

func keyValueTable(rows []PreviewRow) string {
	tableRows := make([][]string, 0, len(rows))
	for _, row := range rows {
		tableRows = append(tableRows, []string{row.Label, emptyDash(row.Value)})
	}
	return tableWithWidths([]string{"Câmp", "Valoare"}, tableRows, []int{3000, 6000})
}

func table(headers []string, rows [][]string) string {
	columns := len(headers)
	for _, row := range rows {
		if len(row) > columns {
			columns = len(row)
		}
	}
	if columns == 0 {
		return ""
	}
	widths := make([]int, columns)
	base := inventoryTableWidth / columns
	for index := range widths {
		widths[index] = base
	}
	widths[len(widths)-1] += inventoryTableWidth - base*columns
	return tableWithWidths(headers, rows, widths)
}

func tableWithWidths(headers []string, rows [][]string, widths []int) string {
	columns := len(widths)
	if columns == 0 {
		return ""
	}
	var out strings.Builder
	out.WriteString(`<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="` + strconv.Itoa(inventoryTableWidth) + `" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr><w:tblGrid>`)
	for _, width := range widths {
		out.WriteString(`<w:gridCol w:w="` + strconv.Itoa(width) + `"/>`)
	}
	out.WriteString(`</w:tblGrid>`)
	if len(headers) > 0 {
		out.WriteString(`<w:tr><w:trPr><w:tblHeader/></w:trPr>`)
		for index := 0; index < columns; index++ {
			value := ""
			if index < len(headers) {
				value = headers[index]
			}
			out.WriteString(tableCell(value, true, widths[index]))
		}
		out.WriteString(`</w:tr>`)
	}
	for _, row := range rows {
		out.WriteString(`<w:tr><w:trPr><w:cantSplit/></w:trPr>`)
		for index := 0; index < columns; index++ {
			value := ""
			if index < len(row) {
				value = row[index]
			}
			out.WriteString(tableCell(emptyDash(value), false, widths[index]))
		}
		out.WriteString(`</w:tr>`)
	}
	out.WriteString(`</w:tbl><w:p/>`)
	return out.String()
}

func tableCell(value string, bold bool, width int) string {
	runProperties := ""
	if bold {
		runProperties = `<w:rPr><w:b/></w:rPr>`
	}
	return `<w:tc><w:tcPr><w:tcW w:w="` + strconv.Itoa(width) + `" w:type="dxa"/><w:vAlign w:val="top"/></w:tcPr><w:p><w:r>` + runProperties + `<w:t xml:space="preserve">` + xmlText(value) + `</w:t></w:r></w:p></w:tc>`
}

func xmlText(value string) string {
	return html.EscapeString(strings.ToValidUTF8(value, "�"))
}

func updateCoreProperties(text string, data GenerationData) string {
	text = replaceXMLTag(text, "dc:title", "Fișă tehnică VM — "+data.VM.Name)
	text = replaceXMLTag(text, "dc:creator", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username, "vm-doc-server"))
	text = replaceXMLTag(text, "cp:lastModifiedBy", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username, "vm-doc-server"))
	text = replaceXMLTag(text, "dcterms:modified", data.GeneratedAt.UTC().Format(time.RFC3339))
	return text
}

func replaceXMLTag(text, tag, value string) string {
	pattern := regexp.MustCompile(`(?s)<` + regexp.QuoteMeta(tag) + `([^>]*)>.*?</` + regexp.QuoteMeta(tag) + `>`)
	match := pattern.FindStringSubmatchIndex(text)
	if match == nil {
		return text
	}
	attributes := ""
	if len(match) >= 4 && match[2] >= 0 {
		attributes = text[match[2]:match[3]]
	}
	replacement := `<` + tag + attributes + `>` + xmlText(value) + `</` + tag + `>`
	return text[:match[0]] + replacement + text[match[1]:]
}

func readZipFile(file *zip.File, max int64) ([]byte, error) {
	reader, err := file.Open()
	if err != nil {
		return nil, err
	}
	defer reader.Close()
	limited := io.LimitReader(reader, max+1)
	content, err := io.ReadAll(limited)
	if err != nil {
		return nil, err
	}
	if int64(len(content)) > max {
		return nil, fmt.Errorf("DOCX part %s is too large", file.Name)
	}
	return content, nil
}

func formatTime(value time.Time) string {
	if value.IsZero() {
		return "—"
	}
	return value.Local().Format("02.01.2006 15:04:05")
}

func formatTimePtr(value *time.Time) string {
	if value == nil {
		return "—"
	}
	return formatTime(*value)
}

func formatMemory(mib int64) string {
	if mib <= 0 {
		return "—"
	}
	return fmt.Sprintf("%.1f GB", float64(mib)/1024)
}

func formatIntPtr(value *int) string {
	if value == nil {
		return "—"
	}
	return strconv.Itoa(*value)
}

func formatMinutes(value *int) string {
	if value == nil {
		return "—"
	}
	if *value%1440 == 0 && *value > 0 {
		return fmt.Sprintf("%d zile", *value/1440)
	}
	if *value%60 == 0 && *value > 0 {
		return fmt.Sprintf("%d ore", *value/60)
	}
	return fmt.Sprintf("%d minute", *value)
}

func responsibilityLabel(value string) string {
	labels := map[string]string{
		"technical_admin":      "Administrator tehnic",
		"service_owner":        "Responsabil serviciu",
		"business_owner":       "Responsabil business",
		"application_owner":    "Responsabil aplicație",
		"infrastructure_owner": "Responsabil infrastructură",
		"security_contact":     "Contact securitate",
		"backup_contact":       "Contact backup",
		"other":                "Altă responsabilitate",
	}
	if label := labels[value]; label != "" {
		return label
	}
	return value
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}

func nonEmpty(values ...string) []string {
	result := make([]string, 0, len(values))
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			result = append(result, strings.TrimSpace(value))
		}
	}
	return result
}

func emptyDash(value string) string {
	if strings.TrimSpace(value) == "" {
		return "—"
	}
	return value
}

const stylesXML = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="ro-RO"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="240"/><w:jc w:val="center"/></w:pPr><w:rPr><w:b/><w:sz w:val="36"/><w:szCs w:val="36"/><w:color w:val="1F4E78"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="260" w:after="120"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:sz w:val="28"/><w:szCs w:val="28"/><w:color w:val="1F4E78"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="180" w:after="80"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:sz w:val="24"/><w:szCs w:val="24"/><w:color w:val="2F5597"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="IntenseQuote"><w:name w:val="Intense Quote"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:ind w:left="432" w:right="432"/><w:spacing w:before="120" w:after="120"/></w:pPr><w:rPr><w:i/><w:color w:val="666666"/></w:rPr></w:style><w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:uiPriority w:val="59"/><w:semiHidden/><w:unhideWhenUsed/><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="B7C9E2"/><w:left w:val="single" w:sz="4" w:space="0" w:color="B7C9E2"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="B7C9E2"/><w:right w:val="single" w:sz="4" w:space="0" w:color="B7C9E2"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="D9E2F3"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="D9E2F3"/></w:tblBorders><w:tblCellMar><w:top w:w="80" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style></w:styles>`
