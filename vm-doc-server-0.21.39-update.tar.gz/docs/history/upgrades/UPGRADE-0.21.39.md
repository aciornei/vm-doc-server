# Upgrade VM-DOC Server 0.21.38 → 0.21.39

## Înainte de actualizare

1. Fă backup la MariaDB și salvează binarul/sursele 0.21.38.
2. Folosește `vm-doc-server-0.21.38-to-0.21.39.patch` sau `vm-doc-server-0.21.39-update.tar.gz` peste o **copie** a surselor 0.21.38.
3. Păstrează directorul `vendor/` din mediul offline; pachetele livrate nu conțin module externe și nici executabil Go precompilat.

## Aplicare

```bash
cp -a vm-doc-server-0.21.38 vm-doc-server-0.21.39
cd vm-doc-server-0.21.39
tar -xzf /cale/vm-doc-server-0.21.39-update.tar.gz
cat VERSION  # 0.21.39
bash scripts/cleanup-source-tree.sh --check
GOPROXY=off GOSUMDB=off go test ./...
GOPROXY=off GOSUMDB=off make build
```

**Nu rula update-ul peste un arbore care conține surse mai vechi amestecate.** Acest upgrade este aditiv: UI + un endpoint XLSX. Nu modifică schema SQL, fișierele de configurare, agentul sau politicile de publicare.

## Probe în staging

- Deschide Web Access Control cu mai multe site-uri: cele cu ACL în față și expandate, cele fără ACL închise, chiar dacă sunt nerevizuite.
- Verifică faptul că textul „Fără ACL explicit” apare o singură dată și că „Revizuiește” din antet nu acționează expandarea.
- Testează revizia individuală și colectivă, filtrele, paginarea și linkurile către VM.
- Export Excel global și pentru o VM: workbook cu `Site-uri` (inclusiv fără ACL) și `Reguli ACL` (dacă există); numără toate regulile, confirmă fișierele sursă.
- Repetă la 1595, 1024 și 390 px; evaluează memoria Chrome pe dataset real.

## Rollback

Restaurează binarul 0.21.38 și sursele vechi. Nu este necesar rollback SQL. Reviziile salvate în timpul 0.21.39 rămân în baza de date.

## Validare de dezvoltare

- `node --check` și `go test` pentru pachetele independente au trecut.
- Chromium mock la 1595/1024/390 a trecut verificările structurale și click.
- Testele complete `internal/server`/MariaDB/release pe serverul offline cu vendor lipsesc; nu presupune instalare validată.
