package server

import (
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/xlsx"
)

// securityWebWorkbook exports each vhost, including those without explicit
// allow/deny rules. Separate rules worksheet preserves the exact source of
// every directive instead of conflating inherited or implicit access policy.
func securityWebWorkbook(sites []securityWebSite) []xlsx.Sheet {
	vhosts := xlsx.Sheet{Name: "Site-uri", Rows: [][]xlsx.Cell{{
		xlsx.Text("VM"), xlsx.Text("Motor"), xlsx.Text("Site / VHost"),
		xlsx.Text("Server names"), xlsx.Text("Config principal"),
		xlsx.Text("ACL explicit"), xlsx.Text("Număr reguli"), xlsx.Text("ALLOW ALL"),
		xlsx.Text("Ultima revizie"), xlsx.Text("Next review"), xlsx.Text("Revizuit de"),
		xlsx.Text("Justificat"),
	}}}
	rules := xlsx.Sheet{Name: "Reguli ACL", Rows: [][]xlsx.Cell{{
		xlsx.Text("VM"), xlsx.Text("Motor"), xlsx.Text("Site / VHost"),
		xlsx.Text("Acțiune"), xlsx.Text("Sursă / adresă"), xlsx.Text("Scope"),
		xlsx.Text("Directivă"), xlsx.Text("Fișier sursă"), xlsx.Text("ALLOW ALL"),
	}}}
	stamp := func(t *time.Time) string {
		if t == nil {
			return ""
		}
		return t.UTC().Format(time.RFC3339)
	}
	yes := func(value bool) string {
		if value {
			return "Da"
		}
		return "Nu"
	}
	for _, site := range sites {
		warn := false
		for _, rule := range site.Rules {
			if webAllowAll(rule) {
				warn = true
			}
			rules.Rows = append(rules.Rows, []xlsx.Cell{
				xlsx.Text(site.VMName), xlsx.Text(site.Engine), xlsx.Text(site.Name),
				xlsx.Text(rule.Action), xlsx.Text(rule.Source), xlsx.Text(rule.Scope),
				xlsx.Text(rule.Directive), xlsx.Text(rule.SourceFile), xlsx.Text(yes(webAllowAll(rule))),
			})
		}
		justified := ""
		if site.Review.ReviewedAt != nil {
			justified = yes(site.Review.Justified)
		}
		vhosts.Rows = append(vhosts.Rows, []xlsx.Cell{
			xlsx.Text(site.VMName), xlsx.Text(site.Engine), xlsx.Text(site.Name),
			xlsx.Text(strings.Join(site.ServerNames, ", ")), xlsx.Text(site.ConfigFile),
			xlsx.Text(yes(len(site.Rules) > 0)), xlsx.Number(float64(len(site.Rules))), xlsx.Text(yes(warn)),
			xlsx.Text(stamp(site.Review.ReviewedAt)), xlsx.Text(stamp(site.Review.NextReviewAt)),
			xlsx.Text(site.Review.ReviewedBy), xlsx.Text(justified),
		})
	}
	result := []xlsx.Sheet{vhosts}
	if len(rules.Rows) > 1 {
		result = append(result, rules)
	}
	return result
}

// Inventory is loaded from MariaDB on demand, never from the paged JS cache.
func (a *App) exportSecurityWeb(w http.ResponseWriter, r *http.Request) {
	var vmID int64
	if raw := strings.TrimSpace(r.URL.Query().Get("vm_id")); raw != "" {
		id, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || id <= 0 {
			badRequest(w, fmt.Errorf("vm_id invalid"))
			return
		}
		vmID = id
	}
	reviews, err := a.loadSecurityReviews(r.Context())
	if err != nil {
		respond(w, nil, err)
		return
	}
	result := securityResponse{}
	if err := a.loadSecurityWeb(r.Context(), reviews, &result, vmID); err != nil {
		respond(w, nil, err)
		return
	}
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="vm-doc-security-web-acl-%s.xlsx"`, time.Now().Format("20060102-150405")))
	if err := xlsx.WriteSheets(w, securityWebWorkbook(result.WebSites)); err != nil && a.Logger != nil {
		a.Logger.Error("web access control export XLSX", "error", err)
	}
}
