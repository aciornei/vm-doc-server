package server

import (
	"testing"
	"time"
)

func TestSecurityWebWorkbookIncludesNoACLAndSource(t *testing.T) {
	now := time.Date(2026, 10, 19, 7, 0, 0, 0, time.UTC)
	sites := []securityWebSite{
		{VMName: "web-01", Name: "no-acl", Engine: "nginx"},
		{VMName: "web-02", Name: "restricted", Engine: "apache", Rules: []securityWebRule{
			{Action: "allow", Source: "10.0.0.0/8", Directive: "Require ip", Scope: "location /", SourceFile: "/etc/apache2/site.conf"},
			{Action: "deny", Source: "all", Directive: "Require not ip", SourceFile: "/etc/apache2/site.conf"},
		}, Review: securityReview{ReviewedAt: &now, Justified: true, ReviewedBy: "admin"}},
	}
	sheets := securityWebWorkbook(sites)
	if len(sheets) != 2 {
		t.Fatalf("expected 2 sheets, got %d", len(sheets))
	}
	if sheets[0].Name != "Site-uri" || len(sheets[0].Rows) != 3 {
		t.Fatalf("sites missing, sheets=%v rows=%d", sheets[0].Name, len(sheets[0].Rows))
	}
	if sheets[1].Name != "Reguli ACL" || len(sheets[1].Rows) != 3 {
		t.Fatalf("rules missing: %v rows=%d", sheets[1].Name, len(sheets[1].Rows))
	}
	if sheets[1].Rows[1][7].Text != "/etc/apache2/site.conf" {
		t.Fatal("rule source file lost")
	}
	if got := securityWebWorkbook(sites[:1]); len(got) != 1 || len(got[0].Rows) != 2 {
		t.Fatalf("no ACL must preserve site, got %+v", got)
	}
}
