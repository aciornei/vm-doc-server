package equipment

import (
	"context"
	"database/sql"
	"errors"
	"net/url"
	"strings"

	"vm-doc-server/internal/domain"
)

type Service struct{ DB *sql.DB }

type DeviceInput struct {
	Name                string `json:"name"`
	DeviceTypeID        *int64 `json:"device_type_id,omitempty"`
	Manufacturer        string `json:"manufacturer"`
	Model               string `json:"model"`
	SerialNumber        string `json:"serial_number"`
	Hostname            string `json:"hostname"`
	IPAddresses         string `json:"ip_addresses"`
	MACAddress          string `json:"mac_address"`
	Location            string `json:"location"`
	ResponsiblePersonID *int64 `json:"responsible_person_id,omitempty"`
	Description         string `json:"description"`
	Notes               string `json:"notes"`
	DocumentationURL    string `json:"documentation_url"`
	Active              *bool  `json:"active,omitempty"`
}

type AssignmentInput struct {
	InternalServiceID int64  `json:"internal_service_id"`
	RoleName          string `json:"role_name"`
	Protocol          string `json:"protocol"`
	Port              *int   `json:"port,omitempty"`
	Direction         string `json:"direction"`
	Purpose           string `json:"purpose"`
	Notes             string `json:"notes"`
	Active            *bool  `json:"active,omitempty"`
}

func (s Service) List(ctx context.Context, q, active string, deviceTypeID *int64) ([]domain.EquipmentDevice, error) {
	where := []string{"1=1"}
	args := make([]any, 0, 10)
	q = strings.TrimSpace(q)
	if q != "" {
		like := "%" + q + "%"
		where = append(where, `(d.name LIKE ? OR d.manufacturer LIKE ? OR d.model LIKE ? OR d.serial_number LIKE ? OR d.hostname LIKE ? OR d.ip_addresses LIKE ? OR d.mac_address LIKE ? OR d.location LIKE ? OR d.description LIKE ?)`)
		for i := 0; i < 9; i++ {
			args = append(args, like)
		}
	}
	if deviceTypeID != nil && *deviceTypeID > 0 {
		where = append(where, "d.device_type_id=?")
		args = append(args, *deviceTypeID)
	}
	switch strings.ToLower(strings.TrimSpace(active)) {
	case "active", "1", "true":
		where = append(where, "d.active=1")
	case "inactive", "0", "false":
		where = append(where, "d.active=0")
	}
	rows, err := s.DB.QueryContext(ctx, deviceSelect+" WHERE "+strings.Join(where, " AND ")+" ORDER BY d.active DESC,d.name,d.id", args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.EquipmentDevice, 0)
	for rows.Next() {
		v, err := scanDevice(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

func (s Service) Get(ctx context.Context, id int64) (domain.EquipmentDevice, error) {
	v, err := scanDevice(s.DB.QueryRowContext(ctx, deviceSelect+" WHERE d.id=?", id))
	if err != nil {
		return domain.EquipmentDevice{}, err
	}
	v.Services, err = s.ListAssignmentsForDevice(ctx, id, false)
	return v, err
}

func (s Service) Create(ctx context.Context, userID int64, input DeviceInput) (domain.EquipmentDevice, error) {
	if err := s.normalizeDevice(ctx, &input); err != nil {
		return domain.EquipmentDevice{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO equipment_devices(name,device_type_id,manufacturer,model,serial_number,hostname,ip_addresses,mac_address,location,responsible_person_id,description,notes,documentation_url,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, input.Name, nullableInt64(input.DeviceTypeID), input.Manufacturer, input.Model, input.SerialNumber, input.Hostname, input.IPAddresses, input.MACAddress, input.Location, nullableInt64(input.ResponsiblePersonID), input.Description, input.Notes, input.DocumentationURL, active, nullableUser(userID), nullableUser(userID))
	if err != nil {
		return domain.EquipmentDevice{}, err
	}
	id, err := res.LastInsertId()
	if err != nil {
		return domain.EquipmentDevice{}, err
	}
	return s.Get(ctx, id)
}

func (s Service) Update(ctx context.Context, id, userID int64, input DeviceInput) (domain.EquipmentDevice, error) {
	current, err := s.Get(ctx, id)
	if err != nil {
		return domain.EquipmentDevice{}, err
	}
	if strings.TrimSpace(input.Name) == "" {
		input.Name = current.Name
	}
	if input.Active == nil {
		v := current.Active
		input.Active = &v
	}
	if err := s.normalizeDevice(ctx, &input); err != nil {
		return domain.EquipmentDevice{}, err
	}
	if _, err := s.DB.ExecContext(ctx, `UPDATE equipment_devices SET name=?,device_type_id=?,manufacturer=?,model=?,serial_number=?,hostname=?,ip_addresses=?,mac_address=?,location=?,responsible_person_id=?,description=?,notes=?,documentation_url=?,active=?,updated_by=? WHERE id=?`, input.Name, nullableInt64(input.DeviceTypeID), input.Manufacturer, input.Model, input.SerialNumber, input.Hostname, input.IPAddresses, input.MACAddress, input.Location, nullableInt64(input.ResponsiblePersonID), input.Description, input.Notes, input.DocumentationURL, *input.Active, nullableUser(userID), id); err != nil {
		return domain.EquipmentDevice{}, err
	}
	return s.Get(ctx, id)
}

func (s Service) Delete(ctx context.Context, id int64) error {
	res, err := s.DB.ExecContext(ctx, `DELETE FROM equipment_devices WHERE id=?`, id)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) ListAssignmentsForDevice(ctx context.Context, equipmentID int64, activeOnly bool) ([]domain.EquipmentServiceAssignment, error) {
	query := assignmentSelect + ` WHERE a.equipment_id=?`
	if activeOnly {
		query += ` AND a.active=1`
	}
	query += ` ORDER BY a.active DESC,svc.name,a.id`
	return s.listAssignments(ctx, query, equipmentID)
}

func (s Service) ListForService(ctx context.Context, serviceID int64, activeOnly bool) ([]domain.EquipmentServiceAssignment, error) {
	query := assignmentSelect + ` WHERE a.internal_service_id=?`
	if activeOnly {
		query += ` AND a.active=1 AND d.active=1`
	}
	query += ` ORDER BY d.name,a.id`
	return s.listAssignments(ctx, query, serviceID)
}

func (s Service) GetAssignment(ctx context.Context, equipmentID, assignmentID int64) (domain.EquipmentServiceAssignment, error) {
	return scanAssignment(s.DB.QueryRowContext(ctx, assignmentSelect+` WHERE a.id=? AND a.equipment_id=?`, assignmentID, equipmentID))
}

func (s Service) CreateAssignment(ctx context.Context, equipmentID, userID int64, input AssignmentInput) (domain.EquipmentServiceAssignment, error) {
	if err := s.normalizeAssignment(ctx, equipmentID, &input); err != nil {
		return domain.EquipmentServiceAssignment{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO equipment_service_assignments(equipment_id,internal_service_id,role_name,protocol,port,direction,purpose,notes,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)`, equipmentID, input.InternalServiceID, input.RoleName, input.Protocol, nullableInt(input.Port), input.Direction, input.Purpose, input.Notes, active, nullableUser(userID), nullableUser(userID))
	if err != nil {
		return domain.EquipmentServiceAssignment{}, err
	}
	id, err := res.LastInsertId()
	if err != nil {
		return domain.EquipmentServiceAssignment{}, err
	}
	return s.GetAssignment(ctx, equipmentID, id)
}

func (s Service) UpdateAssignment(ctx context.Context, equipmentID, assignmentID, userID int64, input AssignmentInput) (domain.EquipmentServiceAssignment, error) {
	current, err := s.GetAssignment(ctx, equipmentID, assignmentID)
	if err != nil {
		return domain.EquipmentServiceAssignment{}, err
	}
	if input.InternalServiceID == 0 {
		input.InternalServiceID = current.InternalServiceID
	}
	if strings.TrimSpace(input.Direction) == "" {
		input.Direction = current.Direction
	}
	if input.Active == nil {
		v := current.Active
		input.Active = &v
	}
	if err := s.normalizeAssignment(ctx, equipmentID, &input); err != nil {
		return domain.EquipmentServiceAssignment{}, err
	}
	if _, err := s.DB.ExecContext(ctx, `UPDATE equipment_service_assignments SET internal_service_id=?,role_name=?,protocol=?,port=?,direction=?,purpose=?,notes=?,active=?,updated_by=? WHERE id=? AND equipment_id=?`, input.InternalServiceID, input.RoleName, input.Protocol, nullableInt(input.Port), input.Direction, input.Purpose, input.Notes, *input.Active, nullableUser(userID), assignmentID, equipmentID); err != nil {
		return domain.EquipmentServiceAssignment{}, err
	}
	return s.GetAssignment(ctx, equipmentID, assignmentID)
}

func (s Service) DeleteAssignment(ctx context.Context, equipmentID, assignmentID int64) error {
	res, err := s.DB.ExecContext(ctx, `DELETE FROM equipment_service_assignments WHERE id=? AND equipment_id=?`, assignmentID, equipmentID)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) listAssignments(ctx context.Context, query string, args ...any) ([]domain.EquipmentServiceAssignment, error) {
	rows, err := s.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.EquipmentServiceAssignment, 0)
	for rows.Next() {
		v, err := scanAssignment(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

func (s Service) normalizeDevice(ctx context.Context, input *DeviceInput) error {
	input.Name = strings.TrimSpace(input.Name)
	input.Manufacturer = strings.TrimSpace(input.Manufacturer)
	input.Model = strings.TrimSpace(input.Model)
	input.SerialNumber = strings.TrimSpace(input.SerialNumber)
	input.Hostname = strings.TrimSpace(input.Hostname)
	input.IPAddresses = strings.TrimSpace(input.IPAddresses)
	input.MACAddress = strings.TrimSpace(input.MACAddress)
	input.Location = strings.TrimSpace(input.Location)
	input.Description = strings.TrimSpace(input.Description)
	input.Notes = strings.TrimSpace(input.Notes)
	input.DocumentationURL = strings.TrimSpace(input.DocumentationURL)
	if input.Name == "" {
		return errors.New("equipment name is required")
	}
	if len([]rune(input.Name)) > 255 || len([]rune(input.IPAddresses)) > 1024 || len([]rune(input.Notes)) > 10000 {
		return errors.New("equipment field is too long")
	}
	if input.DocumentationURL != "" {
		u, err := url.Parse(input.DocumentationURL)
		if err != nil || u.Scheme == "" || u.Host == "" {
			return errors.New("documentation_url must be an absolute URL")
		}
	}
	if input.DeviceTypeID != nil {
		var count int
		if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM nomenclature_items WHERE id=? AND category_code='device_type'`, *input.DeviceTypeID).Scan(&count); err != nil {
			return err
		}
		if count == 0 {
			return errors.New("invalid device_type_id")
		}
	}
	if input.ResponsiblePersonID != nil {
		var count int
		if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM people WHERE id=?`, *input.ResponsiblePersonID).Scan(&count); err != nil {
			return err
		}
		if count == 0 {
			return errors.New("invalid responsible_person_id")
		}
	}
	return nil
}

func (s Service) normalizeAssignment(ctx context.Context, equipmentID int64, input *AssignmentInput) error {
	input.RoleName = strings.TrimSpace(input.RoleName)
	input.Protocol = strings.TrimSpace(input.Protocol)
	input.Direction = strings.ToLower(strings.TrimSpace(input.Direction))
	input.Purpose = strings.TrimSpace(input.Purpose)
	input.Notes = strings.TrimSpace(input.Notes)
	if input.Direction == "" {
		input.Direction = "unspecified"
	}
	allowedDirections := map[string]bool{"unspecified": true, "device_to_service": true, "service_to_device": true, "bidirectional": true}
	if !allowedDirections[input.Direction] {
		return errors.New("invalid direction")
	}
	if equipmentID <= 0 || input.InternalServiceID <= 0 {
		return errors.New("equipment_id and internal_service_id are required")
	}
	if input.Port != nil && (*input.Port < 1 || *input.Port > 65535) {
		return errors.New("port must be between 1 and 65535")
	}
	if len([]rune(input.RoleName)) > 255 || len([]rune(input.Protocol)) > 64 || len([]rune(input.Purpose)) > 512 || len([]rune(input.Notes)) > 10000 {
		return errors.New("equipment assignment field is too long")
	}
	var deviceCount, serviceCount int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM equipment_devices WHERE id=?`, equipmentID).Scan(&deviceCount); err != nil {
		return err
	}
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM internal_services WHERE id=?`, input.InternalServiceID).Scan(&serviceCount); err != nil {
		return err
	}
	if deviceCount == 0 || serviceCount == 0 {
		return errors.New("equipment or internal service not found")
	}
	return nil
}

const deviceSelect = `SELECT d.id,d.name,d.device_type_id,COALESCE(t.name,''),d.manufacturer,d.model,d.serial_number,d.hostname,d.ip_addresses,d.mac_address,d.location,d.responsible_person_id,COALESCE(p.display_name,''),d.description,d.notes,d.documentation_url,d.active,(SELECT COUNT(*) FROM equipment_service_assignments a WHERE a.equipment_id=d.id AND a.active=1),d.created_at,d.updated_at FROM equipment_devices d LEFT JOIN nomenclature_items t ON t.id=d.device_type_id LEFT JOIN people p ON p.id=d.responsible_person_id`

func scanDevice(scanner interface{ Scan(...any) error }) (domain.EquipmentDevice, error) {
	var v domain.EquipmentDevice
	var typeID, personID sql.NullInt64
	err := scanner.Scan(&v.ID, &v.Name, &typeID, &v.DeviceType, &v.Manufacturer, &v.Model, &v.SerialNumber, &v.Hostname, &v.IPAddresses, &v.MACAddress, &v.Location, &personID, &v.ResponsiblePersonName, &v.Description, &v.Notes, &v.DocumentationURL, &v.Active, &v.ServiceCount, &v.CreatedAt, &v.UpdatedAt)
	if typeID.Valid {
		x := typeID.Int64
		v.DeviceTypeID = &x
	}
	if personID.Valid {
		x := personID.Int64
		v.ResponsiblePersonID = &x
	}
	return v, err
}

const assignmentSelect = `SELECT a.id,a.equipment_id,d.name,d.device_type_id,COALESCE(t.name,''),d.manufacturer,d.model,d.hostname,d.ip_addresses,d.location,a.internal_service_id,svc.name,a.role_name,a.protocol,a.port,a.direction,a.purpose,a.notes,a.active FROM equipment_service_assignments a JOIN equipment_devices d ON d.id=a.equipment_id LEFT JOIN nomenclature_items t ON t.id=d.device_type_id JOIN internal_services svc ON svc.id=a.internal_service_id`

func scanAssignment(scanner interface{ Scan(...any) error }) (domain.EquipmentServiceAssignment, error) {
	var v domain.EquipmentServiceAssignment
	var typeID sql.NullInt64
	var port sql.NullInt64
	err := scanner.Scan(&v.ID, &v.EquipmentID, &v.EquipmentName, &typeID, &v.DeviceType, &v.Manufacturer, &v.Model, &v.Hostname, &v.IPAddresses, &v.Location, &v.InternalServiceID, &v.InternalServiceName, &v.RoleName, &v.Protocol, &port, &v.Direction, &v.Purpose, &v.Notes, &v.Active)
	if typeID.Valid {
		x := typeID.Int64
		v.DeviceTypeID = &x
	}
	if port.Valid {
		x := int(port.Int64)
		v.Port = &x
	}
	return v, err
}

func nullableInt64(v *int64) any {
	if v == nil || *v <= 0 {
		return nil
	}
	return *v
}
func nullableInt(v *int) any {
	if v == nil || *v <= 0 {
		return nil
	}
	return *v
}
func nullableUser(id int64) any {
	if id <= 0 {
		return nil
	}
	return id
}
