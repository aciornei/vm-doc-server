package server

import (
	"errors"
	"net/http"
	"strconv"
	"strings"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/equipment"
)

func (a *App) listEquipment(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	var typeID *int64
	if raw := strings.TrimSpace(q.Get("device_type_id")); raw != "" {
		id, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || id <= 0 {
			badRequest(w, errors.New("invalid device_type_id"))
			return
		}
		typeID = &id
	}
	values, err := a.Equipment.List(r.Context(), q.Get("q"), q.Get("active"), typeID)
	respond(w, values, err)
}

func (a *App) getEquipment(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Equipment.Get(r.Context(), id)
	respond(w, value, err)
}

func (a *App) createEquipment(w http.ResponseWriter, r *http.Request) {
	var input equipment.DeviceInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Equipment.Create(r.Context(), user.ID, input)
	if err == nil {
		a.auditRequest(r, "equipment.create", "equipment_device", strconv.FormatInt(value.ID, 10), "success", map[string]any{"created": value})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updateEquipment(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, err := a.Equipment.Get(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	var input equipment.DeviceInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Equipment.Update(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "equipment.update", "equipment_device", strconv.FormatInt(id, 10), "success", map[string]any{"before": before, "after": value})
	}
	respond(w, value, err)
}

func (a *App) deleteEquipment(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	before, err := a.Equipment.Get(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.Equipment.Delete(r.Context(), id); err != nil {
		respond(w, nil, err)
		return
	}
	serviceIDs := make([]int64, 0, len(before.Services))
	for _, item := range before.Services {
		serviceIDs = appendAuditServiceID(serviceIDs, item.InternalServiceID)
	}
	a.auditRequest(r, "equipment.delete", "equipment_device", strconv.FormatInt(id, 10), "success", map[string]any{"deleted": before, "service_ids": serviceIDs})
	w.WriteHeader(http.StatusNoContent)
}

func (a *App) createEquipmentServiceAssignment(w http.ResponseWriter, r *http.Request) {
	equipmentID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input equipment.AssignmentInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Equipment.CreateAssignment(r.Context(), equipmentID, user.ID, input)
	if err == nil {
		a.auditRequest(r, "equipment.service.create", "equipment_service_assignment", strconv.FormatInt(value.ID, 10), "success", map[string]any{"equipment_id": equipmentID, "service_id": value.InternalServiceID, "created": value})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updateEquipmentServiceAssignment(w http.ResponseWriter, r *http.Request) {
	equipmentID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	assignmentID, err := strconv.ParseInt(strings.TrimSpace(r.PathValue("assignment_id")), 10, 64)
	if err != nil || assignmentID <= 0 {
		badRequest(w, errors.New("invalid assignment_id"))
		return
	}
	before, err := a.Equipment.GetAssignment(r.Context(), equipmentID, assignmentID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	var input equipment.AssignmentInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Equipment.UpdateAssignment(r.Context(), equipmentID, assignmentID, user.ID, input)
	if err == nil {
		a.auditRequest(r, "equipment.service.update", "equipment_service_assignment", strconv.FormatInt(assignmentID, 10), "success", map[string]any{"equipment_id": equipmentID, "service_id": value.InternalServiceID, "before_service_ids": []int64{before.InternalServiceID}, "after_service_ids": []int64{value.InternalServiceID}, "before": before, "after": value})
	}
	respond(w, value, err)
}

func (a *App) deleteEquipmentServiceAssignment(w http.ResponseWriter, r *http.Request) {
	equipmentID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	assignmentID, err := strconv.ParseInt(strings.TrimSpace(r.PathValue("assignment_id")), 10, 64)
	if err != nil || assignmentID <= 0 {
		badRequest(w, errors.New("invalid assignment_id"))
		return
	}
	before, err := a.Equipment.GetAssignment(r.Context(), equipmentID, assignmentID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if err := a.Equipment.DeleteAssignment(r.Context(), equipmentID, assignmentID); err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "equipment.service.delete", "equipment_service_assignment", strconv.FormatInt(assignmentID, 10), "success", map[string]any{"equipment_id": equipmentID, "service_id": before.InternalServiceID, "deleted": before})
	w.WriteHeader(http.StatusNoContent)
}
