package audit

import (
	"strings"
	"testing"
)

func TestAuditScopeWhereContext(t *testing.T) {
	where, args := auditScopeWhere(Filter{VMID: 404})
	if len(where) != 1 || len(args) != 11 {
		t.Fatalf("VM scope where=%d args=%d, want 1/11", len(where), len(args))
	}
	if !strings.Contains(where[0], "docker_containers") || !strings.Contains(where[0], "inventory_changes") {
		t.Fatalf("VM scope does not include child resources: %s", where[0])
	}

	where, args = auditScopeWhere(Filter{ServiceID: 37})
	if len(where) != 1 || len(args) != 12 {
		t.Fatalf("service scope where=%d args=%d, want 1/12", len(where), len(args))
	}
	if !strings.Contains(where[0], "docker_container_service_assignments") || !strings.Contains(where[0], "web_site_service_assignments") || !strings.Contains(where[0], "equipment_service_assignments") {
		t.Fatalf("service scope does not include technical assignments/equipment: %s", where[0])
	}
}

func TestAuditFallbackLabelKeepsIDSeparate(t *testing.T) {
	got := auditFallbackLabel("docker_container", "677", nil)
	if got != "Container" {
		t.Fatalf("fallback=%q, want Container", got)
	}
}

func TestDescribeContextualResourceActions(t *testing.T) {
	for _, action := range []string{
		"docker.container.services.replace",
		"database.instance.services.replace",
		"web.site.services.replace",
		"vm.documentation_inheritance.resources_sync",
	} {
		label, description, operation := DescribeAction(action)
		if label == "" || description == "" || operation == "" {
			t.Fatalf("incomplete description for %s", action)
		}
	}
}
