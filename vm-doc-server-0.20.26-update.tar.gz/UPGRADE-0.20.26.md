# Upgrade vm-doc-server 0.20.25 → 0.20.26

## Ce se schimbă

- meniu nou **Echipamente** pentru dispozitive și resurse non-VM;
- asociere directă a echipamentelor la unul sau mai multe servicii/proiecte;
- mai multe fluxuri între același echipament și același serviciu, diferențiate prin rol, protocol, port, sens și scop;
- echipamentele apar în schema serviciului, căutarea globală, Audit și documentele DOCX/Markdown;
- nomenclator nou `device_type`;
- permisiuni RBAC noi `equipment.read` și `equipment.manage`;
- migrare automată `055_equipment_inventory.up.sql`.

## Bază de date

Migrarea 055 creează:

- `equipment_devices`;
- `equipment_service_assignments`;
- categoria de nomenclator `device_type` și valorile inițiale;
- permisiunile RBAC pentru echipamente.

Nu există constrângere unică pe perechea echipament–serviciu: sunt permise mai multe fluxuri/porturi către același proiect.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.25 /usr/local/src/vm-doc-server-0.20.26
tar -xzf vm-doc-server-0.20.26-update.tar.gz -C /usr/local/src/vm-doc-server-0.20.26
cd /usr/local/src/vm-doc-server-0.20.26

GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

La prima pornire, serverul aplică automat migrarea 055. Este recomandat backup DB înainte de upgrade.

## Agent

Nu este necesar update de agent. `vm-doc-agent 1.7.9` rămâne compatibil.
