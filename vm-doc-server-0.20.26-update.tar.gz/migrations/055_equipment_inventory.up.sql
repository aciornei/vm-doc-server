-- 0.20.26: echipamente / dispozitive non-VM și asocierea lor la servicii interne.

INSERT IGNORE INTO nomenclature_categories(code,label,sort_order,active)
VALUES ('device_type','Tip echipament',105,1);

INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,icon_key,sort_order,active) VALUES
('device_type','Dispozitiv medical','medical_device','Dispozitiv medical sau aparat clinic conectat ori documentat în infrastructură.','status',10,1),
('device_type','Echipament laborator','laboratory_device','Analizor sau echipament de laborator.','status',20,1),
('device_type','Network appliance','network_appliance','Appliance de rețea sau securitate care nu este inventariat ca VM.','integration',30,1),
('device_type','Server fizic','physical_server','Server fizic fără reprezentare în inventarul de VM-uri.','package',40,1),
('device_type','Storage','storage_appliance','Echipament de stocare / storage appliance.','store',50,1),
('device_type','IoT / embedded','iot_embedded','Echipament embedded sau IoT.','status',60,1),
('device_type','Altul','other_device','Alt tip de echipament sau dispozitiv.','package',999,1);

CREATE TABLE IF NOT EXISTS equipment_devices (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  device_type_id BIGINT UNSIGNED NULL,
  manufacturer VARCHAR(255) NOT NULL DEFAULT '',
  model VARCHAR(255) NOT NULL DEFAULT '',
  serial_number VARCHAR(255) NOT NULL DEFAULT '',
  hostname VARCHAR(255) NOT NULL DEFAULT '',
  ip_addresses VARCHAR(1024) NOT NULL DEFAULT '',
  mac_address VARCHAR(255) NOT NULL DEFAULT '',
  location VARCHAR(255) NOT NULL DEFAULT '',
  responsible_person_id BIGINT UNSIGNED NULL,
  description TEXT NOT NULL,
  notes TEXT NOT NULL,
  documentation_url VARCHAR(1024) NOT NULL DEFAULT '',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  KEY idx_equipment_device_name (name),
  KEY idx_equipment_device_active_type (active,device_type_id,name),
  KEY idx_equipment_device_person (responsible_person_id),
  CONSTRAINT fk_equipment_device_type FOREIGN KEY (device_type_id) REFERENCES nomenclature_items(id) ON DELETE SET NULL,
  CONSTRAINT fk_equipment_device_person FOREIGN KEY (responsible_person_id) REFERENCES people(id) ON DELETE SET NULL,
  CONSTRAINT fk_equipment_device_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_equipment_device_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS equipment_service_assignments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  equipment_id BIGINT UNSIGNED NOT NULL,
  internal_service_id BIGINT UNSIGNED NOT NULL,
  role_name VARCHAR(255) NOT NULL DEFAULT '',
  protocol VARCHAR(64) NOT NULL DEFAULT '',
  port SMALLINT UNSIGNED NULL,
  direction VARCHAR(32) NOT NULL DEFAULT 'unspecified',
  purpose VARCHAR(512) NOT NULL DEFAULT '',
  notes TEXT NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  KEY idx_equipment_assignment_equipment (equipment_id,active,internal_service_id),
  KEY idx_equipment_assignment_service (internal_service_id,active,equipment_id),
  CONSTRAINT fk_equipment_assignment_equipment FOREIGN KEY (equipment_id) REFERENCES equipment_devices(id) ON DELETE CASCADE,
  CONSTRAINT fk_equipment_assignment_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id) ON DELETE CASCADE,
  CONSTRAINT fk_equipment_assignment_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_equipment_assignment_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT chk_equipment_assignment_port CHECK (port IS NULL OR (port BETWEEN 1 AND 65535)),
  CONSTRAINT chk_equipment_assignment_direction CHECK (direction IN ('unspecified','device_to_service','service_to_device','bidirectional'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO permissions(name,description) VALUES
 ('equipment.read','Vizualizare echipamente / dispozitive și asocierile lor la servicii'),
 ('equipment.manage','Administrare echipamente / dispozitive și asocierile lor la servicii');

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name='admin' AND p.name IN ('equipment.read','equipment.manage');

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.name IN ('equipment.read','equipment.manage') WHERE r.name='operator';

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.name='equipment.read' WHERE r.name IN ('viewer','auditor');
