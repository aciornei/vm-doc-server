-- 0.18.3: diferențiază configurarea într-un job Veeam de existența unui restore point.

ALTER TABLE vm_backup_summary
  ADD COLUMN IF NOT EXISTS veeam_in_job TINYINT(1) NOT NULL DEFAULT 0 AFTER protected,
  ADD COLUMN IF NOT EXISTS veeam_job_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER veeam_in_job;

-- Hotfix defensiv pentru instalațiile 0.18.2 unde 035 a creat coloana fără default.
ALTER TABLE vm_backup_summary
  MODIFY COLUMN cron_backup_notes TEXT NOT NULL DEFAULT '';
