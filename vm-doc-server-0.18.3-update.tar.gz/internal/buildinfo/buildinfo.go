package buildinfo

var (
	Version = "0.18.3-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
