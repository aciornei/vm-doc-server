# Integrarea Veeam Backup & Replication

## Scop

vm-doc-server citește în mod read-only starea backupurilor din Veeam Backup & Replication și o corelează cu VM-urile deja importate din vCenter.

## Conectare

Pentru VBR 12.1, porniți cu:

- URL: `https://<veeam-server>:9419`
- REST API / `x-api-version`: `1.1-rev1`
- interval sincronizare recomandat: `1440` minute (o dată pe zi)
- verificare TLS: activă

Folosiți un cont dedicat cu rolul **Veeam Backup Viewer**. Test-ul vm-doc folosește un endpoint read-only și nu necesită Backup Administrator. Parola este criptată de vm-doc-server cu aceeași cheie master folosită pentru celelalte secrete dinamice și nu este returnată prin API/UI.

Dacă serverul Veeam folosește certificat intern, soluția recomandată este ca sistemul vm-doc-server să aibă încredere în CA-ul intern. Dezactivarea verificării TLS există pentru test/compatibilitate, dar nu este recomandată permanent.

## Date citite

Sincronizarea folosește REST API pentru:

- obiecte protejate (`backupObjects`);
- backupuri (`backups`);
- starea joburilor (`jobs/states`);
- definițiile joburilor (`jobs` și, best-effort, detaliul fiecărui job) inclusiv `virtualMachines.includes`;
- cel mai recent restore point per obiect corelat.

vm-doc nu pornește joburi, nu șterge restore points și nu modifică configurația Veeam.

## Corelare

Corelarea este strictă și deterministă după numele VM-ului (comparat case-insensitive, fără fuzzy matching). Sunt folosite două surse:

```text
backupObjects.name             -> backup / restore points existente
virtualMachines.includes.name -> apartenența curentă directă la job
```

Dacă nu există exact un singur VM cu acel nume, obiectul este lăsat neasociat și apare în contorul `Neasociate / ambigue` al sincronizării. În 0.18.3 sunt corelate direct intrările de tip `VirtualMachine`; containerele Veeam precum Folder/ResourcePool nu sunt expandate recursiv.

## Date salvate per VM

În `vm_backup_summary` se actualizează:

- `protected` (există restore point utilizabil);
- `veeam_in_job` și `veeam_job_enabled` (configurarea curentă în job);
- sursa Veeam;
- jobul/joburile;
- repository-ul/repository-urile;
- ultimul rezultat al jobului;
- data celui mai nou restore point;
- următoarea rulare cunoscută;
- numărul total de restore points;
- ultima sincronizare și eventualele erori.

Datele sunt afișate în fila dedicată **Backup** din pagina VM, inclusiv lanțurile Veeam corelate, și sunt disponibile generatorului de fișe VM. Fișa serviciului include la rândul ei un tabel de backup pentru toate VM-urile asociate.
În plus, meniul global **Backup** oferă tabel paginat, căutare și filtre separate după protecție, power state și rezultat.

## Stări Veeam · 0.18.3

vm-doc nu mai tratează „este în job” ca sinonim pentru „are backup”. Starea este calculată astfel:

- **Protejată** — există restore point; dacă VM-ul este și în job, configurația este curentă;
- **Așteaptă primul backup** — VM-ul este inclus direct într-un job activ, dar nu există încă restore point;
- **Job dezactivat · fără backup** — VM-ul este configurat într-un job dezactivat și nu are restore point;
- **Backup existent · în afara jobului** — există restore point, dar VM-ul nu mai apare în `virtualMachines.includes`;
- **Neprotejată** — Veeam a fost sincronizat, dar VM-ul nu este în job și nu are restore point;
- **Neverificată** — încă nu există rezultat Veeam pentru VM.

Această separare permite ca o VM adăugată acum într-un job să apară imediat în vm-doc, fără a aștepta prima rulare a jobului.

## Scheduler

Fiecare sursă are propriul `sync_interval_minutes`. Implicit pentru sursele noi: 1440 minute (o dată pe zi). Sursele existente își păstrează intervalul deja configurat. Scheduler-ul global verifică periodic dacă o sursă este scadentă și evită două sincronizări simultane pentru aceeași sursă.

## Extinderi 0.18.2

Sincronizarea încearcă suplimentar endpointurile read-only `jobs` și `backupInfrastructure/repositories`. Dacă VBR le permite contului Viewer, vm-doc documentează:

- programarea jobului și ora locală raportată de Veeam;
- retenția standard (restore points sau zile);
- GFS Weekly, Monthly și Yearly;
- repository-ul primar și repository-urile secundare / backup copy.

Aceste endpointuri sunt best-effort: un endpoint opțional indisponibil nu anulează inventarul de bază; avertizarea este păstrată în JSON-ul tehnic și jurnal.

## Backup cron / script local

În fila Backup a unei VM poate fi bifat un backup realizat prin cron sau un script local. Se pot documenta expresia cron, comanda/scriptul și observațiile. vm-doc **nu execută** acel cron; doar îl inventariază și îl include în fișa VM și în fișa serviciului. O VM cu backup cron declarat este considerată protejată în indicatorii documentari chiar dacă nu are obiect Veeam.

## Timezone

Timestamp-urile persistente sunt tratate ca UTC în sesiunea MariaDB, iar interfața le afișează în `app.timezone`. Pentru România folosiți:

```yaml
app:
  timezone: "Europe/Bucharest"
```

Ora configurată pentru sincronizarea zilnică vCenter este interpretată în acest fus orar. Astfel `05:00` înseamnă 05:00 ora României, inclusiv după schimbarea DST.

### Backup prin cron / script local

În fila Backup a VM-ului, vm-doc afișează cron-urile detectate de agent. Un cron poate fi selectat ca backup local; programul și comanda sunt copiate în metadatele de backup și apar în fișa VM și în fișa serviciului. vm-doc nu execută și nu modifică cron-ul.
