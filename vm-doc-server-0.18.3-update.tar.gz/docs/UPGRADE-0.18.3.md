# Upgrade vm-doc-server 0.18.2 → 0.18.3

0.18.3 separă apartenența curentă la jobul Veeam de existența unui restore point. Agentul rămâne 1.6.2.

## Pași

1. Opriți `vm-doc-server`.
2. Aplicați `vm-doc-server-0.18.3-update.tar.gz` peste o copie a sursei 0.18.2.
3. Rulați `GOPROXY=off GOFLAGS=-mod=vendor go test ./...`.
4. Rulați `GOPROXY=off GOFLAGS=-mod=vendor make build`.
5. Instalați `bin/vm-doc-server` și porniți serviciul. Collectorul nu necesită schimbare funcțională în această versiune.
6. Verificați aplicarea migrării `037_veeam_job_membership.up.sql`.
7. Faceți `Ctrl+F5` în browser.
8. Din Backup, executați un Sync Veeam.

După primul sync 0.18.3, VM-urile adăugate direct în `virtualMachines.includes` apar imediat ca `Așteaptă primul backup` până când Veeam creează primul restore point.

Migrarea 037 repară defensiv și default-ul `cron_backup_notes` pentru instalațiile 0.18.2 care au aplicat migrarea 035 înainte de hotfix.
