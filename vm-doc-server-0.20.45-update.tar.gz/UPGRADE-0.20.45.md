# Upgrade vm-doc-server 0.20.44 -> 0.20.45

Versiunea 0.20.45 adaugă filtre Outline/OS suportat în lista VM și publicarea tabelului filtrat într-o pagină Outline configurată generic. Include migrarea DB 063 și nu necesită update de vm-doc-agent.

## Schimbări

- Lista VM: filtre `Outline: Toate/DA/NU` și `OS suportat: Toate/DA/NU`.
- Filtrele se aplică listei, exportului Excel și publicării tabelului în Outline.
- Buton nou `Publică tabelul în Outline`; publică toate rezultatele filtrate, nu doar pagina curentă.
- `Documente -> Configurare Outline -> Destinații publicare` conține destinația `Inventar VM`.
- Linkul țintă trebuie să indice o pagină Outline existentă; la salvare este validat și rezolvat la document ID.
- Pagina țintă își păstrează titlul; VM-DOC actualizează doar conținutul.
- Publicarea cu 0 rezultate este blocată.
- Migrarea 063 creează `outline_publication_targets` și seed-ul `vm_inventory`.

## Upgrade offline

```bash
cp -a /usr/local/src/vm-doc-server-0.20.44 \
      /usr/local/src/vm-doc-server-0.20.45

tar -xzf vm-doc-server-0.20.45-update.tar.gz \
    -C /usr/local/src/vm-doc-server-0.20.45

cd /usr/local/src/vm-doc-server-0.20.45
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOSUMDB=off GOFLAGS=-mod=vendor make build
```

La primul startup se aplică automat migrarea `063_outline_publication_targets.up.sql`.

După restart, folosește `Ctrl+F5` în browser pentru `app.js?v=0.20.45`.

## Configurare după upgrade

1. Deschide **Documente -> Configurare Outline**.
2. În **Destinații publicare -> Inventar VM**, introdu URL-ul paginii Outline existente care va conține tabelul.
3. Salvează destinația.
4. Revino la **VM-uri -> Inventar VM**, aplică filtrele dorite și folosește **Publică tabelul în Outline**.
