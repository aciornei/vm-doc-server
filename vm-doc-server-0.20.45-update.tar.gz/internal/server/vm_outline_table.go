package server

import (
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/domain"
	outlineapi "vm-doc-server/internal/outline"
)

func (a *App) listOutlinePublicationTargets(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	values, err := a.Outline.ListPublicationTargets(r.Context())
	respond(w, values, err)
}

func (a *App) updateOutlinePublicationTarget(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		respond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	code := strings.TrimSpace(r.PathValue("code"))
	if code == "" {
		badRequest(w, errors.New("target code is required"))
		return
	}
	var input outlineapi.PublicationTargetInput
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Outline.UpdatePublicationTarget(r.Context(), user.ID, code, input)
	if err == nil {
		a.auditRequest(r, "outline.publication_target.update", "outline_publication_target", code, "success", map[string]any{
			"name":               value.Name,
			"document_reference": value.DocumentReference,
			"document_id":        value.DocumentID,
			"active":             value.Active,
		})
	}
	outlineRespond(w, value, err)
}

func (a *App) publishVMInventoryOutline(w http.ResponseWriter, r *http.Request) {
	if a.Outline == nil {
		outlineRespond(w, nil, errors.New("Outline integration is unavailable"))
		return
	}
	filter, err := vmFilterFromRequest(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	vms, err := a.VCenter.ExportVMs(r.Context(), filter)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if len(vms) == 0 {
		badRequest(w, errors.New("no VMs match the current filters; Outline page was not modified"))
		return
	}
	markdown := a.vmInventoryOutlineMarkdown(vms)
	result, err := a.Outline.PublishTargetDocument(r.Context(), "vm_inventory", []byte(markdown))
	if err == nil {
		a.auditRequest(r, "outline.vm_inventory.publish", "outline_publication_target", "vm_inventory", "success", map[string]any{
			"rows":                len(vms),
			"outline_document_id": result.DocumentID,
			"outline_url":         result.URL,
			"filters":             r.URL.RawQuery,
		})
	}
	if err != nil && a.Logger != nil {
		a.Logger.Error("Outline VM inventory table publish failed", "error", err, "filters", r.URL.RawQuery)
	}
	outlineRespond(w, map[string]any{
		"result": result,
		"rows":   len(vms),
	}, err)
}

func (a *App) vmInventoryOutlineMarkdown(vms []domain.VirtualMachine) string {
	location, err := time.LoadLocation(a.Config.App.Timezone)
	if err != nil {
		location = time.UTC
	}
	generatedAt := time.Now().In(location).Format("02.01.2006 15:04")
	var b strings.Builder
	b.WriteString("> Actualizat automat din VM-DOC la **")
	b.WriteString(generatedAt)
	b.WriteString("** · ")
	b.WriteString(strconv.Itoa(len(vms)))
	b.WriteString(" VM-uri conform filtrelor curente.\n\n")
	b.WriteString("| VM | vCenter | Power | CPU / RAM | Mediu | OS | Suport OS | IP | Agent | Servicii | Outline | Ultima publicare Outline | Completare | Ultimul JSON |\n")
	b.WriteString("|---|---|---|---|---|---|---|---|---|---|---|---|---:|---|\n")
	for _, vm := range vms {
		osName := strings.TrimSpace(vm.InventoryOSName)
		if osName == "" {
			osName = strings.TrimSpace(vm.GuestOS)
		}
		osVersion := strings.TrimSpace(vm.InventoryOSVersion)
		osText := strings.TrimSpace(strings.TrimSpace(osName) + " " + osVersion)
		if osText == "" {
			osText = "—"
		}
		ip := strings.TrimSpace(vm.InventoryPrimaryIP)
		if ip == "" {
			ip = strings.TrimSpace(vm.PrimaryIP)
		}
		agent := strings.TrimSpace(vm.AgentName)
		if agent == "" {
			agent = "Fără agent"
		} else {
			if strings.TrimSpace(vm.AgentVersion) != "" {
				agent += " " + strings.TrimSpace(vm.AgentVersion)
			}
			if strings.TrimSpace(vm.AgentStatus) != "" {
				agent += " · " + strings.TrimSpace(vm.AgentStatus)
			}
		}
		services := strings.Join(vm.ServiceNames, ", ")
		if strings.TrimSpace(services) == "" {
			services = "—"
		}
		vcenterState := "Prezentă"
		if !vm.PresentInVCenter {
			vcenterState = "Lipsă"
		}
		outlineState := "DA"
		if vm.OutlineDocumentationDisabled {
			outlineState = "NU"
		}
		lastOutline := formatOutlineTableTime(vm.OutlineLastSyncedAt, location)
		lastJSON := formatOutlineTableTime(vm.InventoryReceivedAt, location)
		cpuRAM := fmt.Sprintf("%d / %s", vm.CPUCount, outlineMemory(vm.MemoryMiB))
		row := []string{
			vm.Name,
			vcenterState,
			vm.PowerState,
			cpuRAM,
			firstText(vm.Environment, "—"),
			osText,
			osSupportTableLabel(vm.OSSupportStatus),
			firstText(ip, "—"),
			agent,
			services,
			outlineState,
			lastOutline,
			strconv.Itoa(vm.CompletionPercent) + "%",
			lastJSON,
		}
		b.WriteString("|")
		for _, cell := range row {
			b.WriteString(" ")
			b.WriteString(markdownTableCell(cell))
			b.WriteString(" |")
		}
		b.WriteString("\n")
	}
	if len(vms) == 0 {
		b.WriteString("| _Niciun VM pentru filtrele curente_ | — | — | — | — | — | — | — | — | — | — | — | — | — |\n")
	}
	return b.String()
}

func markdownTableCell(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "—"
	}
	value = strings.ReplaceAll(value, "|", "\\|")
	value = strings.ReplaceAll(value, "\r\n", "<br>")
	value = strings.ReplaceAll(value, "\n", "<br>")
	value = strings.ReplaceAll(value, "\r", "<br>")
	return value
}

func osSupportTableLabel(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "supported":
		return "DA"
	case "unsupported":
		return "NU"
	default:
		return "Nedeterminat"
	}
}

func formatOutlineTableTime(value *time.Time, location *time.Location) string {
	if value == nil {
		return "—"
	}
	return value.In(location).Format("02.01.2006 15:04")
}

func outlineMemory(mib int64) string {
	if mib <= 0 {
		return "—"
	}
	if mib >= 1024 {
		return fmt.Sprintf("%.1f GiB", float64(mib)/1024.0)
	}
	return fmt.Sprintf("%d MiB", mib)
}

func firstText(value, fallback string) string {
	if strings.TrimSpace(value) == "" {
		return fallback
	}
	return strings.TrimSpace(value)
}
