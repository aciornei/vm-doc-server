-- 0.20.45: destinații generice pentru publicarea rapoartelor/tabelelor în Outline.

CREATE TABLE IF NOT EXISTS outline_publication_targets (
  target_code VARCHAR(64) NOT NULL,
  target_name VARCHAR(255) NOT NULL,
  document_reference VARCHAR(1024) NOT NULL DEFAULT '',
  document_id VARCHAR(64) NOT NULL DEFAULT '',
  document_url VARCHAR(1024) NOT NULL DEFAULT '',
  content_hash CHAR(64) NOT NULL DEFAULT '',
  active TINYINT(1) NOT NULL DEFAULT 1,
  last_published_at DATETIME(6) NULL,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (target_code),
  CONSTRAINT fk_outline_publication_targets_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_outline_publication_targets_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO outline_publication_targets(target_code,target_name,active)
VALUES ('vm_inventory','Inventar VM',1)
ON DUPLICATE KEY UPDATE target_name=VALUES(target_name);
