# VM-DOC — Context de proiect

> **Scop:** document de continuitate între conversații ChatGPT și între release-uri ale proiectului VM-DOC.  
> **Actualizat:** 2026-10-14 (Europe/Bucharest), după corecțiile Server 0.21.24 și Agent 1.7.18.  
> **Sursa informațiilor:** deciziile și livrările descrise în conversațiile despre VM-DOC. **Nu** reprezintă validare completă în mediul de producție; serverul 0.21.12 a fost raportat ca funcțional de utilizator; reorganizarea 0.21.13 necesită încă verificarea finală pe serverul cu vendor/.  
> **Fișier asociat:** `CHANGELOG.md` (istoric selectiv al modificărilor).

## 1. Rezumat operațional pentru următorul chat

VM-DOC este o aplicație internă pentru inventarierea, documentarea și analiza mașinilor virtuale și serviciilor IT. Are **server central Go**, **agenți multiplatformă**, aplicație web și integrări cu surse de infrastructură. Generează documentație **DOCX / PDF / Markdown** și publică selectiv în **Outline**.

### Versiuni și statut cunoscut

| Componentă | Versiune / reper | Stare și observații |
|---|---|---|
| Server VM-DOC | **0.21.24** | Configurare → Operațional: doar Observații, valorile URL/tichet vechi sunt păstrate intern; Rezumat trimite doar spre Outline; Inventar VM: sortare SQL globală pe coloanele tabelului și export; Infrastructură: navigare imediată și încărcare amânată a dovezilor de completare. Fără SQL nou sau agent. |
| Server VM-DOC | **0.21.23** | Aliniere panouri Configurare VM la lățimea navigării; formular HA cu margini interne și acțiuni aerisite; butoane Servicii/Încadrare despărțite de Observații. Numai UI CSS, fără SQL/API/agent. |
| Server VM-DOC | **0.21.22** | Rezumat VM reorganizat 4×2 cu Beneficiari și responsabilități separate; linkurile Outline/Vault aliniate; KPI 174px pentru viewport 1595; eliminare falsă dublare MySQL/MariaDB cu dovadă și fără instanță MySQL reală. Fără migrare/agent nou. |
| Server VM-DOC | **0.21.20** | UI: toate cele 7 carduri de rezumat VM (listă și fișă) folosesc clasa comună `ui-kpi-seven`, dimensiuni compacte constante și breakpoints; chevron filtre centrat. Fix regresie 0.21.18, fără migrare/API/agent. |
| Server VM-DOC | **0.21.19** | Hotfix OpenAPI/Swagger peste 0.21.18: eliminate rutele dublate `/api/v1/people` și `/api/v1/people/{id}`; păstrate definițiile complete. Test Go pentru unicitatea rutelor în paths și versiune și versiune. Fără migrare sau agent nou; rebuild necesar pentru `go:embed`; build server complet neverificat local. |
| Server VM-DOC | **0.21.18** | Inventar VM: maximum 4 servicii pe celulă + Extinde/Restrânge, bară de filtre cu selecții vizibile/reset/săgeată, 3 carduri noi (Pornite, Publicare Outline, medie completare) și toate cardurile clickabile. API vms cu numere și medie pe toate rezultatele filtrate; `published` și `sort`. Fără migrare; agent 1.7.18 neschimbat. |
| Server VM-DOC | **0.21.17** | Corecții UI VM-uri: doar Căutare/Power vizibile, 8 filtre pliabile cu 4/linie desktop, carduri compacte, dată/oră pe două rânduri, coloanele Publicare/Outline clarificate, meniuri sticky lipite de topbar. Fără migrare SQL/API/agent; validare staging necesară. |
| Server VM-DOC | **0.21.16** | Uniformizare UI transversală cu navigare grupată, meniu mobil, spațiere și formulare/tabele/dialoguri; fără migrare SQL, API sau agent. Backlog Wazuh/Shell în `docs/TODO.md`; validare cu date reale necesară. |
| Server VM-DOC | **0.21.15** | Pachet cu migrarea 076 și motor Hardening configurabil: benchmarkuri, reguli, profiluri Draft/Publicat/Arhivat, clonare, import/export JSON, API/Swagger; testare staging necesară, build server complet neverificat local. Agent 1.7.18 neschimbat. |
| Server VM-DOC | **0.21.14** | Curățare structură peste 0.21.12: UPGRADE/RELEASE-NOTES/VERIFICATION în `docs/history/`, script `scripts/cleanup-source-tree.sh` cu dry-run/--apply/--check, arhivare copii vechi imbricate în afara arborelui Go, verificare pre-build în Makefile. Fără migrare SQL, API/Swagger, agent sau schimbare a logicii de inventar. Build complet cu vendor/ de confirmat. |
| Server VM-DOC | **0.21.12** | **Hotfix Go peste 0.21.11:** `internal/server/hardening.go` `updateHardeningProfile` folosește `_, err =` deoarece `err` era deja definit; în 0.21.11 compilarea eșua cu `no new variables on left side of :=`. Fără migrare, schimbare API sau agent. Testul integral cu `vendor/` trebuie confirmat pe server. |
| Server VM-DOC | **0.21.11** | **Hotfix compilare peste 0.21.10.** În `internal/server/hardening.go` au fost eliminate trei rezultate `sql.Result` neutilizate; modificarea nu schimbă logica Hardening, schema DB, Swagger sau agentul. `go test ./internal/... ./cmd/...` și `make build` trebuie confirmate offline cu `vendor/` pe serverul utilizatorului. |
| Server VM-DOC | **0.21.10** | Nomenclator 25 reguli interne hardening, 6 profiluri OS (Ubuntu 20/22/24, Debian 12, Windows Server 2019/2022), asociere CIS versionată/pending până la validare, motor read-only, raport Excel și Swagger, migrarea `075`. Teste `internal/hardening`, JS/OpenAPI trecute; build server complet/MariaDB reale **neverificate**. Instalare neconfirmată. |
| Server VM-DOC | **0.21.9** | **Pachet de actualizare și surse pregătite în această sesiune** peste 0.21.8. Migrarea `074` adaugă originea Docker/nativ și metadatele MongoDB Replica Set per instanță; UI/API/Swagger/XLSX actualizate. Testele Go limitate la `databaseinventory`, `domain`, `xlsx`, JS și OpenAPI; compilarea completă și MariaDB reală rămân neverificate. **Nu este confirmată instalarea în producție.** |
| Server VM-DOC | **0.21.8** | Bază de upgrade, cu excluderea centralizată Db2 configurabilă și migrarea `073`. |
| Agent modern | **1.7.18** | Schema inventar `2.13`, probe read-only Linux SSH/sysctl/permisiuni și Windows UAC/SMBv1/NLA; binare Linux/Windows amd64/386 compilate, teste Go offline trecute; legacy neschimbate. Test pe OS real neconfirmat. |
| Agent modern | **1.7.17** | Pachet unic modern+legacy+surse, 13.10.2026. Linux/Windows amd64/386 compilate, teste Go offline trecute. MongoDB 4.4 SECONDARY: `setSecondaryOk()` și `getDBs()`; PostgreSQL Docker: `POSTGRES_USER`/`POSTGRES_DB` din mediul containerului (fără parole); timeout Docker DB 15 s (5–60 configurabil); MariaDB/MySQL: diagnostic client/autentificare. Testare reală post-upgrade încă necesară. |
| Agent modern | **1.7.16** | Arhiva `vm-doc-agents-all-2026-10-13-v1.7.16-with-source.zip` există și include Linux amd64/386, Windows amd64/386, sursele Go și patch 1.7.15→1.7.16. Teste și build offline raportate; **instalarea pe VM-uri nu este confirmată**. |
| Agent modern | **1.7.15** | Pachet anterior, sursele Go reconstruite din 1.7.12 + patch-uri 1.7.13/14/15; compatibil cu serverul 0.21.9 (fără metadate Docker/Replica Set noi). |
| Agent SLES9 legacy | **1.0.1** | Variantă separată pentru SLES9, schema inventar menționată `2.9`; binarul legacy nu trebuie presupus recompilat odată cu 1.7.16. |
| Agent Windows legacy | **1.0.2** | Ramură legacy separată; verifică exact ce build-uri suportă XP/Windows vechi și existența surselor. |
| Agent Windows XP | **reper 1.0.1** | Menționat în istoricul legacy; versiunea pachetului efectiv folosit trebuie verificată în arhive. |

**Regulă de lucru:** distinge mereu între **cerință**, **implementare raportată**, **arhivă livrată**, **build/test executat**, **instalare efectivă** și **validare în producție**. Nu crește versiunea doar din discuție.

### Ajustări UI / API — 0.21.24

- **Operațional**: secțiunea finală conține doar Observații; URL-ul documentației și referința tichet nu mai sunt editabile în interfață. Valorile istorice sunt retransmise la salvare pentru a nu fi golite accidental. În Rezumat, URL-ul Documentație este exclusiv cel al paginii Outline asociate (dacă există). Vault rămâne doar în VM-DOC.
- **Inventar VM**: `sort=key:asc|desc` pentru VM, vCenter, Power, CPU/RAM, OS, IP, Agent, Servicii, Publicare, data Outline, Completare și data ultimului inventar; whitelist de expresii SQL cu criteriu secundar stabil. Sortarea se aplică pe tot setul filtrat înainte de paginare și este preluată de exportul Excel; `completion_asc` rămâne acceptat.
- **Infrastructură VM**: navigarea și starea de încărcare sunt afișate imediat. Pentru secțiune nu mai blocăm afișarea pe cele trei inventare separate Docker/DB/Web și beneficiari: ele se încarcă asincron pentru calculul completării. Procentul temporar nu este prezentat ca 0%; este afișat după finalizarea datelor. Nu modifică modelul VM sau datele inventarului.
- **Teste locale**: `node --check`, Go OpenAPI/Web/Buildinfo, teste SQL sortare izolate și Chromium 1595/1024/390 pentru antete (sortare asc/desc, revenire pagina 1) trecute. **Build complet cu vendor și măsurare timp real pe server neconfirmate.**

### Ajustări UI specifice — 0.21.20

- Regula de design: **șapte carduri KPI de aceeași dimensiune**, într-un singur rând când lățimea o permite. Clasele reutilizabile `ui-kpi-seven` și setul de dimensiuni sunt aplicate în lista VM și în fișa unui VM. Pentru paginile noi cu șapte carduri se folosește aceeași clasă. Nu se lățesc la 4 carduri pe un rând.
- În bara VM filtre, săgeata chevron este centrată geometric în rând, iar `Resetează` rămâne în dreapta; mobilul folosește două rânduri.
- 0.21.20 este corecție exclusiv UI peste 0.21.19; TODO Wazuh/SSH nemodificat.

### Ajustări UI specifice — 0.21.18

- Tabel VM / Servicii: primele patru nume vizibile; `+N · Extinde` / `Restrânge` prezintă lista întreagă fără a ascunde datele din server.
- Bara filtre secundare: text „Filtre:” cu selecții vizibile sau „Niciun filtru activ”, buton Resetează și chevron pentru cele 8 filtre; Căutare și Power rămân deasupra.
- 7 carduri sumar clickabile: Rezultate (resetează), Pornite, Publicare Outline (publicate efectiv, `ovmoutline.last_synced_at IS NOT NULL`), Completare generală (media gradului de completare, click pentru ordonare crescătoare), Prezente în vCenter, Lipsă din vCenter, Cu agent asociat.
- Cardurile folosesc aceleași filtre cu tabelul. API `GET /api/v1/vms`: agregate `powered_on_count`, `outline_published_count`, `completion_average_percent` calculate în SQL înainte de `LIMIT/OFFSET`; `published=yes|no`, `sort=completion_asc`; documentație OpenAPI actualizată.
- Procentele de completare individuale și media utilizează aceeași expresie SQL, nealterată semantic. Nu s-a introdus migrare SQL/agent; testele complete Go cu vendor și MariaDB rămân necesare în staging.
- Wazuh și Shell SSH prin Vault rămân **amânate** în `docs/TODO.md`.

### Ajustări UI specifice — 0.21.17

- Lista VM: Căutare VM + Power vizibile, restul de 8 filtre în `<details>`; patru controale pe rând la desktop, responsive la ecrane mici.
- Cardurile sumar din lista VM au dimensiune redusă, ca în rezumat VM.
- Formatterul de dată `dt()` generează markup cu data și ora pe două rânduri în UI, în fusul `state.timezone`; elementele lipsite de timestamp arată `—`.
- În tabelul VM, coloana de eligibilitate Outline a devenit „Publicare”; cea cu ultima sincronizare/publicare a devenit „Outline”.
- Topbar-ul este măsurat dinamic pentru navigarea sticky; nu mai are `top: 78px` sau `82px` fix pe aceste componente.
- Wazuh și Shell prin Vault rămân în `docs/TODO.md` ca funcții amânate, fără schimbări.

### Direcția curentă — UI și funcții amânate (0.21.16)

- S-a decis **pauzarea** extinderii Hardening/CIS proprii; modulul actual rămâne un baseline pentru mașinile fără Wazuh. Nu se implementează colectori CIS compleți în această etapă.
- **TODO Wazuh:** integrare viitoare read-only API pentru agenți, SCA/CIS și ulterior vulnerabilități; corelare cu VM/servicii/beneficiari, scor Wazuh separat de baseline VM-DOC.
- **TODO Shell SSH:** acces interactiv din fișa VM prin backend, chei gestionate în Vault, RBAC, audit sesiune, fără expunerea secretelor browserului; proiect amânat pentru review de securitate.
- Plan activ: uniformizare vizuală toate paginile, urmată de ajustări punctuale. `docs/TODO.md` păstrează criteriile de reluare; `docs/UI-REVIEW-0.21.16.md` acoperă inventarul paginilor.
- Server 0.21.16 schimbă doar HTML, JS navigare, CSS, documentație, VERSION și releases.json; fără migrare/Go/agent.
- Teste Chromium simulate pe 1440/1024/390 px, sintaxă JS/JSON, pachet embed Go; **fără testare end-to-end cu backend MariaDB real și fără build complet Go cu vendor**.

### Hardening extensibil — 0.21.15

- Nomenclatoare → Securitate → Hardening: benchmarkuri metadata, bibliotecă de reguli și profiluri OS sau componentă; utilizatorul poate crea profiluri noi fără release Go dacă dovada/check_key există deja.
- Profil nou Draft; se atașează reguli, publică și se salvează snapshotul de revizie; profilul publicat este structural imuabil (clonează pentru schimbări). Excepție: administratorul poate actualiza separat referințele CIS validate intern.
- Operatori configurați din allowlist, fără comenzi arbitrare; dovezile lipsă sunt unknown, nu conforme.
- Profilurile Apache, Nginx, MariaDB, MySQL, PostgreSQL, MongoDB și Docker sunt șabloane **Draft**. Evaluarea per instanță tehnică necesită colectori ulteriori; nu declara conformitate pentru acestea.
- Migrare aditivă `076`; referințe CIS individuale pending până la verificare; fișiere istorice în `docs/history/`.
- Testat: `internal/hardening`, `internal/domain`, `internal/xlsx`, JS, OpenAPI și smoke Chromium cu API simulat; **build complet Go cu vendor și MariaDB reală lipsesc**. Serverul 0.21.15 nu este confirmat instalat.

### Hardening intern — 0.21.12 (bază) / 1.7.18; 0.21.13 curățare structură

- Decizie: **numai controale proprii VM-DOC**, fără rulare/import CIS-CAT și fără a pretinde certificare CIS.
- Nomenclator: 25 reguli interne (`LIN-*`, `WIN-*`), 6 profiluri L1 interne; profilele rețin numele și versiunea benchmarkului CIS relevant și linkul oficial.
- Mapările exact numerotate `recommendation_id` și `control_id` sunt **pending** până la verificare de administrator pentru versiunea exactă; status `reviewed` înseamnă *verificat intern*, nu oficial. **Nu inventa ID-uri CIS.**
- Rezultate: `pass`, `fail`, `unknown`; un `unknown` nu este conform și reduce scorul intern. Reguli cu metodă manuală rămân `unknown` până la extindere.
- Agent 1.7.18 colectează exclusiv evidențe read-only în `hardening.evidence` (schema 2.13). Linux: `sshd -T`, sysctl IPv4, drepturi `/etc/shadow`; Windows: chei registry UAC/SMB1/RDP NLA. Nu colectează valori secrete, nu modifică setările și nu execută remedieri.
- Server 0.21.10: migrare SQL `075`, meniuri Nomenclatoare/Securitate/fișă VM, raport și export Excel, API/Swagger cu drepturi separate. Scorurile sunt derivate din ultima colectare; agenții legacy pot avea multe valori necunoscute.
- Validare: unit teste agent/server engine, build-uri agent și sintaxă UI/OpenAPI; **lipsesc încă build complet server cu `vendor`, teste MariaDB și teste e2e**.
- Nu modifica linkurile Vault sau politica de publicare Outline în această versiune. Înainte de rollout: backup MariaDB și test staging.

**Incident hotfix 0.21.12:** în 0.21.11 la linia 176, `_, err :=` producea `no new variables on left side of :=` deoarece err fusese declarat înainte. Corectat la `_, err =` în 0.21.12; celelalte două instrucțiuni pot păstra `:=`. Compilarea finală cu `vendor/` rămâne de verificat pe server.

**Incident hotfix 0.21.11:** compilarea 0.21.10 a eșuat cu trei variabile `res/result` declarate și nefolosite în `internal/server/hardening.go`, confirmat de utilizator prin `go test`. Codul 0.21.11 folosește `_` pentru rezultatele SQL neutilizate; nu se presupune că orice altă eroare Go este rezolvată fără compilare completă pe server cu `vendor/`. Evită surse vechi imbricate în proiect când rulezi `go test ./...`.


### Organizarea surselor (0.21.13)

- Fișierele UPGRADE/RELEASE-NOTES (și verificările istorice) au fost mutate din rădăcina serverului în `docs/history/{upgrades,release-notes,verification}/`. Index: `docs/history/INDEX.md`.
- La extragerea arhivei update TAR peste 0.21.12 trebuie rulat `bash scripts/cleanup-source-tree.sh --dry-run`, apoi explicit `--apply`; TAR nu șterge automat vechile fișiere de la rădăcină.
- Scriptul arhivează proiecte Go vechi imbricate în **afara** folderului curent, nu le șterge. Nu atinge `vendor/`, `migrations/`, configurațiile sau datele runtime.
- Înainte de `make test`/`make build`, `Makefile` verifică structura și explică remedierea dacă există surse vechi imbricate.
- Nu se schimbă funcțiile serverului, migrarea 075, Swagger sau Agent 1.7.18. `go test ./...` și build cu vendor pe server trebuie reconfirmate.

## 2. Scop și arhitectură

- **Server central:** aplicație Go, acces web/API; stochează inventarul, configurațiile, relațiile VM–serviciu–componentă și datele din integrări.
- **Agent instalat pe VM:** colectează informații locale, inclusiv versiuni software și componente, fără dependență obligatorie de internet.
- **Infrastructură:** import și corelare cu vCenter; integrare cu Veeam, Prometheus și FortiGate; autentificare enterprise LDAP/AD și OIDC/Keycloak; integrare cu Outline.
- **Documentare:** fișă individuală VM, fișă de serviciu, componente suport; documentele rezultate pot fi publicate în Outline în limitele politicii PROD.
- **Operare offline:** pachetele de release trebuie să poată fi transferate și instalate în rețele fără acces la internet, cu surse, instrucțiuni și hash-uri.

Flux conceptual:

```text
VM-uri (Linux / Windows / legacy)
          |
       Agenți  -----> Inventar sistem, servicii, rețea, Web/DB/Docker,
          |           porturi, conturi, politici, integrare
          v
   Server central VM-DOC <---- vCenter / Veeam / Prometheus / FortiGate
          |
          +-- UI / filtre / rapoarte / API / export Excel
          +-- DOCX / PDF / MD
          +-- Outline (numai resurse eligibile, fără date Vault)
          +-- Securitate / Conturi VM / dependențe / beneficiari
```

### Configurație server exemplificată anterior

Aceste valori sunt **repere istorice**, nu configurație verificată curentă:

```yaml
listen: "0.0.0.0:9080"
trusted_proxies: ["127.0.0.1"]
allowed_networks: ["172.20.0.0/16"]
vcenter:
  allow_http: false
  request_timeout: "60s"
  detail_workers: 8
  scheduler_interval: "1m"
```

Nu transforma valorile exemplificative în instrucțiuni de producție fără verificarea configurației reale. **Nu introduce parole, tokenuri, secrete sau linkuri Vault în acest fișier.**

## 3. Agenți: platforme, colectori, actualizare

### Platforme avute în vedere

- Linux `amd64` și `386` — distribuții curente și vechi: Ubuntu, Debian, CentOS, RHEL, SUSE/SLES.
- Windows `amd64` și, în funcție de build, `386`; Windows XP/legacy necesită ramuri/toolchain distincte.
- **SLES9** — agent legacy separat, deoarece mediul este foarte vechi.
- Compatibilitatea fiecărui binar trebuie verificată cu release manifest; nu echivala lista de platforme cerute cu o matrice de binare finalizate.

### Colectori și arii de inventariere

`system`, `storage`, `network`, `services`, `listening_ports`, `firewall`, `accounts`, `sssd`, `integrations`, `policies`, `cron`, `ntp`, precum și inventarierea Web/DB/Docker și a componentelor software, potrivit suportului pe platformă.

### Reguli importante

- Identificarea agenților trebuie să evite coliziunile `agent_id` după clonarea VM-urilor.
- La agentul modern 1.7.15, mecanismul de refresh a fost schimbat: **POST refresh → ACK**, urmat de **GET** server-side pentru inventarul unic.
- Pentru Linux vechi (ex. CentOS 7/systemd 219), ține cont de compatibilitatea instalării/systemd și de faptul că un bootstrap manual poate fi necesar.
- **Releases:** diferențiază agent modern de `sles9-legacy`, XP și `windows-legacy`; nu distribui un executabil modern ca înlocuitor presupus compatibil pentru legacy.
- **Pachete cerute:** arhivă unică cu toate variantele de agent și **sursele complete**, nu doar patch-uri; alături de binare, manifest platformă/versiune, instrucțiuni de build offline, checksum SHA256.

## 4. Model de inventar și pagini aplicație

### VM-uri

- Import/corelare vCenter: nume, stări power **ON/OFF/SUSP/UNKNOWN**, status operațional **Active/Retired**, mediu **PROD/TEST/DEV**; VM fără potrivire trebuie tratate distinct.
- Identitate: hostname/FQDN/IP principal, sistem de operare, status agent, versiune agent, ultimă colectare, grad de completare, administrare și date tehnice.
- Liste paginate, căutare, filtre și export; cardurile de sumar sunt interactive.
- Rețea în structura de securitate; afișarea tabelelor late trebuie să permită un **scroll orizontal utilizabil al paginii**, fără scroll-uri imbricate inutile.
- Secțiunile goale pot fi ascunse, fără a ascunde erori autentice de colectare.

### Servicii

- Legături la VM-urile componente; clasificare, mediu, status operațional, tip soluție, beneficiari; fișe DOCX/PDF/MD și publicare Outline pentru resurse eligibile.
- Asociere cu baze de date, site-uri/aplicații web, Docker/Compose, backup și relații de infrastructură; listări paginate, export Excel.
- Documentația serviciului conține doar datele permise de politica de publicare.

### Componente suport / software

- Răspunsuri la întrebări: „Pe ce VM-uri există PostgreSQL?”, „Unde rulează MongoDB?”, „Care VM-uri au versiunea X de componentă?”.
- Inventar automat agregat din DB, Web, Docker, servicii și software; deduplicare în raportul transversal, fără a pierde identitatea **instanțelor** DB.
- Raport cu filtre, carduri, paginare, export Excel; publicare în Outline per componentă sau în bloc; linkuri spre documentațiile VM și serviciilor, dacă sunt disponibile.
- Separație între „Componente software” (inventarul observat) și „Componente suport” (vedere/raport/documentare).

## 5. Inventarierea bazelor de date — atenție la instanțe

### Cerințe ferme

- O singură VM poate găzdui **mai multe instanțe ale aceluiași motor** (PostgreSQL, MongoDB, MySQL/MariaDB etc.).
- Instanțele **native** și cele din **Docker** trebuie enumerate separat și identificate stabil; corelează containerul/ID-ul de container, endpoint-ul/portul și motorul/versiunea.
- Nu dubla detecția Docker și detecția procesului nativ pentru aceeași instanță.
- Enumerarea bazelor de date și obiectelor relevante se face **per instanță**, nu doar per motor sau per VM.
- Pentru MongoDB 4.4.11 poate exista utilitarul **`mongo`**, nu `mongosh`; fallback `mongosh` → `mongo` este necesar. Verifică suportul de autentificare și rolurile înainte de a declara colectarea completă.
- **IBM Db2:** serverul 0.21.8 introduce **ignorare implicită/configurabilă central**, prin migrarea `073` și API/Swagger. Datele brute colectate se păstrează; afișarea/folosirea lor poate fi exclusă prin configurare. Nu presupune că agentul nu-l mai detectează.
- **Redis:** nu se dezvoltă enumerarea separată a bazelor logice (`db0`, `db1` etc.) în acest proiect; dacă nu interesează inventarul DB, se poate bifa în **Nomenclatoare → Inventar tehnic → Motoare DB ignorate**. Redis rămâne detectabil ca Docker și Componentă software; păstrează informațiile despre serviciile dependente.
- **MongoDB SECONDARY:** pe MongoDB 4.4.11 cu clientul vechi `mongo`, citirea bazelor a reușit după activarea preferinței de citire secundară. Agent 1.7.16 folosește `secondaryPreferred`; testarea end-to-end pe serverul real rămâne necesară.
- **Autentificare DB:** în prima etapă inventarierea se încearcă numai cu acces local existent, cu motiv explicit pentru enumerare incompletă. Ulterior: credențiale per instanță, minime și păstrate securizat/Vault. Agentul **nu extrage parole** din Compose, `.env`, variabile de mediu sau configurații ale aplicațiilor.
- **Server 0.21.9:** `origin`, `container_id`, `container_name`, `container_image`, `compose_project`, `replica_set`, `replica_role`, `replica_primary` sunt păstrate în `database_instances` (migrarea `074`) și returnate în fișa VM; instanțele Docker folosesc `engine + container_id` pentru a evita coliziunea pe același port intern. Păstrează vechea identitate nativă. Adoptă înregistrări istorice doar dacă potrivirea este neambiguă.


### Corecții Agent 1.7.17 (2026-10-13)

- Pentru `mongo` clasic pe MongoDB 4.4 SECONDARY, `getDBs()` funcționează după `db.getMongo().setSecondaryOk()`. Test confirmat pe VM reală de utilizator; agentul 1.7.17 implementează metoda și fallback pentru clienți diferiți.
- Pentru PostgreSQL în Docker cu rol SQL diferit de `postgres`, interogarea a funcționat cu `POSTGRES_USER`/`POSTGRES_DB` deja prezente în container; agentul **nu citește POSTGRES_PASSWORD**. O execuție a durat 2,691 s. Timeout implicit pentru comenzi Docker DB: **15 s**, configurabil prin `VM_DOC_DB_QUERY_TIMEOUT_SECONDS` (5–60).
- Pentru MariaDB `ilias_mysql_1`, clientul prezent este `mariadb` (nu `mysql`) și accesul fără credențiale returnează `Access denied`: agentul păstrează `authentication_required` și nu încearcă să recupereze parole din Compose/env.
- Arhiva `vm-doc-agents-all-2026-10-13-v1.7.17-with-source.zip` conține toate build-urile moderne, pachetele legacy **nemodificate** (XP 1.0.1, Windows legacy 1.0.2, SLES9 1.0.1), sursele Go 1.7.16 și 1.7.17 și patch verificat. Schema inventar **2.12**, serverul **0.21.9** rămâne compatibil fără migrare.
- Teste raportate la generare: `go test ./...` reușit, 4 platforme moderne compilate, mock Docker, ZIP/TAR, SHA256 și patch aplicat. **Nu** au fost efectuate teste reale pe VM-uri cu noul binar 1.7.17 sau pe OS legacy.

### Stadiu

- 0.21.8: filtrare centralizată Db2 raportată ca implementată; agent nemodificat pentru această funcție.
- 1.7.16: pachetul complet cu variante moderne + legacy și surse a fost generat; variantele XP/SLES9 sunt **binare legacy păstrate**, nu compilări 1.7.16.
- 0.21.9: integrare server pentru schema agentului, migrare `074`, afișare origine/cluster și export XLSX/API.
- **De verificat:** instalarea reală a agentului și serverului, MongoDB 4.4 (`mongo`/SECONDARY), accesul cu autentificare, identitățile Docker la recrearea containerelor și migrația MariaDB.


## 6. Securitate, conturi și politici

- Meniu **Securitate → Conturi VM**: situația controalelor de politică parole; câmpuri/concepte `enforcement_status`, `effective`, `checks` și cardul Politică parole în fișa VM.
- Linux: utilizatorii cu UID sub 1000 pot fi clasificați ca „system” și excluși din evaluarea obișnuită a conturilor, **cu excepția root**, care trebuie păstrat.
- Pentru SLES9, determinarea politicilor folosește `login.defs`, PAM și shadow; compatibilitate cu familiile linuxlike (`suse/sles/debian/redhat`).
- Rapoarte/revizii pentru conturi, acces web, baze de date și reguli FortiGate.
- Autentificare server: LDAP/AD, maparea grupurilor/rolurilor și OIDC cu Keycloak, unde configurat.
- **Confidențialitate obligatorie:** linkurile Vault asociate VM/servicii rămân **strict interne aplicației**. **Nu** apar în DOCX, PDF, Markdown, Outline, exporturi sau în alte artefacte publicate/generate.
- Nu propaga secretele colectate în loguri sau în documentele rezultate.

## 7. Publicarea în Outline — reguli stricte

1. **Numai PROD** poate fi publicat: VM-uri, servicii și componente suport eligibile. Resursele TEST/DEV/nespecificate se sar și se explică de ce.
2. Dacă VM are opțiunea **„Nu se publică în Outline”**, aceasta se aplică atât în UI, cât și în API/server; nu doar ascundere de buton.
3. Pentru VM, titlul paginii Outline are prefixul **`vm-`**; pentru paginile componentelor suport se folosește **`comp-`**.
4. Publicare individuală și bulk, cu procesare asincronă pentru a evita gateway timeout la volume mari; listări paginate.
5. Linkurile Outline ale VM-urilor și serviciilor trebuie folosite în rapoartele/componentele suport; la redenumire verifică rezolvarea backlink-urilor.
6. Nu publica date non-PROD printr-un serviciu/componentă PROD și **niciodată linkuri Vault**.
7. Părinții/colecțiile Outline sunt configurabile (inclusiv „Componente suport”); rezultatele publicării trebuie să permită identificarea erorilor/săriturilor.

## 8. FortiGate — politici, corelare, diagramă

- Căutare după IP de VM ca **sursă** și ca **destinație**; corelare și cu obiecte subnet/CIDR care conțin acel IP (ex.: `10.20.10.25` intră în `10.20.10.0/24`).
- Se ține cont de policy status; regulile **disabled** nu trebuie să polueze rezultatele.
- Corelările cu reguli FortiGate au necesitat profil/API și optimizare pentru a elimina sute de mii de false match-uri.
- Tabel cu sursă, destinație, servicii/porturi permise (fiecare pe rând), politica și **VDOM / NAT / No NAT**; IP-urile trebuie vizibile.
- În diagrama tip Visio: VM-ul central o singură dată, fluxuri către porturile afișate vertical, adresele grupate (3–4 vizibile + expand), fără suprapuneri, padding între numărul regulii și VDOM/NAT.
- UDP se poate ignora în vederea cerută; ascunde porturile DNS (ex. 53) pe VM-uri AD/DNS conform regulilor aplicației.
- Fără limitare arbitrară la 24 fluxuri dacă astfel se pierd informații; performanța și lizibilitatea trebuie gestionate explicit.
- Secțiunea Forti include surse/sincronizare, căutare și analiză; datele filtrabile/exportabile Excel.

## 9. Monitorizare, backup și infrastructură

### Prometheus / Monitorizare

- Mai multe surse Prometheus; test/sync/scheduler, inventar de targets.
- Corelare target ↔ VM pe label, FQDN, hostname și IP, inclusiv IPv4 guest din vCenter.
- Carduri și taburi de Monitorizare; UI Agenți reutilizează stilul `monitoring-section-tabs`.

### Veeam

- Test/sync, situație VM **protejate/neprotejate**, job, repository, next run, retenții GFS/copy, backup în fișa VM și a serviciului.
- Există cerințe pentru politica de backup primară și copii, dar configurația reală Veeam trebuie verificată din sursa conectată.

### vCenter și alte dependențe

- Import/sincronizare VM, power, sistem de operare, IP-uri și stare administrativă.
- Dependențe infrastructură: DNS, AD/OpenLDAP, conectivitate, rute, firewall.
- **GLPI/SCCM/LibreNMS** pot exista în peisajul operațional, dar nu trebuie declarate drept integrare directă VM-DOC fără confirmare în cod/config.

## 10. Beneficiari (AD și manual)

- Beneficiarii pot fi OU-uri din Active Directory sub un base DN configurat și entități adăugate manual; păstrează proveniența **AD/manual**.
- Nomenclator **Beneficiari** cu contor; import persoane AD pentru selecții când se cere.
- Asociere **unul sau mai mulți beneficiari** la VM, serviciu, baze de date, web, Docker și Docker Compose; propagare/corelare în rapoartele Servicii/Componente suport.
- Raportarea trebuie să răspundă: „Ce servicii, componente, baze, web, containere și VM-uri are departamentul X?”. Export Excel și API/Swagger.
- 0.21.0 a fost raportat ca livrând baza acestor funcții; 0.21.7 a adăugat contor și rafinări UI Compose, fără migrare nouă sau agent nou.
- În Docker Compose: păstrează selecțiile **Serviciu**, **Mediu**, **Status operațional**, **Tip soluție**; nu adăuga rânduri suplimentare separate pentru Servicii/Beneficiari; valorile diferite trebuie afișate coerent și persistate.

## 11. UX, rapoarte și performanță

- Listări mari: paginare reală SQL acolo unde este posibil; nu încărca toate rândurile în browser doar pentru a pagina.
- Pagina Agenți 0.20.99: încărcare separată pentru navigație/filtre și date; fast path cu `COUNT(*)`, `LIMIT/OFFSET` fără filtre; căutare cu debounce **350 ms**; filtre avansate păstrează traseul complet.
- Cardurile de sumar sunt **clicabile** și filtrează tabela asociată, acolo unde există această convenție.
- Tabelele late trebuie să permită accesul real la coloanele din dreapta prin scroll orizontal vizibil; evită scroll-ul în scroll.
- Rapoarte: OS suportat, componente suport, securitate/revizii, Veeam, Forti, beneficiari; filtre, paginare, export Excel, vizualizări după mediu/power.
- În inventarul Docker, un container nu necesită automat documentație separată; documentarea se concentrează pe serviciu, integrare și relații.
- Secțiunea Web trebuie să considere fișierele `location` și `*.conf` relevante; bazele de sistem ale motoarelor SQL se ascund din inventarul de business.

## 12. Istoric selectiv al release-urilor

Vezi `CHANGELOG.md` pentru date, modificări și limitele validării. Repere majore:

- `0.20.53–0.20.60`: documentare/publicare Outline asincronă, inventar componente software, Componente suport și mapări părinte.
- `0.20.74–0.20.81`: FortiGate și diagrama de rețea/interdependențe, reguli de afișare.
- `0.20.91–0.20.99`: politici parole, SLES9 legacy, filtre VM, pagină Agenți și optimizări.
- `0.21.0–0.21.7`: beneficiari, AD/OU, asocieri și rafinări Compose/UI.
- `0.21.8`: filtrare centrală Db2 configurabilă, migrare `073`.
- `0.21.9`: integrarea multi-instanță DB a agentului 1.7.16, originea Docker/nativ, Replica Set MongoDB, migrare `074`, UI/XLSX/OpenAPI; testele server complete și MariaDB reală încă necesare.
- `1.7.15 → 1.7.16`: colectare multi-instanță DB și metadate Docker/Replica Set.
- `1.7.17`: MongoDB classic SECONDARY, PostgreSQL Docker POSTGRES_USER/DB, timeout 15 s și diagnostic MariaDB. Arhivă unică binare+surse+legacy.

## 13. Probleme deschise / verificări obligatorii

### Prioritate imediată

- [ ] **Validează Server 0.21.9 pe staging:** build complet folosind `vendor/` existent, migrarea MariaDB `074`, UI și endpointuri; release-ul livrat nu echivalează cu instalare reușită.
- [ ] **Instalează și validează Agent 1.7.17** pe MongoDB SECONDARY și pe VM-urile cu PostgreSQL/MariaDB Docker; build-urile legacy XP/SLES9 nu au fost recompilate.
- [x] Arhiva cumulată a agenților 1.7.16 cu sursele Go, patch, binare moderne și pachete legacy este disponibilă; nu presupune că toate au fost testate pe OS real.
- [ ] Testează complet inventarierea DB native vs Docker, mai multe instanțe din același motor, porturi și identitate stabilă.
- [ ] Testează MongoDB 4.4.11 cu clientul clasic `mongo`, credențiale, drepturi și rol SECONDARY.
- [ ] Compilează/testează release-urile recente server cu dependențe complete și testează migrațiile/operarea pe MariaDB reală; nu presupune că validarea patch/JS/OpenAPI este suficientă.

### Alte verificări/regresii

- [ ] Coliziuni `agent_id` după clonarea VM.
- [ ] Deduplicarea istoriei colectărilor server-side.
- [ ] Redenumiri și backlink-uri Outline (Componente suport ↔ VM/servicii).
- [ ] Publicări mari Outline fără `504 Gateway Timeout` și fără scurgeri de date non-PROD/Vault.
- [ ] Corelarea FortiGate: subnet, disabled, NAT/VDOM, porturi, excluderi UDP/DNS, performanță.
- [ ] Comportament UI pentru liste lungi și tabele late; evitarea suprapunerilor în diagrame.
- [ ] Instalare/upgrade pe platforme legacy: SLES9, XP, Linux `386`, Windows `386` unde suportate.

## 14. Reguli de implementare pentru orice conversație viitoare

1. **Nu elimina funcționalități existente** când rezolvi un bug punctual; preferă patch-uri incrementale.
2. Când propui un release, precizează exact **versiunea de pornire**, fișierele schimbate, migrațiile, compatibilitatea cu agenții și efectele asupra documentelor/API/UI.
3. Dacă sunt disponibile arhivele reale, **inspectează sursa înainte de editare**. Nu reconstrui arbitrar aplicația din acest rezumat.
4. Nu pretinde că un ZIP/binăr/sursă a fost generat, compilat sau verificat fără dovadă și linkul către un fișier existent.
5. Pentru release-uri offline include: **pachet complet**, **surse**, **patch**, **instrucțiuni upgrade/rollback**, **release notes**, **SHA256**, matrice de compatibilitate și eventual `vendor/`/dependințe necesare.
6. Nu introduce linkuri Vault, secrete sau date de producție în materialele exportate/publicate.
7. Publicare Outline **numai PROD** și control aplicat pe server/API, nu doar în UI.
8. Fă diferența între **componentă instalată** și **instanță concretă** (în special baze de date și containere).
9. Menține acest `CONTEXT.md` ca **stare curentă** și `CHANGELOG.md` ca **istoric**; nu transforma documentele în jurnal de discuții.
10. La sfârșitul unei sesiuni de dezvoltare actualizează explicit: versiune livrată, fișiere construite, teste, migrații, probleme deschise și următorul pas.

## 15. Model de rezumat de transfer după un nou release

Copiază și completează la finalul chatului, apoi actualizează cele două fișiere:

```text
Data:
Versiune server inițială -> finală:
Versiuni agent afectate:
Scopul modificării:
Fișiere / module schimbate:
Migrații DB:
Schimbări API / Swagger:
Schimbări UI:
Compatibilitate / upgrade:
Teste rulate (și rezultate):
Arhive efectiv generate (nume exacte + SHA256):
Probleme rămase:
Următorul pas:
```

---

**Notă de precizie:** Informațiile sunt un rezumat al discuțiilor și al livrărilor raportate, nu o substituție pentru arhivele originale, codul sursă, migrațiile SQL, manifestele release sau configurarea curentă din mediu. Dacă există contradicții, prioritatea o au artefactele verificate și rezultatele testelor.


## Actualizare 2026-10-13 — Server 0.21.14
- Hotfix pentru `scripts/cleanup-source-tree.sh`: conflictele între documentele UPGRADE/RELEASE-NOTES din rădăcină și `docs/history/` sunt păstrate ca variante distincte în `docs/history/variants/`, nu mai blochează `--apply`.
- Copiile diferite nu sunt suprascrise; variantele folosesc hash SHA-256; scriptul este idempotent.
- Nu afectează aplicația în execuție, agentul, migrarea 075 sau schema API.

### 0.21.22 — UI VM (2026-10-14)
- Inventar VM și rezumat VM folosesc 7 KPI egale distribuite pe întreaga lățime desktop la 1595px; responsive la rezoluții mai mici.
- Rezumat Responsabilități arată toate persoanele distincte separate prin virgulă, inclusiv persoanele cu rol technical_admin, dar fără numele rolurilor.
- Reperele De completat sunt linkuri la secțiunile VM relevante, cu focus scroll pe câmpuri acolo unde există.
- Fără SQL nou, fără agent nou; agentul curent rămâne 1.7.18.
