package vcenter

import (
	"strings"
	"testing"
)

func TestVMGlobalSortAllColumns(t *testing.T) {
	for name := range vmSortColumns {
		for _, dir := range []string{"asc", "desc"} {
			filter := NormalizeVMFilter(VMFilter{Sort: name + ":" + dir})
			if _, _, err := buildVMWhere(filter); err != nil {
				t.Fatalf("sort %s: %v", filter.Sort, err)
			}
			sql, err := vmOrderBy(filter)
			if err != nil || !strings.Contains(sql, " ORDER BY ") || !strings.Contains(sql, "vm.id ASC") {
				t.Fatalf("sort %s: %q %v", filter.Sort, sql, err)
			}
		}
	}
}
func TestVMGlobalSortRejectsInvalid(t *testing.T) {
	for _, value := range []string{"name:random", "anything:asc", "name:asc;DROP TABLE virtual_machines", "name DESC", "name:asc:desc", "completion_desc"} {
		if _, err := vmOrderBy(NormalizeVMFilter(VMFilter{Sort: value})); err == nil {
			t.Errorf("accepted %q", value)
		}
	}
}
func TestVMGlobalSortPreservesLegacyAndDefault(t *testing.T) {
	for _, sort := range []string{"", "completion_asc"} {
		sql, err := vmOrderBy(NormalizeVMFilter(VMFilter{Sort: sort, Presence: "missing"}))
		if err != nil || !strings.Contains(sql, "ORDER BY") {
			t.Fatalf("%q: %q %v", sort, sql, err)
		}
	}
}
