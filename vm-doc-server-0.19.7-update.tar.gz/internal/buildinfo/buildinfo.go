package buildinfo

var (
	Version = "0.19.7-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
