# Upgrade vm-doc-server 0.19.6 → 0.19.7

0.19.7 este un release de UI/UX pentru pagina Servicii. Nu modifică schema bazei de date și nu necesită upgrade de agent sau collector.

## Noutăți

- fișa serviciului folosește aceeași navigare pe taburi/subtabs ca fișa VM;
- zone principale: Rezumat, Detalii, Arhitectură, Componente, Dependențe și Documentație;
- Arhitectură: Medii, Clasificare, Schemă;
- Componente: VM-uri, Baze de date, Docker, Web;
- Dependențe: Servicii comune, Sisteme externe și Impact pentru serviciile comune;
- toate datele care se modifică din „Editează serviciul” sunt vizibile în tabul Detalii;
- după editare, utilizatorul rămâne pe secțiunea curentă;
- URL-urile/hash-urile serviciilor pot indica direct secțiunea: `#services/<id>/<section>`.

## Instalare

```bash
cd /usr/local/src
cp -a vm-doc-server-0.19.6 vm-doc-server-0.19.7
tar -xzf /home/andrei.ciornei/vm-doc-server-0.19.7-update.tar.gz -C /usr/local/src/vm-doc-server-0.19.7
cd /usr/local/src/vm-doc-server-0.19.7
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
systemctl stop vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
systemctl start vm-doc-server
```

Collectorul nu necesită rebuild/install pentru această versiune. După upgrade folosiți `Ctrl+F5` pentru JavaScript/CSS 0.19.7.

## Verificări rapide

1. `/version` trebuie să raporteze `0.19.7`.
2. Deschideți un serviciu: implicit se afișează `Rezumat`.
3. Tabul `Detalii` trebuie să conțină denumirea, codul, criticitatea, statusul documentației, tipul serviciului, descrierea, scopul, obiectivele și linkul documentației.
4. `Arhitectură` și `Componente` trebuie să afișeze subtabs.
5. După `Editează serviciul` → `Salvează`, pagina trebuie să rămână în tabul curent.
